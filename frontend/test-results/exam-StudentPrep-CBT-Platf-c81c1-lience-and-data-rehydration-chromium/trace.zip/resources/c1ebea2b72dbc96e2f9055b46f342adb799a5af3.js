const React = __vite__cjsImport0_react;const ReactDOM = __vite__cjsImport1_reactDom_client;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=cdd924ad";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=1abb49e3";
import { Provider } from "/node_modules/.vite/deps/react-redux.js?v=987a6311";
import { store } from "/src/store/store.ts";
import App from "/src/App.tsx";
import "/src/index.css?t=1787633556593";
var _jsxFileName = "C:/Users/User/Desktop/studentprep/frontend/src/main.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cdd924ad";
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(React.StrictMode, { children: /* @__PURE__ */ _jsxDEV(Provider, {
	store,
	children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 7
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 10,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 9,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sY0FBYztBQUNyQixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGFBQWE7QUFDdEIsT0FBTyxTQUFTO0FBQ2hCLE9BQU87OztBQUVQLFNBQVMsV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFnQixDQUFDLENBQUMsT0FDbEUsd0JBQUMsTUFBTSxZQUFQLFlBQ0Usd0JBQUMsVUFBRDtDQUFpQjtXQUNmLHdCQUFDLEtBQUQsQ0FBTTs7Ozs7QUFDRTs7OztTQUNNOzs7O1FBQ3BCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tICdyZWFjdC1yZWR1eCdcbmltcG9ydCB7IHN0b3JlIH0gZnJvbSAnLi9zdG9yZS9zdG9yZSdcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAnXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xuXG5SZWFjdERPTS5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykgYXMgSFRNTEVsZW1lbnQpLnJlbmRlcihcbiAgPFJlYWN0LlN0cmljdE1vZGU+XG4gICAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0+XG4gICAgICA8QXBwIC8+XG4gICAgPC9Qcm92aWRlcj5cbiAgPC9SZWFjdC5TdHJpY3RNb2RlPixcbilcclxuIl19