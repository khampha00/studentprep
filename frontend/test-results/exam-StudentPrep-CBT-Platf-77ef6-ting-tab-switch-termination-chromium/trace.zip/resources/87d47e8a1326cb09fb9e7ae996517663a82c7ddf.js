import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/alert-dialog.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=cdd924ad";
import { AlertDialog as AlertDialogPrimitive } from "/node_modules/.vite/deps/@base-ui_react_alert-dialog.js?v=e0985a69";
import { cn } from "/src/lib/utils.ts";
import { Button } from "/src/components/ui/button.tsx";
var _jsxFileName = "C:/Users/User/Desktop/studentprep/frontend/src/components/ui/alert-dialog.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cdd924ad";
function AlertDialog({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Root, {
		"data-slot": "alert-dialog",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 10
	}, this);
}
_c = AlertDialog;
function AlertDialogTrigger({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Trigger, {
		"data-slot": "alert-dialog-trigger",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_c2 = AlertDialogTrigger;
function AlertDialogPortal({ ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Portal, {
		"data-slot": "alert-dialog-portal",
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
}
_c3 = AlertDialogPortal;
function AlertDialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Backdrop, {
		"data-slot": "alert-dialog-overlay",
		className: cn("fixed inset-0 isolate z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_c4 = AlertDialogOverlay;
function AlertDialogContent({ className, size = "default", ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPortal, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogOverlay, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Popup, {
		"data-slot": "alert-dialog-content",
		"data-size": size,
		className: cn("group/alert-dialog-content fixed top-1/2 left-1/2 z-50 grid w-full -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-popover p-4 text-popover-foreground ring-1 ring-foreground/10 duration-100 outline-none data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
}
_c5 = AlertDialogContent;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		"data-slot": "alert-dialog-header",
		className: cn("grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-4 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-left sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 5
	}, this);
}
_c6 = AlertDialogHeader;
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		"data-slot": "alert-dialog-footer",
		className: cn("-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t bg-muted/50 p-4 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 83,
		columnNumber: 5
	}, this);
}
_c7 = AlertDialogFooter;
function AlertDialogMedia({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		"data-slot": "alert-dialog-media",
		className: cn("mb-2 inline-flex size-10 items-center justify-center rounded-md bg-muted sm:group-data-[size=default]/alert-dialog-content:row-span-2 *:[svg:not([class*='size-'])]:size-6", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 99,
		columnNumber: 5
	}, this);
}
_c8 = AlertDialogMedia;
function AlertDialogTitle({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Title, {
		"data-slot": "alert-dialog-title",
		className: cn("font-heading text-base font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 115,
		columnNumber: 5
	}, this);
}
_c9 = AlertDialogTitle;
function AlertDialogDescription({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Description, {
		"data-slot": "alert-dialog-description",
		className: cn("text-sm text-balance text-muted-foreground md:text-pretty *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 131,
		columnNumber: 5
	}, this);
}
_c10 = AlertDialogDescription;
function AlertDialogAction({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV(Button, {
		"data-slot": "alert-dialog-action",
		className: cn(className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 147,
		columnNumber: 5
	}, this);
}
_c11 = AlertDialogAction;
function AlertDialogCancel({ className, variant = "outline", size = "default", ...props }) {
	return /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Close, {
		"data-slot": "alert-dialog-cancel",
		className: cn(className),
		render: /* @__PURE__ */ _jsxDEV(Button, {
			variant,
			size
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 166,
			columnNumber: 15
		}, this),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 163,
		columnNumber: 5
	}, this);
}
_c12 = AlertDialogCancel;
export { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogMedia, AlertDialogOverlay, AlertDialogPortal, AlertDialogTitle, AlertDialogTrigger };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12;
$RefreshReg$(_c, "AlertDialog");
$RefreshReg$(_c2, "AlertDialogTrigger");
$RefreshReg$(_c3, "AlertDialogPortal");
$RefreshReg$(_c4, "AlertDialogOverlay");
$RefreshReg$(_c5, "AlertDialogContent");
$RefreshReg$(_c6, "AlertDialogHeader");
$RefreshReg$(_c7, "AlertDialogFooter");
$RefreshReg$(_c8, "AlertDialogMedia");
$RefreshReg$(_c9, "AlertDialogTitle");
$RefreshReg$(_c10, "AlertDialogDescription");
$RefreshReg$(_c11, "AlertDialogAction");
$RefreshReg$(_c12, "AlertDialogCancel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/alert-dialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/User/Desktop/studentprep/frontend/src/components/ui/alert-dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/User/Desktop/studentprep/frontend/src/components/ui/alert-dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/User/Desktop/studentprep/frontend/src/components/ui/alert-dialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsWUFBWSxXQUFXO0FBQ3ZCLFNBQVMsZUFBZSw0QkFBNEI7QUFFcEQsU0FBUyxVQUFVO0FBQ25CLFNBQVMsY0FBYzs7O0FBRXZCLFNBQVMsWUFBWSxFQUFFLEdBQUcsU0FBMEM7Q0FDbEUsT0FBTyx3QkFBQyxxQkFBcUIsTUFBdEI7RUFBMkIsYUFBVTtFQUFlLEdBQUk7Q0FBUTs7Ozs7QUFDekU7O0FBRUEsU0FBUyxtQkFBbUIsRUFBRSxHQUFHLFNBQTZDO0NBQzVFLE9BQ0Usd0JBQUMscUJBQXFCLFNBQXRCO0VBQThCLGFBQVU7RUFBdUIsR0FBSTtDQUFROzs7OztBQUUvRTs7QUFFQSxTQUFTLGtCQUFrQixFQUFFLEdBQUcsU0FBNEM7Q0FDMUUsT0FDRSx3QkFBQyxxQkFBcUIsUUFBdEI7RUFBNkIsYUFBVTtFQUFzQixHQUFJO0NBQVE7Ozs7O0FBRTdFOztBQUVBLFNBQVMsbUJBQW1CLEVBQzFCLFdBQ0EsR0FBRyxTQUNtQztDQUN0QyxPQUNFLHdCQUFDLHFCQUFxQixVQUF0QjtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQ1QseUxBQ0EsU0FDRjtFQUNBLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLG1CQUFtQixFQUMxQixXQUNBLE9BQU8sV0FDUCxHQUFHLFNBR0Y7Q0FDRCxPQUNFLHdCQUFDLG1CQUFELGFBQ0Usd0JBQUMsb0JBQUQsQ0FBcUI7Ozs7V0FDckIsd0JBQUMscUJBQXFCLE9BQXRCO0VBQ0UsYUFBVTtFQUNWLGFBQVc7RUFDWCxXQUFXLEdBQ1QsOGFBQ0EsU0FDRjtFQUNBLEdBQUk7Q0FDTDs7OztTQUNnQjs7Ozs7QUFFdkI7O0FBRUEsU0FBUyxrQkFBa0IsRUFDekIsV0FDQSxHQUFHLFNBQzJCO0NBQzlCLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQ1Qsc1pBQ0EsU0FDRjtFQUNBLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLGtCQUFrQixFQUN6QixXQUNBLEdBQUcsU0FDMkI7Q0FDOUIsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsYUFBVTtFQUNWLFdBQVcsR0FDVCxpTkFDQSxTQUNGO0VBQ0EsR0FBSTtDQUNMOzs7OztBQUVMOztBQUVBLFNBQVMsaUJBQWlCLEVBQ3hCLFdBQ0EsR0FBRyxTQUMyQjtDQUM5QixPQUNFLHdCQUFDLE9BQUQ7RUFDRSxhQUFVO0VBQ1YsV0FBVyxHQUNULDhLQUNBLFNBQ0Y7RUFDQSxHQUFJO0NBQ0w7Ozs7O0FBRUw7O0FBRUEsU0FBUyxpQkFBaUIsRUFDeEIsV0FDQSxHQUFHLFNBQ3VEO0NBQzFELE9BQ0Usd0JBQUMscUJBQXFCLE9BQXRCO0VBQ0UsYUFBVTtFQUNWLFdBQVcsR0FDVCxrS0FDQSxTQUNGO0VBQ0EsR0FBSTtDQUNMOzs7OztBQUVMOztBQUVBLFNBQVMsdUJBQXVCLEVBQzlCLFdBQ0EsR0FBRyxTQUM2RDtDQUNoRSxPQUNFLHdCQUFDLHFCQUFxQixhQUF0QjtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQ1Qsa0lBQ0EsU0FDRjtFQUNBLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLGtCQUFrQixFQUN6QixXQUNBLEdBQUcsU0FDbUM7Q0FDdEMsT0FDRSx3QkFBQyxRQUFEO0VBQ0UsYUFBVTtFQUNWLFdBQVcsR0FBRyxTQUFTO0VBQ3ZCLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7QUFFQSxTQUFTLGtCQUFrQixFQUN6QixXQUNBLFVBQVUsV0FDVixPQUFPLFdBQ1AsR0FBRyxTQUU0RDtDQUMvRCxPQUNFLHdCQUFDLHFCQUFxQixPQUF0QjtFQUNFLGFBQVU7RUFDVixXQUFXLEdBQUcsU0FBUztFQUN2QixRQUFRLHdCQUFDLFFBQUQ7R0FBaUI7R0FBZTtFQUFPOzs7OztFQUMvQyxHQUFJO0NBQ0w7Ozs7O0FBRUw7O0FBRUEsU0FDRSxhQUNBLG1CQUNBLG1CQUNBLG9CQUNBLHdCQUNBLG1CQUNBLG1CQUNBLGtCQUNBLG9CQUNBLG1CQUNBLGtCQUNBIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImFsZXJ0LWRpYWxvZy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCJcbmltcG9ydCB7IEFsZXJ0RGlhbG9nIGFzIEFsZXJ0RGlhbG9nUHJpbWl0aXZlIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L2FsZXJ0LWRpYWxvZ1wiXG5cbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCJcblxuZnVuY3Rpb24gQWxlcnREaWFsb2coeyAuLi5wcm9wcyB9OiBBbGVydERpYWxvZ1ByaW1pdGl2ZS5Sb290LlByb3BzKSB7XG4gIHJldHVybiA8QWxlcnREaWFsb2dQcmltaXRpdmUuUm9vdCBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2dcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nVHJpZ2dlcih7IC4uLnByb3BzIH06IEFsZXJ0RGlhbG9nUHJpbWl0aXZlLlRyaWdnZXIuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8QWxlcnREaWFsb2dQcmltaXRpdmUuVHJpZ2dlciBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctdHJpZ2dlclwiIHsuLi5wcm9wc30gLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ1BvcnRhbCh7IC4uLnByb3BzIH06IEFsZXJ0RGlhbG9nUHJpbWl0aXZlLlBvcnRhbC5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxBbGVydERpYWxvZ1ByaW1pdGl2ZS5Qb3J0YWwgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nLXBvcnRhbFwiIHsuLi5wcm9wc30gLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ092ZXJsYXkoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBBbGVydERpYWxvZ1ByaW1pdGl2ZS5CYWNrZHJvcC5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxBbGVydERpYWxvZ1ByaW1pdGl2ZS5CYWNrZHJvcFxuICAgICAgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nLW92ZXJsYXlcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmaXhlZCBpbnNldC0wIGlzb2xhdGUgei01MCBiZy1ibGFjay8xMCBkdXJhdGlvbi0xMDAgc3VwcG9ydHMtYmFja2Ryb3AtZmlsdGVyOmJhY2tkcm9wLWJsdXIteHMgZGF0YS1vcGVuOmFuaW1hdGUtaW4gZGF0YS1vcGVuOmZhZGUtaW4tMCBkYXRhLWNsb3NlZDphbmltYXRlLW91dCBkYXRhLWNsb3NlZDpmYWRlLW91dC0wXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nQ29udGVudCh7XG4gIGNsYXNzTmFtZSxcbiAgc2l6ZSA9IFwiZGVmYXVsdFwiLFxuICAuLi5wcm9wc1xufTogQWxlcnREaWFsb2dQcmltaXRpdmUuUG9wdXAuUHJvcHMgJiB7XG4gIHNpemU/OiBcImRlZmF1bHRcIiB8IFwic21cIlxufSkge1xuICByZXR1cm4gKFxuICAgIDxBbGVydERpYWxvZ1BvcnRhbD5cbiAgICAgIDxBbGVydERpYWxvZ092ZXJsYXkgLz5cbiAgICAgIDxBbGVydERpYWxvZ1ByaW1pdGl2ZS5Qb3B1cFxuICAgICAgICBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctY29udGVudFwiXG4gICAgICAgIGRhdGEtc2l6ZT17c2l6ZX1cbiAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICBcImdyb3VwL2FsZXJ0LWRpYWxvZy1jb250ZW50IGZpeGVkIHRvcC0xLzIgbGVmdC0xLzIgei01MCBncmlkIHctZnVsbCAtdHJhbnNsYXRlLXgtMS8yIC10cmFuc2xhdGUteS0xLzIgZ2FwLTQgcm91bmRlZC14bCBiZy1wb3BvdmVyIHAtNCB0ZXh0LXBvcG92ZXItZm9yZWdyb3VuZCByaW5nLTEgcmluZy1mb3JlZ3JvdW5kLzEwIGR1cmF0aW9uLTEwMCBvdXRsaW5lLW5vbmUgZGF0YS1bc2l6ZT1kZWZhdWx0XTptYXgtdy14cyBkYXRhLVtzaXplPXNtXTptYXgtdy14cyBkYXRhLVtzaXplPWRlZmF1bHRdOnNtOm1heC13LXNtIGRhdGEtb3BlbjphbmltYXRlLWluIGRhdGEtb3BlbjpmYWRlLWluLTAgZGF0YS1vcGVuOnpvb20taW4tOTUgZGF0YS1jbG9zZWQ6YW5pbWF0ZS1vdXQgZGF0YS1jbG9zZWQ6ZmFkZS1vdXQtMCBkYXRhLWNsb3NlZDp6b29tLW91dC05NVwiLFxuICAgICAgICAgIGNsYXNzTmFtZVxuICAgICAgICApfVxuICAgICAgICB7Li4ucHJvcHN9XG4gICAgICAvPlxuICAgIDwvQWxlcnREaWFsb2dQb3J0YWw+XG4gIClcbn1cblxuZnVuY3Rpb24gQWxlcnREaWFsb2dIZWFkZXIoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImFsZXJ0LWRpYWxvZy1oZWFkZXJcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJncmlkIGdyaWQtcm93cy1bYXV0b18xZnJdIHBsYWNlLWl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtY2VudGVyIGhhcy1kYXRhLVtzbG90PWFsZXJ0LWRpYWxvZy1tZWRpYV06Z3JpZC1yb3dzLVthdXRvX2F1dG9fMWZyXSBoYXMtZGF0YS1bc2xvdD1hbGVydC1kaWFsb2ctbWVkaWFdOmdhcC14LTQgc206Z3JvdXAtZGF0YS1bc2l6ZT1kZWZhdWx0XS9hbGVydC1kaWFsb2ctY29udGVudDpwbGFjZS1pdGVtcy1zdGFydCBzbTpncm91cC1kYXRhLVtzaXplPWRlZmF1bHRdL2FsZXJ0LWRpYWxvZy1jb250ZW50OnRleHQtbGVmdCBzbTpncm91cC1kYXRhLVtzaXplPWRlZmF1bHRdL2FsZXJ0LWRpYWxvZy1jb250ZW50Omhhcy1kYXRhLVtzbG90PWFsZXJ0LWRpYWxvZy1tZWRpYV06Z3JpZC1yb3dzLVthdXRvXzFmcl1cIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQWxlcnREaWFsb2dGb290ZXIoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImFsZXJ0LWRpYWxvZy1mb290ZXJcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCItbXgtNCAtbWItNCBmbGV4IGZsZXgtY29sLXJldmVyc2UgZ2FwLTIgcm91bmRlZC1iLXhsIGJvcmRlci10IGJnLW11dGVkLzUwIHAtNCBncm91cC1kYXRhLVtzaXplPXNtXS9hbGVydC1kaWFsb2ctY29udGVudDpncmlkIGdyb3VwLWRhdGEtW3NpemU9c21dL2FsZXJ0LWRpYWxvZy1jb250ZW50OmdyaWQtY29scy0yIHNtOmZsZXgtcm93IHNtOmp1c3RpZnktZW5kXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nTWVkaWEoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImFsZXJ0LWRpYWxvZy1tZWRpYVwiXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcIm1iLTIgaW5saW5lLWZsZXggc2l6ZS0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1tZCBiZy1tdXRlZCBzbTpncm91cC1kYXRhLVtzaXplPWRlZmF1bHRdL2FsZXJ0LWRpYWxvZy1jb250ZW50OnJvdy1zcGFuLTIgKjpbc3ZnOm5vdChbY2xhc3MqPSdzaXplLSddKV06c2l6ZS02XCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nVGl0bGUoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgQWxlcnREaWFsb2dQcmltaXRpdmUuVGl0bGU+KSB7XG4gIHJldHVybiAoXG4gICAgPEFsZXJ0RGlhbG9nUHJpbWl0aXZlLlRpdGxlXG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctdGl0bGVcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmb250LWhlYWRpbmcgdGV4dC1iYXNlIGZvbnQtbWVkaXVtIHNtOmdyb3VwLWRhdGEtW3NpemU9ZGVmYXVsdF0vYWxlcnQtZGlhbG9nLWNvbnRlbnQ6Z3JvdXAtaGFzLWRhdGEtW3Nsb3Q9YWxlcnQtZGlhbG9nLW1lZGlhXS9hbGVydC1kaWFsb2ctY29udGVudDpjb2wtc3RhcnQtMlwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ0Rlc2NyaXB0aW9uKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIEFsZXJ0RGlhbG9nUHJpbWl0aXZlLkRlc2NyaXB0aW9uPikge1xuICByZXR1cm4gKFxuICAgIDxBbGVydERpYWxvZ1ByaW1pdGl2ZS5EZXNjcmlwdGlvblxuICAgICAgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nLWRlc2NyaXB0aW9uXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwidGV4dC1zbSB0ZXh0LWJhbGFuY2UgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1kOnRleHQtcHJldHR5ICo6W2FdOnVuZGVybGluZSAqOlthXTp1bmRlcmxpbmUtb2Zmc2V0LTMgKjpbYV06aG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nQWN0aW9uKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIEJ1dHRvbj4pIHtcbiAgcmV0dXJuIChcbiAgICA8QnV0dG9uXG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctYWN0aW9uXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nQ2FuY2VsKHtcbiAgY2xhc3NOYW1lLFxuICB2YXJpYW50ID0gXCJvdXRsaW5lXCIsXG4gIHNpemUgPSBcImRlZmF1bHRcIixcbiAgLi4ucHJvcHNcbn06IEFsZXJ0RGlhbG9nUHJpbWl0aXZlLkNsb3NlLlByb3BzICZcbiAgUGljazxSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgQnV0dG9uPiwgXCJ2YXJpYW50XCIgfCBcInNpemVcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8QWxlcnREaWFsb2dQcmltaXRpdmUuQ2xvc2VcbiAgICAgIGRhdGEtc2xvdD1cImFsZXJ0LWRpYWxvZy1jYW5jZWxcIlxuICAgICAgY2xhc3NOYW1lPXtjbihjbGFzc05hbWUpfVxuICAgICAgcmVuZGVyPXs8QnV0dG9uIHZhcmlhbnQ9e3ZhcmlhbnR9IHNpemU9e3NpemV9IC8+fVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IHtcbiAgQWxlcnREaWFsb2csXG4gIEFsZXJ0RGlhbG9nQWN0aW9uLFxuICBBbGVydERpYWxvZ0NhbmNlbCxcbiAgQWxlcnREaWFsb2dDb250ZW50LFxuICBBbGVydERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBBbGVydERpYWxvZ0Zvb3RlcixcbiAgQWxlcnREaWFsb2dIZWFkZXIsXG4gIEFsZXJ0RGlhbG9nTWVkaWEsXG4gIEFsZXJ0RGlhbG9nT3ZlcmxheSxcbiAgQWxlcnREaWFsb2dQb3J0YWwsXG4gIEFsZXJ0RGlhbG9nVGl0bGUsXG4gIEFsZXJ0RGlhbG9nVHJpZ2dlcixcbn1cbiJdfQ==