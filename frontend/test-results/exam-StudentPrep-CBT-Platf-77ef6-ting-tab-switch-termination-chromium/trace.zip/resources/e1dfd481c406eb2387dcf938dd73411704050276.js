import { _ as ok, a as asciiControl, d as markdownSpace, f as unicodePunctuation, g as codes, h as constants, l as markdownLineEnding, m as types, n as asciiAlpha, p as unicodeWhitespace, r as asciiAlphanumeric, t as factorySpace, u as markdownLineEndingOrSpace } from "/node_modules/.vite/deps/dev-CbuUJWGD.js?v=076f3cfd";
import { a as normalizeIdentifier, c as splice, i as classifyCharacter, n as blankLine, o as combineExtensions, r as resolveAll, t as visit, u as toString } from "/node_modules/.vite/deps/lib-_K5726bf.js?v=076f3cfd";
import { n as visitParents, r as convert } from "/node_modules/.vite/deps/lib-LH9Xd56O.js?v=076f3cfd";
import { t as longestStreak } from "/node_modules/.vite/deps/longest-streak-B5A-0zLa.js?v=076f3cfd";
//#region node_modules/ccount/index.js
/**
* Count how often a character (or substring) is used in a string.
*
* @param {string} value
*   Value to search in.
* @param {string} character
*   Character (or substring) to look for.
* @return {number}
*   Number of times `character` occurred in `value`.
*/
function ccount(value, character) {
	const source = String(value);
	if (typeof character !== "string") throw new TypeError("Expected character");
	let count = 0;
	let index = source.indexOf(character);
	while (index !== -1) {
		count++;
		index = source.indexOf(character, index + character.length);
	}
	return count;
}
//#endregion
//#region node_modules/escape-string-regexp/index.js
function escapeStringRegexp(string) {
	if (typeof string !== "string") throw new TypeError("Expected a string");
	return string.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
//#endregion
//#region node_modules/mdast-util-find-and-replace/lib/index.js
/**
* @import {Nodes, Parents, PhrasingContent, Root, Text} from 'mdast'
* @import {BuildVisitor, Test, VisitorResult} from 'unist-util-visit-parents'
*/
/**
* @typedef RegExpMatchObject
*   Info on the match.
* @property {number} index
*   The index of the search at which the result was found.
* @property {string} input
*   A copy of the search string in the text node.
* @property {[...Array<Parents>, Text]} stack
*   All ancestors of the text node, where the last node is the text itself.
*
* @typedef {RegExp | string} Find
*   Pattern to find.
*
*   Strings are escaped and then turned into global expressions.
*
* @typedef {Array<FindAndReplaceTuple>} FindAndReplaceList
*   Several find and replaces, in array form.
*
* @typedef {[Find, Replace?]} FindAndReplaceTuple
*   Find and replace in tuple form.
*
* @typedef {ReplaceFunction | string | null | undefined} Replace
*   Thing to replace with.
*
* @callback ReplaceFunction
*   Callback called when a search matches.
* @param {...any} parameters
*   The parameters are the result of corresponding search expression:
*
*   * `value` (`string`) — whole match
*   * `...capture` (`Array<string>`) — matches from regex capture groups
*   * `match` (`RegExpMatchObject`) — info on the match
* @returns {Array<PhrasingContent> | PhrasingContent | string | false | null | undefined}
*   Thing to replace with.
*
*   * when `null`, `undefined`, `''`, remove the match
*   * …or when `false`, do not replace at all
*   * …or when `string`, replace with a text node of that value
*   * …or when `Node` or `Array<Node>`, replace with those nodes
*
* @typedef {[RegExp, ReplaceFunction]} Pair
*   Normalized find and replace.
*
* @typedef {Array<Pair>} Pairs
*   All find and replaced.
*
* @typedef Options
*   Configuration.
* @property {Test | null | undefined} [ignore]
*   Test for which nodes to ignore (optional).
*/
/**
* Find patterns in a tree and replace them.
*
* The algorithm searches the tree in *preorder* for complete values in `Text`
* nodes.
* Partial matches are not supported.
*
* @param {Nodes} tree
*   Tree to change.
* @param {FindAndReplaceList | FindAndReplaceTuple} list
*   Patterns to find.
* @param {Options | null | undefined} [options]
*   Configuration (when `find` is not `Find`).
* @returns {undefined}
*   Nothing.
*/
function findAndReplace(tree, list, options) {
	const ignored = convert((options || {}).ignore || []);
	const pairs = toPairs(list);
	let pairIndex = -1;
	while (++pairIndex < pairs.length) visitParents(tree, "text", visitor);
	/** @type {BuildVisitor<Root, 'text'>} */
	function visitor(node, parents) {
		let index = -1;
		/** @type {Parents | undefined} */
		let grandparent;
		while (++index < parents.length) {
			const parent = parents[index];
			/** @type {Array<Nodes> | undefined} */
			const siblings = grandparent ? grandparent.children : void 0;
			if (ignored(parent, siblings ? siblings.indexOf(parent) : void 0, grandparent)) return;
			grandparent = parent;
		}
		if (grandparent) return handler(node, parents);
	}
	/**
	* Handle a text node which is not in an ignored parent.
	*
	* @param {Text} node
	*   Text node.
	* @param {Array<Parents>} parents
	*   Parents.
	* @returns {VisitorResult}
	*   Result.
	*/
	function handler(node, parents) {
		const parent = parents[parents.length - 1];
		const find = pairs[pairIndex][0];
		const replace = pairs[pairIndex][1];
		let start = 0;
		const index = parent.children.indexOf(node);
		let change = false;
		/** @type {Array<PhrasingContent>} */
		let nodes = [];
		find.lastIndex = 0;
		let match = find.exec(node.value);
		while (match) {
			const position = match.index;
			/** @type {RegExpMatchObject} */
			const matchObject = {
				index: match.index,
				input: match.input,
				stack: [...parents, node]
			};
			let value = replace(...match, matchObject);
			if (typeof value === "string") value = value.length > 0 ? {
				type: "text",
				value
			} : void 0;
			if (value === false) find.lastIndex = position + 1;
			else {
				if (start !== position) nodes.push({
					type: "text",
					value: node.value.slice(start, position)
				});
				if (Array.isArray(value)) nodes.push(...value);
				else if (value) nodes.push(value);
				start = position + match[0].length;
				change = true;
			}
			if (!find.global) break;
			match = find.exec(node.value);
		}
		if (change) {
			if (start < node.value.length) nodes.push({
				type: "text",
				value: node.value.slice(start)
			});
			parent.children.splice(index, 1, ...nodes);
		} else nodes = [node];
		return index + nodes.length;
	}
}
/**
* Turn a tuple or a list of tuples into pairs.
*
* @param {FindAndReplaceList | FindAndReplaceTuple} tupleOrList
*   Schema.
* @returns {Pairs}
*   Clean pairs.
*/
function toPairs(tupleOrList) {
	/** @type {Pairs} */
	const result = [];
	if (!Array.isArray(tupleOrList)) throw new TypeError("Expected find and replace tuple or list of tuples");
	/** @type {FindAndReplaceList} */
	const list = !tupleOrList[0] || Array.isArray(tupleOrList[0]) ? tupleOrList : [tupleOrList];
	let index = -1;
	while (++index < list.length) {
		const tuple = list[index];
		result.push([toExpression(tuple[0]), toFunction(tuple[1])]);
	}
	return result;
}
/**
* Turn a find into an expression.
*
* @param {Find} find
*   Find.
* @returns {RegExp}
*   Expression.
*/
function toExpression(find) {
	return typeof find === "string" ? new RegExp(escapeStringRegexp(find), "g") : find;
}
/**
* Turn a replace into a function.
*
* @param {Replace} replace
*   Replace.
* @returns {ReplaceFunction}
*   Function.
*/
function toFunction(replace) {
	return typeof replace === "function" ? replace : function() {
		return replace;
	};
}
//#endregion
//#region node_modules/mdast-util-gfm-autolink-literal/lib/index.js
/**
* @import {RegExpMatchObject, ReplaceFunction} from 'mdast-util-find-and-replace'
* @import {CompileContext, Extension as FromMarkdownExtension, Handle as FromMarkdownHandle, Transform as FromMarkdownTransform} from 'mdast-util-from-markdown'
* @import {ConstructName, Options as ToMarkdownExtension} from 'mdast-util-to-markdown'
* @import {Link, PhrasingContent} from 'mdast'
*/
/** @type {ConstructName} */
var inConstruct = "phrasing";
/** @type {Array<ConstructName>} */
var notInConstruct = [
	"autolink",
	"link",
	"image",
	"label"
];
/**
* Create an extension for `mdast-util-from-markdown` to enable GFM autolink
* literals in markdown.
*
* @returns {FromMarkdownExtension}
*   Extension for `mdast-util-to-markdown` to enable GFM autolink literals.
*/
function gfmAutolinkLiteralFromMarkdown() {
	return {
		transforms: [transformGfmAutolinkLiterals],
		enter: {
			literalAutolink: enterLiteralAutolink,
			literalAutolinkEmail: enterLiteralAutolinkValue,
			literalAutolinkHttp: enterLiteralAutolinkValue,
			literalAutolinkWww: enterLiteralAutolinkValue
		},
		exit: {
			literalAutolink: exitLiteralAutolink,
			literalAutolinkEmail: exitLiteralAutolinkEmail,
			literalAutolinkHttp: exitLiteralAutolinkHttp,
			literalAutolinkWww: exitLiteralAutolinkWww
		}
	};
}
/**
* Create an extension for `mdast-util-to-markdown` to enable GFM autolink
* literals in markdown.
*
* @returns {ToMarkdownExtension}
*   Extension for `mdast-util-to-markdown` to enable GFM autolink literals.
*/
function gfmAutolinkLiteralToMarkdown() {
	return { unsafe: [
		{
			character: "@",
			before: "[+\\-.\\w]",
			after: "[\\-.\\w]",
			inConstruct,
			notInConstruct
		},
		{
			character: ".",
			before: "[Ww]",
			after: "[\\-.\\w]",
			inConstruct,
			notInConstruct
		},
		{
			character: ":",
			before: "[ps]",
			after: "\\/",
			inConstruct,
			notInConstruct
		}
	] };
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterLiteralAutolink(token) {
	this.enter({
		type: "link",
		title: null,
		url: "",
		children: []
	}, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterLiteralAutolinkValue(token) {
	this.config.enter.autolinkProtocol.call(this, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitLiteralAutolinkHttp(token) {
	this.config.exit.autolinkProtocol.call(this, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitLiteralAutolinkWww(token) {
	this.config.exit.data.call(this, token);
	const node = this.stack[this.stack.length - 1];
	ok(node.type === "link");
	node.url = "http://" + this.sliceSerialize(token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitLiteralAutolinkEmail(token) {
	this.config.exit.autolinkEmail.call(this, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitLiteralAutolink(token) {
	this.exit(token);
}
/** @type {FromMarkdownTransform} */
function transformGfmAutolinkLiterals(tree) {
	findAndReplace(tree, [[/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, findUrl], [/(?<=^|\s|\p{P}|\p{S})([-.\w+]+)@([-\w]+(?:\.[-\w]+)+)/gu, findEmail]], { ignore: ["link", "linkReference"] });
}
/**
* @type {ReplaceFunction}
* @param {string} _
* @param {string} protocol
* @param {string} domain
* @param {string} path
* @param {RegExpMatchObject} match
* @returns {Array<PhrasingContent> | Link | false}
*/
function findUrl(_, protocol, domain, path, match) {
	let prefix = "";
	if (!previous(match)) return false;
	if (/^w/i.test(protocol)) {
		domain = protocol + domain;
		protocol = "";
		prefix = "http://";
	}
	if (!isCorrectDomain(domain)) return false;
	const parts = splitUrl(domain + path);
	if (!parts[0]) return false;
	/** @type {Link} */
	const result = {
		type: "link",
		title: null,
		url: prefix + protocol + parts[0],
		children: [{
			type: "text",
			value: protocol + parts[0]
		}]
	};
	if (parts[1]) return [result, {
		type: "text",
		value: parts[1]
	}];
	return result;
}
/**
* @type {ReplaceFunction}
* @param {string} _
* @param {string} atext
* @param {string} label
* @param {RegExpMatchObject} match
* @returns {Link | false}
*/
function findEmail(_, atext, label, match) {
	if (!previous(match, true) || /[-\d_]$/.test(label)) return false;
	return {
		type: "link",
		title: null,
		url: "mailto:" + atext + "@" + label,
		children: [{
			type: "text",
			value: atext + "@" + label
		}]
	};
}
/**
* @param {string} domain
* @returns {boolean}
*/
function isCorrectDomain(domain) {
	const parts = domain.split(".");
	if (parts.length < 2 || parts[parts.length - 1] && (/_/.test(parts[parts.length - 1]) || !/[a-zA-Z\d]/.test(parts[parts.length - 1])) || parts[parts.length - 2] && (/_/.test(parts[parts.length - 2]) || !/[a-zA-Z\d]/.test(parts[parts.length - 2]))) return false;
	return true;
}
/**
* @param {string} url
* @returns {[string, string | undefined]}
*/
function splitUrl(url) {
	const trailExec = /[!"&'),.:;<>?\]}]+$/.exec(url);
	if (!trailExec) return [url, void 0];
	url = url.slice(0, trailExec.index);
	let trail = trailExec[0];
	let closingParenIndex = trail.indexOf(")");
	const openingParens = ccount(url, "(");
	let closingParens = ccount(url, ")");
	while (closingParenIndex !== -1 && openingParens > closingParens) {
		url += trail.slice(0, closingParenIndex + 1);
		trail = trail.slice(closingParenIndex + 1);
		closingParenIndex = trail.indexOf(")");
		closingParens++;
	}
	return [url, trail];
}
/**
* @param {RegExpMatchObject} match
* @param {boolean | null | undefined} [email=false]
* @returns {boolean}
*/
function previous(match, email) {
	const code = match.input.charCodeAt(match.index - 1);
	return (match.index === 0 || unicodeWhitespace(code) || unicodePunctuation(code)) && (!email || code !== 47);
}
//#endregion
//#region node_modules/mdast-util-gfm-footnote/lib/index.js
/**
* @import {
*   CompileContext,
*   Extension as FromMarkdownExtension,
*   Handle as FromMarkdownHandle
* } from 'mdast-util-from-markdown'
* @import {ToMarkdownOptions} from 'mdast-util-gfm-footnote'
* @import {
*   Handle as ToMarkdownHandle,
*   Map,
*   Options as ToMarkdownExtension
* } from 'mdast-util-to-markdown'
* @import {FootnoteDefinition, FootnoteReference} from 'mdast'
*/
footnoteReference.peek = footnoteReferencePeek;
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterFootnoteCallString() {
	this.buffer();
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterFootnoteCall(token) {
	this.enter({
		type: "footnoteReference",
		identifier: "",
		label: ""
	}, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterFootnoteDefinitionLabelString() {
	this.buffer();
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterFootnoteDefinition(token) {
	this.enter({
		type: "footnoteDefinition",
		identifier: "",
		label: "",
		children: []
	}, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitFootnoteCallString(token) {
	const label = this.resume();
	const node = this.stack[this.stack.length - 1];
	ok(node.type === "footnoteReference");
	node.identifier = normalizeIdentifier(this.sliceSerialize(token)).toLowerCase();
	node.label = label;
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitFootnoteCall(token) {
	this.exit(token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitFootnoteDefinitionLabelString(token) {
	const label = this.resume();
	const node = this.stack[this.stack.length - 1];
	ok(node.type === "footnoteDefinition");
	node.identifier = normalizeIdentifier(this.sliceSerialize(token)).toLowerCase();
	node.label = label;
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitFootnoteDefinition(token) {
	this.exit(token);
}
/** @type {ToMarkdownHandle} */
function footnoteReferencePeek() {
	return "[";
}
/**
* @type {ToMarkdownHandle}
* @param {FootnoteReference} node
*/
function footnoteReference(node, _, state, info) {
	const tracker = state.createTracker(info);
	let value = tracker.move("[^");
	const exit = state.enter("footnoteReference");
	const subexit = state.enter("reference");
	value += tracker.move(state.safe(state.associationId(node), {
		after: "]",
		before: value
	}));
	subexit();
	exit();
	value += tracker.move("]");
	return value;
}
/**
* Create an extension for `mdast-util-from-markdown` to enable GFM footnotes
* in markdown.
*
* @returns {FromMarkdownExtension}
*   Extension for `mdast-util-from-markdown`.
*/
function gfmFootnoteFromMarkdown() {
	return {
		enter: {
			gfmFootnoteCallString: enterFootnoteCallString,
			gfmFootnoteCall: enterFootnoteCall,
			gfmFootnoteDefinitionLabelString: enterFootnoteDefinitionLabelString,
			gfmFootnoteDefinition: enterFootnoteDefinition
		},
		exit: {
			gfmFootnoteCallString: exitFootnoteCallString,
			gfmFootnoteCall: exitFootnoteCall,
			gfmFootnoteDefinitionLabelString: exitFootnoteDefinitionLabelString,
			gfmFootnoteDefinition: exitFootnoteDefinition
		}
	};
}
/**
* Create an extension for `mdast-util-to-markdown` to enable GFM footnotes
* in markdown.
*
* @param {ToMarkdownOptions | null | undefined} [options]
*   Configuration (optional).
* @returns {ToMarkdownExtension}
*   Extension for `mdast-util-to-markdown`.
*/
function gfmFootnoteToMarkdown(options) {
	let firstLineBlank = false;
	if (options && options.firstLineBlank) firstLineBlank = true;
	return {
		handlers: {
			footnoteDefinition,
			footnoteReference
		},
		unsafe: [{
			character: "[",
			inConstruct: [
				"label",
				"phrasing",
				"reference"
			]
		}]
	};
	/**
	* @type {ToMarkdownHandle}
	* @param {FootnoteDefinition} node
	*/
	function footnoteDefinition(node, _, state, info) {
		const tracker = state.createTracker(info);
		let value = tracker.move("[^");
		const exit = state.enter("footnoteDefinition");
		const subexit = state.enter("label");
		value += tracker.move(state.safe(state.associationId(node), {
			before: value,
			after: "]"
		}));
		subexit();
		value += tracker.move("]:");
		if (node.children && node.children.length > 0) {
			tracker.shift(4);
			value += tracker.move((firstLineBlank ? "\n" : " ") + state.indentLines(state.containerFlow(node, tracker.current()), firstLineBlank ? mapAll : mapExceptFirst));
		}
		exit();
		return value;
	}
}
/** @type {Map} */
function mapExceptFirst(line, index, blank) {
	return index === 0 ? line : mapAll(line, index, blank);
}
/** @type {Map} */
function mapAll(line, index, blank) {
	return (blank ? "" : "    ") + line;
}
//#endregion
//#region node_modules/mdast-util-gfm-strikethrough/lib/index.js
/**
* @typedef {import('mdast').Delete} Delete
*
* @typedef {import('mdast-util-from-markdown').CompileContext} CompileContext
* @typedef {import('mdast-util-from-markdown').Extension} FromMarkdownExtension
* @typedef {import('mdast-util-from-markdown').Handle} FromMarkdownHandle
*
* @typedef {import('mdast-util-to-markdown').ConstructName} ConstructName
* @typedef {import('mdast-util-to-markdown').Handle} ToMarkdownHandle
* @typedef {import('mdast-util-to-markdown').Options} ToMarkdownExtension
*/
/**
* List of constructs that occur in phrasing (paragraphs, headings), but cannot
* contain strikethrough.
* So they sort of cancel each other out.
* Note: could use a better name.
*
* Note: keep in sync with: <https://github.com/syntax-tree/mdast-util-to-markdown/blob/8ce8dbf/lib/unsafe.js#L14>
*
* @type {Array<ConstructName>}
*/
var constructsWithoutStrikethrough = [
	"autolink",
	"destinationLiteral",
	"destinationRaw",
	"reference",
	"titleQuote",
	"titleApostrophe"
];
handleDelete.peek = peekDelete;
/**
* Create an extension for `mdast-util-from-markdown` to enable GFM
* strikethrough in markdown.
*
* @returns {FromMarkdownExtension}
*   Extension for `mdast-util-from-markdown` to enable GFM strikethrough.
*/
function gfmStrikethroughFromMarkdown() {
	return {
		canContainEols: ["delete"],
		enter: { strikethrough: enterStrikethrough },
		exit: { strikethrough: exitStrikethrough }
	};
}
/**
* Create an extension for `mdast-util-to-markdown` to enable GFM
* strikethrough in markdown.
*
* @returns {ToMarkdownExtension}
*   Extension for `mdast-util-to-markdown` to enable GFM strikethrough.
*/
function gfmStrikethroughToMarkdown() {
	return {
		unsafe: [{
			character: "~",
			inConstruct: "phrasing",
			notInConstruct: constructsWithoutStrikethrough
		}],
		handlers: { delete: handleDelete }
	};
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterStrikethrough(token) {
	this.enter({
		type: "delete",
		children: []
	}, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitStrikethrough(token) {
	this.exit(token);
}
/**
* @type {ToMarkdownHandle}
* @param {Delete} node
*/
function handleDelete(node, _, state, info) {
	const tracker = state.createTracker(info);
	const exit = state.enter("strikethrough");
	let value = tracker.move("~~");
	value += state.containerPhrasing(node, {
		...tracker.current(),
		before: value,
		after: "~"
	});
	value += tracker.move("~~");
	exit();
	return value;
}
/** @type {ToMarkdownHandle} */
function peekDelete() {
	return "~";
}
//#endregion
//#region node_modules/markdown-table/index.js
/**
* @typedef {Options} MarkdownTableOptions
*   Configuration.
*/
/**
* @typedef Options
*   Configuration.
* @property {boolean | null | undefined} [alignDelimiters=true]
*   Whether to align the delimiters (default: `true`);
*   they are aligned by default:
*
*   ```markdown
*   | Alpha | B     |
*   | ----- | ----- |
*   | C     | Delta |
*   ```
*
*   Pass `false` to make them staggered:
*
*   ```markdown
*   | Alpha | B |
*   | - | - |
*   | C | Delta |
*   ```
* @property {ReadonlyArray<string | null | undefined> | string | null | undefined} [align]
*   How to align columns (default: `''`);
*   one style for all columns or styles for their respective columns;
*   each style is either `'l'` (left), `'r'` (right), or `'c'` (center);
*   other values are treated as `''`, which doesn’t place the colon in the
*   alignment row but does align left;
*   *only the lowercased first character is used, so `Right` is fine.*
* @property {boolean | null | undefined} [delimiterEnd=true]
*   Whether to end each row with the delimiter (default: `true`).
*
*   > 👉 **Note**: please don’t use this: it could create fragile structures
*   > that aren’t understandable to some markdown parsers.
*
*   When `true`, there are ending delimiters:
*
*   ```markdown
*   | Alpha | B     |
*   | ----- | ----- |
*   | C     | Delta |
*   ```
*
*   When `false`, there are no ending delimiters:
*
*   ```markdown
*   | Alpha | B
*   | ----- | -----
*   | C     | Delta
*   ```
* @property {boolean | null | undefined} [delimiterStart=true]
*   Whether to begin each row with the delimiter (default: `true`).
*
*   > 👉 **Note**: please don’t use this: it could create fragile structures
*   > that aren’t understandable to some markdown parsers.
*
*   When `true`, there are starting delimiters:
*
*   ```markdown
*   | Alpha | B     |
*   | ----- | ----- |
*   | C     | Delta |
*   ```
*
*   When `false`, there are no starting delimiters:
*
*   ```markdown
*   Alpha | B     |
*   ----- | ----- |
*   C     | Delta |
*   ```
* @property {boolean | null | undefined} [padding=true]
*   Whether to add a space of padding between delimiters and cells
*   (default: `true`).
*
*   When `true`, there is padding:
*
*   ```markdown
*   | Alpha | B     |
*   | ----- | ----- |
*   | C     | Delta |
*   ```
*
*   When `false`, there is no padding:
*
*   ```markdown
*   |Alpha|B    |
*   |-----|-----|
*   |C    |Delta|
*   ```
* @property {((value: string) => number) | null | undefined} [stringLength]
*   Function to detect the length of table cell content (optional);
*   this is used when aligning the delimiters (`|`) between table cells;
*   full-width characters and emoji mess up delimiter alignment when viewing
*   the markdown source;
*   to fix this, you can pass this function,
*   which receives the cell content and returns its “visible” size;
*   note that what is and isn’t visible depends on where the text is displayed.
*
*   Without such a function, the following:
*
*   ```js
*   markdownTable([
*     ['Alpha', 'Bravo'],
*     ['中文', 'Charlie'],
*     ['👩‍❤️‍👩', 'Delta']
*   ])
*   ```
*
*   Yields:
*
*   ```markdown
*   | Alpha | Bravo |
*   | - | - |
*   | 中文 | Charlie |
*   | 👩‍❤️‍👩 | Delta |
*   ```
*
*   With [`string-width`](https://github.com/sindresorhus/string-width):
*
*   ```js
*   import stringWidth from 'string-width'
*
*   markdownTable(
*     [
*       ['Alpha', 'Bravo'],
*       ['中文', 'Charlie'],
*       ['👩‍❤️‍👩', 'Delta']
*     ],
*     {stringLength: stringWidth}
*   )
*   ```
*
*   Yields:
*
*   ```markdown
*   | Alpha | Bravo   |
*   | ----- | ------- |
*   | 中文  | Charlie |
*   | 👩‍❤️‍👩    | Delta   |
*   ```
*/
/**
* @param {string} value
*   Cell value.
* @returns {number}
*   Cell size.
*/
function defaultStringLength(value) {
	return value.length;
}
/**
* Generate a markdown
* ([GFM](https://docs.github.com/en/github/writing-on-github/working-with-advanced-formatting/organizing-information-with-tables))
* table.
*
* @param {ReadonlyArray<ReadonlyArray<string | null | undefined>>} table
*   Table data (matrix of strings).
* @param {Readonly<Options> | null | undefined} [options]
*   Configuration (optional).
* @returns {string}
*   Result.
*/
function markdownTable(table, options) {
	const settings = options || {};
	const align = (settings.align || []).concat();
	const stringLength = settings.stringLength || defaultStringLength;
	/** @type {Array<number>} Character codes as symbols for alignment per column. */
	const alignments = [];
	/** @type {Array<Array<string>>} Cells per row. */
	const cellMatrix = [];
	/** @type {Array<Array<number>>} Sizes of each cell per row. */
	const sizeMatrix = [];
	/** @type {Array<number>} */
	const longestCellByColumn = [];
	let mostCellsPerRow = 0;
	let rowIndex = -1;
	while (++rowIndex < table.length) {
		/** @type {Array<string>} */
		const row = [];
		/** @type {Array<number>} */
		const sizes = [];
		let columnIndex = -1;
		if (table[rowIndex].length > mostCellsPerRow) mostCellsPerRow = table[rowIndex].length;
		while (++columnIndex < table[rowIndex].length) {
			const cell = serialize(table[rowIndex][columnIndex]);
			if (settings.alignDelimiters !== false) {
				const size = stringLength(cell);
				sizes[columnIndex] = size;
				if (longestCellByColumn[columnIndex] === void 0 || size > longestCellByColumn[columnIndex]) longestCellByColumn[columnIndex] = size;
			}
			row.push(cell);
		}
		cellMatrix[rowIndex] = row;
		sizeMatrix[rowIndex] = sizes;
	}
	let columnIndex = -1;
	if (typeof align === "object" && "length" in align) while (++columnIndex < mostCellsPerRow) alignments[columnIndex] = toAlignment(align[columnIndex]);
	else {
		const code = toAlignment(align);
		while (++columnIndex < mostCellsPerRow) alignments[columnIndex] = code;
	}
	columnIndex = -1;
	/** @type {Array<string>} */
	const row = [];
	/** @type {Array<number>} */
	const sizes = [];
	while (++columnIndex < mostCellsPerRow) {
		const code = alignments[columnIndex];
		let before = "";
		let after = "";
		if (code === 99) {
			before = ":";
			after = ":";
		} else if (code === 108) before = ":";
		else if (code === 114) after = ":";
		let size = settings.alignDelimiters === false ? 1 : Math.max(1, longestCellByColumn[columnIndex] - before.length - after.length);
		const cell = before + "-".repeat(size) + after;
		if (settings.alignDelimiters !== false) {
			size = before.length + size + after.length;
			if (size > longestCellByColumn[columnIndex]) longestCellByColumn[columnIndex] = size;
			sizes[columnIndex] = size;
		}
		row[columnIndex] = cell;
	}
	cellMatrix.splice(1, 0, row);
	sizeMatrix.splice(1, 0, sizes);
	rowIndex = -1;
	/** @type {Array<string>} */
	const lines = [];
	while (++rowIndex < cellMatrix.length) {
		const row = cellMatrix[rowIndex];
		const sizes = sizeMatrix[rowIndex];
		columnIndex = -1;
		/** @type {Array<string>} */
		const line = [];
		while (++columnIndex < mostCellsPerRow) {
			const cell = row[columnIndex] || "";
			let before = "";
			let after = "";
			if (settings.alignDelimiters !== false) {
				const size = longestCellByColumn[columnIndex] - (sizes[columnIndex] || 0);
				const code = alignments[columnIndex];
				if (code === 114) before = " ".repeat(size);
				else if (code === 99) {
					if (size % 2) {
						before = " ".repeat(size / 2 + .5);
						after = " ".repeat(size / 2 - .5);
					} else {
						before = " ".repeat(size / 2);
						after = before;
					}
				} else after = " ".repeat(size);
			}
			if (settings.delimiterStart !== false && !columnIndex) line.push("|");
			if (settings.padding !== false && !(settings.alignDelimiters === false && cell === "") && (settings.delimiterStart !== false || columnIndex)) line.push(" ");
			if (settings.alignDelimiters !== false) line.push(before);
			line.push(cell);
			if (settings.alignDelimiters !== false) line.push(after);
			if (settings.padding !== false) line.push(" ");
			if (settings.delimiterEnd !== false || columnIndex !== mostCellsPerRow - 1) line.push("|");
		}
		lines.push(settings.delimiterEnd === false ? line.join("").replace(/ +$/, "") : line.join(""));
	}
	return lines.join("\n");
}
/**
* @param {string | null | undefined} [value]
*   Value to serialize.
* @returns {string}
*   Result.
*/
function serialize(value) {
	return value === null || value === void 0 ? "" : String(value);
}
/**
* @param {string | null | undefined} value
*   Value.
* @returns {number}
*   Alignment.
*/
function toAlignment(value) {
	const code = typeof value === "string" ? value.codePointAt(0) : 0;
	return code === 67 || code === 99 ? 99 : code === 76 || code === 108 ? 108 : code === 82 || code === 114 ? 114 : 0;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/blockquote.js
/**
* @import {Blockquote, Parents} from 'mdast'
* @import {Info, Map, State} from 'mdast-util-to-markdown'
*/
/**
* @param {Blockquote} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function blockquote(node, _, state, info) {
	const exit = state.enter("blockquote");
	const tracker = state.createTracker(info);
	tracker.move("> ");
	tracker.shift(2);
	const value = state.indentLines(state.containerFlow(node, tracker.current()), map$1);
	exit();
	return value;
}
/** @type {Map} */
function map$1(line, _, blank) {
	return ">" + (blank ? "" : " ") + line;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/pattern-in-scope.js
/**
* @import {ConstructName, Unsafe} from 'mdast-util-to-markdown'
*/
/**
* @param {Array<ConstructName>} stack
* @param {Unsafe} pattern
* @returns {boolean}
*/
function patternInScope(stack, pattern) {
	return listInScope(stack, pattern.inConstruct, true) && !listInScope(stack, pattern.notInConstruct, false);
}
/**
* @param {Array<ConstructName>} stack
* @param {Unsafe['inConstruct']} list
* @param {boolean} none
* @returns {boolean}
*/
function listInScope(stack, list, none) {
	if (typeof list === "string") list = [list];
	if (!list || list.length === 0) return none;
	let index = -1;
	while (++index < list.length) if (stack.includes(list[index])) return true;
	return false;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/break.js
/**
* @import {Break, Parents} from 'mdast'
* @import {Info, State} from 'mdast-util-to-markdown'
*/
/**
* @param {Break} _
* @param {Parents | undefined} _1
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function hardBreak(_, _1, state, info) {
	let index = -1;
	while (++index < state.unsafe.length) if (state.unsafe[index].character === "\n" && patternInScope(state.stack, state.unsafe[index])) return /[ \t]/.test(info.before) ? "" : " ";
	return "\\\n";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/format-code-as-indented.js
/**
* @import {State} from 'mdast-util-to-markdown'
* @import {Code} from 'mdast'
*/
/**
* @param {Code} node
* @param {State} state
* @returns {boolean}
*/
function formatCodeAsIndented(node, state) {
	return Boolean(state.options.fences === false && node.value && !node.lang && /[^ \r\n]/.test(node.value) && !/^[\t ]*(?:[\r\n]|$)|(?:^|[\r\n])[\t ]*$/.test(node.value));
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-fence.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['fence'], null | undefined>}
*/
function checkFence(state) {
	const marker = state.options.fence || "`";
	if (marker !== "`" && marker !== "~") throw new Error("Cannot serialize code with `" + marker + "` for `options.fence`, expected `` ` `` or `~`");
	return marker;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/code.js
/**
* @import {Info, Map, State} from 'mdast-util-to-markdown'
* @import {Code, Parents} from 'mdast'
*/
/**
* @param {Code} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function code$1(node, _, state, info) {
	const marker = checkFence(state);
	const raw = node.value || "";
	const suffix = marker === "`" ? "GraveAccent" : "Tilde";
	if (formatCodeAsIndented(node, state)) {
		const exit = state.enter("codeIndented");
		const value = state.indentLines(raw, map);
		exit();
		return value;
	}
	const tracker = state.createTracker(info);
	const sequence = marker.repeat(Math.max(longestStreak(raw, marker) + 1, 3));
	const exit = state.enter("codeFenced");
	let value = tracker.move(sequence);
	if (node.lang) {
		const subexit = state.enter(`codeFencedLang${suffix}`);
		value += tracker.move(state.safe(node.lang, {
			before: value,
			after: " ",
			encode: ["`"],
			...tracker.current()
		}));
		subexit();
	}
	if (node.lang && node.meta) {
		const subexit = state.enter(`codeFencedMeta${suffix}`);
		value += tracker.move(" ");
		value += tracker.move(state.safe(node.meta, {
			before: value,
			after: "\n",
			encode: ["`"],
			...tracker.current()
		}));
		subexit();
	}
	value += tracker.move("\n");
	if (raw) value += tracker.move(raw + "\n");
	value += tracker.move(sequence);
	exit();
	return value;
}
/** @type {Map} */
function map(line, _, blank) {
	return (blank ? "" : "    ") + line;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-quote.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['quote'], null | undefined>}
*/
function checkQuote(state) {
	const marker = state.options.quote || "\"";
	if (marker !== "\"" && marker !== "'") throw new Error("Cannot serialize title with `" + marker + "` for `options.quote`, expected `\"`, or `'`");
	return marker;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/definition.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Definition, Parents} from 'mdast'
*/
/**
* @param {Definition} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function definition(node, _, state, info) {
	const quote = checkQuote(state);
	const suffix = quote === "\"" ? "Quote" : "Apostrophe";
	const exit = state.enter("definition");
	let subexit = state.enter("label");
	const tracker = state.createTracker(info);
	let value = tracker.move("[");
	value += tracker.move(state.safe(state.associationId(node), {
		before: value,
		after: "]",
		...tracker.current()
	}));
	value += tracker.move("]: ");
	subexit();
	if (!node.url || /[\0- \u007F]/.test(node.url)) {
		subexit = state.enter("destinationLiteral");
		value += tracker.move("<");
		value += tracker.move(state.safe(node.url, {
			before: value,
			after: ">",
			...tracker.current()
		}));
		value += tracker.move(">");
	} else {
		subexit = state.enter("destinationRaw");
		value += tracker.move(state.safe(node.url, {
			before: value,
			after: node.title ? " " : "\n",
			...tracker.current()
		}));
	}
	subexit();
	if (node.title) {
		subexit = state.enter(`title${suffix}`);
		value += tracker.move(" " + quote);
		value += tracker.move(state.safe(node.title, {
			before: value,
			after: quote,
			...tracker.current()
		}));
		value += tracker.move(quote);
		subexit();
	}
	exit();
	return value;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-emphasis.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['emphasis'], null | undefined>}
*/
function checkEmphasis(state) {
	const marker = state.options.emphasis || "*";
	if (marker !== "*" && marker !== "_") throw new Error("Cannot serialize emphasis with `" + marker + "` for `options.emphasis`, expected `*`, or `_`");
	return marker;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/encode-character-reference.js
/**
* Encode a code point as a character reference.
*
* @param {number} code
*   Code point to encode.
* @returns {string}
*   Encoded character reference.
*/
function encodeCharacterReference(code) {
	return "&#x" + code.toString(16).toUpperCase() + ";";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/encode-info.js
/**
* @import {EncodeSides} from '../types.js'
*/
/**
* Check whether to encode (as a character reference) the characters
* surrounding an attention run.
*
* Which characters are around an attention run influence whether it works or
* not.
*
* See <https://github.com/orgs/syntax-tree/discussions/60> for more info.
* See this markdown in a particular renderer to see what works:
*
* ```markdown
* |                         | A (letter inside) | B (punctuation inside) | C (whitespace inside) | D (nothing inside) |
* | ----------------------- | ----------------- | ---------------------- | --------------------- | ------------------ |
* | 1 (letter outside)      | x*y*z             | x*.*z                  | x* *z                 | x**z               |
* | 2 (punctuation outside) | .*y*.             | .*.*.                  | .* *.                 | .**.               |
* | 3 (whitespace outside)  | x *y* z           | x *.* z                | x * * z               | x ** z             |
* | 4 (nothing outside)     | *x*               | *.*                    | * *                   | **                 |
* ```
*
* @param {number} outside
*   Code point on the outer side of the run.
* @param {number} inside
*   Code point on the inner side of the run.
* @param {'*' | '_'} marker
*   Marker of the run.
*   Underscores are handled more strictly (they form less often) than
*   asterisks.
* @returns {EncodeSides}
*   Whether to encode characters.
*/
function encodeInfo(outside, inside, marker) {
	const outsideKind = classifyCharacter(outside);
	const insideKind = classifyCharacter(inside);
	if (outsideKind === void 0) return insideKind === void 0 ? marker === "_" ? {
		inside: true,
		outside: true
	} : {
		inside: false,
		outside: false
	} : insideKind === 1 ? {
		inside: true,
		outside: true
	} : {
		inside: false,
		outside: true
	};
	if (outsideKind === 1) return insideKind === void 0 ? {
		inside: false,
		outside: false
	} : insideKind === 1 ? {
		inside: true,
		outside: true
	} : {
		inside: false,
		outside: false
	};
	return insideKind === void 0 ? {
		inside: false,
		outside: false
	} : insideKind === 1 ? {
		inside: true,
		outside: false
	} : {
		inside: false,
		outside: false
	};
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/emphasis.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Emphasis, Parents} from 'mdast'
*/
emphasis.peek = emphasisPeek;
/**
* @param {Emphasis} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function emphasis(node, _, state, info) {
	const marker = checkEmphasis(state);
	const exit = state.enter("emphasis");
	const tracker = state.createTracker(info);
	const before = tracker.move(marker);
	let between = tracker.move(state.containerPhrasing(node, {
		after: marker,
		before,
		...tracker.current()
	}));
	const betweenHead = between.charCodeAt(0);
	const open = encodeInfo(info.before.charCodeAt(info.before.length - 1), betweenHead, marker);
	if (open.inside) between = encodeCharacterReference(betweenHead) + between.slice(1);
	const betweenTail = between.charCodeAt(between.length - 1);
	const close = encodeInfo(info.after.charCodeAt(0), betweenTail, marker);
	if (close.inside) between = between.slice(0, -1) + encodeCharacterReference(betweenTail);
	const after = tracker.move(marker);
	exit();
	state.attentionEncodeSurroundingInfo = {
		after: close.outside,
		before: open.outside
	};
	return before + between + after;
}
/**
* @param {Emphasis} _
* @param {Parents | undefined} _1
* @param {State} state
* @returns {string}
*/
function emphasisPeek(_, _1, state) {
	return state.options.emphasis || "*";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/format-heading-as-setext.js
/**
* @import {State} from 'mdast-util-to-markdown'
* @import {Heading} from 'mdast'
*/
/**
* @param {Heading} node
* @param {State} state
* @returns {boolean}
*/
function formatHeadingAsSetext(node, state) {
	let literalWithBreak = false;
	visit(node, function(node) {
		if ("value" in node && /\r?\n|\r/.test(node.value) || node.type === "break") {
			literalWithBreak = true;
			return false;
		}
	});
	return Boolean((!node.depth || node.depth < 3) && toString(node) && (state.options.setext || literalWithBreak));
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/heading.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Heading, Parents} from 'mdast'
*/
/**
* @param {Heading} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function heading(node, _, state, info) {
	const rank = Math.max(Math.min(6, node.depth || 1), 1);
	const tracker = state.createTracker(info);
	if (formatHeadingAsSetext(node, state)) {
		const exit = state.enter("headingSetext");
		const subexit = state.enter("phrasing");
		const value = state.containerPhrasing(node, {
			...tracker.current(),
			before: "\n",
			after: "\n"
		});
		subexit();
		exit();
		return value + "\n" + (rank === 1 ? "=" : "-").repeat(value.length - (Math.max(value.lastIndexOf("\r"), value.lastIndexOf("\n")) + 1));
	}
	const sequence = "#".repeat(rank);
	const exit = state.enter("headingAtx");
	const subexit = state.enter("phrasing");
	tracker.move(sequence + " ");
	let value = state.containerPhrasing(node, {
		before: "# ",
		after: "\n",
		...tracker.current()
	});
	if (/^[\t ]/.test(value)) value = encodeCharacterReference(value.charCodeAt(0)) + value.slice(1);
	value = value ? sequence + " " + value : sequence;
	if (state.options.closeAtx) value += " " + sequence;
	subexit();
	exit();
	return value;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/html.js
/**
* @import {Html} from 'mdast'
*/
html.peek = htmlPeek;
/**
* @param {Html} node
* @returns {string}
*/
function html(node) {
	return node.value || "";
}
/**
* @returns {string}
*/
function htmlPeek() {
	return "<";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/image.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Image, Parents} from 'mdast'
*/
image.peek = imagePeek;
/**
* @param {Image} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function image(node, _, state, info) {
	const quote = checkQuote(state);
	const suffix = quote === "\"" ? "Quote" : "Apostrophe";
	const exit = state.enter("image");
	let subexit = state.enter("label");
	const tracker = state.createTracker(info);
	let value = tracker.move("![");
	value += tracker.move(state.safe(node.alt, {
		before: value,
		after: "]",
		...tracker.current()
	}));
	value += tracker.move("](");
	subexit();
	if (!node.url && node.title || /[\0- \u007F]/.test(node.url)) {
		subexit = state.enter("destinationLiteral");
		value += tracker.move("<");
		value += tracker.move(state.safe(node.url, {
			before: value,
			after: ">",
			...tracker.current()
		}));
		value += tracker.move(">");
	} else {
		subexit = state.enter("destinationRaw");
		value += tracker.move(state.safe(node.url, {
			before: value,
			after: node.title ? " " : ")",
			...tracker.current()
		}));
	}
	subexit();
	if (node.title) {
		subexit = state.enter(`title${suffix}`);
		value += tracker.move(" " + quote);
		value += tracker.move(state.safe(node.title, {
			before: value,
			after: quote,
			...tracker.current()
		}));
		value += tracker.move(quote);
		subexit();
	}
	value += tracker.move(")");
	exit();
	return value;
}
/**
* @returns {string}
*/
function imagePeek() {
	return "!";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/image-reference.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {ImageReference, Parents} from 'mdast'
*/
imageReference.peek = imageReferencePeek;
/**
* @param {ImageReference} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function imageReference(node, _, state, info) {
	const type = node.referenceType;
	const exit = state.enter("imageReference");
	let subexit = state.enter("label");
	const tracker = state.createTracker(info);
	let value = tracker.move("![");
	const alt = state.safe(node.alt, {
		before: value,
		after: "]",
		...tracker.current()
	});
	value += tracker.move(alt + "][");
	subexit();
	const stack = state.stack;
	state.stack = [];
	subexit = state.enter("reference");
	const reference = state.safe(state.associationId(node), {
		before: value,
		after: "]",
		...tracker.current()
	});
	subexit();
	state.stack = stack;
	exit();
	if (type === "full" || !alt || alt !== reference) value += tracker.move(reference + "]");
	else if (type === "shortcut") value = value.slice(0, -1);
	else value += tracker.move("]");
	return value;
}
/**
* @returns {string}
*/
function imageReferencePeek() {
	return "!";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/inline-code.js
/**
* @import {State} from 'mdast-util-to-markdown'
* @import {InlineCode, Parents} from 'mdast'
*/
inlineCode.peek = inlineCodePeek;
/**
* @param {InlineCode} node
* @param {Parents | undefined} _
* @param {State} state
* @returns {string}
*/
function inlineCode(node, _, state) {
	let value = node.value || "";
	let sequence = "`";
	let index = -1;
	while (new RegExp("(^|[^`])" + sequence + "([^`]|$)").test(value)) sequence += "`";
	if (/[^ \r\n]/.test(value) && (/^[ \r\n]/.test(value) && /[ \r\n]$/.test(value) || /^`|`$/.test(value))) value = " " + value + " ";
	while (++index < state.unsafe.length) {
		const pattern = state.unsafe[index];
		const expression = state.compilePattern(pattern);
		/** @type {RegExpExecArray | null} */
		let match;
		if (!pattern.atBreak) continue;
		while (match = expression.exec(value)) {
			let position = match.index;
			if (value.charCodeAt(position) === 10 && value.charCodeAt(position - 1) === 13) position--;
			value = value.slice(0, position) + " " + value.slice(match.index + 1);
		}
	}
	return sequence + value + sequence;
}
/**
* @returns {string}
*/
function inlineCodePeek() {
	return "`";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/format-link-as-autolink.js
/**
* @import {State} from 'mdast-util-to-markdown'
* @import {Link} from 'mdast'
*/
/**
* @param {Link} node
* @param {State} state
* @returns {boolean}
*/
function formatLinkAsAutolink(node, state) {
	const raw = toString(node);
	return Boolean(!state.options.resourceLink && node.url && !node.title && node.children && node.children.length === 1 && node.children[0].type === "text" && (raw === node.url || "mailto:" + raw === node.url) && /^[a-z][a-z+.-]+:/i.test(node.url) && !/[\0- <>\u007F]/.test(node.url));
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/link.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Link, Parents} from 'mdast'
* @import {Exit} from '../types.js'
*/
link.peek = linkPeek;
/**
* @param {Link} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function link(node, _, state, info) {
	const quote = checkQuote(state);
	const suffix = quote === "\"" ? "Quote" : "Apostrophe";
	const tracker = state.createTracker(info);
	/** @type {Exit} */
	let exit;
	/** @type {Exit} */
	let subexit;
	if (formatLinkAsAutolink(node, state)) {
		const stack = state.stack;
		state.stack = [];
		exit = state.enter("autolink");
		let value = tracker.move("<");
		value += tracker.move(state.containerPhrasing(node, {
			before: value,
			after: ">",
			...tracker.current()
		}));
		value += tracker.move(">");
		exit();
		state.stack = stack;
		return value;
	}
	exit = state.enter("link");
	subexit = state.enter("label");
	let value = tracker.move("[");
	value += tracker.move(state.containerPhrasing(node, {
		before: value,
		after: "](",
		...tracker.current()
	}));
	value += tracker.move("](");
	subexit();
	if (!node.url && node.title || /[\0- \u007F]/.test(node.url)) {
		subexit = state.enter("destinationLiteral");
		value += tracker.move("<");
		value += tracker.move(state.safe(node.url, {
			before: value,
			after: ">",
			...tracker.current()
		}));
		value += tracker.move(">");
	} else {
		subexit = state.enter("destinationRaw");
		value += tracker.move(state.safe(node.url, {
			before: value,
			after: node.title ? " " : ")",
			...tracker.current()
		}));
	}
	subexit();
	if (node.title) {
		subexit = state.enter(`title${suffix}`);
		value += tracker.move(" " + quote);
		value += tracker.move(state.safe(node.title, {
			before: value,
			after: quote,
			...tracker.current()
		}));
		value += tracker.move(quote);
		subexit();
	}
	value += tracker.move(")");
	exit();
	return value;
}
/**
* @param {Link} node
* @param {Parents | undefined} _
* @param {State} state
* @returns {string}
*/
function linkPeek(node, _, state) {
	return formatLinkAsAutolink(node, state) ? "<" : "[";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/link-reference.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {LinkReference, Parents} from 'mdast'
*/
linkReference.peek = linkReferencePeek;
/**
* @param {LinkReference} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function linkReference(node, _, state, info) {
	const type = node.referenceType;
	const exit = state.enter("linkReference");
	let subexit = state.enter("label");
	const tracker = state.createTracker(info);
	let value = tracker.move("[");
	const text = state.containerPhrasing(node, {
		before: value,
		after: "]",
		...tracker.current()
	});
	value += tracker.move(text + "][");
	subexit();
	const stack = state.stack;
	state.stack = [];
	subexit = state.enter("reference");
	const reference = state.safe(state.associationId(node), {
		before: value,
		after: "]",
		...tracker.current()
	});
	subexit();
	state.stack = stack;
	exit();
	if (type === "full" || !text || text !== reference) value += tracker.move(reference + "]");
	else if (type === "shortcut") value = value.slice(0, -1);
	else value += tracker.move("]");
	return value;
}
/**
* @returns {string}
*/
function linkReferencePeek() {
	return "[";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-bullet.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['bullet'], null | undefined>}
*/
function checkBullet(state) {
	const marker = state.options.bullet || "*";
	if (marker !== "*" && marker !== "+" && marker !== "-") throw new Error("Cannot serialize items with `" + marker + "` for `options.bullet`, expected `*`, `+`, or `-`");
	return marker;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-bullet-other.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['bullet'], null | undefined>}
*/
function checkBulletOther(state) {
	const bullet = checkBullet(state);
	const bulletOther = state.options.bulletOther;
	if (!bulletOther) return bullet === "*" ? "-" : "*";
	if (bulletOther !== "*" && bulletOther !== "+" && bulletOther !== "-") throw new Error("Cannot serialize items with `" + bulletOther + "` for `options.bulletOther`, expected `*`, `+`, or `-`");
	if (bulletOther === bullet) throw new Error("Expected `bullet` (`" + bullet + "`) and `bulletOther` (`" + bulletOther + "`) to be different");
	return bulletOther;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-bullet-ordered.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['bulletOrdered'], null | undefined>}
*/
function checkBulletOrdered(state) {
	const marker = state.options.bulletOrdered || ".";
	if (marker !== "." && marker !== ")") throw new Error("Cannot serialize items with `" + marker + "` for `options.bulletOrdered`, expected `.` or `)`");
	return marker;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-rule.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['rule'], null | undefined>}
*/
function checkRule(state) {
	const marker = state.options.rule || "*";
	if (marker !== "*" && marker !== "-" && marker !== "_") throw new Error("Cannot serialize rules with `" + marker + "` for `options.rule`, expected `*`, `-`, or `_`");
	return marker;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/list.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {List, Parents} from 'mdast'
*/
/**
* @param {List} node
* @param {Parents | undefined} parent
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function list(node, parent, state, info) {
	const exit = state.enter("list");
	const bulletCurrent = state.bulletCurrent;
	/** @type {string} */
	let bullet = node.ordered ? checkBulletOrdered(state) : checkBullet(state);
	/** @type {string} */
	const bulletOther = node.ordered ? bullet === "." ? ")" : "." : checkBulletOther(state);
	let useDifferentMarker = parent && state.bulletLastUsed ? bullet === state.bulletLastUsed : false;
	if (!node.ordered) {
		const firstListItem = node.children ? node.children[0] : void 0;
		if ((bullet === "*" || bullet === "-") && firstListItem && (!firstListItem.children || !firstListItem.children[0]) && state.stack[state.stack.length - 1] === "list" && state.stack[state.stack.length - 2] === "listItem" && state.stack[state.stack.length - 3] === "list" && state.stack[state.stack.length - 4] === "listItem" && state.indexStack[state.indexStack.length - 1] === 0 && state.indexStack[state.indexStack.length - 2] === 0 && state.indexStack[state.indexStack.length - 3] === 0) useDifferentMarker = true;
		if (checkRule(state) === bullet && firstListItem) {
			let index = -1;
			while (++index < node.children.length) {
				const item = node.children[index];
				if (item && item.type === "listItem" && item.children && item.children[0] && item.children[0].type === "thematicBreak") {
					useDifferentMarker = true;
					break;
				}
			}
		}
	}
	if (useDifferentMarker) bullet = bulletOther;
	state.bulletCurrent = bullet;
	const value = state.containerFlow(node, info);
	state.bulletLastUsed = bullet;
	state.bulletCurrent = bulletCurrent;
	exit();
	return value;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-list-item-indent.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['listItemIndent'], null | undefined>}
*/
function checkListItemIndent(state) {
	const style = state.options.listItemIndent || "one";
	if (style !== "tab" && style !== "one" && style !== "mixed") throw new Error("Cannot serialize items with `" + style + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");
	return style;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/list-item.js
/**
* @import {Info, Map, State} from 'mdast-util-to-markdown'
* @import {ListItem, Parents} from 'mdast'
*/
/**
* @param {ListItem} node
* @param {Parents | undefined} parent
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function listItem(node, parent, state, info) {
	const listItemIndent = checkListItemIndent(state);
	let bullet = state.bulletCurrent || checkBullet(state);
	if (parent && parent.type === "list" && parent.ordered) bullet = (typeof parent.start === "number" && parent.start > -1 ? parent.start : 1) + (state.options.incrementListMarker === false ? 0 : parent.children.indexOf(node)) + bullet;
	let size = bullet.length + 1;
	if (listItemIndent === "tab" || listItemIndent === "mixed" && (parent && parent.type === "list" && parent.spread || node.spread)) size = Math.ceil(size / 4) * 4;
	const tracker = state.createTracker(info);
	tracker.move(bullet + " ".repeat(size - bullet.length));
	tracker.shift(size);
	const exit = state.enter("listItem");
	const value = state.indentLines(state.containerFlow(node, tracker.current()), map);
	exit();
	return value;
	/** @type {Map} */
	function map(line, index, blank) {
		if (index) return (blank ? "" : " ".repeat(size)) + line;
		return (blank ? bullet : bullet + " ".repeat(size - bullet.length)) + line;
	}
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/paragraph.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Paragraph, Parents} from 'mdast'
*/
/**
* @param {Paragraph} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function paragraph(node, _, state, info) {
	const exit = state.enter("paragraph");
	const subexit = state.enter("phrasing");
	const value = state.containerPhrasing(node, info);
	subexit();
	exit();
	return value;
}
//#endregion
//#region node_modules/mdast-util-phrasing/lib/index.js
/**
* @typedef {import('mdast').Html} Html
* @typedef {import('mdast').PhrasingContent} PhrasingContent
*/
/**
* Check if the given value is *phrasing content*.
*
* > 👉 **Note**: Excludes `html`, which can be both phrasing or flow.
*
* @param node
*   Thing to check, typically `Node`.
* @returns
*   Whether `value` is phrasing content.
*/
var phrasing = convert([
	"break",
	"delete",
	"emphasis",
	"footnote",
	"footnoteReference",
	"image",
	"imageReference",
	"inlineCode",
	"inlineMath",
	"link",
	"linkReference",
	"mdxJsxTextElement",
	"mdxTextExpression",
	"strong",
	"text",
	"textDirective"
]);
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/root.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Parents, Root} from 'mdast'
*/
/**
* @param {Root} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function root(node, _, state, info) {
	return (node.children.some(function(d) {
		return phrasing(d);
	}) ? state.containerPhrasing : state.containerFlow).call(state, node, info);
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-strong.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['strong'], null | undefined>}
*/
function checkStrong(state) {
	const marker = state.options.strong || "*";
	if (marker !== "*" && marker !== "_") throw new Error("Cannot serialize strong with `" + marker + "` for `options.strong`, expected `*`, or `_`");
	return marker;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/strong.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Parents, Strong} from 'mdast'
*/
strong.peek = strongPeek;
/**
* @param {Strong} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function strong(node, _, state, info) {
	const marker = checkStrong(state);
	const exit = state.enter("strong");
	const tracker = state.createTracker(info);
	const before = tracker.move(marker + marker);
	let between = tracker.move(state.containerPhrasing(node, {
		after: marker,
		before,
		...tracker.current()
	}));
	const betweenHead = between.charCodeAt(0);
	const open = encodeInfo(info.before.charCodeAt(info.before.length - 1), betweenHead, marker);
	if (open.inside) between = encodeCharacterReference(betweenHead) + between.slice(1);
	const betweenTail = between.charCodeAt(between.length - 1);
	const close = encodeInfo(info.after.charCodeAt(0), betweenTail, marker);
	if (close.inside) between = between.slice(0, -1) + encodeCharacterReference(betweenTail);
	const after = tracker.move(marker + marker);
	exit();
	state.attentionEncodeSurroundingInfo = {
		after: close.outside,
		before: open.outside
	};
	return before + between + after;
}
/**
* @param {Strong} _
* @param {Parents | undefined} _1
* @param {State} state
* @returns {string}
*/
function strongPeek(_, _1, state) {
	return state.options.strong || "*";
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/text.js
/**
* @import {Info, State} from 'mdast-util-to-markdown'
* @import {Parents, Text} from 'mdast'
*/
/**
* @param {Text} node
* @param {Parents | undefined} _
* @param {State} state
* @param {Info} info
* @returns {string}
*/
function text$1(node, _, state, info) {
	return state.safe(node.value, info);
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/util/check-rule-repetition.js
/**
* @import {Options, State} from 'mdast-util-to-markdown'
*/
/**
* @param {State} state
* @returns {Exclude<Options['ruleRepetition'], null | undefined>}
*/
function checkRuleRepetition(state) {
	const repetition = state.options.ruleRepetition || 3;
	if (repetition < 3) throw new Error("Cannot serialize rules with repetition `" + repetition + "` for `options.ruleRepetition`, expected `3` or more");
	return repetition;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/thematic-break.js
/**
* @import {State} from 'mdast-util-to-markdown'
* @import {Parents, ThematicBreak} from 'mdast'
*/
/**
* @param {ThematicBreak} _
* @param {Parents | undefined} _1
* @param {State} state
* @returns {string}
*/
function thematicBreak(_, _1, state) {
	const value = (checkRule(state) + (state.options.ruleSpaces ? " " : "")).repeat(checkRuleRepetition(state));
	return state.options.ruleSpaces ? value.slice(0, -1) : value;
}
//#endregion
//#region node_modules/mdast-util-to-markdown/lib/handle/index.js
/**
* Default (CommonMark) handlers.
*/
var handle = {
	blockquote,
	break: hardBreak,
	code: code$1,
	definition,
	emphasis,
	hardBreak,
	heading,
	html,
	image,
	imageReference,
	inlineCode,
	link,
	linkReference,
	list,
	listItem,
	paragraph,
	root,
	strong,
	text: text$1,
	thematicBreak
};
//#endregion
//#region node_modules/mdast-util-gfm-table/lib/index.js
/**
* @typedef {import('mdast').InlineCode} InlineCode
* @typedef {import('mdast').Table} Table
* @typedef {import('mdast').TableCell} TableCell
* @typedef {import('mdast').TableRow} TableRow
*
* @typedef {import('markdown-table').Options} MarkdownTableOptions
*
* @typedef {import('mdast-util-from-markdown').CompileContext} CompileContext
* @typedef {import('mdast-util-from-markdown').Extension} FromMarkdownExtension
* @typedef {import('mdast-util-from-markdown').Handle} FromMarkdownHandle
*
* @typedef {import('mdast-util-to-markdown').Options} ToMarkdownExtension
* @typedef {import('mdast-util-to-markdown').Handle} ToMarkdownHandle
* @typedef {import('mdast-util-to-markdown').State} State
* @typedef {import('mdast-util-to-markdown').Info} Info
*/
/**
* @typedef Options
*   Configuration.
* @property {boolean | null | undefined} [tableCellPadding=true]
*   Whether to add a space of padding between delimiters and cells (default:
*   `true`).
* @property {boolean | null | undefined} [tablePipeAlign=true]
*   Whether to align the delimiters (default: `true`).
* @property {MarkdownTableOptions['stringLength'] | null | undefined} [stringLength]
*   Function to detect the length of table cell content, used when aligning
*   the delimiters between cells (optional).
*/
/**
* Create an extension for `mdast-util-from-markdown` to enable GFM tables in
* markdown.
*
* @returns {FromMarkdownExtension}
*   Extension for `mdast-util-from-markdown` to enable GFM tables.
*/
function gfmTableFromMarkdown() {
	return {
		enter: {
			table: enterTable,
			tableData: enterCell,
			tableHeader: enterCell,
			tableRow: enterRow
		},
		exit: {
			codeText: exitCodeText,
			table: exitTable,
			tableData: exit,
			tableHeader: exit,
			tableRow: exit
		}
	};
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterTable(token) {
	const align = token._align;
	ok(align, "expected `_align` on table");
	this.enter({
		type: "table",
		align: align.map(function(d) {
			return d === "none" ? null : d;
		}),
		children: []
	}, token);
	this.data.inTable = true;
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitTable(token) {
	this.exit(token);
	this.data.inTable = void 0;
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterRow(token) {
	this.enter({
		type: "tableRow",
		children: []
	}, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exit(token) {
	this.exit(token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function enterCell(token) {
	this.enter({
		type: "tableCell",
		children: []
	}, token);
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitCodeText(token) {
	let value = this.resume();
	if (this.data.inTable) value = value.replace(/\\([\\|])/g, replace);
	const node = this.stack[this.stack.length - 1];
	ok(node.type === "inlineCode");
	node.value = value;
	this.exit(token);
}
/**
* @param {string} $0
* @param {string} $1
* @returns {string}
*/
function replace($0, $1) {
	return $1 === "|" ? $1 : $0;
}
/**
* Create an extension for `mdast-util-to-markdown` to enable GFM tables in
* markdown.
*
* @param {Options | null | undefined} [options]
*   Configuration.
* @returns {ToMarkdownExtension}
*   Extension for `mdast-util-to-markdown` to enable GFM tables.
*/
function gfmTableToMarkdown(options) {
	const settings = options || {};
	const padding = settings.tableCellPadding;
	const alignDelimiters = settings.tablePipeAlign;
	const stringLength = settings.stringLength;
	const around = padding ? " " : "|";
	return {
		unsafe: [
			{
				character: "\r",
				inConstruct: "tableCell"
			},
			{
				character: "\n",
				inConstruct: "tableCell"
			},
			{
				atBreak: true,
				character: "|",
				after: "[	 :-]"
			},
			{
				character: "|",
				inConstruct: "tableCell"
			},
			{
				atBreak: true,
				character: ":",
				after: "-"
			},
			{
				atBreak: true,
				character: "-",
				after: "[:|-]"
			}
		],
		handlers: {
			inlineCode: inlineCodeWithTable,
			table: handleTable,
			tableCell: handleTableCell,
			tableRow: handleTableRow
		}
	};
	/**
	* @type {ToMarkdownHandle}
	* @param {Table} node
	*/
	function handleTable(node, _, state, info) {
		return serializeData(handleTableAsData(node, state, info), node.align);
	}
	/**
	* This function isn’t really used normally, because we handle rows at the
	* table level.
	* But, if someone passes in a table row, this ensures we make somewhat sense.
	*
	* @type {ToMarkdownHandle}
	* @param {TableRow} node
	*/
	function handleTableRow(node, _, state, info) {
		const value = serializeData([handleTableRowAsData(node, state, info)]);
		return value.slice(0, value.indexOf("\n"));
	}
	/**
	* @type {ToMarkdownHandle}
	* @param {TableCell} node
	*/
	function handleTableCell(node, _, state, info) {
		const exit = state.enter("tableCell");
		const subexit = state.enter("phrasing");
		const value = state.containerPhrasing(node, {
			...info,
			before: around,
			after: around
		});
		subexit();
		exit();
		return value;
	}
	/**
	* @param {Array<Array<string>>} matrix
	* @param {Array<string | null | undefined> | null | undefined} [align]
	*/
	function serializeData(matrix, align) {
		return markdownTable(matrix, {
			align,
			alignDelimiters,
			padding,
			stringLength
		});
	}
	/**
	* @param {Table} node
	* @param {State} state
	* @param {Info} info
	*/
	function handleTableAsData(node, state, info) {
		const children = node.children;
		let index = -1;
		/** @type {Array<Array<string>>} */
		const result = [];
		const subexit = state.enter("table");
		while (++index < children.length) result[index] = handleTableRowAsData(children[index], state, info);
		subexit();
		return result;
	}
	/**
	* @param {TableRow} node
	* @param {State} state
	* @param {Info} info
	*/
	function handleTableRowAsData(node, state, info) {
		const children = node.children;
		let index = -1;
		/** @type {Array<string>} */
		const result = [];
		const subexit = state.enter("tableRow");
		while (++index < children.length) result[index] = handleTableCell(children[index], node, state, info);
		subexit();
		return result;
	}
	/**
	* @type {ToMarkdownHandle}
	* @param {InlineCode} node
	*/
	function inlineCodeWithTable(node, parent, state) {
		let value = handle.inlineCode(node, parent, state);
		if (state.stack.includes("tableCell")) value = value.replace(/\|/g, "\\$&");
		return value;
	}
}
//#endregion
//#region node_modules/mdast-util-gfm-task-list-item/lib/index.js
/**
* @typedef {import('mdast').ListItem} ListItem
* @typedef {import('mdast').Paragraph} Paragraph
* @typedef {import('mdast-util-from-markdown').CompileContext} CompileContext
* @typedef {import('mdast-util-from-markdown').Extension} FromMarkdownExtension
* @typedef {import('mdast-util-from-markdown').Handle} FromMarkdownHandle
* @typedef {import('mdast-util-to-markdown').Options} ToMarkdownExtension
* @typedef {import('mdast-util-to-markdown').Handle} ToMarkdownHandle
*/
/**
* Create an extension for `mdast-util-from-markdown` to enable GFM task
* list items in markdown.
*
* @returns {FromMarkdownExtension}
*   Extension for `mdast-util-from-markdown` to enable GFM task list items.
*/
function gfmTaskListItemFromMarkdown() {
	return { exit: {
		taskListCheckValueChecked: exitCheck,
		taskListCheckValueUnchecked: exitCheck,
		paragraph: exitParagraphWithTaskListItem
	} };
}
/**
* Create an extension for `mdast-util-to-markdown` to enable GFM task list
* items in markdown.
*
* @returns {ToMarkdownExtension}
*   Extension for `mdast-util-to-markdown` to enable GFM task list items.
*/
function gfmTaskListItemToMarkdown() {
	return {
		unsafe: [{
			atBreak: true,
			character: "-",
			after: "[:|-]"
		}],
		handlers: { listItem: listItemWithTaskListItem }
	};
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitCheck(token) {
	const node = this.stack[this.stack.length - 2];
	ok(node.type === "listItem");
	node.checked = token.type === "taskListCheckValueChecked";
}
/**
* @this {CompileContext}
* @type {FromMarkdownHandle}
*/
function exitParagraphWithTaskListItem(token) {
	const parent = this.stack[this.stack.length - 2];
	if (parent && parent.type === "listItem" && typeof parent.checked === "boolean") {
		const node = this.stack[this.stack.length - 1];
		ok(node.type === "paragraph");
		const head = node.children[0];
		if (head && head.type === "text") {
			const siblings = parent.children;
			let index = -1;
			/** @type {Paragraph | undefined} */
			let firstParaghraph;
			while (++index < siblings.length) {
				const sibling = siblings[index];
				if (sibling.type === "paragraph") {
					firstParaghraph = sibling;
					break;
				}
			}
			if (firstParaghraph === node) {
				head.value = head.value.slice(1);
				if (head.value.length === 0) node.children.shift();
				else if (node.position && head.position && typeof head.position.start.offset === "number") {
					head.position.start.column++;
					head.position.start.offset++;
					node.position.start = Object.assign({}, head.position.start);
				}
			}
		}
	}
	this.exit(token);
}
/**
* @type {ToMarkdownHandle}
* @param {ListItem} node
*/
function listItemWithTaskListItem(node, parent, state, info) {
	const head = node.children[0];
	const checkable = typeof node.checked === "boolean" && head && head.type === "paragraph";
	const checkbox = "[" + (node.checked ? "x" : " ") + "] ";
	const tracker = state.createTracker(info);
	if (checkable) tracker.move(checkbox);
	let value = handle.listItem(node, parent, state, {
		...info,
		...tracker.current()
	});
	if (checkable) value = value.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, check);
	return value;
	/**
	* @param {string} $0
	* @returns {string}
	*/
	function check($0) {
		return $0 + checkbox;
	}
}
//#endregion
//#region node_modules/mdast-util-gfm/lib/index.js
/**
* @import {Extension as FromMarkdownExtension} from 'mdast-util-from-markdown'
* @import {Options} from 'mdast-util-gfm'
* @import {Options as ToMarkdownExtension} from 'mdast-util-to-markdown'
*/
/**
* Create an extension for `mdast-util-from-markdown` to enable GFM (autolink
* literals, footnotes, strikethrough, tables, tasklists).
*
* @returns {Array<FromMarkdownExtension>}
*   Extension for `mdast-util-from-markdown` to enable GFM (autolink literals,
*   footnotes, strikethrough, tables, tasklists).
*/
function gfmFromMarkdown() {
	return [
		gfmAutolinkLiteralFromMarkdown(),
		gfmFootnoteFromMarkdown(),
		gfmStrikethroughFromMarkdown(),
		gfmTableFromMarkdown(),
		gfmTaskListItemFromMarkdown()
	];
}
/**
* Create an extension for `mdast-util-to-markdown` to enable GFM (autolink
* literals, footnotes, strikethrough, tables, tasklists).
*
* @param {Options | null | undefined} [options]
*   Configuration (optional).
* @returns {ToMarkdownExtension}
*   Extension for `mdast-util-to-markdown` to enable GFM (autolink literals,
*   footnotes, strikethrough, tables, tasklists).
*/
function gfmToMarkdown(options) {
	return { extensions: [
		gfmAutolinkLiteralToMarkdown(),
		gfmFootnoteToMarkdown(options),
		gfmStrikethroughToMarkdown(),
		gfmTableToMarkdown(options),
		gfmTaskListItemToMarkdown()
	] };
}
//#endregion
//#region node_modules/micromark-extension-gfm-autolink-literal/dev/lib/syntax.js
/**
* @import {Code, ConstructRecord, Event, Extension, Previous, State, TokenizeContext, Tokenizer} from 'micromark-util-types'
*/
var wwwPrefix = {
	tokenize: tokenizeWwwPrefix,
	partial: true
};
var domain = {
	tokenize: tokenizeDomain,
	partial: true
};
var path = {
	tokenize: tokenizePath,
	partial: true
};
var trail = {
	tokenize: tokenizeTrail,
	partial: true
};
var emailDomainDotTrail = {
	tokenize: tokenizeEmailDomainDotTrail,
	partial: true
};
var wwwAutolink = {
	name: "wwwAutolink",
	tokenize: tokenizeWwwAutolink,
	previous: previousWww
};
var protocolAutolink = {
	name: "protocolAutolink",
	tokenize: tokenizeProtocolAutolink,
	previous: previousProtocol
};
var emailAutolink = {
	name: "emailAutolink",
	tokenize: tokenizeEmailAutolink,
	previous: previousEmail
};
/** @type {ConstructRecord} */
var text = {};
/**
* Create an extension for `micromark` to support GitHub autolink literal
* syntax.
*
* @returns {Extension}
*   Extension for `micromark` that can be passed in `extensions` to enable GFM
*   autolink literal syntax.
*/
function gfmAutolinkLiteral() {
	return { text };
}
/** @type {Code} */
var code = codes.digit0;
while (code < codes.leftCurlyBrace) {
	text[code] = emailAutolink;
	code++;
	if (code === codes.colon) code = codes.uppercaseA;
	else if (code === codes.leftSquareBracket) code = codes.lowercaseA;
}
text[codes.plusSign] = emailAutolink;
text[codes.dash] = emailAutolink;
text[codes.dot] = emailAutolink;
text[codes.underscore] = emailAutolink;
text[codes.uppercaseH] = [emailAutolink, protocolAutolink];
text[codes.lowercaseH] = [emailAutolink, protocolAutolink];
text[codes.uppercaseW] = [emailAutolink, wwwAutolink];
text[codes.lowercaseW] = [emailAutolink, wwwAutolink];
/**
* Email autolink literal.
*
* ```markdown
* > | a contact@example.org b
*       ^^^^^^^^^^^^^^^^^^^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeEmailAutolink(effects, ok, nok) {
	const self = this;
	/** @type {boolean | undefined} */
	let dot;
	/** @type {boolean} */
	let data;
	return start;
	/**
	* Start of email autolink literal.
	*
	* ```markdown
	* > | a contact@example.org b
	*       ^
	* ```
	*
	* @type {State}
	*/
	function start(code) {
		if (!gfmAtext(code) || !previousEmail.call(self, self.previous) || previousUnbalanced(self.events)) return nok(code);
		effects.enter("literalAutolink");
		effects.enter("literalAutolinkEmail");
		return atext(code);
	}
	/**
	* In email atext.
	*
	* ```markdown
	* > | a contact@example.org b
	*       ^
	* ```
	*
	* @type {State}
	*/
	function atext(code) {
		if (gfmAtext(code)) {
			effects.consume(code);
			return atext;
		}
		if (code === codes.atSign) {
			effects.consume(code);
			return emailDomain;
		}
		return nok(code);
	}
	/**
	* In email domain.
	*
	* The reference code is a bit overly complex as it handles the `@`, of which
	* there may be just one.
	* Source: <https://github.com/github/cmark-gfm/blob/ef1cfcb/extensions/autolink.c#L318>
	*
	* ```markdown
	* > | a contact@example.org b
	*               ^
	* ```
	*
	* @type {State}
	*/
	function emailDomain(code) {
		if (code === codes.dot) return effects.check(emailDomainDotTrail, emailDomainAfter, emailDomainDot)(code);
		if (code === codes.dash || code === codes.underscore || asciiAlphanumeric(code)) {
			data = true;
			effects.consume(code);
			return emailDomain;
		}
		return emailDomainAfter(code);
	}
	/**
	* In email domain, on dot that is not a trail.
	*
	* ```markdown
	* > | a contact@example.org b
	*                      ^
	* ```
	*
	* @type {State}
	*/
	function emailDomainDot(code) {
		effects.consume(code);
		dot = true;
		return emailDomain;
	}
	/**
	* After email domain.
	*
	* ```markdown
	* > | a contact@example.org b
	*                          ^
	* ```
	*
	* @type {State}
	*/
	function emailDomainAfter(code) {
		if (data && dot && asciiAlpha(self.previous)) {
			effects.exit("literalAutolinkEmail");
			effects.exit("literalAutolink");
			return ok(code);
		}
		return nok(code);
	}
}
/**
* `www` autolink literal.
*
* ```markdown
* > | a www.example.org b
*       ^^^^^^^^^^^^^^^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeWwwAutolink(effects, ok, nok) {
	const self = this;
	return wwwStart;
	/**
	* Start of www autolink literal.
	*
	* ```markdown
	* > | www.example.com/a?b#c
	*     ^
	* ```
	*
	* @type {State}
	*/
	function wwwStart(code) {
		if (code !== codes.uppercaseW && code !== codes.lowercaseW || !previousWww.call(self, self.previous) || previousUnbalanced(self.events)) return nok(code);
		effects.enter("literalAutolink");
		effects.enter("literalAutolinkWww");
		return effects.check(wwwPrefix, effects.attempt(domain, effects.attempt(path, wwwAfter), nok), nok)(code);
	}
	/**
	* After a www autolink literal.
	*
	* ```markdown
	* > | www.example.com/a?b#c
	*                          ^
	* ```
	*
	* @type {State}
	*/
	function wwwAfter(code) {
		effects.exit("literalAutolinkWww");
		effects.exit("literalAutolink");
		return ok(code);
	}
}
/**
* Protocol autolink literal.
*
* ```markdown
* > | a https://example.org b
*       ^^^^^^^^^^^^^^^^^^^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeProtocolAutolink(effects, ok, nok) {
	const self = this;
	let buffer = "";
	let seen = false;
	return protocolStart;
	/**
	* Start of protocol autolink literal.
	*
	* ```markdown
	* > | https://example.com/a?b#c
	*     ^
	* ```
	*
	* @type {State}
	*/
	function protocolStart(code) {
		if ((code === codes.uppercaseH || code === codes.lowercaseH) && previousProtocol.call(self, self.previous) && !previousUnbalanced(self.events)) {
			effects.enter("literalAutolink");
			effects.enter("literalAutolinkHttp");
			buffer += String.fromCodePoint(code);
			effects.consume(code);
			return protocolPrefixInside;
		}
		return nok(code);
	}
	/**
	* In protocol.
	*
	* ```markdown
	* > | https://example.com/a?b#c
	*     ^^^^^
	* ```
	*
	* @type {State}
	*/
	function protocolPrefixInside(code) {
		if (asciiAlpha(code) && buffer.length < 5) {
			buffer += String.fromCodePoint(code);
			effects.consume(code);
			return protocolPrefixInside;
		}
		if (code === codes.colon) {
			const protocol = buffer.toLowerCase();
			if (protocol === "http" || protocol === "https") {
				effects.consume(code);
				return protocolSlashesInside;
			}
		}
		return nok(code);
	}
	/**
	* In slashes.
	*
	* ```markdown
	* > | https://example.com/a?b#c
	*           ^^
	* ```
	*
	* @type {State}
	*/
	function protocolSlashesInside(code) {
		if (code === codes.slash) {
			effects.consume(code);
			if (seen) return afterProtocol;
			seen = true;
			return protocolSlashesInside;
		}
		return nok(code);
	}
	/**
	* After protocol, before domain.
	*
	* ```markdown
	* > | https://example.com/a?b#c
	*             ^
	* ```
	*
	* @type {State}
	*/
	function afterProtocol(code) {
		return code === codes.eof || asciiControl(code) || markdownLineEndingOrSpace(code) || unicodeWhitespace(code) || unicodePunctuation(code) ? nok(code) : effects.attempt(domain, effects.attempt(path, protocolAfter), nok)(code);
	}
	/**
	* After a protocol autolink literal.
	*
	* ```markdown
	* > | https://example.com/a?b#c
	*                              ^
	* ```
	*
	* @type {State}
	*/
	function protocolAfter(code) {
		effects.exit("literalAutolinkHttp");
		effects.exit("literalAutolink");
		return ok(code);
	}
}
/**
* `www` prefix.
*
* ```markdown
* > | a www.example.org b
*       ^^^^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeWwwPrefix(effects, ok, nok) {
	let size = 0;
	return wwwPrefixInside;
	/**
	* In www prefix.
	*
	* ```markdown
	* > | www.example.com
	*     ^^^^
	* ```
	*
	* @type {State}
	*/
	function wwwPrefixInside(code) {
		if ((code === codes.uppercaseW || code === codes.lowercaseW) && size < 3) {
			size++;
			effects.consume(code);
			return wwwPrefixInside;
		}
		if (code === codes.dot && size === 3) {
			effects.consume(code);
			return wwwPrefixAfter;
		}
		return nok(code);
	}
	/**
	* After www prefix.
	*
	* ```markdown
	* > | www.example.com
	*         ^
	* ```
	*
	* @type {State}
	*/
	function wwwPrefixAfter(code) {
		return code === codes.eof ? nok(code) : ok(code);
	}
}
/**
* Domain.
*
* ```markdown
* > | a https://example.org b
*               ^^^^^^^^^^^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeDomain(effects, ok, nok) {
	/** @type {boolean | undefined} */
	let underscoreInLastSegment;
	/** @type {boolean | undefined} */
	let underscoreInLastLastSegment;
	/** @type {boolean | undefined} */
	let seen;
	return domainInside;
	/**
	* In domain.
	*
	* ```markdown
	* > | https://example.com/a
	*             ^^^^^^^^^^^
	* ```
	*
	* @type {State}
	*/
	function domainInside(code) {
		if (code === codes.dot || code === codes.underscore) return effects.check(trail, domainAfter, domainAtPunctuation)(code);
		if (code === codes.eof || markdownLineEndingOrSpace(code) || unicodeWhitespace(code) || code !== codes.dash && unicodePunctuation(code)) return domainAfter(code);
		seen = true;
		effects.consume(code);
		return domainInside;
	}
	/**
	* In domain, at potential trailing punctuation, that was not trailing.
	*
	* ```markdown
	* > | https://example.com
	*                    ^
	* ```
	*
	* @type {State}
	*/
	function domainAtPunctuation(code) {
		if (code === codes.underscore) underscoreInLastSegment = true;
		else {
			underscoreInLastLastSegment = underscoreInLastSegment;
			underscoreInLastSegment = void 0;
		}
		effects.consume(code);
		return domainInside;
	}
	/**
	* After domain.
	*
	* ```markdown
	* > | https://example.com/a
	*                        ^
	* ```
	*
	* @type {State} */
	function domainAfter(code) {
		if (underscoreInLastLastSegment || underscoreInLastSegment || !seen) return nok(code);
		return ok(code);
	}
}
/**
* Path.
*
* ```markdown
* > | a https://example.org/stuff b
*                          ^^^^^^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizePath(effects, ok) {
	let sizeOpen = 0;
	let sizeClose = 0;
	return pathInside;
	/**
	* In path.
	*
	* ```markdown
	* > | https://example.com/a
	*                        ^^
	* ```
	*
	* @type {State}
	*/
	function pathInside(code) {
		if (code === codes.leftParenthesis) {
			sizeOpen++;
			effects.consume(code);
			return pathInside;
		}
		if (code === codes.rightParenthesis && sizeClose < sizeOpen) return pathAtPunctuation(code);
		if (code === codes.exclamationMark || code === codes.quotationMark || code === codes.ampersand || code === codes.apostrophe || code === codes.rightParenthesis || code === codes.asterisk || code === codes.comma || code === codes.dot || code === codes.colon || code === codes.semicolon || code === codes.lessThan || code === codes.questionMark || code === codes.rightSquareBracket || code === codes.underscore || code === codes.tilde) return effects.check(trail, ok, pathAtPunctuation)(code);
		if (code === codes.eof || markdownLineEndingOrSpace(code) || unicodeWhitespace(code)) return ok(code);
		effects.consume(code);
		return pathInside;
	}
	/**
	* In path, at potential trailing punctuation, that was not trailing.
	*
	* ```markdown
	* > | https://example.com/a"b
	*                          ^
	* ```
	*
	* @type {State}
	*/
	function pathAtPunctuation(code) {
		if (code === codes.rightParenthesis) sizeClose++;
		effects.consume(code);
		return pathInside;
	}
}
/**
* Trail.
*
* This calls `ok` if this *is* the trail, followed by an end, which means
* the entire trail is not part of the link.
* It calls `nok` if this *is* part of the link.
*
* ```markdown
* > | https://example.com").
*                        ^^^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeTrail(effects, ok, nok) {
	return trail;
	/**
	* In trail of domain or path.
	*
	* ```markdown
	* > | https://example.com").
	*                        ^
	* ```
	*
	* @type {State}
	*/
	function trail(code) {
		if (code === codes.exclamationMark || code === codes.quotationMark || code === codes.apostrophe || code === codes.rightParenthesis || code === codes.asterisk || code === codes.comma || code === codes.dot || code === codes.colon || code === codes.semicolon || code === codes.questionMark || code === codes.underscore || code === codes.tilde) {
			effects.consume(code);
			return trail;
		}
		if (code === codes.ampersand) {
			effects.consume(code);
			return trailCharacterReferenceStart;
		}
		if (code === codes.rightSquareBracket) {
			effects.consume(code);
			return trailBracketAfter;
		}
		if (code === codes.lessThan || code === codes.eof || markdownLineEndingOrSpace(code) || unicodeWhitespace(code)) return ok(code);
		return nok(code);
	}
	/**
	* In trail, after `]`.
	*
	* > 👉 **Note**: this deviates from `cmark-gfm` to fix a bug.
	* > See end of <https://github.com/github/cmark-gfm/issues/278> for more.
	*
	* ```markdown
	* > | https://example.com](
	*                         ^
	* ```
	*
	* @type {State}
	*/
	function trailBracketAfter(code) {
		if (code === codes.eof || code === codes.leftParenthesis || code === codes.leftSquareBracket || markdownLineEndingOrSpace(code) || unicodeWhitespace(code)) return ok(code);
		return trail(code);
	}
	/**
	* In character-reference like trail, after `&`.
	*
	* ```markdown
	* > | https://example.com&amp;).
	*                         ^
	* ```
	*
	* @type {State}
	*/
	function trailCharacterReferenceStart(code) {
		return asciiAlpha(code) ? trailCharacterReferenceInside(code) : nok(code);
	}
	/**
	* In character-reference like trail.
	*
	* ```markdown
	* > | https://example.com&amp;).
	*                         ^
	* ```
	*
	* @type {State}
	*/
	function trailCharacterReferenceInside(code) {
		if (code === codes.semicolon) {
			effects.consume(code);
			return trail;
		}
		if (asciiAlpha(code)) {
			effects.consume(code);
			return trailCharacterReferenceInside;
		}
		return nok(code);
	}
}
/**
* Dot in email domain trail.
*
* This calls `ok` if this *is* the trail, followed by an end, which means
* the trail is not part of the link.
* It calls `nok` if this *is* part of the link.
*
* ```markdown
* > | contact@example.org.
*                        ^
* ```
*
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeEmailDomainDotTrail(effects, ok, nok) {
	return start;
	/**
	* Dot.
	*
	* ```markdown
	* > | contact@example.org.
	*                    ^   ^
	* ```
	*
	* @type {State}
	*/
	function start(code) {
		effects.consume(code);
		return after;
	}
	/**
	* After dot.
	*
	* ```markdown
	* > | contact@example.org.
	*                     ^   ^
	* ```
	*
	* @type {State}
	*/
	function after(code) {
		return asciiAlphanumeric(code) ? nok(code) : ok(code);
	}
}
/**
* See:
* <https://github.com/github/cmark-gfm/blob/ef1cfcb/extensions/autolink.c#L156>.
*
* @type {Previous}
*/
function previousWww(code) {
	return code === codes.eof || code === codes.leftParenthesis || code === codes.asterisk || code === codes.underscore || code === codes.leftSquareBracket || code === codes.rightSquareBracket || code === codes.tilde || markdownLineEndingOrSpace(code);
}
/**
* See:
* <https://github.com/github/cmark-gfm/blob/ef1cfcb/extensions/autolink.c#L214>.
*
* @type {Previous}
*/
function previousProtocol(code) {
	return !asciiAlpha(code);
}
/**
* @this {TokenizeContext}
* @type {Previous}
*/
function previousEmail(code) {
	return !(code === codes.slash || gfmAtext(code));
}
/**
* @param {Code} code
* @returns {boolean}
*/
function gfmAtext(code) {
	return code === codes.plusSign || code === codes.dash || code === codes.dot || code === codes.underscore || asciiAlphanumeric(code);
}
/**
* @param {Array<Event>} events
* @returns {boolean}
*/
function previousUnbalanced(events) {
	let index = events.length;
	let result = false;
	while (index--) {
		const token = events[index][1];
		if ((token.type === "labelLink" || token.type === "labelImage") && !token._balanced) {
			result = true;
			break;
		}
		if (token._gfmAutolinkLiteralWalkedInto) {
			result = false;
			break;
		}
	}
	if (events.length > 0 && !result) events[events.length - 1][1]._gfmAutolinkLiteralWalkedInto = true;
	return result;
}
//#endregion
//#region node_modules/micromark-extension-gfm-footnote/dev/lib/syntax.js
/**
* @import {Event, Exiter, Extension, Resolver, State, Token, TokenizeContext, Tokenizer} from 'micromark-util-types'
*/
var indent = {
	tokenize: tokenizeIndent,
	partial: true
};
/**
* Create an extension for `micromark` to enable GFM footnote syntax.
*
* @returns {Extension}
*   Extension for `micromark` that can be passed in `extensions` to
*   enable GFM footnote syntax.
*/
function gfmFootnote() {
	/** @type {Extension} */
	return {
		document: { [codes.leftSquareBracket]: {
			name: "gfmFootnoteDefinition",
			tokenize: tokenizeDefinitionStart,
			continuation: { tokenize: tokenizeDefinitionContinuation },
			exit: gfmFootnoteDefinitionEnd
		} },
		text: {
			[codes.leftSquareBracket]: {
				name: "gfmFootnoteCall",
				tokenize: tokenizeGfmFootnoteCall
			},
			[codes.rightSquareBracket]: {
				name: "gfmPotentialFootnoteCall",
				add: "after",
				tokenize: tokenizePotentialGfmFootnoteCall,
				resolveTo: resolveToPotentialGfmFootnoteCall
			}
		}
	};
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizePotentialGfmFootnoteCall(effects, ok$4, nok) {
	const self = this;
	let index = self.events.length;
	const defined = self.parser.gfmFootnotes || (self.parser.gfmFootnotes = []);
	/** @type {Token} */
	let labelStart;
	while (index--) {
		const token = self.events[index][1];
		if (token.type === types.labelImage) {
			labelStart = token;
			break;
		}
		if (token.type === "gfmFootnoteCall" || token.type === types.labelLink || token.type === types.label || token.type === types.image || token.type === types.link) break;
	}
	return start;
	/**
	* @type {State}
	*/
	function start(code) {
		ok(code === codes.rightSquareBracket, "expected `]`");
		if (!labelStart || !labelStart._balanced) return nok(code);
		const id = normalizeIdentifier(self.sliceSerialize({
			start: labelStart.end,
			end: self.now()
		}));
		if (id.codePointAt(0) !== codes.caret || !defined.includes(id.slice(1))) return nok(code);
		effects.enter("gfmFootnoteCallLabelMarker");
		effects.consume(code);
		effects.exit("gfmFootnoteCallLabelMarker");
		return ok$4(code);
	}
}
/** @type {Resolver} */
function resolveToPotentialGfmFootnoteCall(events, context) {
	let index = events.length;
	/** @type {Token | undefined} */
	let labelStart;
	while (index--) if (events[index][1].type === types.labelImage && events[index][0] === "enter") {
		labelStart = events[index][1];
		break;
	}
	ok(labelStart, "expected `labelStart` to resolve");
	events[index + 1][1].type = types.data;
	events[index + 3][1].type = "gfmFootnoteCallLabelMarker";
	/** @type {Token} */
	const call = {
		type: "gfmFootnoteCall",
		start: Object.assign({}, events[index + 3][1].start),
		end: Object.assign({}, events[events.length - 1][1].end)
	};
	/** @type {Token} */
	const marker = {
		type: "gfmFootnoteCallMarker",
		start: Object.assign({}, events[index + 3][1].end),
		end: Object.assign({}, events[index + 3][1].end)
	};
	marker.end.column++;
	marker.end.offset++;
	marker.end._bufferIndex++;
	/** @type {Token} */
	const string = {
		type: "gfmFootnoteCallString",
		start: Object.assign({}, marker.end),
		end: Object.assign({}, events[events.length - 1][1].start)
	};
	/** @type {Token} */
	const chunk = {
		type: types.chunkString,
		contentType: "string",
		start: Object.assign({}, string.start),
		end: Object.assign({}, string.end)
	};
	/** @type {Array<Event>} */
	const replacement = [
		events[index + 1],
		events[index + 2],
		[
			"enter",
			call,
			context
		],
		events[index + 3],
		events[index + 4],
		[
			"enter",
			marker,
			context
		],
		[
			"exit",
			marker,
			context
		],
		[
			"enter",
			string,
			context
		],
		[
			"enter",
			chunk,
			context
		],
		[
			"exit",
			chunk,
			context
		],
		[
			"exit",
			string,
			context
		],
		events[events.length - 2],
		events[events.length - 1],
		[
			"exit",
			call,
			context
		]
	];
	events.splice(index, events.length - index + 1, ...replacement);
	return events;
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeGfmFootnoteCall(effects, ok$5, nok) {
	const self = this;
	const defined = self.parser.gfmFootnotes || (self.parser.gfmFootnotes = []);
	let size = 0;
	/** @type {boolean} */
	let data;
	return start;
	/**
	* Start of footnote label.
	*
	* ```markdown
	* > | a [^b] c
	*       ^
	* ```
	*
	* @type {State}
	*/
	function start(code) {
		ok(code === codes.leftSquareBracket, "expected `[`");
		effects.enter("gfmFootnoteCall");
		effects.enter("gfmFootnoteCallLabelMarker");
		effects.consume(code);
		effects.exit("gfmFootnoteCallLabelMarker");
		return callStart;
	}
	/**
	* After `[`, at `^`.
	*
	* ```markdown
	* > | a [^b] c
	*        ^
	* ```
	*
	* @type {State}
	*/
	function callStart(code) {
		if (code !== codes.caret) return nok(code);
		effects.enter("gfmFootnoteCallMarker");
		effects.consume(code);
		effects.exit("gfmFootnoteCallMarker");
		effects.enter("gfmFootnoteCallString");
		effects.enter("chunkString").contentType = "string";
		return callData;
	}
	/**
	* In label.
	*
	* ```markdown
	* > | a [^b] c
	*         ^
	* ```
	*
	* @type {State}
	*/
	function callData(code) {
		if (size > constants.linkReferenceSizeMax || code === codes.rightSquareBracket && !data || code === codes.eof || code === codes.leftSquareBracket || markdownLineEndingOrSpace(code)) return nok(code);
		if (code === codes.rightSquareBracket) {
			effects.exit("chunkString");
			const token = effects.exit("gfmFootnoteCallString");
			if (!defined.includes(normalizeIdentifier(self.sliceSerialize(token)))) return nok(code);
			effects.enter("gfmFootnoteCallLabelMarker");
			effects.consume(code);
			effects.exit("gfmFootnoteCallLabelMarker");
			effects.exit("gfmFootnoteCall");
			return ok$5;
		}
		if (!markdownLineEndingOrSpace(code)) data = true;
		size++;
		effects.consume(code);
		return code === codes.backslash ? callEscape : callData;
	}
	/**
	* On character after escape.
	*
	* ```markdown
	* > | a [^b\c] d
	*           ^
	* ```
	*
	* @type {State}
	*/
	function callEscape(code) {
		if (code === codes.leftSquareBracket || code === codes.backslash || code === codes.rightSquareBracket) {
			effects.consume(code);
			size++;
			return callData;
		}
		return callData(code);
	}
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeDefinitionStart(effects, ok$6, nok) {
	const self = this;
	const defined = self.parser.gfmFootnotes || (self.parser.gfmFootnotes = []);
	/** @type {string} */
	let identifier;
	let size = 0;
	/** @type {boolean | undefined} */
	let data;
	return start;
	/**
	* Start of GFM footnote definition.
	*
	* ```markdown
	* > | [^a]: b
	*     ^
	* ```
	*
	* @type {State}
	*/
	function start(code) {
		ok(code === codes.leftSquareBracket, "expected `[`");
		effects.enter("gfmFootnoteDefinition")._container = true;
		effects.enter("gfmFootnoteDefinitionLabel");
		effects.enter("gfmFootnoteDefinitionLabelMarker");
		effects.consume(code);
		effects.exit("gfmFootnoteDefinitionLabelMarker");
		return labelAtMarker;
	}
	/**
	* In label, at caret.
	*
	* ```markdown
	* > | [^a]: b
	*      ^
	* ```
	*
	* @type {State}
	*/
	function labelAtMarker(code) {
		if (code === codes.caret) {
			effects.enter("gfmFootnoteDefinitionMarker");
			effects.consume(code);
			effects.exit("gfmFootnoteDefinitionMarker");
			effects.enter("gfmFootnoteDefinitionLabelString");
			effects.enter("chunkString").contentType = "string";
			return labelInside;
		}
		return nok(code);
	}
	/**
	* In label.
	*
	* > 👉 **Note**: `cmark-gfm` prevents whitespace from occurring in footnote
	* > definition labels.
	*
	* ```markdown
	* > | [^a]: b
	*       ^
	* ```
	*
	* @type {State}
	*/
	function labelInside(code) {
		if (size > constants.linkReferenceSizeMax || code === codes.rightSquareBracket && !data || code === codes.eof || code === codes.leftSquareBracket || markdownLineEndingOrSpace(code)) return nok(code);
		if (code === codes.rightSquareBracket) {
			effects.exit("chunkString");
			const token = effects.exit("gfmFootnoteDefinitionLabelString");
			identifier = normalizeIdentifier(self.sliceSerialize(token));
			effects.enter("gfmFootnoteDefinitionLabelMarker");
			effects.consume(code);
			effects.exit("gfmFootnoteDefinitionLabelMarker");
			effects.exit("gfmFootnoteDefinitionLabel");
			return labelAfter;
		}
		if (!markdownLineEndingOrSpace(code)) data = true;
		size++;
		effects.consume(code);
		return code === codes.backslash ? labelEscape : labelInside;
	}
	/**
	* After `\`, at a special character.
	*
	* > 👉 **Note**: `cmark-gfm` currently does not support escaped brackets:
	* > <https://github.com/github/cmark-gfm/issues/240>
	*
	* ```markdown
	* > | [^a\*b]: c
	*         ^
	* ```
	*
	* @type {State}
	*/
	function labelEscape(code) {
		if (code === codes.leftSquareBracket || code === codes.backslash || code === codes.rightSquareBracket) {
			effects.consume(code);
			size++;
			return labelInside;
		}
		return labelInside(code);
	}
	/**
	* After definition label.
	*
	* ```markdown
	* > | [^a]: b
	*         ^
	* ```
	*
	* @type {State}
	*/
	function labelAfter(code) {
		if (code === codes.colon) {
			effects.enter("definitionMarker");
			effects.consume(code);
			effects.exit("definitionMarker");
			if (!defined.includes(identifier)) defined.push(identifier);
			return factorySpace(effects, whitespaceAfter, "gfmFootnoteDefinitionWhitespace");
		}
		return nok(code);
	}
	/**
	* After definition prefix.
	*
	* ```markdown
	* > | [^a]: b
	*           ^
	* ```
	*
	* @type {State}
	*/
	function whitespaceAfter(code) {
		return ok$6(code);
	}
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeDefinitionContinuation(effects, ok, nok) {
	return effects.check(blankLine, ok, effects.attempt(indent, ok, nok));
}
/** @type {Exiter} */
function gfmFootnoteDefinitionEnd(effects) {
	effects.exit("gfmFootnoteDefinition");
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeIndent(effects, ok, nok) {
	const self = this;
	return factorySpace(effects, afterPrefix, "gfmFootnoteDefinitionIndent", constants.tabSize + 1);
	/**
	* @type {State}
	*/
	function afterPrefix(code) {
		const tail = self.events[self.events.length - 1];
		return tail && tail[1].type === "gfmFootnoteDefinitionIndent" && tail[2].sliceSerialize(tail[1], true).length === constants.tabSize ? ok(code) : nok(code);
	}
}
//#endregion
//#region node_modules/micromark-extension-gfm-strikethrough/dev/lib/syntax.js
/**
* @import {Options} from 'micromark-extension-gfm-strikethrough'
* @import {Event, Extension, Resolver, State, Token, TokenizeContext, Tokenizer} from 'micromark-util-types'
*/
/**
* Create an extension for `micromark` to enable GFM strikethrough syntax.
*
* @param {Options | null | undefined} [options={}]
*   Configuration.
* @returns {Extension}
*   Extension for `micromark` that can be passed in `extensions`, to
*   enable GFM strikethrough syntax.
*/
function gfmStrikethrough(options) {
	let single = (options || {}).singleTilde;
	const tokenizer = {
		name: "strikethrough",
		tokenize: tokenizeStrikethrough,
		resolveAll: resolveAllStrikethrough
	};
	if (single === null || single === void 0) single = true;
	return {
		text: { [codes.tilde]: tokenizer },
		insideSpan: { null: [tokenizer] },
		attentionMarkers: { null: [codes.tilde] }
	};
	/**
	* Take events and resolve strikethrough.
	*
	* @type {Resolver}
	*/
	function resolveAllStrikethrough(events, context) {
		let index = -1;
		while (++index < events.length) if (events[index][0] === "enter" && events[index][1].type === "strikethroughSequenceTemporary" && events[index][1]._close) {
			let open = index;
			while (open--) if (events[open][0] === "exit" && events[open][1].type === "strikethroughSequenceTemporary" && events[open][1]._open && events[index][1].end.offset - events[index][1].start.offset === events[open][1].end.offset - events[open][1].start.offset) {
				events[index][1].type = "strikethroughSequence";
				events[open][1].type = "strikethroughSequence";
				/** @type {Token} */
				const strikethrough = {
					type: "strikethrough",
					start: Object.assign({}, events[open][1].start),
					end: Object.assign({}, events[index][1].end)
				};
				/** @type {Token} */
				const text = {
					type: "strikethroughText",
					start: Object.assign({}, events[open][1].end),
					end: Object.assign({}, events[index][1].start)
				};
				/** @type {Array<Event>} */
				const nextEvents = [
					[
						"enter",
						strikethrough,
						context
					],
					[
						"enter",
						events[open][1],
						context
					],
					[
						"exit",
						events[open][1],
						context
					],
					[
						"enter",
						text,
						context
					]
				];
				const insideSpan = context.parser.constructs.insideSpan.null;
				if (insideSpan) splice(nextEvents, nextEvents.length, 0, resolveAll(insideSpan, events.slice(open + 1, index), context));
				splice(nextEvents, nextEvents.length, 0, [
					[
						"exit",
						text,
						context
					],
					[
						"enter",
						events[index][1],
						context
					],
					[
						"exit",
						events[index][1],
						context
					],
					[
						"exit",
						strikethrough,
						context
					]
				]);
				splice(events, open - 1, index - open + 3, nextEvents);
				index = open + nextEvents.length - 2;
				break;
			}
		}
		index = -1;
		while (++index < events.length) if (events[index][1].type === "strikethroughSequenceTemporary") events[index][1].type = types.data;
		return events;
	}
	/**
	* @this {TokenizeContext}
	* @type {Tokenizer}
	*/
	function tokenizeStrikethrough(effects, ok$3, nok) {
		const previous = this.previous;
		const events = this.events;
		let size = 0;
		return start;
		/** @type {State} */
		function start(code) {
			ok(code === codes.tilde, "expected `~`");
			if (previous === codes.tilde && events[events.length - 1][1].type !== types.characterEscape) return nok(code);
			effects.enter("strikethroughSequenceTemporary");
			return more(code);
		}
		/** @type {State} */
		function more(code) {
			const before = classifyCharacter(previous);
			if (code === codes.tilde) {
				if (size > 1) return nok(code);
				effects.consume(code);
				size++;
				return more;
			}
			if (size < 2 && !single) return nok(code);
			const token = effects.exit("strikethroughSequenceTemporary");
			const after = classifyCharacter(code);
			token._open = !after || after === constants.attentionSideAfter && Boolean(before);
			token._close = !before || before === constants.attentionSideAfter && Boolean(after);
			return ok$3(code);
		}
	}
}
//#endregion
//#region node_modules/micromark-extension-gfm-table/dev/lib/edit-map.js
/**
* @import {Event} from 'micromark-util-types'
*/
/**
* @typedef {[number, number, Array<Event>]} Change
* @typedef {[number, number, number]} Jump
*/
/**
* Tracks a bunch of edits.
*/
var EditMap = class {
	/**
	* Create a new edit map.
	*/
	constructor() {
		/**
		* Record of changes.
		*
		* @type {Array<Change>}
		*/
		this.map = [];
	}
	/**
	* Create an edit: a remove and/or add at a certain place.
	*
	* @param {number} index
	* @param {number} remove
	* @param {Array<Event>} add
	* @returns {undefined}
	*/
	add(index, remove, add) {
		addImplementation(this, index, remove, add);
	}
	/**
	* Done, change the events.
	*
	* @param {Array<Event>} events
	* @returns {undefined}
	*/
	consume(events) {
		this.map.sort(function(a, b) {
			return a[0] - b[0];
		});
		/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
		if (this.map.length === 0) return;
		let index = this.map.length;
		/** @type {Array<Array<Event>>} */
		const vecs = [];
		while (index > 0) {
			index -= 1;
			vecs.push(events.slice(this.map[index][0] + this.map[index][1]), this.map[index][2]);
			events.length = this.map[index][0];
		}
		vecs.push(events.slice());
		events.length = 0;
		let slice = vecs.pop();
		while (slice) {
			for (const element of slice) events.push(element);
			slice = vecs.pop();
		}
		this.map.length = 0;
	}
};
/**
* Create an edit.
*
* @param {EditMap} editMap
* @param {number} at
* @param {number} remove
* @param {Array<Event>} add
* @returns {undefined}
*/
function addImplementation(editMap, at, remove, add) {
	let index = 0;
	/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
	if (remove === 0 && add.length === 0) return;
	while (index < editMap.map.length) {
		if (editMap.map[index][0] === at) {
			editMap.map[index][1] += remove;
			editMap.map[index][2].push(...add);
			return;
		}
		index += 1;
	}
	editMap.map.push([
		at,
		remove,
		add
	]);
}
//#endregion
//#region node_modules/micromark-extension-gfm-table/dev/lib/infer.js
/**
* @import {Event} from 'micromark-util-types'
*/
/**
* @typedef {'center' | 'left' | 'none' | 'right'} Align
*/
/**
* Figure out the alignment of a GFM table.
*
* @param {Readonly<Array<Event>>} events
*   List of events.
* @param {number} index
*   Table enter event.
* @returns {Array<Align>}
*   List of aligns.
*/
function gfmTableAlign(events, index) {
	ok(events[index][1].type === "table", "expected table");
	let inDelimiterRow = false;
	/** @type {Array<Align>} */
	const align = [];
	while (index < events.length) {
		const event = events[index];
		if (inDelimiterRow) {
			if (event[0] === "enter") {
				if (event[1].type === "tableContent") align.push(events[index + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
			} else if (event[1].type === "tableContent") {
				if (events[index - 1][1].type === "tableDelimiterMarker") {
					const alignIndex = align.length - 1;
					align[alignIndex] = align[alignIndex] === "left" ? "center" : "right";
				}
			} else if (event[1].type === "tableDelimiterRow") break;
		} else if (event[0] === "enter" && event[1].type === "tableDelimiterRow") inDelimiterRow = true;
		index += 1;
	}
	return align;
}
//#endregion
//#region node_modules/micromark-extension-gfm-table/dev/lib/syntax.js
/**
* @import {Event, Extension, Point, Resolver, State, Token, TokenizeContext, Tokenizer} from 'micromark-util-types'
*/
/**
* @typedef {[number, number, number, number]} Range
*   Cell info.
*
* @typedef {0 | 1 | 2 | 3} RowKind
*   Where we are: `1` for head row, `2` for delimiter row, `3` for body row.
*/
/**
* Create an HTML extension for `micromark` to support GitHub tables syntax.
*
* @returns {Extension}
*   Extension for `micromark` that can be passed in `extensions` to enable GFM
*   table syntax.
*/
function gfmTable() {
	return { flow: { null: {
		name: "table",
		tokenize: tokenizeTable,
		resolveAll: resolveTable
	} } };
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeTable(effects, ok$2, nok) {
	const self = this;
	let size = 0;
	let sizeB = 0;
	/** @type {boolean | undefined} */
	let seen;
	return start;
	/**
	* Start of a GFM table.
	*
	* If there is a valid table row or table head before, then we try to parse
	* another row.
	* Otherwise, we try to parse a head.
	*
	* ```markdown
	* > | | a |
	*     ^
	*   | | - |
	* > | | b |
	*     ^
	* ```
	* @type {State}
	*/
	function start(code) {
		let index = self.events.length - 1;
		while (index > -1) {
			const type = self.events[index][1].type;
			if (type === types.lineEnding || type === types.linePrefix) index--;
			else break;
		}
		const tail = index > -1 ? self.events[index][1].type : null;
		const next = tail === "tableHead" || tail === "tableRow" ? bodyRowStart : headRowBefore;
		if (next === bodyRowStart && self.parser.lazy[self.now().line]) return nok(code);
		return next(code);
	}
	/**
	* Before table head row.
	*
	* ```markdown
	* > | | a |
	*     ^
	*   | | - |
	*   | | b |
	* ```
	*
	* @type {State}
	*/
	function headRowBefore(code) {
		effects.enter("tableHead");
		effects.enter("tableRow");
		return headRowStart(code);
	}
	/**
	* Before table head row, after whitespace.
	*
	* ```markdown
	* > | | a |
	*     ^
	*   | | - |
	*   | | b |
	* ```
	*
	* @type {State}
	*/
	function headRowStart(code) {
		if (code === codes.verticalBar) return headRowBreak(code);
		seen = true;
		sizeB += 1;
		return headRowBreak(code);
	}
	/**
	* At break in table head row.
	*
	* ```markdown
	* > | | a |
	*     ^
	*       ^
	*         ^
	*   | | - |
	*   | | b |
	* ```
	*
	* @type {State}
	*/
	function headRowBreak(code) {
		if (code === codes.eof) return nok(code);
		if (markdownLineEnding(code)) {
			if (sizeB > 1) {
				sizeB = 0;
				self.interrupt = true;
				effects.exit("tableRow");
				effects.enter(types.lineEnding);
				effects.consume(code);
				effects.exit(types.lineEnding);
				return headDelimiterStart;
			}
			return nok(code);
		}
		if (markdownSpace(code)) return factorySpace(effects, headRowBreak, types.whitespace)(code);
		sizeB += 1;
		if (seen) {
			seen = false;
			size += 1;
		}
		if (code === codes.verticalBar) {
			effects.enter("tableCellDivider");
			effects.consume(code);
			effects.exit("tableCellDivider");
			seen = true;
			return headRowBreak;
		}
		effects.enter(types.data);
		return headRowData(code);
	}
	/**
	* In table head row data.
	*
	* ```markdown
	* > | | a |
	*       ^
	*   | | - |
	*   | | b |
	* ```
	*
	* @type {State}
	*/
	function headRowData(code) {
		if (code === codes.eof || code === codes.verticalBar || markdownLineEndingOrSpace(code)) {
			effects.exit(types.data);
			return headRowBreak(code);
		}
		effects.consume(code);
		return code === codes.backslash ? headRowEscape : headRowData;
	}
	/**
	* In table head row escape.
	*
	* ```markdown
	* > | | a\-b |
	*         ^
	*   | | ---- |
	*   | | c    |
	* ```
	*
	* @type {State}
	*/
	function headRowEscape(code) {
		if (code === codes.backslash || code === codes.verticalBar) {
			effects.consume(code);
			return headRowData;
		}
		return headRowData(code);
	}
	/**
	* Before delimiter row.
	*
	* ```markdown
	*   | | a |
	* > | | - |
	*     ^
	*   | | b |
	* ```
	*
	* @type {State}
	*/
	function headDelimiterStart(code) {
		self.interrupt = false;
		if (self.parser.lazy[self.now().line]) return nok(code);
		effects.enter("tableDelimiterRow");
		seen = false;
		if (markdownSpace(code)) {
			ok(self.parser.constructs.disable.null, "expected `disabled.null`");
			return factorySpace(effects, headDelimiterBefore, types.linePrefix, self.parser.constructs.disable.null.includes("codeIndented") ? void 0 : constants.tabSize)(code);
		}
		return headDelimiterBefore(code);
	}
	/**
	* Before delimiter row, after optional whitespace.
	*
	* Reused when a `|` is found later, to parse another cell.
	*
	* ```markdown
	*   | | a |
	* > | | - |
	*     ^
	*   | | b |
	* ```
	*
	* @type {State}
	*/
	function headDelimiterBefore(code) {
		if (code === codes.dash || code === codes.colon) return headDelimiterValueBefore(code);
		if (code === codes.verticalBar) {
			seen = true;
			effects.enter("tableCellDivider");
			effects.consume(code);
			effects.exit("tableCellDivider");
			return headDelimiterCellBefore;
		}
		return headDelimiterNok(code);
	}
	/**
	* After `|`, before delimiter cell.
	*
	* ```markdown
	*   | | a |
	* > | | - |
	*      ^
	* ```
	*
	* @type {State}
	*/
	function headDelimiterCellBefore(code) {
		if (markdownSpace(code)) return factorySpace(effects, headDelimiterValueBefore, types.whitespace)(code);
		return headDelimiterValueBefore(code);
	}
	/**
	* Before delimiter cell value.
	*
	* ```markdown
	*   | | a |
	* > | | - |
	*       ^
	* ```
	*
	* @type {State}
	*/
	function headDelimiterValueBefore(code) {
		if (code === codes.colon) {
			sizeB += 1;
			seen = true;
			effects.enter("tableDelimiterMarker");
			effects.consume(code);
			effects.exit("tableDelimiterMarker");
			return headDelimiterLeftAlignmentAfter;
		}
		if (code === codes.dash) {
			sizeB += 1;
			return headDelimiterLeftAlignmentAfter(code);
		}
		if (code === codes.eof || markdownLineEnding(code)) return headDelimiterCellAfter(code);
		return headDelimiterNok(code);
	}
	/**
	* After delimiter cell left alignment marker.
	*
	* ```markdown
	*   | | a  |
	* > | | :- |
	*        ^
	* ```
	*
	* @type {State}
	*/
	function headDelimiterLeftAlignmentAfter(code) {
		if (code === codes.dash) {
			effects.enter("tableDelimiterFiller");
			return headDelimiterFiller(code);
		}
		return headDelimiterNok(code);
	}
	/**
	* In delimiter cell filler.
	*
	* ```markdown
	*   | | a |
	* > | | - |
	*       ^
	* ```
	*
	* @type {State}
	*/
	function headDelimiterFiller(code) {
		if (code === codes.dash) {
			effects.consume(code);
			return headDelimiterFiller;
		}
		if (code === codes.colon) {
			seen = true;
			effects.exit("tableDelimiterFiller");
			effects.enter("tableDelimiterMarker");
			effects.consume(code);
			effects.exit("tableDelimiterMarker");
			return headDelimiterRightAlignmentAfter;
		}
		effects.exit("tableDelimiterFiller");
		return headDelimiterRightAlignmentAfter(code);
	}
	/**
	* After delimiter cell right alignment marker.
	*
	* ```markdown
	*   | |  a |
	* > | | -: |
	*         ^
	* ```
	*
	* @type {State}
	*/
	function headDelimiterRightAlignmentAfter(code) {
		if (markdownSpace(code)) return factorySpace(effects, headDelimiterCellAfter, types.whitespace)(code);
		return headDelimiterCellAfter(code);
	}
	/**
	* After delimiter cell.
	*
	* ```markdown
	*   | |  a |
	* > | | -: |
	*          ^
	* ```
	*
	* @type {State}
	*/
	function headDelimiterCellAfter(code) {
		if (code === codes.verticalBar) return headDelimiterBefore(code);
		if (code === codes.eof || markdownLineEnding(code)) {
			if (!seen || size !== sizeB) return headDelimiterNok(code);
			effects.exit("tableDelimiterRow");
			effects.exit("tableHead");
			return ok$2(code);
		}
		return headDelimiterNok(code);
	}
	/**
	* In delimiter row, at a disallowed byte.
	*
	* ```markdown
	*   | | a |
	* > | | x |
	*       ^
	* ```
	*
	* @type {State}
	*/
	function headDelimiterNok(code) {
		return nok(code);
	}
	/**
	* Before table body row.
	*
	* ```markdown
	*   | | a |
	*   | | - |
	* > | | b |
	*     ^
	* ```
	*
	* @type {State}
	*/
	function bodyRowStart(code) {
		effects.enter("tableRow");
		return bodyRowBreak(code);
	}
	/**
	* At break in table body row.
	*
	* ```markdown
	*   | | a |
	*   | | - |
	* > | | b |
	*     ^
	*       ^
	*         ^
	* ```
	*
	* @type {State}
	*/
	function bodyRowBreak(code) {
		if (code === codes.verticalBar) {
			effects.enter("tableCellDivider");
			effects.consume(code);
			effects.exit("tableCellDivider");
			return bodyRowBreak;
		}
		if (code === codes.eof || markdownLineEnding(code)) {
			effects.exit("tableRow");
			return ok$2(code);
		}
		if (markdownSpace(code)) return factorySpace(effects, bodyRowBreak, types.whitespace)(code);
		effects.enter(types.data);
		return bodyRowData(code);
	}
	/**
	* In table body row data.
	*
	* ```markdown
	*   | | a |
	*   | | - |
	* > | | b |
	*       ^
	* ```
	*
	* @type {State}
	*/
	function bodyRowData(code) {
		if (code === codes.eof || code === codes.verticalBar || markdownLineEndingOrSpace(code)) {
			effects.exit(types.data);
			return bodyRowBreak(code);
		}
		effects.consume(code);
		return code === codes.backslash ? bodyRowEscape : bodyRowData;
	}
	/**
	* In table body row escape.
	*
	* ```markdown
	*   | | a    |
	*   | | ---- |
	* > | | b\-c |
	*         ^
	* ```
	*
	* @type {State}
	*/
	function bodyRowEscape(code) {
		if (code === codes.backslash || code === codes.verticalBar) {
			effects.consume(code);
			return bodyRowData;
		}
		return bodyRowData(code);
	}
}
/** @type {Resolver} */
function resolveTable(events, context) {
	let index = -1;
	let inFirstCellAwaitingPipe = true;
	/** @type {RowKind} */
	let rowKind = 0;
	/** @type {Range} */
	let lastCell = [
		0,
		0,
		0,
		0
	];
	/** @type {Range} */
	let cell = [
		0,
		0,
		0,
		0
	];
	let afterHeadAwaitingFirstBodyRow = false;
	let lastTableEnd = 0;
	/** @type {Token | undefined} */
	let currentTable;
	/** @type {Token | undefined} */
	let currentBody;
	/** @type {Token | undefined} */
	let currentCell;
	const map = new EditMap();
	while (++index < events.length) {
		const event = events[index];
		const token = event[1];
		if (event[0] === "enter") {
			if (token.type === "tableHead") {
				afterHeadAwaitingFirstBodyRow = false;
				if (lastTableEnd !== 0) {
					ok(currentTable, "there should be a table opening");
					flushTableEnd(map, context, lastTableEnd, currentTable, currentBody);
					currentBody = void 0;
					lastTableEnd = 0;
				}
				currentTable = {
					type: "table",
					start: Object.assign({}, token.start),
					end: Object.assign({}, token.end)
				};
				map.add(index, 0, [[
					"enter",
					currentTable,
					context
				]]);
			} else if (token.type === "tableRow" || token.type === "tableDelimiterRow") {
				inFirstCellAwaitingPipe = true;
				currentCell = void 0;
				lastCell = [
					0,
					0,
					0,
					0
				];
				cell = [
					0,
					index + 1,
					0,
					0
				];
				if (afterHeadAwaitingFirstBodyRow) {
					afterHeadAwaitingFirstBodyRow = false;
					currentBody = {
						type: "tableBody",
						start: Object.assign({}, token.start),
						end: Object.assign({}, token.end)
					};
					map.add(index, 0, [[
						"enter",
						currentBody,
						context
					]]);
				}
				rowKind = token.type === "tableDelimiterRow" ? 2 : currentBody ? 3 : 1;
			} else if (rowKind && (token.type === types.data || token.type === "tableDelimiterMarker" || token.type === "tableDelimiterFiller")) {
				inFirstCellAwaitingPipe = false;
				if (cell[2] === 0) {
					if (lastCell[1] !== 0) {
						cell[0] = cell[1];
						currentCell = flushCell(map, context, lastCell, rowKind, void 0, currentCell);
						lastCell = [
							0,
							0,
							0,
							0
						];
					}
					cell[2] = index;
				}
			} else if (token.type === "tableCellDivider") {
				if (inFirstCellAwaitingPipe) inFirstCellAwaitingPipe = false;
				else {
					if (lastCell[1] !== 0) {
						cell[0] = cell[1];
						currentCell = flushCell(map, context, lastCell, rowKind, void 0, currentCell);
					}
					lastCell = cell;
					cell = [
						lastCell[1],
						index,
						0,
						0
					];
				}
			}
		} else if (token.type === "tableHead") {
			afterHeadAwaitingFirstBodyRow = true;
			lastTableEnd = index;
		} else if (token.type === "tableRow" || token.type === "tableDelimiterRow") {
			lastTableEnd = index;
			if (lastCell[1] !== 0) {
				cell[0] = cell[1];
				currentCell = flushCell(map, context, lastCell, rowKind, index, currentCell);
			} else if (cell[1] !== 0) currentCell = flushCell(map, context, cell, rowKind, index, currentCell);
			rowKind = 0;
		} else if (rowKind && (token.type === types.data || token.type === "tableDelimiterMarker" || token.type === "tableDelimiterFiller")) cell[3] = index;
	}
	if (lastTableEnd !== 0) {
		ok(currentTable, "expected table opening");
		flushTableEnd(map, context, lastTableEnd, currentTable, currentBody);
	}
	map.consume(context.events);
	index = -1;
	while (++index < context.events.length) {
		const event = context.events[index];
		if (event[0] === "enter" && event[1].type === "table") event[1]._align = gfmTableAlign(context.events, index);
	}
	return events;
}
/**
* Generate a cell.
*
* @param {EditMap} map
* @param {Readonly<TokenizeContext>} context
* @param {Readonly<Range>} range
* @param {RowKind} rowKind
* @param {number | undefined} rowEnd
* @param {Token | undefined} previousCell
* @returns {Token | undefined}
*/
function flushCell(map, context, range, rowKind, rowEnd, previousCell) {
	const groupName = rowKind === 1 ? "tableHeader" : rowKind === 2 ? "tableDelimiter" : "tableData";
	const valueName = "tableContent";
	if (range[0] !== 0) {
		ok(previousCell, "expected previous cell enter");
		previousCell.end = Object.assign({}, getPoint(context.events, range[0]));
		map.add(range[0], 0, [[
			"exit",
			previousCell,
			context
		]]);
	}
	const now = getPoint(context.events, range[1]);
	previousCell = {
		type: groupName,
		start: Object.assign({}, now),
		end: Object.assign({}, now)
	};
	map.add(range[1], 0, [[
		"enter",
		previousCell,
		context
	]]);
	if (range[2] !== 0) {
		const relatedStart = getPoint(context.events, range[2]);
		const relatedEnd = getPoint(context.events, range[3]);
		/** @type {Token} */
		const valueToken = {
			type: valueName,
			start: Object.assign({}, relatedStart),
			end: Object.assign({}, relatedEnd)
		};
		map.add(range[2], 0, [[
			"enter",
			valueToken,
			context
		]]);
		ok(range[3] !== 0);
		if (rowKind !== 2) {
			const start = context.events[range[2]];
			const end = context.events[range[3]];
			start[1].end = Object.assign({}, end[1].end);
			start[1].type = types.chunkText;
			start[1].contentType = constants.contentTypeText;
			if (range[3] > range[2] + 1) {
				const a = range[2] + 1;
				const b = range[3] - range[2] - 1;
				map.add(a, b, []);
			}
		}
		map.add(range[3] + 1, 0, [[
			"exit",
			valueToken,
			context
		]]);
	}
	if (rowEnd !== void 0) {
		previousCell.end = Object.assign({}, getPoint(context.events, rowEnd));
		map.add(rowEnd, 0, [[
			"exit",
			previousCell,
			context
		]]);
		previousCell = void 0;
	}
	return previousCell;
}
/**
* Generate table end (and table body end).
*
* @param {Readonly<EditMap>} map
* @param {Readonly<TokenizeContext>} context
* @param {number} index
* @param {Token} table
* @param {Token | undefined} tableBody
*/
function flushTableEnd(map, context, index, table, tableBody) {
	/** @type {Array<Event>} */
	const exits = [];
	const related = getPoint(context.events, index);
	if (tableBody) {
		tableBody.end = Object.assign({}, related);
		exits.push([
			"exit",
			tableBody,
			context
		]);
	}
	table.end = Object.assign({}, related);
	exits.push([
		"exit",
		table,
		context
	]);
	map.add(index + 1, 0, exits);
}
/**
* @param {Readonly<Array<Event>>} events
* @param {number} index
* @returns {Readonly<Point>}
*/
function getPoint(events, index) {
	const event = events[index];
	const side = event[0] === "enter" ? "start" : "end";
	return event[1][side];
}
//#endregion
//#region node_modules/micromark-extension-gfm-task-list-item/dev/lib/syntax.js
/**
* @import {Extension, State, TokenizeContext, Tokenizer} from 'micromark-util-types'
*/
var tasklistCheck = {
	name: "tasklistCheck",
	tokenize: tokenizeTasklistCheck
};
/**
* Create an HTML extension for `micromark` to support GFM task list items
* syntax.
*
* @returns {Extension}
*   Extension for `micromark` that can be passed in `htmlExtensions` to
*   support GFM task list items when serializing to HTML.
*/
function gfmTaskListItem() {
	return { text: { [codes.leftSquareBracket]: tasklistCheck } };
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeTasklistCheck(effects, ok$1, nok) {
	const self = this;
	return open;
	/**
	* At start of task list item check.
	*
	* ```markdown
	* > | * [x] y.
	*       ^
	* ```
	*
	* @type {State}
	*/
	function open(code) {
		ok(code === codes.leftSquareBracket, "expected `[`");
		if (self.previous !== codes.eof || !self._gfmTasklistFirstContentOfListItem) return nok(code);
		effects.enter("taskListCheck");
		effects.enter("taskListCheckMarker");
		effects.consume(code);
		effects.exit("taskListCheckMarker");
		return inside;
	}
	/**
	* In task list item check.
	*
	* ```markdown
	* > | * [x] y.
	*        ^
	* ```
	*
	* @type {State}
	*/
	function inside(code) {
		if (markdownLineEndingOrSpace(code)) {
			effects.enter("taskListCheckValueUnchecked");
			effects.consume(code);
			effects.exit("taskListCheckValueUnchecked");
			return close;
		}
		if (code === codes.uppercaseX || code === codes.lowercaseX) {
			effects.enter("taskListCheckValueChecked");
			effects.consume(code);
			effects.exit("taskListCheckValueChecked");
			return close;
		}
		return nok(code);
	}
	/**
	* At close of task list item check.
	*
	* ```markdown
	* > | * [x] y.
	*         ^
	* ```
	*
	* @type {State}
	*/
	function close(code) {
		if (code === codes.rightSquareBracket) {
			effects.enter("taskListCheckMarker");
			effects.consume(code);
			effects.exit("taskListCheckMarker");
			effects.exit("taskListCheck");
			return after;
		}
		return nok(code);
	}
	/**
	* @type {State}
	*/
	function after(code) {
		if (markdownLineEnding(code)) return ok$1(code);
		if (markdownSpace(code)) return effects.check({ tokenize: spaceThenNonSpace }, ok$1, nok)(code);
		return nok(code);
	}
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function spaceThenNonSpace(effects, ok, nok) {
	return factorySpace(effects, after, types.whitespace);
	/**
	* After whitespace, after task list item check.
	*
	* ```markdown
	* > | * [x] y.
	*           ^
	* ```
	*
	* @type {State}
	*/
	function after(code) {
		return code === codes.eof ? nok(code) : ok(code);
	}
}
//#endregion
//#region node_modules/micromark-extension-gfm/index.js
/**
* @typedef {import('micromark-extension-gfm-footnote').HtmlOptions} HtmlOptions
* @typedef {import('micromark-extension-gfm-strikethrough').Options} Options
* @typedef {import('micromark-util-types').Extension} Extension
* @typedef {import('micromark-util-types').HtmlExtension} HtmlExtension
*/
/**
* Create an extension for `micromark` to enable GFM syntax.
*
* @param {Options | null | undefined} [options]
*   Configuration (optional).
*
*   Passed to `micromark-extens-gfm-strikethrough`.
* @returns {Extension}
*   Extension for `micromark` that can be passed in `extensions` to enable GFM
*   syntax.
*/
function gfm(options) {
	return combineExtensions([
		gfmAutolinkLiteral(),
		gfmFootnote(),
		gfmStrikethrough(options),
		gfmTable(),
		gfmTaskListItem()
	]);
}
//#endregion
//#region node_modules/remark-gfm/lib/index.js
/**
* @import {Root} from 'mdast'
* @import {Options} from 'remark-gfm'
* @import {} from 'remark-parse'
* @import {} from 'remark-stringify'
* @import {Processor} from 'unified'
*/
/** @type {Options} */
var emptyOptions = {};
/**
* Add support GFM (autolink literals, footnotes, strikethrough, tables,
* tasklists).
*
* @param {Options | null | undefined} [options]
*   Configuration (optional).
* @returns {undefined}
*   Nothing.
*/
function remarkGfm(options) {
	const self = this;
	const settings = options || emptyOptions;
	const data = self.data();
	const micromarkExtensions = data.micromarkExtensions || (data.micromarkExtensions = []);
	const fromMarkdownExtensions = data.fromMarkdownExtensions || (data.fromMarkdownExtensions = []);
	const toMarkdownExtensions = data.toMarkdownExtensions || (data.toMarkdownExtensions = []);
	micromarkExtensions.push(gfm(settings));
	fromMarkdownExtensions.push(gfmFromMarkdown());
	toMarkdownExtensions.push(gfmToMarkdown(settings));
}
//#endregion
export { remarkGfm as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVtYXJrLWdmbS5qcyIsIm5hbWVzIjpbImVzY2FwZSIsIm1hcCIsImNvZGUiLCJ0ZXh0IiwiZGVmYXVsdEhhbmRsZXJzIiwiZGVmYXVsdEhhbmRsZXJzIiwib2siLCJvayIsIm9rIiwib2siXSwic291cmNlcyI6WyIuLi8uLi9jY291bnQvaW5kZXguanMiLCIuLi8uLi9lc2NhcGUtc3RyaW5nLXJlZ2V4cC9pbmRleC5qcyIsIi4uLy4uL21kYXN0LXV0aWwtZmluZC1hbmQtcmVwbGFjZS9saWIvaW5kZXguanMiLCIuLi8uLi9tZGFzdC11dGlsLWdmbS1hdXRvbGluay1saXRlcmFsL2xpYi9pbmRleC5qcyIsIi4uLy4uL21kYXN0LXV0aWwtZ2ZtLWZvb3Rub3RlL2xpYi9pbmRleC5qcyIsIi4uLy4uL21kYXN0LXV0aWwtZ2ZtLXN0cmlrZXRocm91Z2gvbGliL2luZGV4LmpzIiwiLi4vLi4vbWFya2Rvd24tdGFibGUvaW5kZXguanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvYmxvY2txdW90ZS5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL3V0aWwvcGF0dGVybi1pbi1zY29wZS5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL2hhbmRsZS9icmVhay5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL3V0aWwvZm9ybWF0LWNvZGUtYXMtaW5kZW50ZWQuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi91dGlsL2NoZWNrLWZlbmNlLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvaGFuZGxlL2NvZGUuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi91dGlsL2NoZWNrLXF1b3RlLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvaGFuZGxlL2RlZmluaXRpb24uanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi91dGlsL2NoZWNrLWVtcGhhc2lzLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvdXRpbC9lbmNvZGUtY2hhcmFjdGVyLXJlZmVyZW5jZS5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL3V0aWwvZW5jb2RlLWluZm8uanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvZW1waGFzaXMuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi91dGlsL2Zvcm1hdC1oZWFkaW5nLWFzLXNldGV4dC5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL2hhbmRsZS9oZWFkaW5nLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvaGFuZGxlL2h0bWwuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvaW1hZ2UuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvaW1hZ2UtcmVmZXJlbmNlLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvaGFuZGxlL2lubGluZS1jb2RlLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvdXRpbC9mb3JtYXQtbGluay1hcy1hdXRvbGluay5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL2hhbmRsZS9saW5rLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvaGFuZGxlL2xpbmstcmVmZXJlbmNlLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvdXRpbC9jaGVjay1idWxsZXQuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi91dGlsL2NoZWNrLWJ1bGxldC1vdGhlci5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL3V0aWwvY2hlY2stYnVsbGV0LW9yZGVyZWQuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi91dGlsL2NoZWNrLXJ1bGUuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvbGlzdC5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL3V0aWwvY2hlY2stbGlzdC1pdGVtLWluZGVudC5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL2hhbmRsZS9saXN0LWl0ZW0uanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvcGFyYWdyYXBoLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC1waHJhc2luZy9saWIvaW5kZXguanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvcm9vdC5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL3V0aWwvY2hlY2stc3Ryb25nLmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvaGFuZGxlL3N0cm9uZy5qcyIsIi4uLy4uL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vbGliL2hhbmRsZS90ZXh0LmpzIiwiLi4vLi4vbWRhc3QtdXRpbC10by1tYXJrZG93bi9saWIvdXRpbC9jaGVjay1ydWxlLXJlcGV0aXRpb24uanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvdGhlbWF0aWMtYnJlYWsuanMiLCIuLi8uLi9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2xpYi9oYW5kbGUvaW5kZXguanMiLCIuLi8uLi9tZGFzdC11dGlsLWdmbS10YWJsZS9saWIvaW5kZXguanMiLCIuLi8uLi9tZGFzdC11dGlsLWdmbS10YXNrLWxpc3QtaXRlbS9saWIvaW5kZXguanMiLCIuLi8uLi9tZGFzdC11dGlsLWdmbS9saWIvaW5kZXguanMiLCIuLi8uLi9taWNyb21hcmstZXh0ZW5zaW9uLWdmbS1hdXRvbGluay1saXRlcmFsL2Rldi9saWIvc3ludGF4LmpzIiwiLi4vLi4vbWljcm9tYXJrLWV4dGVuc2lvbi1nZm0tZm9vdG5vdGUvZGV2L2xpYi9zeW50YXguanMiLCIuLi8uLi9taWNyb21hcmstZXh0ZW5zaW9uLWdmbS1zdHJpa2V0aHJvdWdoL2Rldi9saWIvc3ludGF4LmpzIiwiLi4vLi4vbWljcm9tYXJrLWV4dGVuc2lvbi1nZm0tdGFibGUvZGV2L2xpYi9lZGl0LW1hcC5qcyIsIi4uLy4uL21pY3JvbWFyay1leHRlbnNpb24tZ2ZtLXRhYmxlL2Rldi9saWIvaW5mZXIuanMiLCIuLi8uLi9taWNyb21hcmstZXh0ZW5zaW9uLWdmbS10YWJsZS9kZXYvbGliL3N5bnRheC5qcyIsIi4uLy4uL21pY3JvbWFyay1leHRlbnNpb24tZ2ZtLXRhc2stbGlzdC1pdGVtL2Rldi9saWIvc3ludGF4LmpzIiwiLi4vLi4vbWljcm9tYXJrLWV4dGVuc2lvbi1nZm0vaW5kZXguanMiLCIuLi8uLi9yZW1hcmstZ2ZtL2xpYi9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIENvdW50IGhvdyBvZnRlbiBhIGNoYXJhY3RlciAob3Igc3Vic3RyaW5nKSBpcyB1c2VkIGluIGEgc3RyaW5nLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB2YWx1ZVxuICogICBWYWx1ZSB0byBzZWFyY2ggaW4uXG4gKiBAcGFyYW0ge3N0cmluZ30gY2hhcmFjdGVyXG4gKiAgIENoYXJhY3RlciAob3Igc3Vic3RyaW5nKSB0byBsb29rIGZvci5cbiAqIEByZXR1cm4ge251bWJlcn1cbiAqICAgTnVtYmVyIG9mIHRpbWVzIGBjaGFyYWN0ZXJgIG9jY3VycmVkIGluIGB2YWx1ZWAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjY291bnQodmFsdWUsIGNoYXJhY3Rlcikge1xuICBjb25zdCBzb3VyY2UgPSBTdHJpbmcodmFsdWUpXG5cbiAgaWYgKHR5cGVvZiBjaGFyYWN0ZXIgIT09ICdzdHJpbmcnKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignRXhwZWN0ZWQgY2hhcmFjdGVyJylcbiAgfVxuXG4gIGxldCBjb3VudCA9IDBcbiAgbGV0IGluZGV4ID0gc291cmNlLmluZGV4T2YoY2hhcmFjdGVyKVxuXG4gIHdoaWxlIChpbmRleCAhPT0gLTEpIHtcbiAgICBjb3VudCsrXG4gICAgaW5kZXggPSBzb3VyY2UuaW5kZXhPZihjaGFyYWN0ZXIsIGluZGV4ICsgY2hhcmFjdGVyLmxlbmd0aClcbiAgfVxuXG4gIHJldHVybiBjb3VudFxufVxuIiwiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZXNjYXBlU3RyaW5nUmVnZXhwKHN0cmluZykge1xuXHRpZiAodHlwZW9mIHN0cmluZyAhPT0gJ3N0cmluZycpIHtcblx0XHR0aHJvdyBuZXcgVHlwZUVycm9yKCdFeHBlY3RlZCBhIHN0cmluZycpO1xuXHR9XG5cblx0Ly8gRXNjYXBlIGNoYXJhY3RlcnMgd2l0aCBzcGVjaWFsIG1lYW5pbmcgZWl0aGVyIGluc2lkZSBvciBvdXRzaWRlIGNoYXJhY3RlciBzZXRzLlxuXHQvLyBVc2UgYSBzaW1wbGUgYmFja3NsYXNoIGVzY2FwZSB3aGVuIGl04oCZcyBhbHdheXMgdmFsaWQsIGFuZCBhIGBcXHhubmAgZXNjYXBlIHdoZW4gdGhlIHNpbXBsZXIgZm9ybSB3b3VsZCBiZSBkaXNhbGxvd2VkIGJ5IFVuaWNvZGUgcGF0dGVybnPigJkgc3RyaWN0ZXIgZ3JhbW1hci5cblx0cmV0dXJuIHN0cmluZ1xuXHRcdC5yZXBsYWNlKC9bfFxcXFx7fSgpW1xcXV4kKyo/Ll0vZywgJ1xcXFwkJicpXG5cdFx0LnJlcGxhY2UoLy0vZywgJ1xcXFx4MmQnKTtcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7Tm9kZXMsIFBhcmVudHMsIFBocmFzaW5nQ29udGVudCwgUm9vdCwgVGV4dH0gZnJvbSAnbWRhc3QnXG4gKiBAaW1wb3J0IHtCdWlsZFZpc2l0b3IsIFRlc3QsIFZpc2l0b3JSZXN1bHR9IGZyb20gJ3VuaXN0LXV0aWwtdmlzaXQtcGFyZW50cydcbiAqL1xuXG4vKipcbiAqIEB0eXBlZGVmIFJlZ0V4cE1hdGNoT2JqZWN0XG4gKiAgIEluZm8gb24gdGhlIG1hdGNoLlxuICogQHByb3BlcnR5IHtudW1iZXJ9IGluZGV4XG4gKiAgIFRoZSBpbmRleCBvZiB0aGUgc2VhcmNoIGF0IHdoaWNoIHRoZSByZXN1bHQgd2FzIGZvdW5kLlxuICogQHByb3BlcnR5IHtzdHJpbmd9IGlucHV0XG4gKiAgIEEgY29weSBvZiB0aGUgc2VhcmNoIHN0cmluZyBpbiB0aGUgdGV4dCBub2RlLlxuICogQHByb3BlcnR5IHtbLi4uQXJyYXk8UGFyZW50cz4sIFRleHRdfSBzdGFja1xuICogICBBbGwgYW5jZXN0b3JzIG9mIHRoZSB0ZXh0IG5vZGUsIHdoZXJlIHRoZSBsYXN0IG5vZGUgaXMgdGhlIHRleHQgaXRzZWxmLlxuICpcbiAqIEB0eXBlZGVmIHtSZWdFeHAgfCBzdHJpbmd9IEZpbmRcbiAqICAgUGF0dGVybiB0byBmaW5kLlxuICpcbiAqICAgU3RyaW5ncyBhcmUgZXNjYXBlZCBhbmQgdGhlbiB0dXJuZWQgaW50byBnbG9iYWwgZXhwcmVzc2lvbnMuXG4gKlxuICogQHR5cGVkZWYge0FycmF5PEZpbmRBbmRSZXBsYWNlVHVwbGU+fSBGaW5kQW5kUmVwbGFjZUxpc3RcbiAqICAgU2V2ZXJhbCBmaW5kIGFuZCByZXBsYWNlcywgaW4gYXJyYXkgZm9ybS5cbiAqXG4gKiBAdHlwZWRlZiB7W0ZpbmQsIFJlcGxhY2U/XX0gRmluZEFuZFJlcGxhY2VUdXBsZVxuICogICBGaW5kIGFuZCByZXBsYWNlIGluIHR1cGxlIGZvcm0uXG4gKlxuICogQHR5cGVkZWYge1JlcGxhY2VGdW5jdGlvbiB8IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWR9IFJlcGxhY2VcbiAqICAgVGhpbmcgdG8gcmVwbGFjZSB3aXRoLlxuICpcbiAqIEBjYWxsYmFjayBSZXBsYWNlRnVuY3Rpb25cbiAqICAgQ2FsbGJhY2sgY2FsbGVkIHdoZW4gYSBzZWFyY2ggbWF0Y2hlcy5cbiAqIEBwYXJhbSB7Li4uYW55fSBwYXJhbWV0ZXJzXG4gKiAgIFRoZSBwYXJhbWV0ZXJzIGFyZSB0aGUgcmVzdWx0IG9mIGNvcnJlc3BvbmRpbmcgc2VhcmNoIGV4cHJlc3Npb246XG4gKlxuICogICAqIGB2YWx1ZWAgKGBzdHJpbmdgKSDigJQgd2hvbGUgbWF0Y2hcbiAqICAgKiBgLi4uY2FwdHVyZWAgKGBBcnJheTxzdHJpbmc+YCkg4oCUIG1hdGNoZXMgZnJvbSByZWdleCBjYXB0dXJlIGdyb3Vwc1xuICogICAqIGBtYXRjaGAgKGBSZWdFeHBNYXRjaE9iamVjdGApIOKAlCBpbmZvIG9uIHRoZSBtYXRjaFxuICogQHJldHVybnMge0FycmF5PFBocmFzaW5nQ29udGVudD4gfCBQaHJhc2luZ0NvbnRlbnQgfCBzdHJpbmcgfCBmYWxzZSB8IG51bGwgfCB1bmRlZmluZWR9XG4gKiAgIFRoaW5nIHRvIHJlcGxhY2Ugd2l0aC5cbiAqXG4gKiAgICogd2hlbiBgbnVsbGAsIGB1bmRlZmluZWRgLCBgJydgLCByZW1vdmUgdGhlIG1hdGNoXG4gKiAgICog4oCmb3Igd2hlbiBgZmFsc2VgLCBkbyBub3QgcmVwbGFjZSBhdCBhbGxcbiAqICAgKiDigKZvciB3aGVuIGBzdHJpbmdgLCByZXBsYWNlIHdpdGggYSB0ZXh0IG5vZGUgb2YgdGhhdCB2YWx1ZVxuICogICAqIOKApm9yIHdoZW4gYE5vZGVgIG9yIGBBcnJheTxOb2RlPmAsIHJlcGxhY2Ugd2l0aCB0aG9zZSBub2Rlc1xuICpcbiAqIEB0eXBlZGVmIHtbUmVnRXhwLCBSZXBsYWNlRnVuY3Rpb25dfSBQYWlyXG4gKiAgIE5vcm1hbGl6ZWQgZmluZCBhbmQgcmVwbGFjZS5cbiAqXG4gKiBAdHlwZWRlZiB7QXJyYXk8UGFpcj59IFBhaXJzXG4gKiAgIEFsbCBmaW5kIGFuZCByZXBsYWNlZC5cbiAqXG4gKiBAdHlwZWRlZiBPcHRpb25zXG4gKiAgIENvbmZpZ3VyYXRpb24uXG4gKiBAcHJvcGVydHkge1Rlc3QgfCBudWxsIHwgdW5kZWZpbmVkfSBbaWdub3JlXVxuICogICBUZXN0IGZvciB3aGljaCBub2RlcyB0byBpZ25vcmUgKG9wdGlvbmFsKS5cbiAqL1xuXG5pbXBvcnQgZXNjYXBlIGZyb20gJ2VzY2FwZS1zdHJpbmctcmVnZXhwJ1xuaW1wb3J0IHt2aXNpdFBhcmVudHN9IGZyb20gJ3VuaXN0LXV0aWwtdmlzaXQtcGFyZW50cydcbmltcG9ydCB7Y29udmVydH0gZnJvbSAndW5pc3QtdXRpbC1pcydcblxuLyoqXG4gKiBGaW5kIHBhdHRlcm5zIGluIGEgdHJlZSBhbmQgcmVwbGFjZSB0aGVtLlxuICpcbiAqIFRoZSBhbGdvcml0aG0gc2VhcmNoZXMgdGhlIHRyZWUgaW4gKnByZW9yZGVyKiBmb3IgY29tcGxldGUgdmFsdWVzIGluIGBUZXh0YFxuICogbm9kZXMuXG4gKiBQYXJ0aWFsIG1hdGNoZXMgYXJlIG5vdCBzdXBwb3J0ZWQuXG4gKlxuICogQHBhcmFtIHtOb2Rlc30gdHJlZVxuICogICBUcmVlIHRvIGNoYW5nZS5cbiAqIEBwYXJhbSB7RmluZEFuZFJlcGxhY2VMaXN0IHwgRmluZEFuZFJlcGxhY2VUdXBsZX0gbGlzdFxuICogICBQYXR0ZXJucyB0byBmaW5kLlxuICogQHBhcmFtIHtPcHRpb25zIHwgbnVsbCB8IHVuZGVmaW5lZH0gW29wdGlvbnNdXG4gKiAgIENvbmZpZ3VyYXRpb24gKHdoZW4gYGZpbmRgIGlzIG5vdCBgRmluZGApLlxuICogQHJldHVybnMge3VuZGVmaW5lZH1cbiAqICAgTm90aGluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmRBbmRSZXBsYWNlKHRyZWUsIGxpc3QsIG9wdGlvbnMpIHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBvcHRpb25zIHx8IHt9XG4gIGNvbnN0IGlnbm9yZWQgPSBjb252ZXJ0KHNldHRpbmdzLmlnbm9yZSB8fCBbXSlcbiAgY29uc3QgcGFpcnMgPSB0b1BhaXJzKGxpc3QpXG4gIGxldCBwYWlySW5kZXggPSAtMVxuXG4gIHdoaWxlICgrK3BhaXJJbmRleCA8IHBhaXJzLmxlbmd0aCkge1xuICAgIHZpc2l0UGFyZW50cyh0cmVlLCAndGV4dCcsIHZpc2l0b3IpXG4gIH1cblxuICAvKiogQHR5cGUge0J1aWxkVmlzaXRvcjxSb290LCAndGV4dCc+fSAqL1xuICBmdW5jdGlvbiB2aXNpdG9yKG5vZGUsIHBhcmVudHMpIHtcbiAgICBsZXQgaW5kZXggPSAtMVxuICAgIC8qKiBAdHlwZSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gKi9cbiAgICBsZXQgZ3JhbmRwYXJlbnRcblxuICAgIHdoaWxlICgrK2luZGV4IDwgcGFyZW50cy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IHBhcmVudCA9IHBhcmVudHNbaW5kZXhdXG4gICAgICAvKiogQHR5cGUge0FycmF5PE5vZGVzPiB8IHVuZGVmaW5lZH0gKi9cbiAgICAgIGNvbnN0IHNpYmxpbmdzID0gZ3JhbmRwYXJlbnQgPyBncmFuZHBhcmVudC5jaGlsZHJlbiA6IHVuZGVmaW5lZFxuXG4gICAgICBpZiAoXG4gICAgICAgIGlnbm9yZWQoXG4gICAgICAgICAgcGFyZW50LFxuICAgICAgICAgIHNpYmxpbmdzID8gc2libGluZ3MuaW5kZXhPZihwYXJlbnQpIDogdW5kZWZpbmVkLFxuICAgICAgICAgIGdyYW5kcGFyZW50XG4gICAgICAgIClcbiAgICAgICkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cblxuICAgICAgZ3JhbmRwYXJlbnQgPSBwYXJlbnRcbiAgICB9XG5cbiAgICBpZiAoZ3JhbmRwYXJlbnQpIHtcbiAgICAgIHJldHVybiBoYW5kbGVyKG5vZGUsIHBhcmVudHMpXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEhhbmRsZSBhIHRleHQgbm9kZSB3aGljaCBpcyBub3QgaW4gYW4gaWdub3JlZCBwYXJlbnQuXG4gICAqXG4gICAqIEBwYXJhbSB7VGV4dH0gbm9kZVxuICAgKiAgIFRleHQgbm9kZS5cbiAgICogQHBhcmFtIHtBcnJheTxQYXJlbnRzPn0gcGFyZW50c1xuICAgKiAgIFBhcmVudHMuXG4gICAqIEByZXR1cm5zIHtWaXNpdG9yUmVzdWx0fVxuICAgKiAgIFJlc3VsdC5cbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZXIobm9kZSwgcGFyZW50cykge1xuICAgIGNvbnN0IHBhcmVudCA9IHBhcmVudHNbcGFyZW50cy5sZW5ndGggLSAxXVxuICAgIGNvbnN0IGZpbmQgPSBwYWlyc1twYWlySW5kZXhdWzBdXG4gICAgY29uc3QgcmVwbGFjZSA9IHBhaXJzW3BhaXJJbmRleF1bMV1cbiAgICBsZXQgc3RhcnQgPSAwXG4gICAgLyoqIEB0eXBlIHtBcnJheTxOb2Rlcz59ICovXG4gICAgY29uc3Qgc2libGluZ3MgPSBwYXJlbnQuY2hpbGRyZW5cbiAgICBjb25zdCBpbmRleCA9IHNpYmxpbmdzLmluZGV4T2Yobm9kZSlcbiAgICBsZXQgY2hhbmdlID0gZmFsc2VcbiAgICAvKiogQHR5cGUge0FycmF5PFBocmFzaW5nQ29udGVudD59ICovXG4gICAgbGV0IG5vZGVzID0gW11cblxuICAgIGZpbmQubGFzdEluZGV4ID0gMFxuXG4gICAgbGV0IG1hdGNoID0gZmluZC5leGVjKG5vZGUudmFsdWUpXG5cbiAgICB3aGlsZSAobWF0Y2gpIHtcbiAgICAgIGNvbnN0IHBvc2l0aW9uID0gbWF0Y2guaW5kZXhcbiAgICAgIC8qKiBAdHlwZSB7UmVnRXhwTWF0Y2hPYmplY3R9ICovXG4gICAgICBjb25zdCBtYXRjaE9iamVjdCA9IHtcbiAgICAgICAgaW5kZXg6IG1hdGNoLmluZGV4LFxuICAgICAgICBpbnB1dDogbWF0Y2guaW5wdXQsXG4gICAgICAgIHN0YWNrOiBbLi4ucGFyZW50cywgbm9kZV1cbiAgICAgIH1cbiAgICAgIGxldCB2YWx1ZSA9IHJlcGxhY2UoLi4ubWF0Y2gsIG1hdGNoT2JqZWN0KVxuXG4gICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgICAgICB2YWx1ZSA9IHZhbHVlLmxlbmd0aCA+IDAgPyB7dHlwZTogJ3RleHQnLCB2YWx1ZX0gOiB1bmRlZmluZWRcbiAgICAgIH1cblxuICAgICAgLy8gSXQgd2FzbuKAmXQgYSBtYXRjaCBhZnRlciBhbGwuXG4gICAgICBpZiAodmFsdWUgPT09IGZhbHNlKSB7XG4gICAgICAgIC8vIEZhbHNlIGFjdHMgYXMgaWYgdGhlcmUgd2FzIG5vIG1hdGNoLlxuICAgICAgICAvLyBTbyB3ZSBuZWVkIHRvIHJlc2V0IGBsYXN0SW5kZXhgLCB3aGljaCBjdXJyZW50bHkgYmVpbmcgYXQgdGhlIGVuZCBvZlxuICAgICAgICAvLyB0aGUgY3VycmVudCBtYXRjaCwgdG8gdGhlIGJlZ2lubmluZy5cbiAgICAgICAgZmluZC5sYXN0SW5kZXggPSBwb3NpdGlvbiArIDFcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChzdGFydCAhPT0gcG9zaXRpb24pIHtcbiAgICAgICAgICBub2Rlcy5wdXNoKHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICAgIHZhbHVlOiBub2RlLnZhbHVlLnNsaWNlKHN0YXJ0LCBwb3NpdGlvbilcbiAgICAgICAgICB9KVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgICAgbm9kZXMucHVzaCguLi52YWx1ZSlcbiAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSkge1xuICAgICAgICAgIG5vZGVzLnB1c2godmFsdWUpXG4gICAgICAgIH1cblxuICAgICAgICBzdGFydCA9IHBvc2l0aW9uICsgbWF0Y2hbMF0ubGVuZ3RoXG4gICAgICAgIGNoYW5nZSA9IHRydWVcbiAgICAgIH1cblxuICAgICAgaWYgKCFmaW5kLmdsb2JhbCkge1xuICAgICAgICBicmVha1xuICAgICAgfVxuXG4gICAgICBtYXRjaCA9IGZpbmQuZXhlYyhub2RlLnZhbHVlKVxuICAgIH1cblxuICAgIGlmIChjaGFuZ2UpIHtcbiAgICAgIGlmIChzdGFydCA8IG5vZGUudmFsdWUubGVuZ3RoKSB7XG4gICAgICAgIG5vZGVzLnB1c2goe3R5cGU6ICd0ZXh0JywgdmFsdWU6IG5vZGUudmFsdWUuc2xpY2Uoc3RhcnQpfSlcbiAgICAgIH1cblxuICAgICAgcGFyZW50LmNoaWxkcmVuLnNwbGljZShpbmRleCwgMSwgLi4ubm9kZXMpXG4gICAgfSBlbHNlIHtcbiAgICAgIG5vZGVzID0gW25vZGVdXG4gICAgfVxuXG4gICAgcmV0dXJuIGluZGV4ICsgbm9kZXMubGVuZ3RoXG4gIH1cbn1cblxuLyoqXG4gKiBUdXJuIGEgdHVwbGUgb3IgYSBsaXN0IG9mIHR1cGxlcyBpbnRvIHBhaXJzLlxuICpcbiAqIEBwYXJhbSB7RmluZEFuZFJlcGxhY2VMaXN0IHwgRmluZEFuZFJlcGxhY2VUdXBsZX0gdHVwbGVPckxpc3RcbiAqICAgU2NoZW1hLlxuICogQHJldHVybnMge1BhaXJzfVxuICogICBDbGVhbiBwYWlycy5cbiAqL1xuZnVuY3Rpb24gdG9QYWlycyh0dXBsZU9yTGlzdCkge1xuICAvKiogQHR5cGUge1BhaXJzfSAqL1xuICBjb25zdCByZXN1bHQgPSBbXVxuXG4gIGlmICghQXJyYXkuaXNBcnJheSh0dXBsZU9yTGlzdCkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdFeHBlY3RlZCBmaW5kIGFuZCByZXBsYWNlIHR1cGxlIG9yIGxpc3Qgb2YgdHVwbGVzJylcbiAgfVxuXG4gIC8qKiBAdHlwZSB7RmluZEFuZFJlcGxhY2VMaXN0fSAqL1xuICAvLyBAdHMtZXhwZWN0LWVycm9yOiBjb3JyZWN0LlxuICBjb25zdCBsaXN0ID1cbiAgICAhdHVwbGVPckxpc3RbMF0gfHwgQXJyYXkuaXNBcnJheSh0dXBsZU9yTGlzdFswXSlcbiAgICAgID8gdHVwbGVPckxpc3RcbiAgICAgIDogW3R1cGxlT3JMaXN0XVxuXG4gIGxldCBpbmRleCA9IC0xXG5cbiAgd2hpbGUgKCsraW5kZXggPCBsaXN0Lmxlbmd0aCkge1xuICAgIGNvbnN0IHR1cGxlID0gbGlzdFtpbmRleF1cbiAgICByZXN1bHQucHVzaChbdG9FeHByZXNzaW9uKHR1cGxlWzBdKSwgdG9GdW5jdGlvbih0dXBsZVsxXSldKVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG4vKipcbiAqIFR1cm4gYSBmaW5kIGludG8gYW4gZXhwcmVzc2lvbi5cbiAqXG4gKiBAcGFyYW0ge0ZpbmR9IGZpbmRcbiAqICAgRmluZC5cbiAqIEByZXR1cm5zIHtSZWdFeHB9XG4gKiAgIEV4cHJlc3Npb24uXG4gKi9cbmZ1bmN0aW9uIHRvRXhwcmVzc2lvbihmaW5kKSB7XG4gIHJldHVybiB0eXBlb2YgZmluZCA9PT0gJ3N0cmluZycgPyBuZXcgUmVnRXhwKGVzY2FwZShmaW5kKSwgJ2cnKSA6IGZpbmRcbn1cblxuLyoqXG4gKiBUdXJuIGEgcmVwbGFjZSBpbnRvIGEgZnVuY3Rpb24uXG4gKlxuICogQHBhcmFtIHtSZXBsYWNlfSByZXBsYWNlXG4gKiAgIFJlcGxhY2UuXG4gKiBAcmV0dXJucyB7UmVwbGFjZUZ1bmN0aW9ufVxuICogICBGdW5jdGlvbi5cbiAqL1xuZnVuY3Rpb24gdG9GdW5jdGlvbihyZXBsYWNlKSB7XG4gIHJldHVybiB0eXBlb2YgcmVwbGFjZSA9PT0gJ2Z1bmN0aW9uJ1xuICAgID8gcmVwbGFjZVxuICAgIDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gcmVwbGFjZVxuICAgICAgfVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtSZWdFeHBNYXRjaE9iamVjdCwgUmVwbGFjZUZ1bmN0aW9ufSBmcm9tICdtZGFzdC11dGlsLWZpbmQtYW5kLXJlcGxhY2UnXG4gKiBAaW1wb3J0IHtDb21waWxlQ29udGV4dCwgRXh0ZW5zaW9uIGFzIEZyb21NYXJrZG93bkV4dGVuc2lvbiwgSGFuZGxlIGFzIEZyb21NYXJrZG93bkhhbmRsZSwgVHJhbnNmb3JtIGFzIEZyb21NYXJrZG93blRyYW5zZm9ybX0gZnJvbSAnbWRhc3QtdXRpbC1mcm9tLW1hcmtkb3duJ1xuICogQGltcG9ydCB7Q29uc3RydWN0TmFtZSwgT3B0aW9ucyBhcyBUb01hcmtkb3duRXh0ZW5zaW9ufSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7TGluaywgUGhyYXNpbmdDb250ZW50fSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge2Njb3VudH0gZnJvbSAnY2NvdW50J1xuaW1wb3J0IHtvayBhcyBhc3NlcnR9IGZyb20gJ2RldmxvcCdcbmltcG9ydCB7dW5pY29kZVB1bmN0dWF0aW9uLCB1bmljb2RlV2hpdGVzcGFjZX0gZnJvbSAnbWljcm9tYXJrLXV0aWwtY2hhcmFjdGVyJ1xuaW1wb3J0IHtmaW5kQW5kUmVwbGFjZX0gZnJvbSAnbWRhc3QtdXRpbC1maW5kLWFuZC1yZXBsYWNlJ1xuXG4vKiogQHR5cGUge0NvbnN0cnVjdE5hbWV9ICovXG5jb25zdCBpbkNvbnN0cnVjdCA9ICdwaHJhc2luZydcbi8qKiBAdHlwZSB7QXJyYXk8Q29uc3RydWN0TmFtZT59ICovXG5jb25zdCBub3RJbkNvbnN0cnVjdCA9IFsnYXV0b2xpbmsnLCAnbGluaycsICdpbWFnZScsICdsYWJlbCddXG5cbi8qKlxuICogQ3JlYXRlIGFuIGV4dGVuc2lvbiBmb3IgYG1kYXN0LXV0aWwtZnJvbS1tYXJrZG93bmAgdG8gZW5hYmxlIEdGTSBhdXRvbGlua1xuICogbGl0ZXJhbHMgaW4gbWFya2Rvd24uXG4gKlxuICogQHJldHVybnMge0Zyb21NYXJrZG93bkV4dGVuc2lvbn1cbiAqICAgRXh0ZW5zaW9uIGZvciBgbWRhc3QtdXRpbC10by1tYXJrZG93bmAgdG8gZW5hYmxlIEdGTSBhdXRvbGluayBsaXRlcmFscy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbUF1dG9saW5rTGl0ZXJhbEZyb21NYXJrZG93bigpIHtcbiAgcmV0dXJuIHtcbiAgICB0cmFuc2Zvcm1zOiBbdHJhbnNmb3JtR2ZtQXV0b2xpbmtMaXRlcmFsc10sXG4gICAgZW50ZXI6IHtcbiAgICAgIGxpdGVyYWxBdXRvbGluazogZW50ZXJMaXRlcmFsQXV0b2xpbmssXG4gICAgICBsaXRlcmFsQXV0b2xpbmtFbWFpbDogZW50ZXJMaXRlcmFsQXV0b2xpbmtWYWx1ZSxcbiAgICAgIGxpdGVyYWxBdXRvbGlua0h0dHA6IGVudGVyTGl0ZXJhbEF1dG9saW5rVmFsdWUsXG4gICAgICBsaXRlcmFsQXV0b2xpbmtXd3c6IGVudGVyTGl0ZXJhbEF1dG9saW5rVmFsdWVcbiAgICB9LFxuICAgIGV4aXQ6IHtcbiAgICAgIGxpdGVyYWxBdXRvbGluazogZXhpdExpdGVyYWxBdXRvbGluayxcbiAgICAgIGxpdGVyYWxBdXRvbGlua0VtYWlsOiBleGl0TGl0ZXJhbEF1dG9saW5rRW1haWwsXG4gICAgICBsaXRlcmFsQXV0b2xpbmtIdHRwOiBleGl0TGl0ZXJhbEF1dG9saW5rSHR0cCxcbiAgICAgIGxpdGVyYWxBdXRvbGlua1d3dzogZXhpdExpdGVyYWxBdXRvbGlua1d3d1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLXRvLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNIGF1dG9saW5rXG4gKiBsaXRlcmFscyBpbiBtYXJrZG93bi5cbiAqXG4gKiBAcmV0dXJucyB7VG9NYXJrZG93bkV4dGVuc2lvbn1cbiAqICAgRXh0ZW5zaW9uIGZvciBgbWRhc3QtdXRpbC10by1tYXJrZG93bmAgdG8gZW5hYmxlIEdGTSBhdXRvbGluayBsaXRlcmFscy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbUF1dG9saW5rTGl0ZXJhbFRvTWFya2Rvd24oKSB7XG4gIHJldHVybiB7XG4gICAgdW5zYWZlOiBbXG4gICAgICB7XG4gICAgICAgIGNoYXJhY3RlcjogJ0AnLFxuICAgICAgICBiZWZvcmU6ICdbK1xcXFwtLlxcXFx3XScsXG4gICAgICAgIGFmdGVyOiAnW1xcXFwtLlxcXFx3XScsXG4gICAgICAgIGluQ29uc3RydWN0LFxuICAgICAgICBub3RJbkNvbnN0cnVjdFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgY2hhcmFjdGVyOiAnLicsXG4gICAgICAgIGJlZm9yZTogJ1tXd10nLFxuICAgICAgICBhZnRlcjogJ1tcXFxcLS5cXFxcd10nLFxuICAgICAgICBpbkNvbnN0cnVjdCxcbiAgICAgICAgbm90SW5Db25zdHJ1Y3RcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGNoYXJhY3RlcjogJzonLFxuICAgICAgICBiZWZvcmU6ICdbcHNdJyxcbiAgICAgICAgYWZ0ZXI6ICdcXFxcLycsXG4gICAgICAgIGluQ29uc3RydWN0LFxuICAgICAgICBub3RJbkNvbnN0cnVjdFxuICAgICAgfVxuICAgIF1cbiAgfVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGVudGVyTGl0ZXJhbEF1dG9saW5rKHRva2VuKSB7XG4gIHRoaXMuZW50ZXIoe3R5cGU6ICdsaW5rJywgdGl0bGU6IG51bGwsIHVybDogJycsIGNoaWxkcmVuOiBbXX0sIHRva2VuKVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGVudGVyTGl0ZXJhbEF1dG9saW5rVmFsdWUodG9rZW4pIHtcbiAgdGhpcy5jb25maWcuZW50ZXIuYXV0b2xpbmtQcm90b2NvbC5jYWxsKHRoaXMsIHRva2VuKVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGV4aXRMaXRlcmFsQXV0b2xpbmtIdHRwKHRva2VuKSB7XG4gIHRoaXMuY29uZmlnLmV4aXQuYXV0b2xpbmtQcm90b2NvbC5jYWxsKHRoaXMsIHRva2VuKVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGV4aXRMaXRlcmFsQXV0b2xpbmtXd3codG9rZW4pIHtcbiAgdGhpcy5jb25maWcuZXhpdC5kYXRhLmNhbGwodGhpcywgdG9rZW4pXG4gIGNvbnN0IG5vZGUgPSB0aGlzLnN0YWNrW3RoaXMuc3RhY2subGVuZ3RoIC0gMV1cbiAgYXNzZXJ0KG5vZGUudHlwZSA9PT0gJ2xpbmsnKVxuICBub2RlLnVybCA9ICdodHRwOi8vJyArIHRoaXMuc2xpY2VTZXJpYWxpemUodG9rZW4pXG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZXhpdExpdGVyYWxBdXRvbGlua0VtYWlsKHRva2VuKSB7XG4gIHRoaXMuY29uZmlnLmV4aXQuYXV0b2xpbmtFbWFpbC5jYWxsKHRoaXMsIHRva2VuKVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGV4aXRMaXRlcmFsQXV0b2xpbmsodG9rZW4pIHtcbiAgdGhpcy5leGl0KHRva2VuKVxufVxuXG4vKiogQHR5cGUge0Zyb21NYXJrZG93blRyYW5zZm9ybX0gKi9cbmZ1bmN0aW9uIHRyYW5zZm9ybUdmbUF1dG9saW5rTGl0ZXJhbHModHJlZSkge1xuICBmaW5kQW5kUmVwbGFjZShcbiAgICB0cmVlLFxuICAgIFtcbiAgICAgIFsvKGh0dHBzPzpcXC9cXC98d3d3KD89XFwuKSkoWy0uXFx3XSspKFteIFxcdFxcclxcbl0qKS9naSwgZmluZFVybF0sXG4gICAgICBbLyg/PD1efFxcc3xcXHB7UH18XFxwe1N9KShbLS5cXHcrXSspQChbLVxcd10rKD86XFwuWy1cXHddKykrKS9ndSwgZmluZEVtYWlsXVxuICAgIF0sXG4gICAge2lnbm9yZTogWydsaW5rJywgJ2xpbmtSZWZlcmVuY2UnXX1cbiAgKVxufVxuXG4vKipcbiAqIEB0eXBlIHtSZXBsYWNlRnVuY3Rpb259XG4gKiBAcGFyYW0ge3N0cmluZ30gX1xuICogQHBhcmFtIHtzdHJpbmd9IHByb3RvY29sXG4gKiBAcGFyYW0ge3N0cmluZ30gZG9tYWluXG4gKiBAcGFyYW0ge3N0cmluZ30gcGF0aFxuICogQHBhcmFtIHtSZWdFeHBNYXRjaE9iamVjdH0gbWF0Y2hcbiAqIEByZXR1cm5zIHtBcnJheTxQaHJhc2luZ0NvbnRlbnQ+IHwgTGluayB8IGZhbHNlfVxuICovXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LXBhcmFtc1xuZnVuY3Rpb24gZmluZFVybChfLCBwcm90b2NvbCwgZG9tYWluLCBwYXRoLCBtYXRjaCkge1xuICBsZXQgcHJlZml4ID0gJydcblxuICAvLyBOb3QgYW4gZXhwZWN0ZWQgcHJldmlvdXMgY2hhcmFjdGVyLlxuICBpZiAoIXByZXZpb3VzKG1hdGNoKSkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgLy8gVHJlYXQgYHd3d2AgYXMgcGFydCBvZiB0aGUgZG9tYWluLlxuICBpZiAoL153L2kudGVzdChwcm90b2NvbCkpIHtcbiAgICBkb21haW4gPSBwcm90b2NvbCArIGRvbWFpblxuICAgIHByb3RvY29sID0gJydcbiAgICBwcmVmaXggPSAnaHR0cDovLydcbiAgfVxuXG4gIGlmICghaXNDb3JyZWN0RG9tYWluKGRvbWFpbikpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGNvbnN0IHBhcnRzID0gc3BsaXRVcmwoZG9tYWluICsgcGF0aClcblxuICBpZiAoIXBhcnRzWzBdKSByZXR1cm4gZmFsc2VcblxuICAvKiogQHR5cGUge0xpbmt9ICovXG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICB0eXBlOiAnbGluaycsXG4gICAgdGl0bGU6IG51bGwsXG4gICAgdXJsOiBwcmVmaXggKyBwcm90b2NvbCArIHBhcnRzWzBdLFxuICAgIGNoaWxkcmVuOiBbe3R5cGU6ICd0ZXh0JywgdmFsdWU6IHByb3RvY29sICsgcGFydHNbMF19XVxuICB9XG5cbiAgaWYgKHBhcnRzWzFdKSB7XG4gICAgcmV0dXJuIFtyZXN1bHQsIHt0eXBlOiAndGV4dCcsIHZhbHVlOiBwYXJ0c1sxXX1dXG4gIH1cblxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8qKlxuICogQHR5cGUge1JlcGxhY2VGdW5jdGlvbn1cbiAqIEBwYXJhbSB7c3RyaW5nfSBfXG4gKiBAcGFyYW0ge3N0cmluZ30gYXRleHRcbiAqIEBwYXJhbSB7c3RyaW5nfSBsYWJlbFxuICogQHBhcmFtIHtSZWdFeHBNYXRjaE9iamVjdH0gbWF0Y2hcbiAqIEByZXR1cm5zIHtMaW5rIHwgZmFsc2V9XG4gKi9cbmZ1bmN0aW9uIGZpbmRFbWFpbChfLCBhdGV4dCwgbGFiZWwsIG1hdGNoKSB7XG4gIGlmIChcbiAgICAvLyBOb3QgYW4gZXhwZWN0ZWQgcHJldmlvdXMgY2hhcmFjdGVyLlxuICAgICFwcmV2aW91cyhtYXRjaCwgdHJ1ZSkgfHxcbiAgICAvLyBMYWJlbCBlbmRzIGluIG5vdCBhbGxvd2VkIGNoYXJhY3Rlci5cbiAgICAvWy1cXGRfXSQvLnRlc3QobGFiZWwpXG4gICkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICB0eXBlOiAnbGluaycsXG4gICAgdGl0bGU6IG51bGwsXG4gICAgdXJsOiAnbWFpbHRvOicgKyBhdGV4dCArICdAJyArIGxhYmVsLFxuICAgIGNoaWxkcmVuOiBbe3R5cGU6ICd0ZXh0JywgdmFsdWU6IGF0ZXh0ICsgJ0AnICsgbGFiZWx9XVxuICB9XG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IGRvbWFpblxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIGlzQ29ycmVjdERvbWFpbihkb21haW4pIHtcbiAgY29uc3QgcGFydHMgPSBkb21haW4uc3BsaXQoJy4nKVxuXG4gIGlmIChcbiAgICBwYXJ0cy5sZW5ndGggPCAyIHx8XG4gICAgKHBhcnRzW3BhcnRzLmxlbmd0aCAtIDFdICYmXG4gICAgICAoL18vLnRlc3QocGFydHNbcGFydHMubGVuZ3RoIC0gMV0pIHx8XG4gICAgICAgICEvW2EtekEtWlxcZF0vLnRlc3QocGFydHNbcGFydHMubGVuZ3RoIC0gMV0pKSkgfHxcbiAgICAocGFydHNbcGFydHMubGVuZ3RoIC0gMl0gJiZcbiAgICAgICgvXy8udGVzdChwYXJ0c1twYXJ0cy5sZW5ndGggLSAyXSkgfHxcbiAgICAgICAgIS9bYS16QS1aXFxkXS8udGVzdChwYXJ0c1twYXJ0cy5sZW5ndGggLSAyXSkpKVxuICApIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIHJldHVybiB0cnVlXG59XG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICogQHJldHVybnMge1tzdHJpbmcsIHN0cmluZyB8IHVuZGVmaW5lZF19XG4gKi9cbmZ1bmN0aW9uIHNwbGl0VXJsKHVybCkge1xuICBjb25zdCB0cmFpbEV4ZWMgPSAvWyFcIiYnKSwuOjs8Pj9cXF19XSskLy5leGVjKHVybClcblxuICBpZiAoIXRyYWlsRXhlYykge1xuICAgIHJldHVybiBbdXJsLCB1bmRlZmluZWRdXG4gIH1cblxuICB1cmwgPSB1cmwuc2xpY2UoMCwgdHJhaWxFeGVjLmluZGV4KVxuXG4gIGxldCB0cmFpbCA9IHRyYWlsRXhlY1swXVxuICBsZXQgY2xvc2luZ1BhcmVuSW5kZXggPSB0cmFpbC5pbmRleE9mKCcpJylcbiAgY29uc3Qgb3BlbmluZ1BhcmVucyA9IGNjb3VudCh1cmwsICcoJylcbiAgbGV0IGNsb3NpbmdQYXJlbnMgPSBjY291bnQodXJsLCAnKScpXG5cbiAgd2hpbGUgKGNsb3NpbmdQYXJlbkluZGV4ICE9PSAtMSAmJiBvcGVuaW5nUGFyZW5zID4gY2xvc2luZ1BhcmVucykge1xuICAgIHVybCArPSB0cmFpbC5zbGljZSgwLCBjbG9zaW5nUGFyZW5JbmRleCArIDEpXG4gICAgdHJhaWwgPSB0cmFpbC5zbGljZShjbG9zaW5nUGFyZW5JbmRleCArIDEpXG4gICAgY2xvc2luZ1BhcmVuSW5kZXggPSB0cmFpbC5pbmRleE9mKCcpJylcbiAgICBjbG9zaW5nUGFyZW5zKytcbiAgfVxuXG4gIHJldHVybiBbdXJsLCB0cmFpbF1cbn1cblxuLyoqXG4gKiBAcGFyYW0ge1JlZ0V4cE1hdGNoT2JqZWN0fSBtYXRjaFxuICogQHBhcmFtIHtib29sZWFuIHwgbnVsbCB8IHVuZGVmaW5lZH0gW2VtYWlsPWZhbHNlXVxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIHByZXZpb3VzKG1hdGNoLCBlbWFpbCkge1xuICBjb25zdCBjb2RlID0gbWF0Y2guaW5wdXQuY2hhckNvZGVBdChtYXRjaC5pbmRleCAtIDEpXG5cbiAgcmV0dXJuIChcbiAgICAobWF0Y2guaW5kZXggPT09IDAgfHxcbiAgICAgIHVuaWNvZGVXaGl0ZXNwYWNlKGNvZGUpIHx8XG4gICAgICB1bmljb2RlUHVuY3R1YXRpb24oY29kZSkpICYmXG4gICAgLy8gSWYgaXTigJlzIGFuIGVtYWlsLCB0aGUgcHJldmlvdXMgY2hhcmFjdGVyIHNob3VsZCBub3QgYmUgYSBzbGFzaC5cbiAgICAoIWVtYWlsIHx8IGNvZGUgIT09IDQ3KVxuICApXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge1xuICogICBDb21waWxlQ29udGV4dCxcbiAqICAgRXh0ZW5zaW9uIGFzIEZyb21NYXJrZG93bkV4dGVuc2lvbixcbiAqICAgSGFuZGxlIGFzIEZyb21NYXJrZG93bkhhbmRsZVxuICogfSBmcm9tICdtZGFzdC11dGlsLWZyb20tbWFya2Rvd24nXG4gKiBAaW1wb3J0IHtUb01hcmtkb3duT3B0aW9uc30gZnJvbSAnbWRhc3QtdXRpbC1nZm0tZm9vdG5vdGUnXG4gKiBAaW1wb3J0IHtcbiAqICAgSGFuZGxlIGFzIFRvTWFya2Rvd25IYW5kbGUsXG4gKiAgIE1hcCxcbiAqICAgT3B0aW9ucyBhcyBUb01hcmtkb3duRXh0ZW5zaW9uXG4gKiB9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKiBAaW1wb3J0IHtGb290bm90ZURlZmluaXRpb24sIEZvb3Rub3RlUmVmZXJlbmNlfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge29rIGFzIGFzc2VydH0gZnJvbSAnZGV2bG9wJ1xuaW1wb3J0IHtub3JtYWxpemVJZGVudGlmaWVyfSBmcm9tICdtaWNyb21hcmstdXRpbC1ub3JtYWxpemUtaWRlbnRpZmllcidcblxuZm9vdG5vdGVSZWZlcmVuY2UucGVlayA9IGZvb3Rub3RlUmVmZXJlbmNlUGVla1xuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGVudGVyRm9vdG5vdGVDYWxsU3RyaW5nKCkge1xuICB0aGlzLmJ1ZmZlcigpXG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZW50ZXJGb290bm90ZUNhbGwodG9rZW4pIHtcbiAgdGhpcy5lbnRlcih7dHlwZTogJ2Zvb3Rub3RlUmVmZXJlbmNlJywgaWRlbnRpZmllcjogJycsIGxhYmVsOiAnJ30sIHRva2VuKVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGVudGVyRm9vdG5vdGVEZWZpbml0aW9uTGFiZWxTdHJpbmcoKSB7XG4gIHRoaXMuYnVmZmVyKClcbn1cblxuLyoqXG4gKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gKiBAdHlwZSB7RnJvbU1hcmtkb3duSGFuZGxlfVxuICovXG5mdW5jdGlvbiBlbnRlckZvb3Rub3RlRGVmaW5pdGlvbih0b2tlbikge1xuICB0aGlzLmVudGVyKFxuICAgIHt0eXBlOiAnZm9vdG5vdGVEZWZpbml0aW9uJywgaWRlbnRpZmllcjogJycsIGxhYmVsOiAnJywgY2hpbGRyZW46IFtdfSxcbiAgICB0b2tlblxuICApXG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZXhpdEZvb3Rub3RlQ2FsbFN0cmluZyh0b2tlbikge1xuICBjb25zdCBsYWJlbCA9IHRoaXMucmVzdW1lKClcbiAgY29uc3Qgbm9kZSA9IHRoaXMuc3RhY2tbdGhpcy5zdGFjay5sZW5ndGggLSAxXVxuICBhc3NlcnQobm9kZS50eXBlID09PSAnZm9vdG5vdGVSZWZlcmVuY2UnKVxuICBub2RlLmlkZW50aWZpZXIgPSBub3JtYWxpemVJZGVudGlmaWVyKFxuICAgIHRoaXMuc2xpY2VTZXJpYWxpemUodG9rZW4pXG4gICkudG9Mb3dlckNhc2UoKVxuICBub2RlLmxhYmVsID0gbGFiZWxcbn1cblxuLyoqXG4gKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gKiBAdHlwZSB7RnJvbU1hcmtkb3duSGFuZGxlfVxuICovXG5mdW5jdGlvbiBleGl0Rm9vdG5vdGVDYWxsKHRva2VuKSB7XG4gIHRoaXMuZXhpdCh0b2tlbilcbn1cblxuLyoqXG4gKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gKiBAdHlwZSB7RnJvbU1hcmtkb3duSGFuZGxlfVxuICovXG5mdW5jdGlvbiBleGl0Rm9vdG5vdGVEZWZpbml0aW9uTGFiZWxTdHJpbmcodG9rZW4pIHtcbiAgY29uc3QgbGFiZWwgPSB0aGlzLnJlc3VtZSgpXG4gIGNvbnN0IG5vZGUgPSB0aGlzLnN0YWNrW3RoaXMuc3RhY2subGVuZ3RoIC0gMV1cbiAgYXNzZXJ0KG5vZGUudHlwZSA9PT0gJ2Zvb3Rub3RlRGVmaW5pdGlvbicpXG4gIG5vZGUuaWRlbnRpZmllciA9IG5vcm1hbGl6ZUlkZW50aWZpZXIoXG4gICAgdGhpcy5zbGljZVNlcmlhbGl6ZSh0b2tlbilcbiAgKS50b0xvd2VyQ2FzZSgpXG4gIG5vZGUubGFiZWwgPSBsYWJlbFxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGV4aXRGb290bm90ZURlZmluaXRpb24odG9rZW4pIHtcbiAgdGhpcy5leGl0KHRva2VuKVxufVxuXG4vKiogQHR5cGUge1RvTWFya2Rvd25IYW5kbGV9ICovXG5mdW5jdGlvbiBmb290bm90ZVJlZmVyZW5jZVBlZWsoKSB7XG4gIHJldHVybiAnWydcbn1cblxuLyoqXG4gKiBAdHlwZSB7VG9NYXJrZG93bkhhbmRsZX1cbiAqIEBwYXJhbSB7Rm9vdG5vdGVSZWZlcmVuY2V9IG5vZGVcbiAqL1xuZnVuY3Rpb24gZm9vdG5vdGVSZWZlcmVuY2Uobm9kZSwgXywgc3RhdGUsIGluZm8pIHtcbiAgY29uc3QgdHJhY2tlciA9IHN0YXRlLmNyZWF0ZVRyYWNrZXIoaW5mbylcbiAgbGV0IHZhbHVlID0gdHJhY2tlci5tb3ZlKCdbXicpXG4gIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignZm9vdG5vdGVSZWZlcmVuY2UnKVxuICBjb25zdCBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ3JlZmVyZW5jZScpXG4gIHZhbHVlICs9IHRyYWNrZXIubW92ZShcbiAgICBzdGF0ZS5zYWZlKHN0YXRlLmFzc29jaWF0aW9uSWQobm9kZSksIHthZnRlcjogJ10nLCBiZWZvcmU6IHZhbHVlfSlcbiAgKVxuICBzdWJleGl0KClcbiAgZXhpdCgpXG4gIHZhbHVlICs9IHRyYWNrZXIubW92ZSgnXScpXG4gIHJldHVybiB2YWx1ZVxufVxuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLWZyb20tbWFya2Rvd25gIHRvIGVuYWJsZSBHRk0gZm9vdG5vdGVzXG4gKiBpbiBtYXJrZG93bi5cbiAqXG4gKiBAcmV0dXJucyB7RnJvbU1hcmtkb3duRXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLWZyb20tbWFya2Rvd25gLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2ZtRm9vdG5vdGVGcm9tTWFya2Rvd24oKSB7XG4gIHJldHVybiB7XG4gICAgZW50ZXI6IHtcbiAgICAgIGdmbUZvb3Rub3RlQ2FsbFN0cmluZzogZW50ZXJGb290bm90ZUNhbGxTdHJpbmcsXG4gICAgICBnZm1Gb290bm90ZUNhbGw6IGVudGVyRm9vdG5vdGVDYWxsLFxuICAgICAgZ2ZtRm9vdG5vdGVEZWZpbml0aW9uTGFiZWxTdHJpbmc6IGVudGVyRm9vdG5vdGVEZWZpbml0aW9uTGFiZWxTdHJpbmcsXG4gICAgICBnZm1Gb290bm90ZURlZmluaXRpb246IGVudGVyRm9vdG5vdGVEZWZpbml0aW9uXG4gICAgfSxcbiAgICBleGl0OiB7XG4gICAgICBnZm1Gb290bm90ZUNhbGxTdHJpbmc6IGV4aXRGb290bm90ZUNhbGxTdHJpbmcsXG4gICAgICBnZm1Gb290bm90ZUNhbGw6IGV4aXRGb290bm90ZUNhbGwsXG4gICAgICBnZm1Gb290bm90ZURlZmluaXRpb25MYWJlbFN0cmluZzogZXhpdEZvb3Rub3RlRGVmaW5pdGlvbkxhYmVsU3RyaW5nLFxuICAgICAgZ2ZtRm9vdG5vdGVEZWZpbml0aW9uOiBleGl0Rm9vdG5vdGVEZWZpbml0aW9uXG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlIGFuIGV4dGVuc2lvbiBmb3IgYG1kYXN0LXV0aWwtdG8tbWFya2Rvd25gIHRvIGVuYWJsZSBHRk0gZm9vdG5vdGVzXG4gKiBpbiBtYXJrZG93bi5cbiAqXG4gKiBAcGFyYW0ge1RvTWFya2Rvd25PcHRpb25zIHwgbnVsbCB8IHVuZGVmaW5lZH0gW29wdGlvbnNdXG4gKiAgIENvbmZpZ3VyYXRpb24gKG9wdGlvbmFsKS5cbiAqIEByZXR1cm5zIHtUb01hcmtkb3duRXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLXRvLW1hcmtkb3duYC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbUZvb3Rub3RlVG9NYXJrZG93bihvcHRpb25zKSB7XG4gIC8vIFRvIGRvOiBuZXh0IG1ham9yOiBjaGFuZ2UgZGVmYXVsdC5cbiAgbGV0IGZpcnN0TGluZUJsYW5rID0gZmFsc2VcblxuICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLmZpcnN0TGluZUJsYW5rKSB7XG4gICAgZmlyc3RMaW5lQmxhbmsgPSB0cnVlXG4gIH1cblxuICByZXR1cm4ge1xuICAgIGhhbmRsZXJzOiB7Zm9vdG5vdGVEZWZpbml0aW9uLCBmb290bm90ZVJlZmVyZW5jZX0sXG4gICAgLy8gVGhpcyBpcyBvbiBieSBkZWZhdWx0IGFscmVhZHkuXG4gICAgdW5zYWZlOiBbe2NoYXJhY3RlcjogJ1snLCBpbkNvbnN0cnVjdDogWydsYWJlbCcsICdwaHJhc2luZycsICdyZWZlcmVuY2UnXX1dXG4gIH1cblxuICAvKipcbiAgICogQHR5cGUge1RvTWFya2Rvd25IYW5kbGV9XG4gICAqIEBwYXJhbSB7Rm9vdG5vdGVEZWZpbml0aW9ufSBub2RlXG4gICAqL1xuICBmdW5jdGlvbiBmb290bm90ZURlZmluaXRpb24obm9kZSwgXywgc3RhdGUsIGluZm8pIHtcbiAgICBjb25zdCB0cmFja2VyID0gc3RhdGUuY3JlYXRlVHJhY2tlcihpbmZvKVxuICAgIGxldCB2YWx1ZSA9IHRyYWNrZXIubW92ZSgnW14nKVxuICAgIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignZm9vdG5vdGVEZWZpbml0aW9uJylcbiAgICBjb25zdCBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ2xhYmVsJylcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgICBzdGF0ZS5zYWZlKHN0YXRlLmFzc29jaWF0aW9uSWQobm9kZSksIHtiZWZvcmU6IHZhbHVlLCBhZnRlcjogJ10nfSlcbiAgICApXG4gICAgc3ViZXhpdCgpXG5cbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJ106JylcblxuICAgIGlmIChub2RlLmNoaWxkcmVuICYmIG5vZGUuY2hpbGRyZW4ubGVuZ3RoID4gMCkge1xuICAgICAgdHJhY2tlci5zaGlmdCg0KVxuXG4gICAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgICAgIChmaXJzdExpbmVCbGFuayA/ICdcXG4nIDogJyAnKSArXG4gICAgICAgICAgc3RhdGUuaW5kZW50TGluZXMoXG4gICAgICAgICAgICBzdGF0ZS5jb250YWluZXJGbG93KG5vZGUsIHRyYWNrZXIuY3VycmVudCgpKSxcbiAgICAgICAgICAgIGZpcnN0TGluZUJsYW5rID8gbWFwQWxsIDogbWFwRXhjZXB0Rmlyc3RcbiAgICAgICAgICApXG4gICAgICApXG4gICAgfVxuXG4gICAgZXhpdCgpXG5cbiAgICByZXR1cm4gdmFsdWVcbiAgfVxufVxuXG4vKiogQHR5cGUge01hcH0gKi9cbmZ1bmN0aW9uIG1hcEV4Y2VwdEZpcnN0KGxpbmUsIGluZGV4LCBibGFuaykge1xuICByZXR1cm4gaW5kZXggPT09IDAgPyBsaW5lIDogbWFwQWxsKGxpbmUsIGluZGV4LCBibGFuaylcbn1cblxuLyoqIEB0eXBlIHtNYXB9ICovXG5mdW5jdGlvbiBtYXBBbGwobGluZSwgaW5kZXgsIGJsYW5rKSB7XG4gIHJldHVybiAoYmxhbmsgPyAnJyA6ICcgICAgJykgKyBsaW5lXG59XG4iLCIvKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0JykuRGVsZXRlfSBEZWxldGVcbiAqXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLWZyb20tbWFya2Rvd24nKS5Db21waWxlQ29udGV4dH0gQ29tcGlsZUNvbnRleHRcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0LXV0aWwtZnJvbS1tYXJrZG93bicpLkV4dGVuc2lvbn0gRnJvbU1hcmtkb3duRXh0ZW5zaW9uXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLWZyb20tbWFya2Rvd24nKS5IYW5kbGV9IEZyb21NYXJrZG93bkhhbmRsZVxuICpcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nKS5Db25zdHJ1Y3ROYW1lfSBDb25zdHJ1Y3ROYW1lXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLXRvLW1hcmtkb3duJykuSGFuZGxlfSBUb01hcmtkb3duSGFuZGxlXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLXRvLW1hcmtkb3duJykuT3B0aW9uc30gVG9NYXJrZG93bkV4dGVuc2lvblxuICovXG5cbi8qKlxuICogTGlzdCBvZiBjb25zdHJ1Y3RzIHRoYXQgb2NjdXIgaW4gcGhyYXNpbmcgKHBhcmFncmFwaHMsIGhlYWRpbmdzKSwgYnV0IGNhbm5vdFxuICogY29udGFpbiBzdHJpa2V0aHJvdWdoLlxuICogU28gdGhleSBzb3J0IG9mIGNhbmNlbCBlYWNoIG90aGVyIG91dC5cbiAqIE5vdGU6IGNvdWxkIHVzZSBhIGJldHRlciBuYW1lLlxuICpcbiAqIE5vdGU6IGtlZXAgaW4gc3luYyB3aXRoOiA8aHR0cHM6Ly9naXRodWIuY29tL3N5bnRheC10cmVlL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vYmxvYi84Y2U4ZGJmL2xpYi91bnNhZmUuanMjTDE0PlxuICpcbiAqIEB0eXBlIHtBcnJheTxDb25zdHJ1Y3ROYW1lPn1cbiAqL1xuY29uc3QgY29uc3RydWN0c1dpdGhvdXRTdHJpa2V0aHJvdWdoID0gW1xuICAnYXV0b2xpbmsnLFxuICAnZGVzdGluYXRpb25MaXRlcmFsJyxcbiAgJ2Rlc3RpbmF0aW9uUmF3JyxcbiAgJ3JlZmVyZW5jZScsXG4gICd0aXRsZVF1b3RlJyxcbiAgJ3RpdGxlQXBvc3Ryb3BoZSdcbl1cblxuaGFuZGxlRGVsZXRlLnBlZWsgPSBwZWVrRGVsZXRlXG5cbi8qKlxuICogQ3JlYXRlIGFuIGV4dGVuc2lvbiBmb3IgYG1kYXN0LXV0aWwtZnJvbS1tYXJrZG93bmAgdG8gZW5hYmxlIEdGTVxuICogc3RyaWtldGhyb3VnaCBpbiBtYXJrZG93bi5cbiAqXG4gKiBAcmV0dXJucyB7RnJvbU1hcmtkb3duRXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLWZyb20tbWFya2Rvd25gIHRvIGVuYWJsZSBHRk0gc3RyaWtldGhyb3VnaC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbVN0cmlrZXRocm91Z2hGcm9tTWFya2Rvd24oKSB7XG4gIHJldHVybiB7XG4gICAgY2FuQ29udGFpbkVvbHM6IFsnZGVsZXRlJ10sXG4gICAgZW50ZXI6IHtzdHJpa2V0aHJvdWdoOiBlbnRlclN0cmlrZXRocm91Z2h9LFxuICAgIGV4aXQ6IHtzdHJpa2V0aHJvdWdoOiBleGl0U3RyaWtldGhyb3VnaH1cbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLXRvLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNXG4gKiBzdHJpa2V0aHJvdWdoIGluIG1hcmtkb3duLlxuICpcbiAqIEByZXR1cm5zIHtUb01hcmtkb3duRXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLXRvLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNIHN0cmlrZXRocm91Z2guXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZm1TdHJpa2V0aHJvdWdoVG9NYXJrZG93bigpIHtcbiAgcmV0dXJuIHtcbiAgICB1bnNhZmU6IFtcbiAgICAgIHtcbiAgICAgICAgY2hhcmFjdGVyOiAnficsXG4gICAgICAgIGluQ29uc3RydWN0OiAncGhyYXNpbmcnLFxuICAgICAgICBub3RJbkNvbnN0cnVjdDogY29uc3RydWN0c1dpdGhvdXRTdHJpa2V0aHJvdWdoXG4gICAgICB9XG4gICAgXSxcbiAgICBoYW5kbGVyczoge2RlbGV0ZTogaGFuZGxlRGVsZXRlfVxuICB9XG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZW50ZXJTdHJpa2V0aHJvdWdoKHRva2VuKSB7XG4gIHRoaXMuZW50ZXIoe3R5cGU6ICdkZWxldGUnLCBjaGlsZHJlbjogW119LCB0b2tlbilcbn1cblxuLyoqXG4gKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gKiBAdHlwZSB7RnJvbU1hcmtkb3duSGFuZGxlfVxuICovXG5mdW5jdGlvbiBleGl0U3RyaWtldGhyb3VnaCh0b2tlbikge1xuICB0aGlzLmV4aXQodG9rZW4pXG59XG5cbi8qKlxuICogQHR5cGUge1RvTWFya2Rvd25IYW5kbGV9XG4gKiBAcGFyYW0ge0RlbGV0ZX0gbm9kZVxuICovXG5mdW5jdGlvbiBoYW5kbGVEZWxldGUobm9kZSwgXywgc3RhdGUsIGluZm8pIHtcbiAgY29uc3QgdHJhY2tlciA9IHN0YXRlLmNyZWF0ZVRyYWNrZXIoaW5mbylcbiAgY29uc3QgZXhpdCA9IHN0YXRlLmVudGVyKCdzdHJpa2V0aHJvdWdoJylcbiAgbGV0IHZhbHVlID0gdHJhY2tlci5tb3ZlKCd+ficpXG4gIHZhbHVlICs9IHN0YXRlLmNvbnRhaW5lclBocmFzaW5nKG5vZGUsIHtcbiAgICAuLi50cmFja2VyLmN1cnJlbnQoKSxcbiAgICBiZWZvcmU6IHZhbHVlLFxuICAgIGFmdGVyOiAnfidcbiAgfSlcbiAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCd+ficpXG4gIGV4aXQoKVxuICByZXR1cm4gdmFsdWVcbn1cblxuLyoqIEB0eXBlIHtUb01hcmtkb3duSGFuZGxlfSAqL1xuZnVuY3Rpb24gcGVla0RlbGV0ZSgpIHtcbiAgcmV0dXJuICd+J1xufVxuIiwiLy8gVG8gZG86IG5leHQgbWFqb3I6IHJlbW92ZS5cbi8qKlxuICogQHR5cGVkZWYge09wdGlvbnN9IE1hcmtkb3duVGFibGVPcHRpb25zXG4gKiAgIENvbmZpZ3VyYXRpb24uXG4gKi9cblxuLyoqXG4gKiBAdHlwZWRlZiBPcHRpb25zXG4gKiAgIENvbmZpZ3VyYXRpb24uXG4gKiBAcHJvcGVydHkge2Jvb2xlYW4gfCBudWxsIHwgdW5kZWZpbmVkfSBbYWxpZ25EZWxpbWl0ZXJzPXRydWVdXG4gKiAgIFdoZXRoZXIgdG8gYWxpZ24gdGhlIGRlbGltaXRlcnMgKGRlZmF1bHQ6IGB0cnVlYCk7XG4gKiAgIHRoZXkgYXJlIGFsaWduZWQgYnkgZGVmYXVsdDpcbiAqXG4gKiAgIGBgYG1hcmtkb3duXG4gKiAgIHwgQWxwaGEgfCBCICAgICB8XG4gKiAgIHwgLS0tLS0gfCAtLS0tLSB8XG4gKiAgIHwgQyAgICAgfCBEZWx0YSB8XG4gKiAgIGBgYFxuICpcbiAqICAgUGFzcyBgZmFsc2VgIHRvIG1ha2UgdGhlbSBzdGFnZ2VyZWQ6XG4gKlxuICogICBgYGBtYXJrZG93blxuICogICB8IEFscGhhIHwgQiB8XG4gKiAgIHwgLSB8IC0gfFxuICogICB8IEMgfCBEZWx0YSB8XG4gKiAgIGBgYFxuICogQHByb3BlcnR5IHtSZWFkb25seUFycmF5PHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ+IHwgc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gW2FsaWduXVxuICogICBIb3cgdG8gYWxpZ24gY29sdW1ucyAoZGVmYXVsdDogYCcnYCk7XG4gKiAgIG9uZSBzdHlsZSBmb3IgYWxsIGNvbHVtbnMgb3Igc3R5bGVzIGZvciB0aGVpciByZXNwZWN0aXZlIGNvbHVtbnM7XG4gKiAgIGVhY2ggc3R5bGUgaXMgZWl0aGVyIGAnbCdgIChsZWZ0KSwgYCdyJ2AgKHJpZ2h0KSwgb3IgYCdjJ2AgKGNlbnRlcik7XG4gKiAgIG90aGVyIHZhbHVlcyBhcmUgdHJlYXRlZCBhcyBgJydgLCB3aGljaCBkb2VzbuKAmXQgcGxhY2UgdGhlIGNvbG9uIGluIHRoZVxuICogICBhbGlnbm1lbnQgcm93IGJ1dCBkb2VzIGFsaWduIGxlZnQ7XG4gKiAgICpvbmx5IHRoZSBsb3dlcmNhc2VkIGZpcnN0IGNoYXJhY3RlciBpcyB1c2VkLCBzbyBgUmlnaHRgIGlzIGZpbmUuKlxuICogQHByb3BlcnR5IHtib29sZWFuIHwgbnVsbCB8IHVuZGVmaW5lZH0gW2RlbGltaXRlckVuZD10cnVlXVxuICogICBXaGV0aGVyIHRvIGVuZCBlYWNoIHJvdyB3aXRoIHRoZSBkZWxpbWl0ZXIgKGRlZmF1bHQ6IGB0cnVlYCkuXG4gKlxuICogICA+IPCfkYkgKipOb3RlKio6IHBsZWFzZSBkb27igJl0IHVzZSB0aGlzOiBpdCBjb3VsZCBjcmVhdGUgZnJhZ2lsZSBzdHJ1Y3R1cmVzXG4gKiAgID4gdGhhdCBhcmVu4oCZdCB1bmRlcnN0YW5kYWJsZSB0byBzb21lIG1hcmtkb3duIHBhcnNlcnMuXG4gKlxuICogICBXaGVuIGB0cnVlYCwgdGhlcmUgYXJlIGVuZGluZyBkZWxpbWl0ZXJzOlxuICpcbiAqICAgYGBgbWFya2Rvd25cbiAqICAgfCBBbHBoYSB8IEIgICAgIHxcbiAqICAgfCAtLS0tLSB8IC0tLS0tIHxcbiAqICAgfCBDICAgICB8IERlbHRhIHxcbiAqICAgYGBgXG4gKlxuICogICBXaGVuIGBmYWxzZWAsIHRoZXJlIGFyZSBubyBlbmRpbmcgZGVsaW1pdGVyczpcbiAqXG4gKiAgIGBgYG1hcmtkb3duXG4gKiAgIHwgQWxwaGEgfCBCXG4gKiAgIHwgLS0tLS0gfCAtLS0tLVxuICogICB8IEMgICAgIHwgRGVsdGFcbiAqICAgYGBgXG4gKiBAcHJvcGVydHkge2Jvb2xlYW4gfCBudWxsIHwgdW5kZWZpbmVkfSBbZGVsaW1pdGVyU3RhcnQ9dHJ1ZV1cbiAqICAgV2hldGhlciB0byBiZWdpbiBlYWNoIHJvdyB3aXRoIHRoZSBkZWxpbWl0ZXIgKGRlZmF1bHQ6IGB0cnVlYCkuXG4gKlxuICogICA+IPCfkYkgKipOb3RlKio6IHBsZWFzZSBkb27igJl0IHVzZSB0aGlzOiBpdCBjb3VsZCBjcmVhdGUgZnJhZ2lsZSBzdHJ1Y3R1cmVzXG4gKiAgID4gdGhhdCBhcmVu4oCZdCB1bmRlcnN0YW5kYWJsZSB0byBzb21lIG1hcmtkb3duIHBhcnNlcnMuXG4gKlxuICogICBXaGVuIGB0cnVlYCwgdGhlcmUgYXJlIHN0YXJ0aW5nIGRlbGltaXRlcnM6XG4gKlxuICogICBgYGBtYXJrZG93blxuICogICB8IEFscGhhIHwgQiAgICAgfFxuICogICB8IC0tLS0tIHwgLS0tLS0gfFxuICogICB8IEMgICAgIHwgRGVsdGEgfFxuICogICBgYGBcbiAqXG4gKiAgIFdoZW4gYGZhbHNlYCwgdGhlcmUgYXJlIG5vIHN0YXJ0aW5nIGRlbGltaXRlcnM6XG4gKlxuICogICBgYGBtYXJrZG93blxuICogICBBbHBoYSB8IEIgICAgIHxcbiAqICAgLS0tLS0gfCAtLS0tLSB8XG4gKiAgIEMgICAgIHwgRGVsdGEgfFxuICogICBgYGBcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbiB8IG51bGwgfCB1bmRlZmluZWR9IFtwYWRkaW5nPXRydWVdXG4gKiAgIFdoZXRoZXIgdG8gYWRkIGEgc3BhY2Ugb2YgcGFkZGluZyBiZXR3ZWVuIGRlbGltaXRlcnMgYW5kIGNlbGxzXG4gKiAgIChkZWZhdWx0OiBgdHJ1ZWApLlxuICpcbiAqICAgV2hlbiBgdHJ1ZWAsIHRoZXJlIGlzIHBhZGRpbmc6XG4gKlxuICogICBgYGBtYXJrZG93blxuICogICB8IEFscGhhIHwgQiAgICAgfFxuICogICB8IC0tLS0tIHwgLS0tLS0gfFxuICogICB8IEMgICAgIHwgRGVsdGEgfFxuICogICBgYGBcbiAqXG4gKiAgIFdoZW4gYGZhbHNlYCwgdGhlcmUgaXMgbm8gcGFkZGluZzpcbiAqXG4gKiAgIGBgYG1hcmtkb3duXG4gKiAgIHxBbHBoYXxCICAgIHxcbiAqICAgfC0tLS0tfC0tLS0tfFxuICogICB8QyAgICB8RGVsdGF8XG4gKiAgIGBgYFxuICogQHByb3BlcnR5IHsoKHZhbHVlOiBzdHJpbmcpID0+IG51bWJlcikgfCBudWxsIHwgdW5kZWZpbmVkfSBbc3RyaW5nTGVuZ3RoXVxuICogICBGdW5jdGlvbiB0byBkZXRlY3QgdGhlIGxlbmd0aCBvZiB0YWJsZSBjZWxsIGNvbnRlbnQgKG9wdGlvbmFsKTtcbiAqICAgdGhpcyBpcyB1c2VkIHdoZW4gYWxpZ25pbmcgdGhlIGRlbGltaXRlcnMgKGB8YCkgYmV0d2VlbiB0YWJsZSBjZWxscztcbiAqICAgZnVsbC13aWR0aCBjaGFyYWN0ZXJzIGFuZCBlbW9qaSBtZXNzIHVwIGRlbGltaXRlciBhbGlnbm1lbnQgd2hlbiB2aWV3aW5nXG4gKiAgIHRoZSBtYXJrZG93biBzb3VyY2U7XG4gKiAgIHRvIGZpeCB0aGlzLCB5b3UgY2FuIHBhc3MgdGhpcyBmdW5jdGlvbixcbiAqICAgd2hpY2ggcmVjZWl2ZXMgdGhlIGNlbGwgY29udGVudCBhbmQgcmV0dXJucyBpdHMg4oCcdmlzaWJsZeKAnSBzaXplO1xuICogICBub3RlIHRoYXQgd2hhdCBpcyBhbmQgaXNu4oCZdCB2aXNpYmxlIGRlcGVuZHMgb24gd2hlcmUgdGhlIHRleHQgaXMgZGlzcGxheWVkLlxuICpcbiAqICAgV2l0aG91dCBzdWNoIGEgZnVuY3Rpb24sIHRoZSBmb2xsb3dpbmc6XG4gKlxuICogICBgYGBqc1xuICogICBtYXJrZG93blRhYmxlKFtcbiAqICAgICBbJ0FscGhhJywgJ0JyYXZvJ10sXG4gKiAgICAgWyfkuK3mlocnLCAnQ2hhcmxpZSddLFxuICogICAgIFsn8J+RqeKAjeKdpO+4j+KAjfCfkaknLCAnRGVsdGEnXVxuICogICBdKVxuICogICBgYGBcbiAqXG4gKiAgIFlpZWxkczpcbiAqXG4gKiAgIGBgYG1hcmtkb3duXG4gKiAgIHwgQWxwaGEgfCBCcmF2byB8XG4gKiAgIHwgLSB8IC0gfFxuICogICB8IOS4reaWhyB8IENoYXJsaWUgfFxuICogICB8IPCfkanigI3inaTvuI/igI3wn5GpIHwgRGVsdGEgfFxuICogICBgYGBcbiAqXG4gKiAgIFdpdGggW2BzdHJpbmctd2lkdGhgXShodHRwczovL2dpdGh1Yi5jb20vc2luZHJlc29yaHVzL3N0cmluZy13aWR0aCk6XG4gKlxuICogICBgYGBqc1xuICogICBpbXBvcnQgc3RyaW5nV2lkdGggZnJvbSAnc3RyaW5nLXdpZHRoJ1xuICpcbiAqICAgbWFya2Rvd25UYWJsZShcbiAqICAgICBbXG4gKiAgICAgICBbJ0FscGhhJywgJ0JyYXZvJ10sXG4gKiAgICAgICBbJ+S4reaWhycsICdDaGFybGllJ10sXG4gKiAgICAgICBbJ/CfkanigI3inaTvuI/igI3wn5GpJywgJ0RlbHRhJ11cbiAqICAgICBdLFxuICogICAgIHtzdHJpbmdMZW5ndGg6IHN0cmluZ1dpZHRofVxuICogICApXG4gKiAgIGBgYFxuICpcbiAqICAgWWllbGRzOlxuICpcbiAqICAgYGBgbWFya2Rvd25cbiAqICAgfCBBbHBoYSB8IEJyYXZvICAgfFxuICogICB8IC0tLS0tIHwgLS0tLS0tLSB8XG4gKiAgIHwg5Lit5paHICB8IENoYXJsaWUgfFxuICogICB8IPCfkanigI3inaTvuI/igI3wn5GpICAgIHwgRGVsdGEgICB8XG4gKiAgIGBgYFxuICovXG5cbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHZhbHVlXG4gKiAgIENlbGwgdmFsdWUuXG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICogICBDZWxsIHNpemUuXG4gKi9cbmZ1bmN0aW9uIGRlZmF1bHRTdHJpbmdMZW5ndGgodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlLmxlbmd0aFxufVxuXG4vKipcbiAqIEdlbmVyYXRlIGEgbWFya2Rvd25cbiAqIChbR0ZNXShodHRwczovL2RvY3MuZ2l0aHViLmNvbS9lbi9naXRodWIvd3JpdGluZy1vbi1naXRodWIvd29ya2luZy13aXRoLWFkdmFuY2VkLWZvcm1hdHRpbmcvb3JnYW5pemluZy1pbmZvcm1hdGlvbi13aXRoLXRhYmxlcykpXG4gKiB0YWJsZS5cbiAqXG4gKiBAcGFyYW0ge1JlYWRvbmx5QXJyYXk8UmVhZG9ubHlBcnJheTxzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkPj59IHRhYmxlXG4gKiAgIFRhYmxlIGRhdGEgKG1hdHJpeCBvZiBzdHJpbmdzKS5cbiAqIEBwYXJhbSB7UmVhZG9ubHk8T3B0aW9ucz4gfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0aW9uc11cbiAqICAgQ29uZmlndXJhdGlvbiAob3B0aW9uYWwpLlxuICogQHJldHVybnMge3N0cmluZ31cbiAqICAgUmVzdWx0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWFya2Rvd25UYWJsZSh0YWJsZSwgb3B0aW9ucykge1xuICBjb25zdCBzZXR0aW5ncyA9IG9wdGlvbnMgfHwge31cbiAgLy8gVG8gZG86IG5leHQgbWFqb3I6IGNoYW5nZSB0byBzcHJlYWQuXG4gIGNvbnN0IGFsaWduID0gKHNldHRpbmdzLmFsaWduIHx8IFtdKS5jb25jYXQoKVxuICBjb25zdCBzdHJpbmdMZW5ndGggPSBzZXR0aW5ncy5zdHJpbmdMZW5ndGggfHwgZGVmYXVsdFN0cmluZ0xlbmd0aFxuICAvKiogQHR5cGUge0FycmF5PG51bWJlcj59IENoYXJhY3RlciBjb2RlcyBhcyBzeW1ib2xzIGZvciBhbGlnbm1lbnQgcGVyIGNvbHVtbi4gKi9cbiAgY29uc3QgYWxpZ25tZW50cyA9IFtdXG4gIC8qKiBAdHlwZSB7QXJyYXk8QXJyYXk8c3RyaW5nPj59IENlbGxzIHBlciByb3cuICovXG4gIGNvbnN0IGNlbGxNYXRyaXggPSBbXVxuICAvKiogQHR5cGUge0FycmF5PEFycmF5PG51bWJlcj4+fSBTaXplcyBvZiBlYWNoIGNlbGwgcGVyIHJvdy4gKi9cbiAgY29uc3Qgc2l6ZU1hdHJpeCA9IFtdXG4gIC8qKiBAdHlwZSB7QXJyYXk8bnVtYmVyPn0gKi9cbiAgY29uc3QgbG9uZ2VzdENlbGxCeUNvbHVtbiA9IFtdXG4gIGxldCBtb3N0Q2VsbHNQZXJSb3cgPSAwXG4gIGxldCByb3dJbmRleCA9IC0xXG5cbiAgLy8gVGhpcyBpcyBhIHN1cGVyZmx1b3VzIGxvb3AgaWYgd2UgZG9u4oCZdCBhbGlnbiBkZWxpbWl0ZXJzLCBidXQgb3RoZXJ3aXNlIHdl4oCZZFxuICAvLyBkbyBzdXBlcmZsdW91cyB3b3JrIHdoZW4gYWxpZ25pbmcsIHNvIG9wdGltaXplIGZvciBhbGlnbmluZy5cbiAgd2hpbGUgKCsrcm93SW5kZXggPCB0YWJsZS5sZW5ndGgpIHtcbiAgICAvKiogQHR5cGUge0FycmF5PHN0cmluZz59ICovXG4gICAgY29uc3Qgcm93ID0gW11cbiAgICAvKiogQHR5cGUge0FycmF5PG51bWJlcj59ICovXG4gICAgY29uc3Qgc2l6ZXMgPSBbXVxuICAgIGxldCBjb2x1bW5JbmRleCA9IC0xXG5cbiAgICBpZiAodGFibGVbcm93SW5kZXhdLmxlbmd0aCA+IG1vc3RDZWxsc1BlclJvdykge1xuICAgICAgbW9zdENlbGxzUGVyUm93ID0gdGFibGVbcm93SW5kZXhdLmxlbmd0aFxuICAgIH1cblxuICAgIHdoaWxlICgrK2NvbHVtbkluZGV4IDwgdGFibGVbcm93SW5kZXhdLmxlbmd0aCkge1xuICAgICAgY29uc3QgY2VsbCA9IHNlcmlhbGl6ZSh0YWJsZVtyb3dJbmRleF1bY29sdW1uSW5kZXhdKVxuXG4gICAgICBpZiAoc2V0dGluZ3MuYWxpZ25EZWxpbWl0ZXJzICE9PSBmYWxzZSkge1xuICAgICAgICBjb25zdCBzaXplID0gc3RyaW5nTGVuZ3RoKGNlbGwpXG4gICAgICAgIHNpemVzW2NvbHVtbkluZGV4XSA9IHNpemVcblxuICAgICAgICBpZiAoXG4gICAgICAgICAgbG9uZ2VzdENlbGxCeUNvbHVtbltjb2x1bW5JbmRleF0gPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICAgIHNpemUgPiBsb25nZXN0Q2VsbEJ5Q29sdW1uW2NvbHVtbkluZGV4XVxuICAgICAgICApIHtcbiAgICAgICAgICBsb25nZXN0Q2VsbEJ5Q29sdW1uW2NvbHVtbkluZGV4XSA9IHNpemVcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByb3cucHVzaChjZWxsKVxuICAgIH1cblxuICAgIGNlbGxNYXRyaXhbcm93SW5kZXhdID0gcm93XG4gICAgc2l6ZU1hdHJpeFtyb3dJbmRleF0gPSBzaXplc1xuICB9XG5cbiAgLy8gRmlndXJlIG91dCB3aGljaCBhbGlnbm1lbnRzIHRvIHVzZS5cbiAgbGV0IGNvbHVtbkluZGV4ID0gLTFcblxuICBpZiAodHlwZW9mIGFsaWduID09PSAnb2JqZWN0JyAmJiAnbGVuZ3RoJyBpbiBhbGlnbikge1xuICAgIHdoaWxlICgrK2NvbHVtbkluZGV4IDwgbW9zdENlbGxzUGVyUm93KSB7XG4gICAgICBhbGlnbm1lbnRzW2NvbHVtbkluZGV4XSA9IHRvQWxpZ25tZW50KGFsaWduW2NvbHVtbkluZGV4XSlcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgY29kZSA9IHRvQWxpZ25tZW50KGFsaWduKVxuXG4gICAgd2hpbGUgKCsrY29sdW1uSW5kZXggPCBtb3N0Q2VsbHNQZXJSb3cpIHtcbiAgICAgIGFsaWdubWVudHNbY29sdW1uSW5kZXhdID0gY29kZVxuICAgIH1cbiAgfVxuXG4gIC8vIEluamVjdCB0aGUgYWxpZ25tZW50IHJvdy5cbiAgY29sdW1uSW5kZXggPSAtMVxuICAvKiogQHR5cGUge0FycmF5PHN0cmluZz59ICovXG4gIGNvbnN0IHJvdyA9IFtdXG4gIC8qKiBAdHlwZSB7QXJyYXk8bnVtYmVyPn0gKi9cbiAgY29uc3Qgc2l6ZXMgPSBbXVxuXG4gIHdoaWxlICgrK2NvbHVtbkluZGV4IDwgbW9zdENlbGxzUGVyUm93KSB7XG4gICAgY29uc3QgY29kZSA9IGFsaWdubWVudHNbY29sdW1uSW5kZXhdXG4gICAgbGV0IGJlZm9yZSA9ICcnXG4gICAgbGV0IGFmdGVyID0gJydcblxuICAgIGlmIChjb2RlID09PSA5OSAvKiBgY2AgKi8pIHtcbiAgICAgIGJlZm9yZSA9ICc6J1xuICAgICAgYWZ0ZXIgPSAnOidcbiAgICB9IGVsc2UgaWYgKGNvZGUgPT09IDEwOCAvKiBgbGAgKi8pIHtcbiAgICAgIGJlZm9yZSA9ICc6J1xuICAgIH0gZWxzZSBpZiAoY29kZSA9PT0gMTE0IC8qIGByYCAqLykge1xuICAgICAgYWZ0ZXIgPSAnOidcbiAgICB9XG5cbiAgICAvLyBUaGVyZSAqbXVzdCogYmUgYXQgbGVhc3Qgb25lIGh5cGhlbi1taW51cyBpbiBlYWNoIGFsaWdubWVudCBjZWxsLlxuICAgIGxldCBzaXplID1cbiAgICAgIHNldHRpbmdzLmFsaWduRGVsaW1pdGVycyA9PT0gZmFsc2VcbiAgICAgICAgPyAxXG4gICAgICAgIDogTWF0aC5tYXgoXG4gICAgICAgICAgICAxLFxuICAgICAgICAgICAgbG9uZ2VzdENlbGxCeUNvbHVtbltjb2x1bW5JbmRleF0gLSBiZWZvcmUubGVuZ3RoIC0gYWZ0ZXIubGVuZ3RoXG4gICAgICAgICAgKVxuXG4gICAgY29uc3QgY2VsbCA9IGJlZm9yZSArICctJy5yZXBlYXQoc2l6ZSkgKyBhZnRlclxuXG4gICAgaWYgKHNldHRpbmdzLmFsaWduRGVsaW1pdGVycyAhPT0gZmFsc2UpIHtcbiAgICAgIHNpemUgPSBiZWZvcmUubGVuZ3RoICsgc2l6ZSArIGFmdGVyLmxlbmd0aFxuXG4gICAgICBpZiAoc2l6ZSA+IGxvbmdlc3RDZWxsQnlDb2x1bW5bY29sdW1uSW5kZXhdKSB7XG4gICAgICAgIGxvbmdlc3RDZWxsQnlDb2x1bW5bY29sdW1uSW5kZXhdID0gc2l6ZVxuICAgICAgfVxuXG4gICAgICBzaXplc1tjb2x1bW5JbmRleF0gPSBzaXplXG4gICAgfVxuXG4gICAgcm93W2NvbHVtbkluZGV4XSA9IGNlbGxcbiAgfVxuXG4gIC8vIEluamVjdCB0aGUgYWxpZ25tZW50IHJvdy5cbiAgY2VsbE1hdHJpeC5zcGxpY2UoMSwgMCwgcm93KVxuICBzaXplTWF0cml4LnNwbGljZSgxLCAwLCBzaXplcylcblxuICByb3dJbmRleCA9IC0xXG4gIC8qKiBAdHlwZSB7QXJyYXk8c3RyaW5nPn0gKi9cbiAgY29uc3QgbGluZXMgPSBbXVxuXG4gIHdoaWxlICgrK3Jvd0luZGV4IDwgY2VsbE1hdHJpeC5sZW5ndGgpIHtcbiAgICBjb25zdCByb3cgPSBjZWxsTWF0cml4W3Jvd0luZGV4XVxuICAgIGNvbnN0IHNpemVzID0gc2l6ZU1hdHJpeFtyb3dJbmRleF1cbiAgICBjb2x1bW5JbmRleCA9IC0xXG4gICAgLyoqIEB0eXBlIHtBcnJheTxzdHJpbmc+fSAqL1xuICAgIGNvbnN0IGxpbmUgPSBbXVxuXG4gICAgd2hpbGUgKCsrY29sdW1uSW5kZXggPCBtb3N0Q2VsbHNQZXJSb3cpIHtcbiAgICAgIGNvbnN0IGNlbGwgPSByb3dbY29sdW1uSW5kZXhdIHx8ICcnXG4gICAgICBsZXQgYmVmb3JlID0gJydcbiAgICAgIGxldCBhZnRlciA9ICcnXG5cbiAgICAgIGlmIChzZXR0aW5ncy5hbGlnbkRlbGltaXRlcnMgIT09IGZhbHNlKSB7XG4gICAgICAgIGNvbnN0IHNpemUgPVxuICAgICAgICAgIGxvbmdlc3RDZWxsQnlDb2x1bW5bY29sdW1uSW5kZXhdIC0gKHNpemVzW2NvbHVtbkluZGV4XSB8fCAwKVxuICAgICAgICBjb25zdCBjb2RlID0gYWxpZ25tZW50c1tjb2x1bW5JbmRleF1cblxuICAgICAgICBpZiAoY29kZSA9PT0gMTE0IC8qIGByYCAqLykge1xuICAgICAgICAgIGJlZm9yZSA9ICcgJy5yZXBlYXQoc2l6ZSlcbiAgICAgICAgfSBlbHNlIGlmIChjb2RlID09PSA5OSAvKiBgY2AgKi8pIHtcbiAgICAgICAgICBpZiAoc2l6ZSAlIDIpIHtcbiAgICAgICAgICAgIGJlZm9yZSA9ICcgJy5yZXBlYXQoc2l6ZSAvIDIgKyAwLjUpXG4gICAgICAgICAgICBhZnRlciA9ICcgJy5yZXBlYXQoc2l6ZSAvIDIgLSAwLjUpXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGJlZm9yZSA9ICcgJy5yZXBlYXQoc2l6ZSAvIDIpXG4gICAgICAgICAgICBhZnRlciA9IGJlZm9yZVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBhZnRlciA9ICcgJy5yZXBlYXQoc2l6ZSlcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoc2V0dGluZ3MuZGVsaW1pdGVyU3RhcnQgIT09IGZhbHNlICYmICFjb2x1bW5JbmRleCkge1xuICAgICAgICBsaW5lLnB1c2goJ3wnKVxuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgIHNldHRpbmdzLnBhZGRpbmcgIT09IGZhbHNlICYmXG4gICAgICAgIC8vIERvbuKAmXQgYWRkIHRoZSBvcGVuaW5nIHNwYWNlIGlmIHdl4oCZcmUgbm90IGFsaWduaW5nIGFuZCB0aGUgY2VsbCBpc1xuICAgICAgICAvLyBlbXB0eTogdGhlcmUgd2lsbCBiZSBhIGNsb3Npbmcgc3BhY2UuXG4gICAgICAgICEoc2V0dGluZ3MuYWxpZ25EZWxpbWl0ZXJzID09PSBmYWxzZSAmJiBjZWxsID09PSAnJykgJiZcbiAgICAgICAgKHNldHRpbmdzLmRlbGltaXRlclN0YXJ0ICE9PSBmYWxzZSB8fCBjb2x1bW5JbmRleClcbiAgICAgICkge1xuICAgICAgICBsaW5lLnB1c2goJyAnKVxuICAgICAgfVxuXG4gICAgICBpZiAoc2V0dGluZ3MuYWxpZ25EZWxpbWl0ZXJzICE9PSBmYWxzZSkge1xuICAgICAgICBsaW5lLnB1c2goYmVmb3JlKVxuICAgICAgfVxuXG4gICAgICBsaW5lLnB1c2goY2VsbClcblxuICAgICAgaWYgKHNldHRpbmdzLmFsaWduRGVsaW1pdGVycyAhPT0gZmFsc2UpIHtcbiAgICAgICAgbGluZS5wdXNoKGFmdGVyKVxuICAgICAgfVxuXG4gICAgICBpZiAoc2V0dGluZ3MucGFkZGluZyAhPT0gZmFsc2UpIHtcbiAgICAgICAgbGluZS5wdXNoKCcgJylcbiAgICAgIH1cblxuICAgICAgaWYgKFxuICAgICAgICBzZXR0aW5ncy5kZWxpbWl0ZXJFbmQgIT09IGZhbHNlIHx8XG4gICAgICAgIGNvbHVtbkluZGV4ICE9PSBtb3N0Q2VsbHNQZXJSb3cgLSAxXG4gICAgICApIHtcbiAgICAgICAgbGluZS5wdXNoKCd8JylcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsaW5lcy5wdXNoKFxuICAgICAgc2V0dGluZ3MuZGVsaW1pdGVyRW5kID09PSBmYWxzZVxuICAgICAgICA/IGxpbmUuam9pbignJykucmVwbGFjZSgvICskLywgJycpXG4gICAgICAgIDogbGluZS5qb2luKCcnKVxuICAgIClcbiAgfVxuXG4gIHJldHVybiBsaW5lcy5qb2luKCdcXG4nKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gW3ZhbHVlXVxuICogICBWYWx1ZSB0byBzZXJpYWxpemUuXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICogICBSZXN1bHQuXG4gKi9cbmZ1bmN0aW9uIHNlcmlhbGl6ZSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCA/ICcnIDogU3RyaW5nKHZhbHVlKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gdmFsdWVcbiAqICAgVmFsdWUuXG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICogICBBbGlnbm1lbnQuXG4gKi9cbmZ1bmN0aW9uIHRvQWxpZ25tZW50KHZhbHVlKSB7XG4gIGNvbnN0IGNvZGUgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnID8gdmFsdWUuY29kZVBvaW50QXQoMCkgOiAwXG5cbiAgcmV0dXJuIGNvZGUgPT09IDY3IC8qIGBDYCAqLyB8fCBjb2RlID09PSA5OSAvKiBgY2AgKi9cbiAgICA/IDk5IC8qIGBjYCAqL1xuICAgIDogY29kZSA9PT0gNzYgLyogYExgICovIHx8IGNvZGUgPT09IDEwOCAvKiBgbGAgKi9cbiAgICAgID8gMTA4IC8qIGBsYCAqL1xuICAgICAgOiBjb2RlID09PSA4MiAvKiBgUmAgKi8gfHwgY29kZSA9PT0gMTE0IC8qIGByYCAqL1xuICAgICAgICA/IDExNCAvKiBgcmAgKi9cbiAgICAgICAgOiAwXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0Jsb2NrcXVvdGUsIFBhcmVudHN9IGZyb20gJ21kYXN0J1xuICogQGltcG9ydCB7SW5mbywgTWFwLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqL1xuXG4vKipcbiAqIEBwYXJhbSB7QmxvY2txdW90ZX0gbm9kZVxuICogQHBhcmFtIHtQYXJlbnRzIHwgdW5kZWZpbmVkfSBfXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gYmxvY2txdW90ZShub2RlLCBfLCBzdGF0ZSwgaW5mbykge1xuICBjb25zdCBleGl0ID0gc3RhdGUuZW50ZXIoJ2Jsb2NrcXVvdGUnKVxuICBjb25zdCB0cmFja2VyID0gc3RhdGUuY3JlYXRlVHJhY2tlcihpbmZvKVxuICB0cmFja2VyLm1vdmUoJz4gJylcbiAgdHJhY2tlci5zaGlmdCgyKVxuICBjb25zdCB2YWx1ZSA9IHN0YXRlLmluZGVudExpbmVzKFxuICAgIHN0YXRlLmNvbnRhaW5lckZsb3cobm9kZSwgdHJhY2tlci5jdXJyZW50KCkpLFxuICAgIG1hcFxuICApXG4gIGV4aXQoKVxuICByZXR1cm4gdmFsdWVcbn1cblxuLyoqIEB0eXBlIHtNYXB9ICovXG5mdW5jdGlvbiBtYXAobGluZSwgXywgYmxhbmspIHtcbiAgcmV0dXJuICc+JyArIChibGFuayA/ICcnIDogJyAnKSArIGxpbmVcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7Q29uc3RydWN0TmFtZSwgVW5zYWZlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICovXG5cbi8qKlxuICogQHBhcmFtIHtBcnJheTxDb25zdHJ1Y3ROYW1lPn0gc3RhY2tcbiAqIEBwYXJhbSB7VW5zYWZlfSBwYXR0ZXJuXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhdHRlcm5JblNjb3BlKHN0YWNrLCBwYXR0ZXJuKSB7XG4gIHJldHVybiAoXG4gICAgbGlzdEluU2NvcGUoc3RhY2ssIHBhdHRlcm4uaW5Db25zdHJ1Y3QsIHRydWUpICYmXG4gICAgIWxpc3RJblNjb3BlKHN0YWNrLCBwYXR0ZXJuLm5vdEluQ29uc3RydWN0LCBmYWxzZSlcbiAgKVxufVxuXG4vKipcbiAqIEBwYXJhbSB7QXJyYXk8Q29uc3RydWN0TmFtZT59IHN0YWNrXG4gKiBAcGFyYW0ge1Vuc2FmZVsnaW5Db25zdHJ1Y3QnXX0gbGlzdFxuICogQHBhcmFtIHtib29sZWFufSBub25lXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gbGlzdEluU2NvcGUoc3RhY2ssIGxpc3QsIG5vbmUpIHtcbiAgaWYgKHR5cGVvZiBsaXN0ID09PSAnc3RyaW5nJykge1xuICAgIGxpc3QgPSBbbGlzdF1cbiAgfVxuXG4gIGlmICghbGlzdCB8fCBsaXN0Lmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBub25lXG4gIH1cblxuICBsZXQgaW5kZXggPSAtMVxuXG4gIHdoaWxlICgrK2luZGV4IDwgbGlzdC5sZW5ndGgpIHtcbiAgICBpZiAoc3RhY2suaW5jbHVkZXMobGlzdFtpbmRleF0pKSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBmYWxzZVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtCcmVhaywgUGFyZW50c30gZnJvbSAnbWRhc3QnXG4gKiBAaW1wb3J0IHtJbmZvLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqL1xuXG5pbXBvcnQge3BhdHRlcm5JblNjb3BlfSBmcm9tICcuLi91dGlsL3BhdHRlcm4taW4tc2NvcGUuanMnXG5cbi8qKlxuICogQHBhcmFtIHtCcmVha30gX1xuICogQHBhcmFtIHtQYXJlbnRzIHwgdW5kZWZpbmVkfSBfMVxuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEBwYXJhbSB7SW5mb30gaW5mb1xuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGhhcmRCcmVhayhfLCBfMSwgc3RhdGUsIGluZm8pIHtcbiAgbGV0IGluZGV4ID0gLTFcblxuICB3aGlsZSAoKytpbmRleCA8IHN0YXRlLnVuc2FmZS5sZW5ndGgpIHtcbiAgICAvLyBJZiB3ZSBjYW7igJl0IHB1dCBlb2xzIGluIHRoaXMgY29uc3RydWN0IChzZXRleHQgaGVhZGluZ3MsIHRhYmxlcyksIHVzZSBhXG4gICAgLy8gc3BhY2UgaW5zdGVhZC5cbiAgICBpZiAoXG4gICAgICBzdGF0ZS51bnNhZmVbaW5kZXhdLmNoYXJhY3RlciA9PT0gJ1xcbicgJiZcbiAgICAgIHBhdHRlcm5JblNjb3BlKHN0YXRlLnN0YWNrLCBzdGF0ZS51bnNhZmVbaW5kZXhdKVxuICAgICkge1xuICAgICAgcmV0dXJuIC9bIFxcdF0vLnRlc3QoaW5mby5iZWZvcmUpID8gJycgOiAnICdcbiAgICB9XG4gIH1cblxuICByZXR1cm4gJ1xcXFxcXG4nXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge1N0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7Q29kZX0gZnJvbSAnbWRhc3QnXG4gKi9cblxuLyoqXG4gKiBAcGFyYW0ge0NvZGV9IG5vZGVcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdENvZGVBc0luZGVudGVkKG5vZGUsIHN0YXRlKSB7XG4gIHJldHVybiBCb29sZWFuKFxuICAgIHN0YXRlLm9wdGlvbnMuZmVuY2VzID09PSBmYWxzZSAmJlxuICAgICAgbm9kZS52YWx1ZSAmJlxuICAgICAgLy8gSWYgdGhlcmXigJlzIG5vIGluZm/igKZcbiAgICAgICFub2RlLmxhbmcgJiZcbiAgICAgIC8vIEFuZCB0aGVyZeKAmXMgYSBub24td2hpdGVzcGFjZSBjaGFyYWN0ZXLigKZcbiAgICAgIC9bXiBcXHJcXG5dLy50ZXN0KG5vZGUudmFsdWUpICYmXG4gICAgICAvLyBBbmQgdGhlIHZhbHVlIGRvZXNu4oCZdCBzdGFydCBvciBlbmQgaW4gYSBibGFua+KAplxuICAgICAgIS9eW1xcdCBdKig/OltcXHJcXG5dfCQpfCg/Ol58W1xcclxcbl0pW1xcdCBdKiQvLnRlc3Qobm9kZS52YWx1ZSlcbiAgKVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtPcHRpb25zLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqL1xuXG4vKipcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7RXhjbHVkZTxPcHRpb25zWydmZW5jZSddLCBudWxsIHwgdW5kZWZpbmVkPn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrRmVuY2Uoc3RhdGUpIHtcbiAgY29uc3QgbWFya2VyID0gc3RhdGUub3B0aW9ucy5mZW5jZSB8fCAnYCdcblxuICBpZiAobWFya2VyICE9PSAnYCcgJiYgbWFya2VyICE9PSAnficpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAnQ2Fubm90IHNlcmlhbGl6ZSBjb2RlIHdpdGggYCcgK1xuICAgICAgICBtYXJrZXIgK1xuICAgICAgICAnYCBmb3IgYG9wdGlvbnMuZmVuY2VgLCBleHBlY3RlZCBgYCBgIGBgIG9yIGB+YCdcbiAgICApXG4gIH1cblxuICByZXR1cm4gbWFya2VyXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0luZm8sIE1hcCwgU3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKiBAaW1wb3J0IHtDb2RlLCBQYXJlbnRzfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge2xvbmdlc3RTdHJlYWt9IGZyb20gJ2xvbmdlc3Qtc3RyZWFrJ1xuaW1wb3J0IHtmb3JtYXRDb2RlQXNJbmRlbnRlZH0gZnJvbSAnLi4vdXRpbC9mb3JtYXQtY29kZS1hcy1pbmRlbnRlZC5qcydcbmltcG9ydCB7Y2hlY2tGZW5jZX0gZnJvbSAnLi4vdXRpbC9jaGVjay1mZW5jZS5qcydcblxuLyoqXG4gKiBAcGFyYW0ge0NvZGV9IG5vZGVcbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gX1xuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEBwYXJhbSB7SW5mb30gaW5mb1xuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvZGUobm9kZSwgXywgc3RhdGUsIGluZm8pIHtcbiAgY29uc3QgbWFya2VyID0gY2hlY2tGZW5jZShzdGF0ZSlcbiAgY29uc3QgcmF3ID0gbm9kZS52YWx1ZSB8fCAnJ1xuICBjb25zdCBzdWZmaXggPSBtYXJrZXIgPT09ICdgJyA/ICdHcmF2ZUFjY2VudCcgOiAnVGlsZGUnXG5cbiAgaWYgKGZvcm1hdENvZGVBc0luZGVudGVkKG5vZGUsIHN0YXRlKSkge1xuICAgIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignY29kZUluZGVudGVkJylcbiAgICBjb25zdCB2YWx1ZSA9IHN0YXRlLmluZGVudExpbmVzKHJhdywgbWFwKVxuICAgIGV4aXQoKVxuICAgIHJldHVybiB2YWx1ZVxuICB9XG5cbiAgY29uc3QgdHJhY2tlciA9IHN0YXRlLmNyZWF0ZVRyYWNrZXIoaW5mbylcbiAgY29uc3Qgc2VxdWVuY2UgPSBtYXJrZXIucmVwZWF0KE1hdGgubWF4KGxvbmdlc3RTdHJlYWsocmF3LCBtYXJrZXIpICsgMSwgMykpXG4gIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignY29kZUZlbmNlZCcpXG4gIGxldCB2YWx1ZSA9IHRyYWNrZXIubW92ZShzZXF1ZW5jZSlcblxuICBpZiAobm9kZS5sYW5nKSB7XG4gICAgY29uc3Qgc3ViZXhpdCA9IHN0YXRlLmVudGVyKGBjb2RlRmVuY2VkTGFuZyR7c3VmZml4fWApXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKFxuICAgICAgc3RhdGUuc2FmZShub2RlLmxhbmcsIHtcbiAgICAgICAgYmVmb3JlOiB2YWx1ZSxcbiAgICAgICAgYWZ0ZXI6ICcgJyxcbiAgICAgICAgZW5jb2RlOiBbJ2AnXSxcbiAgICAgICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgICAgIH0pXG4gICAgKVxuICAgIHN1YmV4aXQoKVxuICB9XG5cbiAgaWYgKG5vZGUubGFuZyAmJiBub2RlLm1ldGEpIHtcbiAgICBjb25zdCBzdWJleGl0ID0gc3RhdGUuZW50ZXIoYGNvZGVGZW5jZWRNZXRhJHtzdWZmaXh9YClcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJyAnKVxuICAgIHZhbHVlICs9IHRyYWNrZXIubW92ZShcbiAgICAgIHN0YXRlLnNhZmUobm9kZS5tZXRhLCB7XG4gICAgICAgIGJlZm9yZTogdmFsdWUsXG4gICAgICAgIGFmdGVyOiAnXFxuJyxcbiAgICAgICAgZW5jb2RlOiBbJ2AnXSxcbiAgICAgICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgICAgIH0pXG4gICAgKVxuICAgIHN1YmV4aXQoKVxuICB9XG5cbiAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCdcXG4nKVxuXG4gIGlmIChyYXcpIHtcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUocmF3ICsgJ1xcbicpXG4gIH1cblxuICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoc2VxdWVuY2UpXG4gIGV4aXQoKVxuICByZXR1cm4gdmFsdWVcbn1cblxuLyoqIEB0eXBlIHtNYXB9ICovXG5mdW5jdGlvbiBtYXAobGluZSwgXywgYmxhbmspIHtcbiAgcmV0dXJuIChibGFuayA/ICcnIDogJyAgICAnKSArIGxpbmVcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7T3B0aW9ucywgU3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKi9cblxuLyoqXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHJldHVybnMge0V4Y2x1ZGU8T3B0aW9uc1sncXVvdGUnXSwgbnVsbCB8IHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja1F1b3RlKHN0YXRlKSB7XG4gIGNvbnN0IG1hcmtlciA9IHN0YXRlLm9wdGlvbnMucXVvdGUgfHwgJ1wiJ1xuXG4gIGlmIChtYXJrZXIgIT09ICdcIicgJiYgbWFya2VyICE9PSBcIidcIikge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdDYW5ub3Qgc2VyaWFsaXplIHRpdGxlIHdpdGggYCcgK1xuICAgICAgICBtYXJrZXIgK1xuICAgICAgICAnYCBmb3IgYG9wdGlvbnMucXVvdGVgLCBleHBlY3RlZCBgXCJgLCBvciBgXFwnYCdcbiAgICApXG4gIH1cblxuICByZXR1cm4gbWFya2VyXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0luZm8sIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7RGVmaW5pdGlvbiwgUGFyZW50c30gZnJvbSAnbWRhc3QnXG4gKi9cblxuaW1wb3J0IHtjaGVja1F1b3RlfSBmcm9tICcuLi91dGlsL2NoZWNrLXF1b3RlLmpzJ1xuXG4vKipcbiAqIEBwYXJhbSB7RGVmaW5pdGlvbn0gbm9kZVxuICogQHBhcmFtIHtQYXJlbnRzIHwgdW5kZWZpbmVkfSBfXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVmaW5pdGlvbihub2RlLCBfLCBzdGF0ZSwgaW5mbykge1xuICBjb25zdCBxdW90ZSA9IGNoZWNrUXVvdGUoc3RhdGUpXG4gIGNvbnN0IHN1ZmZpeCA9IHF1b3RlID09PSAnXCInID8gJ1F1b3RlJyA6ICdBcG9zdHJvcGhlJ1xuICBjb25zdCBleGl0ID0gc3RhdGUuZW50ZXIoJ2RlZmluaXRpb24nKVxuICBsZXQgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdsYWJlbCcpXG4gIGNvbnN0IHRyYWNrZXIgPSBzdGF0ZS5jcmVhdGVUcmFja2VyKGluZm8pXG4gIGxldCB2YWx1ZSA9IHRyYWNrZXIubW92ZSgnWycpXG4gIHZhbHVlICs9IHRyYWNrZXIubW92ZShcbiAgICBzdGF0ZS5zYWZlKHN0YXRlLmFzc29jaWF0aW9uSWQobm9kZSksIHtcbiAgICAgIGJlZm9yZTogdmFsdWUsXG4gICAgICBhZnRlcjogJ10nLFxuICAgICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgICB9KVxuICApXG4gIHZhbHVlICs9IHRyYWNrZXIubW92ZSgnXTogJylcblxuICBzdWJleGl0KClcblxuICBpZiAoXG4gICAgLy8gSWYgdGhlcmXigJlzIG5vIHVybCwgb3LigKZcbiAgICAhbm9kZS51cmwgfHxcbiAgICAvLyBJZiB0aGVyZSBhcmUgY29udHJvbCBjaGFyYWN0ZXJzIG9yIHdoaXRlc3BhY2UuXG4gICAgL1tcXDAtIFxcdTAwN0ZdLy50ZXN0KG5vZGUudXJsKVxuICApIHtcbiAgICBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ2Rlc3RpbmF0aW9uTGl0ZXJhbCcpXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCc8JylcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgICBzdGF0ZS5zYWZlKG5vZGUudXJsLCB7YmVmb3JlOiB2YWx1ZSwgYWZ0ZXI6ICc+JywgLi4udHJhY2tlci5jdXJyZW50KCl9KVxuICAgIClcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJz4nKVxuICB9IGVsc2Uge1xuICAgIC8vIE5vIHdoaXRlc3BhY2UsIHJhdyBpcyBwcmV0dGllci5cbiAgICBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ2Rlc3RpbmF0aW9uUmF3JylcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgICBzdGF0ZS5zYWZlKG5vZGUudXJsLCB7XG4gICAgICAgIGJlZm9yZTogdmFsdWUsXG4gICAgICAgIGFmdGVyOiBub2RlLnRpdGxlID8gJyAnIDogJ1xcbicsXG4gICAgICAgIC4uLnRyYWNrZXIuY3VycmVudCgpXG4gICAgICB9KVxuICAgIClcbiAgfVxuXG4gIHN1YmV4aXQoKVxuXG4gIGlmIChub2RlLnRpdGxlKSB7XG4gICAgc3ViZXhpdCA9IHN0YXRlLmVudGVyKGB0aXRsZSR7c3VmZml4fWApXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCcgJyArIHF1b3RlKVxuICAgIHZhbHVlICs9IHRyYWNrZXIubW92ZShcbiAgICAgIHN0YXRlLnNhZmUobm9kZS50aXRsZSwge1xuICAgICAgICBiZWZvcmU6IHZhbHVlLFxuICAgICAgICBhZnRlcjogcXVvdGUsXG4gICAgICAgIC4uLnRyYWNrZXIuY3VycmVudCgpXG4gICAgICB9KVxuICAgIClcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUocXVvdGUpXG4gICAgc3ViZXhpdCgpXG4gIH1cblxuICBleGl0KClcblxuICByZXR1cm4gdmFsdWVcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7T3B0aW9ucywgU3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKi9cblxuLyoqXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHJldHVybnMge0V4Y2x1ZGU8T3B0aW9uc1snZW1waGFzaXMnXSwgbnVsbCB8IHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja0VtcGhhc2lzKHN0YXRlKSB7XG4gIGNvbnN0IG1hcmtlciA9IHN0YXRlLm9wdGlvbnMuZW1waGFzaXMgfHwgJyonXG5cbiAgaWYgKG1hcmtlciAhPT0gJyonICYmIG1hcmtlciAhPT0gJ18nKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ0Nhbm5vdCBzZXJpYWxpemUgZW1waGFzaXMgd2l0aCBgJyArXG4gICAgICAgIG1hcmtlciArXG4gICAgICAgICdgIGZvciBgb3B0aW9ucy5lbXBoYXNpc2AsIGV4cGVjdGVkIGAqYCwgb3IgYF9gJ1xuICAgIClcbiAgfVxuXG4gIHJldHVybiBtYXJrZXJcbn1cbiIsIi8qKlxuICogRW5jb2RlIGEgY29kZSBwb2ludCBhcyBhIGNoYXJhY3RlciByZWZlcmVuY2UuXG4gKlxuICogQHBhcmFtIHtudW1iZXJ9IGNvZGVcbiAqICAgQ29kZSBwb2ludCB0byBlbmNvZGUuXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICogICBFbmNvZGVkIGNoYXJhY3RlciByZWZlcmVuY2UuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVDaGFyYWN0ZXJSZWZlcmVuY2UoY29kZSkge1xuICByZXR1cm4gJyYjeCcgKyBjb2RlLnRvU3RyaW5nKDE2KS50b1VwcGVyQ2FzZSgpICsgJzsnXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0VuY29kZVNpZGVzfSBmcm9tICcuLi90eXBlcy5qcydcbiAqL1xuXG5pbXBvcnQge2NsYXNzaWZ5Q2hhcmFjdGVyfSBmcm9tICdtaWNyb21hcmstdXRpbC1jbGFzc2lmeS1jaGFyYWN0ZXInXG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0byBlbmNvZGUgKGFzIGEgY2hhcmFjdGVyIHJlZmVyZW5jZSkgdGhlIGNoYXJhY3RlcnNcbiAqIHN1cnJvdW5kaW5nIGFuIGF0dGVudGlvbiBydW4uXG4gKlxuICogV2hpY2ggY2hhcmFjdGVycyBhcmUgYXJvdW5kIGFuIGF0dGVudGlvbiBydW4gaW5mbHVlbmNlIHdoZXRoZXIgaXQgd29ya3Mgb3JcbiAqIG5vdC5cbiAqXG4gKiBTZWUgPGh0dHBzOi8vZ2l0aHViLmNvbS9vcmdzL3N5bnRheC10cmVlL2Rpc2N1c3Npb25zLzYwPiBmb3IgbW9yZSBpbmZvLlxuICogU2VlIHRoaXMgbWFya2Rvd24gaW4gYSBwYXJ0aWN1bGFyIHJlbmRlcmVyIHRvIHNlZSB3aGF0IHdvcmtzOlxuICpcbiAqIGBgYG1hcmtkb3duXG4gKiB8ICAgICAgICAgICAgICAgICAgICAgICAgIHwgQSAobGV0dGVyIGluc2lkZSkgfCBCIChwdW5jdHVhdGlvbiBpbnNpZGUpIHwgQyAod2hpdGVzcGFjZSBpbnNpZGUpIHwgRCAobm90aGluZyBpbnNpZGUpIHxcbiAqIHwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gfCAtLS0tLS0tLS0tLS0tLS0tLSB8IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gfCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0gfCAtLS0tLS0tLS0tLS0tLS0tLS0gfFxuICogfCAxIChsZXR0ZXIgb3V0c2lkZSkgICAgICB8IHgqeSp6ICAgICAgICAgICAgIHwgeCouKnogICAgICAgICAgICAgICAgICB8IHgqICp6ICAgICAgICAgICAgICAgICB8IHgqKnogICAgICAgICAgICAgICB8XG4gKiB8IDIgKHB1bmN0dWF0aW9uIG91dHNpZGUpIHwgLip5Ki4gICAgICAgICAgICAgfCAuKi4qLiAgICAgICAgICAgICAgICAgIHwgLiogKi4gICAgICAgICAgICAgICAgIHwgLioqLiAgICAgICAgICAgICAgIHxcbiAqIHwgMyAod2hpdGVzcGFjZSBvdXRzaWRlKSAgfCB4ICp5KiB6ICAgICAgICAgICB8IHggKi4qIHogICAgICAgICAgICAgICAgfCB4ICogKiB6ICAgICAgICAgICAgICAgfCB4ICoqIHogICAgICAgICAgICAgfFxuICogfCA0IChub3RoaW5nIG91dHNpZGUpICAgICB8ICp4KiAgICAgICAgICAgICAgIHwgKi4qICAgICAgICAgICAgICAgICAgICB8ICogKiAgICAgICAgICAgICAgICAgICB8ICoqICAgICAgICAgICAgICAgICB8XG4gKiBgYGBcbiAqXG4gKiBAcGFyYW0ge251bWJlcn0gb3V0c2lkZVxuICogICBDb2RlIHBvaW50IG9uIHRoZSBvdXRlciBzaWRlIG9mIHRoZSBydW4uXG4gKiBAcGFyYW0ge251bWJlcn0gaW5zaWRlXG4gKiAgIENvZGUgcG9pbnQgb24gdGhlIGlubmVyIHNpZGUgb2YgdGhlIHJ1bi5cbiAqIEBwYXJhbSB7JyonIHwgJ18nfSBtYXJrZXJcbiAqICAgTWFya2VyIG9mIHRoZSBydW4uXG4gKiAgIFVuZGVyc2NvcmVzIGFyZSBoYW5kbGVkIG1vcmUgc3RyaWN0bHkgKHRoZXkgZm9ybSBsZXNzIG9mdGVuKSB0aGFuXG4gKiAgIGFzdGVyaXNrcy5cbiAqIEByZXR1cm5zIHtFbmNvZGVTaWRlc31cbiAqICAgV2hldGhlciB0byBlbmNvZGUgY2hhcmFjdGVycy5cbiAqL1xuLy8gSW1wb3J0YW50OiBwdW5jdHVhdGlvbiBtdXN0IG5ldmVyIGJlIGVuY29kZWQuXG4vLyBQdW5jdHVhdGlvbiBpcyBzb2xlbHkgdXNlZCBieSBtYXJrZG93biBjb25zdHJ1Y3RzLlxuLy8gQW5kIGJ5IGVuY29kaW5nIGl0c2VsZi5cbi8vIEVuY29kaW5nIHRoZW0gd2lsbCBicmVhayBjb25zdHJ1Y3RzIG9yIGRvdWJsZSBlbmNvZGUgdGhpbmdzLlxuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZUluZm8ob3V0c2lkZSwgaW5zaWRlLCBtYXJrZXIpIHtcbiAgY29uc3Qgb3V0c2lkZUtpbmQgPSBjbGFzc2lmeUNoYXJhY3RlcihvdXRzaWRlKVxuICBjb25zdCBpbnNpZGVLaW5kID0gY2xhc3NpZnlDaGFyYWN0ZXIoaW5zaWRlKVxuXG4gIC8vIExldHRlciBvdXRzaWRlOlxuICBpZiAob3V0c2lkZUtpbmQgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBpbnNpZGVLaW5kID09PSB1bmRlZmluZWRcbiAgICAgID8gLy8gTGV0dGVyIGluc2lkZTpcbiAgICAgICAgLy8gd2UgaGF2ZSB0byBlbmNvZGUgKmJvdGgqIGxldHRlcnMgZm9yIGBfYCBhcyBpdCBpcyBsb29zZXIuXG4gICAgICAgIC8vIGl0IGFscmVhZHkgZm9ybXMgZm9yIGAqYCAoYW5kIEdGTXMgYH5gKS5cbiAgICAgICAgbWFya2VyID09PSAnXydcbiAgICAgICAgPyB7aW5zaWRlOiB0cnVlLCBvdXRzaWRlOiB0cnVlfVxuICAgICAgICA6IHtpbnNpZGU6IGZhbHNlLCBvdXRzaWRlOiBmYWxzZX1cbiAgICAgIDogaW5zaWRlS2luZCA9PT0gMVxuICAgICAgICA/IC8vIFdoaXRlc3BhY2UgaW5zaWRlOiBlbmNvZGUgYm90aCAobGV0dGVyLCB3aGl0ZXNwYWNlKS5cbiAgICAgICAgICB7aW5zaWRlOiB0cnVlLCBvdXRzaWRlOiB0cnVlfVxuICAgICAgICA6IC8vIFB1bmN0dWF0aW9uIGluc2lkZTogZW5jb2RlIG91dGVyIChsZXR0ZXIpXG4gICAgICAgICAge2luc2lkZTogZmFsc2UsIG91dHNpZGU6IHRydWV9XG4gIH1cblxuICAvLyBXaGl0ZXNwYWNlIG91dHNpZGU6XG4gIGlmIChvdXRzaWRlS2luZCA9PT0gMSkge1xuICAgIHJldHVybiBpbnNpZGVLaW5kID09PSB1bmRlZmluZWRcbiAgICAgID8gLy8gTGV0dGVyIGluc2lkZTogYWxyZWFkeSBmb3Jtcy5cbiAgICAgICAge2luc2lkZTogZmFsc2UsIG91dHNpZGU6IGZhbHNlfVxuICAgICAgOiBpbnNpZGVLaW5kID09PSAxXG4gICAgICAgID8gLy8gV2hpdGVzcGFjZSBpbnNpZGU6IGVuY29kZSBib3RoICh3aGl0ZXNwYWNlKS5cbiAgICAgICAgICB7aW5zaWRlOiB0cnVlLCBvdXRzaWRlOiB0cnVlfVxuICAgICAgICA6IC8vIFB1bmN0dWF0aW9uIGluc2lkZTogYWxyZWFkeSBmb3Jtcy5cbiAgICAgICAgICB7aW5zaWRlOiBmYWxzZSwgb3V0c2lkZTogZmFsc2V9XG4gIH1cblxuICAvLyBQdW5jdHVhdGlvbiBvdXRzaWRlOlxuICByZXR1cm4gaW5zaWRlS2luZCA9PT0gdW5kZWZpbmVkXG4gICAgPyAvLyBMZXR0ZXIgaW5zaWRlOiBhbHJlYWR5IGZvcm1zLlxuICAgICAge2luc2lkZTogZmFsc2UsIG91dHNpZGU6IGZhbHNlfVxuICAgIDogaW5zaWRlS2luZCA9PT0gMVxuICAgICAgPyAvLyBXaGl0ZXNwYWNlIGluc2lkZTogZW5jb2RlIGlubmVyICh3aGl0ZXNwYWNlKS5cbiAgICAgICAge2luc2lkZTogdHJ1ZSwgb3V0c2lkZTogZmFsc2V9XG4gICAgICA6IC8vIFB1bmN0dWF0aW9uIGluc2lkZTogYWxyZWFkeSBmb3Jtcy5cbiAgICAgICAge2luc2lkZTogZmFsc2UsIG91dHNpZGU6IGZhbHNlfVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtJbmZvLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqIEBpbXBvcnQge0VtcGhhc2lzLCBQYXJlbnRzfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge2NoZWNrRW1waGFzaXN9IGZyb20gJy4uL3V0aWwvY2hlY2stZW1waGFzaXMuanMnXG5pbXBvcnQge2VuY29kZUNoYXJhY3RlclJlZmVyZW5jZX0gZnJvbSAnLi4vdXRpbC9lbmNvZGUtY2hhcmFjdGVyLXJlZmVyZW5jZS5qcydcbmltcG9ydCB7ZW5jb2RlSW5mb30gZnJvbSAnLi4vdXRpbC9lbmNvZGUtaW5mby5qcydcblxuZW1waGFzaXMucGVlayA9IGVtcGhhc2lzUGVla1xuXG4vKipcbiAqIEBwYXJhbSB7RW1waGFzaXN9IG5vZGVcbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gX1xuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEBwYXJhbSB7SW5mb30gaW5mb1xuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVtcGhhc2lzKG5vZGUsIF8sIHN0YXRlLCBpbmZvKSB7XG4gIGNvbnN0IG1hcmtlciA9IGNoZWNrRW1waGFzaXMoc3RhdGUpXG4gIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignZW1waGFzaXMnKVxuICBjb25zdCB0cmFja2VyID0gc3RhdGUuY3JlYXRlVHJhY2tlcihpbmZvKVxuICBjb25zdCBiZWZvcmUgPSB0cmFja2VyLm1vdmUobWFya2VyKVxuXG4gIGxldCBiZXR3ZWVuID0gdHJhY2tlci5tb3ZlKFxuICAgIHN0YXRlLmNvbnRhaW5lclBocmFzaW5nKG5vZGUsIHtcbiAgICAgIGFmdGVyOiBtYXJrZXIsXG4gICAgICBiZWZvcmUsXG4gICAgICAuLi50cmFja2VyLmN1cnJlbnQoKVxuICAgIH0pXG4gIClcbiAgY29uc3QgYmV0d2VlbkhlYWQgPSBiZXR3ZWVuLmNoYXJDb2RlQXQoMClcbiAgY29uc3Qgb3BlbiA9IGVuY29kZUluZm8oXG4gICAgaW5mby5iZWZvcmUuY2hhckNvZGVBdChpbmZvLmJlZm9yZS5sZW5ndGggLSAxKSxcbiAgICBiZXR3ZWVuSGVhZCxcbiAgICBtYXJrZXJcbiAgKVxuXG4gIGlmIChvcGVuLmluc2lkZSkge1xuICAgIGJldHdlZW4gPSBlbmNvZGVDaGFyYWN0ZXJSZWZlcmVuY2UoYmV0d2VlbkhlYWQpICsgYmV0d2Vlbi5zbGljZSgxKVxuICB9XG5cbiAgY29uc3QgYmV0d2VlblRhaWwgPSBiZXR3ZWVuLmNoYXJDb2RlQXQoYmV0d2Vlbi5sZW5ndGggLSAxKVxuICBjb25zdCBjbG9zZSA9IGVuY29kZUluZm8oaW5mby5hZnRlci5jaGFyQ29kZUF0KDApLCBiZXR3ZWVuVGFpbCwgbWFya2VyKVxuXG4gIGlmIChjbG9zZS5pbnNpZGUpIHtcbiAgICBiZXR3ZWVuID0gYmV0d2Vlbi5zbGljZSgwLCAtMSkgKyBlbmNvZGVDaGFyYWN0ZXJSZWZlcmVuY2UoYmV0d2VlblRhaWwpXG4gIH1cblxuICBjb25zdCBhZnRlciA9IHRyYWNrZXIubW92ZShtYXJrZXIpXG5cbiAgZXhpdCgpXG5cbiAgc3RhdGUuYXR0ZW50aW9uRW5jb2RlU3Vycm91bmRpbmdJbmZvID0ge1xuICAgIGFmdGVyOiBjbG9zZS5vdXRzaWRlLFxuICAgIGJlZm9yZTogb3Blbi5vdXRzaWRlXG4gIH1cbiAgcmV0dXJuIGJlZm9yZSArIGJldHdlZW4gKyBhZnRlclxufVxuXG4vKipcbiAqIEBwYXJhbSB7RW1waGFzaXN9IF9cbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gXzFcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5mdW5jdGlvbiBlbXBoYXNpc1BlZWsoXywgXzEsIHN0YXRlKSB7XG4gIHJldHVybiBzdGF0ZS5vcHRpb25zLmVtcGhhc2lzIHx8ICcqJ1xufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqIEBpbXBvcnQge0hlYWRpbmd9IGZyb20gJ21kYXN0J1xuICovXG5cbmltcG9ydCB7RVhJVCwgdmlzaXR9IGZyb20gJ3VuaXN0LXV0aWwtdmlzaXQnXG5pbXBvcnQge3RvU3RyaW5nfSBmcm9tICdtZGFzdC11dGlsLXRvLXN0cmluZydcblxuLyoqXG4gKiBAcGFyYW0ge0hlYWRpbmd9IG5vZGVcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdEhlYWRpbmdBc1NldGV4dChub2RlLCBzdGF0ZSkge1xuICBsZXQgbGl0ZXJhbFdpdGhCcmVhayA9IGZhbHNlXG5cbiAgLy8gTG9vayBmb3IgbGl0ZXJhbHMgd2l0aCBhIGxpbmUgYnJlYWsuXG4gIC8vIE5vdGUgdGhhdCB0aGlzIGFsc29cbiAgdmlzaXQobm9kZSwgZnVuY3Rpb24gKG5vZGUpIHtcbiAgICBpZiAoXG4gICAgICAoJ3ZhbHVlJyBpbiBub2RlICYmIC9cXHI/XFxufFxcci8udGVzdChub2RlLnZhbHVlKSkgfHxcbiAgICAgIG5vZGUudHlwZSA9PT0gJ2JyZWFrJ1xuICAgICkge1xuICAgICAgbGl0ZXJhbFdpdGhCcmVhayA9IHRydWVcbiAgICAgIHJldHVybiBFWElUXG4gICAgfVxuICB9KVxuXG4gIHJldHVybiBCb29sZWFuKFxuICAgICghbm9kZS5kZXB0aCB8fCBub2RlLmRlcHRoIDwgMykgJiZcbiAgICAgIHRvU3RyaW5nKG5vZGUpICYmXG4gICAgICAoc3RhdGUub3B0aW9ucy5zZXRleHQgfHwgbGl0ZXJhbFdpdGhCcmVhaylcbiAgKVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtJbmZvLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqIEBpbXBvcnQge0hlYWRpbmcsIFBhcmVudHN9IGZyb20gJ21kYXN0J1xuICovXG5cbmltcG9ydCB7ZW5jb2RlQ2hhcmFjdGVyUmVmZXJlbmNlfSBmcm9tICcuLi91dGlsL2VuY29kZS1jaGFyYWN0ZXItcmVmZXJlbmNlLmpzJ1xuaW1wb3J0IHtmb3JtYXRIZWFkaW5nQXNTZXRleHR9IGZyb20gJy4uL3V0aWwvZm9ybWF0LWhlYWRpbmctYXMtc2V0ZXh0LmpzJ1xuXG4vKipcbiAqIEBwYXJhbSB7SGVhZGluZ30gbm9kZVxuICogQHBhcmFtIHtQYXJlbnRzIHwgdW5kZWZpbmVkfSBfXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gaGVhZGluZyhub2RlLCBfLCBzdGF0ZSwgaW5mbykge1xuICBjb25zdCByYW5rID0gTWF0aC5tYXgoTWF0aC5taW4oNiwgbm9kZS5kZXB0aCB8fCAxKSwgMSlcbiAgY29uc3QgdHJhY2tlciA9IHN0YXRlLmNyZWF0ZVRyYWNrZXIoaW5mbylcblxuICBpZiAoZm9ybWF0SGVhZGluZ0FzU2V0ZXh0KG5vZGUsIHN0YXRlKSkge1xuICAgIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignaGVhZGluZ1NldGV4dCcpXG4gICAgY29uc3Qgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdwaHJhc2luZycpXG4gICAgY29uc3QgdmFsdWUgPSBzdGF0ZS5jb250YWluZXJQaHJhc2luZyhub2RlLCB7XG4gICAgICAuLi50cmFja2VyLmN1cnJlbnQoKSxcbiAgICAgIGJlZm9yZTogJ1xcbicsXG4gICAgICBhZnRlcjogJ1xcbidcbiAgICB9KVxuICAgIHN1YmV4aXQoKVxuICAgIGV4aXQoKVxuXG4gICAgcmV0dXJuIChcbiAgICAgIHZhbHVlICtcbiAgICAgICdcXG4nICtcbiAgICAgIChyYW5rID09PSAxID8gJz0nIDogJy0nKS5yZXBlYXQoXG4gICAgICAgIC8vIFRoZSB3aG9sZSBzaXpl4oCmXG4gICAgICAgIHZhbHVlLmxlbmd0aCAtXG4gICAgICAgICAgLy8gTWludXMgdGhlIHBvc2l0aW9uIG9mIHRoZSBjaGFyYWN0ZXIgYWZ0ZXIgdGhlIGxhc3QgRU9MIChvclxuICAgICAgICAgIC8vIDAgaWYgdGhlcmUgaXMgbm9uZSnigKZcbiAgICAgICAgICAoTWF0aC5tYXgodmFsdWUubGFzdEluZGV4T2YoJ1xccicpLCB2YWx1ZS5sYXN0SW5kZXhPZignXFxuJykpICsgMSlcbiAgICAgIClcbiAgICApXG4gIH1cblxuICBjb25zdCBzZXF1ZW5jZSA9ICcjJy5yZXBlYXQocmFuaylcbiAgY29uc3QgZXhpdCA9IHN0YXRlLmVudGVyKCdoZWFkaW5nQXR4JylcbiAgY29uc3Qgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdwaHJhc2luZycpXG5cbiAgLy8gTm90ZTogZm9yIHByb3BlciB0cmFja2luZywgd2Ugc2hvdWxkIHJlc2V0IHRoZSBvdXRwdXQgcG9zaXRpb25zIHdoZW4gdGhlcmVcbiAgLy8gaXMgbm8gY29udGVudCByZXR1cm5lZCwgYmVjYXVzZSB0aGVuIHRoZSBzcGFjZSBpcyBub3Qgb3V0cHV0LlxuICAvLyBQcmFjdGljYWxseSwgaW4gdGhhdCBjYXNlLCB0aGVyZSBpcyBubyBjb250ZW50LCBzbyBpdCBkb2VzbuKAmXQgbWF0dGVyIHRoYXRcbiAgLy8gd2XigJl2ZSB0cmFja2VkIG9uZSB0b28gbWFueSBjaGFyYWN0ZXJzLlxuICB0cmFja2VyLm1vdmUoc2VxdWVuY2UgKyAnICcpXG5cbiAgbGV0IHZhbHVlID0gc3RhdGUuY29udGFpbmVyUGhyYXNpbmcobm9kZSwge1xuICAgIGJlZm9yZTogJyMgJyxcbiAgICBhZnRlcjogJ1xcbicsXG4gICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgfSlcblxuICBpZiAoL15bXFx0IF0vLnRlc3QodmFsdWUpKSB7XG4gICAgLy8gVG8gZG86IHdoYXQgZWZmZWN0IGhhcyB0aGUgY2hhcmFjdGVyIHJlZmVyZW5jZSBvbiB0cmFja2luZz9cbiAgICB2YWx1ZSA9IGVuY29kZUNoYXJhY3RlclJlZmVyZW5jZSh2YWx1ZS5jaGFyQ29kZUF0KDApKSArIHZhbHVlLnNsaWNlKDEpXG4gIH1cblxuICB2YWx1ZSA9IHZhbHVlID8gc2VxdWVuY2UgKyAnICcgKyB2YWx1ZSA6IHNlcXVlbmNlXG5cbiAgaWYgKHN0YXRlLm9wdGlvbnMuY2xvc2VBdHgpIHtcbiAgICB2YWx1ZSArPSAnICcgKyBzZXF1ZW5jZVxuICB9XG5cbiAgc3ViZXhpdCgpXG4gIGV4aXQoKVxuXG4gIHJldHVybiB2YWx1ZVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtIdG1sfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5odG1sLnBlZWsgPSBodG1sUGVla1xuXG4vKipcbiAqIEBwYXJhbSB7SHRtbH0gbm9kZVxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGh0bWwobm9kZSkge1xuICByZXR1cm4gbm9kZS52YWx1ZSB8fCAnJ1xufVxuXG4vKipcbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGh0bWxQZWVrKCkge1xuICByZXR1cm4gJzwnXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0luZm8sIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7SW1hZ2UsIFBhcmVudHN9IGZyb20gJ21kYXN0J1xuICovXG5cbmltcG9ydCB7Y2hlY2tRdW90ZX0gZnJvbSAnLi4vdXRpbC9jaGVjay1xdW90ZS5qcydcblxuaW1hZ2UucGVlayA9IGltYWdlUGVla1xuXG4vKipcbiAqIEBwYXJhbSB7SW1hZ2V9IG5vZGVcbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gX1xuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEBwYXJhbSB7SW5mb30gaW5mb1xuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGltYWdlKG5vZGUsIF8sIHN0YXRlLCBpbmZvKSB7XG4gIGNvbnN0IHF1b3RlID0gY2hlY2tRdW90ZShzdGF0ZSlcbiAgY29uc3Qgc3VmZml4ID0gcXVvdGUgPT09ICdcIicgPyAnUXVvdGUnIDogJ0Fwb3N0cm9waGUnXG4gIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignaW1hZ2UnKVxuICBsZXQgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdsYWJlbCcpXG4gIGNvbnN0IHRyYWNrZXIgPSBzdGF0ZS5jcmVhdGVUcmFja2VyKGluZm8pXG4gIGxldCB2YWx1ZSA9IHRyYWNrZXIubW92ZSgnIVsnKVxuICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgc3RhdGUuc2FmZShub2RlLmFsdCwge2JlZm9yZTogdmFsdWUsIGFmdGVyOiAnXScsIC4uLnRyYWNrZXIuY3VycmVudCgpfSlcbiAgKVxuICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJ10oJylcblxuICBzdWJleGl0KClcblxuICBpZiAoXG4gICAgLy8gSWYgdGhlcmXigJlzIG5vIHVybCBidXQgdGhlcmUgaXMgYSB0aXRsZeKAplxuICAgICghbm9kZS51cmwgJiYgbm9kZS50aXRsZSkgfHxcbiAgICAvLyBJZiB0aGVyZSBhcmUgY29udHJvbCBjaGFyYWN0ZXJzIG9yIHdoaXRlc3BhY2UuXG4gICAgL1tcXDAtIFxcdTAwN0ZdLy50ZXN0KG5vZGUudXJsKVxuICApIHtcbiAgICBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ2Rlc3RpbmF0aW9uTGl0ZXJhbCcpXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCc8JylcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgICBzdGF0ZS5zYWZlKG5vZGUudXJsLCB7YmVmb3JlOiB2YWx1ZSwgYWZ0ZXI6ICc+JywgLi4udHJhY2tlci5jdXJyZW50KCl9KVxuICAgIClcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJz4nKVxuICB9IGVsc2Uge1xuICAgIC8vIE5vIHdoaXRlc3BhY2UsIHJhdyBpcyBwcmV0dGllci5cbiAgICBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ2Rlc3RpbmF0aW9uUmF3JylcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgICBzdGF0ZS5zYWZlKG5vZGUudXJsLCB7XG4gICAgICAgIGJlZm9yZTogdmFsdWUsXG4gICAgICAgIGFmdGVyOiBub2RlLnRpdGxlID8gJyAnIDogJyknLFxuICAgICAgICAuLi50cmFja2VyLmN1cnJlbnQoKVxuICAgICAgfSlcbiAgICApXG4gIH1cblxuICBzdWJleGl0KClcblxuICBpZiAobm9kZS50aXRsZSkge1xuICAgIHN1YmV4aXQgPSBzdGF0ZS5lbnRlcihgdGl0bGUke3N1ZmZpeH1gKVxuICAgIHZhbHVlICs9IHRyYWNrZXIubW92ZSgnICcgKyBxdW90ZSlcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoXG4gICAgICBzdGF0ZS5zYWZlKG5vZGUudGl0bGUsIHtcbiAgICAgICAgYmVmb3JlOiB2YWx1ZSxcbiAgICAgICAgYWZ0ZXI6IHF1b3RlLFxuICAgICAgICAuLi50cmFja2VyLmN1cnJlbnQoKVxuICAgICAgfSlcbiAgICApXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKHF1b3RlKVxuICAgIHN1YmV4aXQoKVxuICB9XG5cbiAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCcpJylcbiAgZXhpdCgpXG5cbiAgcmV0dXJuIHZhbHVlXG59XG5cbi8qKlxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gaW1hZ2VQZWVrKCkge1xuICByZXR1cm4gJyEnXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0luZm8sIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7SW1hZ2VSZWZlcmVuY2UsIFBhcmVudHN9IGZyb20gJ21kYXN0J1xuICovXG5cbmltYWdlUmVmZXJlbmNlLnBlZWsgPSBpbWFnZVJlZmVyZW5jZVBlZWtcblxuLyoqXG4gKiBAcGFyYW0ge0ltYWdlUmVmZXJlbmNlfSBub2RlXG4gKiBAcGFyYW0ge1BhcmVudHMgfCB1bmRlZmluZWR9IF9cbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcGFyYW0ge0luZm99IGluZm9cbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbWFnZVJlZmVyZW5jZShub2RlLCBfLCBzdGF0ZSwgaW5mbykge1xuICBjb25zdCB0eXBlID0gbm9kZS5yZWZlcmVuY2VUeXBlXG4gIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignaW1hZ2VSZWZlcmVuY2UnKVxuICBsZXQgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdsYWJlbCcpXG4gIGNvbnN0IHRyYWNrZXIgPSBzdGF0ZS5jcmVhdGVUcmFja2VyKGluZm8pXG4gIGxldCB2YWx1ZSA9IHRyYWNrZXIubW92ZSgnIVsnKVxuICBjb25zdCBhbHQgPSBzdGF0ZS5zYWZlKG5vZGUuYWx0LCB7XG4gICAgYmVmb3JlOiB2YWx1ZSxcbiAgICBhZnRlcjogJ10nLFxuICAgIC4uLnRyYWNrZXIuY3VycmVudCgpXG4gIH0pXG4gIHZhbHVlICs9IHRyYWNrZXIubW92ZShhbHQgKyAnXVsnKVxuXG4gIHN1YmV4aXQoKVxuICAvLyBIaWRlIHRoZSBmYWN0IHRoYXQgd2XigJlyZSBpbiBwaHJhc2luZywgYmVjYXVzZSBlc2NhcGVzIGRvbuKAmXQgd29yay5cbiAgY29uc3Qgc3RhY2sgPSBzdGF0ZS5zdGFja1xuICBzdGF0ZS5zdGFjayA9IFtdXG4gIHN1YmV4aXQgPSBzdGF0ZS5lbnRlcigncmVmZXJlbmNlJylcbiAgLy8gTm90ZTogZm9yIHByb3BlciB0cmFja2luZywgd2Ugc2hvdWxkIHJlc2V0IHRoZSBvdXRwdXQgcG9zaXRpb25zIHdoZW4gd2UgZW5kXG4gIC8vIHVwIG1ha2luZyBhIGBzaG9ydGN1dGAgcmVmZXJlbmNlLCBiZWNhdXNlIHRoZW4gdGhlcmUgaXMgbm8gYnJhY2Ugb3V0cHV0LlxuICAvLyBQcmFjdGljYWxseSwgaW4gdGhhdCBjYXNlLCB0aGVyZSBpcyBubyBjb250ZW50LCBzbyBpdCBkb2VzbuKAmXQgbWF0dGVyIHRoYXRcbiAgLy8gd2XigJl2ZSB0cmFja2VkIG9uZSB0b28gbWFueSBjaGFyYWN0ZXJzLlxuICBjb25zdCByZWZlcmVuY2UgPSBzdGF0ZS5zYWZlKHN0YXRlLmFzc29jaWF0aW9uSWQobm9kZSksIHtcbiAgICBiZWZvcmU6IHZhbHVlLFxuICAgIGFmdGVyOiAnXScsXG4gICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgfSlcbiAgc3ViZXhpdCgpXG4gIHN0YXRlLnN0YWNrID0gc3RhY2tcbiAgZXhpdCgpXG5cbiAgaWYgKHR5cGUgPT09ICdmdWxsJyB8fCAhYWx0IHx8IGFsdCAhPT0gcmVmZXJlbmNlKSB7XG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKHJlZmVyZW5jZSArICddJylcbiAgfSBlbHNlIGlmICh0eXBlID09PSAnc2hvcnRjdXQnKSB7XG4gICAgLy8gUmVtb3ZlIHRoZSB1bndhbnRlZCBgW2AuXG4gICAgdmFsdWUgPSB2YWx1ZS5zbGljZSgwLCAtMSlcbiAgfSBlbHNlIHtcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJ10nKVxuICB9XG5cbiAgcmV0dXJuIHZhbHVlXG59XG5cbi8qKlxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gaW1hZ2VSZWZlcmVuY2VQZWVrKCkge1xuICByZXR1cm4gJyEnXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge1N0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7SW5saW5lQ29kZSwgUGFyZW50c30gZnJvbSAnbWRhc3QnXG4gKi9cblxuaW5saW5lQ29kZS5wZWVrID0gaW5saW5lQ29kZVBlZWtcblxuLyoqXG4gKiBAcGFyYW0ge0lubGluZUNvZGV9IG5vZGVcbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gX1xuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbmxpbmVDb2RlKG5vZGUsIF8sIHN0YXRlKSB7XG4gIGxldCB2YWx1ZSA9IG5vZGUudmFsdWUgfHwgJydcbiAgbGV0IHNlcXVlbmNlID0gJ2AnXG4gIGxldCBpbmRleCA9IC0xXG5cbiAgLy8gSWYgdGhlcmUgaXMgYSBzaW5nbGUgZ3JhdmUgYWNjZW50IG9uIGl0cyBvd24gaW4gdGhlIGNvZGUsIHVzZSBhIGZlbmNlIG9mXG4gIC8vIHR3by5cbiAgLy8gSWYgdGhlcmUgYXJlIHR3byBpbiBhIHJvdywgdXNlIG9uZS5cbiAgd2hpbGUgKG5ldyBSZWdFeHAoJyhefFteYF0pJyArIHNlcXVlbmNlICsgJyhbXmBdfCQpJykudGVzdCh2YWx1ZSkpIHtcbiAgICBzZXF1ZW5jZSArPSAnYCdcbiAgfVxuXG4gIC8vIElmIHRoaXMgaXMgbm90IGp1c3Qgc3BhY2VzIG9yIGVvbHMgKHRhYnMgZG9u4oCZdCBjb3VudCksIGFuZCBlaXRoZXIgdGhlXG4gIC8vIGZpcnN0IG9yIGxhc3QgY2hhcmFjdGVyIGFyZSBhIHNwYWNlLCBlb2wsIG9yIHRpY2ssIHRoZW4gcGFkIHdpdGggc3BhY2VzLlxuICBpZiAoXG4gICAgL1teIFxcclxcbl0vLnRlc3QodmFsdWUpICYmXG4gICAgKCgvXlsgXFxyXFxuXS8udGVzdCh2YWx1ZSkgJiYgL1sgXFxyXFxuXSQvLnRlc3QodmFsdWUpKSB8fCAvXmB8YCQvLnRlc3QodmFsdWUpKVxuICApIHtcbiAgICB2YWx1ZSA9ICcgJyArIHZhbHVlICsgJyAnXG4gIH1cblxuICAvLyBXZSBoYXZlIGEgcG90ZW50aWFsIHByb2JsZW06IGNlcnRhaW4gY2hhcmFjdGVycyBhZnRlciBlb2xzIGNvdWxkIHJlc3VsdCBpblxuICAvLyBibG9ja3MgYmVpbmcgc2Vlbi5cbiAgLy8gRm9yIGV4YW1wbGUsIGlmIHNvbWVvbmUgaW5qZWN0ZWQgdGhlIHN0cmluZyBgJ1xcbiMgYidgLCB0aGVuIHRoYXQgd291bGRcbiAgLy8gcmVzdWx0IGluIGFuIEFUWCBoZWFkaW5nLlxuICAvLyBXZSBjYW7igJl0IGVzY2FwZSBjaGFyYWN0ZXJzIGluIGBpbmxpbmVDb2RlYCwgYnV0IGJlY2F1c2UgZW9scyBhcmVcbiAgLy8gdHJhbnNmb3JtZWQgdG8gc3BhY2VzIHdoZW4gZ29pbmcgZnJvbSBtYXJrZG93biB0byBIVE1MIGFueXdheSwgd2UgY2FuIHN3YXBcbiAgLy8gdGhlbSBvdXQuXG4gIHdoaWxlICgrK2luZGV4IDwgc3RhdGUudW5zYWZlLmxlbmd0aCkge1xuICAgIGNvbnN0IHBhdHRlcm4gPSBzdGF0ZS51bnNhZmVbaW5kZXhdXG4gICAgY29uc3QgZXhwcmVzc2lvbiA9IHN0YXRlLmNvbXBpbGVQYXR0ZXJuKHBhdHRlcm4pXG4gICAgLyoqIEB0eXBlIHtSZWdFeHBFeGVjQXJyYXkgfCBudWxsfSAqL1xuICAgIGxldCBtYXRjaFxuXG4gICAgLy8gT25seSBsb29rIGZvciBgYXRCcmVha2BzLlxuICAgIC8vIEJ0dzogbm90ZSB0aGF0IGBhdEJyZWFrYCBwYXR0ZXJucyB3aWxsIGFsd2F5cyBzdGFydCB0aGUgcmVnZXggYXQgTEYgb3JcbiAgICAvLyBDUi5cbiAgICBpZiAoIXBhdHRlcm4uYXRCcmVhaykgY29udGludWVcblxuICAgIHdoaWxlICgobWF0Y2ggPSBleHByZXNzaW9uLmV4ZWModmFsdWUpKSkge1xuICAgICAgbGV0IHBvc2l0aW9uID0gbWF0Y2guaW5kZXhcblxuICAgICAgLy8gU3VwcG9ydCBDUkxGIChwYXR0ZXJucyBvbmx5IGxvb2sgZm9yIG9uZSBvZiB0aGUgY2hhcmFjdGVycykuXG4gICAgICBpZiAoXG4gICAgICAgIHZhbHVlLmNoYXJDb2RlQXQocG9zaXRpb24pID09PSAxMCAvKiBgXFxuYCAqLyAmJlxuICAgICAgICB2YWx1ZS5jaGFyQ29kZUF0KHBvc2l0aW9uIC0gMSkgPT09IDEzIC8qIGBcXHJgICovXG4gICAgICApIHtcbiAgICAgICAgcG9zaXRpb24tLVxuICAgICAgfVxuXG4gICAgICB2YWx1ZSA9IHZhbHVlLnNsaWNlKDAsIHBvc2l0aW9uKSArICcgJyArIHZhbHVlLnNsaWNlKG1hdGNoLmluZGV4ICsgMSlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gc2VxdWVuY2UgKyB2YWx1ZSArIHNlcXVlbmNlXG59XG5cbi8qKlxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gaW5saW5lQ29kZVBlZWsoKSB7XG4gIHJldHVybiAnYCdcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7U3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKiBAaW1wb3J0IHtMaW5rfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge3RvU3RyaW5nfSBmcm9tICdtZGFzdC11dGlsLXRvLXN0cmluZydcblxuLyoqXG4gKiBAcGFyYW0ge0xpbmt9IG5vZGVcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdExpbmtBc0F1dG9saW5rKG5vZGUsIHN0YXRlKSB7XG4gIGNvbnN0IHJhdyA9IHRvU3RyaW5nKG5vZGUpXG5cbiAgcmV0dXJuIEJvb2xlYW4oXG4gICAgIXN0YXRlLm9wdGlvbnMucmVzb3VyY2VMaW5rICYmXG4gICAgICAvLyBJZiB0aGVyZeKAmXMgYSB1cmzigKZcbiAgICAgIG5vZGUudXJsICYmXG4gICAgICAvLyBBbmQgdGhlcmXigJlzIGEgbm8gdGl0bGXigKZcbiAgICAgICFub2RlLnRpdGxlICYmXG4gICAgICAvLyBBbmQgdGhlIGNvbnRlbnQgb2YgYG5vZGVgIGlzIGEgc2luZ2xlIHRleHQgbm9kZeKAplxuICAgICAgbm9kZS5jaGlsZHJlbiAmJlxuICAgICAgbm9kZS5jaGlsZHJlbi5sZW5ndGggPT09IDEgJiZcbiAgICAgIG5vZGUuY2hpbGRyZW5bMF0udHlwZSA9PT0gJ3RleHQnICYmXG4gICAgICAvLyBBbmQgaWYgdGhlIHVybCBpcyB0aGUgc2FtZSBhcyB0aGUgY29udGVudOKAplxuICAgICAgKHJhdyA9PT0gbm9kZS51cmwgfHwgJ21haWx0bzonICsgcmF3ID09PSBub2RlLnVybCkgJiZcbiAgICAgIC8vIEFuZCB0aGF0IHN0YXJ0cyB3LyBhIHByb3RvY29s4oCmXG4gICAgICAvXlthLXpdW2EteisuLV0rOi9pLnRlc3Qobm9kZS51cmwpICYmXG4gICAgICAvLyBBbmQgdGhhdCBkb2VzbuKAmXQgY29udGFpbiBBU0NJSSBjb250cm9sIGNvZGVzIChjaGFyYWN0ZXIgZXNjYXBlcyBhbmRcbiAgICAgIC8vIHJlZmVyZW5jZXMgZG9u4oCZdCB3b3JrKSwgc3BhY2UsIG9yIGFuZ2xlIGJyYWNrZXRz4oCmXG4gICAgICAhL1tcXDAtIDw+XFx1MDA3Rl0vLnRlc3Qobm9kZS51cmwpXG4gIClcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7SW5mbywgU3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKiBAaW1wb3J0IHtMaW5rLCBQYXJlbnRzfSBmcm9tICdtZGFzdCdcbiAqIEBpbXBvcnQge0V4aXR9IGZyb20gJy4uL3R5cGVzLmpzJ1xuICovXG5cbmltcG9ydCB7Y2hlY2tRdW90ZX0gZnJvbSAnLi4vdXRpbC9jaGVjay1xdW90ZS5qcydcbmltcG9ydCB7Zm9ybWF0TGlua0FzQXV0b2xpbmt9IGZyb20gJy4uL3V0aWwvZm9ybWF0LWxpbmstYXMtYXV0b2xpbmsuanMnXG5cbmxpbmsucGVlayA9IGxpbmtQZWVrXG5cbi8qKlxuICogQHBhcmFtIHtMaW5rfSBub2RlXG4gKiBAcGFyYW0ge1BhcmVudHMgfCB1bmRlZmluZWR9IF9cbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcGFyYW0ge0luZm99IGluZm9cbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsaW5rKG5vZGUsIF8sIHN0YXRlLCBpbmZvKSB7XG4gIGNvbnN0IHF1b3RlID0gY2hlY2tRdW90ZShzdGF0ZSlcbiAgY29uc3Qgc3VmZml4ID0gcXVvdGUgPT09ICdcIicgPyAnUXVvdGUnIDogJ0Fwb3N0cm9waGUnXG4gIGNvbnN0IHRyYWNrZXIgPSBzdGF0ZS5jcmVhdGVUcmFja2VyKGluZm8pXG4gIC8qKiBAdHlwZSB7RXhpdH0gKi9cbiAgbGV0IGV4aXRcbiAgLyoqIEB0eXBlIHtFeGl0fSAqL1xuICBsZXQgc3ViZXhpdFxuXG4gIGlmIChmb3JtYXRMaW5rQXNBdXRvbGluayhub2RlLCBzdGF0ZSkpIHtcbiAgICAvLyBIaWRlIHRoZSBmYWN0IHRoYXQgd2XigJlyZSBpbiBwaHJhc2luZywgYmVjYXVzZSBlc2NhcGVzIGRvbuKAmXQgd29yay5cbiAgICBjb25zdCBzdGFjayA9IHN0YXRlLnN0YWNrXG4gICAgc3RhdGUuc3RhY2sgPSBbXVxuICAgIGV4aXQgPSBzdGF0ZS5lbnRlcignYXV0b2xpbmsnKVxuICAgIGxldCB2YWx1ZSA9IHRyYWNrZXIubW92ZSgnPCcpXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKFxuICAgICAgc3RhdGUuY29udGFpbmVyUGhyYXNpbmcobm9kZSwge1xuICAgICAgICBiZWZvcmU6IHZhbHVlLFxuICAgICAgICBhZnRlcjogJz4nLFxuICAgICAgICAuLi50cmFja2VyLmN1cnJlbnQoKVxuICAgICAgfSlcbiAgICApXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCc+JylcbiAgICBleGl0KClcbiAgICBzdGF0ZS5zdGFjayA9IHN0YWNrXG4gICAgcmV0dXJuIHZhbHVlXG4gIH1cblxuICBleGl0ID0gc3RhdGUuZW50ZXIoJ2xpbmsnKVxuICBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ2xhYmVsJylcbiAgbGV0IHZhbHVlID0gdHJhY2tlci5tb3ZlKCdbJylcbiAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKFxuICAgIHN0YXRlLmNvbnRhaW5lclBocmFzaW5nKG5vZGUsIHtcbiAgICAgIGJlZm9yZTogdmFsdWUsXG4gICAgICBhZnRlcjogJ10oJyxcbiAgICAgIC4uLnRyYWNrZXIuY3VycmVudCgpXG4gICAgfSlcbiAgKVxuICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJ10oJylcbiAgc3ViZXhpdCgpXG5cbiAgaWYgKFxuICAgIC8vIElmIHRoZXJl4oCZcyBubyB1cmwgYnV0IHRoZXJlIGlzIGEgdGl0bGXigKZcbiAgICAoIW5vZGUudXJsICYmIG5vZGUudGl0bGUpIHx8XG4gICAgLy8gSWYgdGhlcmUgYXJlIGNvbnRyb2wgY2hhcmFjdGVycyBvciB3aGl0ZXNwYWNlLlxuICAgIC9bXFwwLSBcXHUwMDdGXS8udGVzdChub2RlLnVybClcbiAgKSB7XG4gICAgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdkZXN0aW5hdGlvbkxpdGVyYWwnKVxuICAgIHZhbHVlICs9IHRyYWNrZXIubW92ZSgnPCcpXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKFxuICAgICAgc3RhdGUuc2FmZShub2RlLnVybCwge2JlZm9yZTogdmFsdWUsIGFmdGVyOiAnPicsIC4uLnRyYWNrZXIuY3VycmVudCgpfSlcbiAgICApXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCc+JylcbiAgfSBlbHNlIHtcbiAgICAvLyBObyB3aGl0ZXNwYWNlLCByYXcgaXMgcHJldHRpZXIuXG4gICAgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdkZXN0aW5hdGlvblJhdycpXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKFxuICAgICAgc3RhdGUuc2FmZShub2RlLnVybCwge1xuICAgICAgICBiZWZvcmU6IHZhbHVlLFxuICAgICAgICBhZnRlcjogbm9kZS50aXRsZSA/ICcgJyA6ICcpJyxcbiAgICAgICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgICAgIH0pXG4gICAgKVxuICB9XG5cbiAgc3ViZXhpdCgpXG5cbiAgaWYgKG5vZGUudGl0bGUpIHtcbiAgICBzdWJleGl0ID0gc3RhdGUuZW50ZXIoYHRpdGxlJHtzdWZmaXh9YClcbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJyAnICsgcXVvdGUpXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKFxuICAgICAgc3RhdGUuc2FmZShub2RlLnRpdGxlLCB7XG4gICAgICAgIGJlZm9yZTogdmFsdWUsXG4gICAgICAgIGFmdGVyOiBxdW90ZSxcbiAgICAgICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgICAgIH0pXG4gICAgKVxuICAgIHZhbHVlICs9IHRyYWNrZXIubW92ZShxdW90ZSlcbiAgICBzdWJleGl0KClcbiAgfVxuXG4gIHZhbHVlICs9IHRyYWNrZXIubW92ZSgnKScpXG5cbiAgZXhpdCgpXG4gIHJldHVybiB2YWx1ZVxufVxuXG4vKipcbiAqIEBwYXJhbSB7TGlua30gbm9kZVxuICogQHBhcmFtIHtQYXJlbnRzIHwgdW5kZWZpbmVkfSBfXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gbGlua1BlZWsobm9kZSwgXywgc3RhdGUpIHtcbiAgcmV0dXJuIGZvcm1hdExpbmtBc0F1dG9saW5rKG5vZGUsIHN0YXRlKSA/ICc8JyA6ICdbJ1xufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtJbmZvLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqIEBpbXBvcnQge0xpbmtSZWZlcmVuY2UsIFBhcmVudHN9IGZyb20gJ21kYXN0J1xuICovXG5cbmxpbmtSZWZlcmVuY2UucGVlayA9IGxpbmtSZWZlcmVuY2VQZWVrXG5cbi8qKlxuICogQHBhcmFtIHtMaW5rUmVmZXJlbmNlfSBub2RlXG4gKiBAcGFyYW0ge1BhcmVudHMgfCB1bmRlZmluZWR9IF9cbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcGFyYW0ge0luZm99IGluZm9cbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsaW5rUmVmZXJlbmNlKG5vZGUsIF8sIHN0YXRlLCBpbmZvKSB7XG4gIGNvbnN0IHR5cGUgPSBub2RlLnJlZmVyZW5jZVR5cGVcbiAgY29uc3QgZXhpdCA9IHN0YXRlLmVudGVyKCdsaW5rUmVmZXJlbmNlJylcbiAgbGV0IHN1YmV4aXQgPSBzdGF0ZS5lbnRlcignbGFiZWwnKVxuICBjb25zdCB0cmFja2VyID0gc3RhdGUuY3JlYXRlVHJhY2tlcihpbmZvKVxuICBsZXQgdmFsdWUgPSB0cmFja2VyLm1vdmUoJ1snKVxuICBjb25zdCB0ZXh0ID0gc3RhdGUuY29udGFpbmVyUGhyYXNpbmcobm9kZSwge1xuICAgIGJlZm9yZTogdmFsdWUsXG4gICAgYWZ0ZXI6ICddJyxcbiAgICAuLi50cmFja2VyLmN1cnJlbnQoKVxuICB9KVxuICB2YWx1ZSArPSB0cmFja2VyLm1vdmUodGV4dCArICddWycpXG5cbiAgc3ViZXhpdCgpXG4gIC8vIEhpZGUgdGhlIGZhY3QgdGhhdCB3ZeKAmXJlIGluIHBocmFzaW5nLCBiZWNhdXNlIGVzY2FwZXMgZG9u4oCZdCB3b3JrLlxuICBjb25zdCBzdGFjayA9IHN0YXRlLnN0YWNrXG4gIHN0YXRlLnN0YWNrID0gW11cbiAgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdyZWZlcmVuY2UnKVxuICAvLyBOb3RlOiBmb3IgcHJvcGVyIHRyYWNraW5nLCB3ZSBzaG91bGQgcmVzZXQgdGhlIG91dHB1dCBwb3NpdGlvbnMgd2hlbiB3ZSBlbmRcbiAgLy8gdXAgbWFraW5nIGEgYHNob3J0Y3V0YCByZWZlcmVuY2UsIGJlY2F1c2UgdGhlbiB0aGVyZSBpcyBubyBicmFjZSBvdXRwdXQuXG4gIC8vIFByYWN0aWNhbGx5LCBpbiB0aGF0IGNhc2UsIHRoZXJlIGlzIG5vIGNvbnRlbnQsIHNvIGl0IGRvZXNu4oCZdCBtYXR0ZXIgdGhhdFxuICAvLyB3ZeKAmXZlIHRyYWNrZWQgb25lIHRvbyBtYW55IGNoYXJhY3RlcnMuXG4gIGNvbnN0IHJlZmVyZW5jZSA9IHN0YXRlLnNhZmUoc3RhdGUuYXNzb2NpYXRpb25JZChub2RlKSwge1xuICAgIGJlZm9yZTogdmFsdWUsXG4gICAgYWZ0ZXI6ICddJyxcbiAgICAuLi50cmFja2VyLmN1cnJlbnQoKVxuICB9KVxuICBzdWJleGl0KClcbiAgc3RhdGUuc3RhY2sgPSBzdGFja1xuICBleGl0KClcblxuICBpZiAodHlwZSA9PT0gJ2Z1bGwnIHx8ICF0ZXh0IHx8IHRleHQgIT09IHJlZmVyZW5jZSkge1xuICAgIHZhbHVlICs9IHRyYWNrZXIubW92ZShyZWZlcmVuY2UgKyAnXScpXG4gIH0gZWxzZSBpZiAodHlwZSA9PT0gJ3Nob3J0Y3V0Jykge1xuICAgIC8vIFJlbW92ZSB0aGUgdW53YW50ZWQgYFtgLlxuICAgIHZhbHVlID0gdmFsdWUuc2xpY2UoMCwgLTEpXG4gIH0gZWxzZSB7XG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKCddJylcbiAgfVxuXG4gIHJldHVybiB2YWx1ZVxufVxuXG4vKipcbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGxpbmtSZWZlcmVuY2VQZWVrKCkge1xuICByZXR1cm4gJ1snXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge09wdGlvbnMsIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICovXG5cbi8qKlxuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEByZXR1cm5zIHtFeGNsdWRlPE9wdGlvbnNbJ2J1bGxldCddLCBudWxsIHwgdW5kZWZpbmVkPn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrQnVsbGV0KHN0YXRlKSB7XG4gIGNvbnN0IG1hcmtlciA9IHN0YXRlLm9wdGlvbnMuYnVsbGV0IHx8ICcqJ1xuXG4gIGlmIChtYXJrZXIgIT09ICcqJyAmJiBtYXJrZXIgIT09ICcrJyAmJiBtYXJrZXIgIT09ICctJykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdDYW5ub3Qgc2VyaWFsaXplIGl0ZW1zIHdpdGggYCcgK1xuICAgICAgICBtYXJrZXIgK1xuICAgICAgICAnYCBmb3IgYG9wdGlvbnMuYnVsbGV0YCwgZXhwZWN0ZWQgYCpgLCBgK2AsIG9yIGAtYCdcbiAgICApXG4gIH1cblxuICByZXR1cm4gbWFya2VyXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge09wdGlvbnMsIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICovXG5cbmltcG9ydCB7Y2hlY2tCdWxsZXR9IGZyb20gJy4vY2hlY2stYnVsbGV0LmpzJ1xuXG4vKipcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7RXhjbHVkZTxPcHRpb25zWydidWxsZXQnXSwgbnVsbCB8IHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja0J1bGxldE90aGVyKHN0YXRlKSB7XG4gIGNvbnN0IGJ1bGxldCA9IGNoZWNrQnVsbGV0KHN0YXRlKVxuICBjb25zdCBidWxsZXRPdGhlciA9IHN0YXRlLm9wdGlvbnMuYnVsbGV0T3RoZXJcblxuICBpZiAoIWJ1bGxldE90aGVyKSB7XG4gICAgcmV0dXJuIGJ1bGxldCA9PT0gJyonID8gJy0nIDogJyonXG4gIH1cblxuICBpZiAoYnVsbGV0T3RoZXIgIT09ICcqJyAmJiBidWxsZXRPdGhlciAhPT0gJysnICYmIGJ1bGxldE90aGVyICE9PSAnLScpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAnQ2Fubm90IHNlcmlhbGl6ZSBpdGVtcyB3aXRoIGAnICtcbiAgICAgICAgYnVsbGV0T3RoZXIgK1xuICAgICAgICAnYCBmb3IgYG9wdGlvbnMuYnVsbGV0T3RoZXJgLCBleHBlY3RlZCBgKmAsIGArYCwgb3IgYC1gJ1xuICAgIClcbiAgfVxuXG4gIGlmIChidWxsZXRPdGhlciA9PT0gYnVsbGV0KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ0V4cGVjdGVkIGBidWxsZXRgIChgJyArXG4gICAgICAgIGJ1bGxldCArXG4gICAgICAgICdgKSBhbmQgYGJ1bGxldE90aGVyYCAoYCcgK1xuICAgICAgICBidWxsZXRPdGhlciArXG4gICAgICAgICdgKSB0byBiZSBkaWZmZXJlbnQnXG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIGJ1bGxldE90aGVyXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge09wdGlvbnMsIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICovXG5cbi8qKlxuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEByZXR1cm5zIHtFeGNsdWRlPE9wdGlvbnNbJ2J1bGxldE9yZGVyZWQnXSwgbnVsbCB8IHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja0J1bGxldE9yZGVyZWQoc3RhdGUpIHtcbiAgY29uc3QgbWFya2VyID0gc3RhdGUub3B0aW9ucy5idWxsZXRPcmRlcmVkIHx8ICcuJ1xuXG4gIGlmIChtYXJrZXIgIT09ICcuJyAmJiBtYXJrZXIgIT09ICcpJykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdDYW5ub3Qgc2VyaWFsaXplIGl0ZW1zIHdpdGggYCcgK1xuICAgICAgICBtYXJrZXIgK1xuICAgICAgICAnYCBmb3IgYG9wdGlvbnMuYnVsbGV0T3JkZXJlZGAsIGV4cGVjdGVkIGAuYCBvciBgKWAnXG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIG1hcmtlclxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtPcHRpb25zLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqL1xuXG4vKipcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7RXhjbHVkZTxPcHRpb25zWydydWxlJ10sIG51bGwgfCB1bmRlZmluZWQ+fVxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tSdWxlKHN0YXRlKSB7XG4gIGNvbnN0IG1hcmtlciA9IHN0YXRlLm9wdGlvbnMucnVsZSB8fCAnKidcblxuICBpZiAobWFya2VyICE9PSAnKicgJiYgbWFya2VyICE9PSAnLScgJiYgbWFya2VyICE9PSAnXycpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAnQ2Fubm90IHNlcmlhbGl6ZSBydWxlcyB3aXRoIGAnICtcbiAgICAgICAgbWFya2VyICtcbiAgICAgICAgJ2AgZm9yIGBvcHRpb25zLnJ1bGVgLCBleHBlY3RlZCBgKmAsIGAtYCwgb3IgYF9gJ1xuICAgIClcbiAgfVxuXG4gIHJldHVybiBtYXJrZXJcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7SW5mbywgU3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKiBAaW1wb3J0IHtMaXN0LCBQYXJlbnRzfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge2NoZWNrQnVsbGV0fSBmcm9tICcuLi91dGlsL2NoZWNrLWJ1bGxldC5qcydcbmltcG9ydCB7Y2hlY2tCdWxsZXRPdGhlcn0gZnJvbSAnLi4vdXRpbC9jaGVjay1idWxsZXQtb3RoZXIuanMnXG5pbXBvcnQge2NoZWNrQnVsbGV0T3JkZXJlZH0gZnJvbSAnLi4vdXRpbC9jaGVjay1idWxsZXQtb3JkZXJlZC5qcydcbmltcG9ydCB7Y2hlY2tSdWxlfSBmcm9tICcuLi91dGlsL2NoZWNrLXJ1bGUuanMnXG5cbi8qKlxuICogQHBhcmFtIHtMaXN0fSBub2RlXG4gKiBAcGFyYW0ge1BhcmVudHMgfCB1bmRlZmluZWR9IHBhcmVudFxuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEBwYXJhbSB7SW5mb30gaW5mb1xuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxpc3Qobm9kZSwgcGFyZW50LCBzdGF0ZSwgaW5mbykge1xuICBjb25zdCBleGl0ID0gc3RhdGUuZW50ZXIoJ2xpc3QnKVxuICBjb25zdCBidWxsZXRDdXJyZW50ID0gc3RhdGUuYnVsbGV0Q3VycmVudFxuICAvKiogQHR5cGUge3N0cmluZ30gKi9cbiAgbGV0IGJ1bGxldCA9IG5vZGUub3JkZXJlZCA/IGNoZWNrQnVsbGV0T3JkZXJlZChzdGF0ZSkgOiBjaGVja0J1bGxldChzdGF0ZSlcbiAgLyoqIEB0eXBlIHtzdHJpbmd9ICovXG4gIGNvbnN0IGJ1bGxldE90aGVyID0gbm9kZS5vcmRlcmVkXG4gICAgPyBidWxsZXQgPT09ICcuJ1xuICAgICAgPyAnKSdcbiAgICAgIDogJy4nXG4gICAgOiBjaGVja0J1bGxldE90aGVyKHN0YXRlKVxuICBsZXQgdXNlRGlmZmVyZW50TWFya2VyID1cbiAgICBwYXJlbnQgJiYgc3RhdGUuYnVsbGV0TGFzdFVzZWQgPyBidWxsZXQgPT09IHN0YXRlLmJ1bGxldExhc3RVc2VkIDogZmFsc2VcblxuICBpZiAoIW5vZGUub3JkZXJlZCkge1xuICAgIGNvbnN0IGZpcnN0TGlzdEl0ZW0gPSBub2RlLmNoaWxkcmVuID8gbm9kZS5jaGlsZHJlblswXSA6IHVuZGVmaW5lZFxuXG4gICAgLy8gSWYgdGhlcmXigJlzIGFuIGVtcHR5IGZpcnN0IGxpc3QgaXRlbSBkaXJlY3RseSBpbiB0d28gbGlzdCBpdGVtcyxcbiAgICAvLyB3ZSBoYXZlIHRvIHVzZSBhIGRpZmZlcmVudCBidWxsZXQ6XG4gICAgLy9cbiAgICAvLyBgYGBtYXJrZG93blxuICAgIC8vICogLSAqXG4gICAgLy8gYGBgXG4gICAgLy9cbiAgICAvLyDigKZiZWNhdXNlIG90aGVyd2lzZSBpdCB3b3VsZCBiZWNvbWUgb25lIGJpZyB0aGVtYXRpYyBicmVhay5cbiAgICBpZiAoXG4gICAgICAvLyBCdWxsZXQgY291bGQgYmUgdXNlZCBhcyBhIHRoZW1hdGljIGJyZWFrIG1hcmtlcjpcbiAgICAgIChidWxsZXQgPT09ICcqJyB8fCBidWxsZXQgPT09ICctJykgJiZcbiAgICAgIC8vIEVtcHR5IGZpcnN0IGxpc3QgaXRlbTpcbiAgICAgIGZpcnN0TGlzdEl0ZW0gJiZcbiAgICAgICghZmlyc3RMaXN0SXRlbS5jaGlsZHJlbiB8fCAhZmlyc3RMaXN0SXRlbS5jaGlsZHJlblswXSkgJiZcbiAgICAgIC8vIERpcmVjdGx5IGluIHR3byBvdGhlciBsaXN0IGl0ZW1zOlxuICAgICAgc3RhdGUuc3RhY2tbc3RhdGUuc3RhY2subGVuZ3RoIC0gMV0gPT09ICdsaXN0JyAmJlxuICAgICAgc3RhdGUuc3RhY2tbc3RhdGUuc3RhY2subGVuZ3RoIC0gMl0gPT09ICdsaXN0SXRlbScgJiZcbiAgICAgIHN0YXRlLnN0YWNrW3N0YXRlLnN0YWNrLmxlbmd0aCAtIDNdID09PSAnbGlzdCcgJiZcbiAgICAgIHN0YXRlLnN0YWNrW3N0YXRlLnN0YWNrLmxlbmd0aCAtIDRdID09PSAnbGlzdEl0ZW0nICYmXG4gICAgICAvLyBUaGF0IGFyZSBlYWNoIHRoZSBmaXJzdCBjaGlsZC5cbiAgICAgIHN0YXRlLmluZGV4U3RhY2tbc3RhdGUuaW5kZXhTdGFjay5sZW5ndGggLSAxXSA9PT0gMCAmJlxuICAgICAgc3RhdGUuaW5kZXhTdGFja1tzdGF0ZS5pbmRleFN0YWNrLmxlbmd0aCAtIDJdID09PSAwICYmXG4gICAgICBzdGF0ZS5pbmRleFN0YWNrW3N0YXRlLmluZGV4U3RhY2subGVuZ3RoIC0gM10gPT09IDBcbiAgICApIHtcbiAgICAgIHVzZURpZmZlcmVudE1hcmtlciA9IHRydWVcbiAgICB9XG5cbiAgICAvLyBJZiB0aGVyZeKAmXMgYSB0aGVtYXRpYyBicmVhayBhdCB0aGUgc3RhcnQgb2YgdGhlIGZpcnN0IGxpc3QgaXRlbSxcbiAgICAvLyB3ZSBoYXZlIHRvIHVzZSBhIGRpZmZlcmVudCBidWxsZXQ6XG4gICAgLy9cbiAgICAvLyBgYGBtYXJrZG93blxuICAgIC8vICogLS0tXG4gICAgLy8gYGBgXG4gICAgLy9cbiAgICAvLyDigKZiZWNhdXNlIG90aGVyd2lzZSBpdCB3b3VsZCBiZWNvbWUgb25lIGJpZyB0aGVtYXRpYyBicmVhay5cbiAgICBpZiAoY2hlY2tSdWxlKHN0YXRlKSA9PT0gYnVsbGV0ICYmIGZpcnN0TGlzdEl0ZW0pIHtcbiAgICAgIGxldCBpbmRleCA9IC0xXG5cbiAgICAgIHdoaWxlICgrK2luZGV4IDwgbm9kZS5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgaXRlbSA9IG5vZGUuY2hpbGRyZW5baW5kZXhdXG5cbiAgICAgICAgaWYgKFxuICAgICAgICAgIGl0ZW0gJiZcbiAgICAgICAgICBpdGVtLnR5cGUgPT09ICdsaXN0SXRlbScgJiZcbiAgICAgICAgICBpdGVtLmNoaWxkcmVuICYmXG4gICAgICAgICAgaXRlbS5jaGlsZHJlblswXSAmJlxuICAgICAgICAgIGl0ZW0uY2hpbGRyZW5bMF0udHlwZSA9PT0gJ3RoZW1hdGljQnJlYWsnXG4gICAgICAgICkge1xuICAgICAgICAgIHVzZURpZmZlcmVudE1hcmtlciA9IHRydWVcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaWYgKHVzZURpZmZlcmVudE1hcmtlcikge1xuICAgIGJ1bGxldCA9IGJ1bGxldE90aGVyXG4gIH1cblxuICBzdGF0ZS5idWxsZXRDdXJyZW50ID0gYnVsbGV0XG4gIGNvbnN0IHZhbHVlID0gc3RhdGUuY29udGFpbmVyRmxvdyhub2RlLCBpbmZvKVxuICBzdGF0ZS5idWxsZXRMYXN0VXNlZCA9IGJ1bGxldFxuICBzdGF0ZS5idWxsZXRDdXJyZW50ID0gYnVsbGV0Q3VycmVudFxuICBleGl0KClcbiAgcmV0dXJuIHZhbHVlXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge09wdGlvbnMsIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICovXG5cbi8qKlxuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEByZXR1cm5zIHtFeGNsdWRlPE9wdGlvbnNbJ2xpc3RJdGVtSW5kZW50J10sIG51bGwgfCB1bmRlZmluZWQ+fVxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tMaXN0SXRlbUluZGVudChzdGF0ZSkge1xuICBjb25zdCBzdHlsZSA9IHN0YXRlLm9wdGlvbnMubGlzdEl0ZW1JbmRlbnQgfHwgJ29uZSdcblxuICBpZiAoc3R5bGUgIT09ICd0YWInICYmIHN0eWxlICE9PSAnb25lJyAmJiBzdHlsZSAhPT0gJ21peGVkJykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdDYW5ub3Qgc2VyaWFsaXplIGl0ZW1zIHdpdGggYCcgK1xuICAgICAgICBzdHlsZSArXG4gICAgICAgICdgIGZvciBgb3B0aW9ucy5saXN0SXRlbUluZGVudGAsIGV4cGVjdGVkIGB0YWJgLCBgb25lYCwgb3IgYG1peGVkYCdcbiAgICApXG4gIH1cblxuICByZXR1cm4gc3R5bGVcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7SW5mbywgTWFwLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqIEBpbXBvcnQge0xpc3RJdGVtLCBQYXJlbnRzfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge2NoZWNrQnVsbGV0fSBmcm9tICcuLi91dGlsL2NoZWNrLWJ1bGxldC5qcydcbmltcG9ydCB7Y2hlY2tMaXN0SXRlbUluZGVudH0gZnJvbSAnLi4vdXRpbC9jaGVjay1saXN0LWl0ZW0taW5kZW50LmpzJ1xuXG4vKipcbiAqIEBwYXJhbSB7TGlzdEl0ZW19IG5vZGVcbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gcGFyZW50XG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gbGlzdEl0ZW0obm9kZSwgcGFyZW50LCBzdGF0ZSwgaW5mbykge1xuICBjb25zdCBsaXN0SXRlbUluZGVudCA9IGNoZWNrTGlzdEl0ZW1JbmRlbnQoc3RhdGUpXG4gIGxldCBidWxsZXQgPSBzdGF0ZS5idWxsZXRDdXJyZW50IHx8IGNoZWNrQnVsbGV0KHN0YXRlKVxuXG4gIC8vIEFkZCB0aGUgbWFya2VyIHZhbHVlIGZvciBvcmRlcmVkIGxpc3RzLlxuICBpZiAocGFyZW50ICYmIHBhcmVudC50eXBlID09PSAnbGlzdCcgJiYgcGFyZW50Lm9yZGVyZWQpIHtcbiAgICBidWxsZXQgPVxuICAgICAgKHR5cGVvZiBwYXJlbnQuc3RhcnQgPT09ICdudW1iZXInICYmIHBhcmVudC5zdGFydCA+IC0xXG4gICAgICAgID8gcGFyZW50LnN0YXJ0XG4gICAgICAgIDogMSkgK1xuICAgICAgKHN0YXRlLm9wdGlvbnMuaW5jcmVtZW50TGlzdE1hcmtlciA9PT0gZmFsc2VcbiAgICAgICAgPyAwXG4gICAgICAgIDogcGFyZW50LmNoaWxkcmVuLmluZGV4T2Yobm9kZSkpICtcbiAgICAgIGJ1bGxldFxuICB9XG5cbiAgbGV0IHNpemUgPSBidWxsZXQubGVuZ3RoICsgMVxuXG4gIGlmIChcbiAgICBsaXN0SXRlbUluZGVudCA9PT0gJ3RhYicgfHxcbiAgICAobGlzdEl0ZW1JbmRlbnQgPT09ICdtaXhlZCcgJiZcbiAgICAgICgocGFyZW50ICYmIHBhcmVudC50eXBlID09PSAnbGlzdCcgJiYgcGFyZW50LnNwcmVhZCkgfHwgbm9kZS5zcHJlYWQpKVxuICApIHtcbiAgICBzaXplID0gTWF0aC5jZWlsKHNpemUgLyA0KSAqIDRcbiAgfVxuXG4gIGNvbnN0IHRyYWNrZXIgPSBzdGF0ZS5jcmVhdGVUcmFja2VyKGluZm8pXG4gIHRyYWNrZXIubW92ZShidWxsZXQgKyAnICcucmVwZWF0KHNpemUgLSBidWxsZXQubGVuZ3RoKSlcbiAgdHJhY2tlci5zaGlmdChzaXplKVxuICBjb25zdCBleGl0ID0gc3RhdGUuZW50ZXIoJ2xpc3RJdGVtJylcbiAgY29uc3QgdmFsdWUgPSBzdGF0ZS5pbmRlbnRMaW5lcyhcbiAgICBzdGF0ZS5jb250YWluZXJGbG93KG5vZGUsIHRyYWNrZXIuY3VycmVudCgpKSxcbiAgICBtYXBcbiAgKVxuICBleGl0KClcblxuICByZXR1cm4gdmFsdWVcblxuICAvKiogQHR5cGUge01hcH0gKi9cbiAgZnVuY3Rpb24gbWFwKGxpbmUsIGluZGV4LCBibGFuaykge1xuICAgIGlmIChpbmRleCkge1xuICAgICAgcmV0dXJuIChibGFuayA/ICcnIDogJyAnLnJlcGVhdChzaXplKSkgKyBsaW5lXG4gICAgfVxuXG4gICAgcmV0dXJuIChibGFuayA/IGJ1bGxldCA6IGJ1bGxldCArICcgJy5yZXBlYXQoc2l6ZSAtIGJ1bGxldC5sZW5ndGgpKSArIGxpbmVcbiAgfVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtJbmZvLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqIEBpbXBvcnQge1BhcmFncmFwaCwgUGFyZW50c30gZnJvbSAnbWRhc3QnXG4gKi9cblxuLyoqXG4gKiBAcGFyYW0ge1BhcmFncmFwaH0gbm9kZVxuICogQHBhcmFtIHtQYXJlbnRzIHwgdW5kZWZpbmVkfSBfXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyYWdyYXBoKG5vZGUsIF8sIHN0YXRlLCBpbmZvKSB7XG4gIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcigncGFyYWdyYXBoJylcbiAgY29uc3Qgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCdwaHJhc2luZycpXG4gIGNvbnN0IHZhbHVlID0gc3RhdGUuY29udGFpbmVyUGhyYXNpbmcobm9kZSwgaW5mbylcbiAgc3ViZXhpdCgpXG4gIGV4aXQoKVxuICByZXR1cm4gdmFsdWVcbn1cbiIsIi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QnKS5IdG1sfSBIdG1sXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdCcpLlBocmFzaW5nQ29udGVudH0gUGhyYXNpbmdDb250ZW50XG4gKi9cblxuaW1wb3J0IHtjb252ZXJ0fSBmcm9tICd1bmlzdC11dGlsLWlzJ1xuXG4vKipcbiAqIENoZWNrIGlmIHRoZSBnaXZlbiB2YWx1ZSBpcyAqcGhyYXNpbmcgY29udGVudCouXG4gKlxuICogPiDwn5GJICoqTm90ZSoqOiBFeGNsdWRlcyBgaHRtbGAsIHdoaWNoIGNhbiBiZSBib3RoIHBocmFzaW5nIG9yIGZsb3cuXG4gKlxuICogQHBhcmFtIG5vZGVcbiAqICAgVGhpbmcgdG8gY2hlY2ssIHR5cGljYWxseSBgTm9kZWAuXG4gKiBAcmV0dXJuc1xuICogICBXaGV0aGVyIGB2YWx1ZWAgaXMgcGhyYXNpbmcgY29udGVudC5cbiAqL1xuXG5leHBvcnQgY29uc3QgcGhyYXNpbmcgPVxuICAvKiogQHR5cGUgeyhub2RlPzogdW5rbm93bikgPT4gbm9kZSBpcyBFeGNsdWRlPFBocmFzaW5nQ29udGVudCwgSHRtbD59ICovXG4gIChcbiAgICBjb252ZXJ0KFtcbiAgICAgICdicmVhaycsXG4gICAgICAnZGVsZXRlJyxcbiAgICAgICdlbXBoYXNpcycsXG4gICAgICAvLyBUbyBkbzogbmV4dCBtYWpvcjogcmVtb3ZlZCBzaW5jZSBmb290bm90ZXMgd2VyZSBhZGRlZCB0byBHRk0uXG4gICAgICAnZm9vdG5vdGUnLFxuICAgICAgJ2Zvb3Rub3RlUmVmZXJlbmNlJyxcbiAgICAgICdpbWFnZScsXG4gICAgICAnaW1hZ2VSZWZlcmVuY2UnLFxuICAgICAgJ2lubGluZUNvZGUnLFxuICAgICAgLy8gRW5hYmxlZCBieSBgbWRhc3QtdXRpbC1tYXRoYDpcbiAgICAgICdpbmxpbmVNYXRoJyxcbiAgICAgICdsaW5rJyxcbiAgICAgICdsaW5rUmVmZXJlbmNlJyxcbiAgICAgIC8vIEVuYWJsZWQgYnkgYG1kYXN0LXV0aWwtbWR4YDpcbiAgICAgICdtZHhKc3hUZXh0RWxlbWVudCcsXG4gICAgICAvLyBFbmFibGVkIGJ5IGBtZGFzdC11dGlsLW1keGA6XG4gICAgICAnbWR4VGV4dEV4cHJlc3Npb24nLFxuICAgICAgJ3N0cm9uZycsXG4gICAgICAndGV4dCcsXG4gICAgICAvLyBFbmFibGVkIGJ5IGBtZGFzdC11dGlsLWRpcmVjdGl2ZWA6XG4gICAgICAndGV4dERpcmVjdGl2ZSdcbiAgICBdKVxuICApXG4iLCIvKipcbiAqIEBpbXBvcnQge0luZm8sIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7UGFyZW50cywgUm9vdH0gZnJvbSAnbWRhc3QnXG4gKi9cblxuaW1wb3J0IHtwaHJhc2luZ30gZnJvbSAnbWRhc3QtdXRpbC1waHJhc2luZydcblxuLyoqXG4gKiBAcGFyYW0ge1Jvb3R9IG5vZGVcbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gX1xuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEBwYXJhbSB7SW5mb30gaW5mb1xuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJvb3Qobm9kZSwgXywgc3RhdGUsIGluZm8pIHtcbiAgLy8gTm90ZTogYGh0bWxgIG5vZGVzIGFyZSBhbWJpZ3VvdXMuXG4gIGNvbnN0IGhhc1BocmFzaW5nID0gbm9kZS5jaGlsZHJlbi5zb21lKGZ1bmN0aW9uIChkKSB7XG4gICAgcmV0dXJuIHBocmFzaW5nKGQpXG4gIH0pXG5cbiAgY29uc3QgY29udGFpbmVyID0gaGFzUGhyYXNpbmcgPyBzdGF0ZS5jb250YWluZXJQaHJhc2luZyA6IHN0YXRlLmNvbnRhaW5lckZsb3dcbiAgcmV0dXJuIGNvbnRhaW5lci5jYWxsKHN0YXRlLCBub2RlLCBpbmZvKVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtPcHRpb25zLCBTdGF0ZX0gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcbiAqL1xuXG4vKipcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7RXhjbHVkZTxPcHRpb25zWydzdHJvbmcnXSwgbnVsbCB8IHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja1N0cm9uZyhzdGF0ZSkge1xuICBjb25zdCBtYXJrZXIgPSBzdGF0ZS5vcHRpb25zLnN0cm9uZyB8fCAnKidcblxuICBpZiAobWFya2VyICE9PSAnKicgJiYgbWFya2VyICE9PSAnXycpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAnQ2Fubm90IHNlcmlhbGl6ZSBzdHJvbmcgd2l0aCBgJyArXG4gICAgICAgIG1hcmtlciArXG4gICAgICAgICdgIGZvciBgb3B0aW9ucy5zdHJvbmdgLCBleHBlY3RlZCBgKmAsIG9yIGBfYCdcbiAgICApXG4gIH1cblxuICByZXR1cm4gbWFya2VyXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0luZm8sIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7UGFyZW50cywgU3Ryb25nfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge2NoZWNrU3Ryb25nfSBmcm9tICcuLi91dGlsL2NoZWNrLXN0cm9uZy5qcydcbmltcG9ydCB7ZW5jb2RlQ2hhcmFjdGVyUmVmZXJlbmNlfSBmcm9tICcuLi91dGlsL2VuY29kZS1jaGFyYWN0ZXItcmVmZXJlbmNlLmpzJ1xuaW1wb3J0IHtlbmNvZGVJbmZvfSBmcm9tICcuLi91dGlsL2VuY29kZS1pbmZvLmpzJ1xuXG5zdHJvbmcucGVlayA9IHN0cm9uZ1BlZWtcblxuLyoqXG4gKiBAcGFyYW0ge1N0cm9uZ30gbm9kZVxuICogQHBhcmFtIHtQYXJlbnRzIHwgdW5kZWZpbmVkfSBfXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gc3Ryb25nKG5vZGUsIF8sIHN0YXRlLCBpbmZvKSB7XG4gIGNvbnN0IG1hcmtlciA9IGNoZWNrU3Ryb25nKHN0YXRlKVxuICBjb25zdCBleGl0ID0gc3RhdGUuZW50ZXIoJ3N0cm9uZycpXG4gIGNvbnN0IHRyYWNrZXIgPSBzdGF0ZS5jcmVhdGVUcmFja2VyKGluZm8pXG4gIGNvbnN0IGJlZm9yZSA9IHRyYWNrZXIubW92ZShtYXJrZXIgKyBtYXJrZXIpXG5cbiAgbGV0IGJldHdlZW4gPSB0cmFja2VyLm1vdmUoXG4gICAgc3RhdGUuY29udGFpbmVyUGhyYXNpbmcobm9kZSwge1xuICAgICAgYWZ0ZXI6IG1hcmtlcixcbiAgICAgIGJlZm9yZSxcbiAgICAgIC4uLnRyYWNrZXIuY3VycmVudCgpXG4gICAgfSlcbiAgKVxuICBjb25zdCBiZXR3ZWVuSGVhZCA9IGJldHdlZW4uY2hhckNvZGVBdCgwKVxuICBjb25zdCBvcGVuID0gZW5jb2RlSW5mbyhcbiAgICBpbmZvLmJlZm9yZS5jaGFyQ29kZUF0KGluZm8uYmVmb3JlLmxlbmd0aCAtIDEpLFxuICAgIGJldHdlZW5IZWFkLFxuICAgIG1hcmtlclxuICApXG5cbiAgaWYgKG9wZW4uaW5zaWRlKSB7XG4gICAgYmV0d2VlbiA9IGVuY29kZUNoYXJhY3RlclJlZmVyZW5jZShiZXR3ZWVuSGVhZCkgKyBiZXR3ZWVuLnNsaWNlKDEpXG4gIH1cblxuICBjb25zdCBiZXR3ZWVuVGFpbCA9IGJldHdlZW4uY2hhckNvZGVBdChiZXR3ZWVuLmxlbmd0aCAtIDEpXG4gIGNvbnN0IGNsb3NlID0gZW5jb2RlSW5mbyhpbmZvLmFmdGVyLmNoYXJDb2RlQXQoMCksIGJldHdlZW5UYWlsLCBtYXJrZXIpXG5cbiAgaWYgKGNsb3NlLmluc2lkZSkge1xuICAgIGJldHdlZW4gPSBiZXR3ZWVuLnNsaWNlKDAsIC0xKSArIGVuY29kZUNoYXJhY3RlclJlZmVyZW5jZShiZXR3ZWVuVGFpbClcbiAgfVxuXG4gIGNvbnN0IGFmdGVyID0gdHJhY2tlci5tb3ZlKG1hcmtlciArIG1hcmtlcilcblxuICBleGl0KClcblxuICBzdGF0ZS5hdHRlbnRpb25FbmNvZGVTdXJyb3VuZGluZ0luZm8gPSB7XG4gICAgYWZ0ZXI6IGNsb3NlLm91dHNpZGUsXG4gICAgYmVmb3JlOiBvcGVuLm91dHNpZGVcbiAgfVxuICByZXR1cm4gYmVmb3JlICsgYmV0d2VlbiArIGFmdGVyXG59XG5cbi8qKlxuICogQHBhcmFtIHtTdHJvbmd9IF9cbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gXzFcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5mdW5jdGlvbiBzdHJvbmdQZWVrKF8sIF8xLCBzdGF0ZSkge1xuICByZXR1cm4gc3RhdGUub3B0aW9ucy5zdHJvbmcgfHwgJyonXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0luZm8sIFN0YXRlfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICogQGltcG9ydCB7UGFyZW50cywgVGV4dH0gZnJvbSAnbWRhc3QnXG4gKi9cblxuLyoqXG4gKiBAcGFyYW0ge1RleHR9IG5vZGVcbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gX1xuICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAqIEBwYXJhbSB7SW5mb30gaW5mb1xuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRleHQobm9kZSwgXywgc3RhdGUsIGluZm8pIHtcbiAgcmV0dXJuIHN0YXRlLnNhZmUobm9kZS52YWx1ZSwgaW5mbylcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7T3B0aW9ucywgU3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKi9cblxuLyoqXG4gKiBAcGFyYW0ge1N0YXRlfSBzdGF0ZVxuICogQHJldHVybnMge0V4Y2x1ZGU8T3B0aW9uc1sncnVsZVJlcGV0aXRpb24nXSwgbnVsbCB8IHVuZGVmaW5lZD59XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja1J1bGVSZXBldGl0aW9uKHN0YXRlKSB7XG4gIGNvbnN0IHJlcGV0aXRpb24gPSBzdGF0ZS5vcHRpb25zLnJ1bGVSZXBldGl0aW9uIHx8IDNcblxuICBpZiAocmVwZXRpdGlvbiA8IDMpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAnQ2Fubm90IHNlcmlhbGl6ZSBydWxlcyB3aXRoIHJlcGV0aXRpb24gYCcgK1xuICAgICAgICByZXBldGl0aW9uICtcbiAgICAgICAgJ2AgZm9yIGBvcHRpb25zLnJ1bGVSZXBldGl0aW9uYCwgZXhwZWN0ZWQgYDNgIG9yIG1vcmUnXG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIHJlcGV0aXRpb25cbn1cbiIsIi8qKlxuICogQGltcG9ydCB7U3RhdGV9IGZyb20gJ21kYXN0LXV0aWwtdG8tbWFya2Rvd24nXG4gKiBAaW1wb3J0IHtQYXJlbnRzLCBUaGVtYXRpY0JyZWFrfSBmcm9tICdtZGFzdCdcbiAqL1xuXG5pbXBvcnQge2NoZWNrUnVsZVJlcGV0aXRpb259IGZyb20gJy4uL3V0aWwvY2hlY2stcnVsZS1yZXBldGl0aW9uLmpzJ1xuaW1wb3J0IHtjaGVja1J1bGV9IGZyb20gJy4uL3V0aWwvY2hlY2stcnVsZS5qcydcblxuLyoqXG4gKiBAcGFyYW0ge1RoZW1hdGljQnJlYWt9IF9cbiAqIEBwYXJhbSB7UGFyZW50cyB8IHVuZGVmaW5lZH0gXzFcbiAqIEBwYXJhbSB7U3RhdGV9IHN0YXRlXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gdGhlbWF0aWNCcmVhayhfLCBfMSwgc3RhdGUpIHtcbiAgY29uc3QgdmFsdWUgPSAoXG4gICAgY2hlY2tSdWxlKHN0YXRlKSArIChzdGF0ZS5vcHRpb25zLnJ1bGVTcGFjZXMgPyAnICcgOiAnJylcbiAgKS5yZXBlYXQoY2hlY2tSdWxlUmVwZXRpdGlvbihzdGF0ZSkpXG5cbiAgcmV0dXJuIHN0YXRlLm9wdGlvbnMucnVsZVNwYWNlcyA/IHZhbHVlLnNsaWNlKDAsIC0xKSA6IHZhbHVlXG59XG4iLCJpbXBvcnQge2Jsb2NrcXVvdGV9IGZyb20gJy4vYmxvY2txdW90ZS5qcydcbmltcG9ydCB7aGFyZEJyZWFrfSBmcm9tICcuL2JyZWFrLmpzJ1xuaW1wb3J0IHtjb2RlfSBmcm9tICcuL2NvZGUuanMnXG5pbXBvcnQge2RlZmluaXRpb259IGZyb20gJy4vZGVmaW5pdGlvbi5qcydcbmltcG9ydCB7ZW1waGFzaXN9IGZyb20gJy4vZW1waGFzaXMuanMnXG5pbXBvcnQge2hlYWRpbmd9IGZyb20gJy4vaGVhZGluZy5qcydcbmltcG9ydCB7aHRtbH0gZnJvbSAnLi9odG1sLmpzJ1xuaW1wb3J0IHtpbWFnZX0gZnJvbSAnLi9pbWFnZS5qcydcbmltcG9ydCB7aW1hZ2VSZWZlcmVuY2V9IGZyb20gJy4vaW1hZ2UtcmVmZXJlbmNlLmpzJ1xuaW1wb3J0IHtpbmxpbmVDb2RlfSBmcm9tICcuL2lubGluZS1jb2RlLmpzJ1xuaW1wb3J0IHtsaW5rfSBmcm9tICcuL2xpbmsuanMnXG5pbXBvcnQge2xpbmtSZWZlcmVuY2V9IGZyb20gJy4vbGluay1yZWZlcmVuY2UuanMnXG5pbXBvcnQge2xpc3R9IGZyb20gJy4vbGlzdC5qcydcbmltcG9ydCB7bGlzdEl0ZW19IGZyb20gJy4vbGlzdC1pdGVtLmpzJ1xuaW1wb3J0IHtwYXJhZ3JhcGh9IGZyb20gJy4vcGFyYWdyYXBoLmpzJ1xuaW1wb3J0IHtyb290fSBmcm9tICcuL3Jvb3QuanMnXG5pbXBvcnQge3N0cm9uZ30gZnJvbSAnLi9zdHJvbmcuanMnXG5pbXBvcnQge3RleHR9IGZyb20gJy4vdGV4dC5qcydcbmltcG9ydCB7dGhlbWF0aWNCcmVha30gZnJvbSAnLi90aGVtYXRpYy1icmVhay5qcydcblxuLyoqXG4gKiBEZWZhdWx0IChDb21tb25NYXJrKSBoYW5kbGVycy5cbiAqL1xuZXhwb3J0IGNvbnN0IGhhbmRsZSA9IHtcbiAgYmxvY2txdW90ZSxcbiAgYnJlYWs6IGhhcmRCcmVhayxcbiAgY29kZSxcbiAgZGVmaW5pdGlvbixcbiAgZW1waGFzaXMsXG4gIGhhcmRCcmVhayxcbiAgaGVhZGluZyxcbiAgaHRtbCxcbiAgaW1hZ2UsXG4gIGltYWdlUmVmZXJlbmNlLFxuICBpbmxpbmVDb2RlLFxuICBsaW5rLFxuICBsaW5rUmVmZXJlbmNlLFxuICBsaXN0LFxuICBsaXN0SXRlbSxcbiAgcGFyYWdyYXBoLFxuICByb290LFxuICBzdHJvbmcsXG4gIHRleHQsXG4gIHRoZW1hdGljQnJlYWtcbn1cbiIsIi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QnKS5JbmxpbmVDb2RlfSBJbmxpbmVDb2RlXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdCcpLlRhYmxlfSBUYWJsZVxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QnKS5UYWJsZUNlbGx9IFRhYmxlQ2VsbFxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QnKS5UYWJsZVJvd30gVGFibGVSb3dcbiAqXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtYXJrZG93bi10YWJsZScpLk9wdGlvbnN9IE1hcmtkb3duVGFibGVPcHRpb25zXG4gKlxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC1mcm9tLW1hcmtkb3duJykuQ29tcGlsZUNvbnRleHR9IENvbXBpbGVDb250ZXh0XG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLWZyb20tbWFya2Rvd24nKS5FeHRlbnNpb259IEZyb21NYXJrZG93bkV4dGVuc2lvblxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC1mcm9tLW1hcmtkb3duJykuSGFuZGxlfSBGcm9tTWFya2Rvd25IYW5kbGVcbiAqXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLXRvLW1hcmtkb3duJykuT3B0aW9uc30gVG9NYXJrZG93bkV4dGVuc2lvblxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC10by1tYXJrZG93bicpLkhhbmRsZX0gVG9NYXJrZG93bkhhbmRsZVxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC10by1tYXJrZG93bicpLlN0YXRlfSBTdGF0ZVxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC10by1tYXJrZG93bicpLkluZm99IEluZm9cbiAqL1xuXG4vKipcbiAqIEB0eXBlZGVmIE9wdGlvbnNcbiAqICAgQ29uZmlndXJhdGlvbi5cbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbiB8IG51bGwgfCB1bmRlZmluZWR9IFt0YWJsZUNlbGxQYWRkaW5nPXRydWVdXG4gKiAgIFdoZXRoZXIgdG8gYWRkIGEgc3BhY2Ugb2YgcGFkZGluZyBiZXR3ZWVuIGRlbGltaXRlcnMgYW5kIGNlbGxzIChkZWZhdWx0OlxuICogICBgdHJ1ZWApLlxuICogQHByb3BlcnR5IHtib29sZWFuIHwgbnVsbCB8IHVuZGVmaW5lZH0gW3RhYmxlUGlwZUFsaWduPXRydWVdXG4gKiAgIFdoZXRoZXIgdG8gYWxpZ24gdGhlIGRlbGltaXRlcnMgKGRlZmF1bHQ6IGB0cnVlYCkuXG4gKiBAcHJvcGVydHkge01hcmtkb3duVGFibGVPcHRpb25zWydzdHJpbmdMZW5ndGgnXSB8IG51bGwgfCB1bmRlZmluZWR9IFtzdHJpbmdMZW5ndGhdXG4gKiAgIEZ1bmN0aW9uIHRvIGRldGVjdCB0aGUgbGVuZ3RoIG9mIHRhYmxlIGNlbGwgY29udGVudCwgdXNlZCB3aGVuIGFsaWduaW5nXG4gKiAgIHRoZSBkZWxpbWl0ZXJzIGJldHdlZW4gY2VsbHMgKG9wdGlvbmFsKS5cbiAqL1xuXG5pbXBvcnQge29rIGFzIGFzc2VydH0gZnJvbSAnZGV2bG9wJ1xuaW1wb3J0IHttYXJrZG93blRhYmxlfSBmcm9tICdtYXJrZG93bi10YWJsZSdcbmltcG9ydCB7ZGVmYXVsdEhhbmRsZXJzfSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLWZyb20tbWFya2Rvd25gIHRvIGVuYWJsZSBHRk0gdGFibGVzIGluXG4gKiBtYXJrZG93bi5cbiAqXG4gKiBAcmV0dXJucyB7RnJvbU1hcmtkb3duRXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLWZyb20tbWFya2Rvd25gIHRvIGVuYWJsZSBHRk0gdGFibGVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2ZtVGFibGVGcm9tTWFya2Rvd24oKSB7XG4gIHJldHVybiB7XG4gICAgZW50ZXI6IHtcbiAgICAgIHRhYmxlOiBlbnRlclRhYmxlLFxuICAgICAgdGFibGVEYXRhOiBlbnRlckNlbGwsXG4gICAgICB0YWJsZUhlYWRlcjogZW50ZXJDZWxsLFxuICAgICAgdGFibGVSb3c6IGVudGVyUm93XG4gICAgfSxcbiAgICBleGl0OiB7XG4gICAgICBjb2RlVGV4dDogZXhpdENvZGVUZXh0LFxuICAgICAgdGFibGU6IGV4aXRUYWJsZSxcbiAgICAgIHRhYmxlRGF0YTogZXhpdCxcbiAgICAgIHRhYmxlSGVhZGVyOiBleGl0LFxuICAgICAgdGFibGVSb3c6IGV4aXRcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gKiBAdHlwZSB7RnJvbU1hcmtkb3duSGFuZGxlfVxuICovXG5mdW5jdGlvbiBlbnRlclRhYmxlKHRva2VuKSB7XG4gIGNvbnN0IGFsaWduID0gdG9rZW4uX2FsaWduXG4gIGFzc2VydChhbGlnbiwgJ2V4cGVjdGVkIGBfYWxpZ25gIG9uIHRhYmxlJylcbiAgdGhpcy5lbnRlcihcbiAgICB7XG4gICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgYWxpZ246IGFsaWduLm1hcChmdW5jdGlvbiAoZCkge1xuICAgICAgICByZXR1cm4gZCA9PT0gJ25vbmUnID8gbnVsbCA6IGRcbiAgICAgIH0pLFxuICAgICAgY2hpbGRyZW46IFtdXG4gICAgfSxcbiAgICB0b2tlblxuICApXG4gIHRoaXMuZGF0YS5pblRhYmxlID0gdHJ1ZVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGV4aXRUYWJsZSh0b2tlbikge1xuICB0aGlzLmV4aXQodG9rZW4pXG4gIHRoaXMuZGF0YS5pblRhYmxlID0gdW5kZWZpbmVkXG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZW50ZXJSb3codG9rZW4pIHtcbiAgdGhpcy5lbnRlcih7dHlwZTogJ3RhYmxlUm93JywgY2hpbGRyZW46IFtdfSwgdG9rZW4pXG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZXhpdCh0b2tlbikge1xuICB0aGlzLmV4aXQodG9rZW4pXG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZW50ZXJDZWxsKHRva2VuKSB7XG4gIHRoaXMuZW50ZXIoe3R5cGU6ICd0YWJsZUNlbGwnLCBjaGlsZHJlbjogW119LCB0b2tlbilcbn1cblxuLy8gT3ZlcndyaXRlIHRoZSBkZWZhdWx0IGNvZGUgdGV4dCBkYXRhIGhhbmRsZXIgdG8gdW5lc2NhcGUgZXNjYXBlZCBwaXBlcyB3aGVuXG4vLyB0aGV5IGFyZSBpbiB0YWJsZXMuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGV4aXRDb2RlVGV4dCh0b2tlbikge1xuICBsZXQgdmFsdWUgPSB0aGlzLnJlc3VtZSgpXG5cbiAgaWYgKHRoaXMuZGF0YS5pblRhYmxlKSB7XG4gICAgdmFsdWUgPSB2YWx1ZS5yZXBsYWNlKC9cXFxcKFtcXFxcfF0pL2csIHJlcGxhY2UpXG4gIH1cblxuICBjb25zdCBub2RlID0gdGhpcy5zdGFja1t0aGlzLnN0YWNrLmxlbmd0aCAtIDFdXG4gIGFzc2VydChub2RlLnR5cGUgPT09ICdpbmxpbmVDb2RlJylcbiAgbm9kZS52YWx1ZSA9IHZhbHVlXG4gIHRoaXMuZXhpdCh0b2tlbilcbn1cblxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gJDBcbiAqIEBwYXJhbSB7c3RyaW5nfSAkMVxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gcmVwbGFjZSgkMCwgJDEpIHtcbiAgLy8gUGlwZXMgd29yaywgYmFja3NsYXNoZXMgZG9u4oCZdCAoYnV0IGNhbuKAmXQgZXNjYXBlIHBpcGVzKS5cbiAgcmV0dXJuICQxID09PSAnfCcgPyAkMSA6ICQwXG59XG5cbi8qKlxuICogQ3JlYXRlIGFuIGV4dGVuc2lvbiBmb3IgYG1kYXN0LXV0aWwtdG8tbWFya2Rvd25gIHRvIGVuYWJsZSBHRk0gdGFibGVzIGluXG4gKiBtYXJrZG93bi5cbiAqXG4gKiBAcGFyYW0ge09wdGlvbnMgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0aW9uc11cbiAqICAgQ29uZmlndXJhdGlvbi5cbiAqIEByZXR1cm5zIHtUb01hcmtkb3duRXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLXRvLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNIHRhYmxlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbVRhYmxlVG9NYXJrZG93bihvcHRpb25zKSB7XG4gIGNvbnN0IHNldHRpbmdzID0gb3B0aW9ucyB8fCB7fVxuICBjb25zdCBwYWRkaW5nID0gc2V0dGluZ3MudGFibGVDZWxsUGFkZGluZ1xuICBjb25zdCBhbGlnbkRlbGltaXRlcnMgPSBzZXR0aW5ncy50YWJsZVBpcGVBbGlnblxuICBjb25zdCBzdHJpbmdMZW5ndGggPSBzZXR0aW5ncy5zdHJpbmdMZW5ndGhcbiAgY29uc3QgYXJvdW5kID0gcGFkZGluZyA/ICcgJyA6ICd8J1xuXG4gIHJldHVybiB7XG4gICAgdW5zYWZlOiBbXG4gICAgICB7Y2hhcmFjdGVyOiAnXFxyJywgaW5Db25zdHJ1Y3Q6ICd0YWJsZUNlbGwnfSxcbiAgICAgIHtjaGFyYWN0ZXI6ICdcXG4nLCBpbkNvbnN0cnVjdDogJ3RhYmxlQ2VsbCd9LFxuICAgICAgLy8gQSBwaXBlLCB3aGVuIGZvbGxvd2VkIGJ5IGEgdGFiIG9yIHNwYWNlIChwYWRkaW5nKSwgb3IgYSBkYXNoIG9yIGNvbG9uXG4gICAgICAvLyAodW5wYWRkZWQgZGVsaW1pdGVyIHJvdyksIGNvdWxkIHJlc3VsdCBpbiBhIHRhYmxlLlxuICAgICAge2F0QnJlYWs6IHRydWUsIGNoYXJhY3RlcjogJ3wnLCBhZnRlcjogJ1tcXHQgOi1dJ30sXG4gICAgICAvLyBBIHBpcGUgaW4gYSBjZWxsIG11c3QgYmUgZW5jb2RlZC5cbiAgICAgIHtjaGFyYWN0ZXI6ICd8JywgaW5Db25zdHJ1Y3Q6ICd0YWJsZUNlbGwnfSxcbiAgICAgIC8vIEEgY29sb24gbXVzdCBiZSBmb2xsb3dlZCBieSBhIGRhc2gsIGluIHdoaWNoIGNhc2UgaXQgY291bGQgc3RhcnQgYVxuICAgICAgLy8gZGVsaW1pdGVyIHJvdy5cbiAgICAgIHthdEJyZWFrOiB0cnVlLCBjaGFyYWN0ZXI6ICc6JywgYWZ0ZXI6ICctJ30sXG4gICAgICAvLyBBIGRlbGltaXRlciByb3cgY2FuIGFsc28gc3RhcnQgd2l0aCBhIGRhc2gsIHdoZW4gZm9sbG93ZWQgYnkgbW9yZVxuICAgICAgLy8gZGFzaGVzLCBhIGNvbG9uLCBvciBhIHBpcGUuXG4gICAgICAvLyBUaGlzIGlzIGEgc3RyaWN0ZXIgdmVyc2lvbiB0aGFuIHRoZSBidWlsdCBpbiBjaGVjayBmb3IgbGlzdHMsIHRoZW1hdGljXG4gICAgICAvLyBicmVha3MsIGFuZCBzZXRleCBoZWFkaW5nIHVuZGVybGluZXMgdGhvdWdoOlxuICAgICAgLy8gPGh0dHBzOi8vZ2l0aHViLmNvbS9zeW50YXgtdHJlZS9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2Jsb2IvNTFhMjAzOC9saWIvdW5zYWZlLmpzI0w1Nz5cbiAgICAgIHthdEJyZWFrOiB0cnVlLCBjaGFyYWN0ZXI6ICctJywgYWZ0ZXI6ICdbOnwtXSd9XG4gICAgXSxcbiAgICBoYW5kbGVyczoge1xuICAgICAgaW5saW5lQ29kZTogaW5saW5lQ29kZVdpdGhUYWJsZSxcbiAgICAgIHRhYmxlOiBoYW5kbGVUYWJsZSxcbiAgICAgIHRhYmxlQ2VsbDogaGFuZGxlVGFibGVDZWxsLFxuICAgICAgdGFibGVSb3c6IGhhbmRsZVRhYmxlUm93XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEB0eXBlIHtUb01hcmtkb3duSGFuZGxlfVxuICAgKiBAcGFyYW0ge1RhYmxlfSBub2RlXG4gICAqL1xuICBmdW5jdGlvbiBoYW5kbGVUYWJsZShub2RlLCBfLCBzdGF0ZSwgaW5mbykge1xuICAgIHJldHVybiBzZXJpYWxpemVEYXRhKGhhbmRsZVRhYmxlQXNEYXRhKG5vZGUsIHN0YXRlLCBpbmZvKSwgbm9kZS5hbGlnbilcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGZ1bmN0aW9uIGlzbuKAmXQgcmVhbGx5IHVzZWQgbm9ybWFsbHksIGJlY2F1c2Ugd2UgaGFuZGxlIHJvd3MgYXQgdGhlXG4gICAqIHRhYmxlIGxldmVsLlxuICAgKiBCdXQsIGlmIHNvbWVvbmUgcGFzc2VzIGluIGEgdGFibGUgcm93LCB0aGlzIGVuc3VyZXMgd2UgbWFrZSBzb21ld2hhdCBzZW5zZS5cbiAgICpcbiAgICogQHR5cGUge1RvTWFya2Rvd25IYW5kbGV9XG4gICAqIEBwYXJhbSB7VGFibGVSb3d9IG5vZGVcbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZVRhYmxlUm93KG5vZGUsIF8sIHN0YXRlLCBpbmZvKSB7XG4gICAgY29uc3Qgcm93ID0gaGFuZGxlVGFibGVSb3dBc0RhdGEobm9kZSwgc3RhdGUsIGluZm8pXG4gICAgY29uc3QgdmFsdWUgPSBzZXJpYWxpemVEYXRhKFtyb3ddKVxuICAgIC8vIGBtYXJrZG93bi10YWJsZWAgd2lsbCBhbHdheXMgYWRkIGFuIGFsaWduIHJvd1xuICAgIHJldHVybiB2YWx1ZS5zbGljZSgwLCB2YWx1ZS5pbmRleE9mKCdcXG4nKSlcbiAgfVxuXG4gIC8qKlxuICAgKiBAdHlwZSB7VG9NYXJrZG93bkhhbmRsZX1cbiAgICogQHBhcmFtIHtUYWJsZUNlbGx9IG5vZGVcbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZVRhYmxlQ2VsbChub2RlLCBfLCBzdGF0ZSwgaW5mbykge1xuICAgIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcigndGFibGVDZWxsJylcbiAgICBjb25zdCBzdWJleGl0ID0gc3RhdGUuZW50ZXIoJ3BocmFzaW5nJylcbiAgICBjb25zdCB2YWx1ZSA9IHN0YXRlLmNvbnRhaW5lclBocmFzaW5nKG5vZGUsIHtcbiAgICAgIC4uLmluZm8sXG4gICAgICBiZWZvcmU6IGFyb3VuZCxcbiAgICAgIGFmdGVyOiBhcm91bmRcbiAgICB9KVxuICAgIHN1YmV4aXQoKVxuICAgIGV4aXQoKVxuICAgIHJldHVybiB2YWx1ZVxuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7QXJyYXk8QXJyYXk8c3RyaW5nPj59IG1hdHJpeFxuICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ+IHwgbnVsbCB8IHVuZGVmaW5lZH0gW2FsaWduXVxuICAgKi9cbiAgZnVuY3Rpb24gc2VyaWFsaXplRGF0YShtYXRyaXgsIGFsaWduKSB7XG4gICAgcmV0dXJuIG1hcmtkb3duVGFibGUobWF0cml4LCB7XG4gICAgICBhbGlnbixcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3I6IGBtYXJrZG93bi10YWJsZWAgdHlwZXMgc2hvdWxkIHN1cHBvcnQgYG51bGxgLlxuICAgICAgYWxpZ25EZWxpbWl0ZXJzLFxuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvcjogYG1hcmtkb3duLXRhYmxlYCB0eXBlcyBzaG91bGQgc3VwcG9ydCBgbnVsbGAuXG4gICAgICBwYWRkaW5nLFxuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvcjogYG1hcmtkb3duLXRhYmxlYCB0eXBlcyBzaG91bGQgc3VwcG9ydCBgbnVsbGAuXG4gICAgICBzdHJpbmdMZW5ndGhcbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7VGFibGV9IG5vZGVcbiAgICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAgICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gICAqL1xuICBmdW5jdGlvbiBoYW5kbGVUYWJsZUFzRGF0YShub2RlLCBzdGF0ZSwgaW5mbykge1xuICAgIGNvbnN0IGNoaWxkcmVuID0gbm9kZS5jaGlsZHJlblxuICAgIGxldCBpbmRleCA9IC0xXG4gICAgLyoqIEB0eXBlIHtBcnJheTxBcnJheTxzdHJpbmc+Pn0gKi9cbiAgICBjb25zdCByZXN1bHQgPSBbXVxuICAgIGNvbnN0IHN1YmV4aXQgPSBzdGF0ZS5lbnRlcigndGFibGUnKVxuXG4gICAgd2hpbGUgKCsraW5kZXggPCBjaGlsZHJlbi5sZW5ndGgpIHtcbiAgICAgIHJlc3VsdFtpbmRleF0gPSBoYW5kbGVUYWJsZVJvd0FzRGF0YShjaGlsZHJlbltpbmRleF0sIHN0YXRlLCBpbmZvKVxuICAgIH1cblxuICAgIHN1YmV4aXQoKVxuXG4gICAgcmV0dXJuIHJlc3VsdFxuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7VGFibGVSb3d9IG5vZGVcbiAgICogQHBhcmFtIHtTdGF0ZX0gc3RhdGVcbiAgICogQHBhcmFtIHtJbmZvfSBpbmZvXG4gICAqL1xuICBmdW5jdGlvbiBoYW5kbGVUYWJsZVJvd0FzRGF0YShub2RlLCBzdGF0ZSwgaW5mbykge1xuICAgIGNvbnN0IGNoaWxkcmVuID0gbm9kZS5jaGlsZHJlblxuICAgIGxldCBpbmRleCA9IC0xXG4gICAgLyoqIEB0eXBlIHtBcnJheTxzdHJpbmc+fSAqL1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdXG4gICAgY29uc3Qgc3ViZXhpdCA9IHN0YXRlLmVudGVyKCd0YWJsZVJvdycpXG5cbiAgICB3aGlsZSAoKytpbmRleCA8IGNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgLy8gTm90ZTogdGhlIHBvc2l0aW9uYWwgaW5mbyBhcyB1c2VkIGhlcmUgaXMgaW5jb3JyZWN0LlxuICAgICAgLy8gTWFraW5nIGl0IGNvcnJlY3Qgd291bGQgYmUgaW1wb3NzaWJsZSBkdWUgdG8gYWxpZ25pbmcgY2VsbHM/XG4gICAgICAvLyBBbmQgaXQgd291bGQgbmVlZCBjb3B5L3Bhc3RpbmcgYG1hcmtkb3duLXRhYmxlYCBpbnRvIHRoaXMgcHJvamVjdC5cbiAgICAgIHJlc3VsdFtpbmRleF0gPSBoYW5kbGVUYWJsZUNlbGwoY2hpbGRyZW5baW5kZXhdLCBub2RlLCBzdGF0ZSwgaW5mbylcbiAgICB9XG5cbiAgICBzdWJleGl0KClcblxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIC8qKlxuICAgKiBAdHlwZSB7VG9NYXJrZG93bkhhbmRsZX1cbiAgICogQHBhcmFtIHtJbmxpbmVDb2RlfSBub2RlXG4gICAqL1xuICBmdW5jdGlvbiBpbmxpbmVDb2RlV2l0aFRhYmxlKG5vZGUsIHBhcmVudCwgc3RhdGUpIHtcbiAgICBsZXQgdmFsdWUgPSBkZWZhdWx0SGFuZGxlcnMuaW5saW5lQ29kZShub2RlLCBwYXJlbnQsIHN0YXRlKVxuXG4gICAgaWYgKHN0YXRlLnN0YWNrLmluY2x1ZGVzKCd0YWJsZUNlbGwnKSkge1xuICAgICAgdmFsdWUgPSB2YWx1ZS5yZXBsYWNlKC9cXHwvZywgJ1xcXFwkJicpXG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbHVlXG4gIH1cbn1cbiIsIi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QnKS5MaXN0SXRlbX0gTGlzdEl0ZW1cbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0JykuUGFyYWdyYXBofSBQYXJhZ3JhcGhcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0LXV0aWwtZnJvbS1tYXJrZG93bicpLkNvbXBpbGVDb250ZXh0fSBDb21waWxlQ29udGV4dFxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC1mcm9tLW1hcmtkb3duJykuRXh0ZW5zaW9ufSBGcm9tTWFya2Rvd25FeHRlbnNpb25cbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0LXV0aWwtZnJvbS1tYXJrZG93bicpLkhhbmRsZX0gRnJvbU1hcmtkb3duSGFuZGxlXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLXRvLW1hcmtkb3duJykuT3B0aW9uc30gVG9NYXJrZG93bkV4dGVuc2lvblxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC10by1tYXJrZG93bicpLkhhbmRsZX0gVG9NYXJrZG93bkhhbmRsZVxuICovXG5cbmltcG9ydCB7b2sgYXMgYXNzZXJ0fSBmcm9tICdkZXZsb3AnXG5pbXBvcnQge2RlZmF1bHRIYW5kbGVyc30gZnJvbSAnbWRhc3QtdXRpbC10by1tYXJrZG93bidcblxuLyoqXG4gKiBDcmVhdGUgYW4gZXh0ZW5zaW9uIGZvciBgbWRhc3QtdXRpbC1mcm9tLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNIHRhc2tcbiAqIGxpc3QgaXRlbXMgaW4gbWFya2Rvd24uXG4gKlxuICogQHJldHVybnMge0Zyb21NYXJrZG93bkV4dGVuc2lvbn1cbiAqICAgRXh0ZW5zaW9uIGZvciBgbWRhc3QtdXRpbC1mcm9tLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNIHRhc2sgbGlzdCBpdGVtcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbVRhc2tMaXN0SXRlbUZyb21NYXJrZG93bigpIHtcbiAgcmV0dXJuIHtcbiAgICBleGl0OiB7XG4gICAgICB0YXNrTGlzdENoZWNrVmFsdWVDaGVja2VkOiBleGl0Q2hlY2ssXG4gICAgICB0YXNrTGlzdENoZWNrVmFsdWVVbmNoZWNrZWQ6IGV4aXRDaGVjayxcbiAgICAgIHBhcmFncmFwaDogZXhpdFBhcmFncmFwaFdpdGhUYXNrTGlzdEl0ZW1cbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGUgYW4gZXh0ZW5zaW9uIGZvciBgbWRhc3QtdXRpbC10by1tYXJrZG93bmAgdG8gZW5hYmxlIEdGTSB0YXNrIGxpc3RcbiAqIGl0ZW1zIGluIG1hcmtkb3duLlxuICpcbiAqIEByZXR1cm5zIHtUb01hcmtkb3duRXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLXRvLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNIHRhc2sgbGlzdCBpdGVtcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbVRhc2tMaXN0SXRlbVRvTWFya2Rvd24oKSB7XG4gIHJldHVybiB7XG4gICAgdW5zYWZlOiBbe2F0QnJlYWs6IHRydWUsIGNoYXJhY3RlcjogJy0nLCBhZnRlcjogJ1s6fC1dJ31dLFxuICAgIGhhbmRsZXJzOiB7bGlzdEl0ZW06IGxpc3RJdGVtV2l0aFRhc2tMaXN0SXRlbX1cbiAgfVxufVxuXG4vKipcbiAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gKi9cbmZ1bmN0aW9uIGV4aXRDaGVjayh0b2tlbikge1xuICAvLyBXZeKAmXJlIGFsd2F5cyBpbiBhIHBhcmFncmFwaCwgaW4gYSBsaXN0IGl0ZW0uXG4gIGNvbnN0IG5vZGUgPSB0aGlzLnN0YWNrW3RoaXMuc3RhY2subGVuZ3RoIC0gMl1cbiAgYXNzZXJ0KG5vZGUudHlwZSA9PT0gJ2xpc3RJdGVtJylcbiAgbm9kZS5jaGVja2VkID0gdG9rZW4udHlwZSA9PT0gJ3Rhc2tMaXN0Q2hlY2tWYWx1ZUNoZWNrZWQnXG59XG5cbi8qKlxuICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAqL1xuZnVuY3Rpb24gZXhpdFBhcmFncmFwaFdpdGhUYXNrTGlzdEl0ZW0odG9rZW4pIHtcbiAgY29uc3QgcGFyZW50ID0gdGhpcy5zdGFja1t0aGlzLnN0YWNrLmxlbmd0aCAtIDJdXG5cbiAgaWYgKFxuICAgIHBhcmVudCAmJlxuICAgIHBhcmVudC50eXBlID09PSAnbGlzdEl0ZW0nICYmXG4gICAgdHlwZW9mIHBhcmVudC5jaGVja2VkID09PSAnYm9vbGVhbidcbiAgKSB7XG4gICAgY29uc3Qgbm9kZSA9IHRoaXMuc3RhY2tbdGhpcy5zdGFjay5sZW5ndGggLSAxXVxuICAgIGFzc2VydChub2RlLnR5cGUgPT09ICdwYXJhZ3JhcGgnKVxuICAgIGNvbnN0IGhlYWQgPSBub2RlLmNoaWxkcmVuWzBdXG5cbiAgICBpZiAoaGVhZCAmJiBoZWFkLnR5cGUgPT09ICd0ZXh0Jykge1xuICAgICAgY29uc3Qgc2libGluZ3MgPSBwYXJlbnQuY2hpbGRyZW5cbiAgICAgIGxldCBpbmRleCA9IC0xXG4gICAgICAvKiogQHR5cGUge1BhcmFncmFwaCB8IHVuZGVmaW5lZH0gKi9cbiAgICAgIGxldCBmaXJzdFBhcmFnaHJhcGhcblxuICAgICAgd2hpbGUgKCsraW5kZXggPCBzaWJsaW5ncy5sZW5ndGgpIHtcbiAgICAgICAgY29uc3Qgc2libGluZyA9IHNpYmxpbmdzW2luZGV4XVxuICAgICAgICBpZiAoc2libGluZy50eXBlID09PSAncGFyYWdyYXBoJykge1xuICAgICAgICAgIGZpcnN0UGFyYWdocmFwaCA9IHNpYmxpbmdcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChmaXJzdFBhcmFnaHJhcGggPT09IG5vZGUpIHtcbiAgICAgICAgLy8gTXVzdCBzdGFydCB3aXRoIGEgc3BhY2Ugb3IgYSB0YWIuXG4gICAgICAgIGhlYWQudmFsdWUgPSBoZWFkLnZhbHVlLnNsaWNlKDEpXG5cbiAgICAgICAgaWYgKGhlYWQudmFsdWUubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgbm9kZS5jaGlsZHJlbi5zaGlmdCgpXG4gICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgbm9kZS5wb3NpdGlvbiAmJlxuICAgICAgICAgIGhlYWQucG9zaXRpb24gJiZcbiAgICAgICAgICB0eXBlb2YgaGVhZC5wb3NpdGlvbi5zdGFydC5vZmZzZXQgPT09ICdudW1iZXInXG4gICAgICAgICkge1xuICAgICAgICAgIGhlYWQucG9zaXRpb24uc3RhcnQuY29sdW1uKytcbiAgICAgICAgICBoZWFkLnBvc2l0aW9uLnN0YXJ0Lm9mZnNldCsrXG4gICAgICAgICAgbm9kZS5wb3NpdGlvbi5zdGFydCA9IE9iamVjdC5hc3NpZ24oe30sIGhlYWQucG9zaXRpb24uc3RhcnQpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICB0aGlzLmV4aXQodG9rZW4pXG59XG5cbi8qKlxuICogQHR5cGUge1RvTWFya2Rvd25IYW5kbGV9XG4gKiBAcGFyYW0ge0xpc3RJdGVtfSBub2RlXG4gKi9cbmZ1bmN0aW9uIGxpc3RJdGVtV2l0aFRhc2tMaXN0SXRlbShub2RlLCBwYXJlbnQsIHN0YXRlLCBpbmZvKSB7XG4gIGNvbnN0IGhlYWQgPSBub2RlLmNoaWxkcmVuWzBdXG4gIGNvbnN0IGNoZWNrYWJsZSA9XG4gICAgdHlwZW9mIG5vZGUuY2hlY2tlZCA9PT0gJ2Jvb2xlYW4nICYmIGhlYWQgJiYgaGVhZC50eXBlID09PSAncGFyYWdyYXBoJ1xuICBjb25zdCBjaGVja2JveCA9ICdbJyArIChub2RlLmNoZWNrZWQgPyAneCcgOiAnICcpICsgJ10gJ1xuICBjb25zdCB0cmFja2VyID0gc3RhdGUuY3JlYXRlVHJhY2tlcihpbmZvKVxuXG4gIGlmIChjaGVja2FibGUpIHtcbiAgICB0cmFja2VyLm1vdmUoY2hlY2tib3gpXG4gIH1cblxuICBsZXQgdmFsdWUgPSBkZWZhdWx0SGFuZGxlcnMubGlzdEl0ZW0obm9kZSwgcGFyZW50LCBzdGF0ZSwge1xuICAgIC4uLmluZm8sXG4gICAgLi4udHJhY2tlci5jdXJyZW50KClcbiAgfSlcblxuICBpZiAoY2hlY2thYmxlKSB7XG4gICAgdmFsdWUgPSB2YWx1ZS5yZXBsYWNlKC9eKD86WyorLV18XFxkK1xcLikoW1xcclxcbl18IHsxLDN9KS8sIGNoZWNrKVxuICB9XG5cbiAgcmV0dXJuIHZhbHVlXG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7c3RyaW5nfSAkMFxuICAgKiBAcmV0dXJucyB7c3RyaW5nfVxuICAgKi9cbiAgZnVuY3Rpb24gY2hlY2soJDApIHtcbiAgICByZXR1cm4gJDAgKyBjaGVja2JveFxuICB9XG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0V4dGVuc2lvbiBhcyBGcm9tTWFya2Rvd25FeHRlbnNpb259IGZyb20gJ21kYXN0LXV0aWwtZnJvbS1tYXJrZG93bidcbiAqIEBpbXBvcnQge09wdGlvbnN9IGZyb20gJ21kYXN0LXV0aWwtZ2ZtJ1xuICogQGltcG9ydCB7T3B0aW9ucyBhcyBUb01hcmtkb3duRXh0ZW5zaW9ufSBmcm9tICdtZGFzdC11dGlsLXRvLW1hcmtkb3duJ1xuICovXG5cbmltcG9ydCB7XG4gIGdmbUF1dG9saW5rTGl0ZXJhbEZyb21NYXJrZG93bixcbiAgZ2ZtQXV0b2xpbmtMaXRlcmFsVG9NYXJrZG93blxufSBmcm9tICdtZGFzdC11dGlsLWdmbS1hdXRvbGluay1saXRlcmFsJ1xuaW1wb3J0IHtcbiAgZ2ZtRm9vdG5vdGVGcm9tTWFya2Rvd24sXG4gIGdmbUZvb3Rub3RlVG9NYXJrZG93blxufSBmcm9tICdtZGFzdC11dGlsLWdmbS1mb290bm90ZSdcbmltcG9ydCB7XG4gIGdmbVN0cmlrZXRocm91Z2hGcm9tTWFya2Rvd24sXG4gIGdmbVN0cmlrZXRocm91Z2hUb01hcmtkb3duXG59IGZyb20gJ21kYXN0LXV0aWwtZ2ZtLXN0cmlrZXRocm91Z2gnXG5pbXBvcnQge2dmbVRhYmxlRnJvbU1hcmtkb3duLCBnZm1UYWJsZVRvTWFya2Rvd259IGZyb20gJ21kYXN0LXV0aWwtZ2ZtLXRhYmxlJ1xuaW1wb3J0IHtcbiAgZ2ZtVGFza0xpc3RJdGVtRnJvbU1hcmtkb3duLFxuICBnZm1UYXNrTGlzdEl0ZW1Ub01hcmtkb3duXG59IGZyb20gJ21kYXN0LXV0aWwtZ2ZtLXRhc2stbGlzdC1pdGVtJ1xuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLWZyb20tbWFya2Rvd25gIHRvIGVuYWJsZSBHRk0gKGF1dG9saW5rXG4gKiBsaXRlcmFscywgZm9vdG5vdGVzLCBzdHJpa2V0aHJvdWdoLCB0YWJsZXMsIHRhc2tsaXN0cykuXG4gKlxuICogQHJldHVybnMge0FycmF5PEZyb21NYXJrZG93bkV4dGVuc2lvbj59XG4gKiAgIEV4dGVuc2lvbiBmb3IgYG1kYXN0LXV0aWwtZnJvbS1tYXJrZG93bmAgdG8gZW5hYmxlIEdGTSAoYXV0b2xpbmsgbGl0ZXJhbHMsXG4gKiAgIGZvb3Rub3Rlcywgc3RyaWtldGhyb3VnaCwgdGFibGVzLCB0YXNrbGlzdHMpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2ZtRnJvbU1hcmtkb3duKCkge1xuICByZXR1cm4gW1xuICAgIGdmbUF1dG9saW5rTGl0ZXJhbEZyb21NYXJrZG93bigpLFxuICAgIGdmbUZvb3Rub3RlRnJvbU1hcmtkb3duKCksXG4gICAgZ2ZtU3RyaWtldGhyb3VnaEZyb21NYXJrZG93bigpLFxuICAgIGdmbVRhYmxlRnJvbU1hcmtkb3duKCksXG4gICAgZ2ZtVGFza0xpc3RJdGVtRnJvbU1hcmtkb3duKClcbiAgXVxufVxuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLXRvLW1hcmtkb3duYCB0byBlbmFibGUgR0ZNIChhdXRvbGlua1xuICogbGl0ZXJhbHMsIGZvb3Rub3Rlcywgc3RyaWtldGhyb3VnaCwgdGFibGVzLCB0YXNrbGlzdHMpLlxuICpcbiAqIEBwYXJhbSB7T3B0aW9ucyB8IG51bGwgfCB1bmRlZmluZWR9IFtvcHRpb25zXVxuICogICBDb25maWd1cmF0aW9uIChvcHRpb25hbCkuXG4gKiBAcmV0dXJucyB7VG9NYXJrZG93bkV4dGVuc2lvbn1cbiAqICAgRXh0ZW5zaW9uIGZvciBgbWRhc3QtdXRpbC10by1tYXJrZG93bmAgdG8gZW5hYmxlIEdGTSAoYXV0b2xpbmsgbGl0ZXJhbHMsXG4gKiAgIGZvb3Rub3Rlcywgc3RyaWtldGhyb3VnaCwgdGFibGVzLCB0YXNrbGlzdHMpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2ZtVG9NYXJrZG93bihvcHRpb25zKSB7XG4gIHJldHVybiB7XG4gICAgZXh0ZW5zaW9uczogW1xuICAgICAgZ2ZtQXV0b2xpbmtMaXRlcmFsVG9NYXJrZG93bigpLFxuICAgICAgZ2ZtRm9vdG5vdGVUb01hcmtkb3duKG9wdGlvbnMpLFxuICAgICAgZ2ZtU3RyaWtldGhyb3VnaFRvTWFya2Rvd24oKSxcbiAgICAgIGdmbVRhYmxlVG9NYXJrZG93bihvcHRpb25zKSxcbiAgICAgIGdmbVRhc2tMaXN0SXRlbVRvTWFya2Rvd24oKVxuICAgIF1cbiAgfVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtDb2RlLCBDb25zdHJ1Y3RSZWNvcmQsIEV2ZW50LCBFeHRlbnNpb24sIFByZXZpb3VzLCBTdGF0ZSwgVG9rZW5pemVDb250ZXh0LCBUb2tlbml6ZXJ9IGZyb20gJ21pY3JvbWFyay11dGlsLXR5cGVzJ1xuICovXG5cbmltcG9ydCB7XG4gIGFzY2lpQWxwaGEsXG4gIGFzY2lpQWxwaGFudW1lcmljLFxuICBhc2NpaUNvbnRyb2wsXG4gIG1hcmtkb3duTGluZUVuZGluZ09yU3BhY2UsXG4gIHVuaWNvZGVQdW5jdHVhdGlvbixcbiAgdW5pY29kZVdoaXRlc3BhY2Vcbn0gZnJvbSAnbWljcm9tYXJrLXV0aWwtY2hhcmFjdGVyJ1xuaW1wb3J0IHtjb2Rlc30gZnJvbSAnbWljcm9tYXJrLXV0aWwtc3ltYm9sJ1xuXG5jb25zdCB3d3dQcmVmaXggPSB7dG9rZW5pemU6IHRva2VuaXplV3d3UHJlZml4LCBwYXJ0aWFsOiB0cnVlfVxuY29uc3QgZG9tYWluID0ge3Rva2VuaXplOiB0b2tlbml6ZURvbWFpbiwgcGFydGlhbDogdHJ1ZX1cbmNvbnN0IHBhdGggPSB7dG9rZW5pemU6IHRva2VuaXplUGF0aCwgcGFydGlhbDogdHJ1ZX1cbmNvbnN0IHRyYWlsID0ge3Rva2VuaXplOiB0b2tlbml6ZVRyYWlsLCBwYXJ0aWFsOiB0cnVlfVxuY29uc3QgZW1haWxEb21haW5Eb3RUcmFpbCA9IHtcbiAgdG9rZW5pemU6IHRva2VuaXplRW1haWxEb21haW5Eb3RUcmFpbCxcbiAgcGFydGlhbDogdHJ1ZVxufVxuXG5jb25zdCB3d3dBdXRvbGluayA9IHtcbiAgbmFtZTogJ3d3d0F1dG9saW5rJyxcbiAgdG9rZW5pemU6IHRva2VuaXplV3d3QXV0b2xpbmssXG4gIHByZXZpb3VzOiBwcmV2aW91c1d3d1xufVxuXG5jb25zdCBwcm90b2NvbEF1dG9saW5rID0ge1xuICBuYW1lOiAncHJvdG9jb2xBdXRvbGluaycsXG4gIHRva2VuaXplOiB0b2tlbml6ZVByb3RvY29sQXV0b2xpbmssXG4gIHByZXZpb3VzOiBwcmV2aW91c1Byb3RvY29sXG59XG5cbmNvbnN0IGVtYWlsQXV0b2xpbmsgPSB7XG4gIG5hbWU6ICdlbWFpbEF1dG9saW5rJyxcbiAgdG9rZW5pemU6IHRva2VuaXplRW1haWxBdXRvbGluayxcbiAgcHJldmlvdXM6IHByZXZpb3VzRW1haWxcbn1cblxuLyoqIEB0eXBlIHtDb25zdHJ1Y3RSZWNvcmR9ICovXG5jb25zdCB0ZXh0ID0ge31cblxuLyoqXG4gKiBDcmVhdGUgYW4gZXh0ZW5zaW9uIGZvciBgbWljcm9tYXJrYCB0byBzdXBwb3J0IEdpdEh1YiBhdXRvbGluayBsaXRlcmFsXG4gKiBzeW50YXguXG4gKlxuICogQHJldHVybnMge0V4dGVuc2lvbn1cbiAqICAgRXh0ZW5zaW9uIGZvciBgbWljcm9tYXJrYCB0aGF0IGNhbiBiZSBwYXNzZWQgaW4gYGV4dGVuc2lvbnNgIHRvIGVuYWJsZSBHRk1cbiAqICAgYXV0b2xpbmsgbGl0ZXJhbCBzeW50YXguXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZm1BdXRvbGlua0xpdGVyYWwoKSB7XG4gIHJldHVybiB7dGV4dH1cbn1cblxuLyoqIEB0eXBlIHtDb2RlfSAqL1xubGV0IGNvZGUgPSBjb2Rlcy5kaWdpdDBcblxuLy8gQWRkIGFscGhhbnVtZXJpY3MuXG53aGlsZSAoY29kZSA8IGNvZGVzLmxlZnRDdXJseUJyYWNlKSB7XG4gIHRleHRbY29kZV0gPSBlbWFpbEF1dG9saW5rXG4gIGNvZGUrK1xuICBpZiAoY29kZSA9PT0gY29kZXMuY29sb24pIGNvZGUgPSBjb2Rlcy51cHBlcmNhc2VBXG4gIGVsc2UgaWYgKGNvZGUgPT09IGNvZGVzLmxlZnRTcXVhcmVCcmFja2V0KSBjb2RlID0gY29kZXMubG93ZXJjYXNlQVxufVxuXG50ZXh0W2NvZGVzLnBsdXNTaWduXSA9IGVtYWlsQXV0b2xpbmtcbnRleHRbY29kZXMuZGFzaF0gPSBlbWFpbEF1dG9saW5rXG50ZXh0W2NvZGVzLmRvdF0gPSBlbWFpbEF1dG9saW5rXG50ZXh0W2NvZGVzLnVuZGVyc2NvcmVdID0gZW1haWxBdXRvbGlua1xudGV4dFtjb2Rlcy51cHBlcmNhc2VIXSA9IFtlbWFpbEF1dG9saW5rLCBwcm90b2NvbEF1dG9saW5rXVxudGV4dFtjb2Rlcy5sb3dlcmNhc2VIXSA9IFtlbWFpbEF1dG9saW5rLCBwcm90b2NvbEF1dG9saW5rXVxudGV4dFtjb2Rlcy51cHBlcmNhc2VXXSA9IFtlbWFpbEF1dG9saW5rLCB3d3dBdXRvbGlua11cbnRleHRbY29kZXMubG93ZXJjYXNlV10gPSBbZW1haWxBdXRvbGluaywgd3d3QXV0b2xpbmtdXG5cbi8vIFRvIGRvOiBwZXJmb3JtIGVtYWlsIGF1dG9saW5rIGxpdGVyYWxzIG9uIGV2ZW50cywgYWZ0ZXJ3YXJkcy5cbi8vIFRoYXTigJlzIHdoZXJlIGBtYXJrZG93bi1yc2AgYW5kIGBjbWFyay1nZm1gIHBlcmZvcm0gaXQuXG4vLyBJdCBzaG91bGQgbG9vayBmb3IgYEBgLCB0aGVuIGZvciBhdGV4dCBiYWNrd2FyZHMsIGFuZCB0aGVuIGZvciBhIGxhYmVsXG4vLyBmb3J3YXJkcy5cbi8vIFRvIGRvOiBgbWFpbHRvOmAsIGB4bXBwOmAgcHJvdG9jb2wgYXMgcHJlZml4LlxuXG4vKipcbiAqIEVtYWlsIGF1dG9saW5rIGxpdGVyYWwuXG4gKlxuICogYGBgbWFya2Rvd25cbiAqID4gfCBhIGNvbnRhY3RAZXhhbXBsZS5vcmcgYlxuICogICAgICAgXl5eXl5eXl5eXl5eXl5eXl5eXlxuICogYGBgXG4gKlxuICogQHRoaXMge1Rva2VuaXplQ29udGV4dH1cbiAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gKi9cbmZ1bmN0aW9uIHRva2VuaXplRW1haWxBdXRvbGluayhlZmZlY3RzLCBvaywgbm9rKSB7XG4gIGNvbnN0IHNlbGYgPSB0aGlzXG4gIC8qKiBAdHlwZSB7Ym9vbGVhbiB8IHVuZGVmaW5lZH0gKi9cbiAgbGV0IGRvdFxuICAvKiogQHR5cGUge2Jvb2xlYW59ICovXG4gIGxldCBkYXRhXG5cbiAgcmV0dXJuIHN0YXJ0XG5cbiAgLyoqXG4gICAqIFN0YXJ0IG9mIGVtYWlsIGF1dG9saW5rIGxpdGVyYWwuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIGNvbnRhY3RAZXhhbXBsZS5vcmcgYlxuICAgKiAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBzdGFydChjb2RlKSB7XG4gICAgaWYgKFxuICAgICAgIWdmbUF0ZXh0KGNvZGUpIHx8XG4gICAgICAhcHJldmlvdXNFbWFpbC5jYWxsKHNlbGYsIHNlbGYucHJldmlvdXMpIHx8XG4gICAgICBwcmV2aW91c1VuYmFsYW5jZWQoc2VsZi5ldmVudHMpXG4gICAgKSB7XG4gICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgfVxuXG4gICAgZWZmZWN0cy5lbnRlcignbGl0ZXJhbEF1dG9saW5rJylcbiAgICBlZmZlY3RzLmVudGVyKCdsaXRlcmFsQXV0b2xpbmtFbWFpbCcpXG4gICAgcmV0dXJuIGF0ZXh0KGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gZW1haWwgYXRleHQuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIGNvbnRhY3RAZXhhbXBsZS5vcmcgYlxuICAgKiAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBhdGV4dChjb2RlKSB7XG4gICAgaWYgKGdmbUF0ZXh0KGNvZGUpKSB7XG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIHJldHVybiBhdGV4dFxuICAgIH1cblxuICAgIGlmIChjb2RlID09PSBjb2Rlcy5hdFNpZ24pIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgcmV0dXJuIGVtYWlsRG9tYWluXG4gICAgfVxuXG4gICAgcmV0dXJuIG5vayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEluIGVtYWlsIGRvbWFpbi5cbiAgICpcbiAgICogVGhlIHJlZmVyZW5jZSBjb2RlIGlzIGEgYml0IG92ZXJseSBjb21wbGV4IGFzIGl0IGhhbmRsZXMgdGhlIGBAYCwgb2Ygd2hpY2hcbiAgICogdGhlcmUgbWF5IGJlIGp1c3Qgb25lLlxuICAgKiBTb3VyY2U6IDxodHRwczovL2dpdGh1Yi5jb20vZ2l0aHViL2NtYXJrLWdmbS9ibG9iL2VmMWNmY2IvZXh0ZW5zaW9ucy9hdXRvbGluay5jI0wzMTg+XG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIGNvbnRhY3RAZXhhbXBsZS5vcmcgYlxuICAgKiAgICAgICAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGVtYWlsRG9tYWluKGNvZGUpIHtcbiAgICAvLyBEb3QgZm9sbG93ZWQgYnkgYWxwaGFudW1lcmljYWwgKG5vdCBgLWAgb3IgYF9gKS5cbiAgICBpZiAoY29kZSA9PT0gY29kZXMuZG90KSB7XG4gICAgICByZXR1cm4gZWZmZWN0cy5jaGVjayhcbiAgICAgICAgZW1haWxEb21haW5Eb3RUcmFpbCxcbiAgICAgICAgZW1haWxEb21haW5BZnRlcixcbiAgICAgICAgZW1haWxEb21haW5Eb3RcbiAgICAgICkoY29kZSlcbiAgICB9XG5cbiAgICAvLyBBbHBoYW51bWVyaWNhbCwgYC1gLCBhbmQgYF9gLlxuICAgIGlmIChcbiAgICAgIGNvZGUgPT09IGNvZGVzLmRhc2ggfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLnVuZGVyc2NvcmUgfHxcbiAgICAgIGFzY2lpQWxwaGFudW1lcmljKGNvZGUpXG4gICAgKSB7XG4gICAgICBkYXRhID0gdHJ1ZVxuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICByZXR1cm4gZW1haWxEb21haW5cbiAgICB9XG5cbiAgICAvLyBUbyBkbzogYC9gIGlmIHhtcHAuXG5cbiAgICAvLyBOb3RlOiBub3JtYWxseSB3ZeKAmWQgdHJ1bmNhdGUgdHJhaWxpbmcgcHVuY3R1YXRpb24gZnJvbSB0aGUgbGluay5cbiAgICAvLyBIb3dldmVyLCBlbWFpbCBhdXRvbGluayBsaXRlcmFscyBjYW5ub3QgY29udGFpbiBhbnkgb2YgdGhvc2UgbWFya2VycyxcbiAgICAvLyBleGNlcHQgZm9yIGAuYCwgYnV0IHRoYXQgY2FuIG9ubHkgb2NjdXIgaWYgaXQgaXNu4oCZdCB0cmFpbGluZy5cbiAgICAvLyBTbyB3ZSBjYW4gaWdub3JlIHRydW5jYXRpbmchXG4gICAgcmV0dXJuIGVtYWlsRG9tYWluQWZ0ZXIoY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBJbiBlbWFpbCBkb21haW4sIG9uIGRvdCB0aGF0IGlzIG5vdCBhIHRyYWlsLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgYSBjb250YWN0QGV4YW1wbGUub3JnIGJcbiAgICogICAgICAgICAgICAgICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gZW1haWxEb21haW5Eb3QoY29kZSkge1xuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIGRvdCA9IHRydWVcbiAgICByZXR1cm4gZW1haWxEb21haW5cbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBlbWFpbCBkb21haW4uXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIGNvbnRhY3RAZXhhbXBsZS5vcmcgYlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gZW1haWxEb21haW5BZnRlcihjb2RlKSB7XG4gICAgLy8gRG9tYWluIG11c3Qgbm90IGJlIGVtcHR5LCBtdXN0IGluY2x1ZGUgYSBkb3QsIGFuZCBtdXN0IGVuZCBpbiBhbHBoYWJldGljYWwuXG4gICAgLy8gU291cmNlOiA8aHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9jbWFyay1nZm0vYmxvYi9lZjFjZmNiL2V4dGVuc2lvbnMvYXV0b2xpbmsuYyNMMzMyPi5cbiAgICBpZiAoZGF0YSAmJiBkb3QgJiYgYXNjaWlBbHBoYShzZWxmLnByZXZpb3VzKSkge1xuICAgICAgZWZmZWN0cy5leGl0KCdsaXRlcmFsQXV0b2xpbmtFbWFpbCcpXG4gICAgICBlZmZlY3RzLmV4aXQoJ2xpdGVyYWxBdXRvbGluaycpXG4gICAgICByZXR1cm4gb2soY29kZSlcbiAgICB9XG5cbiAgICByZXR1cm4gbm9rKGNvZGUpXG4gIH1cbn1cblxuLyoqXG4gKiBgd3d3YCBhdXRvbGluayBsaXRlcmFsLlxuICpcbiAqIGBgYG1hcmtkb3duXG4gKiA+IHwgYSB3d3cuZXhhbXBsZS5vcmcgYlxuICogICAgICAgXl5eXl5eXl5eXl5eXl5eXG4gKiBgYGBcbiAqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1Rva2VuaXplcn1cbiAqL1xuZnVuY3Rpb24gdG9rZW5pemVXd3dBdXRvbGluayhlZmZlY3RzLCBvaywgbm9rKSB7XG4gIGNvbnN0IHNlbGYgPSB0aGlzXG5cbiAgcmV0dXJuIHd3d1N0YXJ0XG5cbiAgLyoqXG4gICAqIFN0YXJ0IG9mIHd3dyBhdXRvbGluayBsaXRlcmFsLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgd3d3LmV4YW1wbGUuY29tL2E/YiNjXG4gICAqICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiB3d3dTdGFydChjb2RlKSB7XG4gICAgaWYgKFxuICAgICAgKGNvZGUgIT09IGNvZGVzLnVwcGVyY2FzZVcgJiYgY29kZSAhPT0gY29kZXMubG93ZXJjYXNlVykgfHxcbiAgICAgICFwcmV2aW91c1d3dy5jYWxsKHNlbGYsIHNlbGYucHJldmlvdXMpIHx8XG4gICAgICBwcmV2aW91c1VuYmFsYW5jZWQoc2VsZi5ldmVudHMpXG4gICAgKSB7XG4gICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgfVxuXG4gICAgZWZmZWN0cy5lbnRlcignbGl0ZXJhbEF1dG9saW5rJylcbiAgICBlZmZlY3RzLmVudGVyKCdsaXRlcmFsQXV0b2xpbmtXd3cnKVxuICAgIC8vIE5vdGU6IHdlICpjaGVjayosIHNvIHdlIGNhbiBkaXNjYXJkIHRoZSBgd3d3LmAgd2UgcGFyc2VkLlxuICAgIC8vIElmIGl0IHdvcmtlZCwgd2UgY29uc2lkZXIgaXQgYXMgYSBwYXJ0IG9mIHRoZSBkb21haW4uXG4gICAgcmV0dXJuIGVmZmVjdHMuY2hlY2soXG4gICAgICB3d3dQcmVmaXgsXG4gICAgICBlZmZlY3RzLmF0dGVtcHQoZG9tYWluLCBlZmZlY3RzLmF0dGVtcHQocGF0aCwgd3d3QWZ0ZXIpLCBub2spLFxuICAgICAgbm9rXG4gICAgKShjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEFmdGVyIGEgd3d3IGF1dG9saW5rIGxpdGVyYWwuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCB3d3cuZXhhbXBsZS5jb20vYT9iI2NcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIHd3d0FmdGVyKGNvZGUpIHtcbiAgICBlZmZlY3RzLmV4aXQoJ2xpdGVyYWxBdXRvbGlua1d3dycpXG4gICAgZWZmZWN0cy5leGl0KCdsaXRlcmFsQXV0b2xpbmsnKVxuICAgIHJldHVybiBvayhjb2RlKVxuICB9XG59XG5cbi8qKlxuICogUHJvdG9jb2wgYXV0b2xpbmsgbGl0ZXJhbC5cbiAqXG4gKiBgYGBtYXJrZG93blxuICogPiB8IGEgaHR0cHM6Ly9leGFtcGxlLm9yZyBiXG4gKiAgICAgICBeXl5eXl5eXl5eXl5eXl5eXl5eXG4gKiBgYGBcbiAqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1Rva2VuaXplcn1cbiAqL1xuZnVuY3Rpb24gdG9rZW5pemVQcm90b2NvbEF1dG9saW5rKGVmZmVjdHMsIG9rLCBub2spIHtcbiAgY29uc3Qgc2VsZiA9IHRoaXNcbiAgbGV0IGJ1ZmZlciA9ICcnXG4gIGxldCBzZWVuID0gZmFsc2VcblxuICByZXR1cm4gcHJvdG9jb2xTdGFydFxuXG4gIC8qKlxuICAgKiBTdGFydCBvZiBwcm90b2NvbCBhdXRvbGluayBsaXRlcmFsLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgaHR0cHM6Ly9leGFtcGxlLmNvbS9hP2IjY1xuICAgKiAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gcHJvdG9jb2xTdGFydChjb2RlKSB7XG4gICAgaWYgKFxuICAgICAgKGNvZGUgPT09IGNvZGVzLnVwcGVyY2FzZUggfHwgY29kZSA9PT0gY29kZXMubG93ZXJjYXNlSCkgJiZcbiAgICAgIHByZXZpb3VzUHJvdG9jb2wuY2FsbChzZWxmLCBzZWxmLnByZXZpb3VzKSAmJlxuICAgICAgIXByZXZpb3VzVW5iYWxhbmNlZChzZWxmLmV2ZW50cylcbiAgICApIHtcbiAgICAgIGVmZmVjdHMuZW50ZXIoJ2xpdGVyYWxBdXRvbGluaycpXG4gICAgICBlZmZlY3RzLmVudGVyKCdsaXRlcmFsQXV0b2xpbmtIdHRwJylcbiAgICAgIGJ1ZmZlciArPSBTdHJpbmcuZnJvbUNvZGVQb2ludChjb2RlKVxuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICByZXR1cm4gcHJvdG9jb2xQcmVmaXhJbnNpZGVcbiAgICB9XG5cbiAgICByZXR1cm4gbm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gcHJvdG9jb2wuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBodHRwczovL2V4YW1wbGUuY29tL2E/YiNjXG4gICAqICAgICBeXl5eXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gcHJvdG9jb2xQcmVmaXhJbnNpZGUoY29kZSkge1xuICAgIC8vIGA1YCBpcyBzaXplIG9mIGBodHRwc2BcbiAgICBpZiAoYXNjaWlBbHBoYShjb2RlKSAmJiBidWZmZXIubGVuZ3RoIDwgNSkge1xuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvcjogZGVmaW5pdGVseSBudW1iZXIuXG4gICAgICBidWZmZXIgKz0gU3RyaW5nLmZyb21Db2RlUG9pbnQoY29kZSlcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgcmV0dXJuIHByb3RvY29sUHJlZml4SW5zaWRlXG4gICAgfVxuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLmNvbG9uKSB7XG4gICAgICBjb25zdCBwcm90b2NvbCA9IGJ1ZmZlci50b0xvd2VyQ2FzZSgpXG5cbiAgICAgIGlmIChwcm90b2NvbCA9PT0gJ2h0dHAnIHx8IHByb3RvY29sID09PSAnaHR0cHMnKSB7XG4gICAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgICByZXR1cm4gcHJvdG9jb2xTbGFzaGVzSW5zaWRlXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5vayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEluIHNsYXNoZXMuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBodHRwczovL2V4YW1wbGUuY29tL2E/YiNjXG4gICAqICAgICAgICAgICBeXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gcHJvdG9jb2xTbGFzaGVzSW5zaWRlKGNvZGUpIHtcbiAgICBpZiAoY29kZSA9PT0gY29kZXMuc2xhc2gpIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuXG4gICAgICBpZiAoc2Vlbikge1xuICAgICAgICByZXR1cm4gYWZ0ZXJQcm90b2NvbFxuICAgICAgfVxuXG4gICAgICBzZWVuID0gdHJ1ZVxuICAgICAgcmV0dXJuIHByb3RvY29sU2xhc2hlc0luc2lkZVxuICAgIH1cblxuICAgIHJldHVybiBub2soY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBwcm90b2NvbCwgYmVmb3JlIGRvbWFpbi5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogPiB8IGh0dHBzOi8vZXhhbXBsZS5jb20vYT9iI2NcbiAgICogICAgICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gYWZ0ZXJQcm90b2NvbChjb2RlKSB7XG4gICAgLy8gVG8gZG86IHRoaXMgaXMgZGlmZmVyZW50IGZyb20gYG1hcmtkb3duLXJzYDpcbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vd29vb3JtL21hcmtkb3duLXJzL2Jsb2IvYjNhOTIxYzc2MTMwOWFlMDBhNTFmZTM0OGQ4YTQzYWRiYzU0YjUxOC9zcmMvY29uc3RydWN0L2dmbV9hdXRvbGlua19saXRlcmFsLnJzI0wxNzItTDE4MlxuICAgIHJldHVybiBjb2RlID09PSBjb2Rlcy5lb2YgfHxcbiAgICAgIGFzY2lpQ29udHJvbChjb2RlKSB8fFxuICAgICAgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZShjb2RlKSB8fFxuICAgICAgdW5pY29kZVdoaXRlc3BhY2UoY29kZSkgfHxcbiAgICAgIHVuaWNvZGVQdW5jdHVhdGlvbihjb2RlKVxuICAgICAgPyBub2soY29kZSlcbiAgICAgIDogZWZmZWN0cy5hdHRlbXB0KGRvbWFpbiwgZWZmZWN0cy5hdHRlbXB0KHBhdGgsIHByb3RvY29sQWZ0ZXIpLCBub2spKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQWZ0ZXIgYSBwcm90b2NvbCBhdXRvbGluayBsaXRlcmFsLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgaHR0cHM6Ly9leGFtcGxlLmNvbS9hP2IjY1xuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIHByb3RvY29sQWZ0ZXIoY29kZSkge1xuICAgIGVmZmVjdHMuZXhpdCgnbGl0ZXJhbEF1dG9saW5rSHR0cCcpXG4gICAgZWZmZWN0cy5leGl0KCdsaXRlcmFsQXV0b2xpbmsnKVxuICAgIHJldHVybiBvayhjb2RlKVxuICB9XG59XG5cbi8qKlxuICogYHd3d2AgcHJlZml4LlxuICpcbiAqIGBgYG1hcmtkb3duXG4gKiA+IHwgYSB3d3cuZXhhbXBsZS5vcmcgYlxuICogICAgICAgXl5eXlxuICogYGBgXG4gKlxuICogQHRoaXMge1Rva2VuaXplQ29udGV4dH1cbiAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gKi9cbmZ1bmN0aW9uIHRva2VuaXplV3d3UHJlZml4KGVmZmVjdHMsIG9rLCBub2spIHtcbiAgbGV0IHNpemUgPSAwXG5cbiAgcmV0dXJuIHd3d1ByZWZpeEluc2lkZVxuXG4gIC8qKlxuICAgKiBJbiB3d3cgcHJlZml4LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgd3d3LmV4YW1wbGUuY29tXG4gICAqICAgICBeXl5eXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiB3d3dQcmVmaXhJbnNpZGUoY29kZSkge1xuICAgIGlmICgoY29kZSA9PT0gY29kZXMudXBwZXJjYXNlVyB8fCBjb2RlID09PSBjb2Rlcy5sb3dlcmNhc2VXKSAmJiBzaXplIDwgMykge1xuICAgICAgc2l6ZSsrXG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIHJldHVybiB3d3dQcmVmaXhJbnNpZGVcbiAgICB9XG5cbiAgICBpZiAoY29kZSA9PT0gY29kZXMuZG90ICYmIHNpemUgPT09IDMpIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgcmV0dXJuIHd3d1ByZWZpeEFmdGVyXG4gICAgfVxuXG4gICAgcmV0dXJuIG5vayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEFmdGVyIHd3dyBwcmVmaXguXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCB3d3cuZXhhbXBsZS5jb21cbiAgICogICAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiB3d3dQcmVmaXhBZnRlcihjb2RlKSB7XG4gICAgLy8gSWYgdGhlcmUgaXMgKmFueXRoaW5nKiwgd2UgY2FuIGxpbmsuXG4gICAgcmV0dXJuIGNvZGUgPT09IGNvZGVzLmVvZiA/IG5vayhjb2RlKSA6IG9rKGNvZGUpXG4gIH1cbn1cblxuLyoqXG4gKiBEb21haW4uXG4gKlxuICogYGBgbWFya2Rvd25cbiAqID4gfCBhIGh0dHBzOi8vZXhhbXBsZS5vcmcgYlxuICogICAgICAgICAgICAgICBeXl5eXl5eXl5eXlxuICogYGBgXG4gKlxuICogQHRoaXMge1Rva2VuaXplQ29udGV4dH1cbiAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gKi9cbmZ1bmN0aW9uIHRva2VuaXplRG9tYWluKGVmZmVjdHMsIG9rLCBub2spIHtcbiAgLyoqIEB0eXBlIHtib29sZWFuIHwgdW5kZWZpbmVkfSAqL1xuICBsZXQgdW5kZXJzY29yZUluTGFzdFNlZ21lbnRcbiAgLyoqIEB0eXBlIHtib29sZWFuIHwgdW5kZWZpbmVkfSAqL1xuICBsZXQgdW5kZXJzY29yZUluTGFzdExhc3RTZWdtZW50XG4gIC8qKiBAdHlwZSB7Ym9vbGVhbiB8IHVuZGVmaW5lZH0gKi9cbiAgbGV0IHNlZW5cblxuICByZXR1cm4gZG9tYWluSW5zaWRlXG5cbiAgLyoqXG4gICAqIEluIGRvbWFpbi5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogPiB8IGh0dHBzOi8vZXhhbXBsZS5jb20vYVxuICAgKiAgICAgICAgICAgICBeXl5eXl5eXl5eXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gZG9tYWluSW5zaWRlKGNvZGUpIHtcbiAgICAvLyBDaGVjayB3aGV0aGVyIHRoaXMgbWFya2VyLCB3aGljaCBpcyBhIHRyYWlsaW5nIHB1bmN0dWF0aW9uXG4gICAgLy8gbWFya2VyLCBvcHRpb25hbGx5IGZvbGxvd2VkIGJ5IG1vcmUgdHJhaWxpbmcgbWFya2VycywgYW5kIHRoZW5cbiAgICAvLyBmb2xsb3dlZCBieSBhbiBlbmQuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLmRvdCB8fCBjb2RlID09PSBjb2Rlcy51bmRlcnNjb3JlKSB7XG4gICAgICByZXR1cm4gZWZmZWN0cy5jaGVjayh0cmFpbCwgZG9tYWluQWZ0ZXIsIGRvbWFpbkF0UHVuY3R1YXRpb24pKGNvZGUpXG4gICAgfVxuXG4gICAgLy8gR0ggZG9jdW1lbnRzIHRoYXQgb25seSBhbHBoYW51bWVyaWNzIChvdGhlciB0aGFuIGAtYCwgYC5gLCBhbmQgYF9gKSBjYW5cbiAgICAvLyBvY2N1ciwgd2hpY2ggc291bmRzIGxpa2UgQVNDSUkgb25seSwgYnV0IHRoZXkgYWxzbyBzdXBwb3J0IGB3d3cu6bue55yLLmNvbWAsXG4gICAgLy8gc28gdGhhdOKAmXMgVW5pY29kZS5cbiAgICAvLyBJbnN0ZWFkIG9mIHNvbWUgbmV3IHByb2R1Y3Rpb24gZm9yIFVuaWNvZGUgYWxwaGFudW1lcmljcywgbWFya2Rvd25cbiAgICAvLyBhbHJlYWR5IGhhcyB0aGF0IGZvciBVbmljb2RlIHB1bmN0dWF0aW9uIGFuZCB3aGl0ZXNwYWNlLCBzbyB1c2UgdGhvc2UuXG4gICAgLy8gU291cmNlOiA8aHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9jbWFyay1nZm0vYmxvYi9lZjFjZmNiL2V4dGVuc2lvbnMvYXV0b2xpbmsuYyNMMTI+LlxuICAgIGlmIChcbiAgICAgIGNvZGUgPT09IGNvZGVzLmVvZiB8fFxuICAgICAgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZShjb2RlKSB8fFxuICAgICAgdW5pY29kZVdoaXRlc3BhY2UoY29kZSkgfHxcbiAgICAgIChjb2RlICE9PSBjb2Rlcy5kYXNoICYmIHVuaWNvZGVQdW5jdHVhdGlvbihjb2RlKSlcbiAgICApIHtcbiAgICAgIHJldHVybiBkb21haW5BZnRlcihjb2RlKVxuICAgIH1cblxuICAgIHNlZW4gPSB0cnVlXG4gICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgcmV0dXJuIGRvbWFpbkluc2lkZVxuICB9XG5cbiAgLyoqXG4gICAqIEluIGRvbWFpbiwgYXQgcG90ZW50aWFsIHRyYWlsaW5nIHB1bmN0dWF0aW9uLCB0aGF0IHdhcyBub3QgdHJhaWxpbmcuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBodHRwczovL2V4YW1wbGUuY29tXG4gICAqICAgICAgICAgICAgICAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBkb21haW5BdFB1bmN0dWF0aW9uKGNvZGUpIHtcbiAgICAvLyBUaGVyZSBpcyBhbiB1bmRlcnNjb3JlIGluIHRoZSBsYXN0IHNlZ21lbnQgb2YgdGhlIGRvbWFpblxuICAgIGlmIChjb2RlID09PSBjb2Rlcy51bmRlcnNjb3JlKSB7XG4gICAgICB1bmRlcnNjb3JlSW5MYXN0U2VnbWVudCA9IHRydWVcbiAgICB9XG4gICAgLy8gT3RoZXJ3aXNlLCBpdOKAmXMgYSBgLmA6IHNhdmUgdGhlIGxhc3Qgc2VnbWVudCB1bmRlcnNjb3JlIGluIHRoZVxuICAgIC8vIHBlbnVsdGltYXRlIHNlZ21lbnQgc2xvdC5cbiAgICBlbHNlIHtcbiAgICAgIHVuZGVyc2NvcmVJbkxhc3RMYXN0U2VnbWVudCA9IHVuZGVyc2NvcmVJbkxhc3RTZWdtZW50XG4gICAgICB1bmRlcnNjb3JlSW5MYXN0U2VnbWVudCA9IHVuZGVmaW5lZFxuICAgIH1cblxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIHJldHVybiBkb21haW5JbnNpZGVcbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBkb21haW4uXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBodHRwczovL2V4YW1wbGUuY29tL2FcbiAgICogICAgICAgICAgICAgICAgICAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9ICovXG4gIGZ1bmN0aW9uIGRvbWFpbkFmdGVyKGNvZGUpIHtcbiAgICAvLyBOb3RlOiB0aGF04oCZcyBHSCBzYXlzIGEgZG90IGlzIG5lZWRlZCwgYnV0IGl04oCZcyBub3QgdHJ1ZTpcbiAgICAvLyA8aHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9jbWFyay1nZm0vaXNzdWVzLzI3OT5cbiAgICBpZiAodW5kZXJzY29yZUluTGFzdExhc3RTZWdtZW50IHx8IHVuZGVyc2NvcmVJbkxhc3RTZWdtZW50IHx8ICFzZWVuKSB7XG4gICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgfVxuXG4gICAgcmV0dXJuIG9rKGNvZGUpXG4gIH1cbn1cblxuLyoqXG4gKiBQYXRoLlxuICpcbiAqIGBgYG1hcmtkb3duXG4gKiA+IHwgYSBodHRwczovL2V4YW1wbGUub3JnL3N0dWZmIGJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICBeXl5eXl5cbiAqIGBgYFxuICpcbiAqIEB0aGlzIHtUb2tlbml6ZUNvbnRleHR9XG4gKiBAdHlwZSB7VG9rZW5pemVyfVxuICovXG5mdW5jdGlvbiB0b2tlbml6ZVBhdGgoZWZmZWN0cywgb2spIHtcbiAgbGV0IHNpemVPcGVuID0gMFxuICBsZXQgc2l6ZUNsb3NlID0gMFxuXG4gIHJldHVybiBwYXRoSW5zaWRlXG5cbiAgLyoqXG4gICAqIEluIHBhdGguXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBodHRwczovL2V4YW1wbGUuY29tL2FcbiAgICogICAgICAgICAgICAgICAgICAgICAgICBeXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gcGF0aEluc2lkZShjb2RlKSB7XG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLmxlZnRQYXJlbnRoZXNpcykge1xuICAgICAgc2l6ZU9wZW4rK1xuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICByZXR1cm4gcGF0aEluc2lkZVxuICAgIH1cblxuICAgIC8vIFRvIGRvOiBgbWFya2Rvd24tcnNgIGFsc28gbmVlZHMgdGhpcy5cbiAgICAvLyBJZiB0aGlzIGlzIGEgcGFyZW4sIGFuZCB0aGVyZSBhcmUgbGVzcyBjbG9zaW5ncyB0aGFuIG9wZW5pbmdzLFxuICAgIC8vIHdlIGRvbuKAmXQgY2hlY2sgZm9yIGEgdHJhaWwuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLnJpZ2h0UGFyZW50aGVzaXMgJiYgc2l6ZUNsb3NlIDwgc2l6ZU9wZW4pIHtcbiAgICAgIHJldHVybiBwYXRoQXRQdW5jdHVhdGlvbihjb2RlKVxuICAgIH1cblxuICAgIC8vIENoZWNrIHdoZXRoZXIgdGhpcyB0cmFpbGluZyBwdW5jdHVhdGlvbiBtYXJrZXIgaXMgb3B0aW9uYWxseVxuICAgIC8vIGZvbGxvd2VkIGJ5IG1vcmUgdHJhaWxpbmcgbWFya2VycywgYW5kIHRoZW4gZm9sbG93ZWRcbiAgICAvLyBieSBhbiBlbmQuXG4gICAgaWYgKFxuICAgICAgY29kZSA9PT0gY29kZXMuZXhjbGFtYXRpb25NYXJrIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5xdW90YXRpb25NYXJrIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5hbXBlcnNhbmQgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLmFwb3N0cm9waGUgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLnJpZ2h0UGFyZW50aGVzaXMgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLmFzdGVyaXNrIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5jb21tYSB8fFxuICAgICAgY29kZSA9PT0gY29kZXMuZG90IHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5jb2xvbiB8fFxuICAgICAgY29kZSA9PT0gY29kZXMuc2VtaWNvbG9uIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5sZXNzVGhhbiB8fFxuICAgICAgY29kZSA9PT0gY29kZXMucXVlc3Rpb25NYXJrIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5yaWdodFNxdWFyZUJyYWNrZXQgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLnVuZGVyc2NvcmUgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLnRpbGRlXG4gICAgKSB7XG4gICAgICByZXR1cm4gZWZmZWN0cy5jaGVjayh0cmFpbCwgb2ssIHBhdGhBdFB1bmN0dWF0aW9uKShjb2RlKVxuICAgIH1cblxuICAgIGlmIChcbiAgICAgIGNvZGUgPT09IGNvZGVzLmVvZiB8fFxuICAgICAgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZShjb2RlKSB8fFxuICAgICAgdW5pY29kZVdoaXRlc3BhY2UoY29kZSlcbiAgICApIHtcbiAgICAgIHJldHVybiBvayhjb2RlKVxuICAgIH1cblxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIHJldHVybiBwYXRoSW5zaWRlXG4gIH1cblxuICAvKipcbiAgICogSW4gcGF0aCwgYXQgcG90ZW50aWFsIHRyYWlsaW5nIHB1bmN0dWF0aW9uLCB0aGF0IHdhcyBub3QgdHJhaWxpbmcuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBodHRwczovL2V4YW1wbGUuY29tL2FcImJcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIHBhdGhBdFB1bmN0dWF0aW9uKGNvZGUpIHtcbiAgICAvLyBDb3VudCBjbG9zaW5nIHBhcmVucy5cbiAgICBpZiAoY29kZSA9PT0gY29kZXMucmlnaHRQYXJlbnRoZXNpcykge1xuICAgICAgc2l6ZUNsb3NlKytcbiAgICB9XG5cbiAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICByZXR1cm4gcGF0aEluc2lkZVxuICB9XG59XG5cbi8qKlxuICogVHJhaWwuXG4gKlxuICogVGhpcyBjYWxscyBgb2tgIGlmIHRoaXMgKmlzKiB0aGUgdHJhaWwsIGZvbGxvd2VkIGJ5IGFuIGVuZCwgd2hpY2ggbWVhbnNcbiAqIHRoZSBlbnRpcmUgdHJhaWwgaXMgbm90IHBhcnQgb2YgdGhlIGxpbmsuXG4gKiBJdCBjYWxscyBgbm9rYCBpZiB0aGlzICppcyogcGFydCBvZiB0aGUgbGluay5cbiAqXG4gKiBgYGBtYXJrZG93blxuICogPiB8IGh0dHBzOi8vZXhhbXBsZS5jb21cIikuXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIF5eXlxuICogYGBgXG4gKlxuICogQHRoaXMge1Rva2VuaXplQ29udGV4dH1cbiAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gKi9cbmZ1bmN0aW9uIHRva2VuaXplVHJhaWwoZWZmZWN0cywgb2ssIG5vaykge1xuICByZXR1cm4gdHJhaWxcblxuICAvKipcbiAgICogSW4gdHJhaWwgb2YgZG9tYWluIG9yIHBhdGguXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBodHRwczovL2V4YW1wbGUuY29tXCIpLlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIHRyYWlsKGNvZGUpIHtcbiAgICAvLyBSZWd1bGFyIHRyYWlsaW5nIHB1bmN0dWF0aW9uLlxuICAgIGlmIChcbiAgICAgIGNvZGUgPT09IGNvZGVzLmV4Y2xhbWF0aW9uTWFyayB8fFxuICAgICAgY29kZSA9PT0gY29kZXMucXVvdGF0aW9uTWFyayB8fFxuICAgICAgY29kZSA9PT0gY29kZXMuYXBvc3Ryb3BoZSB8fFxuICAgICAgY29kZSA9PT0gY29kZXMucmlnaHRQYXJlbnRoZXNpcyB8fFxuICAgICAgY29kZSA9PT0gY29kZXMuYXN0ZXJpc2sgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLmNvbW1hIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5kb3QgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLmNvbG9uIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5zZW1pY29sb24gfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLnF1ZXN0aW9uTWFyayB8fFxuICAgICAgY29kZSA9PT0gY29kZXMudW5kZXJzY29yZSB8fFxuICAgICAgY29kZSA9PT0gY29kZXMudGlsZGVcbiAgICApIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgcmV0dXJuIHRyYWlsXG4gICAgfVxuXG4gICAgLy8gYCZgIGZvbGxvd2VkIGJ5IG9uZSBvciBtb3JlIGFscGhhYmV0aWNhbHMgYW5kIHRoZW4gYSBgO2AsIGlzXG4gICAgLy8gYXMgYSB3aG9sZSBjb25zaWRlcmVkIGFzIHRyYWlsaW5nIHB1bmN0dWF0aW9uLlxuICAgIC8vIEluIGFsbCBvdGhlciBjYXNlcywgaXQgaXMgY29uc2lkZXJlZCBhcyBjb250aW51YXRpb24gb2YgdGhlIFVSTC5cbiAgICBpZiAoY29kZSA9PT0gY29kZXMuYW1wZXJzYW5kKSB7XG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIHJldHVybiB0cmFpbENoYXJhY3RlclJlZmVyZW5jZVN0YXJ0XG4gICAgfVxuXG4gICAgLy8gTmVlZGVkIGJlY2F1c2Ugd2UgYWxsb3cgbGl0ZXJhbHMgYWZ0ZXIgYFtgLCBhcyB3ZSBmaXg6XG4gICAgLy8gPGh0dHBzOi8vZ2l0aHViLmNvbS9naXRodWIvY21hcmstZ2ZtL2lzc3Vlcy8yNzg+LlxuICAgIC8vIENoZWNrIHRoYXQgaXQgaXMgbm90IGZvbGxvd2VkIGJ5IGAoYCBvciBgW2AuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLnJpZ2h0U3F1YXJlQnJhY2tldCkge1xuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICByZXR1cm4gdHJhaWxCcmFja2V0QWZ0ZXJcbiAgICB9XG5cbiAgICBpZiAoXG4gICAgICAvLyBgPGAgaXMgYW4gZW5kLlxuICAgICAgY29kZSA9PT0gY29kZXMubGVzc1RoYW4gfHxcbiAgICAgIC8vIFNvIGlzIHdoaXRlc3BhY2UuXG4gICAgICBjb2RlID09PSBjb2Rlcy5lb2YgfHxcbiAgICAgIG1hcmtkb3duTGluZUVuZGluZ09yU3BhY2UoY29kZSkgfHxcbiAgICAgIHVuaWNvZGVXaGl0ZXNwYWNlKGNvZGUpXG4gICAgKSB7XG4gICAgICByZXR1cm4gb2soY29kZSlcbiAgICB9XG5cbiAgICByZXR1cm4gbm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gdHJhaWwsIGFmdGVyIGBdYC5cbiAgICpcbiAgICogPiDwn5GJICoqTm90ZSoqOiB0aGlzIGRldmlhdGVzIGZyb20gYGNtYXJrLWdmbWAgdG8gZml4IGEgYnVnLlxuICAgKiA+IFNlZSBlbmQgb2YgPGh0dHBzOi8vZ2l0aHViLmNvbS9naXRodWIvY21hcmstZ2ZtL2lzc3Vlcy8yNzg+IGZvciBtb3JlLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgaHR0cHM6Ly9leGFtcGxlLmNvbV0oXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIHRyYWlsQnJhY2tldEFmdGVyKGNvZGUpIHtcbiAgICAvLyBXaGl0ZXNwYWNlIG9yIHNvbWV0aGluZyB0aGF0IGNvdWxkIHN0YXJ0IGEgcmVzb3VyY2Ugb3IgcmVmZXJlbmNlIGlzIHRoZSBlbmQuXG4gICAgLy8gU3dpdGNoIGJhY2sgdG8gdHJhaWwgb3RoZXJ3aXNlLlxuICAgIGlmIChcbiAgICAgIGNvZGUgPT09IGNvZGVzLmVvZiB8fFxuICAgICAgY29kZSA9PT0gY29kZXMubGVmdFBhcmVudGhlc2lzIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5sZWZ0U3F1YXJlQnJhY2tldCB8fFxuICAgICAgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZShjb2RlKSB8fFxuICAgICAgdW5pY29kZVdoaXRlc3BhY2UoY29kZSlcbiAgICApIHtcbiAgICAgIHJldHVybiBvayhjb2RlKVxuICAgIH1cblxuICAgIHJldHVybiB0cmFpbChjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEluIGNoYXJhY3Rlci1yZWZlcmVuY2UgbGlrZSB0cmFpbCwgYWZ0ZXIgYCZgLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgaHR0cHM6Ly9leGFtcGxlLmNvbSZhbXA7KS5cbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gdHJhaWxDaGFyYWN0ZXJSZWZlcmVuY2VTdGFydChjb2RlKSB7XG4gICAgLy8gV2hlbiBub24tYWxwaGEsIGl04oCZcyBub3QgYSB0cmFpbC5cbiAgICByZXR1cm4gYXNjaWlBbHBoYShjb2RlKSA/IHRyYWlsQ2hhcmFjdGVyUmVmZXJlbmNlSW5zaWRlKGNvZGUpIDogbm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gY2hhcmFjdGVyLXJlZmVyZW5jZSBsaWtlIHRyYWlsLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgaHR0cHM6Ly9leGFtcGxlLmNvbSZhbXA7KS5cbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gdHJhaWxDaGFyYWN0ZXJSZWZlcmVuY2VJbnNpZGUoY29kZSkge1xuICAgIC8vIFN3aXRjaCBiYWNrIHRvIHRyYWlsIGlmIHRoaXMgaXMgd2VsbC1mb3JtZWQuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLnNlbWljb2xvbikge1xuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICByZXR1cm4gdHJhaWxcbiAgICB9XG5cbiAgICBpZiAoYXNjaWlBbHBoYShjb2RlKSkge1xuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICByZXR1cm4gdHJhaWxDaGFyYWN0ZXJSZWZlcmVuY2VJbnNpZGVcbiAgICB9XG5cbiAgICAvLyBJdOKAmXMgbm90IGEgdHJhaWwuXG4gICAgcmV0dXJuIG5vayhjb2RlKVxuICB9XG59XG5cbi8qKlxuICogRG90IGluIGVtYWlsIGRvbWFpbiB0cmFpbC5cbiAqXG4gKiBUaGlzIGNhbGxzIGBva2AgaWYgdGhpcyAqaXMqIHRoZSB0cmFpbCwgZm9sbG93ZWQgYnkgYW4gZW5kLCB3aGljaCBtZWFuc1xuICogdGhlIHRyYWlsIGlzIG5vdCBwYXJ0IG9mIHRoZSBsaW5rLlxuICogSXQgY2FsbHMgYG5va2AgaWYgdGhpcyAqaXMqIHBhcnQgb2YgdGhlIGxpbmsuXG4gKlxuICogYGBgbWFya2Rvd25cbiAqID4gfCBjb250YWN0QGV4YW1wbGUub3JnLlxuICogICAgICAgICAgICAgICAgICAgICAgICBeXG4gKiBgYGBcbiAqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1Rva2VuaXplcn1cbiAqL1xuZnVuY3Rpb24gdG9rZW5pemVFbWFpbERvbWFpbkRvdFRyYWlsKGVmZmVjdHMsIG9rLCBub2spIHtcbiAgcmV0dXJuIHN0YXJ0XG5cbiAgLyoqXG4gICAqIERvdC5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogPiB8IGNvbnRhY3RAZXhhbXBsZS5vcmcuXG4gICAqICAgICAgICAgICAgICAgICAgICBeICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gc3RhcnQoY29kZSkge1xuICAgIC8vIE11c3QgYmUgZG90LlxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIHJldHVybiBhZnRlclxuICB9XG5cbiAgLyoqXG4gICAqIEFmdGVyIGRvdC5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogPiB8IGNvbnRhY3RAZXhhbXBsZS5vcmcuXG4gICAqICAgICAgICAgICAgICAgICAgICAgXiAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGFmdGVyKGNvZGUpIHtcbiAgICAvLyBOb3QgYSB0cmFpbCBpZiBhbHBoYW51bWVyaWMuXG4gICAgcmV0dXJuIGFzY2lpQWxwaGFudW1lcmljKGNvZGUpID8gbm9rKGNvZGUpIDogb2soY29kZSlcbiAgfVxufVxuXG4vKipcbiAqIFNlZTpcbiAqIDxodHRwczovL2dpdGh1Yi5jb20vZ2l0aHViL2NtYXJrLWdmbS9ibG9iL2VmMWNmY2IvZXh0ZW5zaW9ucy9hdXRvbGluay5jI0wxNTY+LlxuICpcbiAqIEB0eXBlIHtQcmV2aW91c31cbiAqL1xuZnVuY3Rpb24gcHJldmlvdXNXd3coY29kZSkge1xuICByZXR1cm4gKFxuICAgIGNvZGUgPT09IGNvZGVzLmVvZiB8fFxuICAgIGNvZGUgPT09IGNvZGVzLmxlZnRQYXJlbnRoZXNpcyB8fFxuICAgIGNvZGUgPT09IGNvZGVzLmFzdGVyaXNrIHx8XG4gICAgY29kZSA9PT0gY29kZXMudW5kZXJzY29yZSB8fFxuICAgIGNvZGUgPT09IGNvZGVzLmxlZnRTcXVhcmVCcmFja2V0IHx8XG4gICAgY29kZSA9PT0gY29kZXMucmlnaHRTcXVhcmVCcmFja2V0IHx8XG4gICAgY29kZSA9PT0gY29kZXMudGlsZGUgfHxcbiAgICBtYXJrZG93bkxpbmVFbmRpbmdPclNwYWNlKGNvZGUpXG4gIClcbn1cblxuLyoqXG4gKiBTZWU6XG4gKiA8aHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9jbWFyay1nZm0vYmxvYi9lZjFjZmNiL2V4dGVuc2lvbnMvYXV0b2xpbmsuYyNMMjE0Pi5cbiAqXG4gKiBAdHlwZSB7UHJldmlvdXN9XG4gKi9cbmZ1bmN0aW9uIHByZXZpb3VzUHJvdG9jb2woY29kZSkge1xuICByZXR1cm4gIWFzY2lpQWxwaGEoY29kZSlcbn1cblxuLyoqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1ByZXZpb3VzfVxuICovXG5mdW5jdGlvbiBwcmV2aW91c0VtYWlsKGNvZGUpIHtcbiAgLy8gRG8gbm90IGFsbG93IGEgc2xhc2gg4oCcaW5zaWRl4oCdIGF0ZXh0LlxuICAvLyBUaGUgcmVmZXJlbmNlIGNvZGUgaXMgYSBiaXQgd2VpcmQsIGJ1dCB0aGF04oCZcyB3aGF0IGl0IHJlc3VsdHMgaW4uXG4gIC8vIFNvdXJjZTogPGh0dHBzOi8vZ2l0aHViLmNvbS9naXRodWIvY21hcmstZ2ZtL2Jsb2IvZWYxY2ZjYi9leHRlbnNpb25zL2F1dG9saW5rLmMjTDMwNz4uXG4gIC8vIE90aGVyIHRoYW4gc2xhc2gsIGV2ZXJ5IHByZWNlZGluZyBjaGFyYWN0ZXIgaXMgYWxsb3dlZC5cbiAgcmV0dXJuICEoY29kZSA9PT0gY29kZXMuc2xhc2ggfHwgZ2ZtQXRleHQoY29kZSkpXG59XG5cbi8qKlxuICogQHBhcmFtIHtDb2RlfSBjb2RlXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gZ2ZtQXRleHQoY29kZSkge1xuICByZXR1cm4gKFxuICAgIGNvZGUgPT09IGNvZGVzLnBsdXNTaWduIHx8XG4gICAgY29kZSA9PT0gY29kZXMuZGFzaCB8fFxuICAgIGNvZGUgPT09IGNvZGVzLmRvdCB8fFxuICAgIGNvZGUgPT09IGNvZGVzLnVuZGVyc2NvcmUgfHxcbiAgICBhc2NpaUFscGhhbnVtZXJpYyhjb2RlKVxuICApXG59XG5cbi8qKlxuICogQHBhcmFtIHtBcnJheTxFdmVudD59IGV2ZW50c1xuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIHByZXZpb3VzVW5iYWxhbmNlZChldmVudHMpIHtcbiAgbGV0IGluZGV4ID0gZXZlbnRzLmxlbmd0aFxuICBsZXQgcmVzdWx0ID0gZmFsc2VcblxuICB3aGlsZSAoaW5kZXgtLSkge1xuICAgIGNvbnN0IHRva2VuID0gZXZlbnRzW2luZGV4XVsxXVxuXG4gICAgaWYgKFxuICAgICAgKHRva2VuLnR5cGUgPT09ICdsYWJlbExpbmsnIHx8IHRva2VuLnR5cGUgPT09ICdsYWJlbEltYWdlJykgJiZcbiAgICAgICF0b2tlbi5fYmFsYW5jZWRcbiAgICApIHtcbiAgICAgIHJlc3VsdCA9IHRydWVcbiAgICAgIGJyZWFrXG4gICAgfVxuXG4gICAgLy8gSWYgd2XigJl2ZSBzZWVuIHRoaXMgdG9rZW4sIGFuZCBpdCB3YXMgbWFya2VkIGFzIG5vdCBoYXZpbmcgYW55IHVuYmFsYW5jZWRcbiAgICAvLyBicmFja2V0IGJlZm9yZSBpdCwgd2UgY2FuIGV4aXQuXG4gICAgaWYgKHRva2VuLl9nZm1BdXRvbGlua0xpdGVyYWxXYWxrZWRJbnRvKSB7XG4gICAgICByZXN1bHQgPSBmYWxzZVxuICAgICAgYnJlYWtcbiAgICB9XG4gIH1cblxuICBpZiAoZXZlbnRzLmxlbmd0aCA+IDAgJiYgIXJlc3VsdCkge1xuICAgIC8vIE1hcmsgdGhlIGxhc3QgdG9rZW4gYXMg4oCcd2Fsa2VkIGludG/igJ0gdy9vIGZpbmRpbmdcbiAgICAvLyBhbnl0aGluZy5cbiAgICBldmVudHNbZXZlbnRzLmxlbmd0aCAtIDFdWzFdLl9nZm1BdXRvbGlua0xpdGVyYWxXYWxrZWRJbnRvID0gdHJ1ZVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtFdmVudCwgRXhpdGVyLCBFeHRlbnNpb24sIFJlc29sdmVyLCBTdGF0ZSwgVG9rZW4sIFRva2VuaXplQ29udGV4dCwgVG9rZW5pemVyfSBmcm9tICdtaWNyb21hcmstdXRpbC10eXBlcydcbiAqL1xuXG5pbXBvcnQge29rIGFzIGFzc2VydH0gZnJvbSAnZGV2bG9wJ1xuaW1wb3J0IHtibGFua0xpbmV9IGZyb20gJ21pY3JvbWFyay1jb3JlLWNvbW1vbm1hcmsnXG5pbXBvcnQge2ZhY3RvcnlTcGFjZX0gZnJvbSAnbWljcm9tYXJrLWZhY3Rvcnktc3BhY2UnXG5pbXBvcnQge21hcmtkb3duTGluZUVuZGluZ09yU3BhY2V9IGZyb20gJ21pY3JvbWFyay11dGlsLWNoYXJhY3RlcidcbmltcG9ydCB7bm9ybWFsaXplSWRlbnRpZmllcn0gZnJvbSAnbWljcm9tYXJrLXV0aWwtbm9ybWFsaXplLWlkZW50aWZpZXInXG5pbXBvcnQge2NvZGVzLCBjb25zdGFudHMsIHR5cGVzfSBmcm9tICdtaWNyb21hcmstdXRpbC1zeW1ib2wnXG5cbmNvbnN0IGluZGVudCA9IHt0b2tlbml6ZTogdG9rZW5pemVJbmRlbnQsIHBhcnRpYWw6IHRydWV9XG5cbi8vIFRvIGRvOiBtaWNyb21hcmsgc2hvdWxkIHN1cHBvcnQgYSBgX2hpZGRlbkdmbUZvb3Rub3RlU3VwcG9ydGAsIHdoaWNoIG9ubHlcbi8vIGFmZmVjdHMgbGFiZWwgc3RhcnQgKGltYWdlKS5cbi8vIFRoYXQgd2lsbCBsZXQgdXMgZHJvcCBgdG9rZW5pemVQb3RlbnRpYWxHZm1Gb290bm90ZSpgLlxuLy8gSXQgY3VycmVudGx5IGhhcyBhIGBfaGlkZGVuRm9vdG5vdGVTdXBwb3J0YCwgd2hpY2ggYWZmZWN0cyB0aGF0IGFuZCBtb3JlLlxuLy8gVGhhdCBjYW4gYmUgcmVtb3ZlZCB3aGVuIGBtaWNyb21hcmstZXh0ZW5zaW9uLWZvb3Rub3RlYCBpcyBhcmNoaXZlZC5cblxuLyoqXG4gKiBDcmVhdGUgYW4gZXh0ZW5zaW9uIGZvciBgbWljcm9tYXJrYCB0byBlbmFibGUgR0ZNIGZvb3Rub3RlIHN5bnRheC5cbiAqXG4gKiBAcmV0dXJucyB7RXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtaWNyb21hcmtgIHRoYXQgY2FuIGJlIHBhc3NlZCBpbiBgZXh0ZW5zaW9uc2AgdG9cbiAqICAgZW5hYmxlIEdGTSBmb290bm90ZSBzeW50YXguXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZm1Gb290bm90ZSgpIHtcbiAgLyoqIEB0eXBlIHtFeHRlbnNpb259ICovXG4gIHJldHVybiB7XG4gICAgZG9jdW1lbnQ6IHtcbiAgICAgIFtjb2Rlcy5sZWZ0U3F1YXJlQnJhY2tldF06IHtcbiAgICAgICAgbmFtZTogJ2dmbUZvb3Rub3RlRGVmaW5pdGlvbicsXG4gICAgICAgIHRva2VuaXplOiB0b2tlbml6ZURlZmluaXRpb25TdGFydCxcbiAgICAgICAgY29udGludWF0aW9uOiB7dG9rZW5pemU6IHRva2VuaXplRGVmaW5pdGlvbkNvbnRpbnVhdGlvbn0sXG4gICAgICAgIGV4aXQ6IGdmbUZvb3Rub3RlRGVmaW5pdGlvbkVuZFxuICAgICAgfVxuICAgIH0sXG4gICAgdGV4dDoge1xuICAgICAgW2NvZGVzLmxlZnRTcXVhcmVCcmFja2V0XToge1xuICAgICAgICBuYW1lOiAnZ2ZtRm9vdG5vdGVDYWxsJyxcbiAgICAgICAgdG9rZW5pemU6IHRva2VuaXplR2ZtRm9vdG5vdGVDYWxsXG4gICAgICB9LFxuICAgICAgW2NvZGVzLnJpZ2h0U3F1YXJlQnJhY2tldF06IHtcbiAgICAgICAgbmFtZTogJ2dmbVBvdGVudGlhbEZvb3Rub3RlQ2FsbCcsXG4gICAgICAgIGFkZDogJ2FmdGVyJyxcbiAgICAgICAgdG9rZW5pemU6IHRva2VuaXplUG90ZW50aWFsR2ZtRm9vdG5vdGVDYWxsLFxuICAgICAgICByZXNvbHZlVG86IHJlc29sdmVUb1BvdGVudGlhbEdmbUZvb3Rub3RlQ2FsbFxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyBUbyBkbzogcmVtb3ZlIGFmdGVyIG1pY3JvbWFyayB1cGRhdGUuXG4vKipcbiAqIEB0aGlzIHtUb2tlbml6ZUNvbnRleHR9XG4gKiBAdHlwZSB7VG9rZW5pemVyfVxuICovXG5mdW5jdGlvbiB0b2tlbml6ZVBvdGVudGlhbEdmbUZvb3Rub3RlQ2FsbChlZmZlY3RzLCBvaywgbm9rKSB7XG4gIGNvbnN0IHNlbGYgPSB0aGlzXG4gIGxldCBpbmRleCA9IHNlbGYuZXZlbnRzLmxlbmd0aFxuICBjb25zdCBkZWZpbmVkID0gc2VsZi5wYXJzZXIuZ2ZtRm9vdG5vdGVzIHx8IChzZWxmLnBhcnNlci5nZm1Gb290bm90ZXMgPSBbXSlcbiAgLyoqIEB0eXBlIHtUb2tlbn0gKi9cbiAgbGV0IGxhYmVsU3RhcnRcblxuICAvLyBGaW5kIGFuIG9wZW5pbmcuXG4gIHdoaWxlIChpbmRleC0tKSB7XG4gICAgY29uc3QgdG9rZW4gPSBzZWxmLmV2ZW50c1tpbmRleF1bMV1cblxuICAgIGlmICh0b2tlbi50eXBlID09PSB0eXBlcy5sYWJlbEltYWdlKSB7XG4gICAgICBsYWJlbFN0YXJ0ID0gdG9rZW5cbiAgICAgIGJyZWFrXG4gICAgfVxuXG4gICAgLy8gRXhpdCBpZiB3ZeKAmXZlIHdhbGtlZCBmYXIgZW5vdWdoLlxuICAgIGlmIChcbiAgICAgIHRva2VuLnR5cGUgPT09ICdnZm1Gb290bm90ZUNhbGwnIHx8XG4gICAgICB0b2tlbi50eXBlID09PSB0eXBlcy5sYWJlbExpbmsgfHxcbiAgICAgIHRva2VuLnR5cGUgPT09IHR5cGVzLmxhYmVsIHx8XG4gICAgICB0b2tlbi50eXBlID09PSB0eXBlcy5pbWFnZSB8fFxuICAgICAgdG9rZW4udHlwZSA9PT0gdHlwZXMubGlua1xuICAgICkge1xuICAgICAgYnJlYWtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gc3RhcnRcblxuICAvKipcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gc3RhcnQoY29kZSkge1xuICAgIGFzc2VydChjb2RlID09PSBjb2Rlcy5yaWdodFNxdWFyZUJyYWNrZXQsICdleHBlY3RlZCBgXWAnKVxuXG4gICAgaWYgKCFsYWJlbFN0YXJ0IHx8ICFsYWJlbFN0YXJ0Ll9iYWxhbmNlZCkge1xuICAgICAgcmV0dXJuIG5vayhjb2RlKVxuICAgIH1cblxuICAgIGNvbnN0IGlkID0gbm9ybWFsaXplSWRlbnRpZmllcihcbiAgICAgIHNlbGYuc2xpY2VTZXJpYWxpemUoe3N0YXJ0OiBsYWJlbFN0YXJ0LmVuZCwgZW5kOiBzZWxmLm5vdygpfSlcbiAgICApXG5cbiAgICBpZiAoaWQuY29kZVBvaW50QXQoMCkgIT09IGNvZGVzLmNhcmV0IHx8ICFkZWZpbmVkLmluY2x1ZGVzKGlkLnNsaWNlKDEpKSkge1xuICAgICAgcmV0dXJuIG5vayhjb2RlKVxuICAgIH1cblxuICAgIGVmZmVjdHMuZW50ZXIoJ2dmbUZvb3Rub3RlQ2FsbExhYmVsTWFya2VyJylcbiAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICBlZmZlY3RzLmV4aXQoJ2dmbUZvb3Rub3RlQ2FsbExhYmVsTWFya2VyJylcbiAgICByZXR1cm4gb2soY29kZSlcbiAgfVxufVxuXG4vLyBUbyBkbzogcmVtb3ZlIGFmdGVyIG1pY3JvbWFyayB1cGRhdGUuXG4vKiogQHR5cGUge1Jlc29sdmVyfSAqL1xuZnVuY3Rpb24gcmVzb2x2ZVRvUG90ZW50aWFsR2ZtRm9vdG5vdGVDYWxsKGV2ZW50cywgY29udGV4dCkge1xuICBsZXQgaW5kZXggPSBldmVudHMubGVuZ3RoXG4gIC8qKiBAdHlwZSB7VG9rZW4gfCB1bmRlZmluZWR9ICovXG4gIGxldCBsYWJlbFN0YXJ0XG5cbiAgLy8gRmluZCBhbiBvcGVuaW5nLlxuICB3aGlsZSAoaW5kZXgtLSkge1xuICAgIGlmIChcbiAgICAgIGV2ZW50c1tpbmRleF1bMV0udHlwZSA9PT0gdHlwZXMubGFiZWxJbWFnZSAmJlxuICAgICAgZXZlbnRzW2luZGV4XVswXSA9PT0gJ2VudGVyJ1xuICAgICkge1xuICAgICAgbGFiZWxTdGFydCA9IGV2ZW50c1tpbmRleF1bMV1cbiAgICAgIGJyZWFrXG4gICAgfVxuICB9XG5cbiAgYXNzZXJ0KGxhYmVsU3RhcnQsICdleHBlY3RlZCBgbGFiZWxTdGFydGAgdG8gcmVzb2x2ZScpXG5cbiAgLy8gQ2hhbmdlIHRoZSBgbGFiZWxJbWFnZU1hcmtlcmAgdG8gYSBgZGF0YWAuXG4gIGV2ZW50c1tpbmRleCArIDFdWzFdLnR5cGUgPSB0eXBlcy5kYXRhXG4gIGV2ZW50c1tpbmRleCArIDNdWzFdLnR5cGUgPSAnZ2ZtRm9vdG5vdGVDYWxsTGFiZWxNYXJrZXInXG5cbiAgLy8gVGhlIHdob2xlICh3aXRob3V0IGAhYCk6XG4gIC8qKiBAdHlwZSB7VG9rZW59ICovXG4gIGNvbnN0IGNhbGwgPSB7XG4gICAgdHlwZTogJ2dmbUZvb3Rub3RlQ2FsbCcsXG4gICAgc3RhcnQ6IE9iamVjdC5hc3NpZ24oe30sIGV2ZW50c1tpbmRleCArIDNdWzFdLnN0YXJ0KSxcbiAgICBlbmQ6IE9iamVjdC5hc3NpZ24oe30sIGV2ZW50c1tldmVudHMubGVuZ3RoIC0gMV1bMV0uZW5kKVxuICB9XG4gIC8vIFRoZSBgXmAgbWFya2VyXG4gIC8qKiBAdHlwZSB7VG9rZW59ICovXG4gIGNvbnN0IG1hcmtlciA9IHtcbiAgICB0eXBlOiAnZ2ZtRm9vdG5vdGVDYWxsTWFya2VyJyxcbiAgICBzdGFydDogT2JqZWN0LmFzc2lnbih7fSwgZXZlbnRzW2luZGV4ICsgM11bMV0uZW5kKSxcbiAgICBlbmQ6IE9iamVjdC5hc3NpZ24oe30sIGV2ZW50c1tpbmRleCArIDNdWzFdLmVuZClcbiAgfVxuICAvLyBJbmNyZW1lbnQgdGhlIGVuZCAxIGNoYXJhY3Rlci5cbiAgbWFya2VyLmVuZC5jb2x1bW4rK1xuICBtYXJrZXIuZW5kLm9mZnNldCsrXG4gIG1hcmtlci5lbmQuX2J1ZmZlckluZGV4KytcbiAgLyoqIEB0eXBlIHtUb2tlbn0gKi9cbiAgY29uc3Qgc3RyaW5nID0ge1xuICAgIHR5cGU6ICdnZm1Gb290bm90ZUNhbGxTdHJpbmcnLFxuICAgIHN0YXJ0OiBPYmplY3QuYXNzaWduKHt9LCBtYXJrZXIuZW5kKSxcbiAgICBlbmQ6IE9iamVjdC5hc3NpZ24oe30sIGV2ZW50c1tldmVudHMubGVuZ3RoIC0gMV1bMV0uc3RhcnQpXG4gIH1cbiAgLyoqIEB0eXBlIHtUb2tlbn0gKi9cbiAgY29uc3QgY2h1bmsgPSB7XG4gICAgdHlwZTogdHlwZXMuY2h1bmtTdHJpbmcsXG4gICAgY29udGVudFR5cGU6ICdzdHJpbmcnLFxuICAgIHN0YXJ0OiBPYmplY3QuYXNzaWduKHt9LCBzdHJpbmcuc3RhcnQpLFxuICAgIGVuZDogT2JqZWN0LmFzc2lnbih7fSwgc3RyaW5nLmVuZClcbiAgfVxuXG4gIC8qKiBAdHlwZSB7QXJyYXk8RXZlbnQ+fSAqL1xuICBjb25zdCByZXBsYWNlbWVudCA9IFtcbiAgICAvLyBUYWtlIHRoZSBgbGFiZWxJbWFnZU1hcmtlcmAgKG5vdyBgZGF0YWAsIHRoZSBgIWApXG4gICAgZXZlbnRzW2luZGV4ICsgMV0sXG4gICAgZXZlbnRzW2luZGV4ICsgMl0sXG4gICAgWydlbnRlcicsIGNhbGwsIGNvbnRleHRdLFxuICAgIC8vIFRoZSBgW2BcbiAgICBldmVudHNbaW5kZXggKyAzXSxcbiAgICBldmVudHNbaW5kZXggKyA0XSxcbiAgICAvLyBUaGUgYF5gLlxuICAgIFsnZW50ZXInLCBtYXJrZXIsIGNvbnRleHRdLFxuICAgIFsnZXhpdCcsIG1hcmtlciwgY29udGV4dF0sXG4gICAgLy8gRXZlcnl0aGluZyBpbiBiZXR3ZWVuLlxuICAgIFsnZW50ZXInLCBzdHJpbmcsIGNvbnRleHRdLFxuICAgIFsnZW50ZXInLCBjaHVuaywgY29udGV4dF0sXG4gICAgWydleGl0JywgY2h1bmssIGNvbnRleHRdLFxuICAgIFsnZXhpdCcsIHN0cmluZywgY29udGV4dF0sXG4gICAgLy8gVGhlIGVuZGluZyAoYF1gLCBwcm9wZXJseSBwYXJzZWQgYW5kIGxhYmVsbGVkKS5cbiAgICBldmVudHNbZXZlbnRzLmxlbmd0aCAtIDJdLFxuICAgIGV2ZW50c1tldmVudHMubGVuZ3RoIC0gMV0sXG4gICAgWydleGl0JywgY2FsbCwgY29udGV4dF1cbiAgXVxuXG4gIGV2ZW50cy5zcGxpY2UoaW5kZXgsIGV2ZW50cy5sZW5ndGggLSBpbmRleCArIDEsIC4uLnJlcGxhY2VtZW50KVxuXG4gIHJldHVybiBldmVudHNcbn1cblxuLyoqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1Rva2VuaXplcn1cbiAqL1xuZnVuY3Rpb24gdG9rZW5pemVHZm1Gb290bm90ZUNhbGwoZWZmZWN0cywgb2ssIG5vaykge1xuICBjb25zdCBzZWxmID0gdGhpc1xuICBjb25zdCBkZWZpbmVkID0gc2VsZi5wYXJzZXIuZ2ZtRm9vdG5vdGVzIHx8IChzZWxmLnBhcnNlci5nZm1Gb290bm90ZXMgPSBbXSlcbiAgbGV0IHNpemUgPSAwXG4gIC8qKiBAdHlwZSB7Ym9vbGVhbn0gKi9cbiAgbGV0IGRhdGFcblxuICAvLyBOb3RlOiB0aGUgaW1wbGVtZW50YXRpb24gb2YgYG1hcmtkb3duLXJzYCBpcyBkaWZmZXJlbnQsIGJlY2F1c2UgaXQgaG91c2VzXG4gIC8vIGNvcmUgKmFuZCogZXh0ZW5zaW9ucyBpbiBvbmUgcHJvamVjdC5cbiAgLy8gVGhlcmVmb3JlLCBpdCBjYW4gaW5jbHVkZSBmb290bm90ZSBsb2dpYyBpbnNpZGUgYGxhYmVsLWVuZGAuXG4gIC8vIFdlIGNhbuKAmXQgZG8gdGhhdCwgYnV0IGx1Y2tpbHksIHdlIGNhbiBwYXJzZSBmb290bm90ZXMgaW4gYSBzaW1wbGVyIHdheSB0aGFuXG4gIC8vIG5lZWRlZCBmb3IgbGFiZWxzLlxuICByZXR1cm4gc3RhcnRcblxuICAvKipcbiAgICogU3RhcnQgb2YgZm9vdG5vdGUgbGFiZWwuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIFteYl0gY1xuICAgKiAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBzdGFydChjb2RlKSB7XG4gICAgYXNzZXJ0KGNvZGUgPT09IGNvZGVzLmxlZnRTcXVhcmVCcmFja2V0LCAnZXhwZWN0ZWQgYFtgJylcbiAgICBlZmZlY3RzLmVudGVyKCdnZm1Gb290bm90ZUNhbGwnKVxuICAgIGVmZmVjdHMuZW50ZXIoJ2dmbUZvb3Rub3RlQ2FsbExhYmVsTWFya2VyJylcbiAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICBlZmZlY3RzLmV4aXQoJ2dmbUZvb3Rub3RlQ2FsbExhYmVsTWFya2VyJylcbiAgICByZXR1cm4gY2FsbFN0YXJ0XG4gIH1cblxuICAvKipcbiAgICogQWZ0ZXIgYFtgLCBhdCBgXmAuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIFteYl0gY1xuICAgKiAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gY2FsbFN0YXJ0KGNvZGUpIHtcbiAgICBpZiAoY29kZSAhPT0gY29kZXMuY2FyZXQpIHJldHVybiBub2soY29kZSlcblxuICAgIGVmZmVjdHMuZW50ZXIoJ2dmbUZvb3Rub3RlQ2FsbE1hcmtlcicpXG4gICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgZWZmZWN0cy5leGl0KCdnZm1Gb290bm90ZUNhbGxNYXJrZXInKVxuICAgIGVmZmVjdHMuZW50ZXIoJ2dmbUZvb3Rub3RlQ2FsbFN0cmluZycpXG4gICAgZWZmZWN0cy5lbnRlcignY2h1bmtTdHJpbmcnKS5jb250ZW50VHlwZSA9ICdzdHJpbmcnXG4gICAgcmV0dXJuIGNhbGxEYXRhXG4gIH1cblxuICAvKipcbiAgICogSW4gbGFiZWwuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIFteYl0gY1xuICAgKiAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGNhbGxEYXRhKGNvZGUpIHtcbiAgICBpZiAoXG4gICAgICAvLyBUb28gbG9uZy5cbiAgICAgIHNpemUgPiBjb25zdGFudHMubGlua1JlZmVyZW5jZVNpemVNYXggfHxcbiAgICAgIC8vIENsb3NpbmcgYnJhY2Ugd2l0aCBub3RoaW5nLlxuICAgICAgKGNvZGUgPT09IGNvZGVzLnJpZ2h0U3F1YXJlQnJhY2tldCAmJiAhZGF0YSkgfHxcbiAgICAgIC8vIFNwYWNlIG9yIHRhYiBpcyBub3Qgc3VwcG9ydGVkIGJ5IEdGTSBmb3Igc29tZSByZWFzb24uXG4gICAgICAvLyBgXFxuYCBhbmQgYFtgIG5vdCBiZWluZyBzdXBwb3J0ZWQgbWFrZXMgc2Vuc2UuXG4gICAgICBjb2RlID09PSBjb2Rlcy5lb2YgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLmxlZnRTcXVhcmVCcmFja2V0IHx8XG4gICAgICBtYXJrZG93bkxpbmVFbmRpbmdPclNwYWNlKGNvZGUpXG4gICAgKSB7XG4gICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgfVxuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLnJpZ2h0U3F1YXJlQnJhY2tldCkge1xuICAgICAgZWZmZWN0cy5leGl0KCdjaHVua1N0cmluZycpXG4gICAgICBjb25zdCB0b2tlbiA9IGVmZmVjdHMuZXhpdCgnZ2ZtRm9vdG5vdGVDYWxsU3RyaW5nJylcblxuICAgICAgaWYgKCFkZWZpbmVkLmluY2x1ZGVzKG5vcm1hbGl6ZUlkZW50aWZpZXIoc2VsZi5zbGljZVNlcmlhbGl6ZSh0b2tlbikpKSkge1xuICAgICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgICB9XG5cbiAgICAgIGVmZmVjdHMuZW50ZXIoJ2dmbUZvb3Rub3RlQ2FsbExhYmVsTWFya2VyJylcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgZWZmZWN0cy5leGl0KCdnZm1Gb290bm90ZUNhbGxMYWJlbE1hcmtlcicpXG4gICAgICBlZmZlY3RzLmV4aXQoJ2dmbUZvb3Rub3RlQ2FsbCcpXG4gICAgICByZXR1cm4gb2tcbiAgICB9XG5cbiAgICBpZiAoIW1hcmtkb3duTGluZUVuZGluZ09yU3BhY2UoY29kZSkpIHtcbiAgICAgIGRhdGEgPSB0cnVlXG4gICAgfVxuXG4gICAgc2l6ZSsrXG4gICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgcmV0dXJuIGNvZGUgPT09IGNvZGVzLmJhY2tzbGFzaCA/IGNhbGxFc2NhcGUgOiBjYWxsRGF0YVxuICB9XG5cbiAgLyoqXG4gICAqIE9uIGNoYXJhY3RlciBhZnRlciBlc2NhcGUuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBhIFteYlxcY10gZFxuICAgKiAgICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gY2FsbEVzY2FwZShjb2RlKSB7XG4gICAgaWYgKFxuICAgICAgY29kZSA9PT0gY29kZXMubGVmdFNxdWFyZUJyYWNrZXQgfHxcbiAgICAgIGNvZGUgPT09IGNvZGVzLmJhY2tzbGFzaCB8fFxuICAgICAgY29kZSA9PT0gY29kZXMucmlnaHRTcXVhcmVCcmFja2V0XG4gICAgKSB7XG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIHNpemUrK1xuICAgICAgcmV0dXJuIGNhbGxEYXRhXG4gICAgfVxuXG4gICAgcmV0dXJuIGNhbGxEYXRhKGNvZGUpXG4gIH1cbn1cblxuLyoqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1Rva2VuaXplcn1cbiAqL1xuZnVuY3Rpb24gdG9rZW5pemVEZWZpbml0aW9uU3RhcnQoZWZmZWN0cywgb2ssIG5vaykge1xuICBjb25zdCBzZWxmID0gdGhpc1xuICBjb25zdCBkZWZpbmVkID0gc2VsZi5wYXJzZXIuZ2ZtRm9vdG5vdGVzIHx8IChzZWxmLnBhcnNlci5nZm1Gb290bm90ZXMgPSBbXSlcbiAgLyoqIEB0eXBlIHtzdHJpbmd9ICovXG4gIGxldCBpZGVudGlmaWVyXG4gIGxldCBzaXplID0gMFxuICAvKiogQHR5cGUge2Jvb2xlYW4gfCB1bmRlZmluZWR9ICovXG4gIGxldCBkYXRhXG5cbiAgcmV0dXJuIHN0YXJ0XG5cbiAgLyoqXG4gICAqIFN0YXJ0IG9mIEdGTSBmb290bm90ZSBkZWZpbml0aW9uLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgW15hXTogYlxuICAgKiAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gc3RhcnQoY29kZSkge1xuICAgIGFzc2VydChjb2RlID09PSBjb2Rlcy5sZWZ0U3F1YXJlQnJhY2tldCwgJ2V4cGVjdGVkIGBbYCcpXG4gICAgZWZmZWN0cy5lbnRlcignZ2ZtRm9vdG5vdGVEZWZpbml0aW9uJykuX2NvbnRhaW5lciA9IHRydWVcbiAgICBlZmZlY3RzLmVudGVyKCdnZm1Gb290bm90ZURlZmluaXRpb25MYWJlbCcpXG4gICAgZWZmZWN0cy5lbnRlcignZ2ZtRm9vdG5vdGVEZWZpbml0aW9uTGFiZWxNYXJrZXInKVxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIGVmZmVjdHMuZXhpdCgnZ2ZtRm9vdG5vdGVEZWZpbml0aW9uTGFiZWxNYXJrZXInKVxuICAgIHJldHVybiBsYWJlbEF0TWFya2VyXG4gIH1cblxuICAvKipcbiAgICogSW4gbGFiZWwsIGF0IGNhcmV0LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgW15hXTogYlxuICAgKiAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGxhYmVsQXRNYXJrZXIoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5jYXJldCkge1xuICAgICAgZWZmZWN0cy5lbnRlcignZ2ZtRm9vdG5vdGVEZWZpbml0aW9uTWFya2VyJylcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgZWZmZWN0cy5leGl0KCdnZm1Gb290bm90ZURlZmluaXRpb25NYXJrZXInKVxuICAgICAgZWZmZWN0cy5lbnRlcignZ2ZtRm9vdG5vdGVEZWZpbml0aW9uTGFiZWxTdHJpbmcnKVxuICAgICAgZWZmZWN0cy5lbnRlcignY2h1bmtTdHJpbmcnKS5jb250ZW50VHlwZSA9ICdzdHJpbmcnXG4gICAgICByZXR1cm4gbGFiZWxJbnNpZGVcbiAgICB9XG5cbiAgICByZXR1cm4gbm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gbGFiZWwuXG4gICAqXG4gICAqID4g8J+RiSAqKk5vdGUqKjogYGNtYXJrLWdmbWAgcHJldmVudHMgd2hpdGVzcGFjZSBmcm9tIG9jY3VycmluZyBpbiBmb290bm90ZVxuICAgKiA+IGRlZmluaXRpb24gbGFiZWxzLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgW15hXTogYlxuICAgKiAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBsYWJlbEluc2lkZShjb2RlKSB7XG4gICAgaWYgKFxuICAgICAgLy8gVG9vIGxvbmcuXG4gICAgICBzaXplID4gY29uc3RhbnRzLmxpbmtSZWZlcmVuY2VTaXplTWF4IHx8XG4gICAgICAvLyBDbG9zaW5nIGJyYWNlIHdpdGggbm90aGluZy5cbiAgICAgIChjb2RlID09PSBjb2Rlcy5yaWdodFNxdWFyZUJyYWNrZXQgJiYgIWRhdGEpIHx8XG4gICAgICAvLyBTcGFjZSBvciB0YWIgaXMgbm90IHN1cHBvcnRlZCBieSBHRk0gZm9yIHNvbWUgcmVhc29uLlxuICAgICAgLy8gYFxcbmAgYW5kIGBbYCBub3QgYmVpbmcgc3VwcG9ydGVkIG1ha2VzIHNlbnNlLlxuICAgICAgY29kZSA9PT0gY29kZXMuZW9mIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5sZWZ0U3F1YXJlQnJhY2tldCB8fFxuICAgICAgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZShjb2RlKVxuICAgICkge1xuICAgICAgcmV0dXJuIG5vayhjb2RlKVxuICAgIH1cblxuICAgIGlmIChjb2RlID09PSBjb2Rlcy5yaWdodFNxdWFyZUJyYWNrZXQpIHtcbiAgICAgIGVmZmVjdHMuZXhpdCgnY2h1bmtTdHJpbmcnKVxuICAgICAgY29uc3QgdG9rZW4gPSBlZmZlY3RzLmV4aXQoJ2dmbUZvb3Rub3RlRGVmaW5pdGlvbkxhYmVsU3RyaW5nJylcbiAgICAgIGlkZW50aWZpZXIgPSBub3JtYWxpemVJZGVudGlmaWVyKHNlbGYuc2xpY2VTZXJpYWxpemUodG9rZW4pKVxuICAgICAgZWZmZWN0cy5lbnRlcignZ2ZtRm9vdG5vdGVEZWZpbml0aW9uTGFiZWxNYXJrZXInKVxuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICBlZmZlY3RzLmV4aXQoJ2dmbUZvb3Rub3RlRGVmaW5pdGlvbkxhYmVsTWFya2VyJylcbiAgICAgIGVmZmVjdHMuZXhpdCgnZ2ZtRm9vdG5vdGVEZWZpbml0aW9uTGFiZWwnKVxuICAgICAgcmV0dXJuIGxhYmVsQWZ0ZXJcbiAgICB9XG5cbiAgICBpZiAoIW1hcmtkb3duTGluZUVuZGluZ09yU3BhY2UoY29kZSkpIHtcbiAgICAgIGRhdGEgPSB0cnVlXG4gICAgfVxuXG4gICAgc2l6ZSsrXG4gICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgcmV0dXJuIGNvZGUgPT09IGNvZGVzLmJhY2tzbGFzaCA/IGxhYmVsRXNjYXBlIDogbGFiZWxJbnNpZGVcbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBgXFxgLCBhdCBhIHNwZWNpYWwgY2hhcmFjdGVyLlxuICAgKlxuICAgKiA+IPCfkYkgKipOb3RlKio6IGBjbWFyay1nZm1gIGN1cnJlbnRseSBkb2VzIG5vdCBzdXBwb3J0IGVzY2FwZWQgYnJhY2tldHM6XG4gICAqID4gPGh0dHBzOi8vZ2l0aHViLmNvbS9naXRodWIvY21hcmstZ2ZtL2lzc3Vlcy8yNDA+XG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCBbXmFcXCpiXTogY1xuICAgKiAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGxhYmVsRXNjYXBlKGNvZGUpIHtcbiAgICBpZiAoXG4gICAgICBjb2RlID09PSBjb2Rlcy5sZWZ0U3F1YXJlQnJhY2tldCB8fFxuICAgICAgY29kZSA9PT0gY29kZXMuYmFja3NsYXNoIHx8XG4gICAgICBjb2RlID09PSBjb2Rlcy5yaWdodFNxdWFyZUJyYWNrZXRcbiAgICApIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgc2l6ZSsrXG4gICAgICByZXR1cm4gbGFiZWxJbnNpZGVcbiAgICB9XG5cbiAgICByZXR1cm4gbGFiZWxJbnNpZGUoY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBkZWZpbml0aW9uIGxhYmVsLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgW15hXTogYlxuICAgKiAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGxhYmVsQWZ0ZXIoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5jb2xvbikge1xuICAgICAgZWZmZWN0cy5lbnRlcignZGVmaW5pdGlvbk1hcmtlcicpXG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIGVmZmVjdHMuZXhpdCgnZGVmaW5pdGlvbk1hcmtlcicpXG5cbiAgICAgIGlmICghZGVmaW5lZC5pbmNsdWRlcyhpZGVudGlmaWVyKSkge1xuICAgICAgICBkZWZpbmVkLnB1c2goaWRlbnRpZmllcilcbiAgICAgIH1cblxuICAgICAgLy8gQW55IHdoaXRlc3BhY2UgYWZ0ZXIgdGhlIG1hcmtlciBpcyBlYXRlbiwgZm9ybWluZyBpbmRlbnRlZCBjb2RlXG4gICAgICAvLyBpcyBub3QgcG9zc2libGUuXG4gICAgICAvLyBObyBzcGFjZSBpcyBhbHNvIGZpbmUsIGp1c3QgbGlrZSBhIGJsb2NrIHF1b3RlIG1hcmtlci5cbiAgICAgIHJldHVybiBmYWN0b3J5U3BhY2UoXG4gICAgICAgIGVmZmVjdHMsXG4gICAgICAgIHdoaXRlc3BhY2VBZnRlcixcbiAgICAgICAgJ2dmbUZvb3Rub3RlRGVmaW5pdGlvbldoaXRlc3BhY2UnXG4gICAgICApXG4gICAgfVxuXG4gICAgcmV0dXJuIG5vayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEFmdGVyIGRlZmluaXRpb24gcHJlZml4LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgW15hXTogYlxuICAgKiAgICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gd2hpdGVzcGFjZUFmdGVyKGNvZGUpIHtcbiAgICAvLyBgbWFya2Rvd24tcnNgIGhhcyBhIHdyYXBwaW5nIHRva2VuIGZvciB0aGUgcHJlZml4IHRoYXQgaXMgY2xvc2VkIGhlcmUuXG4gICAgcmV0dXJuIG9rKGNvZGUpXG4gIH1cbn1cblxuLyoqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1Rva2VuaXplcn1cbiAqL1xuZnVuY3Rpb24gdG9rZW5pemVEZWZpbml0aW9uQ29udGludWF0aW9uKGVmZmVjdHMsIG9rLCBub2spIHtcbiAgLy8vIFN0YXJ0IG9mIGZvb3Rub3RlIGRlZmluaXRpb24gY29udGludWF0aW9uLlxuICAvLy9cbiAgLy8vIGBgYG1hcmtkb3duXG4gIC8vLyAgIHwgW15hXTogYlxuICAvLy8gPiB8ICAgICBjXG4gIC8vLyAgICAgXlxuICAvLy8gYGBgXG4gIC8vXG4gIC8vIEVpdGhlciBhIGJsYW5rIGxpbmUsIHdoaWNoIGlzIG9rYXksIG9yIGFuIGluZGVudGVkIHRoaW5nLlxuICByZXR1cm4gZWZmZWN0cy5jaGVjayhibGFua0xpbmUsIG9rLCBlZmZlY3RzLmF0dGVtcHQoaW5kZW50LCBvaywgbm9rKSlcbn1cblxuLyoqIEB0eXBlIHtFeGl0ZXJ9ICovXG5mdW5jdGlvbiBnZm1Gb290bm90ZURlZmluaXRpb25FbmQoZWZmZWN0cykge1xuICBlZmZlY3RzLmV4aXQoJ2dmbUZvb3Rub3RlRGVmaW5pdGlvbicpXG59XG5cbi8qKlxuICogQHRoaXMge1Rva2VuaXplQ29udGV4dH1cbiAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gKi9cbmZ1bmN0aW9uIHRva2VuaXplSW5kZW50KGVmZmVjdHMsIG9rLCBub2spIHtcbiAgY29uc3Qgc2VsZiA9IHRoaXNcblxuICByZXR1cm4gZmFjdG9yeVNwYWNlKFxuICAgIGVmZmVjdHMsXG4gICAgYWZ0ZXJQcmVmaXgsXG4gICAgJ2dmbUZvb3Rub3RlRGVmaW5pdGlvbkluZGVudCcsXG4gICAgY29uc3RhbnRzLnRhYlNpemUgKyAxXG4gIClcblxuICAvKipcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gYWZ0ZXJQcmVmaXgoY29kZSkge1xuICAgIGNvbnN0IHRhaWwgPSBzZWxmLmV2ZW50c1tzZWxmLmV2ZW50cy5sZW5ndGggLSAxXVxuICAgIHJldHVybiB0YWlsICYmXG4gICAgICB0YWlsWzFdLnR5cGUgPT09ICdnZm1Gb290bm90ZURlZmluaXRpb25JbmRlbnQnICYmXG4gICAgICB0YWlsWzJdLnNsaWNlU2VyaWFsaXplKHRhaWxbMV0sIHRydWUpLmxlbmd0aCA9PT0gY29uc3RhbnRzLnRhYlNpemVcbiAgICAgID8gb2soY29kZSlcbiAgICAgIDogbm9rKGNvZGUpXG4gIH1cbn1cbiIsIi8qKlxuICogQGltcG9ydCB7T3B0aW9uc30gZnJvbSAnbWljcm9tYXJrLWV4dGVuc2lvbi1nZm0tc3RyaWtldGhyb3VnaCdcbiAqIEBpbXBvcnQge0V2ZW50LCBFeHRlbnNpb24sIFJlc29sdmVyLCBTdGF0ZSwgVG9rZW4sIFRva2VuaXplQ29udGV4dCwgVG9rZW5pemVyfSBmcm9tICdtaWNyb21hcmstdXRpbC10eXBlcydcbiAqL1xuXG5pbXBvcnQge29rIGFzIGFzc2VydH0gZnJvbSAnZGV2bG9wJ1xuaW1wb3J0IHtzcGxpY2V9IGZyb20gJ21pY3JvbWFyay11dGlsLWNodW5rZWQnXG5pbXBvcnQge2NsYXNzaWZ5Q2hhcmFjdGVyfSBmcm9tICdtaWNyb21hcmstdXRpbC1jbGFzc2lmeS1jaGFyYWN0ZXInXG5pbXBvcnQge3Jlc29sdmVBbGx9IGZyb20gJ21pY3JvbWFyay11dGlsLXJlc29sdmUtYWxsJ1xuaW1wb3J0IHtjb2RlcywgY29uc3RhbnRzLCB0eXBlc30gZnJvbSAnbWljcm9tYXJrLXV0aWwtc3ltYm9sJ1xuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtaWNyb21hcmtgIHRvIGVuYWJsZSBHRk0gc3RyaWtldGhyb3VnaCBzeW50YXguXG4gKlxuICogQHBhcmFtIHtPcHRpb25zIHwgbnVsbCB8IHVuZGVmaW5lZH0gW29wdGlvbnM9e31dXG4gKiAgIENvbmZpZ3VyYXRpb24uXG4gKiBAcmV0dXJucyB7RXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtaWNyb21hcmtgIHRoYXQgY2FuIGJlIHBhc3NlZCBpbiBgZXh0ZW5zaW9uc2AsIHRvXG4gKiAgIGVuYWJsZSBHRk0gc3RyaWtldGhyb3VnaCBzeW50YXguXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZm1TdHJpa2V0aHJvdWdoKG9wdGlvbnMpIHtcbiAgY29uc3Qgb3B0aW9uc18gPSBvcHRpb25zIHx8IHt9XG4gIGxldCBzaW5nbGUgPSBvcHRpb25zXy5zaW5nbGVUaWxkZVxuICBjb25zdCB0b2tlbml6ZXIgPSB7XG4gICAgbmFtZTogJ3N0cmlrZXRocm91Z2gnLFxuICAgIHRva2VuaXplOiB0b2tlbml6ZVN0cmlrZXRocm91Z2gsXG4gICAgcmVzb2x2ZUFsbDogcmVzb2x2ZUFsbFN0cmlrZXRocm91Z2hcbiAgfVxuXG4gIGlmIChzaW5nbGUgPT09IG51bGwgfHwgc2luZ2xlID09PSB1bmRlZmluZWQpIHtcbiAgICBzaW5nbGUgPSB0cnVlXG4gIH1cblxuICByZXR1cm4ge1xuICAgIHRleHQ6IHtbY29kZXMudGlsZGVdOiB0b2tlbml6ZXJ9LFxuICAgIGluc2lkZVNwYW46IHtudWxsOiBbdG9rZW5pemVyXX0sXG4gICAgYXR0ZW50aW9uTWFya2Vyczoge251bGw6IFtjb2Rlcy50aWxkZV19XG4gIH1cblxuICAvKipcbiAgICogVGFrZSBldmVudHMgYW5kIHJlc29sdmUgc3RyaWtldGhyb3VnaC5cbiAgICpcbiAgICogQHR5cGUge1Jlc29sdmVyfVxuICAgKi9cbiAgZnVuY3Rpb24gcmVzb2x2ZUFsbFN0cmlrZXRocm91Z2goZXZlbnRzLCBjb250ZXh0KSB7XG4gICAgbGV0IGluZGV4ID0gLTFcblxuICAgIC8vIFdhbGsgdGhyb3VnaCBhbGwgZXZlbnRzLlxuICAgIHdoaWxlICgrK2luZGV4IDwgZXZlbnRzLmxlbmd0aCkge1xuICAgICAgLy8gRmluZCBhIHRva2VuIHRoYXQgY2FuIGNsb3NlLlxuICAgICAgaWYgKFxuICAgICAgICBldmVudHNbaW5kZXhdWzBdID09PSAnZW50ZXInICYmXG4gICAgICAgIGV2ZW50c1tpbmRleF1bMV0udHlwZSA9PT0gJ3N0cmlrZXRocm91Z2hTZXF1ZW5jZVRlbXBvcmFyeScgJiZcbiAgICAgICAgZXZlbnRzW2luZGV4XVsxXS5fY2xvc2VcbiAgICAgICkge1xuICAgICAgICBsZXQgb3BlbiA9IGluZGV4XG5cbiAgICAgICAgLy8gTm93IHdhbGsgYmFjayB0byBmaW5kIGFuIG9wZW5lci5cbiAgICAgICAgd2hpbGUgKG9wZW4tLSkge1xuICAgICAgICAgIC8vIEZpbmQgYSB0b2tlbiB0aGF0IGNhbiBvcGVuIHRoZSBjbG9zZXIuXG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgZXZlbnRzW29wZW5dWzBdID09PSAnZXhpdCcgJiZcbiAgICAgICAgICAgIGV2ZW50c1tvcGVuXVsxXS50eXBlID09PSAnc3RyaWtldGhyb3VnaFNlcXVlbmNlVGVtcG9yYXJ5JyAmJlxuICAgICAgICAgICAgZXZlbnRzW29wZW5dWzFdLl9vcGVuICYmXG4gICAgICAgICAgICAvLyBJZiB0aGUgc2l6ZXMgYXJlIHRoZSBzYW1lOlxuICAgICAgICAgICAgZXZlbnRzW2luZGV4XVsxXS5lbmQub2Zmc2V0IC0gZXZlbnRzW2luZGV4XVsxXS5zdGFydC5vZmZzZXQgPT09XG4gICAgICAgICAgICAgIGV2ZW50c1tvcGVuXVsxXS5lbmQub2Zmc2V0IC0gZXZlbnRzW29wZW5dWzFdLnN0YXJ0Lm9mZnNldFxuICAgICAgICAgICkge1xuICAgICAgICAgICAgZXZlbnRzW2luZGV4XVsxXS50eXBlID0gJ3N0cmlrZXRocm91Z2hTZXF1ZW5jZSdcbiAgICAgICAgICAgIGV2ZW50c1tvcGVuXVsxXS50eXBlID0gJ3N0cmlrZXRocm91Z2hTZXF1ZW5jZSdcblxuICAgICAgICAgICAgLyoqIEB0eXBlIHtUb2tlbn0gKi9cbiAgICAgICAgICAgIGNvbnN0IHN0cmlrZXRocm91Z2ggPSB7XG4gICAgICAgICAgICAgIHR5cGU6ICdzdHJpa2V0aHJvdWdoJyxcbiAgICAgICAgICAgICAgc3RhcnQ6IE9iamVjdC5hc3NpZ24oe30sIGV2ZW50c1tvcGVuXVsxXS5zdGFydCksXG4gICAgICAgICAgICAgIGVuZDogT2JqZWN0LmFzc2lnbih7fSwgZXZlbnRzW2luZGV4XVsxXS5lbmQpXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8qKiBAdHlwZSB7VG9rZW59ICovXG4gICAgICAgICAgICBjb25zdCB0ZXh0ID0ge1xuICAgICAgICAgICAgICB0eXBlOiAnc3RyaWtldGhyb3VnaFRleHQnLFxuICAgICAgICAgICAgICBzdGFydDogT2JqZWN0LmFzc2lnbih7fSwgZXZlbnRzW29wZW5dWzFdLmVuZCksXG4gICAgICAgICAgICAgIGVuZDogT2JqZWN0LmFzc2lnbih7fSwgZXZlbnRzW2luZGV4XVsxXS5zdGFydClcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gT3BlbmluZy5cbiAgICAgICAgICAgIC8qKiBAdHlwZSB7QXJyYXk8RXZlbnQ+fSAqL1xuICAgICAgICAgICAgY29uc3QgbmV4dEV2ZW50cyA9IFtcbiAgICAgICAgICAgICAgWydlbnRlcicsIHN0cmlrZXRocm91Z2gsIGNvbnRleHRdLFxuICAgICAgICAgICAgICBbJ2VudGVyJywgZXZlbnRzW29wZW5dWzFdLCBjb250ZXh0XSxcbiAgICAgICAgICAgICAgWydleGl0JywgZXZlbnRzW29wZW5dWzFdLCBjb250ZXh0XSxcbiAgICAgICAgICAgICAgWydlbnRlcicsIHRleHQsIGNvbnRleHRdXG4gICAgICAgICAgICBdXG5cbiAgICAgICAgICAgIGNvbnN0IGluc2lkZVNwYW4gPSBjb250ZXh0LnBhcnNlci5jb25zdHJ1Y3RzLmluc2lkZVNwYW4ubnVsbFxuXG4gICAgICAgICAgICBpZiAoaW5zaWRlU3Bhbikge1xuICAgICAgICAgICAgICAvLyBCZXR3ZWVuLlxuICAgICAgICAgICAgICBzcGxpY2UoXG4gICAgICAgICAgICAgICAgbmV4dEV2ZW50cyxcbiAgICAgICAgICAgICAgICBuZXh0RXZlbnRzLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAwLFxuICAgICAgICAgICAgICAgIHJlc29sdmVBbGwoaW5zaWRlU3BhbiwgZXZlbnRzLnNsaWNlKG9wZW4gKyAxLCBpbmRleCksIGNvbnRleHQpXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gQ2xvc2luZy5cbiAgICAgICAgICAgIHNwbGljZShuZXh0RXZlbnRzLCBuZXh0RXZlbnRzLmxlbmd0aCwgMCwgW1xuICAgICAgICAgICAgICBbJ2V4aXQnLCB0ZXh0LCBjb250ZXh0XSxcbiAgICAgICAgICAgICAgWydlbnRlcicsIGV2ZW50c1tpbmRleF1bMV0sIGNvbnRleHRdLFxuICAgICAgICAgICAgICBbJ2V4aXQnLCBldmVudHNbaW5kZXhdWzFdLCBjb250ZXh0XSxcbiAgICAgICAgICAgICAgWydleGl0Jywgc3RyaWtldGhyb3VnaCwgY29udGV4dF1cbiAgICAgICAgICAgIF0pXG5cbiAgICAgICAgICAgIHNwbGljZShldmVudHMsIG9wZW4gLSAxLCBpbmRleCAtIG9wZW4gKyAzLCBuZXh0RXZlbnRzKVxuXG4gICAgICAgICAgICBpbmRleCA9IG9wZW4gKyBuZXh0RXZlbnRzLmxlbmd0aCAtIDJcbiAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaW5kZXggPSAtMVxuXG4gICAgd2hpbGUgKCsraW5kZXggPCBldmVudHMubGVuZ3RoKSB7XG4gICAgICBpZiAoZXZlbnRzW2luZGV4XVsxXS50eXBlID09PSAnc3RyaWtldGhyb3VnaFNlcXVlbmNlVGVtcG9yYXJ5Jykge1xuICAgICAgICBldmVudHNbaW5kZXhdWzFdLnR5cGUgPSB0eXBlcy5kYXRhXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGV2ZW50c1xuICB9XG5cbiAgLyoqXG4gICAqIEB0aGlzIHtUb2tlbml6ZUNvbnRleHR9XG4gICAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gICAqL1xuICBmdW5jdGlvbiB0b2tlbml6ZVN0cmlrZXRocm91Z2goZWZmZWN0cywgb2ssIG5vaykge1xuICAgIGNvbnN0IHByZXZpb3VzID0gdGhpcy5wcmV2aW91c1xuICAgIGNvbnN0IGV2ZW50cyA9IHRoaXMuZXZlbnRzXG4gICAgbGV0IHNpemUgPSAwXG5cbiAgICByZXR1cm4gc3RhcnRcblxuICAgIC8qKiBAdHlwZSB7U3RhdGV9ICovXG4gICAgZnVuY3Rpb24gc3RhcnQoY29kZSkge1xuICAgICAgYXNzZXJ0KGNvZGUgPT09IGNvZGVzLnRpbGRlLCAnZXhwZWN0ZWQgYH5gJylcblxuICAgICAgaWYgKFxuICAgICAgICBwcmV2aW91cyA9PT0gY29kZXMudGlsZGUgJiZcbiAgICAgICAgZXZlbnRzW2V2ZW50cy5sZW5ndGggLSAxXVsxXS50eXBlICE9PSB0eXBlcy5jaGFyYWN0ZXJFc2NhcGVcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgICB9XG5cbiAgICAgIGVmZmVjdHMuZW50ZXIoJ3N0cmlrZXRocm91Z2hTZXF1ZW5jZVRlbXBvcmFyeScpXG4gICAgICByZXR1cm4gbW9yZShjb2RlKVxuICAgIH1cblxuICAgIC8qKiBAdHlwZSB7U3RhdGV9ICovXG4gICAgZnVuY3Rpb24gbW9yZShjb2RlKSB7XG4gICAgICBjb25zdCBiZWZvcmUgPSBjbGFzc2lmeUNoYXJhY3RlcihwcmV2aW91cylcblxuICAgICAgaWYgKGNvZGUgPT09IGNvZGVzLnRpbGRlKSB7XG4gICAgICAgIC8vIElmIHRoaXMgaXMgdGhlIHRoaXJkIG1hcmtlciwgZXhpdC5cbiAgICAgICAgaWYgKHNpemUgPiAxKSByZXR1cm4gbm9rKGNvZGUpXG4gICAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgICBzaXplKytcbiAgICAgICAgcmV0dXJuIG1vcmVcbiAgICAgIH1cblxuICAgICAgaWYgKHNpemUgPCAyICYmICFzaW5nbGUpIHJldHVybiBub2soY29kZSlcbiAgICAgIGNvbnN0IHRva2VuID0gZWZmZWN0cy5leGl0KCdzdHJpa2V0aHJvdWdoU2VxdWVuY2VUZW1wb3JhcnknKVxuICAgICAgY29uc3QgYWZ0ZXIgPSBjbGFzc2lmeUNoYXJhY3Rlcihjb2RlKVxuICAgICAgdG9rZW4uX29wZW4gPVxuICAgICAgICAhYWZ0ZXIgfHwgKGFmdGVyID09PSBjb25zdGFudHMuYXR0ZW50aW9uU2lkZUFmdGVyICYmIEJvb2xlYW4oYmVmb3JlKSlcbiAgICAgIHRva2VuLl9jbG9zZSA9XG4gICAgICAgICFiZWZvcmUgfHwgKGJlZm9yZSA9PT0gY29uc3RhbnRzLmF0dGVudGlvblNpZGVBZnRlciAmJiBCb29sZWFuKGFmdGVyKSlcbiAgICAgIHJldHVybiBvayhjb2RlKVxuICAgIH1cbiAgfVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtFdmVudH0gZnJvbSAnbWljcm9tYXJrLXV0aWwtdHlwZXMnXG4gKi9cblxuLy8gUG9ydCBvZiBgZWRpdF9tYXAucnNgIGZyb20gYG1hcmtkb3duLXJzYC5cbi8vIFRoaXMgc2hvdWxkIG1vdmUgdG8gYG1hcmtkb3duLWpzYCBsYXRlci5cblxuLy8gRGVhbCB3aXRoIHNldmVyYWwgY2hhbmdlcyBpbiBldmVudHMsIGJhdGNoaW5nIHRoZW0gdG9nZXRoZXIuXG4vL1xuLy8gUHJlZmVyYWJseSwgY2hhbmdlcyBzaG91bGQgYmUga2VwdCB0byBhIG1pbmltdW0uXG4vLyBTb21ldGltZXMsIGl04oCZcyBuZWVkZWQgdG8gY2hhbmdlIHRoZSBsaXN0IG9mIGV2ZW50cywgYmVjYXVzZSBwYXJzaW5nIGNhbiBiZVxuLy8gbWVzc3ksIGFuZCBpdCBoZWxwcyB0byBleHBvc2UgYSBjbGVhbmVyIGludGVyZmFjZSBvZiBldmVudHMgdG8gdGhlIGNvbXBpbGVyXG4vLyBhbmQgb3RoZXIgdXNlcnMuXG4vLyBJdCBjYW4gYWxzbyBoZWxwIHRvIG1lcmdlIG1hbnkgYWRqYWNlbnQgc2ltaWxhciBldmVudHMuXG4vLyBBbmQsIGluIG90aGVyIGNhc2VzLCBpdOKAmXMgbmVlZGVkIHRvIHBhcnNlIHN1YmNvbnRlbnQ6IHBhc3Mgc29tZSBldmVudHNcbi8vIHRocm91Z2ggYW5vdGhlciB0b2tlbml6ZXIgYW5kIGluamVjdCB0aGUgcmVzdWx0LlxuXG4vKipcbiAqIEB0eXBlZGVmIHtbbnVtYmVyLCBudW1iZXIsIEFycmF5PEV2ZW50Pl19IENoYW5nZVxuICogQHR5cGVkZWYge1tudW1iZXIsIG51bWJlciwgbnVtYmVyXX0gSnVtcFxuICovXG5cbi8qKlxuICogVHJhY2tzIGEgYnVuY2ggb2YgZWRpdHMuXG4gKi9cbmV4cG9ydCBjbGFzcyBFZGl0TWFwIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBlZGl0IG1hcC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIC8qKlxuICAgICAqIFJlY29yZCBvZiBjaGFuZ2VzLlxuICAgICAqXG4gICAgICogQHR5cGUge0FycmF5PENoYW5nZT59XG4gICAgICovXG4gICAgdGhpcy5tYXAgPSBbXVxuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhbiBlZGl0OiBhIHJlbW92ZSBhbmQvb3IgYWRkIGF0IGEgY2VydGFpbiBwbGFjZS5cbiAgICpcbiAgICogQHBhcmFtIHtudW1iZXJ9IGluZGV4XG4gICAqIEBwYXJhbSB7bnVtYmVyfSByZW1vdmVcbiAgICogQHBhcmFtIHtBcnJheTxFdmVudD59IGFkZFxuICAgKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICAgKi9cbiAgYWRkKGluZGV4LCByZW1vdmUsIGFkZCkge1xuICAgIGFkZEltcGxlbWVudGF0aW9uKHRoaXMsIGluZGV4LCByZW1vdmUsIGFkZClcbiAgfVxuXG4gIC8vIFRvIGRvOiBhZGQgdGhpcyB3aGVuIG1vdmluZyB0byBgbWljcm9tYXJrYC5cbiAgLy8gLyoqXG4gIC8vICAqIENyZWF0ZSBhbiBlZGl0OiBidXQgaW5zZXJ0IGBhZGRgIGJlZm9yZSBleGlzdGluZyBhZGRpdGlvbnMuXG4gIC8vICAqXG4gIC8vICAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICAvLyAgKiBAcGFyYW0ge251bWJlcn0gcmVtb3ZlXG4gIC8vICAqIEBwYXJhbSB7QXJyYXk8RXZlbnQ+fSBhZGRcbiAgLy8gICogQHJldHVybnMge3VuZGVmaW5lZH1cbiAgLy8gICovXG4gIC8vIGFkZEJlZm9yZShpbmRleCwgcmVtb3ZlLCBhZGQpIHtcbiAgLy8gICBhZGRJbXBsZW1lbnRhdGlvbih0aGlzLCBpbmRleCwgcmVtb3ZlLCBhZGQsIHRydWUpXG4gIC8vIH1cblxuICAvKipcbiAgICogRG9uZSwgY2hhbmdlIHRoZSBldmVudHMuXG4gICAqXG4gICAqIEBwYXJhbSB7QXJyYXk8RXZlbnQ+fSBldmVudHNcbiAgICogQHJldHVybnMge3VuZGVmaW5lZH1cbiAgICovXG4gIGNvbnN1bWUoZXZlbnRzKSB7XG4gICAgdGhpcy5tYXAuc29ydChmdW5jdGlvbiAoYSwgYikge1xuICAgICAgcmV0dXJuIGFbMF0gLSBiWzBdXG4gICAgfSlcblxuICAgIC8qIGM4IGlnbm9yZSBuZXh0IDMgLS0gYHJlc29sdmVgIGlzIG5ldmVyIGNhbGxlZCB3aXRob3V0IHRhYmxlcywgc28gd2l0aG91dCBlZGl0cy4gKi9cbiAgICBpZiAodGhpcy5tYXAubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICAvLyBUbyBkbzogaWYgbGlua3MgYXJlIGFkZGVkIGluIGV2ZW50cywgbGlrZSB0aGV5IGFyZSBpbiBgbWFya2Rvd24tcnNgLFxuICAgIC8vIHRoaXMgaXMgbmVlZGVkLlxuICAgIC8vIC8vIENhbGN1bGF0ZSBqdW1wczogd2hlcmUgaXRlbXMgaW4gdGhlIGN1cnJlbnQgbGlzdCBtb3ZlIHRvLlxuICAgIC8vIC8qKiBAdHlwZSB7QXJyYXk8SnVtcD59ICovXG4gICAgLy8gY29uc3QganVtcHMgPSBbXVxuICAgIC8vIGxldCBpbmRleCA9IDBcbiAgICAvLyBsZXQgYWRkQWNjID0gMFxuICAgIC8vIGxldCByZW1vdmVBY2MgPSAwXG4gICAgLy8gd2hpbGUgKGluZGV4IDwgdGhpcy5tYXAubGVuZ3RoKSB7XG4gICAgLy8gICBjb25zdCBbYXQsIHJlbW92ZSwgYWRkXSA9IHRoaXMubWFwW2luZGV4XVxuICAgIC8vICAgcmVtb3ZlQWNjICs9IHJlbW92ZVxuICAgIC8vICAgYWRkQWNjICs9IGFkZC5sZW5ndGhcbiAgICAvLyAgIGp1bXBzLnB1c2goW2F0LCByZW1vdmVBY2MsIGFkZEFjY10pXG4gICAgLy8gICBpbmRleCArPSAxXG4gICAgLy8gfVxuICAgIC8vXG4gICAgLy8gLiBzaGlmdExpbmtzKGV2ZW50cywganVtcHMpXG5cbiAgICBsZXQgaW5kZXggPSB0aGlzLm1hcC5sZW5ndGhcbiAgICAvKiogQHR5cGUge0FycmF5PEFycmF5PEV2ZW50Pj59ICovXG4gICAgY29uc3QgdmVjcyA9IFtdXG4gICAgd2hpbGUgKGluZGV4ID4gMCkge1xuICAgICAgaW5kZXggLT0gMVxuICAgICAgdmVjcy5wdXNoKFxuICAgICAgICBldmVudHMuc2xpY2UodGhpcy5tYXBbaW5kZXhdWzBdICsgdGhpcy5tYXBbaW5kZXhdWzFdKSxcbiAgICAgICAgdGhpcy5tYXBbaW5kZXhdWzJdXG4gICAgICApXG5cbiAgICAgIC8vIFRydW5jYXRlIHJlc3QuXG4gICAgICBldmVudHMubGVuZ3RoID0gdGhpcy5tYXBbaW5kZXhdWzBdXG4gICAgfVxuXG4gICAgdmVjcy5wdXNoKGV2ZW50cy5zbGljZSgpKVxuICAgIGV2ZW50cy5sZW5ndGggPSAwXG5cbiAgICBsZXQgc2xpY2UgPSB2ZWNzLnBvcCgpXG5cbiAgICB3aGlsZSAoc2xpY2UpIHtcbiAgICAgIGZvciAoY29uc3QgZWxlbWVudCBvZiBzbGljZSkge1xuICAgICAgICBldmVudHMucHVzaChlbGVtZW50KVxuICAgICAgfVxuXG4gICAgICBzbGljZSA9IHZlY3MucG9wKClcbiAgICB9XG5cbiAgICAvLyBUcnVuY2F0ZSBldmVyeXRoaW5nLlxuICAgIHRoaXMubWFwLmxlbmd0aCA9IDBcbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZSBhbiBlZGl0LlxuICpcbiAqIEBwYXJhbSB7RWRpdE1hcH0gZWRpdE1hcFxuICogQHBhcmFtIHtudW1iZXJ9IGF0XG4gKiBAcGFyYW0ge251bWJlcn0gcmVtb3ZlXG4gKiBAcGFyYW0ge0FycmF5PEV2ZW50Pn0gYWRkXG4gKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICovXG5mdW5jdGlvbiBhZGRJbXBsZW1lbnRhdGlvbihlZGl0TWFwLCBhdCwgcmVtb3ZlLCBhZGQpIHtcbiAgbGV0IGluZGV4ID0gMFxuXG4gIC8qIGM4IGlnbm9yZSBuZXh0IDMgLS0gYHJlc29sdmVgIGlzIG5ldmVyIGNhbGxlZCB3aXRob3V0IHRhYmxlcywgc28gd2l0aG91dCBlZGl0cy4gKi9cbiAgaWYgKHJlbW92ZSA9PT0gMCAmJiBhZGQubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuXG4gIH1cblxuICB3aGlsZSAoaW5kZXggPCBlZGl0TWFwLm1hcC5sZW5ndGgpIHtcbiAgICBpZiAoZWRpdE1hcC5tYXBbaW5kZXhdWzBdID09PSBhdCkge1xuICAgICAgZWRpdE1hcC5tYXBbaW5kZXhdWzFdICs9IHJlbW92ZVxuXG4gICAgICAvLyBUbyBkbzogYmVmb3JlIG5vdCB1c2VkIGJ5IHRhYmxlcywgdXNlIHdoZW4gbW92aW5nIHRvIG1pY3JvbWFyay5cbiAgICAgIC8vIGlmIChiZWZvcmUpIHtcbiAgICAgIC8vICAgYWRkLnB1c2goLi4uZWRpdE1hcC5tYXBbaW5kZXhdWzJdKVxuICAgICAgLy8gICBlZGl0TWFwLm1hcFtpbmRleF1bMl0gPSBhZGRcbiAgICAgIC8vIH0gZWxzZSB7XG4gICAgICBlZGl0TWFwLm1hcFtpbmRleF1bMl0ucHVzaCguLi5hZGQpXG4gICAgICAvLyB9XG5cbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGluZGV4ICs9IDFcbiAgfVxuXG4gIGVkaXRNYXAubWFwLnB1c2goW2F0LCByZW1vdmUsIGFkZF0pXG59XG5cbi8vIC8qKlxuLy8gICogU2hpZnQgYHByZXZpb3VzYCBhbmQgYG5leHRgIGxpbmtzIGFjY29yZGluZyB0byBganVtcHNgLlxuLy8gICpcbi8vICAqIFRoaXMgZml4ZXMgbGlua3MgaW4gY2FzZSB0aGVyZSBhcmUgZXZlbnRzIHJlbW92ZWQgb3IgYWRkZWQgYmV0d2VlbiB0aGVtLlxuLy8gICpcbi8vICAqIEBwYXJhbSB7QXJyYXk8RXZlbnQ+fSBldmVudHNcbi8vICAqIEBwYXJhbSB7QXJyYXk8SnVtcD59IGp1bXBzXG4vLyAgKi9cbi8vIGZ1bmN0aW9uIHNoaWZ0TGlua3MoZXZlbnRzLCBqdW1wcykge1xuLy8gICBsZXQganVtcEluZGV4ID0gMFxuLy8gICBsZXQgaW5kZXggPSAwXG4vLyAgIGxldCBhZGQgPSAwXG4vLyAgIGxldCBybSA9IDBcblxuLy8gICB3aGlsZSAoaW5kZXggPCBldmVudHMubGVuZ3RoKSB7XG4vLyAgICAgY29uc3Qgcm1DdXJyID0gcm1cblxuLy8gICAgIHdoaWxlIChqdW1wSW5kZXggPCBqdW1wcy5sZW5ndGggJiYganVtcHNbanVtcEluZGV4XVswXSA8PSBpbmRleCkge1xuLy8gICAgICAgYWRkID0ganVtcHNbanVtcEluZGV4XVsyXVxuLy8gICAgICAgcm0gPSBqdW1wc1tqdW1wSW5kZXhdWzFdXG4vLyAgICAgICBqdW1wSW5kZXggKz0gMVxuLy8gICAgIH1cblxuLy8gICAgIC8vIElnbm9yZSBpdGVtcyB0aGF0IHdpbGwgYmUgcmVtb3ZlZC5cbi8vICAgICBpZiAocm0gPiBybUN1cnIpIHtcbi8vICAgICAgIGluZGV4ICs9IHJtIC0gcm1DdXJyXG4vLyAgICAgfSBlbHNlIHtcbi8vICAgICAgIC8vID9cbi8vICAgICAgIC8vIGlmIGxldCBTb21lKGxpbmspID0gJmV2ZW50c1tpbmRleF0ubGluayB7XG4vLyAgICAgICAvLyAgICAgaWYgbGV0IFNvbWUobmV4dCkgPSBsaW5rLm5leHQge1xuLy8gICAgICAgLy8gICAgICAgICBldmVudHNbbmV4dF0ubGluay5hc19tdXQoKS51bndyYXAoKS5wcmV2aW91cyA9IFNvbWUoaW5kZXggKyBhZGQgLSBybSk7XG4vLyAgICAgICAvLyAgICAgICAgIHdoaWxlIGp1bXBJbmRleCA8IGp1bXBzLmxlbigpICYmIGp1bXBzW2p1bXBJbmRleF0uMCA8PSBuZXh0IHtcbi8vICAgICAgIC8vICAgICAgICAgICAgIGFkZCA9IGp1bXBzW2p1bXBJbmRleF0uMjtcbi8vICAgICAgIC8vICAgICAgICAgICAgIHJtID0ganVtcHNbanVtcEluZGV4XS4xO1xuLy8gICAgICAgLy8gICAgICAgICAgICAganVtcEluZGV4ICs9IDE7XG4vLyAgICAgICAvLyAgICAgICAgIH1cbi8vICAgICAgIC8vICAgICAgICAgZXZlbnRzW2luZGV4XS5saW5rLmFzX211dCgpLnVud3JhcCgpLm5leHQgPSBTb21lKG5leHQgKyBhZGQgLSBybSk7XG4vLyAgICAgICAvLyAgICAgICAgIGluZGV4ID0gbmV4dDtcbi8vICAgICAgIC8vICAgICAgICAgY29udGludWU7XG4vLyAgICAgICAvLyAgICAgfVxuLy8gICAgICAgLy8gfVxuLy8gICAgICAgaW5kZXggKz0gMVxuLy8gICAgIH1cbi8vICAgfVxuLy8gfVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtFdmVudH0gZnJvbSAnbWljcm9tYXJrLXV0aWwtdHlwZXMnXG4gKi9cblxuLyoqXG4gKiBAdHlwZWRlZiB7J2NlbnRlcicgfCAnbGVmdCcgfCAnbm9uZScgfCAncmlnaHQnfSBBbGlnblxuICovXG5cbmltcG9ydCB7b2sgYXMgYXNzZXJ0fSBmcm9tICdkZXZsb3AnXG5cbi8qKlxuICogRmlndXJlIG91dCB0aGUgYWxpZ25tZW50IG9mIGEgR0ZNIHRhYmxlLlxuICpcbiAqIEBwYXJhbSB7UmVhZG9ubHk8QXJyYXk8RXZlbnQ+Pn0gZXZlbnRzXG4gKiAgIExpc3Qgb2YgZXZlbnRzLlxuICogQHBhcmFtIHtudW1iZXJ9IGluZGV4XG4gKiAgIFRhYmxlIGVudGVyIGV2ZW50LlxuICogQHJldHVybnMge0FycmF5PEFsaWduPn1cbiAqICAgTGlzdCBvZiBhbGlnbnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZm1UYWJsZUFsaWduKGV2ZW50cywgaW5kZXgpIHtcbiAgYXNzZXJ0KGV2ZW50c1tpbmRleF1bMV0udHlwZSA9PT0gJ3RhYmxlJywgJ2V4cGVjdGVkIHRhYmxlJylcbiAgbGV0IGluRGVsaW1pdGVyUm93ID0gZmFsc2VcbiAgLyoqIEB0eXBlIHtBcnJheTxBbGlnbj59ICovXG4gIGNvbnN0IGFsaWduID0gW11cblxuICB3aGlsZSAoaW5kZXggPCBldmVudHMubGVuZ3RoKSB7XG4gICAgY29uc3QgZXZlbnQgPSBldmVudHNbaW5kZXhdXG5cbiAgICBpZiAoaW5EZWxpbWl0ZXJSb3cpIHtcbiAgICAgIGlmIChldmVudFswXSA9PT0gJ2VudGVyJykge1xuICAgICAgICAvLyBTdGFydCBvZiBhbGlnbm1lbnQgdmFsdWU6IHNldCBhIG5ldyBjb2x1bW4uXG4gICAgICAgIC8vIFRvIGRvOiBgbWFya2Rvd24tcnNgIHVzZXMgYHRhYmxlRGVsaW1pdGVyQ2VsbFZhbHVlYC5cbiAgICAgICAgaWYgKGV2ZW50WzFdLnR5cGUgPT09ICd0YWJsZUNvbnRlbnQnKSB7XG4gICAgICAgICAgYWxpZ24ucHVzaChcbiAgICAgICAgICAgIGV2ZW50c1tpbmRleCArIDFdWzFdLnR5cGUgPT09ICd0YWJsZURlbGltaXRlck1hcmtlcidcbiAgICAgICAgICAgICAgPyAnbGVmdCdcbiAgICAgICAgICAgICAgOiAnbm9uZSdcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8vIEV4aXRzOlxuICAgICAgLy8gRW5kIG9mIGFsaWdubWVudCB2YWx1ZTogY2hhbmdlIHRoZSBjb2x1bW4uXG4gICAgICAvLyBUbyBkbzogYG1hcmtkb3duLXJzYCB1c2VzIGB0YWJsZURlbGltaXRlckNlbGxWYWx1ZWAuXG4gICAgICBlbHNlIGlmIChldmVudFsxXS50eXBlID09PSAndGFibGVDb250ZW50Jykge1xuICAgICAgICBpZiAoZXZlbnRzW2luZGV4IC0gMV1bMV0udHlwZSA9PT0gJ3RhYmxlRGVsaW1pdGVyTWFya2VyJykge1xuICAgICAgICAgIGNvbnN0IGFsaWduSW5kZXggPSBhbGlnbi5sZW5ndGggLSAxXG5cbiAgICAgICAgICBhbGlnblthbGlnbkluZGV4XSA9IGFsaWduW2FsaWduSW5kZXhdID09PSAnbGVmdCcgPyAnY2VudGVyJyA6ICdyaWdodCdcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLy8gRG9uZSFcbiAgICAgIGVsc2UgaWYgKGV2ZW50WzFdLnR5cGUgPT09ICd0YWJsZURlbGltaXRlclJvdycpIHtcbiAgICAgICAgYnJlYWtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGV2ZW50WzBdID09PSAnZW50ZXInICYmIGV2ZW50WzFdLnR5cGUgPT09ICd0YWJsZURlbGltaXRlclJvdycpIHtcbiAgICAgIGluRGVsaW1pdGVyUm93ID0gdHJ1ZVxuICAgIH1cblxuICAgIGluZGV4ICs9IDFcbiAgfVxuXG4gIHJldHVybiBhbGlnblxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtFdmVudCwgRXh0ZW5zaW9uLCBQb2ludCwgUmVzb2x2ZXIsIFN0YXRlLCBUb2tlbiwgVG9rZW5pemVDb250ZXh0LCBUb2tlbml6ZXJ9IGZyb20gJ21pY3JvbWFyay11dGlsLXR5cGVzJ1xuICovXG5cbi8qKlxuICogQHR5cGVkZWYge1tudW1iZXIsIG51bWJlciwgbnVtYmVyLCBudW1iZXJdfSBSYW5nZVxuICogICBDZWxsIGluZm8uXG4gKlxuICogQHR5cGVkZWYgezAgfCAxIHwgMiB8IDN9IFJvd0tpbmRcbiAqICAgV2hlcmUgd2UgYXJlOiBgMWAgZm9yIGhlYWQgcm93LCBgMmAgZm9yIGRlbGltaXRlciByb3csIGAzYCBmb3IgYm9keSByb3cuXG4gKi9cblxuaW1wb3J0IHtvayBhcyBhc3NlcnR9IGZyb20gJ2RldmxvcCdcbmltcG9ydCB7ZmFjdG9yeVNwYWNlfSBmcm9tICdtaWNyb21hcmstZmFjdG9yeS1zcGFjZSdcbmltcG9ydCB7XG4gIG1hcmtkb3duTGluZUVuZGluZyxcbiAgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZSxcbiAgbWFya2Rvd25TcGFjZVxufSBmcm9tICdtaWNyb21hcmstdXRpbC1jaGFyYWN0ZXInXG5pbXBvcnQge2NvZGVzLCBjb25zdGFudHMsIHR5cGVzfSBmcm9tICdtaWNyb21hcmstdXRpbC1zeW1ib2wnXG5pbXBvcnQge0VkaXRNYXB9IGZyb20gJy4vZWRpdC1tYXAuanMnXG5pbXBvcnQge2dmbVRhYmxlQWxpZ259IGZyb20gJy4vaW5mZXIuanMnXG5cbi8qKlxuICogQ3JlYXRlIGFuIEhUTUwgZXh0ZW5zaW9uIGZvciBgbWljcm9tYXJrYCB0byBzdXBwb3J0IEdpdEh1YiB0YWJsZXMgc3ludGF4LlxuICpcbiAqIEByZXR1cm5zIHtFeHRlbnNpb259XG4gKiAgIEV4dGVuc2lvbiBmb3IgYG1pY3JvbWFya2AgdGhhdCBjYW4gYmUgcGFzc2VkIGluIGBleHRlbnNpb25zYCB0byBlbmFibGUgR0ZNXG4gKiAgIHRhYmxlIHN5bnRheC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdmbVRhYmxlKCkge1xuICByZXR1cm4ge1xuICAgIGZsb3c6IHtcbiAgICAgIG51bGw6IHtuYW1lOiAndGFibGUnLCB0b2tlbml6ZTogdG9rZW5pemVUYWJsZSwgcmVzb2x2ZUFsbDogcmVzb2x2ZVRhYmxlfVxuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIEB0aGlzIHtUb2tlbml6ZUNvbnRleHR9XG4gKiBAdHlwZSB7VG9rZW5pemVyfVxuICovXG5mdW5jdGlvbiB0b2tlbml6ZVRhYmxlKGVmZmVjdHMsIG9rLCBub2spIHtcbiAgY29uc3Qgc2VsZiA9IHRoaXNcbiAgbGV0IHNpemUgPSAwXG4gIGxldCBzaXplQiA9IDBcbiAgLyoqIEB0eXBlIHtib29sZWFuIHwgdW5kZWZpbmVkfSAqL1xuICBsZXQgc2VlblxuXG4gIHJldHVybiBzdGFydFxuXG4gIC8qKlxuICAgKiBTdGFydCBvZiBhIEdGTSB0YWJsZS5cbiAgICpcbiAgICogSWYgdGhlcmUgaXMgYSB2YWxpZCB0YWJsZSByb3cgb3IgdGFibGUgaGVhZCBiZWZvcmUsIHRoZW4gd2UgdHJ5IHRvIHBhcnNlXG4gICAqIGFub3RoZXIgcm93LlxuICAgKiBPdGhlcndpc2UsIHdlIHRyeSB0byBwYXJzZSBhIGhlYWQuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCB8IGEgfFxuICAgKiAgICAgXlxuICAgKiAgIHwgfCAtIHxcbiAgICogPiB8IHwgYiB8XG4gICAqICAgICBeXG4gICAqIGBgYFxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBzdGFydChjb2RlKSB7XG4gICAgbGV0IGluZGV4ID0gc2VsZi5ldmVudHMubGVuZ3RoIC0gMVxuXG4gICAgd2hpbGUgKGluZGV4ID4gLTEpIHtcbiAgICAgIGNvbnN0IHR5cGUgPSBzZWxmLmV2ZW50c1tpbmRleF1bMV0udHlwZVxuICAgICAgaWYgKFxuICAgICAgICB0eXBlID09PSB0eXBlcy5saW5lRW5kaW5nIHx8XG4gICAgICAgIC8vIE5vdGU6IG1hcmtkb3duLXJzIHVzZXMgYHdoaXRlc3BhY2VgIGluc3RlYWQgb2YgYGxpbmVQcmVmaXhgXG4gICAgICAgIHR5cGUgPT09IHR5cGVzLmxpbmVQcmVmaXhcbiAgICAgIClcbiAgICAgICAgaW5kZXgtLVxuICAgICAgZWxzZSBicmVha1xuICAgIH1cblxuICAgIGNvbnN0IHRhaWwgPSBpbmRleCA+IC0xID8gc2VsZi5ldmVudHNbaW5kZXhdWzFdLnR5cGUgOiBudWxsXG5cbiAgICBjb25zdCBuZXh0ID1cbiAgICAgIHRhaWwgPT09ICd0YWJsZUhlYWQnIHx8IHRhaWwgPT09ICd0YWJsZVJvdycgPyBib2R5Um93U3RhcnQgOiBoZWFkUm93QmVmb3JlXG5cbiAgICAvLyBEb27igJl0IGFsbG93IGxhenkgYm9keSByb3dzLlxuICAgIGlmIChuZXh0ID09PSBib2R5Um93U3RhcnQgJiYgc2VsZi5wYXJzZXIubGF6eVtzZWxmLm5vdygpLmxpbmVdKSB7XG4gICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgfVxuXG4gICAgcmV0dXJuIG5leHQoY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBCZWZvcmUgdGFibGUgaGVhZCByb3cuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCB8IGEgfFxuICAgKiAgICAgXlxuICAgKiAgIHwgfCAtIHxcbiAgICogICB8IHwgYiB8XG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBoZWFkUm93QmVmb3JlKGNvZGUpIHtcbiAgICBlZmZlY3RzLmVudGVyKCd0YWJsZUhlYWQnKVxuICAgIGVmZmVjdHMuZW50ZXIoJ3RhYmxlUm93JylcbiAgICByZXR1cm4gaGVhZFJvd1N0YXJ0KGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQmVmb3JlIHRhYmxlIGhlYWQgcm93LCBhZnRlciB3aGl0ZXNwYWNlLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgfCBhIHxcbiAgICogICAgIF5cbiAgICogICB8IHwgLSB8XG4gICAqICAgfCB8IGIgfFxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gaGVhZFJvd1N0YXJ0KGNvZGUpIHtcbiAgICBpZiAoY29kZSA9PT0gY29kZXMudmVydGljYWxCYXIpIHtcbiAgICAgIHJldHVybiBoZWFkUm93QnJlYWsoY29kZSlcbiAgICB9XG5cbiAgICAvLyBUbyBkbzogbWljcm9tYXJrLWpzIHNob3VsZCBsZXQgdXMgcGFyc2Ugb3VyIG93biB3aGl0ZXNwYWNlIGluIGV4dGVuc2lvbnMsXG4gICAgLy8gbGlrZSBgbWFya2Rvd24tcnNgOlxuICAgIC8vXG4gICAgLy8gYGBganNcbiAgICAvLyAvLyA0KyBzcGFjZXMuXG4gICAgLy8gaWYgKG1hcmtkb3duU3BhY2UoY29kZSkpIHtcbiAgICAvLyAgIHJldHVybiBub2soY29kZSlcbiAgICAvLyB9XG4gICAgLy8gYGBgXG5cbiAgICBzZWVuID0gdHJ1ZVxuICAgIC8vIENvdW50IHRoZSBmaXJzdCBjaGFyYWN0ZXIsIHRoYXQgaXNu4oCZdCBhIHBpcGUsIGRvdWJsZS5cbiAgICBzaXplQiArPSAxXG4gICAgcmV0dXJuIGhlYWRSb3dCcmVhayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEF0IGJyZWFrIGluIHRhYmxlIGhlYWQgcm93LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgfCBhIHxcbiAgICogICAgIF5cbiAgICogICAgICAgXlxuICAgKiAgICAgICAgIF5cbiAgICogICB8IHwgLSB8XG4gICAqICAgfCB8IGIgfFxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gaGVhZFJvd0JyZWFrKGNvZGUpIHtcbiAgICBpZiAoY29kZSA9PT0gY29kZXMuZW9mKSB7XG4gICAgICAvLyBOb3RlOiBpbiBgbWFya2Rvd24tcnNgLCB3ZSBuZWVkIHRvIHJlc2V0LCBpbiBgbWljcm9tYXJrLWpzYCB3ZSBkb27igJh0LlxuICAgICAgcmV0dXJuIG5vayhjb2RlKVxuICAgIH1cblxuICAgIGlmIChtYXJrZG93bkxpbmVFbmRpbmcoY29kZSkpIHtcbiAgICAgIC8vIElmIGFueXRoaW5nIG90aGVyIHRoYW4gb25lIHBpcGUgKGlnbm9yaW5nIHdoaXRlc3BhY2UpIHdhcyB1c2VkLCBpdOKAmXMgZmluZS5cbiAgICAgIGlmIChzaXplQiA+IDEpIHtcbiAgICAgICAgc2l6ZUIgPSAwXG4gICAgICAgIC8vIFRvIGRvOiBjaGVjayBpZiB0aGlzIHdvcmtzLlxuICAgICAgICAvLyBGZWVsIGZyZWUgdG8gaW50ZXJydXB0OlxuICAgICAgICBzZWxmLmludGVycnVwdCA9IHRydWVcbiAgICAgICAgZWZmZWN0cy5leGl0KCd0YWJsZVJvdycpXG4gICAgICAgIGVmZmVjdHMuZW50ZXIodHlwZXMubGluZUVuZGluZylcbiAgICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICAgIGVmZmVjdHMuZXhpdCh0eXBlcy5saW5lRW5kaW5nKVxuICAgICAgICByZXR1cm4gaGVhZERlbGltaXRlclN0YXJ0XG4gICAgICB9XG5cbiAgICAgIC8vIE5vdGU6IGluIGBtYXJrZG93bi1yc2AsIHdlIG5lZWQgdG8gcmVzZXQsIGluIGBtaWNyb21hcmstanNgIHdlIGRvbuKAmHQuXG4gICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgfVxuXG4gICAgaWYgKG1hcmtkb3duU3BhY2UoY29kZSkpIHtcbiAgICAgIC8vIFRvIGRvOiBjaGVjayBpZiB0aGlzIGlzIGZpbmUuXG4gICAgICAvLyBlZmZlY3RzLmF0dGVtcHQoU3RhdGU6Ok5leHQoU3RhdGVOYW1lOjpHZm1UYWJsZUhlYWRSb3dCcmVhayksIFN0YXRlOjpOb2spXG4gICAgICAvLyBTdGF0ZTo6UmV0cnkoc3BhY2Vfb3JfdGFiKHRva2VuaXplcikpXG4gICAgICByZXR1cm4gZmFjdG9yeVNwYWNlKGVmZmVjdHMsIGhlYWRSb3dCcmVhaywgdHlwZXMud2hpdGVzcGFjZSkoY29kZSlcbiAgICB9XG5cbiAgICBzaXplQiArPSAxXG5cbiAgICBpZiAoc2Vlbikge1xuICAgICAgc2VlbiA9IGZhbHNlXG4gICAgICAvLyBIZWFkZXIgY2VsbCBjb3VudC5cbiAgICAgIHNpemUgKz0gMVxuICAgIH1cblxuICAgIGlmIChjb2RlID09PSBjb2Rlcy52ZXJ0aWNhbEJhcikge1xuICAgICAgZWZmZWN0cy5lbnRlcigndGFibGVDZWxsRGl2aWRlcicpXG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIGVmZmVjdHMuZXhpdCgndGFibGVDZWxsRGl2aWRlcicpXG4gICAgICAvLyBXaGV0aGVyIGEgZGVsaW1pdGVyIHdhcyBzZWVuLlxuICAgICAgc2VlbiA9IHRydWVcbiAgICAgIHJldHVybiBoZWFkUm93QnJlYWtcbiAgICB9XG5cbiAgICAvLyBBbnl0aGluZyBlbHNlIGlzIGNlbGwgZGF0YS5cbiAgICBlZmZlY3RzLmVudGVyKHR5cGVzLmRhdGEpXG4gICAgcmV0dXJuIGhlYWRSb3dEYXRhKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gdGFibGUgaGVhZCByb3cgZGF0YS5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogPiB8IHwgYSB8XG4gICAqICAgICAgIF5cbiAgICogICB8IHwgLSB8XG4gICAqICAgfCB8IGIgfFxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gaGVhZFJvd0RhdGEoY29kZSkge1xuICAgIGlmIChcbiAgICAgIGNvZGUgPT09IGNvZGVzLmVvZiB8fFxuICAgICAgY29kZSA9PT0gY29kZXMudmVydGljYWxCYXIgfHxcbiAgICAgIG1hcmtkb3duTGluZUVuZGluZ09yU3BhY2UoY29kZSlcbiAgICApIHtcbiAgICAgIGVmZmVjdHMuZXhpdCh0eXBlcy5kYXRhKVxuICAgICAgcmV0dXJuIGhlYWRSb3dCcmVhayhjb2RlKVxuICAgIH1cblxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIHJldHVybiBjb2RlID09PSBjb2Rlcy5iYWNrc2xhc2ggPyBoZWFkUm93RXNjYXBlIDogaGVhZFJvd0RhdGFcbiAgfVxuXG4gIC8qKlxuICAgKiBJbiB0YWJsZSBoZWFkIHJvdyBlc2NhcGUuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCB8IGFcXC1iIHxcbiAgICogICAgICAgICBeXG4gICAqICAgfCB8IC0tLS0gfFxuICAgKiAgIHwgfCBjICAgIHxcbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGhlYWRSb3dFc2NhcGUoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5iYWNrc2xhc2ggfHwgY29kZSA9PT0gY29kZXMudmVydGljYWxCYXIpIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgcmV0dXJuIGhlYWRSb3dEYXRhXG4gICAgfVxuXG4gICAgcmV0dXJuIGhlYWRSb3dEYXRhKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQmVmb3JlIGRlbGltaXRlciByb3cuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqICAgfCB8IGEgfFxuICAgKiA+IHwgfCAtIHxcbiAgICogICAgIF5cbiAgICogICB8IHwgYiB8XG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBoZWFkRGVsaW1pdGVyU3RhcnQoY29kZSkge1xuICAgIC8vIFJlc2V0IGBpbnRlcnJ1cHRgLlxuICAgIHNlbGYuaW50ZXJydXB0ID0gZmFsc2VcblxuICAgIC8vIE5vdGU6IGluIGBtYXJrZG93bi1yc2AsIHdlIG5lZWQgdG8gaGFuZGxlIHBpZXJjaW5nIGhlcmUgdG9vLlxuICAgIGlmIChzZWxmLnBhcnNlci5sYXp5W3NlbGYubm93KCkubGluZV0pIHtcbiAgICAgIHJldHVybiBub2soY29kZSlcbiAgICB9XG5cbiAgICBlZmZlY3RzLmVudGVyKCd0YWJsZURlbGltaXRlclJvdycpXG4gICAgLy8gVHJhY2sgaWYgd2XigJl2ZSBzZWVuIGEgYDpgIG9yIGB8YC5cbiAgICBzZWVuID0gZmFsc2VcblxuICAgIGlmIChtYXJrZG93blNwYWNlKGNvZGUpKSB7XG4gICAgICBhc3NlcnQoc2VsZi5wYXJzZXIuY29uc3RydWN0cy5kaXNhYmxlLm51bGwsICdleHBlY3RlZCBgZGlzYWJsZWQubnVsbGAnKVxuICAgICAgcmV0dXJuIGZhY3RvcnlTcGFjZShcbiAgICAgICAgZWZmZWN0cyxcbiAgICAgICAgaGVhZERlbGltaXRlckJlZm9yZSxcbiAgICAgICAgdHlwZXMubGluZVByZWZpeCxcbiAgICAgICAgc2VsZi5wYXJzZXIuY29uc3RydWN0cy5kaXNhYmxlLm51bGwuaW5jbHVkZXMoJ2NvZGVJbmRlbnRlZCcpXG4gICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICA6IGNvbnN0YW50cy50YWJTaXplXG4gICAgICApKGNvZGUpXG4gICAgfVxuXG4gICAgcmV0dXJuIGhlYWREZWxpbWl0ZXJCZWZvcmUoY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBCZWZvcmUgZGVsaW1pdGVyIHJvdywgYWZ0ZXIgb3B0aW9uYWwgd2hpdGVzcGFjZS5cbiAgICpcbiAgICogUmV1c2VkIHdoZW4gYSBgfGAgaXMgZm91bmQgbGF0ZXIsIHRvIHBhcnNlIGFub3RoZXIgY2VsbC5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogICB8IHwgYSB8XG4gICAqID4gfCB8IC0gfFxuICAgKiAgICAgXlxuICAgKiAgIHwgfCBiIHxcbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGhlYWREZWxpbWl0ZXJCZWZvcmUoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5kYXNoIHx8IGNvZGUgPT09IGNvZGVzLmNvbG9uKSB7XG4gICAgICByZXR1cm4gaGVhZERlbGltaXRlclZhbHVlQmVmb3JlKGNvZGUpXG4gICAgfVxuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLnZlcnRpY2FsQmFyKSB7XG4gICAgICBzZWVuID0gdHJ1ZVxuICAgICAgLy8gSWYgd2Ugc3RhcnQgd2l0aCBhIHBpcGUsIHdlIG9wZW4gYSBjZWxsIG1hcmtlci5cbiAgICAgIGVmZmVjdHMuZW50ZXIoJ3RhYmxlQ2VsbERpdmlkZXInKVxuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICBlZmZlY3RzLmV4aXQoJ3RhYmxlQ2VsbERpdmlkZXInKVxuICAgICAgcmV0dXJuIGhlYWREZWxpbWl0ZXJDZWxsQmVmb3JlXG4gICAgfVxuXG4gICAgLy8gTW9yZSB3aGl0ZXNwYWNlIC8gZW1wdHkgcm93IG5vdCBhbGxvd2VkIGF0IHN0YXJ0LlxuICAgIHJldHVybiBoZWFkRGVsaW1pdGVyTm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQWZ0ZXIgYHxgLCBiZWZvcmUgZGVsaW1pdGVyIGNlbGwuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqICAgfCB8IGEgfFxuICAgKiA+IHwgfCAtIHxcbiAgICogICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBoZWFkRGVsaW1pdGVyQ2VsbEJlZm9yZShjb2RlKSB7XG4gICAgaWYgKG1hcmtkb3duU3BhY2UoY29kZSkpIHtcbiAgICAgIHJldHVybiBmYWN0b3J5U3BhY2UoXG4gICAgICAgIGVmZmVjdHMsXG4gICAgICAgIGhlYWREZWxpbWl0ZXJWYWx1ZUJlZm9yZSxcbiAgICAgICAgdHlwZXMud2hpdGVzcGFjZVxuICAgICAgKShjb2RlKVxuICAgIH1cblxuICAgIHJldHVybiBoZWFkRGVsaW1pdGVyVmFsdWVCZWZvcmUoY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBCZWZvcmUgZGVsaW1pdGVyIGNlbGwgdmFsdWUuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqICAgfCB8IGEgfFxuICAgKiA+IHwgfCAtIHxcbiAgICogICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gaGVhZERlbGltaXRlclZhbHVlQmVmb3JlKGNvZGUpIHtcbiAgICAvLyBBbGlnbjogbGVmdC5cbiAgICBpZiAoY29kZSA9PT0gY29kZXMuY29sb24pIHtcbiAgICAgIHNpemVCICs9IDFcbiAgICAgIHNlZW4gPSB0cnVlXG5cbiAgICAgIGVmZmVjdHMuZW50ZXIoJ3RhYmxlRGVsaW1pdGVyTWFya2VyJylcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgZWZmZWN0cy5leGl0KCd0YWJsZURlbGltaXRlck1hcmtlcicpXG4gICAgICByZXR1cm4gaGVhZERlbGltaXRlckxlZnRBbGlnbm1lbnRBZnRlclxuICAgIH1cblxuICAgIC8vIEFsaWduOiBub25lLlxuICAgIGlmIChjb2RlID09PSBjb2Rlcy5kYXNoKSB7XG4gICAgICBzaXplQiArPSAxXG4gICAgICAvLyBUbyBkbzogc2VlbXMgd2VpcmQgdGhhdCB0aGlzICppc27igJl0KiBsZWZ0IGFsaWduZWQsIGJ1dCB0aGF0IHN0YXRlIGlzIHVzZWQ/XG4gICAgICByZXR1cm4gaGVhZERlbGltaXRlckxlZnRBbGlnbm1lbnRBZnRlcihjb2RlKVxuICAgIH1cblxuICAgIGlmIChjb2RlID09PSBjb2Rlcy5lb2YgfHwgbWFya2Rvd25MaW5lRW5kaW5nKGNvZGUpKSB7XG4gICAgICByZXR1cm4gaGVhZERlbGltaXRlckNlbGxBZnRlcihjb2RlKVxuICAgIH1cblxuICAgIHJldHVybiBoZWFkRGVsaW1pdGVyTm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQWZ0ZXIgZGVsaW1pdGVyIGNlbGwgbGVmdCBhbGlnbm1lbnQgbWFya2VyLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgfCBhICB8XG4gICAqID4gfCB8IDotIHxcbiAgICogICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGhlYWREZWxpbWl0ZXJMZWZ0QWxpZ25tZW50QWZ0ZXIoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5kYXNoKSB7XG4gICAgICBlZmZlY3RzLmVudGVyKCd0YWJsZURlbGltaXRlckZpbGxlcicpXG4gICAgICByZXR1cm4gaGVhZERlbGltaXRlckZpbGxlcihjb2RlKVxuICAgIH1cblxuICAgIC8vIEFueXRoaW5nIGVsc2UgaXMgbm90IG9rIGFmdGVyIHRoZSBsZWZ0LWFsaWduIGNvbG9uLlxuICAgIHJldHVybiBoZWFkRGVsaW1pdGVyTm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gZGVsaW1pdGVyIGNlbGwgZmlsbGVyLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgfCBhIHxcbiAgICogPiB8IHwgLSB8XG4gICAqICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGhlYWREZWxpbWl0ZXJGaWxsZXIoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5kYXNoKSB7XG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIHJldHVybiBoZWFkRGVsaW1pdGVyRmlsbGVyXG4gICAgfVxuXG4gICAgLy8gQWxpZ24gaXMgYGNlbnRlcmAgaWYgaXQgd2FzIGBsZWZ0YCwgYHJpZ2h0YCBvdGhlcndpc2UuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLmNvbG9uKSB7XG4gICAgICBzZWVuID0gdHJ1ZVxuICAgICAgZWZmZWN0cy5leGl0KCd0YWJsZURlbGltaXRlckZpbGxlcicpXG4gICAgICBlZmZlY3RzLmVudGVyKCd0YWJsZURlbGltaXRlck1hcmtlcicpXG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIGVmZmVjdHMuZXhpdCgndGFibGVEZWxpbWl0ZXJNYXJrZXInKVxuICAgICAgcmV0dXJuIGhlYWREZWxpbWl0ZXJSaWdodEFsaWdubWVudEFmdGVyXG4gICAgfVxuXG4gICAgZWZmZWN0cy5leGl0KCd0YWJsZURlbGltaXRlckZpbGxlcicpXG4gICAgcmV0dXJuIGhlYWREZWxpbWl0ZXJSaWdodEFsaWdubWVudEFmdGVyKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQWZ0ZXIgZGVsaW1pdGVyIGNlbGwgcmlnaHQgYWxpZ25tZW50IG1hcmtlci5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogICB8IHwgIGEgfFxuICAgKiA+IHwgfCAtOiB8XG4gICAqICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gaGVhZERlbGltaXRlclJpZ2h0QWxpZ25tZW50QWZ0ZXIoY29kZSkge1xuICAgIGlmIChtYXJrZG93blNwYWNlKGNvZGUpKSB7XG4gICAgICByZXR1cm4gZmFjdG9yeVNwYWNlKFxuICAgICAgICBlZmZlY3RzLFxuICAgICAgICBoZWFkRGVsaW1pdGVyQ2VsbEFmdGVyLFxuICAgICAgICB0eXBlcy53aGl0ZXNwYWNlXG4gICAgICApKGNvZGUpXG4gICAgfVxuXG4gICAgcmV0dXJuIGhlYWREZWxpbWl0ZXJDZWxsQWZ0ZXIoY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBkZWxpbWl0ZXIgY2VsbC5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogICB8IHwgIGEgfFxuICAgKiA+IHwgfCAtOiB8XG4gICAqICAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGhlYWREZWxpbWl0ZXJDZWxsQWZ0ZXIoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy52ZXJ0aWNhbEJhcikge1xuICAgICAgcmV0dXJuIGhlYWREZWxpbWl0ZXJCZWZvcmUoY29kZSlcbiAgICB9XG5cbiAgICBpZiAoY29kZSA9PT0gY29kZXMuZW9mIHx8IG1hcmtkb3duTGluZUVuZGluZyhjb2RlKSkge1xuICAgICAgLy8gRXhpdCB3aGVuOlxuICAgICAgLy8gKiB0aGVyZSB3YXMgbm8gYDpgIG9yIGB8YCBhdCBhbGwgKGl04oCZcyBhIHRoZW1hdGljIGJyZWFrIG9yIHNldGV4dFxuICAgICAgLy8gICB1bmRlcmxpbmUgaW5zdGVhZClcbiAgICAgIC8vICogdGhlIGhlYWRlciBjZWxsIGNvdW50IGlzIG5vdCB0aGUgZGVsaW1pdGVyIGNlbGwgY291bnRcbiAgICAgIGlmICghc2VlbiB8fCBzaXplICE9PSBzaXplQikge1xuICAgICAgICByZXR1cm4gaGVhZERlbGltaXRlck5vayhjb2RlKVxuICAgICAgfVxuXG4gICAgICAvLyBOb3RlOiBpbiBtYXJrZG93bi1yc2AsIGEgcmVzZXQgaXMgbmVlZGVkIGhlcmUuXG4gICAgICBlZmZlY3RzLmV4aXQoJ3RhYmxlRGVsaW1pdGVyUm93JylcbiAgICAgIGVmZmVjdHMuZXhpdCgndGFibGVIZWFkJylcbiAgICAgIC8vIFRvIGRvOiBpbiBgbWFya2Rvd24tcnNgLCByZXNvbHZlcnMgbmVlZCB0byBiZSByZWdpc3RlcmVkIG1hbnVhbGx5LlxuICAgICAgLy8gZWZmZWN0cy5yZWdpc3Rlcl9yZXNvbHZlcihSZXNvbHZlTmFtZTo6R2ZtVGFibGUpXG4gICAgICByZXR1cm4gb2soY29kZSlcbiAgICB9XG5cbiAgICByZXR1cm4gaGVhZERlbGltaXRlck5vayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEluIGRlbGltaXRlciByb3csIGF0IGEgZGlzYWxsb3dlZCBieXRlLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgfCBhIHxcbiAgICogPiB8IHwgeCB8XG4gICAqICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGhlYWREZWxpbWl0ZXJOb2soY29kZSkge1xuICAgIC8vIE5vdGU6IGluIGBtYXJrZG93bi1yc2AsIHdlIG5lZWQgdG8gcmVzZXQsIGluIGBtaWNyb21hcmstanNgIHdlIGRvbuKAmHQuXG4gICAgcmV0dXJuIG5vayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEJlZm9yZSB0YWJsZSBib2R5IHJvdy5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogICB8IHwgYSB8XG4gICAqICAgfCB8IC0gfFxuICAgKiA+IHwgfCBiIHxcbiAgICogICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGJvZHlSb3dTdGFydChjb2RlKSB7XG4gICAgLy8gTm90ZTogaW4gYG1hcmtkb3duLXJzYCB3ZSBuZWVkIHRvIG1hbnVhbGx5IHRha2UgY2FyZSBvZiBhIHByZWZpeCxcbiAgICAvLyBidXQgaW4gYG1pY3JvbWFyay1qc2AgdGhhdCBpcyBkb25lIGZvciB1cywgc28gaWYgd2XigJlyZSBoZXJlLCB3ZeKAmXJlXG4gICAgLy8gbmV2ZXIgYXQgd2hpdGVzcGFjZS5cbiAgICBlZmZlY3RzLmVudGVyKCd0YWJsZVJvdycpXG4gICAgcmV0dXJuIGJvZHlSb3dCcmVhayhjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEF0IGJyZWFrIGluIHRhYmxlIGJvZHkgcm93LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgfCBhIHxcbiAgICogICB8IHwgLSB8XG4gICAqID4gfCB8IGIgfFxuICAgKiAgICAgXlxuICAgKiAgICAgICBeXG4gICAqICAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gYm9keVJvd0JyZWFrKGNvZGUpIHtcbiAgICBpZiAoY29kZSA9PT0gY29kZXMudmVydGljYWxCYXIpIHtcbiAgICAgIGVmZmVjdHMuZW50ZXIoJ3RhYmxlQ2VsbERpdmlkZXInKVxuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICBlZmZlY3RzLmV4aXQoJ3RhYmxlQ2VsbERpdmlkZXInKVxuICAgICAgcmV0dXJuIGJvZHlSb3dCcmVha1xuICAgIH1cblxuICAgIGlmIChjb2RlID09PSBjb2Rlcy5lb2YgfHwgbWFya2Rvd25MaW5lRW5kaW5nKGNvZGUpKSB7XG4gICAgICBlZmZlY3RzLmV4aXQoJ3RhYmxlUm93JylcbiAgICAgIHJldHVybiBvayhjb2RlKVxuICAgIH1cblxuICAgIGlmIChtYXJrZG93blNwYWNlKGNvZGUpKSB7XG4gICAgICByZXR1cm4gZmFjdG9yeVNwYWNlKGVmZmVjdHMsIGJvZHlSb3dCcmVhaywgdHlwZXMud2hpdGVzcGFjZSkoY29kZSlcbiAgICB9XG5cbiAgICAvLyBBbnl0aGluZyBlbHNlIGlzIGNlbGwgY29udGVudC5cbiAgICBlZmZlY3RzLmVudGVyKHR5cGVzLmRhdGEpXG4gICAgcmV0dXJuIGJvZHlSb3dEYXRhKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gdGFibGUgYm9keSByb3cgZGF0YS5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogICB8IHwgYSB8XG4gICAqICAgfCB8IC0gfFxuICAgKiA+IHwgfCBiIHxcbiAgICogICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gYm9keVJvd0RhdGEoY29kZSkge1xuICAgIGlmIChcbiAgICAgIGNvZGUgPT09IGNvZGVzLmVvZiB8fFxuICAgICAgY29kZSA9PT0gY29kZXMudmVydGljYWxCYXIgfHxcbiAgICAgIG1hcmtkb3duTGluZUVuZGluZ09yU3BhY2UoY29kZSlcbiAgICApIHtcbiAgICAgIGVmZmVjdHMuZXhpdCh0eXBlcy5kYXRhKVxuICAgICAgcmV0dXJuIGJvZHlSb3dCcmVhayhjb2RlKVxuICAgIH1cblxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIHJldHVybiBjb2RlID09PSBjb2Rlcy5iYWNrc2xhc2ggPyBib2R5Um93RXNjYXBlIDogYm9keVJvd0RhdGFcbiAgfVxuXG4gIC8qKlxuICAgKiBJbiB0YWJsZSBib2R5IHJvdyBlc2NhcGUuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqICAgfCB8IGEgICAgfFxuICAgKiAgIHwgfCAtLS0tIHxcbiAgICogPiB8IHwgYlxcLWMgfFxuICAgKiAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGJvZHlSb3dFc2NhcGUoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5iYWNrc2xhc2ggfHwgY29kZSA9PT0gY29kZXMudmVydGljYWxCYXIpIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgcmV0dXJuIGJvZHlSb3dEYXRhXG4gICAgfVxuXG4gICAgcmV0dXJuIGJvZHlSb3dEYXRhKGNvZGUpXG4gIH1cbn1cblxuLyoqIEB0eXBlIHtSZXNvbHZlcn0gKi9cblxuZnVuY3Rpb24gcmVzb2x2ZVRhYmxlKGV2ZW50cywgY29udGV4dCkge1xuICBsZXQgaW5kZXggPSAtMVxuICBsZXQgaW5GaXJzdENlbGxBd2FpdGluZ1BpcGUgPSB0cnVlXG4gIC8qKiBAdHlwZSB7Um93S2luZH0gKi9cbiAgbGV0IHJvd0tpbmQgPSAwXG4gIC8qKiBAdHlwZSB7UmFuZ2V9ICovXG4gIGxldCBsYXN0Q2VsbCA9IFswLCAwLCAwLCAwXVxuICAvKiogQHR5cGUge1JhbmdlfSAqL1xuICBsZXQgY2VsbCA9IFswLCAwLCAwLCAwXVxuICBsZXQgYWZ0ZXJIZWFkQXdhaXRpbmdGaXJzdEJvZHlSb3cgPSBmYWxzZVxuICBsZXQgbGFzdFRhYmxlRW5kID0gMFxuICAvKiogQHR5cGUge1Rva2VuIHwgdW5kZWZpbmVkfSAqL1xuICBsZXQgY3VycmVudFRhYmxlXG4gIC8qKiBAdHlwZSB7VG9rZW4gfCB1bmRlZmluZWR9ICovXG4gIGxldCBjdXJyZW50Qm9keVxuICAvKiogQHR5cGUge1Rva2VuIHwgdW5kZWZpbmVkfSAqL1xuICBsZXQgY3VycmVudENlbGxcblxuICBjb25zdCBtYXAgPSBuZXcgRWRpdE1hcCgpXG5cbiAgd2hpbGUgKCsraW5kZXggPCBldmVudHMubGVuZ3RoKSB7XG4gICAgY29uc3QgZXZlbnQgPSBldmVudHNbaW5kZXhdXG4gICAgY29uc3QgdG9rZW4gPSBldmVudFsxXVxuXG4gICAgaWYgKGV2ZW50WzBdID09PSAnZW50ZXInKSB7XG4gICAgICAvLyBTdGFydCBvZiBoZWFkLlxuICAgICAgaWYgKHRva2VuLnR5cGUgPT09ICd0YWJsZUhlYWQnKSB7XG4gICAgICAgIGFmdGVySGVhZEF3YWl0aW5nRmlyc3RCb2R5Um93ID0gZmFsc2VcblxuICAgICAgICAvLyBJbmplY3QgcHJldmlvdXMgKGJvZHkgZW5kIGFuZCkgdGFibGUgZW5kLlxuICAgICAgICBpZiAobGFzdFRhYmxlRW5kICE9PSAwKSB7XG4gICAgICAgICAgYXNzZXJ0KGN1cnJlbnRUYWJsZSwgJ3RoZXJlIHNob3VsZCBiZSBhIHRhYmxlIG9wZW5pbmcnKVxuICAgICAgICAgIGZsdXNoVGFibGVFbmQobWFwLCBjb250ZXh0LCBsYXN0VGFibGVFbmQsIGN1cnJlbnRUYWJsZSwgY3VycmVudEJvZHkpXG4gICAgICAgICAgY3VycmVudEJvZHkgPSB1bmRlZmluZWRcbiAgICAgICAgICBsYXN0VGFibGVFbmQgPSAwXG4gICAgICAgIH1cblxuICAgICAgICAvLyBJbmplY3QgdGFibGUgc3RhcnQuXG4gICAgICAgIGN1cnJlbnRUYWJsZSA9IHtcbiAgICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICAgIHN0YXJ0OiBPYmplY3QuYXNzaWduKHt9LCB0b2tlbi5zdGFydCksXG4gICAgICAgICAgLy8gTm90ZTogY29ycmVjdCBlbmQgaXMgc2V0IGxhdGVyLlxuICAgICAgICAgIGVuZDogT2JqZWN0LmFzc2lnbih7fSwgdG9rZW4uZW5kKVxuICAgICAgICB9XG4gICAgICAgIG1hcC5hZGQoaW5kZXgsIDAsIFtbJ2VudGVyJywgY3VycmVudFRhYmxlLCBjb250ZXh0XV0pXG4gICAgICB9IGVsc2UgaWYgKFxuICAgICAgICB0b2tlbi50eXBlID09PSAndGFibGVSb3cnIHx8XG4gICAgICAgIHRva2VuLnR5cGUgPT09ICd0YWJsZURlbGltaXRlclJvdydcbiAgICAgICkge1xuICAgICAgICBpbkZpcnN0Q2VsbEF3YWl0aW5nUGlwZSA9IHRydWVcbiAgICAgICAgY3VycmVudENlbGwgPSB1bmRlZmluZWRcbiAgICAgICAgbGFzdENlbGwgPSBbMCwgMCwgMCwgMF1cbiAgICAgICAgY2VsbCA9IFswLCBpbmRleCArIDEsIDAsIDBdXG5cbiAgICAgICAgLy8gSW5qZWN0IHRhYmxlIGJvZHkgc3RhcnQuXG4gICAgICAgIGlmIChhZnRlckhlYWRBd2FpdGluZ0ZpcnN0Qm9keVJvdykge1xuICAgICAgICAgIGFmdGVySGVhZEF3YWl0aW5nRmlyc3RCb2R5Um93ID0gZmFsc2VcbiAgICAgICAgICBjdXJyZW50Qm9keSA9IHtcbiAgICAgICAgICAgIHR5cGU6ICd0YWJsZUJvZHknLFxuICAgICAgICAgICAgc3RhcnQ6IE9iamVjdC5hc3NpZ24oe30sIHRva2VuLnN0YXJ0KSxcbiAgICAgICAgICAgIC8vIE5vdGU6IGNvcnJlY3QgZW5kIGlzIHNldCBsYXRlci5cbiAgICAgICAgICAgIGVuZDogT2JqZWN0LmFzc2lnbih7fSwgdG9rZW4uZW5kKVxuICAgICAgICAgIH1cbiAgICAgICAgICBtYXAuYWRkKGluZGV4LCAwLCBbWydlbnRlcicsIGN1cnJlbnRCb2R5LCBjb250ZXh0XV0pXG4gICAgICAgIH1cblxuICAgICAgICByb3dLaW5kID0gdG9rZW4udHlwZSA9PT0gJ3RhYmxlRGVsaW1pdGVyUm93JyA/IDIgOiBjdXJyZW50Qm9keSA/IDMgOiAxXG4gICAgICB9XG4gICAgICAvLyBDZWxsIGRhdGEuXG4gICAgICBlbHNlIGlmIChcbiAgICAgICAgcm93S2luZCAmJlxuICAgICAgICAodG9rZW4udHlwZSA9PT0gdHlwZXMuZGF0YSB8fFxuICAgICAgICAgIHRva2VuLnR5cGUgPT09ICd0YWJsZURlbGltaXRlck1hcmtlcicgfHxcbiAgICAgICAgICB0b2tlbi50eXBlID09PSAndGFibGVEZWxpbWl0ZXJGaWxsZXInKVxuICAgICAgKSB7XG4gICAgICAgIGluRmlyc3RDZWxsQXdhaXRpbmdQaXBlID0gZmFsc2VcblxuICAgICAgICAvLyBGaXJzdCB2YWx1ZSBpbiBjZWxsLlxuICAgICAgICBpZiAoY2VsbFsyXSA9PT0gMCkge1xuICAgICAgICAgIGlmIChsYXN0Q2VsbFsxXSAhPT0gMCkge1xuICAgICAgICAgICAgY2VsbFswXSA9IGNlbGxbMV1cbiAgICAgICAgICAgIGN1cnJlbnRDZWxsID0gZmx1c2hDZWxsKFxuICAgICAgICAgICAgICBtYXAsXG4gICAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICAgIGxhc3RDZWxsLFxuICAgICAgICAgICAgICByb3dLaW5kLFxuICAgICAgICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIGN1cnJlbnRDZWxsXG4gICAgICAgICAgICApXG4gICAgICAgICAgICBsYXN0Q2VsbCA9IFswLCAwLCAwLCAwXVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGNlbGxbMl0gPSBpbmRleFxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHRva2VuLnR5cGUgPT09ICd0YWJsZUNlbGxEaXZpZGVyJykge1xuICAgICAgICBpZiAoaW5GaXJzdENlbGxBd2FpdGluZ1BpcGUpIHtcbiAgICAgICAgICBpbkZpcnN0Q2VsbEF3YWl0aW5nUGlwZSA9IGZhbHNlXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKGxhc3RDZWxsWzFdICE9PSAwKSB7XG4gICAgICAgICAgICBjZWxsWzBdID0gY2VsbFsxXVxuICAgICAgICAgICAgY3VycmVudENlbGwgPSBmbHVzaENlbGwoXG4gICAgICAgICAgICAgIG1hcCxcbiAgICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgICAgbGFzdENlbGwsXG4gICAgICAgICAgICAgIHJvd0tpbmQsXG4gICAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgY3VycmVudENlbGxcbiAgICAgICAgICAgIClcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBsYXN0Q2VsbCA9IGNlbGxcbiAgICAgICAgICBjZWxsID0gW2xhc3RDZWxsWzFdLCBpbmRleCwgMCwgMF1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICAvLyBFeGl0IGV2ZW50cy5cbiAgICBlbHNlIGlmICh0b2tlbi50eXBlID09PSAndGFibGVIZWFkJykge1xuICAgICAgYWZ0ZXJIZWFkQXdhaXRpbmdGaXJzdEJvZHlSb3cgPSB0cnVlXG4gICAgICBsYXN0VGFibGVFbmQgPSBpbmRleFxuICAgIH0gZWxzZSBpZiAoXG4gICAgICB0b2tlbi50eXBlID09PSAndGFibGVSb3cnIHx8XG4gICAgICB0b2tlbi50eXBlID09PSAndGFibGVEZWxpbWl0ZXJSb3cnXG4gICAgKSB7XG4gICAgICBsYXN0VGFibGVFbmQgPSBpbmRleFxuXG4gICAgICBpZiAobGFzdENlbGxbMV0gIT09IDApIHtcbiAgICAgICAgY2VsbFswXSA9IGNlbGxbMV1cbiAgICAgICAgY3VycmVudENlbGwgPSBmbHVzaENlbGwoXG4gICAgICAgICAgbWFwLFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgbGFzdENlbGwsXG4gICAgICAgICAgcm93S2luZCxcbiAgICAgICAgICBpbmRleCxcbiAgICAgICAgICBjdXJyZW50Q2VsbFxuICAgICAgICApXG4gICAgICB9IGVsc2UgaWYgKGNlbGxbMV0gIT09IDApIHtcbiAgICAgICAgY3VycmVudENlbGwgPSBmbHVzaENlbGwobWFwLCBjb250ZXh0LCBjZWxsLCByb3dLaW5kLCBpbmRleCwgY3VycmVudENlbGwpXG4gICAgICB9XG5cbiAgICAgIHJvd0tpbmQgPSAwXG4gICAgfSBlbHNlIGlmIChcbiAgICAgIHJvd0tpbmQgJiZcbiAgICAgICh0b2tlbi50eXBlID09PSB0eXBlcy5kYXRhIHx8XG4gICAgICAgIHRva2VuLnR5cGUgPT09ICd0YWJsZURlbGltaXRlck1hcmtlcicgfHxcbiAgICAgICAgdG9rZW4udHlwZSA9PT0gJ3RhYmxlRGVsaW1pdGVyRmlsbGVyJylcbiAgICApIHtcbiAgICAgIGNlbGxbM10gPSBpbmRleFxuICAgIH1cbiAgfVxuXG4gIGlmIChsYXN0VGFibGVFbmQgIT09IDApIHtcbiAgICBhc3NlcnQoY3VycmVudFRhYmxlLCAnZXhwZWN0ZWQgdGFibGUgb3BlbmluZycpXG4gICAgZmx1c2hUYWJsZUVuZChtYXAsIGNvbnRleHQsIGxhc3RUYWJsZUVuZCwgY3VycmVudFRhYmxlLCBjdXJyZW50Qm9keSlcbiAgfVxuXG4gIG1hcC5jb25zdW1lKGNvbnRleHQuZXZlbnRzKVxuXG4gIC8vIFRvIGRvOiBtb3ZlIHRoaXMgaW50byBgaHRtbGAsIHdoZW4gZXZlbnRzIGFyZSBleHBvc2VkIHRoZXJlLlxuICAvLyBUaGF04oCZcyB3aGF0IGBtYXJrZG93bi1yc2AgZG9lcy5cbiAgLy8gVGhhdCBuZWVkcyB1cGRhdGVzIHRvIGBtZGFzdC11dGlsLWdmbS10YWJsZWAuXG4gIGluZGV4ID0gLTFcbiAgd2hpbGUgKCsraW5kZXggPCBjb250ZXh0LmV2ZW50cy5sZW5ndGgpIHtcbiAgICBjb25zdCBldmVudCA9IGNvbnRleHQuZXZlbnRzW2luZGV4XVxuICAgIGlmIChldmVudFswXSA9PT0gJ2VudGVyJyAmJiBldmVudFsxXS50eXBlID09PSAndGFibGUnKSB7XG4gICAgICBldmVudFsxXS5fYWxpZ24gPSBnZm1UYWJsZUFsaWduKGNvbnRleHQuZXZlbnRzLCBpbmRleClcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZXZlbnRzXG59XG5cbi8qKlxuICogR2VuZXJhdGUgYSBjZWxsLlxuICpcbiAqIEBwYXJhbSB7RWRpdE1hcH0gbWFwXG4gKiBAcGFyYW0ge1JlYWRvbmx5PFRva2VuaXplQ29udGV4dD59IGNvbnRleHRcbiAqIEBwYXJhbSB7UmVhZG9ubHk8UmFuZ2U+fSByYW5nZVxuICogQHBhcmFtIHtSb3dLaW5kfSByb3dLaW5kXG4gKiBAcGFyYW0ge251bWJlciB8IHVuZGVmaW5lZH0gcm93RW5kXG4gKiBAcGFyYW0ge1Rva2VuIHwgdW5kZWZpbmVkfSBwcmV2aW91c0NlbGxcbiAqIEByZXR1cm5zIHtUb2tlbiB8IHVuZGVmaW5lZH1cbiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1wYXJhbXNcbmZ1bmN0aW9uIGZsdXNoQ2VsbChtYXAsIGNvbnRleHQsIHJhbmdlLCByb3dLaW5kLCByb3dFbmQsIHByZXZpb3VzQ2VsbCkge1xuICAvLyBgbWFya2Rvd24tcnNgIHVzZXM6XG4gIC8vIHJvd0tpbmQgPT09IDIgPyAndGFibGVEZWxpbWl0ZXJDZWxsJyA6ICd0YWJsZUNlbGwnXG4gIGNvbnN0IGdyb3VwTmFtZSA9XG4gICAgcm93S2luZCA9PT0gMVxuICAgICAgPyAndGFibGVIZWFkZXInXG4gICAgICA6IHJvd0tpbmQgPT09IDJcbiAgICAgICAgPyAndGFibGVEZWxpbWl0ZXInXG4gICAgICAgIDogJ3RhYmxlRGF0YSdcbiAgLy8gYG1hcmtkb3duLXJzYCB1c2VzOlxuICAvLyByb3dLaW5kID09PSAyID8gJ3RhYmxlRGVsaW1pdGVyQ2VsbFZhbHVlJyA6ICd0YWJsZUNlbGxUZXh0J1xuICBjb25zdCB2YWx1ZU5hbWUgPSAndGFibGVDb250ZW50J1xuXG4gIC8vIEluc2VydCBhbiBleGl0IGZvciB0aGUgcHJldmlvdXMgY2VsbCwgaWYgdGhlcmUgaXMgb25lLlxuICAvL1xuICAvLyBgYGBtYXJrZG93blxuICAvLyA+IHwgfCBhYSB8IGJiIHwgY2MgfFxuICAvLyAgICAgICAgICBeLS0gZXhpdFxuICAvLyAgICAgICAgICAgXl5eXi0tIHRoaXMgY2VsbFxuICAvLyBgYGBcbiAgaWYgKHJhbmdlWzBdICE9PSAwKSB7XG4gICAgYXNzZXJ0KHByZXZpb3VzQ2VsbCwgJ2V4cGVjdGVkIHByZXZpb3VzIGNlbGwgZW50ZXInKVxuICAgIHByZXZpb3VzQ2VsbC5lbmQgPSBPYmplY3QuYXNzaWduKHt9LCBnZXRQb2ludChjb250ZXh0LmV2ZW50cywgcmFuZ2VbMF0pKVxuICAgIG1hcC5hZGQocmFuZ2VbMF0sIDAsIFtbJ2V4aXQnLCBwcmV2aW91c0NlbGwsIGNvbnRleHRdXSlcbiAgfVxuXG4gIC8vIEluc2VydCBlbnRlciBvZiB0aGlzIGNlbGwuXG4gIC8vXG4gIC8vIGBgYG1hcmtkb3duXG4gIC8vID4gfCB8IGFhIHwgYmIgfCBjYyB8XG4gIC8vICAgICAgICAgICBeLS0gZW50ZXJcbiAgLy8gICAgICAgICAgIF5eXl4tLSB0aGlzIGNlbGxcbiAgLy8gYGBgXG4gIGNvbnN0IG5vdyA9IGdldFBvaW50KGNvbnRleHQuZXZlbnRzLCByYW5nZVsxXSlcbiAgcHJldmlvdXNDZWxsID0ge1xuICAgIHR5cGU6IGdyb3VwTmFtZSxcbiAgICBzdGFydDogT2JqZWN0LmFzc2lnbih7fSwgbm93KSxcbiAgICAvLyBOb3RlOiBjb3JyZWN0IGVuZCBpcyBzZXQgbGF0ZXIuXG4gICAgZW5kOiBPYmplY3QuYXNzaWduKHt9LCBub3cpXG4gIH1cbiAgbWFwLmFkZChyYW5nZVsxXSwgMCwgW1snZW50ZXInLCBwcmV2aW91c0NlbGwsIGNvbnRleHRdXSlcblxuICAvLyBJbnNlcnQgdGV4dCBzdGFydCBhdCBmaXJzdCBkYXRhIHN0YXJ0IGFuZCBlbmQgYXQgbGFzdCBkYXRhIGVuZCwgYW5kXG4gIC8vIHJlbW92ZSBldmVudHMgYmV0d2Vlbi5cbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gPiB8IHwgYWEgfCBiYiB8IGNjIHxcbiAgLy8gICAgICAgICAgICBeLS0gZW50ZXJcbiAgLy8gICAgICAgICAgICAgXi0tIGV4aXRcbiAgLy8gICAgICAgICAgIF5eXl4tLSB0aGlzIGNlbGxcbiAgLy8gYGBgXG4gIGlmIChyYW5nZVsyXSAhPT0gMCkge1xuICAgIGNvbnN0IHJlbGF0ZWRTdGFydCA9IGdldFBvaW50KGNvbnRleHQuZXZlbnRzLCByYW5nZVsyXSlcbiAgICBjb25zdCByZWxhdGVkRW5kID0gZ2V0UG9pbnQoY29udGV4dC5ldmVudHMsIHJhbmdlWzNdKVxuICAgIC8qKiBAdHlwZSB7VG9rZW59ICovXG4gICAgY29uc3QgdmFsdWVUb2tlbiA9IHtcbiAgICAgIHR5cGU6IHZhbHVlTmFtZSxcbiAgICAgIHN0YXJ0OiBPYmplY3QuYXNzaWduKHt9LCByZWxhdGVkU3RhcnQpLFxuICAgICAgZW5kOiBPYmplY3QuYXNzaWduKHt9LCByZWxhdGVkRW5kKVxuICAgIH1cbiAgICBtYXAuYWRkKHJhbmdlWzJdLCAwLCBbWydlbnRlcicsIHZhbHVlVG9rZW4sIGNvbnRleHRdXSlcbiAgICBhc3NlcnQocmFuZ2VbM10gIT09IDApXG5cbiAgICBpZiAocm93S2luZCAhPT0gMikge1xuICAgICAgLy8gRml4IHBvc2l0aW9uYWwgaW5mbyBvbiByZW1haW5pbmcgZXZlbnRzXG4gICAgICBjb25zdCBzdGFydCA9IGNvbnRleHQuZXZlbnRzW3JhbmdlWzJdXVxuICAgICAgY29uc3QgZW5kID0gY29udGV4dC5ldmVudHNbcmFuZ2VbM11dXG4gICAgICBzdGFydFsxXS5lbmQgPSBPYmplY3QuYXNzaWduKHt9LCBlbmRbMV0uZW5kKVxuICAgICAgc3RhcnRbMV0udHlwZSA9IHR5cGVzLmNodW5rVGV4dFxuICAgICAgc3RhcnRbMV0uY29udGVudFR5cGUgPSBjb25zdGFudHMuY29udGVudFR5cGVUZXh0XG5cbiAgICAgIC8vIFJlbW92ZSBpZiBuZWVkZWQuXG4gICAgICBpZiAocmFuZ2VbM10gPiByYW5nZVsyXSArIDEpIHtcbiAgICAgICAgY29uc3QgYSA9IHJhbmdlWzJdICsgMVxuICAgICAgICBjb25zdCBiID0gcmFuZ2VbM10gLSByYW5nZVsyXSAtIDFcbiAgICAgICAgbWFwLmFkZChhLCBiLCBbXSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBtYXAuYWRkKHJhbmdlWzNdICsgMSwgMCwgW1snZXhpdCcsIHZhbHVlVG9rZW4sIGNvbnRleHRdXSlcbiAgfVxuXG4gIC8vIEluc2VydCBhbiBleGl0IGZvciB0aGUgbGFzdCBjZWxsLCBpZiBhdCB0aGUgcm93IGVuZC5cbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gPiB8IHwgYWEgfCBiYiB8IGNjIHxcbiAgLy8gICAgICAgICAgICAgICAgICAgIF4tLSBleGl0XG4gIC8vICAgICAgICAgICAgICAgXl5eXl5eLS0gdGhpcyBjZWxsICh0aGUgbGFzdCBvbmUgY29udGFpbnMgdHdvIOKAnGJldHdlZW7igJ0gcGFydHMpXG4gIC8vIGBgYFxuICBpZiAocm93RW5kICE9PSB1bmRlZmluZWQpIHtcbiAgICBwcmV2aW91c0NlbGwuZW5kID0gT2JqZWN0LmFzc2lnbih7fSwgZ2V0UG9pbnQoY29udGV4dC5ldmVudHMsIHJvd0VuZCkpXG4gICAgbWFwLmFkZChyb3dFbmQsIDAsIFtbJ2V4aXQnLCBwcmV2aW91c0NlbGwsIGNvbnRleHRdXSlcbiAgICBwcmV2aW91c0NlbGwgPSB1bmRlZmluZWRcbiAgfVxuXG4gIHJldHVybiBwcmV2aW91c0NlbGxcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZSB0YWJsZSBlbmQgKGFuZCB0YWJsZSBib2R5IGVuZCkuXG4gKlxuICogQHBhcmFtIHtSZWFkb25seTxFZGl0TWFwPn0gbWFwXG4gKiBAcGFyYW0ge1JlYWRvbmx5PFRva2VuaXplQ29udGV4dD59IGNvbnRleHRcbiAqIEBwYXJhbSB7bnVtYmVyfSBpbmRleFxuICogQHBhcmFtIHtUb2tlbn0gdGFibGVcbiAqIEBwYXJhbSB7VG9rZW4gfCB1bmRlZmluZWR9IHRhYmxlQm9keVxuICovXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LXBhcmFtc1xuZnVuY3Rpb24gZmx1c2hUYWJsZUVuZChtYXAsIGNvbnRleHQsIGluZGV4LCB0YWJsZSwgdGFibGVCb2R5KSB7XG4gIC8qKiBAdHlwZSB7QXJyYXk8RXZlbnQ+fSAqL1xuICBjb25zdCBleGl0cyA9IFtdXG4gIGNvbnN0IHJlbGF0ZWQgPSBnZXRQb2ludChjb250ZXh0LmV2ZW50cywgaW5kZXgpXG5cbiAgaWYgKHRhYmxlQm9keSkge1xuICAgIHRhYmxlQm9keS5lbmQgPSBPYmplY3QuYXNzaWduKHt9LCByZWxhdGVkKVxuICAgIGV4aXRzLnB1c2goWydleGl0JywgdGFibGVCb2R5LCBjb250ZXh0XSlcbiAgfVxuXG4gIHRhYmxlLmVuZCA9IE9iamVjdC5hc3NpZ24oe30sIHJlbGF0ZWQpXG4gIGV4aXRzLnB1c2goWydleGl0JywgdGFibGUsIGNvbnRleHRdKVxuXG4gIG1hcC5hZGQoaW5kZXggKyAxLCAwLCBleGl0cylcbn1cblxuLyoqXG4gKiBAcGFyYW0ge1JlYWRvbmx5PEFycmF5PEV2ZW50Pj59IGV2ZW50c1xuICogQHBhcmFtIHtudW1iZXJ9IGluZGV4XG4gKiBAcmV0dXJucyB7UmVhZG9ubHk8UG9pbnQ+fVxuICovXG5mdW5jdGlvbiBnZXRQb2ludChldmVudHMsIGluZGV4KSB7XG4gIGNvbnN0IGV2ZW50ID0gZXZlbnRzW2luZGV4XVxuICBjb25zdCBzaWRlID0gZXZlbnRbMF0gPT09ICdlbnRlcicgPyAnc3RhcnQnIDogJ2VuZCdcbiAgcmV0dXJuIGV2ZW50WzFdW3NpZGVdXG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0V4dGVuc2lvbiwgU3RhdGUsIFRva2VuaXplQ29udGV4dCwgVG9rZW5pemVyfSBmcm9tICdtaWNyb21hcmstdXRpbC10eXBlcydcbiAqL1xuXG5pbXBvcnQge29rIGFzIGFzc2VydH0gZnJvbSAnZGV2bG9wJ1xuaW1wb3J0IHtmYWN0b3J5U3BhY2V9IGZyb20gJ21pY3JvbWFyay1mYWN0b3J5LXNwYWNlJ1xuaW1wb3J0IHtcbiAgbWFya2Rvd25MaW5lRW5kaW5nLFxuICBtYXJrZG93bkxpbmVFbmRpbmdPclNwYWNlLFxuICBtYXJrZG93blNwYWNlXG59IGZyb20gJ21pY3JvbWFyay11dGlsLWNoYXJhY3RlcidcbmltcG9ydCB7Y29kZXMsIHR5cGVzfSBmcm9tICdtaWNyb21hcmstdXRpbC1zeW1ib2wnXG5cbmNvbnN0IHRhc2tsaXN0Q2hlY2sgPSB7bmFtZTogJ3Rhc2tsaXN0Q2hlY2snLCB0b2tlbml6ZTogdG9rZW5pemVUYXNrbGlzdENoZWNrfVxuXG4vKipcbiAqIENyZWF0ZSBhbiBIVE1MIGV4dGVuc2lvbiBmb3IgYG1pY3JvbWFya2AgdG8gc3VwcG9ydCBHRk0gdGFzayBsaXN0IGl0ZW1zXG4gKiBzeW50YXguXG4gKlxuICogQHJldHVybnMge0V4dGVuc2lvbn1cbiAqICAgRXh0ZW5zaW9uIGZvciBgbWljcm9tYXJrYCB0aGF0IGNhbiBiZSBwYXNzZWQgaW4gYGh0bWxFeHRlbnNpb25zYCB0b1xuICogICBzdXBwb3J0IEdGTSB0YXNrIGxpc3QgaXRlbXMgd2hlbiBzZXJpYWxpemluZyB0byBIVE1MLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2ZtVGFza0xpc3RJdGVtKCkge1xuICByZXR1cm4ge1xuICAgIHRleHQ6IHtbY29kZXMubGVmdFNxdWFyZUJyYWNrZXRdOiB0YXNrbGlzdENoZWNrfVxuICB9XG59XG5cbi8qKlxuICogQHRoaXMge1Rva2VuaXplQ29udGV4dH1cbiAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gKi9cbmZ1bmN0aW9uIHRva2VuaXplVGFza2xpc3RDaGVjayhlZmZlY3RzLCBvaywgbm9rKSB7XG4gIGNvbnN0IHNlbGYgPSB0aGlzXG5cbiAgcmV0dXJuIG9wZW5cblxuICAvKipcbiAgICogQXQgc3RhcnQgb2YgdGFzayBsaXN0IGl0ZW0gY2hlY2suXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCAqIFt4XSB5LlxuICAgKiAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBvcGVuKGNvZGUpIHtcbiAgICBhc3NlcnQoY29kZSA9PT0gY29kZXMubGVmdFNxdWFyZUJyYWNrZXQsICdleHBlY3RlZCBgW2AnKVxuXG4gICAgaWYgKFxuICAgICAgLy8gRXhpdCBpZiB0aGVyZeKAmXMgc3R1ZmYgYmVmb3JlLlxuICAgICAgc2VsZi5wcmV2aW91cyAhPT0gY29kZXMuZW9mIHx8XG4gICAgICAvLyBFeGl0IGlmIG5vdCBpbiB0aGUgZmlyc3QgY29udGVudCB0aGF0IGlzIHRoZSBmaXJzdCBjaGlsZCBvZiBhIGxpc3RcbiAgICAgIC8vIGl0ZW0uXG4gICAgICAhc2VsZi5fZ2ZtVGFza2xpc3RGaXJzdENvbnRlbnRPZkxpc3RJdGVtXG4gICAgKSB7XG4gICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgfVxuXG4gICAgZWZmZWN0cy5lbnRlcigndGFza0xpc3RDaGVjaycpXG4gICAgZWZmZWN0cy5lbnRlcigndGFza0xpc3RDaGVja01hcmtlcicpXG4gICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgZWZmZWN0cy5leGl0KCd0YXNrTGlzdENoZWNrTWFya2VyJylcbiAgICByZXR1cm4gaW5zaWRlXG4gIH1cblxuICAvKipcbiAgICogSW4gdGFzayBsaXN0IGl0ZW0gY2hlY2suXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCAqIFt4XSB5LlxuICAgKiAgICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gaW5zaWRlKGNvZGUpIHtcbiAgICAvLyBDdXJyZW50bHkgd2UgbWF0Y2ggaG93IEdIIHdvcmtzIGluIGZpbGVzLlxuICAgIC8vIFRvIG1hdGNoIGhvdyBHSCB3b3JrcyBpbiBjb21tZW50cywgdXNlIGBtYXJrZG93blNwYWNlYCAoYFtcXHQgXWApIGluc3RlYWRcbiAgICAvLyBvZiBgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZWAgKGBbXFx0XFxuXFxyIF1gKS5cbiAgICBpZiAobWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZShjb2RlKSkge1xuICAgICAgZWZmZWN0cy5lbnRlcigndGFza0xpc3RDaGVja1ZhbHVlVW5jaGVja2VkJylcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgZWZmZWN0cy5leGl0KCd0YXNrTGlzdENoZWNrVmFsdWVVbmNoZWNrZWQnKVxuICAgICAgcmV0dXJuIGNsb3NlXG4gICAgfVxuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLnVwcGVyY2FzZVggfHwgY29kZSA9PT0gY29kZXMubG93ZXJjYXNlWCkge1xuICAgICAgZWZmZWN0cy5lbnRlcigndGFza0xpc3RDaGVja1ZhbHVlQ2hlY2tlZCcpXG4gICAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICAgIGVmZmVjdHMuZXhpdCgndGFza0xpc3RDaGVja1ZhbHVlQ2hlY2tlZCcpXG4gICAgICByZXR1cm4gY2xvc2VcbiAgICB9XG5cbiAgICByZXR1cm4gbm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQXQgY2xvc2Ugb2YgdGFzayBsaXN0IGl0ZW0gY2hlY2suXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCAqIFt4XSB5LlxuICAgKiAgICAgICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGNsb3NlKGNvZGUpIHtcbiAgICBpZiAoY29kZSA9PT0gY29kZXMucmlnaHRTcXVhcmVCcmFja2V0KSB7XG4gICAgICBlZmZlY3RzLmVudGVyKCd0YXNrTGlzdENoZWNrTWFya2VyJylcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgZWZmZWN0cy5leGl0KCd0YXNrTGlzdENoZWNrTWFya2VyJylcbiAgICAgIGVmZmVjdHMuZXhpdCgndGFza0xpc3RDaGVjaycpXG4gICAgICByZXR1cm4gYWZ0ZXJcbiAgICB9XG5cbiAgICByZXR1cm4gbm9rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gYWZ0ZXIoY29kZSkge1xuICAgIC8vIEVPTCBpbiBwYXJhZ3JhcGggbWVhbnMgdGhlcmUgbXVzdCBiZSBzb21ldGhpbmcgZWxzZSBhZnRlciBpdC5cbiAgICBpZiAobWFya2Rvd25MaW5lRW5kaW5nKGNvZGUpKSB7XG4gICAgICByZXR1cm4gb2soY29kZSlcbiAgICB9XG5cbiAgICAvLyBTcGFjZSBvciB0YWI/XG4gICAgLy8gQ2hlY2sgd2hhdCBjb21lcyBhZnRlci5cbiAgICBpZiAobWFya2Rvd25TcGFjZShjb2RlKSkge1xuICAgICAgcmV0dXJuIGVmZmVjdHMuY2hlY2soe3Rva2VuaXplOiBzcGFjZVRoZW5Ob25TcGFjZX0sIG9rLCBub2spKGNvZGUpXG4gICAgfVxuXG4gICAgLy8gRU9GLCBvciBub24td2hpdGVzcGFjZSwgYm90aCB3cm9uZy5cbiAgICByZXR1cm4gbm9rKGNvZGUpXG4gIH1cbn1cblxuLyoqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1Rva2VuaXplcn1cbiAqL1xuZnVuY3Rpb24gc3BhY2VUaGVuTm9uU3BhY2UoZWZmZWN0cywgb2ssIG5vaykge1xuICByZXR1cm4gZmFjdG9yeVNwYWNlKGVmZmVjdHMsIGFmdGVyLCB0eXBlcy53aGl0ZXNwYWNlKVxuXG4gIC8qKlxuICAgKiBBZnRlciB3aGl0ZXNwYWNlLCBhZnRlciB0YXNrIGxpc3QgaXRlbSBjaGVjay5cbiAgICpcbiAgICogYGBgbWFya2Rvd25cbiAgICogPiB8ICogW3hdIHkuXG4gICAqICAgICAgICAgICBeXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBhZnRlcihjb2RlKSB7XG4gICAgLy8gRU9GIG1lYW5zIHRoZXJlIHdhcyBub3RoaW5nLCBzbyBiYWQuXG4gICAgLy8gRU9MIG1lYW5zIHRoZXJl4oCZcyBjb250ZW50IGFmdGVyIGl0LCBzbyBnb29kLlxuICAgIC8vIEltcG9zc2libGUgdG8gaGF2ZSBtb3JlIHNwYWNlcy5cbiAgICAvLyBBbnl0aGluZyBlbHNlIGlzIGdvb2QuXG4gICAgcmV0dXJuIGNvZGUgPT09IGNvZGVzLmVvZiA/IG5vayhjb2RlKSA6IG9rKGNvZGUpXG4gIH1cbn1cbiIsIi8qKlxuICogQHR5cGVkZWYge2ltcG9ydCgnbWljcm9tYXJrLWV4dGVuc2lvbi1nZm0tZm9vdG5vdGUnKS5IdG1sT3B0aW9uc30gSHRtbE9wdGlvbnNcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21pY3JvbWFyay1leHRlbnNpb24tZ2ZtLXN0cmlrZXRocm91Z2gnKS5PcHRpb25zfSBPcHRpb25zXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtaWNyb21hcmstdXRpbC10eXBlcycpLkV4dGVuc2lvbn0gRXh0ZW5zaW9uXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtaWNyb21hcmstdXRpbC10eXBlcycpLkh0bWxFeHRlbnNpb259IEh0bWxFeHRlbnNpb25cbiAqL1xuXG5pbXBvcnQge1xuICBjb21iaW5lRXh0ZW5zaW9ucyxcbiAgY29tYmluZUh0bWxFeHRlbnNpb25zXG59IGZyb20gJ21pY3JvbWFyay11dGlsLWNvbWJpbmUtZXh0ZW5zaW9ucydcbmltcG9ydCB7XG4gIGdmbUF1dG9saW5rTGl0ZXJhbCxcbiAgZ2ZtQXV0b2xpbmtMaXRlcmFsSHRtbFxufSBmcm9tICdtaWNyb21hcmstZXh0ZW5zaW9uLWdmbS1hdXRvbGluay1saXRlcmFsJ1xuaW1wb3J0IHtnZm1Gb290bm90ZSwgZ2ZtRm9vdG5vdGVIdG1sfSBmcm9tICdtaWNyb21hcmstZXh0ZW5zaW9uLWdmbS1mb290bm90ZSdcbmltcG9ydCB7XG4gIGdmbVN0cmlrZXRocm91Z2gsXG4gIGdmbVN0cmlrZXRocm91Z2hIdG1sXG59IGZyb20gJ21pY3JvbWFyay1leHRlbnNpb24tZ2ZtLXN0cmlrZXRocm91Z2gnXG5pbXBvcnQge2dmbVRhYmxlLCBnZm1UYWJsZUh0bWx9IGZyb20gJ21pY3JvbWFyay1leHRlbnNpb24tZ2ZtLXRhYmxlJ1xuaW1wb3J0IHtnZm1UYWdmaWx0ZXJIdG1sfSBmcm9tICdtaWNyb21hcmstZXh0ZW5zaW9uLWdmbS10YWdmaWx0ZXInXG5pbXBvcnQge1xuICBnZm1UYXNrTGlzdEl0ZW0sXG4gIGdmbVRhc2tMaXN0SXRlbUh0bWxcbn0gZnJvbSAnbWljcm9tYXJrLWV4dGVuc2lvbi1nZm0tdGFzay1saXN0LWl0ZW0nXG5cbi8qKlxuICogQ3JlYXRlIGFuIGV4dGVuc2lvbiBmb3IgYG1pY3JvbWFya2AgdG8gZW5hYmxlIEdGTSBzeW50YXguXG4gKlxuICogQHBhcmFtIHtPcHRpb25zIHwgbnVsbCB8IHVuZGVmaW5lZH0gW29wdGlvbnNdXG4gKiAgIENvbmZpZ3VyYXRpb24gKG9wdGlvbmFsKS5cbiAqXG4gKiAgIFBhc3NlZCB0byBgbWljcm9tYXJrLWV4dGVucy1nZm0tc3RyaWtldGhyb3VnaGAuXG4gKiBAcmV0dXJucyB7RXh0ZW5zaW9ufVxuICogICBFeHRlbnNpb24gZm9yIGBtaWNyb21hcmtgIHRoYXQgY2FuIGJlIHBhc3NlZCBpbiBgZXh0ZW5zaW9uc2AgdG8gZW5hYmxlIEdGTVxuICogICBzeW50YXguXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZm0ob3B0aW9ucykge1xuICByZXR1cm4gY29tYmluZUV4dGVuc2lvbnMoW1xuICAgIGdmbUF1dG9saW5rTGl0ZXJhbCgpLFxuICAgIGdmbUZvb3Rub3RlKCksXG4gICAgZ2ZtU3RyaWtldGhyb3VnaChvcHRpb25zKSxcbiAgICBnZm1UYWJsZSgpLFxuICAgIGdmbVRhc2tMaXN0SXRlbSgpXG4gIF0pXG59XG5cbi8qKlxuICogQ3JlYXRlIGFuIGV4dGVuc2lvbiBmb3IgYG1pY3JvbWFya2AgdG8gc3VwcG9ydCBHRk0gd2hlbiBzZXJpYWxpemluZyB0byBIVE1MLlxuICpcbiAqIEBwYXJhbSB7SHRtbE9wdGlvbnMgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0aW9uc11cbiAqICAgQ29uZmlndXJhdGlvbiAob3B0aW9uYWwpLlxuICpcbiAqICAgUGFzc2VkIHRvIGBtaWNyb21hcmstZXh0ZW5zLWdmbS1mb290bm90ZWAuXG4gKiBAcmV0dXJucyB7SHRtbEV4dGVuc2lvbn1cbiAqICAgRXh0ZW5zaW9uIGZvciBgbWljcm9tYXJrYCB0aGF0IGNhbiBiZSBwYXNzZWQgaW4gYGh0bWxFeHRlbnNpb25zYCB0b1xuICogICBzdXBwb3J0IEdGTSB3aGVuIHNlcmlhbGl6aW5nIHRvIEhUTUwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZm1IdG1sKG9wdGlvbnMpIHtcbiAgcmV0dXJuIGNvbWJpbmVIdG1sRXh0ZW5zaW9ucyhbXG4gICAgZ2ZtQXV0b2xpbmtMaXRlcmFsSHRtbCgpLFxuICAgIGdmbUZvb3Rub3RlSHRtbChvcHRpb25zKSxcbiAgICBnZm1TdHJpa2V0aHJvdWdoSHRtbCgpLFxuICAgIGdmbVRhYmxlSHRtbCgpLFxuICAgIGdmbVRhZ2ZpbHRlckh0bWwoKSxcbiAgICBnZm1UYXNrTGlzdEl0ZW1IdG1sKClcbiAgXSlcbn1cbiIsIi8qKlxuICogQGltcG9ydCB7Um9vdH0gZnJvbSAnbWRhc3QnXG4gKiBAaW1wb3J0IHtPcHRpb25zfSBmcm9tICdyZW1hcmstZ2ZtJ1xuICogQGltcG9ydCB7fSBmcm9tICdyZW1hcmstcGFyc2UnXG4gKiBAaW1wb3J0IHt9IGZyb20gJ3JlbWFyay1zdHJpbmdpZnknXG4gKiBAaW1wb3J0IHtQcm9jZXNzb3J9IGZyb20gJ3VuaWZpZWQnXG4gKi9cblxuaW1wb3J0IHtnZm1Gcm9tTWFya2Rvd24sIGdmbVRvTWFya2Rvd259IGZyb20gJ21kYXN0LXV0aWwtZ2ZtJ1xuaW1wb3J0IHtnZm19IGZyb20gJ21pY3JvbWFyay1leHRlbnNpb24tZ2ZtJ1xuXG4vKiogQHR5cGUge09wdGlvbnN9ICovXG5jb25zdCBlbXB0eU9wdGlvbnMgPSB7fVxuXG4vKipcbiAqIEFkZCBzdXBwb3J0IEdGTSAoYXV0b2xpbmsgbGl0ZXJhbHMsIGZvb3Rub3Rlcywgc3RyaWtldGhyb3VnaCwgdGFibGVzLFxuICogdGFza2xpc3RzKS5cbiAqXG4gKiBAcGFyYW0ge09wdGlvbnMgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0aW9uc11cbiAqICAgQ29uZmlndXJhdGlvbiAob3B0aW9uYWwpLlxuICogQHJldHVybnMge3VuZGVmaW5lZH1cbiAqICAgTm90aGluZy5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gcmVtYXJrR2ZtKG9wdGlvbnMpIHtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvcjogVFMgaXMgd3JvbmcgYWJvdXQgYHRoaXNgLlxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgdW5pY29ybi9uby10aGlzLWFzc2lnbm1lbnRcbiAgY29uc3Qgc2VsZiA9IC8qKiBAdHlwZSB7UHJvY2Vzc29yPFJvb3Q+fSAqLyAodGhpcylcbiAgY29uc3Qgc2V0dGluZ3MgPSBvcHRpb25zIHx8IGVtcHR5T3B0aW9uc1xuICBjb25zdCBkYXRhID0gc2VsZi5kYXRhKClcblxuICBjb25zdCBtaWNyb21hcmtFeHRlbnNpb25zID1cbiAgICBkYXRhLm1pY3JvbWFya0V4dGVuc2lvbnMgfHwgKGRhdGEubWljcm9tYXJrRXh0ZW5zaW9ucyA9IFtdKVxuICBjb25zdCBmcm9tTWFya2Rvd25FeHRlbnNpb25zID1cbiAgICBkYXRhLmZyb21NYXJrZG93bkV4dGVuc2lvbnMgfHwgKGRhdGEuZnJvbU1hcmtkb3duRXh0ZW5zaW9ucyA9IFtdKVxuICBjb25zdCB0b01hcmtkb3duRXh0ZW5zaW9ucyA9XG4gICAgZGF0YS50b01hcmtkb3duRXh0ZW5zaW9ucyB8fCAoZGF0YS50b01hcmtkb3duRXh0ZW5zaW9ucyA9IFtdKVxuXG4gIG1pY3JvbWFya0V4dGVuc2lvbnMucHVzaChnZm0oc2V0dGluZ3MpKVxuICBmcm9tTWFya2Rvd25FeHRlbnNpb25zLnB1c2goZ2ZtRnJvbU1hcmtkb3duKCkpXG4gIHRvTWFya2Rvd25FeHRlbnNpb25zLnB1c2goZ2ZtVG9NYXJrZG93bihzZXR0aW5ncykpXG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQVVBLFNBQWdCLE9BQU8sT0FBTyxXQUFXO0NBQ3ZDLE1BQU0sU0FBUyxPQUFPLEtBQUs7Q0FFM0IsSUFBSSxPQUFPLGNBQWMsVUFDdkIsTUFBTSxJQUFJLFVBQVUsb0JBQW9CO0NBRzFDLElBQUksUUFBUTtDQUNaLElBQUksUUFBUSxPQUFPLFFBQVEsU0FBUztDQUVwQyxPQUFPLFVBQVUsSUFBSTtFQUNuQjtFQUNBLFFBQVEsT0FBTyxRQUFRLFdBQVcsUUFBUSxVQUFVLE1BQU07Q0FDNUQ7Q0FFQSxPQUFPO0FBQ1Q7OztBQzFCQSxTQUF3QixtQkFBbUIsUUFBUTtDQUNsRCxJQUFJLE9BQU8sV0FBVyxVQUNyQixNQUFNLElBQUksVUFBVSxtQkFBbUI7Q0FLeEMsT0FBTyxPQUNMLFFBQVEsdUJBQXVCLE1BQU0sQ0FBQyxDQUN0QyxRQUFRLE1BQU0sT0FBTztBQUN4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNtRUEsU0FBZ0IsZUFBZSxNQUFNLE1BQU0sU0FBUztDQUVsRCxNQUFNLFVBQVUsU0FEQyxXQUFXLENBQUMsRUFBQSxDQUNJLFVBQVUsQ0FBQyxDQUFDO0NBQzdDLE1BQU0sUUFBUSxRQUFRLElBQUk7Q0FDMUIsSUFBSSxZQUFZO0NBRWhCLE9BQU8sRUFBRSxZQUFZLE1BQU0sUUFDekIsYUFBYSxNQUFNLFFBQVEsT0FBTzs7Q0FJcEMsU0FBUyxRQUFRLE1BQU0sU0FBUztFQUM5QixJQUFJLFFBQVE7O0VBRVosSUFBSTtFQUVKLE9BQU8sRUFBRSxRQUFRLFFBQVEsUUFBUTtHQUMvQixNQUFNLFNBQVMsUUFBUTs7R0FFdkIsTUFBTSxXQUFXLGNBQWMsWUFBWSxXQUFXLEtBQUE7R0FFdEQsSUFDRSxRQUNFLFFBQ0EsV0FBVyxTQUFTLFFBQVEsTUFBTSxJQUFJLEtBQUEsR0FDdEMsV0FDRixHQUVBO0dBR0YsY0FBYztFQUNoQjtFQUVBLElBQUksYUFDRixPQUFPLFFBQVEsTUFBTSxPQUFPO0NBRWhDOzs7Ozs7Ozs7OztDQVlBLFNBQVMsUUFBUSxNQUFNLFNBQVM7RUFDOUIsTUFBTSxTQUFTLFFBQVEsUUFBUSxTQUFTO0VBQ3hDLE1BQU0sT0FBTyxNQUFNLFVBQVUsQ0FBQztFQUM5QixNQUFNLFVBQVUsTUFBTSxVQUFVLENBQUM7RUFDakMsSUFBSSxRQUFRO0VBR1osTUFBTSxRQURXLE9BQU8sU0FDRCxRQUFRLElBQUk7RUFDbkMsSUFBSSxTQUFTOztFQUViLElBQUksUUFBUSxDQUFDO0VBRWIsS0FBSyxZQUFZO0VBRWpCLElBQUksUUFBUSxLQUFLLEtBQUssS0FBSyxLQUFLO0VBRWhDLE9BQU8sT0FBTztHQUNaLE1BQU0sV0FBVyxNQUFNOztHQUV2QixNQUFNLGNBQWM7SUFDbEIsT0FBTyxNQUFNO0lBQ2IsT0FBTyxNQUFNO0lBQ2IsT0FBTyxDQUFDLEdBQUcsU0FBUyxJQUFJO0dBQzFCO0dBQ0EsSUFBSSxRQUFRLFFBQVEsR0FBRyxPQUFPLFdBQVc7R0FFekMsSUFBSSxPQUFPLFVBQVUsVUFDbkIsUUFBUSxNQUFNLFNBQVMsSUFBSTtJQUFDLE1BQU07SUFBUTtHQUFLLElBQUksS0FBQTtHQUlyRCxJQUFJLFVBQVUsT0FJWixLQUFLLFlBQVksV0FBVztRQUN2QjtJQUNMLElBQUksVUFBVSxVQUNaLE1BQU0sS0FBSztLQUNULE1BQU07S0FDTixPQUFPLEtBQUssTUFBTSxNQUFNLE9BQU8sUUFBUTtJQUN6QyxDQUFDO0lBR0gsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUNyQixNQUFNLEtBQUssR0FBRyxLQUFLO1NBQ2QsSUFBSSxPQUNULE1BQU0sS0FBSyxLQUFLO0lBR2xCLFFBQVEsV0FBVyxNQUFNLEVBQUUsQ0FBQztJQUM1QixTQUFTO0dBQ1g7R0FFQSxJQUFJLENBQUMsS0FBSyxRQUNSO0dBR0YsUUFBUSxLQUFLLEtBQUssS0FBSyxLQUFLO0VBQzlCO0VBRUEsSUFBSSxRQUFRO0dBQ1YsSUFBSSxRQUFRLEtBQUssTUFBTSxRQUNyQixNQUFNLEtBQUs7SUFBQyxNQUFNO0lBQVEsT0FBTyxLQUFLLE1BQU0sTUFBTSxLQUFLO0dBQUMsQ0FBQztHQUczRCxPQUFPLFNBQVMsT0FBTyxPQUFPLEdBQUcsR0FBRyxLQUFLO0VBQzNDLE9BQ0UsUUFBUSxDQUFDLElBQUk7RUFHZixPQUFPLFFBQVEsTUFBTTtDQUN2QjtBQUNGOzs7Ozs7Ozs7QUFVQSxTQUFTLFFBQVEsYUFBYTs7Q0FFNUIsTUFBTSxTQUFTLENBQUM7Q0FFaEIsSUFBSSxDQUFDLE1BQU0sUUFBUSxXQUFXLEdBQzVCLE1BQU0sSUFBSSxVQUFVLG1EQUFtRDs7Q0FLekUsTUFBTSxPQUNKLENBQUMsWUFBWSxNQUFNLE1BQU0sUUFBUSxZQUFZLEVBQUUsSUFDM0MsY0FDQSxDQUFDLFdBQVc7Q0FFbEIsSUFBSSxRQUFRO0NBRVosT0FBTyxFQUFFLFFBQVEsS0FBSyxRQUFRO0VBQzVCLE1BQU0sUUFBUSxLQUFLO0VBQ25CLE9BQU8sS0FBSyxDQUFDLGFBQWEsTUFBTSxFQUFFLEdBQUcsV0FBVyxNQUFNLEVBQUUsQ0FBQyxDQUFDO0NBQzVEO0NBRUEsT0FBTztBQUNUOzs7Ozs7Ozs7QUFVQSxTQUFTLGFBQWEsTUFBTTtDQUMxQixPQUFPLE9BQU8sU0FBUyxXQUFXLElBQUksT0FBT0EsbUJBQU8sSUFBSSxHQUFHLEdBQUcsSUFBSTtBQUNwRTs7Ozs7Ozs7O0FBVUEsU0FBUyxXQUFXLFNBQVM7Q0FDM0IsT0FBTyxPQUFPLFlBQVksYUFDdEIsVUFDQSxXQUFZO0VBQ1YsT0FBTztDQUNUO0FBQ047Ozs7Ozs7Ozs7QUN2UEEsSUFBTSxjQUFjOztBQUVwQixJQUFNLGlCQUFpQjtDQUFDO0NBQVk7Q0FBUTtDQUFTO0FBQU87Ozs7Ozs7O0FBUzVELFNBQWdCLGlDQUFpQztDQUMvQyxPQUFPO0VBQ0wsWUFBWSxDQUFDLDRCQUE0QjtFQUN6QyxPQUFPO0dBQ0wsaUJBQWlCO0dBQ2pCLHNCQUFzQjtHQUN0QixxQkFBcUI7R0FDckIsb0JBQW9CO0VBQ3RCO0VBQ0EsTUFBTTtHQUNKLGlCQUFpQjtHQUNqQixzQkFBc0I7R0FDdEIscUJBQXFCO0dBQ3JCLG9CQUFvQjtFQUN0QjtDQUNGO0FBQ0Y7Ozs7Ozs7O0FBU0EsU0FBZ0IsK0JBQStCO0NBQzdDLE9BQU8sRUFDTCxRQUFRO0VBQ047R0FDRSxXQUFXO0dBQ1gsUUFBUTtHQUNSLE9BQU87R0FDUDtHQUNBO0VBQ0Y7RUFDQTtHQUNFLFdBQVc7R0FDWCxRQUFRO0dBQ1IsT0FBTztHQUNQO0dBQ0E7RUFDRjtFQUNBO0dBQ0UsV0FBVztHQUNYLFFBQVE7R0FDUixPQUFPO0dBQ1A7R0FDQTtFQUNGO0NBQ0YsRUFDRjtBQUNGOzs7OztBQU1BLFNBQVMscUJBQXFCLE9BQU87Q0FDbkMsS0FBSyxNQUFNO0VBQUMsTUFBTTtFQUFRLE9BQU87RUFBTSxLQUFLO0VBQUksVUFBVSxDQUFDO0NBQUMsR0FBRyxLQUFLO0FBQ3RFOzs7OztBQU1BLFNBQVMsMEJBQTBCLE9BQU87Q0FDeEMsS0FBSyxPQUFPLE1BQU0saUJBQWlCLEtBQUssTUFBTSxLQUFLO0FBQ3JEOzs7OztBQU1BLFNBQVMsd0JBQXdCLE9BQU87Q0FDdEMsS0FBSyxPQUFPLEtBQUssaUJBQWlCLEtBQUssTUFBTSxLQUFLO0FBQ3BEOzs7OztBQU1BLFNBQVMsdUJBQXVCLE9BQU87Q0FDckMsS0FBSyxPQUFPLEtBQUssS0FBSyxLQUFLLE1BQU0sS0FBSztDQUN0QyxNQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxTQUFTO0NBQzVDLEdBQU8sS0FBSyxTQUFTLE1BQU07Q0FDM0IsS0FBSyxNQUFNLFlBQVksS0FBSyxlQUFlLEtBQUs7QUFDbEQ7Ozs7O0FBTUEsU0FBUyx5QkFBeUIsT0FBTztDQUN2QyxLQUFLLE9BQU8sS0FBSyxjQUFjLEtBQUssTUFBTSxLQUFLO0FBQ2pEOzs7OztBQU1BLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsS0FBSyxLQUFLLEtBQUs7QUFDakI7O0FBR0EsU0FBUyw2QkFBNkIsTUFBTTtDQUMxQyxlQUNFLE1BQ0EsQ0FDRSxDQUFDLG1EQUFtRCxPQUFPLEdBQzNELENBQUMsMkRBQTJELFNBQVMsQ0FDdkUsR0FDQSxFQUFDLFFBQVEsQ0FBQyxRQUFRLGVBQWUsRUFBQyxDQUNwQztBQUNGOzs7Ozs7Ozs7O0FBWUEsU0FBUyxRQUFRLEdBQUcsVUFBVSxRQUFRLE1BQU0sT0FBTztDQUNqRCxJQUFJLFNBQVM7Q0FHYixJQUFJLENBQUMsU0FBUyxLQUFLLEdBQ2pCLE9BQU87Q0FJVCxJQUFJLE1BQU0sS0FBSyxRQUFRLEdBQUc7RUFDeEIsU0FBUyxXQUFXO0VBQ3BCLFdBQVc7RUFDWCxTQUFTO0NBQ1g7Q0FFQSxJQUFJLENBQUMsZ0JBQWdCLE1BQU0sR0FDekIsT0FBTztDQUdULE1BQU0sUUFBUSxTQUFTLFNBQVMsSUFBSTtDQUVwQyxJQUFJLENBQUMsTUFBTSxJQUFJLE9BQU87O0NBR3RCLE1BQU0sU0FBUztFQUNiLE1BQU07RUFDTixPQUFPO0VBQ1AsS0FBSyxTQUFTLFdBQVcsTUFBTTtFQUMvQixVQUFVLENBQUM7R0FBQyxNQUFNO0dBQVEsT0FBTyxXQUFXLE1BQU07RUFBRSxDQUFDO0NBQ3ZEO0NBRUEsSUFBSSxNQUFNLElBQ1IsT0FBTyxDQUFDLFFBQVE7RUFBQyxNQUFNO0VBQVEsT0FBTyxNQUFNO0NBQUUsQ0FBQztDQUdqRCxPQUFPO0FBQ1Q7Ozs7Ozs7OztBQVVBLFNBQVMsVUFBVSxHQUFHLE9BQU8sT0FBTyxPQUFPO0NBQ3pDLElBRUUsQ0FBQyxTQUFTLE9BQU8sSUFBSSxLQUVyQixVQUFVLEtBQUssS0FBSyxHQUVwQixPQUFPO0NBR1QsT0FBTztFQUNMLE1BQU07RUFDTixPQUFPO0VBQ1AsS0FBSyxZQUFZLFFBQVEsTUFBTTtFQUMvQixVQUFVLENBQUM7R0FBQyxNQUFNO0dBQVEsT0FBTyxRQUFRLE1BQU07RUFBSyxDQUFDO0NBQ3ZEO0FBQ0Y7Ozs7O0FBTUEsU0FBUyxnQkFBZ0IsUUFBUTtDQUMvQixNQUFNLFFBQVEsT0FBTyxNQUFNLEdBQUc7Q0FFOUIsSUFDRSxNQUFNLFNBQVMsS0FDZCxNQUFNLE1BQU0sU0FBUyxPQUNuQixJQUFJLEtBQUssTUFBTSxNQUFNLFNBQVMsRUFBRSxLQUMvQixDQUFDLGFBQWEsS0FBSyxNQUFNLE1BQU0sU0FBUyxFQUFFLE1BQzdDLE1BQU0sTUFBTSxTQUFTLE9BQ25CLElBQUksS0FBSyxNQUFNLE1BQU0sU0FBUyxFQUFFLEtBQy9CLENBQUMsYUFBYSxLQUFLLE1BQU0sTUFBTSxTQUFTLEVBQUUsSUFFOUMsT0FBTztDQUdULE9BQU87QUFDVDs7Ozs7QUFNQSxTQUFTLFNBQVMsS0FBSztDQUNyQixNQUFNLFlBQVksc0JBQXNCLEtBQUssR0FBRztDQUVoRCxJQUFJLENBQUMsV0FDSCxPQUFPLENBQUMsS0FBSyxLQUFBLENBQVM7Q0FHeEIsTUFBTSxJQUFJLE1BQU0sR0FBRyxVQUFVLEtBQUs7Q0FFbEMsSUFBSSxRQUFRLFVBQVU7Q0FDdEIsSUFBSSxvQkFBb0IsTUFBTSxRQUFRLEdBQUc7Q0FDekMsTUFBTSxnQkFBZ0IsT0FBTyxLQUFLLEdBQUc7Q0FDckMsSUFBSSxnQkFBZ0IsT0FBTyxLQUFLLEdBQUc7Q0FFbkMsT0FBTyxzQkFBc0IsTUFBTSxnQkFBZ0IsZUFBZTtFQUNoRSxPQUFPLE1BQU0sTUFBTSxHQUFHLG9CQUFvQixDQUFDO0VBQzNDLFFBQVEsTUFBTSxNQUFNLG9CQUFvQixDQUFDO0VBQ3pDLG9CQUFvQixNQUFNLFFBQVEsR0FBRztFQUNyQztDQUNGO0NBRUEsT0FBTyxDQUFDLEtBQUssS0FBSztBQUNwQjs7Ozs7O0FBT0EsU0FBUyxTQUFTLE9BQU8sT0FBTztDQUM5QixNQUFNLE9BQU8sTUFBTSxNQUFNLFdBQVcsTUFBTSxRQUFRLENBQUM7Q0FFbkQsUUFDRyxNQUFNLFVBQVUsS0FDZixrQkFBa0IsSUFBSSxLQUN0QixtQkFBbUIsSUFBSSxPQUV4QixDQUFDLFNBQVMsU0FBUztBQUV4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyUUEsa0JBQWtCLE9BQU87Ozs7O0FBTXpCLFNBQVMsMEJBQTBCO0NBQ2pDLEtBQUssT0FBTztBQUNkOzs7OztBQU1BLFNBQVMsa0JBQWtCLE9BQU87Q0FDaEMsS0FBSyxNQUFNO0VBQUMsTUFBTTtFQUFxQixZQUFZO0VBQUksT0FBTztDQUFFLEdBQUcsS0FBSztBQUMxRTs7Ozs7QUFNQSxTQUFTLHFDQUFxQztDQUM1QyxLQUFLLE9BQU87QUFDZDs7Ozs7QUFNQSxTQUFTLHdCQUF3QixPQUFPO0NBQ3RDLEtBQUssTUFDSDtFQUFDLE1BQU07RUFBc0IsWUFBWTtFQUFJLE9BQU87RUFBSSxVQUFVLENBQUM7Q0FBQyxHQUNwRSxLQUNGO0FBQ0Y7Ozs7O0FBTUEsU0FBUyx1QkFBdUIsT0FBTztDQUNyQyxNQUFNLFFBQVEsS0FBSyxPQUFPO0NBQzFCLE1BQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLFNBQVM7Q0FDNUMsR0FBTyxLQUFLLFNBQVMsbUJBQW1CO0NBQ3hDLEtBQUssYUFBYSxvQkFDaEIsS0FBSyxlQUFlLEtBQUssQ0FDM0IsQ0FBQyxDQUFDLFlBQVk7Q0FDZCxLQUFLLFFBQVE7QUFDZjs7Ozs7QUFNQSxTQUFTLGlCQUFpQixPQUFPO0NBQy9CLEtBQUssS0FBSyxLQUFLO0FBQ2pCOzs7OztBQU1BLFNBQVMsa0NBQWtDLE9BQU87Q0FDaEQsTUFBTSxRQUFRLEtBQUssT0FBTztDQUMxQixNQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxTQUFTO0NBQzVDLEdBQU8sS0FBSyxTQUFTLG9CQUFvQjtDQUN6QyxLQUFLLGFBQWEsb0JBQ2hCLEtBQUssZUFBZSxLQUFLLENBQzNCLENBQUMsQ0FBQyxZQUFZO0NBQ2QsS0FBSyxRQUFRO0FBQ2Y7Ozs7O0FBTUEsU0FBUyx1QkFBdUIsT0FBTztDQUNyQyxLQUFLLEtBQUssS0FBSztBQUNqQjs7QUFHQSxTQUFTLHdCQUF3QjtDQUMvQixPQUFPO0FBQ1Q7Ozs7O0FBTUEsU0FBUyxrQkFBa0IsTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUMvQyxNQUFNLFVBQVUsTUFBTSxjQUFjLElBQUk7Q0FDeEMsSUFBSSxRQUFRLFFBQVEsS0FBSyxJQUFJO0NBQzdCLE1BQU0sT0FBTyxNQUFNLE1BQU0sbUJBQW1CO0NBQzVDLE1BQU0sVUFBVSxNQUFNLE1BQU0sV0FBVztDQUN2QyxTQUFTLFFBQVEsS0FDZixNQUFNLEtBQUssTUFBTSxjQUFjLElBQUksR0FBRztFQUFDLE9BQU87RUFBSyxRQUFRO0NBQUssQ0FBQyxDQUNuRTtDQUNBLFFBQVE7Q0FDUixLQUFLO0NBQ0wsU0FBUyxRQUFRLEtBQUssR0FBRztDQUN6QixPQUFPO0FBQ1Q7Ozs7Ozs7O0FBU0EsU0FBZ0IsMEJBQTBCO0NBQ3hDLE9BQU87RUFDTCxPQUFPO0dBQ0wsdUJBQXVCO0dBQ3ZCLGlCQUFpQjtHQUNqQixrQ0FBa0M7R0FDbEMsdUJBQXVCO0VBQ3pCO0VBQ0EsTUFBTTtHQUNKLHVCQUF1QjtHQUN2QixpQkFBaUI7R0FDakIsa0NBQWtDO0dBQ2xDLHVCQUF1QjtFQUN6QjtDQUNGO0FBQ0Y7Ozs7Ozs7Ozs7QUFXQSxTQUFnQixzQkFBc0IsU0FBUztDQUU3QyxJQUFJLGlCQUFpQjtDQUVyQixJQUFJLFdBQVcsUUFBUSxnQkFDckIsaUJBQWlCO0NBR25CLE9BQU87RUFDTCxVQUFVO0dBQUM7R0FBb0I7RUFBaUI7RUFFaEQsUUFBUSxDQUFDO0dBQUMsV0FBVztHQUFLLGFBQWE7SUFBQztJQUFTO0lBQVk7R0FBVztFQUFDLENBQUM7Q0FDNUU7Ozs7O0NBTUEsU0FBUyxtQkFBbUIsTUFBTSxHQUFHLE9BQU8sTUFBTTtFQUNoRCxNQUFNLFVBQVUsTUFBTSxjQUFjLElBQUk7RUFDeEMsSUFBSSxRQUFRLFFBQVEsS0FBSyxJQUFJO0VBQzdCLE1BQU0sT0FBTyxNQUFNLE1BQU0sb0JBQW9CO0VBQzdDLE1BQU0sVUFBVSxNQUFNLE1BQU0sT0FBTztFQUNuQyxTQUFTLFFBQVEsS0FDZixNQUFNLEtBQUssTUFBTSxjQUFjLElBQUksR0FBRztHQUFDLFFBQVE7R0FBTyxPQUFPO0VBQUcsQ0FBQyxDQUNuRTtFQUNBLFFBQVE7RUFFUixTQUFTLFFBQVEsS0FBSyxJQUFJO0VBRTFCLElBQUksS0FBSyxZQUFZLEtBQUssU0FBUyxTQUFTLEdBQUc7R0FDN0MsUUFBUSxNQUFNLENBQUM7R0FFZixTQUFTLFFBQVEsTUFDZCxpQkFBaUIsT0FBTyxPQUN2QixNQUFNLFlBQ0osTUFBTSxjQUFjLE1BQU0sUUFBUSxRQUFRLENBQUMsR0FDM0MsaUJBQWlCLFNBQVMsY0FDNUIsQ0FDSjtFQUNGO0VBRUEsS0FBSztFQUVMLE9BQU87Q0FDVDtBQUNGOztBQUdBLFNBQVMsZUFBZSxNQUFNLE9BQU8sT0FBTztDQUMxQyxPQUFPLFVBQVUsSUFBSSxPQUFPLE9BQU8sTUFBTSxPQUFPLEtBQUs7QUFDdkQ7O0FBR0EsU0FBUyxPQUFPLE1BQU0sT0FBTyxPQUFPO0NBQ2xDLFFBQVEsUUFBUSxLQUFLLFVBQVU7QUFDakM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdMQSxJQUFNLGlDQUFpQztDQUNyQztDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRjtBQUVBLGFBQWEsT0FBTzs7Ozs7Ozs7QUFTcEIsU0FBZ0IsK0JBQStCO0NBQzdDLE9BQU87RUFDTCxnQkFBZ0IsQ0FBQyxRQUFRO0VBQ3pCLE9BQU8sRUFBQyxlQUFlLG1CQUFrQjtFQUN6QyxNQUFNLEVBQUMsZUFBZSxrQkFBaUI7Q0FDekM7QUFDRjs7Ozs7Ozs7QUFTQSxTQUFnQiw2QkFBNkI7Q0FDM0MsT0FBTztFQUNMLFFBQVEsQ0FDTjtHQUNFLFdBQVc7R0FDWCxhQUFhO0dBQ2IsZ0JBQWdCO0VBQ2xCLENBQ0Y7RUFDQSxVQUFVLEVBQUMsUUFBUSxhQUFZO0NBQ2pDO0FBQ0Y7Ozs7O0FBTUEsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxLQUFLLE1BQU07RUFBQyxNQUFNO0VBQVUsVUFBVSxDQUFDO0NBQUMsR0FBRyxLQUFLO0FBQ2xEOzs7OztBQU1BLFNBQVMsa0JBQWtCLE9BQU87Q0FDaEMsS0FBSyxLQUFLLEtBQUs7QUFDakI7Ozs7O0FBTUEsU0FBUyxhQUFhLE1BQU0sR0FBRyxPQUFPLE1BQU07Q0FDMUMsTUFBTSxVQUFVLE1BQU0sY0FBYyxJQUFJO0NBQ3hDLE1BQU0sT0FBTyxNQUFNLE1BQU0sZUFBZTtDQUN4QyxJQUFJLFFBQVEsUUFBUSxLQUFLLElBQUk7Q0FDN0IsU0FBUyxNQUFNLGtCQUFrQixNQUFNO0VBQ3JDLEdBQUcsUUFBUSxRQUFRO0VBQ25CLFFBQVE7RUFDUixPQUFPO0NBQ1QsQ0FBQztDQUNELFNBQVMsUUFBUSxLQUFLLElBQUk7Q0FDMUIsS0FBSztDQUNMLE9BQU87QUFDVDs7QUFHQSxTQUFTLGFBQWE7Q0FDcEIsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNnREEsU0FBUyxvQkFBb0IsT0FBTztDQUNsQyxPQUFPLE1BQU07QUFDZjs7Ozs7Ozs7Ozs7OztBQWNBLFNBQWdCLGNBQWMsT0FBTyxTQUFTO0NBQzVDLE1BQU0sV0FBVyxXQUFXLENBQUM7Q0FFN0IsTUFBTSxTQUFTLFNBQVMsU0FBUyxDQUFDLEVBQUEsQ0FBRyxPQUFPO0NBQzVDLE1BQU0sZUFBZSxTQUFTLGdCQUFnQjs7Q0FFOUMsTUFBTSxhQUFhLENBQUM7O0NBRXBCLE1BQU0sYUFBYSxDQUFDOztDQUVwQixNQUFNLGFBQWEsQ0FBQzs7Q0FFcEIsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixJQUFJLGtCQUFrQjtDQUN0QixJQUFJLFdBQVc7Q0FJZixPQUFPLEVBQUUsV0FBVyxNQUFNLFFBQVE7O0VBRWhDLE1BQU0sTUFBTSxDQUFDOztFQUViLE1BQU0sUUFBUSxDQUFDO0VBQ2YsSUFBSSxjQUFjO0VBRWxCLElBQUksTUFBTSxTQUFTLENBQUMsU0FBUyxpQkFDM0Isa0JBQWtCLE1BQU0sU0FBUyxDQUFDO0VBR3BDLE9BQU8sRUFBRSxjQUFjLE1BQU0sU0FBUyxDQUFDLFFBQVE7R0FDN0MsTUFBTSxPQUFPLFVBQVUsTUFBTSxTQUFTLENBQUMsWUFBWTtHQUVuRCxJQUFJLFNBQVMsb0JBQW9CLE9BQU87SUFDdEMsTUFBTSxPQUFPLGFBQWEsSUFBSTtJQUM5QixNQUFNLGVBQWU7SUFFckIsSUFDRSxvQkFBb0IsaUJBQWlCLEtBQUEsS0FDckMsT0FBTyxvQkFBb0IsY0FFM0Isb0JBQW9CLGVBQWU7R0FFdkM7R0FFQSxJQUFJLEtBQUssSUFBSTtFQUNmO0VBRUEsV0FBVyxZQUFZO0VBQ3ZCLFdBQVcsWUFBWTtDQUN6QjtDQUdBLElBQUksY0FBYztDQUVsQixJQUFJLE9BQU8sVUFBVSxZQUFZLFlBQVksT0FDM0MsT0FBTyxFQUFFLGNBQWMsaUJBQ3JCLFdBQVcsZUFBZSxZQUFZLE1BQU0sWUFBWTtNQUVyRDtFQUNMLE1BQU0sT0FBTyxZQUFZLEtBQUs7RUFFOUIsT0FBTyxFQUFFLGNBQWMsaUJBQ3JCLFdBQVcsZUFBZTtDQUU5QjtDQUdBLGNBQWM7O0NBRWQsTUFBTSxNQUFNLENBQUM7O0NBRWIsTUFBTSxRQUFRLENBQUM7Q0FFZixPQUFPLEVBQUUsY0FBYyxpQkFBaUI7RUFDdEMsTUFBTSxPQUFPLFdBQVc7RUFDeEIsSUFBSSxTQUFTO0VBQ2IsSUFBSSxRQUFRO0VBRVosSUFBSSxTQUFTLElBQWM7R0FDekIsU0FBUztHQUNULFFBQVE7RUFDVixPQUFPLElBQUksU0FBUyxLQUNsQixTQUFTO09BQ0osSUFBSSxTQUFTLEtBQ2xCLFFBQVE7RUFJVixJQUFJLE9BQ0YsU0FBUyxvQkFBb0IsUUFDekIsSUFDQSxLQUFLLElBQ0gsR0FDQSxvQkFBb0IsZUFBZSxPQUFPLFNBQVMsTUFBTSxNQUMzRDtFQUVOLE1BQU0sT0FBTyxTQUFTLElBQUksT0FBTyxJQUFJLElBQUk7RUFFekMsSUFBSSxTQUFTLG9CQUFvQixPQUFPO0dBQ3RDLE9BQU8sT0FBTyxTQUFTLE9BQU8sTUFBTTtHQUVwQyxJQUFJLE9BQU8sb0JBQW9CLGNBQzdCLG9CQUFvQixlQUFlO0dBR3JDLE1BQU0sZUFBZTtFQUN2QjtFQUVBLElBQUksZUFBZTtDQUNyQjtDQUdBLFdBQVcsT0FBTyxHQUFHLEdBQUcsR0FBRztDQUMzQixXQUFXLE9BQU8sR0FBRyxHQUFHLEtBQUs7Q0FFN0IsV0FBVzs7Q0FFWCxNQUFNLFFBQVEsQ0FBQztDQUVmLE9BQU8sRUFBRSxXQUFXLFdBQVcsUUFBUTtFQUNyQyxNQUFNLE1BQU0sV0FBVztFQUN2QixNQUFNLFFBQVEsV0FBVztFQUN6QixjQUFjOztFQUVkLE1BQU0sT0FBTyxDQUFDO0VBRWQsT0FBTyxFQUFFLGNBQWMsaUJBQWlCO0dBQ3RDLE1BQU0sT0FBTyxJQUFJLGdCQUFnQjtHQUNqQyxJQUFJLFNBQVM7R0FDYixJQUFJLFFBQVE7R0FFWixJQUFJLFNBQVMsb0JBQW9CLE9BQU87SUFDdEMsTUFBTSxPQUNKLG9CQUFvQixnQkFBZ0IsTUFBTSxnQkFBZ0I7SUFDNUQsTUFBTSxPQUFPLFdBQVc7SUFFeEIsSUFBSSxTQUFTLEtBQ1gsU0FBUyxJQUFJLE9BQU8sSUFBSTtTQUNuQixJQUFJLFNBQVMsSUFBYztLQUNoQyxJQUFJLE9BQU8sR0FBRztNQUNaLFNBQVMsSUFBSSxPQUFPLE9BQU8sSUFBSSxFQUFHO01BQ2xDLFFBQVEsSUFBSSxPQUFPLE9BQU8sSUFBSSxFQUFHO0tBQ25DLE9BQU87TUFDTCxTQUFTLElBQUksT0FBTyxPQUFPLENBQUM7TUFDNUIsUUFBUTtLQUNWO0lBQ0YsT0FDRSxRQUFRLElBQUksT0FBTyxJQUFJO0dBRTNCO0dBRUEsSUFBSSxTQUFTLG1CQUFtQixTQUFTLENBQUMsYUFDeEMsS0FBSyxLQUFLLEdBQUc7R0FHZixJQUNFLFNBQVMsWUFBWSxTQUdyQixFQUFFLFNBQVMsb0JBQW9CLFNBQVMsU0FBUyxRQUNoRCxTQUFTLG1CQUFtQixTQUFTLGNBRXRDLEtBQUssS0FBSyxHQUFHO0dBR2YsSUFBSSxTQUFTLG9CQUFvQixPQUMvQixLQUFLLEtBQUssTUFBTTtHQUdsQixLQUFLLEtBQUssSUFBSTtHQUVkLElBQUksU0FBUyxvQkFBb0IsT0FDL0IsS0FBSyxLQUFLLEtBQUs7R0FHakIsSUFBSSxTQUFTLFlBQVksT0FDdkIsS0FBSyxLQUFLLEdBQUc7R0FHZixJQUNFLFNBQVMsaUJBQWlCLFNBQzFCLGdCQUFnQixrQkFBa0IsR0FFbEMsS0FBSyxLQUFLLEdBQUc7RUFFakI7RUFFQSxNQUFNLEtBQ0osU0FBUyxpQkFBaUIsUUFDdEIsS0FBSyxLQUFLLEVBQUUsQ0FBQyxDQUFDLFFBQVEsT0FBTyxFQUFFLElBQy9CLEtBQUssS0FBSyxFQUFFLENBQ2xCO0NBQ0Y7Q0FFQSxPQUFPLE1BQU0sS0FBSyxJQUFJO0FBQ3hCOzs7Ozs7O0FBUUEsU0FBUyxVQUFVLE9BQU87Q0FDeEIsT0FBTyxVQUFVLFFBQVEsVUFBVSxLQUFBLElBQVksS0FBSyxPQUFPLEtBQUs7QUFDbEU7Ozs7Ozs7QUFRQSxTQUFTLFlBQVksT0FBTztDQUMxQixNQUFNLE9BQU8sT0FBTyxVQUFVLFdBQVcsTUFBTSxZQUFZLENBQUMsSUFBSTtDQUVoRSxPQUFPLFNBQVMsTUFBZ0IsU0FBUyxLQUNyQyxLQUNBLFNBQVMsTUFBZ0IsU0FBUyxNQUNoQyxNQUNBLFNBQVMsTUFBZ0IsU0FBUyxNQUNoQyxNQUNBO0FBQ1Y7Ozs7Ozs7Ozs7Ozs7O0FDNVhBLFNBQWdCLFdBQVcsTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUMvQyxNQUFNLE9BQU8sTUFBTSxNQUFNLFlBQVk7Q0FDckMsTUFBTSxVQUFVLE1BQU0sY0FBYyxJQUFJO0NBQ3hDLFFBQVEsS0FBSyxJQUFJO0NBQ2pCLFFBQVEsTUFBTSxDQUFDO0NBQ2YsTUFBTSxRQUFRLE1BQU0sWUFDbEIsTUFBTSxjQUFjLE1BQU0sUUFBUSxRQUFRLENBQUMsR0FDM0NDLEtBQ0Y7Q0FDQSxLQUFLO0NBQ0wsT0FBTztBQUNUOztBQUdBLFNBQVNBLE1BQUksTUFBTSxHQUFHLE9BQU87Q0FDM0IsT0FBTyxPQUFPLFFBQVEsS0FBSyxPQUFPO0FBQ3BDOzs7Ozs7Ozs7OztBQ25CQSxTQUFnQixlQUFlLE9BQU8sU0FBUztDQUM3QyxPQUNFLFlBQVksT0FBTyxRQUFRLGFBQWEsSUFBSSxLQUM1QyxDQUFDLFlBQVksT0FBTyxRQUFRLGdCQUFnQixLQUFLO0FBRXJEOzs7Ozs7O0FBUUEsU0FBUyxZQUFZLE9BQU8sTUFBTSxNQUFNO0NBQ3RDLElBQUksT0FBTyxTQUFTLFVBQ2xCLE9BQU8sQ0FBQyxJQUFJO0NBR2QsSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLEdBQzNCLE9BQU87Q0FHVCxJQUFJLFFBQVE7Q0FFWixPQUFPLEVBQUUsUUFBUSxLQUFLLFFBQ3BCLElBQUksTUFBTSxTQUFTLEtBQUssTUFBTSxHQUM1QixPQUFPO0NBSVgsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7OztBQzFCQSxTQUFnQixVQUFVLEdBQUcsSUFBSSxPQUFPLE1BQU07Q0FDNUMsSUFBSSxRQUFRO0NBRVosT0FBTyxFQUFFLFFBQVEsTUFBTSxPQUFPLFFBRzVCLElBQ0UsTUFBTSxPQUFPLE1BQU0sQ0FBQyxjQUFjLFFBQ2xDLGVBQWUsTUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNLEdBRS9DLE9BQU8sUUFBUSxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQUs7Q0FJNUMsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7QUNuQkEsU0FBZ0IscUJBQXFCLE1BQU0sT0FBTztDQUNoRCxPQUFPLFFBQ0wsTUFBTSxRQUFRLFdBQVcsU0FDdkIsS0FBSyxTQUVMLENBQUMsS0FBSyxRQUVOLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FFMUIsQ0FBQywwQ0FBMEMsS0FBSyxLQUFLLEtBQUssQ0FDOUQ7QUFDRjs7Ozs7Ozs7OztBQ2JBLFNBQWdCLFdBQVcsT0FBTztDQUNoQyxNQUFNLFNBQVMsTUFBTSxRQUFRLFNBQVM7Q0FFdEMsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUMvQixNQUFNLElBQUksTUFDUixpQ0FDRSxTQUNBLGdEQUNKO0NBR0YsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7OztBQ0pBLFNBQWdCQyxPQUFLLE1BQU0sR0FBRyxPQUFPLE1BQU07Q0FDekMsTUFBTSxTQUFTLFdBQVcsS0FBSztDQUMvQixNQUFNLE1BQU0sS0FBSyxTQUFTO0NBQzFCLE1BQU0sU0FBUyxXQUFXLE1BQU0sZ0JBQWdCO0NBRWhELElBQUkscUJBQXFCLE1BQU0sS0FBSyxHQUFHO0VBQ3JDLE1BQU0sT0FBTyxNQUFNLE1BQU0sY0FBYztFQUN2QyxNQUFNLFFBQVEsTUFBTSxZQUFZLEtBQUssR0FBRztFQUN4QyxLQUFLO0VBQ0wsT0FBTztDQUNUO0NBRUEsTUFBTSxVQUFVLE1BQU0sY0FBYyxJQUFJO0NBQ3hDLE1BQU0sV0FBVyxPQUFPLE9BQU8sS0FBSyxJQUFJLGNBQWMsS0FBSyxNQUFNLElBQUksR0FBRyxDQUFDLENBQUM7Q0FDMUUsTUFBTSxPQUFPLE1BQU0sTUFBTSxZQUFZO0NBQ3JDLElBQUksUUFBUSxRQUFRLEtBQUssUUFBUTtDQUVqQyxJQUFJLEtBQUssTUFBTTtFQUNiLE1BQU0sVUFBVSxNQUFNLE1BQU0saUJBQWlCLFFBQVE7RUFDckQsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssTUFBTTtHQUNwQixRQUFRO0dBQ1IsT0FBTztHQUNQLFFBQVEsQ0FBQyxHQUFHO0dBQ1osR0FBRyxRQUFRLFFBQVE7RUFDckIsQ0FBQyxDQUNIO0VBQ0EsUUFBUTtDQUNWO0NBRUEsSUFBSSxLQUFLLFFBQVEsS0FBSyxNQUFNO0VBQzFCLE1BQU0sVUFBVSxNQUFNLE1BQU0saUJBQWlCLFFBQVE7RUFDckQsU0FBUyxRQUFRLEtBQUssR0FBRztFQUN6QixTQUFTLFFBQVEsS0FDZixNQUFNLEtBQUssS0FBSyxNQUFNO0dBQ3BCLFFBQVE7R0FDUixPQUFPO0dBQ1AsUUFBUSxDQUFDLEdBQUc7R0FDWixHQUFHLFFBQVEsUUFBUTtFQUNyQixDQUFDLENBQ0g7RUFDQSxRQUFRO0NBQ1Y7Q0FFQSxTQUFTLFFBQVEsS0FBSyxJQUFJO0NBRTFCLElBQUksS0FDRixTQUFTLFFBQVEsS0FBSyxNQUFNLElBQUk7Q0FHbEMsU0FBUyxRQUFRLEtBQUssUUFBUTtDQUM5QixLQUFLO0NBQ0wsT0FBTztBQUNUOztBQUdBLFNBQVMsSUFBSSxNQUFNLEdBQUcsT0FBTztDQUMzQixRQUFRLFFBQVEsS0FBSyxVQUFVO0FBQ2pDOzs7Ozs7Ozs7O0FDbEVBLFNBQWdCLFdBQVcsT0FBTztDQUNoQyxNQUFNLFNBQVMsTUFBTSxRQUFRLFNBQVM7Q0FFdEMsSUFBSSxXQUFXLFFBQU8sV0FBVyxLQUMvQixNQUFNLElBQUksTUFDUixrQ0FDRSxTQUNBLDhDQUNKO0NBR0YsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7OztBQ05BLFNBQWdCLFdBQVcsTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUMvQyxNQUFNLFFBQVEsV0FBVyxLQUFLO0NBQzlCLE1BQU0sU0FBUyxVQUFVLE9BQU0sVUFBVTtDQUN6QyxNQUFNLE9BQU8sTUFBTSxNQUFNLFlBQVk7Q0FDckMsSUFBSSxVQUFVLE1BQU0sTUFBTSxPQUFPO0NBQ2pDLE1BQU0sVUFBVSxNQUFNLGNBQWMsSUFBSTtDQUN4QyxJQUFJLFFBQVEsUUFBUSxLQUFLLEdBQUc7Q0FDNUIsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLE1BQU0sY0FBYyxJQUFJLEdBQUc7RUFDcEMsUUFBUTtFQUNSLE9BQU87RUFDUCxHQUFHLFFBQVEsUUFBUTtDQUNyQixDQUFDLENBQ0g7Q0FDQSxTQUFTLFFBQVEsS0FBSyxLQUFLO0NBRTNCLFFBQVE7Q0FFUixJQUVFLENBQUMsS0FBSyxPQUVOLGVBQWUsS0FBSyxLQUFLLEdBQUcsR0FDNUI7RUFDQSxVQUFVLE1BQU0sTUFBTSxvQkFBb0I7RUFDMUMsU0FBUyxRQUFRLEtBQUssR0FBRztFQUN6QixTQUFTLFFBQVEsS0FDZixNQUFNLEtBQUssS0FBSyxLQUFLO0dBQUMsUUFBUTtHQUFPLE9BQU87R0FBSyxHQUFHLFFBQVEsUUFBUTtFQUFDLENBQUMsQ0FDeEU7RUFDQSxTQUFTLFFBQVEsS0FBSyxHQUFHO0NBQzNCLE9BQU87RUFFTCxVQUFVLE1BQU0sTUFBTSxnQkFBZ0I7RUFDdEMsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssS0FBSztHQUNuQixRQUFRO0dBQ1IsT0FBTyxLQUFLLFFBQVEsTUFBTTtHQUMxQixHQUFHLFFBQVEsUUFBUTtFQUNyQixDQUFDLENBQ0g7Q0FDRjtDQUVBLFFBQVE7Q0FFUixJQUFJLEtBQUssT0FBTztFQUNkLFVBQVUsTUFBTSxNQUFNLFFBQVEsUUFBUTtFQUN0QyxTQUFTLFFBQVEsS0FBSyxNQUFNLEtBQUs7RUFDakMsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssT0FBTztHQUNyQixRQUFRO0dBQ1IsT0FBTztHQUNQLEdBQUcsUUFBUSxRQUFRO0VBQ3JCLENBQUMsQ0FDSDtFQUNBLFNBQVMsUUFBUSxLQUFLLEtBQUs7RUFDM0IsUUFBUTtDQUNWO0NBRUEsS0FBSztDQUVMLE9BQU87QUFDVDs7Ozs7Ozs7OztBQ25FQSxTQUFnQixjQUFjLE9BQU87Q0FDbkMsTUFBTSxTQUFTLE1BQU0sUUFBUSxZQUFZO0NBRXpDLElBQUksV0FBVyxPQUFPLFdBQVcsS0FDL0IsTUFBTSxJQUFJLE1BQ1IscUNBQ0UsU0FDQSxnREFDSjtDQUdGLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7QUNaQSxTQUFnQix5QkFBeUIsTUFBTTtDQUM3QyxPQUFPLFFBQVEsS0FBSyxTQUFTLEVBQUUsQ0FBQyxDQUFDLFlBQVksSUFBSTtBQUNuRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOEJBLFNBQWdCLFdBQVcsU0FBUyxRQUFRLFFBQVE7Q0FDbEQsTUFBTSxjQUFjLGtCQUFrQixPQUFPO0NBQzdDLE1BQU0sYUFBYSxrQkFBa0IsTUFBTTtDQUczQyxJQUFJLGdCQUFnQixLQUFBLEdBQ2xCLE9BQU8sZUFBZSxLQUFBLElBSWxCLFdBQVcsTUFDVDtFQUFDLFFBQVE7RUFBTSxTQUFTO0NBQUksSUFDNUI7RUFBQyxRQUFRO0VBQU8sU0FBUztDQUFLLElBQ2hDLGVBQWUsSUFFYjtFQUFDLFFBQVE7RUFBTSxTQUFTO0NBQUksSUFFNUI7RUFBQyxRQUFRO0VBQU8sU0FBUztDQUFJO0NBSXJDLElBQUksZ0JBQWdCLEdBQ2xCLE9BQU8sZUFBZSxLQUFBLElBRWxCO0VBQUMsUUFBUTtFQUFPLFNBQVM7Q0FBSyxJQUM5QixlQUFlLElBRWI7RUFBQyxRQUFRO0VBQU0sU0FBUztDQUFJLElBRTVCO0VBQUMsUUFBUTtFQUFPLFNBQVM7Q0FBSztDQUl0QyxPQUFPLGVBQWUsS0FBQSxJQUVsQjtFQUFDLFFBQVE7RUFBTyxTQUFTO0NBQUssSUFDOUIsZUFBZSxJQUViO0VBQUMsUUFBUTtFQUFNLFNBQVM7Q0FBSyxJQUU3QjtFQUFDLFFBQVE7RUFBTyxTQUFTO0NBQUs7QUFDdEM7Ozs7Ozs7QUN4RUEsU0FBUyxPQUFPOzs7Ozs7OztBQVNoQixTQUFnQixTQUFTLE1BQU0sR0FBRyxPQUFPLE1BQU07Q0FDN0MsTUFBTSxTQUFTLGNBQWMsS0FBSztDQUNsQyxNQUFNLE9BQU8sTUFBTSxNQUFNLFVBQVU7Q0FDbkMsTUFBTSxVQUFVLE1BQU0sY0FBYyxJQUFJO0NBQ3hDLE1BQU0sU0FBUyxRQUFRLEtBQUssTUFBTTtDQUVsQyxJQUFJLFVBQVUsUUFBUSxLQUNwQixNQUFNLGtCQUFrQixNQUFNO0VBQzVCLE9BQU87RUFDUDtFQUNBLEdBQUcsUUFBUSxRQUFRO0NBQ3JCLENBQUMsQ0FDSDtDQUNBLE1BQU0sY0FBYyxRQUFRLFdBQVcsQ0FBQztDQUN4QyxNQUFNLE9BQU8sV0FDWCxLQUFLLE9BQU8sV0FBVyxLQUFLLE9BQU8sU0FBUyxDQUFDLEdBQzdDLGFBQ0EsTUFDRjtDQUVBLElBQUksS0FBSyxRQUNQLFVBQVUseUJBQXlCLFdBQVcsSUFBSSxRQUFRLE1BQU0sQ0FBQztDQUduRSxNQUFNLGNBQWMsUUFBUSxXQUFXLFFBQVEsU0FBUyxDQUFDO0NBQ3pELE1BQU0sUUFBUSxXQUFXLEtBQUssTUFBTSxXQUFXLENBQUMsR0FBRyxhQUFhLE1BQU07Q0FFdEUsSUFBSSxNQUFNLFFBQ1IsVUFBVSxRQUFRLE1BQU0sR0FBRyxFQUFFLElBQUkseUJBQXlCLFdBQVc7Q0FHdkUsTUFBTSxRQUFRLFFBQVEsS0FBSyxNQUFNO0NBRWpDLEtBQUs7Q0FFTCxNQUFNLGlDQUFpQztFQUNyQyxPQUFPLE1BQU07RUFDYixRQUFRLEtBQUs7Q0FDZjtDQUNBLE9BQU8sU0FBUyxVQUFVO0FBQzVCOzs7Ozs7O0FBUUEsU0FBUyxhQUFhLEdBQUcsSUFBSSxPQUFPO0NBQ2xDLE9BQU8sTUFBTSxRQUFRLFlBQVk7QUFDbkM7Ozs7Ozs7Ozs7OztBQ3ZEQSxTQUFnQixzQkFBc0IsTUFBTSxPQUFPO0NBQ2pELElBQUksbUJBQW1CO0NBSXZCLE1BQU0sTUFBTSxTQUFVLE1BQU07RUFDMUIsSUFDRyxXQUFXLFFBQVEsV0FBVyxLQUFLLEtBQUssS0FBSyxLQUM5QyxLQUFLLFNBQVMsU0FDZDtHQUNBLG1CQUFtQjtHQUNuQixPQUFBO0VBQ0Y7Q0FDRixDQUFDO0NBRUQsT0FBTyxTQUNKLENBQUMsS0FBSyxTQUFTLEtBQUssUUFBUSxNQUMzQixTQUFTLElBQUksTUFDWixNQUFNLFFBQVEsVUFBVSxpQkFDN0I7QUFDRjs7Ozs7Ozs7Ozs7Ozs7QUNsQkEsU0FBZ0IsUUFBUSxNQUFNLEdBQUcsT0FBTyxNQUFNO0NBQzVDLE1BQU0sT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxTQUFTLENBQUMsR0FBRyxDQUFDO0NBQ3JELE1BQU0sVUFBVSxNQUFNLGNBQWMsSUFBSTtDQUV4QyxJQUFJLHNCQUFzQixNQUFNLEtBQUssR0FBRztFQUN0QyxNQUFNLE9BQU8sTUFBTSxNQUFNLGVBQWU7RUFDeEMsTUFBTSxVQUFVLE1BQU0sTUFBTSxVQUFVO0VBQ3RDLE1BQU0sUUFBUSxNQUFNLGtCQUFrQixNQUFNO0dBQzFDLEdBQUcsUUFBUSxRQUFRO0dBQ25CLFFBQVE7R0FDUixPQUFPO0VBQ1QsQ0FBQztFQUNELFFBQVE7RUFDUixLQUFLO0VBRUwsT0FDRSxRQUNBLFFBQ0MsU0FBUyxJQUFJLE1BQU0sSUFBQSxDQUFLLE9BRXZCLE1BQU0sVUFHSCxLQUFLLElBQUksTUFBTSxZQUFZLElBQUksR0FBRyxNQUFNLFlBQVksSUFBSSxDQUFDLElBQUksRUFDbEU7Q0FFSjtDQUVBLE1BQU0sV0FBVyxJQUFJLE9BQU8sSUFBSTtDQUNoQyxNQUFNLE9BQU8sTUFBTSxNQUFNLFlBQVk7Q0FDckMsTUFBTSxVQUFVLE1BQU0sTUFBTSxVQUFVO0NBTXRDLFFBQVEsS0FBSyxXQUFXLEdBQUc7Q0FFM0IsSUFBSSxRQUFRLE1BQU0sa0JBQWtCLE1BQU07RUFDeEMsUUFBUTtFQUNSLE9BQU87RUFDUCxHQUFHLFFBQVEsUUFBUTtDQUNyQixDQUFDO0NBRUQsSUFBSSxTQUFTLEtBQUssS0FBSyxHQUVyQixRQUFRLHlCQUF5QixNQUFNLFdBQVcsQ0FBQyxDQUFDLElBQUksTUFBTSxNQUFNLENBQUM7Q0FHdkUsUUFBUSxRQUFRLFdBQVcsTUFBTSxRQUFRO0NBRXpDLElBQUksTUFBTSxRQUFRLFVBQ2hCLFNBQVMsTUFBTTtDQUdqQixRQUFRO0NBQ1IsS0FBSztDQUVMLE9BQU87QUFDVDs7Ozs7O0FDdEVBLEtBQUssT0FBTzs7Ozs7QUFNWixTQUFnQixLQUFLLE1BQU07Q0FDekIsT0FBTyxLQUFLLFNBQVM7QUFDdkI7Ozs7QUFLQSxTQUFTLFdBQVc7Q0FDbEIsT0FBTztBQUNUOzs7Ozs7O0FDWkEsTUFBTSxPQUFPOzs7Ozs7OztBQVNiLFNBQWdCLE1BQU0sTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUMxQyxNQUFNLFFBQVEsV0FBVyxLQUFLO0NBQzlCLE1BQU0sU0FBUyxVQUFVLE9BQU0sVUFBVTtDQUN6QyxNQUFNLE9BQU8sTUFBTSxNQUFNLE9BQU87Q0FDaEMsSUFBSSxVQUFVLE1BQU0sTUFBTSxPQUFPO0NBQ2pDLE1BQU0sVUFBVSxNQUFNLGNBQWMsSUFBSTtDQUN4QyxJQUFJLFFBQVEsUUFBUSxLQUFLLElBQUk7Q0FDN0IsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssS0FBSztFQUFDLFFBQVE7RUFBTyxPQUFPO0VBQUssR0FBRyxRQUFRLFFBQVE7Q0FBQyxDQUFDLENBQ3hFO0NBQ0EsU0FBUyxRQUFRLEtBQUssSUFBSTtDQUUxQixRQUFRO0NBRVIsSUFFRyxDQUFDLEtBQUssT0FBTyxLQUFLLFNBRW5CLGVBQWUsS0FBSyxLQUFLLEdBQUcsR0FDNUI7RUFDQSxVQUFVLE1BQU0sTUFBTSxvQkFBb0I7RUFDMUMsU0FBUyxRQUFRLEtBQUssR0FBRztFQUN6QixTQUFTLFFBQVEsS0FDZixNQUFNLEtBQUssS0FBSyxLQUFLO0dBQUMsUUFBUTtHQUFPLE9BQU87R0FBSyxHQUFHLFFBQVEsUUFBUTtFQUFDLENBQUMsQ0FDeEU7RUFDQSxTQUFTLFFBQVEsS0FBSyxHQUFHO0NBQzNCLE9BQU87RUFFTCxVQUFVLE1BQU0sTUFBTSxnQkFBZ0I7RUFDdEMsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssS0FBSztHQUNuQixRQUFRO0dBQ1IsT0FBTyxLQUFLLFFBQVEsTUFBTTtHQUMxQixHQUFHLFFBQVEsUUFBUTtFQUNyQixDQUFDLENBQ0g7Q0FDRjtDQUVBLFFBQVE7Q0FFUixJQUFJLEtBQUssT0FBTztFQUNkLFVBQVUsTUFBTSxNQUFNLFFBQVEsUUFBUTtFQUN0QyxTQUFTLFFBQVEsS0FBSyxNQUFNLEtBQUs7RUFDakMsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssT0FBTztHQUNyQixRQUFRO0dBQ1IsT0FBTztHQUNQLEdBQUcsUUFBUSxRQUFRO0VBQ3JCLENBQUMsQ0FDSDtFQUNBLFNBQVMsUUFBUSxLQUFLLEtBQUs7RUFDM0IsUUFBUTtDQUNWO0NBRUEsU0FBUyxRQUFRLEtBQUssR0FBRztDQUN6QixLQUFLO0NBRUwsT0FBTztBQUNUOzs7O0FBS0EsU0FBUyxZQUFZO0NBQ25CLE9BQU87QUFDVDs7Ozs7OztBQzVFQSxlQUFlLE9BQU87Ozs7Ozs7O0FBU3RCLFNBQWdCLGVBQWUsTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUNuRCxNQUFNLE9BQU8sS0FBSztDQUNsQixNQUFNLE9BQU8sTUFBTSxNQUFNLGdCQUFnQjtDQUN6QyxJQUFJLFVBQVUsTUFBTSxNQUFNLE9BQU87Q0FDakMsTUFBTSxVQUFVLE1BQU0sY0FBYyxJQUFJO0NBQ3hDLElBQUksUUFBUSxRQUFRLEtBQUssSUFBSTtDQUM3QixNQUFNLE1BQU0sTUFBTSxLQUFLLEtBQUssS0FBSztFQUMvQixRQUFRO0VBQ1IsT0FBTztFQUNQLEdBQUcsUUFBUSxRQUFRO0NBQ3JCLENBQUM7Q0FDRCxTQUFTLFFBQVEsS0FBSyxNQUFNLElBQUk7Q0FFaEMsUUFBUTtDQUVSLE1BQU0sUUFBUSxNQUFNO0NBQ3BCLE1BQU0sUUFBUSxDQUFDO0NBQ2YsVUFBVSxNQUFNLE1BQU0sV0FBVztDQUtqQyxNQUFNLFlBQVksTUFBTSxLQUFLLE1BQU0sY0FBYyxJQUFJLEdBQUc7RUFDdEQsUUFBUTtFQUNSLE9BQU87RUFDUCxHQUFHLFFBQVEsUUFBUTtDQUNyQixDQUFDO0NBQ0QsUUFBUTtDQUNSLE1BQU0sUUFBUTtDQUNkLEtBQUs7Q0FFTCxJQUFJLFNBQVMsVUFBVSxDQUFDLE9BQU8sUUFBUSxXQUNyQyxTQUFTLFFBQVEsS0FBSyxZQUFZLEdBQUc7TUFDaEMsSUFBSSxTQUFTLFlBRWxCLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRTtNQUV6QixTQUFTLFFBQVEsS0FBSyxHQUFHO0NBRzNCLE9BQU87QUFDVDs7OztBQUtBLFNBQVMscUJBQXFCO0NBQzVCLE9BQU87QUFDVDs7Ozs7OztBQ3pEQSxXQUFXLE9BQU87Ozs7Ozs7QUFRbEIsU0FBZ0IsV0FBVyxNQUFNLEdBQUcsT0FBTztDQUN6QyxJQUFJLFFBQVEsS0FBSyxTQUFTO0NBQzFCLElBQUksV0FBVztDQUNmLElBQUksUUFBUTtDQUtaLE9BQU8sSUFBSSxPQUFPLGFBQWEsV0FBVyxVQUFVLENBQUMsQ0FBQyxLQUFLLEtBQUssR0FDOUQsWUFBWTtDQUtkLElBQ0UsV0FBVyxLQUFLLEtBQUssTUFDbkIsV0FBVyxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUssS0FBSyxLQUFNLFFBQVEsS0FBSyxLQUFLLElBRXpFLFFBQVEsTUFBTSxRQUFRO0NBVXhCLE9BQU8sRUFBRSxRQUFRLE1BQU0sT0FBTyxRQUFRO0VBQ3BDLE1BQU0sVUFBVSxNQUFNLE9BQU87RUFDN0IsTUFBTSxhQUFhLE1BQU0sZUFBZSxPQUFPOztFQUUvQyxJQUFJO0VBS0osSUFBSSxDQUFDLFFBQVEsU0FBUztFQUV0QixPQUFRLFFBQVEsV0FBVyxLQUFLLEtBQUssR0FBSTtHQUN2QyxJQUFJLFdBQVcsTUFBTTtHQUdyQixJQUNFLE1BQU0sV0FBVyxRQUFRLE1BQU0sTUFDL0IsTUFBTSxXQUFXLFdBQVcsQ0FBQyxNQUFNLElBRW5DO0dBR0YsUUFBUSxNQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxRQUFRLENBQUM7RUFDdEU7Q0FDRjtDQUVBLE9BQU8sV0FBVyxRQUFRO0FBQzVCOzs7O0FBS0EsU0FBUyxpQkFBaUI7Q0FDeEIsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7QUMvREEsU0FBZ0IscUJBQXFCLE1BQU0sT0FBTztDQUNoRCxNQUFNLE1BQU0sU0FBUyxJQUFJO0NBRXpCLE9BQU8sUUFDTCxDQUFDLE1BQU0sUUFBUSxnQkFFYixLQUFLLE9BRUwsQ0FBQyxLQUFLLFNBRU4sS0FBSyxZQUNMLEtBQUssU0FBUyxXQUFXLEtBQ3pCLEtBQUssU0FBUyxFQUFFLENBQUMsU0FBUyxXQUV6QixRQUFRLEtBQUssT0FBTyxZQUFZLFFBQVEsS0FBSyxRQUU5QyxvQkFBb0IsS0FBSyxLQUFLLEdBQUcsS0FHakMsQ0FBQyxpQkFBaUIsS0FBSyxLQUFLLEdBQUcsQ0FDbkM7QUFDRjs7Ozs7Ozs7QUN4QkEsS0FBSyxPQUFPOzs7Ozs7OztBQVNaLFNBQWdCLEtBQUssTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUN6QyxNQUFNLFFBQVEsV0FBVyxLQUFLO0NBQzlCLE1BQU0sU0FBUyxVQUFVLE9BQU0sVUFBVTtDQUN6QyxNQUFNLFVBQVUsTUFBTSxjQUFjLElBQUk7O0NBRXhDLElBQUk7O0NBRUosSUFBSTtDQUVKLElBQUkscUJBQXFCLE1BQU0sS0FBSyxHQUFHO0VBRXJDLE1BQU0sUUFBUSxNQUFNO0VBQ3BCLE1BQU0sUUFBUSxDQUFDO0VBQ2YsT0FBTyxNQUFNLE1BQU0sVUFBVTtFQUM3QixJQUFJLFFBQVEsUUFBUSxLQUFLLEdBQUc7RUFDNUIsU0FBUyxRQUFRLEtBQ2YsTUFBTSxrQkFBa0IsTUFBTTtHQUM1QixRQUFRO0dBQ1IsT0FBTztHQUNQLEdBQUcsUUFBUSxRQUFRO0VBQ3JCLENBQUMsQ0FDSDtFQUNBLFNBQVMsUUFBUSxLQUFLLEdBQUc7RUFDekIsS0FBSztFQUNMLE1BQU0sUUFBUTtFQUNkLE9BQU87Q0FDVDtDQUVBLE9BQU8sTUFBTSxNQUFNLE1BQU07Q0FDekIsVUFBVSxNQUFNLE1BQU0sT0FBTztDQUM3QixJQUFJLFFBQVEsUUFBUSxLQUFLLEdBQUc7Q0FDNUIsU0FBUyxRQUFRLEtBQ2YsTUFBTSxrQkFBa0IsTUFBTTtFQUM1QixRQUFRO0VBQ1IsT0FBTztFQUNQLEdBQUcsUUFBUSxRQUFRO0NBQ3JCLENBQUMsQ0FDSDtDQUNBLFNBQVMsUUFBUSxLQUFLLElBQUk7Q0FDMUIsUUFBUTtDQUVSLElBRUcsQ0FBQyxLQUFLLE9BQU8sS0FBSyxTQUVuQixlQUFlLEtBQUssS0FBSyxHQUFHLEdBQzVCO0VBQ0EsVUFBVSxNQUFNLE1BQU0sb0JBQW9CO0VBQzFDLFNBQVMsUUFBUSxLQUFLLEdBQUc7RUFDekIsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssS0FBSztHQUFDLFFBQVE7R0FBTyxPQUFPO0dBQUssR0FBRyxRQUFRLFFBQVE7RUFBQyxDQUFDLENBQ3hFO0VBQ0EsU0FBUyxRQUFRLEtBQUssR0FBRztDQUMzQixPQUFPO0VBRUwsVUFBVSxNQUFNLE1BQU0sZ0JBQWdCO0VBQ3RDLFNBQVMsUUFBUSxLQUNmLE1BQU0sS0FBSyxLQUFLLEtBQUs7R0FDbkIsUUFBUTtHQUNSLE9BQU8sS0FBSyxRQUFRLE1BQU07R0FDMUIsR0FBRyxRQUFRLFFBQVE7RUFDckIsQ0FBQyxDQUNIO0NBQ0Y7Q0FFQSxRQUFRO0NBRVIsSUFBSSxLQUFLLE9BQU87RUFDZCxVQUFVLE1BQU0sTUFBTSxRQUFRLFFBQVE7RUFDdEMsU0FBUyxRQUFRLEtBQUssTUFBTSxLQUFLO0VBQ2pDLFNBQVMsUUFBUSxLQUNmLE1BQU0sS0FBSyxLQUFLLE9BQU87R0FDckIsUUFBUTtHQUNSLE9BQU87R0FDUCxHQUFHLFFBQVEsUUFBUTtFQUNyQixDQUFDLENBQ0g7RUFDQSxTQUFTLFFBQVEsS0FBSyxLQUFLO0VBQzNCLFFBQVE7Q0FDVjtDQUVBLFNBQVMsUUFBUSxLQUFLLEdBQUc7Q0FFekIsS0FBSztDQUNMLE9BQU87QUFDVDs7Ozs7OztBQVFBLFNBQVMsU0FBUyxNQUFNLEdBQUcsT0FBTztDQUNoQyxPQUFPLHFCQUFxQixNQUFNLEtBQUssSUFBSSxNQUFNO0FBQ25EOzs7Ozs7O0FDNUdBLGNBQWMsT0FBTzs7Ozs7Ozs7QUFTckIsU0FBZ0IsY0FBYyxNQUFNLEdBQUcsT0FBTyxNQUFNO0NBQ2xELE1BQU0sT0FBTyxLQUFLO0NBQ2xCLE1BQU0sT0FBTyxNQUFNLE1BQU0sZUFBZTtDQUN4QyxJQUFJLFVBQVUsTUFBTSxNQUFNLE9BQU87Q0FDakMsTUFBTSxVQUFVLE1BQU0sY0FBYyxJQUFJO0NBQ3hDLElBQUksUUFBUSxRQUFRLEtBQUssR0FBRztDQUM1QixNQUFNLE9BQU8sTUFBTSxrQkFBa0IsTUFBTTtFQUN6QyxRQUFRO0VBQ1IsT0FBTztFQUNQLEdBQUcsUUFBUSxRQUFRO0NBQ3JCLENBQUM7Q0FDRCxTQUFTLFFBQVEsS0FBSyxPQUFPLElBQUk7Q0FFakMsUUFBUTtDQUVSLE1BQU0sUUFBUSxNQUFNO0NBQ3BCLE1BQU0sUUFBUSxDQUFDO0NBQ2YsVUFBVSxNQUFNLE1BQU0sV0FBVztDQUtqQyxNQUFNLFlBQVksTUFBTSxLQUFLLE1BQU0sY0FBYyxJQUFJLEdBQUc7RUFDdEQsUUFBUTtFQUNSLE9BQU87RUFDUCxHQUFHLFFBQVEsUUFBUTtDQUNyQixDQUFDO0NBQ0QsUUFBUTtDQUNSLE1BQU0sUUFBUTtDQUNkLEtBQUs7Q0FFTCxJQUFJLFNBQVMsVUFBVSxDQUFDLFFBQVEsU0FBUyxXQUN2QyxTQUFTLFFBQVEsS0FBSyxZQUFZLEdBQUc7TUFDaEMsSUFBSSxTQUFTLFlBRWxCLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRTtNQUV6QixTQUFTLFFBQVEsS0FBSyxHQUFHO0NBRzNCLE9BQU87QUFDVDs7OztBQUtBLFNBQVMsb0JBQW9CO0NBQzNCLE9BQU87QUFDVDs7Ozs7Ozs7OztBQ3REQSxTQUFnQixZQUFZLE9BQU87Q0FDakMsTUFBTSxTQUFTLE1BQU0sUUFBUSxVQUFVO0NBRXZDLElBQUksV0FBVyxPQUFPLFdBQVcsT0FBTyxXQUFXLEtBQ2pELE1BQU0sSUFBSSxNQUNSLGtDQUNFLFNBQ0EsbURBQ0o7Q0FHRixPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7QUNWQSxTQUFnQixpQkFBaUIsT0FBTztDQUN0QyxNQUFNLFNBQVMsWUFBWSxLQUFLO0NBQ2hDLE1BQU0sY0FBYyxNQUFNLFFBQVE7Q0FFbEMsSUFBSSxDQUFDLGFBQ0gsT0FBTyxXQUFXLE1BQU0sTUFBTTtDQUdoQyxJQUFJLGdCQUFnQixPQUFPLGdCQUFnQixPQUFPLGdCQUFnQixLQUNoRSxNQUFNLElBQUksTUFDUixrQ0FDRSxjQUNBLHdEQUNKO0NBR0YsSUFBSSxnQkFBZ0IsUUFDbEIsTUFBTSxJQUFJLE1BQ1IseUJBQ0UsU0FDQSw0QkFDQSxjQUNBLG9CQUNKO0NBR0YsT0FBTztBQUNUOzs7Ozs7Ozs7O0FDN0JBLFNBQWdCLG1CQUFtQixPQUFPO0NBQ3hDLE1BQU0sU0FBUyxNQUFNLFFBQVEsaUJBQWlCO0NBRTlDLElBQUksV0FBVyxPQUFPLFdBQVcsS0FDL0IsTUFBTSxJQUFJLE1BQ1Isa0NBQ0UsU0FDQSxvREFDSjtDQUdGLE9BQU87QUFDVDs7Ozs7Ozs7OztBQ1pBLFNBQWdCLFVBQVUsT0FBTztDQUMvQixNQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVE7Q0FFckMsSUFBSSxXQUFXLE9BQU8sV0FBVyxPQUFPLFdBQVcsS0FDakQsTUFBTSxJQUFJLE1BQ1Isa0NBQ0UsU0FDQSxpREFDSjtDQUdGLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7Ozs7QUNIQSxTQUFnQixLQUFLLE1BQU0sUUFBUSxPQUFPLE1BQU07Q0FDOUMsTUFBTSxPQUFPLE1BQU0sTUFBTSxNQUFNO0NBQy9CLE1BQU0sZ0JBQWdCLE1BQU07O0NBRTVCLElBQUksU0FBUyxLQUFLLFVBQVUsbUJBQW1CLEtBQUssSUFBSSxZQUFZLEtBQUs7O0NBRXpFLE1BQU0sY0FBYyxLQUFLLFVBQ3JCLFdBQVcsTUFDVCxNQUNBLE1BQ0YsaUJBQWlCLEtBQUs7Q0FDMUIsSUFBSSxxQkFDRixVQUFVLE1BQU0saUJBQWlCLFdBQVcsTUFBTSxpQkFBaUI7Q0FFckUsSUFBSSxDQUFDLEtBQUssU0FBUztFQUNqQixNQUFNLGdCQUFnQixLQUFLLFdBQVcsS0FBSyxTQUFTLEtBQUssS0FBQTtFQVV6RCxLQUVHLFdBQVcsT0FBTyxXQUFXLFFBRTlCLGtCQUNDLENBQUMsY0FBYyxZQUFZLENBQUMsY0FBYyxTQUFTLE9BRXBELE1BQU0sTUFBTSxNQUFNLE1BQU0sU0FBUyxPQUFPLFVBQ3hDLE1BQU0sTUFBTSxNQUFNLE1BQU0sU0FBUyxPQUFPLGNBQ3hDLE1BQU0sTUFBTSxNQUFNLE1BQU0sU0FBUyxPQUFPLFVBQ3hDLE1BQU0sTUFBTSxNQUFNLE1BQU0sU0FBUyxPQUFPLGNBRXhDLE1BQU0sV0FBVyxNQUFNLFdBQVcsU0FBUyxPQUFPLEtBQ2xELE1BQU0sV0FBVyxNQUFNLFdBQVcsU0FBUyxPQUFPLEtBQ2xELE1BQU0sV0FBVyxNQUFNLFdBQVcsU0FBUyxPQUFPLEdBRWxELHFCQUFxQjtFQVd2QixJQUFJLFVBQVUsS0FBSyxNQUFNLFVBQVUsZUFBZTtHQUNoRCxJQUFJLFFBQVE7R0FFWixPQUFPLEVBQUUsUUFBUSxLQUFLLFNBQVMsUUFBUTtJQUNyQyxNQUFNLE9BQU8sS0FBSyxTQUFTO0lBRTNCLElBQ0UsUUFDQSxLQUFLLFNBQVMsY0FDZCxLQUFLLFlBQ0wsS0FBSyxTQUFTLE1BQ2QsS0FBSyxTQUFTLEVBQUUsQ0FBQyxTQUFTLGlCQUMxQjtLQUNBLHFCQUFxQjtLQUNyQjtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBRUEsSUFBSSxvQkFDRixTQUFTO0NBR1gsTUFBTSxnQkFBZ0I7Q0FDdEIsTUFBTSxRQUFRLE1BQU0sY0FBYyxNQUFNLElBQUk7Q0FDNUMsTUFBTSxpQkFBaUI7Q0FDdkIsTUFBTSxnQkFBZ0I7Q0FDdEIsS0FBSztDQUNMLE9BQU87QUFDVDs7Ozs7Ozs7OztBQzNGQSxTQUFnQixvQkFBb0IsT0FBTztDQUN6QyxNQUFNLFFBQVEsTUFBTSxRQUFRLGtCQUFrQjtDQUU5QyxJQUFJLFVBQVUsU0FBUyxVQUFVLFNBQVMsVUFBVSxTQUNsRCxNQUFNLElBQUksTUFDUixrQ0FDRSxRQUNBLG1FQUNKO0NBR0YsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7OztBQ0xBLFNBQWdCLFNBQVMsTUFBTSxRQUFRLE9BQU8sTUFBTTtDQUNsRCxNQUFNLGlCQUFpQixvQkFBb0IsS0FBSztDQUNoRCxJQUFJLFNBQVMsTUFBTSxpQkFBaUIsWUFBWSxLQUFLO0NBR3JELElBQUksVUFBVSxPQUFPLFNBQVMsVUFBVSxPQUFPLFNBQzdDLFVBQ0csT0FBTyxPQUFPLFVBQVUsWUFBWSxPQUFPLFFBQVEsS0FDaEQsT0FBTyxRQUNQLE1BQ0gsTUFBTSxRQUFRLHdCQUF3QixRQUNuQyxJQUNBLE9BQU8sU0FBUyxRQUFRLElBQUksS0FDaEM7Q0FHSixJQUFJLE9BQU8sT0FBTyxTQUFTO0NBRTNCLElBQ0UsbUJBQW1CLFNBQ2xCLG1CQUFtQixZQUNoQixVQUFVLE9BQU8sU0FBUyxVQUFVLE9BQU8sVUFBVyxLQUFLLFNBRS9ELE9BQU8sS0FBSyxLQUFLLE9BQU8sQ0FBQyxJQUFJO0NBRy9CLE1BQU0sVUFBVSxNQUFNLGNBQWMsSUFBSTtDQUN4QyxRQUFRLEtBQUssU0FBUyxJQUFJLE9BQU8sT0FBTyxPQUFPLE1BQU0sQ0FBQztDQUN0RCxRQUFRLE1BQU0sSUFBSTtDQUNsQixNQUFNLE9BQU8sTUFBTSxNQUFNLFVBQVU7Q0FDbkMsTUFBTSxRQUFRLE1BQU0sWUFDbEIsTUFBTSxjQUFjLE1BQU0sUUFBUSxRQUFRLENBQUMsR0FDM0MsR0FDRjtDQUNBLEtBQUs7Q0FFTCxPQUFPOztDQUdQLFNBQVMsSUFBSSxNQUFNLE9BQU8sT0FBTztFQUMvQixJQUFJLE9BQ0YsUUFBUSxRQUFRLEtBQUssSUFBSSxPQUFPLElBQUksS0FBSztFQUczQyxRQUFRLFFBQVEsU0FBUyxTQUFTLElBQUksT0FBTyxPQUFPLE9BQU8sTUFBTSxLQUFLO0NBQ3hFO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7O0FDakRBLFNBQWdCLFVBQVUsTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUM5QyxNQUFNLE9BQU8sTUFBTSxNQUFNLFdBQVc7Q0FDcEMsTUFBTSxVQUFVLE1BQU0sTUFBTSxVQUFVO0NBQ3RDLE1BQU0sUUFBUSxNQUFNLGtCQUFrQixNQUFNLElBQUk7Q0FDaEQsUUFBUTtDQUNSLEtBQUs7Q0FDTCxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDREEsSUFBYSxXQUdULFFBQVE7Q0FDTjtDQUNBO0NBQ0E7Q0FFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBRUE7Q0FDQTtDQUNBO0NBRUE7Q0FFQTtDQUNBO0NBQ0E7Q0FFQTtBQUNGLENBQUM7Ozs7Ozs7Ozs7Ozs7O0FDN0JMLFNBQWdCLEtBQUssTUFBTSxHQUFHLE9BQU8sTUFBTTtDQU96QyxRQUxvQixLQUFLLFNBQVMsS0FBSyxTQUFVLEdBQUc7RUFDbEQsT0FBTyxTQUFTLENBQUM7Q0FDbkIsQ0FFNEIsSUFBSSxNQUFNLG9CQUFvQixNQUFNLGNBQUEsQ0FDL0MsS0FBSyxPQUFPLE1BQU0sSUFBSTtBQUN6Qzs7Ozs7Ozs7OztBQ2RBLFNBQWdCLFlBQVksT0FBTztDQUNqQyxNQUFNLFNBQVMsTUFBTSxRQUFRLFVBQVU7Q0FFdkMsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUMvQixNQUFNLElBQUksTUFDUixtQ0FDRSxTQUNBLDhDQUNKO0NBR0YsT0FBTztBQUNUOzs7Ozs7O0FDWEEsT0FBTyxPQUFPOzs7Ozs7OztBQVNkLFNBQWdCLE9BQU8sTUFBTSxHQUFHLE9BQU8sTUFBTTtDQUMzQyxNQUFNLFNBQVMsWUFBWSxLQUFLO0NBQ2hDLE1BQU0sT0FBTyxNQUFNLE1BQU0sUUFBUTtDQUNqQyxNQUFNLFVBQVUsTUFBTSxjQUFjLElBQUk7Q0FDeEMsTUFBTSxTQUFTLFFBQVEsS0FBSyxTQUFTLE1BQU07Q0FFM0MsSUFBSSxVQUFVLFFBQVEsS0FDcEIsTUFBTSxrQkFBa0IsTUFBTTtFQUM1QixPQUFPO0VBQ1A7RUFDQSxHQUFHLFFBQVEsUUFBUTtDQUNyQixDQUFDLENBQ0g7Q0FDQSxNQUFNLGNBQWMsUUFBUSxXQUFXLENBQUM7Q0FDeEMsTUFBTSxPQUFPLFdBQ1gsS0FBSyxPQUFPLFdBQVcsS0FBSyxPQUFPLFNBQVMsQ0FBQyxHQUM3QyxhQUNBLE1BQ0Y7Q0FFQSxJQUFJLEtBQUssUUFDUCxVQUFVLHlCQUF5QixXQUFXLElBQUksUUFBUSxNQUFNLENBQUM7Q0FHbkUsTUFBTSxjQUFjLFFBQVEsV0FBVyxRQUFRLFNBQVMsQ0FBQztDQUN6RCxNQUFNLFFBQVEsV0FBVyxLQUFLLE1BQU0sV0FBVyxDQUFDLEdBQUcsYUFBYSxNQUFNO0NBRXRFLElBQUksTUFBTSxRQUNSLFVBQVUsUUFBUSxNQUFNLEdBQUcsRUFBRSxJQUFJLHlCQUF5QixXQUFXO0NBR3ZFLE1BQU0sUUFBUSxRQUFRLEtBQUssU0FBUyxNQUFNO0NBRTFDLEtBQUs7Q0FFTCxNQUFNLGlDQUFpQztFQUNyQyxPQUFPLE1BQU07RUFDYixRQUFRLEtBQUs7Q0FDZjtDQUNBLE9BQU8sU0FBUyxVQUFVO0FBQzVCOzs7Ozs7O0FBUUEsU0FBUyxXQUFXLEdBQUcsSUFBSSxPQUFPO0NBQ2hDLE9BQU8sTUFBTSxRQUFRLFVBQVU7QUFDakM7Ozs7Ozs7Ozs7Ozs7O0FDeERBLFNBQWdCQyxPQUFLLE1BQU0sR0FBRyxPQUFPLE1BQU07Q0FDekMsT0FBTyxNQUFNLEtBQUssS0FBSyxPQUFPLElBQUk7QUFDcEM7Ozs7Ozs7Ozs7QUNOQSxTQUFnQixvQkFBb0IsT0FBTztDQUN6QyxNQUFNLGFBQWEsTUFBTSxRQUFRLGtCQUFrQjtDQUVuRCxJQUFJLGFBQWEsR0FDZixNQUFNLElBQUksTUFDUiw2Q0FDRSxhQUNBLHNEQUNKO0NBR0YsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7O0FDTkEsU0FBZ0IsY0FBYyxHQUFHLElBQUksT0FBTztDQUMxQyxNQUFNLFNBQ0osVUFBVSxLQUFLLEtBQUssTUFBTSxRQUFRLGFBQWEsTUFBTSxJQUFBLENBQ3JELE9BQU8sb0JBQW9CLEtBQUssQ0FBQztDQUVuQyxPQUFPLE1BQU0sUUFBUSxhQUFhLE1BQU0sTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUN6RDs7Ozs7O0FDR0EsSUFBYSxTQUFTO0NBQ3BCO0NBQ0EsT0FBTztDQUNQLE1BQUE7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxNQUFBO0NBQ0E7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRkEsU0FBZ0IsdUJBQXVCO0NBQ3JDLE9BQU87RUFDTCxPQUFPO0dBQ0wsT0FBTztHQUNQLFdBQVc7R0FDWCxhQUFhO0dBQ2IsVUFBVTtFQUNaO0VBQ0EsTUFBTTtHQUNKLFVBQVU7R0FDVixPQUFPO0dBQ1AsV0FBVztHQUNYLGFBQWE7R0FDYixVQUFVO0VBQ1o7Q0FDRjtBQUNGOzs7OztBQU1BLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLE1BQU0sUUFBUSxNQUFNO0NBQ3BCLEdBQU8sT0FBTyw0QkFBNEI7Q0FDMUMsS0FBSyxNQUNIO0VBQ0UsTUFBTTtFQUNOLE9BQU8sTUFBTSxJQUFJLFNBQVUsR0FBRztHQUM1QixPQUFPLE1BQU0sU0FBUyxPQUFPO0VBQy9CLENBQUM7RUFDRCxVQUFVLENBQUM7Q0FDYixHQUNBLEtBQ0Y7Q0FDQSxLQUFLLEtBQUssVUFBVTtBQUN0Qjs7Ozs7QUFNQSxTQUFTLFVBQVUsT0FBTztDQUN4QixLQUFLLEtBQUssS0FBSztDQUNmLEtBQUssS0FBSyxVQUFVLEtBQUE7QUFDdEI7Ozs7O0FBTUEsU0FBUyxTQUFTLE9BQU87Q0FDdkIsS0FBSyxNQUFNO0VBQUMsTUFBTTtFQUFZLFVBQVUsQ0FBQztDQUFDLEdBQUcsS0FBSztBQUNwRDs7Ozs7QUFNQSxTQUFTLEtBQUssT0FBTztDQUNuQixLQUFLLEtBQUssS0FBSztBQUNqQjs7Ozs7QUFNQSxTQUFTLFVBQVUsT0FBTztDQUN4QixLQUFLLE1BQU07RUFBQyxNQUFNO0VBQWEsVUFBVSxDQUFDO0NBQUMsR0FBRyxLQUFLO0FBQ3JEOzs7OztBQVFBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLElBQUksUUFBUSxLQUFLLE9BQU87Q0FFeEIsSUFBSSxLQUFLLEtBQUssU0FDWixRQUFRLE1BQU0sUUFBUSxjQUFjLE9BQU87Q0FHN0MsTUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUztDQUM1QyxHQUFPLEtBQUssU0FBUyxZQUFZO0NBQ2pDLEtBQUssUUFBUTtDQUNiLEtBQUssS0FBSyxLQUFLO0FBQ2pCOzs7Ozs7QUFPQSxTQUFTLFFBQVEsSUFBSSxJQUFJO0NBRXZCLE9BQU8sT0FBTyxNQUFNLEtBQUs7QUFDM0I7Ozs7Ozs7Ozs7QUFXQSxTQUFnQixtQkFBbUIsU0FBUztDQUMxQyxNQUFNLFdBQVcsV0FBVyxDQUFDO0NBQzdCLE1BQU0sVUFBVSxTQUFTO0NBQ3pCLE1BQU0sa0JBQWtCLFNBQVM7Q0FDakMsTUFBTSxlQUFlLFNBQVM7Q0FDOUIsTUFBTSxTQUFTLFVBQVUsTUFBTTtDQUUvQixPQUFPO0VBQ0wsUUFBUTtHQUNOO0lBQUMsV0FBVztJQUFNLGFBQWE7R0FBVztHQUMxQztJQUFDLFdBQVc7SUFBTSxhQUFhO0dBQVc7R0FHMUM7SUFBQyxTQUFTO0lBQU0sV0FBVztJQUFLLE9BQU87R0FBUztHQUVoRDtJQUFDLFdBQVc7SUFBSyxhQUFhO0dBQVc7R0FHekM7SUFBQyxTQUFTO0lBQU0sV0FBVztJQUFLLE9BQU87R0FBRztHQU0xQztJQUFDLFNBQVM7SUFBTSxXQUFXO0lBQUssT0FBTztHQUFPO0VBQ2hEO0VBQ0EsVUFBVTtHQUNSLFlBQVk7R0FDWixPQUFPO0dBQ1AsV0FBVztHQUNYLFVBQVU7RUFDWjtDQUNGOzs7OztDQU1BLFNBQVMsWUFBWSxNQUFNLEdBQUcsT0FBTyxNQUFNO0VBQ3pDLE9BQU8sY0FBYyxrQkFBa0IsTUFBTSxPQUFPLElBQUksR0FBRyxLQUFLLEtBQUs7Q0FDdkU7Ozs7Ozs7OztDQVVBLFNBQVMsZUFBZSxNQUFNLEdBQUcsT0FBTyxNQUFNO0VBRTVDLE1BQU0sUUFBUSxjQUFjLENBRGhCLHFCQUFxQixNQUFNLE9BQU8sSUFDZixDQUFDLENBQUM7RUFFakMsT0FBTyxNQUFNLE1BQU0sR0FBRyxNQUFNLFFBQVEsSUFBSSxDQUFDO0NBQzNDOzs7OztDQU1BLFNBQVMsZ0JBQWdCLE1BQU0sR0FBRyxPQUFPLE1BQU07RUFDN0MsTUFBTSxPQUFPLE1BQU0sTUFBTSxXQUFXO0VBQ3BDLE1BQU0sVUFBVSxNQUFNLE1BQU0sVUFBVTtFQUN0QyxNQUFNLFFBQVEsTUFBTSxrQkFBa0IsTUFBTTtHQUMxQyxHQUFHO0dBQ0gsUUFBUTtHQUNSLE9BQU87RUFDVCxDQUFDO0VBQ0QsUUFBUTtFQUNSLEtBQUs7RUFDTCxPQUFPO0NBQ1Q7Ozs7O0NBTUEsU0FBUyxjQUFjLFFBQVEsT0FBTztFQUNwQyxPQUFPLGNBQWMsUUFBUTtHQUMzQjtHQUVBO0dBRUE7R0FFQTtFQUNGLENBQUM7Q0FDSDs7Ozs7O0NBT0EsU0FBUyxrQkFBa0IsTUFBTSxPQUFPLE1BQU07RUFDNUMsTUFBTSxXQUFXLEtBQUs7RUFDdEIsSUFBSSxRQUFROztFQUVaLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLE1BQU0sVUFBVSxNQUFNLE1BQU0sT0FBTztFQUVuQyxPQUFPLEVBQUUsUUFBUSxTQUFTLFFBQ3hCLE9BQU8sU0FBUyxxQkFBcUIsU0FBUyxRQUFRLE9BQU8sSUFBSTtFQUduRSxRQUFRO0VBRVIsT0FBTztDQUNUOzs7Ozs7Q0FPQSxTQUFTLHFCQUFxQixNQUFNLE9BQU8sTUFBTTtFQUMvQyxNQUFNLFdBQVcsS0FBSztFQUN0QixJQUFJLFFBQVE7O0VBRVosTUFBTSxTQUFTLENBQUM7RUFDaEIsTUFBTSxVQUFVLE1BQU0sTUFBTSxVQUFVO0VBRXRDLE9BQU8sRUFBRSxRQUFRLFNBQVMsUUFJeEIsT0FBTyxTQUFTLGdCQUFnQixTQUFTLFFBQVEsTUFBTSxPQUFPLElBQUk7RUFHcEUsUUFBUTtFQUVSLE9BQU87Q0FDVDs7Ozs7Q0FNQSxTQUFTLG9CQUFvQixNQUFNLFFBQVEsT0FBTztFQUNoRCxJQUFJLFFBQVFDLE9BQWdCLFdBQVcsTUFBTSxRQUFRLEtBQUs7RUFFMUQsSUFBSSxNQUFNLE1BQU0sU0FBUyxXQUFXLEdBQ2xDLFFBQVEsTUFBTSxRQUFRLE9BQU8sTUFBTTtFQUdyQyxPQUFPO0NBQ1Q7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZSQSxTQUFnQiw4QkFBOEI7Q0FDNUMsT0FBTyxFQUNMLE1BQU07RUFDSiwyQkFBMkI7RUFDM0IsNkJBQTZCO0VBQzdCLFdBQVc7Q0FDYixFQUNGO0FBQ0Y7Ozs7Ozs7O0FBU0EsU0FBZ0IsNEJBQTRCO0NBQzFDLE9BQU87RUFDTCxRQUFRLENBQUM7R0FBQyxTQUFTO0dBQU0sV0FBVztHQUFLLE9BQU87RUFBTyxDQUFDO0VBQ3hELFVBQVUsRUFBQyxVQUFVLHlCQUF3QjtDQUMvQztBQUNGOzs7OztBQU1BLFNBQVMsVUFBVSxPQUFPO0NBRXhCLE1BQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxNQUFNLFNBQVM7Q0FDNUMsR0FBTyxLQUFLLFNBQVMsVUFBVTtDQUMvQixLQUFLLFVBQVUsTUFBTSxTQUFTO0FBQ2hDOzs7OztBQU1BLFNBQVMsOEJBQThCLE9BQU87Q0FDNUMsTUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUztDQUU5QyxJQUNFLFVBQ0EsT0FBTyxTQUFTLGNBQ2hCLE9BQU8sT0FBTyxZQUFZLFdBQzFCO0VBQ0EsTUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUztFQUM1QyxHQUFPLEtBQUssU0FBUyxXQUFXO0VBQ2hDLE1BQU0sT0FBTyxLQUFLLFNBQVM7RUFFM0IsSUFBSSxRQUFRLEtBQUssU0FBUyxRQUFRO0dBQ2hDLE1BQU0sV0FBVyxPQUFPO0dBQ3hCLElBQUksUUFBUTs7R0FFWixJQUFJO0dBRUosT0FBTyxFQUFFLFFBQVEsU0FBUyxRQUFRO0lBQ2hDLE1BQU0sVUFBVSxTQUFTO0lBQ3pCLElBQUksUUFBUSxTQUFTLGFBQWE7S0FDaEMsa0JBQWtCO0tBQ2xCO0lBQ0Y7R0FDRjtHQUVBLElBQUksb0JBQW9CLE1BQU07SUFFNUIsS0FBSyxRQUFRLEtBQUssTUFBTSxNQUFNLENBQUM7SUFFL0IsSUFBSSxLQUFLLE1BQU0sV0FBVyxHQUN4QixLQUFLLFNBQVMsTUFBTTtTQUNmLElBQ0wsS0FBSyxZQUNMLEtBQUssWUFDTCxPQUFPLEtBQUssU0FBUyxNQUFNLFdBQVcsVUFDdEM7S0FDQSxLQUFLLFNBQVMsTUFBTTtLQUNwQixLQUFLLFNBQVMsTUFBTTtLQUNwQixLQUFLLFNBQVMsUUFBUSxPQUFPLE9BQU8sQ0FBQyxHQUFHLEtBQUssU0FBUyxLQUFLO0lBQzdEO0dBQ0Y7RUFDRjtDQUNGO0NBRUEsS0FBSyxLQUFLLEtBQUs7QUFDakI7Ozs7O0FBTUEsU0FBUyx5QkFBeUIsTUFBTSxRQUFRLE9BQU8sTUFBTTtDQUMzRCxNQUFNLE9BQU8sS0FBSyxTQUFTO0NBQzNCLE1BQU0sWUFDSixPQUFPLEtBQUssWUFBWSxhQUFhLFFBQVEsS0FBSyxTQUFTO0NBQzdELE1BQU0sV0FBVyxPQUFPLEtBQUssVUFBVSxNQUFNLE9BQU87Q0FDcEQsTUFBTSxVQUFVLE1BQU0sY0FBYyxJQUFJO0NBRXhDLElBQUksV0FDRixRQUFRLEtBQUssUUFBUTtDQUd2QixJQUFJLFFBQVFDLE9BQWdCLFNBQVMsTUFBTSxRQUFRLE9BQU87RUFDeEQsR0FBRztFQUNILEdBQUcsUUFBUSxRQUFRO0NBQ3JCLENBQUM7Q0FFRCxJQUFJLFdBQ0YsUUFBUSxNQUFNLFFBQVEsbUNBQW1DLEtBQUs7Q0FHaEUsT0FBTzs7Ozs7Q0FNUCxTQUFTLE1BQU0sSUFBSTtFQUNqQixPQUFPLEtBQUs7Q0FDZDtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0FDNUdBLFNBQWdCLGtCQUFrQjtDQUNoQyxPQUFPO0VBQ0wsK0JBQStCO0VBQy9CLHdCQUF3QjtFQUN4Qiw2QkFBNkI7RUFDN0IscUJBQXFCO0VBQ3JCLDRCQUE0QjtDQUM5QjtBQUNGOzs7Ozs7Ozs7OztBQVlBLFNBQWdCLGNBQWMsU0FBUztDQUNyQyxPQUFPLEVBQ0wsWUFBWTtFQUNWLDZCQUE2QjtFQUM3QixzQkFBc0IsT0FBTztFQUM3QiwyQkFBMkI7RUFDM0IsbUJBQW1CLE9BQU87RUFDMUIsMEJBQTBCO0NBQzVCLEVBQ0Y7QUFDRjs7Ozs7O0FDaERBLElBQU0sWUFBWTtDQUFDLFVBQVU7Q0FBbUIsU0FBUztBQUFJO0FBQzdELElBQU0sU0FBUztDQUFDLFVBQVU7Q0FBZ0IsU0FBUztBQUFJO0FBQ3ZELElBQU0sT0FBTztDQUFDLFVBQVU7Q0FBYyxTQUFTO0FBQUk7QUFDbkQsSUFBTSxRQUFRO0NBQUMsVUFBVTtDQUFlLFNBQVM7QUFBSTtBQUNyRCxJQUFNLHNCQUFzQjtDQUMxQixVQUFVO0NBQ1YsU0FBUztBQUNYO0FBRUEsSUFBTSxjQUFjO0NBQ2xCLE1BQU07Q0FDTixVQUFVO0NBQ1YsVUFBVTtBQUNaO0FBRUEsSUFBTSxtQkFBbUI7Q0FDdkIsTUFBTTtDQUNOLFVBQVU7Q0FDVixVQUFVO0FBQ1o7QUFFQSxJQUFNLGdCQUFnQjtDQUNwQixNQUFNO0NBQ04sVUFBVTtDQUNWLFVBQVU7QUFDWjs7QUFHQSxJQUFNLE9BQU8sQ0FBQzs7Ozs7Ozs7O0FBVWQsU0FBZ0IscUJBQXFCO0NBQ25DLE9BQU8sRUFBQyxLQUFJO0FBQ2Q7O0FBR0EsSUFBSSxPQUFPLE1BQU07QUFHakIsT0FBTyxPQUFPLE1BQU0sZ0JBQWdCO0NBQ2xDLEtBQUssUUFBUTtDQUNiO0NBQ0EsSUFBSSxTQUFTLE1BQU0sT0FBTyxPQUFPLE1BQU07TUFDbEMsSUFBSSxTQUFTLE1BQU0sbUJBQW1CLE9BQU8sTUFBTTtBQUMxRDtBQUVBLEtBQUssTUFBTSxZQUFZO0FBQ3ZCLEtBQUssTUFBTSxRQUFRO0FBQ25CLEtBQUssTUFBTSxPQUFPO0FBQ2xCLEtBQUssTUFBTSxjQUFjO0FBQ3pCLEtBQUssTUFBTSxjQUFjLENBQUMsZUFBZSxnQkFBZ0I7QUFDekQsS0FBSyxNQUFNLGNBQWMsQ0FBQyxlQUFlLGdCQUFnQjtBQUN6RCxLQUFLLE1BQU0sY0FBYyxDQUFDLGVBQWUsV0FBVztBQUNwRCxLQUFLLE1BQU0sY0FBYyxDQUFDLGVBQWUsV0FBVzs7Ozs7Ozs7Ozs7O0FBbUJwRCxTQUFTLHNCQUFzQixTQUFTLElBQUksS0FBSztDQUMvQyxNQUFNLE9BQU87O0NBRWIsSUFBSTs7Q0FFSixJQUFJO0NBRUosT0FBTzs7Ozs7Ozs7Ozs7Q0FZUCxTQUFTLE1BQU0sTUFBTTtFQUNuQixJQUNFLENBQUMsU0FBUyxJQUFJLEtBQ2QsQ0FBQyxjQUFjLEtBQUssTUFBTSxLQUFLLFFBQVEsS0FDdkMsbUJBQW1CLEtBQUssTUFBTSxHQUU5QixPQUFPLElBQUksSUFBSTtFQUdqQixRQUFRLE1BQU0saUJBQWlCO0VBQy9CLFFBQVEsTUFBTSxzQkFBc0I7RUFDcEMsT0FBTyxNQUFNLElBQUk7Q0FDbkI7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxNQUFNLE1BQU07RUFDbkIsSUFBSSxTQUFTLElBQUksR0FBRztHQUNsQixRQUFRLFFBQVEsSUFBSTtHQUNwQixPQUFPO0VBQ1Q7RUFFQSxJQUFJLFNBQVMsTUFBTSxRQUFRO0dBQ3pCLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLE9BQU87RUFDVDtFQUVBLE9BQU8sSUFBSSxJQUFJO0NBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsU0FBUyxZQUFZLE1BQU07RUFFekIsSUFBSSxTQUFTLE1BQU0sS0FDakIsT0FBTyxRQUFRLE1BQ2IscUJBQ0Esa0JBQ0EsY0FDRixDQUFDLENBQUMsSUFBSTtFQUlSLElBQ0UsU0FBUyxNQUFNLFFBQ2YsU0FBUyxNQUFNLGNBQ2Ysa0JBQWtCLElBQUksR0FDdEI7R0FDQSxPQUFPO0dBQ1AsUUFBUSxRQUFRLElBQUk7R0FDcEIsT0FBTztFQUNUO0VBUUEsT0FBTyxpQkFBaUIsSUFBSTtDQUM5Qjs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLGVBQWUsTUFBTTtFQUM1QixRQUFRLFFBQVEsSUFBSTtFQUNwQixNQUFNO0VBQ04sT0FBTztDQUNUOzs7Ozs7Ozs7OztDQVlBLFNBQVMsaUJBQWlCLE1BQU07RUFHOUIsSUFBSSxRQUFRLE9BQU8sV0FBVyxLQUFLLFFBQVEsR0FBRztHQUM1QyxRQUFRLEtBQUssc0JBQXNCO0dBQ25DLFFBQVEsS0FBSyxpQkFBaUI7R0FDOUIsT0FBTyxHQUFHLElBQUk7RUFDaEI7RUFFQSxPQUFPLElBQUksSUFBSTtDQUNqQjtBQUNGOzs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLG9CQUFvQixTQUFTLElBQUksS0FBSztDQUM3QyxNQUFNLE9BQU87Q0FFYixPQUFPOzs7Ozs7Ozs7OztDQVlQLFNBQVMsU0FBUyxNQUFNO0VBQ3RCLElBQ0csU0FBUyxNQUFNLGNBQWMsU0FBUyxNQUFNLGNBQzdDLENBQUMsWUFBWSxLQUFLLE1BQU0sS0FBSyxRQUFRLEtBQ3JDLG1CQUFtQixLQUFLLE1BQU0sR0FFOUIsT0FBTyxJQUFJLElBQUk7RUFHakIsUUFBUSxNQUFNLGlCQUFpQjtFQUMvQixRQUFRLE1BQU0sb0JBQW9CO0VBR2xDLE9BQU8sUUFBUSxNQUNiLFdBQ0EsUUFBUSxRQUFRLFFBQVEsUUFBUSxRQUFRLE1BQU0sUUFBUSxHQUFHLEdBQUcsR0FDNUQsR0FDRixDQUFDLENBQUMsSUFBSTtDQUNSOzs7Ozs7Ozs7OztDQVlBLFNBQVMsU0FBUyxNQUFNO0VBQ3RCLFFBQVEsS0FBSyxvQkFBb0I7RUFDakMsUUFBUSxLQUFLLGlCQUFpQjtFQUM5QixPQUFPLEdBQUcsSUFBSTtDQUNoQjtBQUNGOzs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLHlCQUF5QixTQUFTLElBQUksS0FBSztDQUNsRCxNQUFNLE9BQU87Q0FDYixJQUFJLFNBQVM7Q0FDYixJQUFJLE9BQU87Q0FFWCxPQUFPOzs7Ozs7Ozs7OztDQVlQLFNBQVMsY0FBYyxNQUFNO0VBQzNCLEtBQ0csU0FBUyxNQUFNLGNBQWMsU0FBUyxNQUFNLGVBQzdDLGlCQUFpQixLQUFLLE1BQU0sS0FBSyxRQUFRLEtBQ3pDLENBQUMsbUJBQW1CLEtBQUssTUFBTSxHQUMvQjtHQUNBLFFBQVEsTUFBTSxpQkFBaUI7R0FDL0IsUUFBUSxNQUFNLHFCQUFxQjtHQUNuQyxVQUFVLE9BQU8sY0FBYyxJQUFJO0dBQ25DLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLE9BQU87RUFDVDtFQUVBLE9BQU8sSUFBSSxJQUFJO0NBQ2pCOzs7Ozs7Ozs7OztDQVlBLFNBQVMscUJBQXFCLE1BQU07RUFFbEMsSUFBSSxXQUFXLElBQUksS0FBSyxPQUFPLFNBQVMsR0FBRztHQUV6QyxVQUFVLE9BQU8sY0FBYyxJQUFJO0dBQ25DLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLE9BQU87RUFDVDtFQUVBLElBQUksU0FBUyxNQUFNLE9BQU87R0FDeEIsTUFBTSxXQUFXLE9BQU8sWUFBWTtHQUVwQyxJQUFJLGFBQWEsVUFBVSxhQUFhLFNBQVM7SUFDL0MsUUFBUSxRQUFRLElBQUk7SUFDcEIsT0FBTztHQUNUO0VBQ0Y7RUFFQSxPQUFPLElBQUksSUFBSTtDQUNqQjs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLHNCQUFzQixNQUFNO0VBQ25DLElBQUksU0FBUyxNQUFNLE9BQU87R0FDeEIsUUFBUSxRQUFRLElBQUk7R0FFcEIsSUFBSSxNQUNGLE9BQU87R0FHVCxPQUFPO0dBQ1AsT0FBTztFQUNUO0VBRUEsT0FBTyxJQUFJLElBQUk7Q0FDakI7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxjQUFjLE1BQU07RUFHM0IsT0FBTyxTQUFTLE1BQU0sT0FDcEIsYUFBYSxJQUFJLEtBQ2pCLDBCQUEwQixJQUFJLEtBQzlCLGtCQUFrQixJQUFJLEtBQ3RCLG1CQUFtQixJQUFJLElBQ3JCLElBQUksSUFBSSxJQUNSLFFBQVEsUUFBUSxRQUFRLFFBQVEsUUFBUSxNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJO0NBQzdFOzs7Ozs7Ozs7OztDQVlBLFNBQVMsY0FBYyxNQUFNO0VBQzNCLFFBQVEsS0FBSyxxQkFBcUI7RUFDbEMsUUFBUSxLQUFLLGlCQUFpQjtFQUM5QixPQUFPLEdBQUcsSUFBSTtDQUNoQjtBQUNGOzs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLGtCQUFrQixTQUFTLElBQUksS0FBSztDQUMzQyxJQUFJLE9BQU87Q0FFWCxPQUFPOzs7Ozs7Ozs7OztDQVlQLFNBQVMsZ0JBQWdCLE1BQU07RUFDN0IsS0FBSyxTQUFTLE1BQU0sY0FBYyxTQUFTLE1BQU0sZUFBZSxPQUFPLEdBQUc7R0FDeEU7R0FDQSxRQUFRLFFBQVEsSUFBSTtHQUNwQixPQUFPO0VBQ1Q7RUFFQSxJQUFJLFNBQVMsTUFBTSxPQUFPLFNBQVMsR0FBRztHQUNwQyxRQUFRLFFBQVEsSUFBSTtHQUNwQixPQUFPO0VBQ1Q7RUFFQSxPQUFPLElBQUksSUFBSTtDQUNqQjs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLGVBQWUsTUFBTTtFQUU1QixPQUFPLFNBQVMsTUFBTSxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSTtDQUNqRDtBQUNGOzs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLGVBQWUsU0FBUyxJQUFJLEtBQUs7O0NBRXhDLElBQUk7O0NBRUosSUFBSTs7Q0FFSixJQUFJO0NBRUosT0FBTzs7Ozs7Ozs7Ozs7Q0FZUCxTQUFTLGFBQWEsTUFBTTtFQUkxQixJQUFJLFNBQVMsTUFBTSxPQUFPLFNBQVMsTUFBTSxZQUN2QyxPQUFPLFFBQVEsTUFBTSxPQUFPLGFBQWEsbUJBQW1CLENBQUMsQ0FBQyxJQUFJO0VBU3BFLElBQ0UsU0FBUyxNQUFNLE9BQ2YsMEJBQTBCLElBQUksS0FDOUIsa0JBQWtCLElBQUksS0FDckIsU0FBUyxNQUFNLFFBQVEsbUJBQW1CLElBQUksR0FFL0MsT0FBTyxZQUFZLElBQUk7RUFHekIsT0FBTztFQUNQLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLG9CQUFvQixNQUFNO0VBRWpDLElBQUksU0FBUyxNQUFNLFlBQ2pCLDBCQUEwQjtPQUl2QjtHQUNILDhCQUE4QjtHQUM5QiwwQkFBMEIsS0FBQTtFQUM1QjtFQUVBLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7OztDQVdBLFNBQVMsWUFBWSxNQUFNO0VBR3pCLElBQUksK0JBQStCLDJCQUEyQixDQUFDLE1BQzdELE9BQU8sSUFBSSxJQUFJO0VBR2pCLE9BQU8sR0FBRyxJQUFJO0NBQ2hCO0FBQ0Y7Ozs7Ozs7Ozs7OztBQWFBLFNBQVMsYUFBYSxTQUFTLElBQUk7Q0FDakMsSUFBSSxXQUFXO0NBQ2YsSUFBSSxZQUFZO0NBRWhCLE9BQU87Ozs7Ozs7Ozs7O0NBWVAsU0FBUyxXQUFXLE1BQU07RUFDeEIsSUFBSSxTQUFTLE1BQU0saUJBQWlCO0dBQ2xDO0dBQ0EsUUFBUSxRQUFRLElBQUk7R0FDcEIsT0FBTztFQUNUO0VBS0EsSUFBSSxTQUFTLE1BQU0sb0JBQW9CLFlBQVksVUFDakQsT0FBTyxrQkFBa0IsSUFBSTtFQU0vQixJQUNFLFNBQVMsTUFBTSxtQkFDZixTQUFTLE1BQU0saUJBQ2YsU0FBUyxNQUFNLGFBQ2YsU0FBUyxNQUFNLGNBQ2YsU0FBUyxNQUFNLG9CQUNmLFNBQVMsTUFBTSxZQUNmLFNBQVMsTUFBTSxTQUNmLFNBQVMsTUFBTSxPQUNmLFNBQVMsTUFBTSxTQUNmLFNBQVMsTUFBTSxhQUNmLFNBQVMsTUFBTSxZQUNmLFNBQVMsTUFBTSxnQkFDZixTQUFTLE1BQU0sc0JBQ2YsU0FBUyxNQUFNLGNBQ2YsU0FBUyxNQUFNLE9BRWYsT0FBTyxRQUFRLE1BQU0sT0FBTyxJQUFJLGlCQUFpQixDQUFDLENBQUMsSUFBSTtFQUd6RCxJQUNFLFNBQVMsTUFBTSxPQUNmLDBCQUEwQixJQUFJLEtBQzlCLGtCQUFrQixJQUFJLEdBRXRCLE9BQU8sR0FBRyxJQUFJO0VBR2hCLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLGtCQUFrQixNQUFNO0VBRS9CLElBQUksU0FBUyxNQUFNLGtCQUNqQjtFQUdGLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLE9BQU87Q0FDVDtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsY0FBYyxTQUFTLElBQUksS0FBSztDQUN2QyxPQUFPOzs7Ozs7Ozs7OztDQVlQLFNBQVMsTUFBTSxNQUFNO0VBRW5CLElBQ0UsU0FBUyxNQUFNLG1CQUNmLFNBQVMsTUFBTSxpQkFDZixTQUFTLE1BQU0sY0FDZixTQUFTLE1BQU0sb0JBQ2YsU0FBUyxNQUFNLFlBQ2YsU0FBUyxNQUFNLFNBQ2YsU0FBUyxNQUFNLE9BQ2YsU0FBUyxNQUFNLFNBQ2YsU0FBUyxNQUFNLGFBQ2YsU0FBUyxNQUFNLGdCQUNmLFNBQVMsTUFBTSxjQUNmLFNBQVMsTUFBTSxPQUNmO0dBQ0EsUUFBUSxRQUFRLElBQUk7R0FDcEIsT0FBTztFQUNUO0VBS0EsSUFBSSxTQUFTLE1BQU0sV0FBVztHQUM1QixRQUFRLFFBQVEsSUFBSTtHQUNwQixPQUFPO0VBQ1Q7RUFLQSxJQUFJLFNBQVMsTUFBTSxvQkFBb0I7R0FDckMsUUFBUSxRQUFRLElBQUk7R0FDcEIsT0FBTztFQUNUO0VBRUEsSUFFRSxTQUFTLE1BQU0sWUFFZixTQUFTLE1BQU0sT0FDZiwwQkFBMEIsSUFBSSxLQUM5QixrQkFBa0IsSUFBSSxHQUV0QixPQUFPLEdBQUcsSUFBSTtFQUdoQixPQUFPLElBQUksSUFBSTtDQUNqQjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxTQUFTLGtCQUFrQixNQUFNO0VBRy9CLElBQ0UsU0FBUyxNQUFNLE9BQ2YsU0FBUyxNQUFNLG1CQUNmLFNBQVMsTUFBTSxxQkFDZiwwQkFBMEIsSUFBSSxLQUM5QixrQkFBa0IsSUFBSSxHQUV0QixPQUFPLEdBQUcsSUFBSTtFQUdoQixPQUFPLE1BQU0sSUFBSTtDQUNuQjs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLDZCQUE2QixNQUFNO0VBRTFDLE9BQU8sV0FBVyxJQUFJLElBQUksOEJBQThCLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDMUU7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyw4QkFBOEIsTUFBTTtFQUUzQyxJQUFJLFNBQVMsTUFBTSxXQUFXO0dBQzVCLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLE9BQU87RUFDVDtFQUVBLElBQUksV0FBVyxJQUFJLEdBQUc7R0FDcEIsUUFBUSxRQUFRLElBQUk7R0FDcEIsT0FBTztFQUNUO0VBR0EsT0FBTyxJQUFJLElBQUk7Q0FDakI7QUFDRjs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLDRCQUE0QixTQUFTLElBQUksS0FBSztDQUNyRCxPQUFPOzs7Ozs7Ozs7OztDQVlQLFNBQVMsTUFBTSxNQUFNO0VBRW5CLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLE1BQU0sTUFBTTtFQUVuQixPQUFPLGtCQUFrQixJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJO0NBQ3REO0FBQ0Y7Ozs7Ozs7QUFRQSxTQUFTLFlBQVksTUFBTTtDQUN6QixPQUNFLFNBQVMsTUFBTSxPQUNmLFNBQVMsTUFBTSxtQkFDZixTQUFTLE1BQU0sWUFDZixTQUFTLE1BQU0sY0FDZixTQUFTLE1BQU0scUJBQ2YsU0FBUyxNQUFNLHNCQUNmLFNBQVMsTUFBTSxTQUNmLDBCQUEwQixJQUFJO0FBRWxDOzs7Ozs7O0FBUUEsU0FBUyxpQkFBaUIsTUFBTTtDQUM5QixPQUFPLENBQUMsV0FBVyxJQUFJO0FBQ3pCOzs7OztBQU1BLFNBQVMsY0FBYyxNQUFNO0NBSzNCLE9BQU8sRUFBRSxTQUFTLE1BQU0sU0FBUyxTQUFTLElBQUk7QUFDaEQ7Ozs7O0FBTUEsU0FBUyxTQUFTLE1BQU07Q0FDdEIsT0FDRSxTQUFTLE1BQU0sWUFDZixTQUFTLE1BQU0sUUFDZixTQUFTLE1BQU0sT0FDZixTQUFTLE1BQU0sY0FDZixrQkFBa0IsSUFBSTtBQUUxQjs7Ozs7QUFNQSxTQUFTLG1CQUFtQixRQUFRO0NBQ2xDLElBQUksUUFBUSxPQUFPO0NBQ25CLElBQUksU0FBUztDQUViLE9BQU8sU0FBUztFQUNkLE1BQU0sUUFBUSxPQUFPLE1BQU0sQ0FBQztFQUU1QixLQUNHLE1BQU0sU0FBUyxlQUFlLE1BQU0sU0FBUyxpQkFDOUMsQ0FBQyxNQUFNLFdBQ1A7R0FDQSxTQUFTO0dBQ1Q7RUFDRjtFQUlBLElBQUksTUFBTSwrQkFBK0I7R0FDdkMsU0FBUztHQUNUO0VBQ0Y7Q0FDRjtDQUVBLElBQUksT0FBTyxTQUFTLEtBQUssQ0FBQyxRQUd4QixPQUFPLE9BQU8sU0FBUyxFQUFFLENBQUMsRUFBRSxDQUFDLGdDQUFnQztDQUcvRCxPQUFPO0FBQ1Q7Ozs7OztBQzM4QkEsSUFBTSxTQUFTO0NBQUMsVUFBVTtDQUFnQixTQUFTO0FBQUk7Ozs7Ozs7O0FBZXZELFNBQWdCLGNBQWM7O0NBRTVCLE9BQU87RUFDTCxVQUFVLEdBQ1AsTUFBTSxvQkFBb0I7R0FDekIsTUFBTTtHQUNOLFVBQVU7R0FDVixjQUFjLEVBQUMsVUFBVSwrQkFBOEI7R0FDdkQsTUFBTTtFQUNSLEVBQ0Y7RUFDQSxNQUFNO0lBQ0gsTUFBTSxvQkFBb0I7SUFDekIsTUFBTTtJQUNOLFVBQVU7R0FDWjtJQUNDLE1BQU0scUJBQXFCO0lBQzFCLE1BQU07SUFDTixLQUFLO0lBQ0wsVUFBVTtJQUNWLFdBQVc7R0FDYjtFQUNGO0NBQ0Y7QUFDRjs7Ozs7QUFPQSxTQUFTLGlDQUFpQyxTQUFTLE1BQUksS0FBSztDQUMxRCxNQUFNLE9BQU87Q0FDYixJQUFJLFFBQVEsS0FBSyxPQUFPO0NBQ3hCLE1BQU0sVUFBVSxLQUFLLE9BQU8saUJBQWlCLEtBQUssT0FBTyxlQUFlLENBQUM7O0NBRXpFLElBQUk7Q0FHSixPQUFPLFNBQVM7RUFDZCxNQUFNLFFBQVEsS0FBSyxPQUFPLE1BQU0sQ0FBQztFQUVqQyxJQUFJLE1BQU0sU0FBUyxNQUFNLFlBQVk7R0FDbkMsYUFBYTtHQUNiO0VBQ0Y7RUFHQSxJQUNFLE1BQU0sU0FBUyxxQkFDZixNQUFNLFNBQVMsTUFBTSxhQUNyQixNQUFNLFNBQVMsTUFBTSxTQUNyQixNQUFNLFNBQVMsTUFBTSxTQUNyQixNQUFNLFNBQVMsTUFBTSxNQUVyQjtDQUVKO0NBRUEsT0FBTzs7OztDQUtQLFNBQVMsTUFBTSxNQUFNO0VBQ25CLEdBQU8sU0FBUyxNQUFNLG9CQUFvQixjQUFjO0VBRXhELElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxXQUM3QixPQUFPLElBQUksSUFBSTtFQUdqQixNQUFNLEtBQUssb0JBQ1QsS0FBSyxlQUFlO0dBQUMsT0FBTyxXQUFXO0dBQUssS0FBSyxLQUFLLElBQUk7RUFBQyxDQUFDLENBQzlEO0VBRUEsSUFBSSxHQUFHLFlBQVksQ0FBQyxNQUFNLE1BQU0sU0FBUyxDQUFDLFFBQVEsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQ3BFLE9BQU8sSUFBSSxJQUFJO0VBR2pCLFFBQVEsTUFBTSw0QkFBNEI7RUFDMUMsUUFBUSxRQUFRLElBQUk7RUFDcEIsUUFBUSxLQUFLLDRCQUE0QjtFQUN6QyxPQUFPQyxLQUFHLElBQUk7Q0FDaEI7QUFDRjs7QUFJQSxTQUFTLGtDQUFrQyxRQUFRLFNBQVM7Q0FDMUQsSUFBSSxRQUFRLE9BQU87O0NBRW5CLElBQUk7Q0FHSixPQUFPLFNBQ0wsSUFDRSxPQUFPLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxNQUFNLGNBQ2hDLE9BQU8sTUFBTSxDQUFDLE9BQU8sU0FDckI7RUFDQSxhQUFhLE9BQU8sTUFBTSxDQUFDO0VBQzNCO0NBQ0Y7Q0FHRixHQUFPLFlBQVksa0NBQWtDO0NBR3JELE9BQU8sUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLE9BQU8sTUFBTTtDQUNsQyxPQUFPLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxPQUFPOztDQUk1QixNQUFNLE9BQU87RUFDWCxNQUFNO0VBQ04sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLEtBQUs7RUFDbkQsS0FBSyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sT0FBTyxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRztDQUN6RDs7Q0FHQSxNQUFNLFNBQVM7RUFDYixNQUFNO0VBQ04sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUc7RUFDakQsS0FBSyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUc7Q0FDakQ7Q0FFQSxPQUFPLElBQUk7Q0FDWCxPQUFPLElBQUk7Q0FDWCxPQUFPLElBQUk7O0NBRVgsTUFBTSxTQUFTO0VBQ2IsTUFBTTtFQUNOLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxPQUFPLEdBQUc7RUFDbkMsS0FBSyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sT0FBTyxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsS0FBSztDQUMzRDs7Q0FFQSxNQUFNLFFBQVE7RUFDWixNQUFNLE1BQU07RUFDWixhQUFhO0VBQ2IsT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sS0FBSztFQUNyQyxLQUFLLE9BQU8sT0FBTyxDQUFDLEdBQUcsT0FBTyxHQUFHO0NBQ25DOztDQUdBLE1BQU0sY0FBYztFQUVsQixPQUFPLFFBQVE7RUFDZixPQUFPLFFBQVE7RUFDZjtHQUFDO0dBQVM7R0FBTTtFQUFPO0VBRXZCLE9BQU8sUUFBUTtFQUNmLE9BQU8sUUFBUTtFQUVmO0dBQUM7R0FBUztHQUFRO0VBQU87RUFDekI7R0FBQztHQUFRO0dBQVE7RUFBTztFQUV4QjtHQUFDO0dBQVM7R0FBUTtFQUFPO0VBQ3pCO0dBQUM7R0FBUztHQUFPO0VBQU87RUFDeEI7R0FBQztHQUFRO0dBQU87RUFBTztFQUN2QjtHQUFDO0dBQVE7R0FBUTtFQUFPO0VBRXhCLE9BQU8sT0FBTyxTQUFTO0VBQ3ZCLE9BQU8sT0FBTyxTQUFTO0VBQ3ZCO0dBQUM7R0FBUTtHQUFNO0VBQU87Q0FDeEI7Q0FFQSxPQUFPLE9BQU8sT0FBTyxPQUFPLFNBQVMsUUFBUSxHQUFHLEdBQUcsV0FBVztDQUU5RCxPQUFPO0FBQ1Q7Ozs7O0FBTUEsU0FBUyx3QkFBd0IsU0FBUyxNQUFJLEtBQUs7Q0FDakQsTUFBTSxPQUFPO0NBQ2IsTUFBTSxVQUFVLEtBQUssT0FBTyxpQkFBaUIsS0FBSyxPQUFPLGVBQWUsQ0FBQztDQUN6RSxJQUFJLE9BQU87O0NBRVgsSUFBSTtDQU9KLE9BQU87Ozs7Ozs7Ozs7O0NBWVAsU0FBUyxNQUFNLE1BQU07RUFDbkIsR0FBTyxTQUFTLE1BQU0sbUJBQW1CLGNBQWM7RUFDdkQsUUFBUSxNQUFNLGlCQUFpQjtFQUMvQixRQUFRLE1BQU0sNEJBQTRCO0VBQzFDLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLFFBQVEsS0FBSyw0QkFBNEI7RUFDekMsT0FBTztDQUNUOzs7Ozs7Ozs7OztDQVlBLFNBQVMsVUFBVSxNQUFNO0VBQ3ZCLElBQUksU0FBUyxNQUFNLE9BQU8sT0FBTyxJQUFJLElBQUk7RUFFekMsUUFBUSxNQUFNLHVCQUF1QjtFQUNyQyxRQUFRLFFBQVEsSUFBSTtFQUNwQixRQUFRLEtBQUssdUJBQXVCO0VBQ3BDLFFBQVEsTUFBTSx1QkFBdUI7RUFDckMsUUFBUSxNQUFNLGFBQWEsQ0FBQyxDQUFDLGNBQWM7RUFDM0MsT0FBTztDQUNUOzs7Ozs7Ozs7OztDQVlBLFNBQVMsU0FBUyxNQUFNO0VBQ3RCLElBRUUsT0FBTyxVQUFVLHdCQUVoQixTQUFTLE1BQU0sc0JBQXNCLENBQUMsUUFHdkMsU0FBUyxNQUFNLE9BQ2YsU0FBUyxNQUFNLHFCQUNmLDBCQUEwQixJQUFJLEdBRTlCLE9BQU8sSUFBSSxJQUFJO0VBR2pCLElBQUksU0FBUyxNQUFNLG9CQUFvQjtHQUNyQyxRQUFRLEtBQUssYUFBYTtHQUMxQixNQUFNLFFBQVEsUUFBUSxLQUFLLHVCQUF1QjtHQUVsRCxJQUFJLENBQUMsUUFBUSxTQUFTLG9CQUFvQixLQUFLLGVBQWUsS0FBSyxDQUFDLENBQUMsR0FDbkUsT0FBTyxJQUFJLElBQUk7R0FHakIsUUFBUSxNQUFNLDRCQUE0QjtHQUMxQyxRQUFRLFFBQVEsSUFBSTtHQUNwQixRQUFRLEtBQUssNEJBQTRCO0dBQ3pDLFFBQVEsS0FBSyxpQkFBaUI7R0FDOUIsT0FBT0E7RUFDVDtFQUVBLElBQUksQ0FBQywwQkFBMEIsSUFBSSxHQUNqQyxPQUFPO0VBR1Q7RUFDQSxRQUFRLFFBQVEsSUFBSTtFQUNwQixPQUFPLFNBQVMsTUFBTSxZQUFZLGFBQWE7Q0FDakQ7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxXQUFXLE1BQU07RUFDeEIsSUFDRSxTQUFTLE1BQU0scUJBQ2YsU0FBUyxNQUFNLGFBQ2YsU0FBUyxNQUFNLG9CQUNmO0dBQ0EsUUFBUSxRQUFRLElBQUk7R0FDcEI7R0FDQSxPQUFPO0VBQ1Q7RUFFQSxPQUFPLFNBQVMsSUFBSTtDQUN0QjtBQUNGOzs7OztBQU1BLFNBQVMsd0JBQXdCLFNBQVMsTUFBSSxLQUFLO0NBQ2pELE1BQU0sT0FBTztDQUNiLE1BQU0sVUFBVSxLQUFLLE9BQU8saUJBQWlCLEtBQUssT0FBTyxlQUFlLENBQUM7O0NBRXpFLElBQUk7Q0FDSixJQUFJLE9BQU87O0NBRVgsSUFBSTtDQUVKLE9BQU87Ozs7Ozs7Ozs7O0NBWVAsU0FBUyxNQUFNLE1BQU07RUFDbkIsR0FBTyxTQUFTLE1BQU0sbUJBQW1CLGNBQWM7RUFDdkQsUUFBUSxNQUFNLHVCQUF1QixDQUFDLENBQUMsYUFBYTtFQUNwRCxRQUFRLE1BQU0sNEJBQTRCO0VBQzFDLFFBQVEsTUFBTSxrQ0FBa0M7RUFDaEQsUUFBUSxRQUFRLElBQUk7RUFDcEIsUUFBUSxLQUFLLGtDQUFrQztFQUMvQyxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxjQUFjLE1BQU07RUFDM0IsSUFBSSxTQUFTLE1BQU0sT0FBTztHQUN4QixRQUFRLE1BQU0sNkJBQTZCO0dBQzNDLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLFFBQVEsS0FBSyw2QkFBNkI7R0FDMUMsUUFBUSxNQUFNLGtDQUFrQztHQUNoRCxRQUFRLE1BQU0sYUFBYSxDQUFDLENBQUMsY0FBYztHQUMzQyxPQUFPO0VBQ1Q7RUFFQSxPQUFPLElBQUksSUFBSTtDQUNqQjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxTQUFTLFlBQVksTUFBTTtFQUN6QixJQUVFLE9BQU8sVUFBVSx3QkFFaEIsU0FBUyxNQUFNLHNCQUFzQixDQUFDLFFBR3ZDLFNBQVMsTUFBTSxPQUNmLFNBQVMsTUFBTSxxQkFDZiwwQkFBMEIsSUFBSSxHQUU5QixPQUFPLElBQUksSUFBSTtFQUdqQixJQUFJLFNBQVMsTUFBTSxvQkFBb0I7R0FDckMsUUFBUSxLQUFLLGFBQWE7R0FDMUIsTUFBTSxRQUFRLFFBQVEsS0FBSyxrQ0FBa0M7R0FDN0QsYUFBYSxvQkFBb0IsS0FBSyxlQUFlLEtBQUssQ0FBQztHQUMzRCxRQUFRLE1BQU0sa0NBQWtDO0dBQ2hELFFBQVEsUUFBUSxJQUFJO0dBQ3BCLFFBQVEsS0FBSyxrQ0FBa0M7R0FDL0MsUUFBUSxLQUFLLDRCQUE0QjtHQUN6QyxPQUFPO0VBQ1Q7RUFFQSxJQUFJLENBQUMsMEJBQTBCLElBQUksR0FDakMsT0FBTztFQUdUO0VBQ0EsUUFBUSxRQUFRLElBQUk7RUFDcEIsT0FBTyxTQUFTLE1BQU0sWUFBWSxjQUFjO0NBQ2xEOzs7Ozs7Ozs7Ozs7OztDQWVBLFNBQVMsWUFBWSxNQUFNO0VBQ3pCLElBQ0UsU0FBUyxNQUFNLHFCQUNmLFNBQVMsTUFBTSxhQUNmLFNBQVMsTUFBTSxvQkFDZjtHQUNBLFFBQVEsUUFBUSxJQUFJO0dBQ3BCO0dBQ0EsT0FBTztFQUNUO0VBRUEsT0FBTyxZQUFZLElBQUk7Q0FDekI7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxXQUFXLE1BQU07RUFDeEIsSUFBSSxTQUFTLE1BQU0sT0FBTztHQUN4QixRQUFRLE1BQU0sa0JBQWtCO0dBQ2hDLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLFFBQVEsS0FBSyxrQkFBa0I7R0FFL0IsSUFBSSxDQUFDLFFBQVEsU0FBUyxVQUFVLEdBQzlCLFFBQVEsS0FBSyxVQUFVO0dBTXpCLE9BQU8sYUFDTCxTQUNBLGlCQUNBLGlDQUNGO0VBQ0Y7RUFFQSxPQUFPLElBQUksSUFBSTtDQUNqQjs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLGdCQUFnQixNQUFNO0VBRTdCLE9BQU9BLEtBQUcsSUFBSTtDQUNoQjtBQUNGOzs7OztBQU1BLFNBQVMsK0JBQStCLFNBQVMsSUFBSSxLQUFLO0NBVXhELE9BQU8sUUFBUSxNQUFNLFdBQVcsSUFBSSxRQUFRLFFBQVEsUUFBUSxJQUFJLEdBQUcsQ0FBQztBQUN0RTs7QUFHQSxTQUFTLHlCQUF5QixTQUFTO0NBQ3pDLFFBQVEsS0FBSyx1QkFBdUI7QUFDdEM7Ozs7O0FBTUEsU0FBUyxlQUFlLFNBQVMsSUFBSSxLQUFLO0NBQ3hDLE1BQU0sT0FBTztDQUViLE9BQU8sYUFDTCxTQUNBLGFBQ0EsK0JBQ0EsVUFBVSxVQUFVLENBQ3RCOzs7O0NBS0EsU0FBUyxZQUFZLE1BQU07RUFDekIsTUFBTSxPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sU0FBUztFQUM5QyxPQUFPLFFBQ0wsS0FBSyxFQUFFLENBQUMsU0FBUyxpQ0FDakIsS0FBSyxFQUFFLENBQUMsZUFBZSxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsV0FBVyxVQUFVLFVBQ3pELEdBQUcsSUFBSSxJQUNQLElBQUksSUFBSTtDQUNkO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6aEJBLFNBQWdCLGlCQUFpQixTQUFTO0NBRXhDLElBQUksVUFEYSxXQUFXLENBQUMsRUFBQSxDQUNQO0NBQ3RCLE1BQU0sWUFBWTtFQUNoQixNQUFNO0VBQ04sVUFBVTtFQUNWLFlBQVk7Q0FDZDtDQUVBLElBQUksV0FBVyxRQUFRLFdBQVcsS0FBQSxHQUNoQyxTQUFTO0NBR1gsT0FBTztFQUNMLE1BQU0sR0FBRSxNQUFNLFFBQVEsVUFBUztFQUMvQixZQUFZLEVBQUMsTUFBTSxDQUFDLFNBQVMsRUFBQztFQUM5QixrQkFBa0IsRUFBQyxNQUFNLENBQUMsTUFBTSxLQUFLLEVBQUM7Q0FDeEM7Ozs7OztDQU9BLFNBQVMsd0JBQXdCLFFBQVEsU0FBUztFQUNoRCxJQUFJLFFBQVE7RUFHWixPQUFPLEVBQUUsUUFBUSxPQUFPLFFBRXRCLElBQ0UsT0FBTyxNQUFNLENBQUMsT0FBTyxXQUNyQixPQUFPLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxvQ0FDMUIsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQ2pCO0dBQ0EsSUFBSSxPQUFPO0dBR1gsT0FBTyxRQUVMLElBQ0UsT0FBTyxLQUFLLENBQUMsT0FBTyxVQUNwQixPQUFPLEtBQUssQ0FBQyxFQUFFLENBQUMsU0FBUyxvQ0FDekIsT0FBTyxLQUFLLENBQUMsRUFBRSxDQUFDLFNBRWhCLE9BQU8sTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLFNBQVMsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sV0FDbkQsT0FBTyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksU0FBUyxPQUFPLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxRQUNyRDtJQUNBLE9BQU8sTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPO0lBQ3hCLE9BQU8sS0FBSyxDQUFDLEVBQUUsQ0FBQyxPQUFPOztJQUd2QixNQUFNLGdCQUFnQjtLQUNwQixNQUFNO0tBQ04sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLO0tBQzlDLEtBQUssT0FBTyxPQUFPLENBQUMsR0FBRyxPQUFPLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRztJQUM3Qzs7SUFHQSxNQUFNLE9BQU87S0FDWCxNQUFNO0tBQ04sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHO0tBQzVDLEtBQUssT0FBTyxPQUFPLENBQUMsR0FBRyxPQUFPLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSztJQUMvQzs7SUFJQSxNQUFNLGFBQWE7S0FDakI7TUFBQztNQUFTO01BQWU7S0FBTztLQUNoQztNQUFDO01BQVMsT0FBTyxLQUFLLENBQUM7TUFBSTtLQUFPO0tBQ2xDO01BQUM7TUFBUSxPQUFPLEtBQUssQ0FBQztNQUFJO0tBQU87S0FDakM7TUFBQztNQUFTO01BQU07S0FBTztJQUN6QjtJQUVBLE1BQU0sYUFBYSxRQUFRLE9BQU8sV0FBVyxXQUFXO0lBRXhELElBQUksWUFFRixPQUNFLFlBQ0EsV0FBVyxRQUNYLEdBQ0EsV0FBVyxZQUFZLE9BQU8sTUFBTSxPQUFPLEdBQUcsS0FBSyxHQUFHLE9BQU8sQ0FDL0Q7SUFJRixPQUFPLFlBQVksV0FBVyxRQUFRLEdBQUc7S0FDdkM7TUFBQztNQUFRO01BQU07S0FBTztLQUN0QjtNQUFDO01BQVMsT0FBTyxNQUFNLENBQUM7TUFBSTtLQUFPO0tBQ25DO01BQUM7TUFBUSxPQUFPLE1BQU0sQ0FBQztNQUFJO0tBQU87S0FDbEM7TUFBQztNQUFRO01BQWU7S0FBTztJQUNqQyxDQUFDO0lBRUQsT0FBTyxRQUFRLE9BQU8sR0FBRyxRQUFRLE9BQU8sR0FBRyxVQUFVO0lBRXJELFFBQVEsT0FBTyxXQUFXLFNBQVM7SUFDbkM7R0FDRjtFQUVKO0VBR0YsUUFBUTtFQUVSLE9BQU8sRUFBRSxRQUFRLE9BQU8sUUFDdEIsSUFBSSxPQUFPLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxrQ0FDNUIsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDLE9BQU8sTUFBTTtFQUlsQyxPQUFPO0NBQ1Q7Ozs7O0NBTUEsU0FBUyxzQkFBc0IsU0FBUyxNQUFJLEtBQUs7RUFDL0MsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxTQUFTLEtBQUs7RUFDcEIsSUFBSSxPQUFPO0VBRVgsT0FBTzs7RUFHUCxTQUFTLE1BQU0sTUFBTTtHQUNuQixHQUFPLFNBQVMsTUFBTSxPQUFPLGNBQWM7R0FFM0MsSUFDRSxhQUFhLE1BQU0sU0FDbkIsT0FBTyxPQUFPLFNBQVMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxTQUFTLE1BQU0saUJBRTVDLE9BQU8sSUFBSSxJQUFJO0dBR2pCLFFBQVEsTUFBTSxnQ0FBZ0M7R0FDOUMsT0FBTyxLQUFLLElBQUk7RUFDbEI7O0VBR0EsU0FBUyxLQUFLLE1BQU07R0FDbEIsTUFBTSxTQUFTLGtCQUFrQixRQUFRO0dBRXpDLElBQUksU0FBUyxNQUFNLE9BQU87SUFFeEIsSUFBSSxPQUFPLEdBQUcsT0FBTyxJQUFJLElBQUk7SUFDN0IsUUFBUSxRQUFRLElBQUk7SUFDcEI7SUFDQSxPQUFPO0dBQ1Q7R0FFQSxJQUFJLE9BQU8sS0FBSyxDQUFDLFFBQVEsT0FBTyxJQUFJLElBQUk7R0FDeEMsTUFBTSxRQUFRLFFBQVEsS0FBSyxnQ0FBZ0M7R0FDM0QsTUFBTSxRQUFRLGtCQUFrQixJQUFJO0dBQ3BDLE1BQU0sUUFDSixDQUFDLFNBQVUsVUFBVSxVQUFVLHNCQUFzQixRQUFRLE1BQU07R0FDckUsTUFBTSxTQUNKLENBQUMsVUFBVyxXQUFXLFVBQVUsc0JBQXNCLFFBQVEsS0FBSztHQUN0RSxPQUFPQyxLQUFHLElBQUk7RUFDaEI7Q0FDRjtBQUNGOzs7Ozs7Ozs7Ozs7O0FDN0pBLElBQWEsVUFBYixNQUFxQjs7OztDQUluQixjQUFjOzs7Ozs7RUFNWixLQUFLLE1BQU0sQ0FBQztDQUNkOzs7Ozs7Ozs7Q0FVQSxJQUFJLE9BQU8sUUFBUSxLQUFLO0VBQ3RCLGtCQUFrQixNQUFNLE9BQU8sUUFBUSxHQUFHO0NBQzVDOzs7Ozs7O0NBcUJBLFFBQVEsUUFBUTtFQUNkLEtBQUssSUFBSSxLQUFLLFNBQVUsR0FBRyxHQUFHO0dBQzVCLE9BQU8sRUFBRSxLQUFLLEVBQUU7RUFDbEIsQ0FBQzs7RUFHRCxJQUFJLEtBQUssSUFBSSxXQUFXLEdBQ3RCO0VBcUJGLElBQUksUUFBUSxLQUFLLElBQUk7O0VBRXJCLE1BQU0sT0FBTyxDQUFDO0VBQ2QsT0FBTyxRQUFRLEdBQUc7R0FDaEIsU0FBUztHQUNULEtBQUssS0FDSCxPQUFPLE1BQU0sS0FBSyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEtBQUssSUFBSSxNQUFNLENBQUMsRUFBRSxHQUNwRCxLQUFLLElBQUksTUFBTSxDQUFDLEVBQ2xCO0dBR0EsT0FBTyxTQUFTLEtBQUssSUFBSSxNQUFNLENBQUM7RUFDbEM7RUFFQSxLQUFLLEtBQUssT0FBTyxNQUFNLENBQUM7RUFDeEIsT0FBTyxTQUFTO0VBRWhCLElBQUksUUFBUSxLQUFLLElBQUk7RUFFckIsT0FBTyxPQUFPO0dBQ1osS0FBSyxNQUFNLFdBQVcsT0FDcEIsT0FBTyxLQUFLLE9BQU87R0FHckIsUUFBUSxLQUFLLElBQUk7RUFDbkI7RUFHQSxLQUFLLElBQUksU0FBUztDQUNwQjtBQUNGOzs7Ozs7Ozs7O0FBV0EsU0FBUyxrQkFBa0IsU0FBUyxJQUFJLFFBQVEsS0FBSztDQUNuRCxJQUFJLFFBQVE7O0NBR1osSUFBSSxXQUFXLEtBQUssSUFBSSxXQUFXLEdBQ2pDO0NBR0YsT0FBTyxRQUFRLFFBQVEsSUFBSSxRQUFRO0VBQ2pDLElBQUksUUFBUSxJQUFJLE1BQU0sQ0FBQyxPQUFPLElBQUk7R0FDaEMsUUFBUSxJQUFJLE1BQU0sQ0FBQyxNQUFNO0dBT3pCLFFBQVEsSUFBSSxNQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssR0FBRyxHQUFHO0dBR2pDO0VBQ0Y7RUFFQSxTQUFTO0NBQ1g7Q0FFQSxRQUFRLElBQUksS0FBSztFQUFDO0VBQUk7RUFBUTtDQUFHLENBQUM7QUFDcEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqSkEsU0FBZ0IsY0FBYyxRQUFRLE9BQU87Q0FDM0MsR0FBTyxPQUFPLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxTQUFTLGdCQUFnQjtDQUMxRCxJQUFJLGlCQUFpQjs7Q0FFckIsTUFBTSxRQUFRLENBQUM7Q0FFZixPQUFPLFFBQVEsT0FBTyxRQUFRO0VBQzVCLE1BQU0sUUFBUSxPQUFPO0VBRXJCLElBQUksZ0JBQWdCO0dBQ2xCLElBQUksTUFBTSxPQUFPLFNBR1g7UUFBQSxNQUFNLEVBQUUsQ0FBQyxTQUFTLGdCQUNwQixNQUFNLEtBQ0osT0FBTyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUMsU0FBUyx5QkFDMUIsU0FDQSxNQUNOO0dBQUEsT0FNQyxJQUFJLE1BQU0sRUFBRSxDQUFDLFNBQVMsZ0JBQ3JCO1FBQUEsT0FBTyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUMsU0FBUyx3QkFBd0I7S0FDeEQsTUFBTSxhQUFhLE1BQU0sU0FBUztLQUVsQyxNQUFNLGNBQWMsTUFBTSxnQkFBZ0IsU0FBUyxXQUFXO0lBQ2hFO1VBR0csSUFBSSxNQUFNLEVBQUUsQ0FBQyxTQUFTLHFCQUN6QjtFQUVKLE9BQU8sSUFBSSxNQUFNLE9BQU8sV0FBVyxNQUFNLEVBQUUsQ0FBQyxTQUFTLHFCQUNuRCxpQkFBaUI7RUFHbkIsU0FBUztDQUNYO0NBRUEsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDQSxTQUFnQixXQUFXO0NBQ3pCLE9BQU8sRUFDTCxNQUFNLEVBQ0osTUFBTTtFQUFDLE1BQU07RUFBUyxVQUFVO0VBQWUsWUFBWTtDQUFZLEVBQ3pFLEVBQ0Y7QUFDRjs7Ozs7QUFNQSxTQUFTLGNBQWMsU0FBUyxNQUFJLEtBQUs7Q0FDdkMsTUFBTSxPQUFPO0NBQ2IsSUFBSSxPQUFPO0NBQ1gsSUFBSSxRQUFROztDQUVaLElBQUk7Q0FFSixPQUFPOzs7Ozs7Ozs7Ozs7Ozs7OztDQWtCUCxTQUFTLE1BQU0sTUFBTTtFQUNuQixJQUFJLFFBQVEsS0FBSyxPQUFPLFNBQVM7RUFFakMsT0FBTyxRQUFRLElBQUk7R0FDakIsTUFBTSxPQUFPLEtBQUssT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDO0dBQ25DLElBQ0UsU0FBUyxNQUFNLGNBRWYsU0FBUyxNQUFNLFlBRWY7UUFDRztFQUNQO0VBRUEsTUFBTSxPQUFPLFFBQVEsS0FBSyxLQUFLLE9BQU8sTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPO0VBRXZELE1BQU0sT0FDSixTQUFTLGVBQWUsU0FBUyxhQUFhLGVBQWU7RUFHL0QsSUFBSSxTQUFTLGdCQUFnQixLQUFLLE9BQU8sS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDLE9BQ3ZELE9BQU8sSUFBSSxJQUFJO0VBR2pCLE9BQU8sS0FBSyxJQUFJO0NBQ2xCOzs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxjQUFjLE1BQU07RUFDM0IsUUFBUSxNQUFNLFdBQVc7RUFDekIsUUFBUSxNQUFNLFVBQVU7RUFDeEIsT0FBTyxhQUFhLElBQUk7Q0FDMUI7Ozs7Ozs7Ozs7Ozs7Q0FjQSxTQUFTLGFBQWEsTUFBTTtFQUMxQixJQUFJLFNBQVMsTUFBTSxhQUNqQixPQUFPLGFBQWEsSUFBSTtFQWExQixPQUFPO0VBRVAsU0FBUztFQUNULE9BQU8sYUFBYSxJQUFJO0NBQzFCOzs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsU0FBUyxhQUFhLE1BQU07RUFDMUIsSUFBSSxTQUFTLE1BQU0sS0FFakIsT0FBTyxJQUFJLElBQUk7RUFHakIsSUFBSSxtQkFBbUIsSUFBSSxHQUFHO0dBRTVCLElBQUksUUFBUSxHQUFHO0lBQ2IsUUFBUTtJQUdSLEtBQUssWUFBWTtJQUNqQixRQUFRLEtBQUssVUFBVTtJQUN2QixRQUFRLE1BQU0sTUFBTSxVQUFVO0lBQzlCLFFBQVEsUUFBUSxJQUFJO0lBQ3BCLFFBQVEsS0FBSyxNQUFNLFVBQVU7SUFDN0IsT0FBTztHQUNUO0dBR0EsT0FBTyxJQUFJLElBQUk7RUFDakI7RUFFQSxJQUFJLGNBQWMsSUFBSSxHQUlwQixPQUFPLGFBQWEsU0FBUyxjQUFjLE1BQU0sVUFBVSxDQUFDLENBQUMsSUFBSTtFQUduRSxTQUFTO0VBRVQsSUFBSSxNQUFNO0dBQ1IsT0FBTztHQUVQLFFBQVE7RUFDVjtFQUVBLElBQUksU0FBUyxNQUFNLGFBQWE7R0FDOUIsUUFBUSxNQUFNLGtCQUFrQjtHQUNoQyxRQUFRLFFBQVEsSUFBSTtHQUNwQixRQUFRLEtBQUssa0JBQWtCO0dBRS9CLE9BQU87R0FDUCxPQUFPO0VBQ1Q7RUFHQSxRQUFRLE1BQU0sTUFBTSxJQUFJO0VBQ3hCLE9BQU8sWUFBWSxJQUFJO0NBQ3pCOzs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxZQUFZLE1BQU07RUFDekIsSUFDRSxTQUFTLE1BQU0sT0FDZixTQUFTLE1BQU0sZUFDZiwwQkFBMEIsSUFBSSxHQUM5QjtHQUNBLFFBQVEsS0FBSyxNQUFNLElBQUk7R0FDdkIsT0FBTyxhQUFhLElBQUk7RUFDMUI7RUFFQSxRQUFRLFFBQVEsSUFBSTtFQUNwQixPQUFPLFNBQVMsTUFBTSxZQUFZLGdCQUFnQjtDQUNwRDs7Ozs7Ozs7Ozs7OztDQWNBLFNBQVMsY0FBYyxNQUFNO0VBQzNCLElBQUksU0FBUyxNQUFNLGFBQWEsU0FBUyxNQUFNLGFBQWE7R0FDMUQsUUFBUSxRQUFRLElBQUk7R0FDcEIsT0FBTztFQUNUO0VBRUEsT0FBTyxZQUFZLElBQUk7Q0FDekI7Ozs7Ozs7Ozs7Ozs7Q0FjQSxTQUFTLG1CQUFtQixNQUFNO0VBRWhDLEtBQUssWUFBWTtFQUdqQixJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssSUFBSSxDQUFDLENBQUMsT0FDOUIsT0FBTyxJQUFJLElBQUk7RUFHakIsUUFBUSxNQUFNLG1CQUFtQjtFQUVqQyxPQUFPO0VBRVAsSUFBSSxjQUFjLElBQUksR0FBRztHQUN2QixHQUFPLEtBQUssT0FBTyxXQUFXLFFBQVEsTUFBTSwwQkFBMEI7R0FDdEUsT0FBTyxhQUNMLFNBQ0EscUJBQ0EsTUFBTSxZQUNOLEtBQUssT0FBTyxXQUFXLFFBQVEsS0FBSyxTQUFTLGNBQWMsSUFDdkQsS0FBQSxJQUNBLFVBQVUsT0FDaEIsQ0FBQyxDQUFDLElBQUk7RUFDUjtFQUVBLE9BQU8sb0JBQW9CLElBQUk7Q0FDakM7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxTQUFTLG9CQUFvQixNQUFNO0VBQ2pDLElBQUksU0FBUyxNQUFNLFFBQVEsU0FBUyxNQUFNLE9BQ3hDLE9BQU8seUJBQXlCLElBQUk7RUFHdEMsSUFBSSxTQUFTLE1BQU0sYUFBYTtHQUM5QixPQUFPO0dBRVAsUUFBUSxNQUFNLGtCQUFrQjtHQUNoQyxRQUFRLFFBQVEsSUFBSTtHQUNwQixRQUFRLEtBQUssa0JBQWtCO0dBQy9CLE9BQU87RUFDVDtFQUdBLE9BQU8saUJBQWlCLElBQUk7Q0FDOUI7Ozs7Ozs7Ozs7OztDQWFBLFNBQVMsd0JBQXdCLE1BQU07RUFDckMsSUFBSSxjQUFjLElBQUksR0FDcEIsT0FBTyxhQUNMLFNBQ0EsMEJBQ0EsTUFBTSxVQUNSLENBQUMsQ0FBQyxJQUFJO0VBR1IsT0FBTyx5QkFBeUIsSUFBSTtDQUN0Qzs7Ozs7Ozs7Ozs7O0NBYUEsU0FBUyx5QkFBeUIsTUFBTTtFQUV0QyxJQUFJLFNBQVMsTUFBTSxPQUFPO0dBQ3hCLFNBQVM7R0FDVCxPQUFPO0dBRVAsUUFBUSxNQUFNLHNCQUFzQjtHQUNwQyxRQUFRLFFBQVEsSUFBSTtHQUNwQixRQUFRLEtBQUssc0JBQXNCO0dBQ25DLE9BQU87RUFDVDtFQUdBLElBQUksU0FBUyxNQUFNLE1BQU07R0FDdkIsU0FBUztHQUVULE9BQU8sZ0NBQWdDLElBQUk7RUFDN0M7RUFFQSxJQUFJLFNBQVMsTUFBTSxPQUFPLG1CQUFtQixJQUFJLEdBQy9DLE9BQU8sdUJBQXVCLElBQUk7RUFHcEMsT0FBTyxpQkFBaUIsSUFBSTtDQUM5Qjs7Ozs7Ozs7Ozs7O0NBYUEsU0FBUyxnQ0FBZ0MsTUFBTTtFQUM3QyxJQUFJLFNBQVMsTUFBTSxNQUFNO0dBQ3ZCLFFBQVEsTUFBTSxzQkFBc0I7R0FDcEMsT0FBTyxvQkFBb0IsSUFBSTtFQUNqQztFQUdBLE9BQU8saUJBQWlCLElBQUk7Q0FDOUI7Ozs7Ozs7Ozs7OztDQWFBLFNBQVMsb0JBQW9CLE1BQU07RUFDakMsSUFBSSxTQUFTLE1BQU0sTUFBTTtHQUN2QixRQUFRLFFBQVEsSUFBSTtHQUNwQixPQUFPO0VBQ1Q7RUFHQSxJQUFJLFNBQVMsTUFBTSxPQUFPO0dBQ3hCLE9BQU87R0FDUCxRQUFRLEtBQUssc0JBQXNCO0dBQ25DLFFBQVEsTUFBTSxzQkFBc0I7R0FDcEMsUUFBUSxRQUFRLElBQUk7R0FDcEIsUUFBUSxLQUFLLHNCQUFzQjtHQUNuQyxPQUFPO0VBQ1Q7RUFFQSxRQUFRLEtBQUssc0JBQXNCO0VBQ25DLE9BQU8saUNBQWlDLElBQUk7Q0FDOUM7Ozs7Ozs7Ozs7OztDQWFBLFNBQVMsaUNBQWlDLE1BQU07RUFDOUMsSUFBSSxjQUFjLElBQUksR0FDcEIsT0FBTyxhQUNMLFNBQ0Esd0JBQ0EsTUFBTSxVQUNSLENBQUMsQ0FBQyxJQUFJO0VBR1IsT0FBTyx1QkFBdUIsSUFBSTtDQUNwQzs7Ozs7Ozs7Ozs7O0NBYUEsU0FBUyx1QkFBdUIsTUFBTTtFQUNwQyxJQUFJLFNBQVMsTUFBTSxhQUNqQixPQUFPLG9CQUFvQixJQUFJO0VBR2pDLElBQUksU0FBUyxNQUFNLE9BQU8sbUJBQW1CLElBQUksR0FBRztHQUtsRCxJQUFJLENBQUMsUUFBUSxTQUFTLE9BQ3BCLE9BQU8saUJBQWlCLElBQUk7R0FJOUIsUUFBUSxLQUFLLG1CQUFtQjtHQUNoQyxRQUFRLEtBQUssV0FBVztHQUd4QixPQUFPQyxLQUFHLElBQUk7RUFDaEI7RUFFQSxPQUFPLGlCQUFpQixJQUFJO0NBQzlCOzs7Ozs7Ozs7Ozs7Q0FhQSxTQUFTLGlCQUFpQixNQUFNO0VBRTlCLE9BQU8sSUFBSSxJQUFJO0NBQ2pCOzs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxhQUFhLE1BQU07RUFJMUIsUUFBUSxNQUFNLFVBQVU7RUFDeEIsT0FBTyxhQUFhLElBQUk7Q0FDMUI7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxTQUFTLGFBQWEsTUFBTTtFQUMxQixJQUFJLFNBQVMsTUFBTSxhQUFhO0dBQzlCLFFBQVEsTUFBTSxrQkFBa0I7R0FDaEMsUUFBUSxRQUFRLElBQUk7R0FDcEIsUUFBUSxLQUFLLGtCQUFrQjtHQUMvQixPQUFPO0VBQ1Q7RUFFQSxJQUFJLFNBQVMsTUFBTSxPQUFPLG1CQUFtQixJQUFJLEdBQUc7R0FDbEQsUUFBUSxLQUFLLFVBQVU7R0FDdkIsT0FBT0EsS0FBRyxJQUFJO0VBQ2hCO0VBRUEsSUFBSSxjQUFjLElBQUksR0FDcEIsT0FBTyxhQUFhLFNBQVMsY0FBYyxNQUFNLFVBQVUsQ0FBQyxDQUFDLElBQUk7RUFJbkUsUUFBUSxNQUFNLE1BQU0sSUFBSTtFQUN4QixPQUFPLFlBQVksSUFBSTtDQUN6Qjs7Ozs7Ozs7Ozs7OztDQWNBLFNBQVMsWUFBWSxNQUFNO0VBQ3pCLElBQ0UsU0FBUyxNQUFNLE9BQ2YsU0FBUyxNQUFNLGVBQ2YsMEJBQTBCLElBQUksR0FDOUI7R0FDQSxRQUFRLEtBQUssTUFBTSxJQUFJO0dBQ3ZCLE9BQU8sYUFBYSxJQUFJO0VBQzFCO0VBRUEsUUFBUSxRQUFRLElBQUk7RUFDcEIsT0FBTyxTQUFTLE1BQU0sWUFBWSxnQkFBZ0I7Q0FDcEQ7Ozs7Ozs7Ozs7Ozs7Q0FjQSxTQUFTLGNBQWMsTUFBTTtFQUMzQixJQUFJLFNBQVMsTUFBTSxhQUFhLFNBQVMsTUFBTSxhQUFhO0dBQzFELFFBQVEsUUFBUSxJQUFJO0dBQ3BCLE9BQU87RUFDVDtFQUVBLE9BQU8sWUFBWSxJQUFJO0NBQ3pCO0FBQ0Y7O0FBSUEsU0FBUyxhQUFhLFFBQVEsU0FBUztDQUNyQyxJQUFJLFFBQVE7Q0FDWixJQUFJLDBCQUEwQjs7Q0FFOUIsSUFBSSxVQUFVOztDQUVkLElBQUksV0FBVztFQUFDO0VBQUc7RUFBRztFQUFHO0NBQUM7O0NBRTFCLElBQUksT0FBTztFQUFDO0VBQUc7RUFBRztFQUFHO0NBQUM7Q0FDdEIsSUFBSSxnQ0FBZ0M7Q0FDcEMsSUFBSSxlQUFlOztDQUVuQixJQUFJOztDQUVKLElBQUk7O0NBRUosSUFBSTtDQUVKLE1BQU0sTUFBTSxJQUFJLFFBQVE7Q0FFeEIsT0FBTyxFQUFFLFFBQVEsT0FBTyxRQUFRO0VBQzlCLE1BQU0sUUFBUSxPQUFPO0VBQ3JCLE1BQU0sUUFBUSxNQUFNO0VBRXBCLElBQUksTUFBTSxPQUFPLFNBQVM7R0FFeEIsSUFBSSxNQUFNLFNBQVMsYUFBYTtJQUM5QixnQ0FBZ0M7SUFHaEMsSUFBSSxpQkFBaUIsR0FBRztLQUN0QixHQUFPLGNBQWMsaUNBQWlDO0tBQ3RELGNBQWMsS0FBSyxTQUFTLGNBQWMsY0FBYyxXQUFXO0tBQ25FLGNBQWMsS0FBQTtLQUNkLGVBQWU7SUFDakI7SUFHQSxlQUFlO0tBQ2IsTUFBTTtLQUNOLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxNQUFNLEtBQUs7S0FFcEMsS0FBSyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE1BQU0sR0FBRztJQUNsQztJQUNBLElBQUksSUFBSSxPQUFPLEdBQUcsQ0FBQztLQUFDO0tBQVM7S0FBYztJQUFPLENBQUMsQ0FBQztHQUN0RCxPQUFPLElBQ0wsTUFBTSxTQUFTLGNBQ2YsTUFBTSxTQUFTLHFCQUNmO0lBQ0EsMEJBQTBCO0lBQzFCLGNBQWMsS0FBQTtJQUNkLFdBQVc7S0FBQztLQUFHO0tBQUc7S0FBRztJQUFDO0lBQ3RCLE9BQU87S0FBQztLQUFHLFFBQVE7S0FBRztLQUFHO0lBQUM7SUFHMUIsSUFBSSwrQkFBK0I7S0FDakMsZ0NBQWdDO0tBQ2hDLGNBQWM7TUFDWixNQUFNO01BQ04sT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE1BQU0sS0FBSztNQUVwQyxLQUFLLE9BQU8sT0FBTyxDQUFDLEdBQUcsTUFBTSxHQUFHO0tBQ2xDO0tBQ0EsSUFBSSxJQUFJLE9BQU8sR0FBRyxDQUFDO01BQUM7TUFBUztNQUFhO0tBQU8sQ0FBQyxDQUFDO0lBQ3JEO0lBRUEsVUFBVSxNQUFNLFNBQVMsc0JBQXNCLElBQUksY0FBYyxJQUFJO0dBQ3ZFLE9BRUssSUFDSCxZQUNDLE1BQU0sU0FBUyxNQUFNLFFBQ3BCLE1BQU0sU0FBUywwQkFDZixNQUFNLFNBQVMseUJBQ2pCO0lBQ0EsMEJBQTBCO0lBRzFCLElBQUksS0FBSyxPQUFPLEdBQUc7S0FDakIsSUFBSSxTQUFTLE9BQU8sR0FBRztNQUNyQixLQUFLLEtBQUssS0FBSztNQUNmLGNBQWMsVUFDWixLQUNBLFNBQ0EsVUFDQSxTQUNBLEtBQUEsR0FDQSxXQUNGO01BQ0EsV0FBVztPQUFDO09BQUc7T0FBRztPQUFHO01BQUM7S0FDeEI7S0FFQSxLQUFLLEtBQUs7SUFDWjtHQUNGLE9BQU8sSUFBSSxNQUFNLFNBQVMsb0JBQW9CO0lBQzVDLElBQUkseUJBQ0YsMEJBQTBCO1NBQ3JCO0tBQ0wsSUFBSSxTQUFTLE9BQU8sR0FBRztNQUNyQixLQUFLLEtBQUssS0FBSztNQUNmLGNBQWMsVUFDWixLQUNBLFNBQ0EsVUFDQSxTQUNBLEtBQUEsR0FDQSxXQUNGO0tBQ0Y7S0FFQSxXQUFXO0tBQ1gsT0FBTztNQUFDLFNBQVM7TUFBSTtNQUFPO01BQUc7S0FBQztJQUNsQztHQUNGO0VBQ0YsT0FFSyxJQUFJLE1BQU0sU0FBUyxhQUFhO0dBQ25DLGdDQUFnQztHQUNoQyxlQUFlO0VBQ2pCLE9BQU8sSUFDTCxNQUFNLFNBQVMsY0FDZixNQUFNLFNBQVMscUJBQ2Y7R0FDQSxlQUFlO0dBRWYsSUFBSSxTQUFTLE9BQU8sR0FBRztJQUNyQixLQUFLLEtBQUssS0FBSztJQUNmLGNBQWMsVUFDWixLQUNBLFNBQ0EsVUFDQSxTQUNBLE9BQ0EsV0FDRjtHQUNGLE9BQU8sSUFBSSxLQUFLLE9BQU8sR0FDckIsY0FBYyxVQUFVLEtBQUssU0FBUyxNQUFNLFNBQVMsT0FBTyxXQUFXO0dBR3pFLFVBQVU7RUFDWixPQUFPLElBQ0wsWUFDQyxNQUFNLFNBQVMsTUFBTSxRQUNwQixNQUFNLFNBQVMsMEJBQ2YsTUFBTSxTQUFTLHlCQUVqQixLQUFLLEtBQUs7Q0FFZDtDQUVBLElBQUksaUJBQWlCLEdBQUc7RUFDdEIsR0FBTyxjQUFjLHdCQUF3QjtFQUM3QyxjQUFjLEtBQUssU0FBUyxjQUFjLGNBQWMsV0FBVztDQUNyRTtDQUVBLElBQUksUUFBUSxRQUFRLE1BQU07Q0FLMUIsUUFBUTtDQUNSLE9BQU8sRUFBRSxRQUFRLFFBQVEsT0FBTyxRQUFRO0VBQ3RDLE1BQU0sUUFBUSxRQUFRLE9BQU87RUFDN0IsSUFBSSxNQUFNLE9BQU8sV0FBVyxNQUFNLEVBQUUsQ0FBQyxTQUFTLFNBQzVDLE1BQU0sRUFBRSxDQUFDLFNBQVMsY0FBYyxRQUFRLFFBQVEsS0FBSztDQUV6RDtDQUVBLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxVQUFVLEtBQUssU0FBUyxPQUFPLFNBQVMsUUFBUSxjQUFjO0NBR3JFLE1BQU0sWUFDSixZQUFZLElBQ1IsZ0JBQ0EsWUFBWSxJQUNWLG1CQUNBO0NBR1IsTUFBTSxZQUFZO0NBU2xCLElBQUksTUFBTSxPQUFPLEdBQUc7RUFDbEIsR0FBTyxjQUFjLDhCQUE4QjtFQUNuRCxhQUFhLE1BQU0sT0FBTyxPQUFPLENBQUMsR0FBRyxTQUFTLFFBQVEsUUFBUSxNQUFNLEVBQUUsQ0FBQztFQUN2RSxJQUFJLElBQUksTUFBTSxJQUFJLEdBQUcsQ0FBQztHQUFDO0dBQVE7R0FBYztFQUFPLENBQUMsQ0FBQztDQUN4RDtDQVNBLE1BQU0sTUFBTSxTQUFTLFFBQVEsUUFBUSxNQUFNLEVBQUU7Q0FDN0MsZUFBZTtFQUNiLE1BQU07RUFDTixPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsR0FBRztFQUU1QixLQUFLLE9BQU8sT0FBTyxDQUFDLEdBQUcsR0FBRztDQUM1QjtDQUNBLElBQUksSUFBSSxNQUFNLElBQUksR0FBRyxDQUFDO0VBQUM7RUFBUztFQUFjO0NBQU8sQ0FBQyxDQUFDO0NBV3ZELElBQUksTUFBTSxPQUFPLEdBQUc7RUFDbEIsTUFBTSxlQUFlLFNBQVMsUUFBUSxRQUFRLE1BQU0sRUFBRTtFQUN0RCxNQUFNLGFBQWEsU0FBUyxRQUFRLFFBQVEsTUFBTSxFQUFFOztFQUVwRCxNQUFNLGFBQWE7R0FDakIsTUFBTTtHQUNOLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxZQUFZO0dBQ3JDLEtBQUssT0FBTyxPQUFPLENBQUMsR0FBRyxVQUFVO0VBQ25DO0VBQ0EsSUFBSSxJQUFJLE1BQU0sSUFBSSxHQUFHLENBQUM7R0FBQztHQUFTO0dBQVk7RUFBTyxDQUFDLENBQUM7RUFDckQsR0FBTyxNQUFNLE9BQU8sQ0FBQztFQUVyQixJQUFJLFlBQVksR0FBRztHQUVqQixNQUFNLFFBQVEsUUFBUSxPQUFPLE1BQU07R0FDbkMsTUFBTSxNQUFNLFFBQVEsT0FBTyxNQUFNO0dBQ2pDLE1BQU0sRUFBRSxDQUFDLE1BQU0sT0FBTyxPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxHQUFHO0dBQzNDLE1BQU0sRUFBRSxDQUFDLE9BQU8sTUFBTTtHQUN0QixNQUFNLEVBQUUsQ0FBQyxjQUFjLFVBQVU7R0FHakMsSUFBSSxNQUFNLEtBQUssTUFBTSxLQUFLLEdBQUc7SUFDM0IsTUFBTSxJQUFJLE1BQU0sS0FBSztJQUNyQixNQUFNLElBQUksTUFBTSxLQUFLLE1BQU0sS0FBSztJQUNoQyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQztHQUNsQjtFQUNGO0VBRUEsSUFBSSxJQUFJLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztHQUFDO0dBQVE7R0FBWTtFQUFPLENBQUMsQ0FBQztDQUMxRDtDQVNBLElBQUksV0FBVyxLQUFBLEdBQVc7RUFDeEIsYUFBYSxNQUFNLE9BQU8sT0FBTyxDQUFDLEdBQUcsU0FBUyxRQUFRLFFBQVEsTUFBTSxDQUFDO0VBQ3JFLElBQUksSUFBSSxRQUFRLEdBQUcsQ0FBQztHQUFDO0dBQVE7R0FBYztFQUFPLENBQUMsQ0FBQztFQUNwRCxlQUFlLEtBQUE7Q0FDakI7Q0FFQSxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7QUFZQSxTQUFTLGNBQWMsS0FBSyxTQUFTLE9BQU8sT0FBTyxXQUFXOztDQUU1RCxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sVUFBVSxTQUFTLFFBQVEsUUFBUSxLQUFLO0NBRTlDLElBQUksV0FBVztFQUNiLFVBQVUsTUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU87RUFDekMsTUFBTSxLQUFLO0dBQUM7R0FBUTtHQUFXO0VBQU8sQ0FBQztDQUN6QztDQUVBLE1BQU0sTUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU87Q0FDckMsTUFBTSxLQUFLO0VBQUM7RUFBUTtFQUFPO0NBQU8sQ0FBQztDQUVuQyxJQUFJLElBQUksUUFBUSxHQUFHLEdBQUcsS0FBSztBQUM3Qjs7Ozs7O0FBT0EsU0FBUyxTQUFTLFFBQVEsT0FBTztDQUMvQixNQUFNLFFBQVEsT0FBTztDQUNyQixNQUFNLE9BQU8sTUFBTSxPQUFPLFVBQVUsVUFBVTtDQUM5QyxPQUFPLE1BQU0sRUFBRSxDQUFDO0FBQ2xCOzs7Ozs7QUMvNUJBLElBQU0sZ0JBQWdCO0NBQUMsTUFBTTtDQUFpQixVQUFVO0FBQXFCOzs7Ozs7Ozs7QUFVN0UsU0FBZ0Isa0JBQWtCO0NBQ2hDLE9BQU8sRUFDTCxNQUFNLEdBQUUsTUFBTSxvQkFBb0IsY0FBYSxFQUNqRDtBQUNGOzs7OztBQU1BLFNBQVMsc0JBQXNCLFNBQVMsTUFBSSxLQUFLO0NBQy9DLE1BQU0sT0FBTztDQUViLE9BQU87Ozs7Ozs7Ozs7O0NBWVAsU0FBUyxLQUFLLE1BQU07RUFDbEIsR0FBTyxTQUFTLE1BQU0sbUJBQW1CLGNBQWM7RUFFdkQsSUFFRSxLQUFLLGFBQWEsTUFBTSxPQUd4QixDQUFDLEtBQUssb0NBRU4sT0FBTyxJQUFJLElBQUk7RUFHakIsUUFBUSxNQUFNLGVBQWU7RUFDN0IsUUFBUSxNQUFNLHFCQUFxQjtFQUNuQyxRQUFRLFFBQVEsSUFBSTtFQUNwQixRQUFRLEtBQUsscUJBQXFCO0VBQ2xDLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Q0FZQSxTQUFTLE9BQU8sTUFBTTtFQUlwQixJQUFJLDBCQUEwQixJQUFJLEdBQUc7R0FDbkMsUUFBUSxNQUFNLDZCQUE2QjtHQUMzQyxRQUFRLFFBQVEsSUFBSTtHQUNwQixRQUFRLEtBQUssNkJBQTZCO0dBQzFDLE9BQU87RUFDVDtFQUVBLElBQUksU0FBUyxNQUFNLGNBQWMsU0FBUyxNQUFNLFlBQVk7R0FDMUQsUUFBUSxNQUFNLDJCQUEyQjtHQUN6QyxRQUFRLFFBQVEsSUFBSTtHQUNwQixRQUFRLEtBQUssMkJBQTJCO0dBQ3hDLE9BQU87RUFDVDtFQUVBLE9BQU8sSUFBSSxJQUFJO0NBQ2pCOzs7Ozs7Ozs7OztDQVlBLFNBQVMsTUFBTSxNQUFNO0VBQ25CLElBQUksU0FBUyxNQUFNLG9CQUFvQjtHQUNyQyxRQUFRLE1BQU0scUJBQXFCO0dBQ25DLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLFFBQVEsS0FBSyxxQkFBcUI7R0FDbEMsUUFBUSxLQUFLLGVBQWU7R0FDNUIsT0FBTztFQUNUO0VBRUEsT0FBTyxJQUFJLElBQUk7Q0FDakI7Ozs7Q0FLQSxTQUFTLE1BQU0sTUFBTTtFQUVuQixJQUFJLG1CQUFtQixJQUFJLEdBQ3pCLE9BQU9DLEtBQUcsSUFBSTtFQUtoQixJQUFJLGNBQWMsSUFBSSxHQUNwQixPQUFPLFFBQVEsTUFBTSxFQUFDLFVBQVUsa0JBQWlCLEdBQUdBLE1BQUksR0FBRyxDQUFDLENBQUMsSUFBSTtFQUluRSxPQUFPLElBQUksSUFBSTtDQUNqQjtBQUNGOzs7OztBQU1BLFNBQVMsa0JBQWtCLFNBQVMsSUFBSSxLQUFLO0NBQzNDLE9BQU8sYUFBYSxTQUFTLE9BQU8sTUFBTSxVQUFVOzs7Ozs7Ozs7OztDQVlwRCxTQUFTLE1BQU0sTUFBTTtFQUtuQixPQUFPLFNBQVMsTUFBTSxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSTtDQUNqRDtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9IQSxTQUFnQixJQUFJLFNBQVM7Q0FDM0IsT0FBTyxrQkFBa0I7RUFDdkIsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixpQkFBaUIsT0FBTztFQUN4QixTQUFTO0VBQ1QsZ0JBQWdCO0NBQ2xCLENBQUM7QUFDSDs7Ozs7Ozs7Ozs7QUNsQ0EsSUFBTSxlQUFlLENBQUM7Ozs7Ozs7Ozs7QUFXdEIsU0FBd0IsVUFBVSxTQUFTO0NBR3pDLE1BQU0sT0FBdUM7Q0FDN0MsTUFBTSxXQUFXLFdBQVc7Q0FDNUIsTUFBTSxPQUFPLEtBQUssS0FBSztDQUV2QixNQUFNLHNCQUNKLEtBQUssd0JBQXdCLEtBQUssc0JBQXNCLENBQUM7Q0FDM0QsTUFBTSx5QkFDSixLQUFLLDJCQUEyQixLQUFLLHlCQUF5QixDQUFDO0NBQ2pFLE1BQU0sdUJBQ0osS0FBSyx5QkFBeUIsS0FBSyx1QkFBdUIsQ0FBQztDQUU3RCxvQkFBb0IsS0FBSyxJQUFJLFFBQVEsQ0FBQztDQUN0Qyx1QkFBdUIsS0FBSyxnQkFBZ0IsQ0FBQztDQUM3QyxxQkFBcUIsS0FBSyxjQUFjLFFBQVEsQ0FBQztBQUNuRCIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyLDUzLDU0LDU1XX0=