import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=076f3cfd";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=cdd924ad";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=cdd924ad";
import { T as useIsoLayoutEffect, c as useStableCallback, d as EMPTY_ARRAY$1, f as EMPTY_OBJECT, i as useRenderElement, m as useRefWithInit, p as NOOP, r as error, t as CompositeRootContext, u as useMergedRefs } from "/node_modules/.vite/deps/CompositeRootContext-D1Svtiq7.js?v=076f3cfd";
import { a as COMPOSITE_KEYS, c as SHIFT, d as findNonDisabledListIndex, f as getMaxListIndex, g as isListIndexDisabled, h as isIndexOutOfListBounds, i as ARROW_UP, l as isNativeInput, n as ARROW_LEFT, p as getMinListIndex, r as ARROW_RIGHT, s as MODIFIER_KEYS$1, t as ARROW_DOWN, u as scrollIntoViewIfNeeded, v as contains, y as getTarget } from "/node_modules/.vite/deps/composite-Bo6ZVhSW.js?v=076f3cfd";
import { t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-B8kiyj7L.js?v=076f3cfd";
import { a as CompositeListContext, c as DEFAULT_VALIDITY_STATE, i as useFieldRootContext, l as fieldValidityMapping, r as useLabelableContext, t as RadioGroupContext } from "/node_modules/.vite/deps/RadioGroupContext-Cpb2051b.js?v=076f3cfd";
//#region node_modules/@base-ui/react/internals/useValueChanged.mjs
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function useValueChanged(value, onChange) {
	const valueRef = import_react.useRef(value);
	const onChangeCallback = useStableCallback(onChange);
	useIsoLayoutEffect(() => {
		if (valueRef.current !== value) onChangeCallback(valueRef.current);
		valueRef.current = value;
	}, [value, onChangeCallback]);
}
//#endregion
//#region node_modules/@base-ui/utils/useControlled.mjs
function useControlled({ controlled, default: defaultProp, name, state = "value" }) {
	const { current: isControlled } = import_react.useRef(controlled !== void 0);
	const [valueState, setValue] = import_react.useState(defaultProp);
	const value = isControlled ? controlled : valueState;
	{
		import_react.useEffect(() => {
			if (isControlled !== (controlled !== void 0)) error([
				`A component is changing the ${isControlled ? "" : "un"}controlled ${state} state of ${name} to be ${isControlled ? "un" : ""}controlled.`,
				"Elements should not switch from uncontrolled to controlled (or vice versa).",
				`Decide between using a controlled or uncontrolled ${name} element for the lifetime of the component.`,
				"The nature of the state is determined during the first render. It's considered controlled if the value is not `undefined`.",
				"More info: https://fb.me/react-controlled-components"
			].join("\n"));
		}, [
			state,
			name,
			controlled
		]);
		const { current: defaultValue } = import_react.useRef(defaultProp);
		import_react.useEffect(() => {
			if (!isControlled && serializeToDevModeString(defaultValue) !== serializeToDevModeString(defaultProp)) error([`A component is changing the default ${state} state of an uncontrolled ${name} after being initialized. To suppress this warning opt to use a controlled ${name}.`].join("\n"));
		}, [defaultProp]);
	}
	return [value, import_react.useCallback((newValue) => {
		if (!isControlled) setValue(newValue);
	}, [])];
}
function serializeToDevModeString(input) {
	let nextId = 0;
	const seen = /* @__PURE__ */ new WeakMap();
	try {
		return JSON.stringify(input, function replacer(key, value) {
			if (key === "_owner" && this != null && typeof this === "object" && "$$typeof" in this) return;
			if (typeof value === "bigint") return `__bigint__:${value}`;
			if (value !== null && typeof value === "object") {
				const id = seen.get(value);
				if (id !== void 0) return `__object__:${id}`;
				seen.set(value, nextId);
				nextId += 1;
			}
			return value;
		}) ?? `__top__:${typeof input}`;
	} catch {
		return "__unserializable__";
	}
}
//#endregion
//#region node_modules/@base-ui/react/internals/composite/list/CompositeList.mjs
/**
* Provides context for a list of items in a composite component.
*/
function CompositeList(props) {
	const { children, elementsRef, labelsRef, onMapChange: onMapChangeProp } = props;
	const onMapChange = useStableCallback(onMapChangeProp);
	const [, setMapTick] = import_react.useState(false);
	const listeners = useRefWithInit(createListeners).current;
	const map = useRefWithInit(createMap).current;
	const nextIndexRef = import_react.useRef(0);
	const isDirtyRef = import_react.useRef(true);
	const itemsRef = import_react.useRef([]);
	const mutationObserverRef = import_react.useRef(null);
	const scheduleMapUpdate = useStableCallback(() => {
		if (isDirtyRef.current) return;
		isDirtyRef.current = true;
		setMapTick((tick) => !tick);
	});
	const register = useStableCallback((node, registration) => {
		map.set(node, registration);
		scheduleMapUpdate();
	});
	const unregister = useStableCallback((node) => {
		map.delete(node);
		scheduleMapUpdate();
	});
	const syncRefs = useStableCallback((items) => {
		const nextMap = /* @__PURE__ */ new Map();
		elementsRef.current.length = 0;
		if (labelsRef) labelsRef.current.length = 0;
		items.forEach((item) => {
			nextMap.set(item.element, {
				...item.registration.metadata ?? {},
				index: item.index
			});
			elementsRef.current[item.index] = item.element;
			if (labelsRef) labelsRef.current[item.index] = item.registration.label !== void 0 ? item.registration.label : item.registration.textRef?.current?.textContent ?? item.element.textContent;
		});
		nextIndexRef.current = elementsRef.current.length;
		return nextMap;
	});
	function observe(sortedNodes) {
		mutationObserverRef.current?.disconnect();
		mutationObserverRef.current = null;
		if (typeof MutationObserver !== "function" || sortedNodes.length < 2) return;
		const mutationObserver = new MutationObserver((entries) => {
			if (!hasMovedNode(entries)) return;
			let previousConnectedNode = null;
			for (const node of sortedNodes) {
				if (!node.isConnected) continue;
				if (previousConnectedNode && sortByDocumentPosition(previousConnectedNode, node) > 0) {
					mutationObserver.disconnect();
					scheduleMapUpdate();
					return;
				}
				previousConnectedNode = node;
			}
		});
		mutationObserverRef.current = mutationObserver;
		const roots = /* @__PURE__ */ new Set();
		for (let i = 1; i < sortedNodes.length; i += 1) {
			const root = getCommonAncestor(sortedNodes[i - 1], sortedNodes[i]);
			if (root) roots.add(root);
		}
		roots.forEach((root) => mutationObserver.observe(root, { childList: true }));
	}
	const flush = useStableCallback(() => {
		const [items, automaticNodes] = getCompositeListSnapshot(map);
		const nextMap = syncRefs(items);
		observe(automaticNodes);
		itemsRef.current = items;
		isDirtyRef.current = false;
		listeners.forEach((listener) => listener(nextMap));
		onMapChange(nextMap);
	});
	useIsoLayoutEffect(() => {
		if (!isDirtyRef.current) syncRefs(itemsRef.current);
		return () => {
			elementsRef.current = [];
			if (labelsRef) labelsRef.current = [];
		};
	}, [
		elementsRef,
		labelsRef,
		syncRefs
	]);
	useIsoLayoutEffect(() => {
		if (isDirtyRef.current) flush();
	});
	useIsoLayoutEffect(() => {
		return () => {
			mutationObserverRef.current?.disconnect();
			isDirtyRef.current = true;
		};
	}, []);
	const subscribeMapChange = useStableCallback((fn) => {
		listeners.add(fn);
		return () => {
			listeners.delete(fn);
		};
	});
	const contextValue = import_react.useMemo(() => ({
		register,
		unregister,
		subscribeMapChange,
		nextIndexRef
	}), [
		register,
		unregister,
		subscribeMapChange,
		nextIndexRef
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeListContext.Provider, {
		value: contextValue,
		children
	});
}
function createMap() {
	return /* @__PURE__ */ new Map();
}
function createListeners() {
	return /* @__PURE__ */ new Set();
}
function getCompositeListSnapshot(map) {
	const reservedIndices = /* @__PURE__ */ new Set();
	const items = [];
	const automaticItems = [];
	map.forEach((registration, node) => {
		if (!node.isConnected) return;
		const index = registration.index;
		const item = {
			index: index ?? -1,
			element: node,
			registration
		};
		if (index === null) automaticItems.push(item);
		else if (index >= 0) {
			reservedIndices.add(index);
			items.push(item);
		}
	});
	let nextAutomaticIndex = 0;
	automaticItems.sort((a, b) => sortByDocumentPosition(a.element, b.element));
	automaticItems.forEach((item) => {
		while (reservedIndices.has(nextAutomaticIndex)) nextAutomaticIndex += 1;
		item.index = nextAutomaticIndex;
		items.push(item);
		nextAutomaticIndex += 1;
	});
	if (reservedIndices.size > 0) items.sort((a, b) => a.index - b.index);
	return [items, automaticItems.map((item) => item.element)];
}
function getCommonAncestor(firstNode, lastNode) {
	let ancestor = firstNode.parentElement;
	while (ancestor && !ancestor.contains(lastNode)) ancestor = ancestor.parentElement;
	return ancestor;
}
function hasMovedNode(entries) {
	for (const entry of entries) for (let i = 0; i < entry.removedNodes.length; i += 1) if (entry.removedNodes[i].isConnected) return true;
	return false;
}
function sortByDocumentPosition(a, b) {
	return a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}
//#endregion
//#region node_modules/@base-ui/utils/isElementDisabled.mjs
function isElementDisabled(element) {
	return element == null || element.hasAttribute("disabled") || element.getAttribute("aria-disabled") === "true";
}
//#endregion
//#region node_modules/@base-ui/react/internals/composite/root/useCompositeRoot.mjs
var EMPTY_ARRAY = [];
function useCompositeRoot(params) {
	const { loopFocus = true, orientation = "both", grid, onLoop, direction, highlightedIndex: externalHighlightedIndex, onHighlightedIndexChange: externalSetHighlightedIndex, rootRef: externalRef, enableHomeAndEndKeys = false, stopEventPropagation, disabledIndices, modifierKeys = EMPTY_ARRAY } = params;
	const [internalHighlightedIndex, internalSetHighlightedIndex] = import_react.useState(0);
	const isGrid = grid != null;
	const rootRef = import_react.useRef(null);
	const mergedRef = useMergedRefs(rootRef, externalRef);
	const elementsRef = import_react.useRef([]);
	const hasSetDefaultIndexRef = import_react.useRef(false);
	const highlightedIndex = externalHighlightedIndex ?? internalHighlightedIndex;
	const onHighlightedIndexChange = useStableCallback((index, shouldScrollIntoView = false) => {
		(externalSetHighlightedIndex ?? internalSetHighlightedIndex)(index);
		if (shouldScrollIntoView) {
			const newActiveItem = elementsRef.current[index];
			scrollIntoViewIfNeeded(rootRef.current, newActiveItem, direction, orientation);
		}
	});
	const onMapChange = useStableCallback((map) => {
		if (map.size === 0 || hasSetDefaultIndexRef.current) return;
		hasSetDefaultIndexRef.current = true;
		const sortedElements = Array.from(map.keys());
		const activeItem = sortedElements.find((compositeElement) => compositeElement?.hasAttribute("data-composite-item-active")) ?? null;
		const activeIndex = activeItem ? map.get(activeItem)?.index ?? -1 : -1;
		if (activeIndex !== -1) onHighlightedIndexChange(activeIndex);
		else if (isListIndexDisabled(sortedElements, highlightedIndex, disabledIndices)) {
			const firstEnabledIndex = findNonDisabledListIndex(sortedElements, { disabledIndices });
			if (!isIndexOutOfListBounds(sortedElements, firstEnabledIndex)) onHighlightedIndexChange(firstEnabledIndex);
		}
		scrollIntoViewIfNeeded(rootRef.current, activeItem, direction, orientation);
	});
	useIsoLayoutEffect(() => {
		if (disabledIndices == null || externalHighlightedIndex != null || !hasSetDefaultIndexRef.current) return;
		const elements = elementsRef.current;
		if (isListIndexDisabled(elements, highlightedIndex, disabledIndices)) {
			const firstEnabledIndex = findNonDisabledListIndex(elements, { disabledIndices });
			if (!isIndexOutOfListBounds(elements, firstEnabledIndex)) onHighlightedIndexChange(firstEnabledIndex);
		}
	}, [
		disabledIndices,
		externalHighlightedIndex,
		highlightedIndex,
		elementsRef,
		onHighlightedIndexChange
	]);
	const wrappedOnLoop = useStableCallback((event, prevIndex, nextIndex) => {
		if (!onLoop) return nextIndex;
		return onLoop(event, prevIndex, nextIndex, elementsRef);
	});
	const onKeyDown = useStableCallback((event) => {
		const isHomeOrEnd = event.key === "Home" || event.key === "End";
		if (!COMPOSITE_KEYS.has(event.key) || !enableHomeAndEndKeys && isHomeOrEnd) return;
		if (isModifierKeySet(event, modifierKeys)) return;
		if (!rootRef.current) return;
		const isRtl = direction === "rtl";
		const horizontalForwardKey = isRtl ? ARROW_LEFT : ARROW_RIGHT;
		const horizontalBackwardKey = isRtl ? ARROW_RIGHT : ARROW_LEFT;
		const forwardKey = orientation === "vertical" ? ARROW_DOWN : horizontalForwardKey;
		const backwardKey = orientation === "vertical" ? ARROW_UP : horizontalBackwardKey;
		const target = getTarget(event.nativeEvent);
		if (target != null && isNativeInput(target) && !isElementDisabled(target)) {
			const selectionStart = target.selectionStart;
			const selectionEnd = target.selectionEnd;
			const textContent = target.value;
			if (selectionStart == null || event.shiftKey || selectionStart !== selectionEnd) return;
			if (event.key !== backwardKey && selectionStart < textContent.length) return;
			if (event.key !== forwardKey && selectionStart > 0) return;
		}
		let nextIndex = highlightedIndex;
		const minIndex = getMinListIndex(elementsRef, disabledIndices);
		const maxIndex = getMaxListIndex(elementsRef, disabledIndices);
		if (grid != null) nextIndex = grid({
			disabledIndices,
			elementsRef,
			event,
			highlightedIndex,
			loopFocus,
			maxIndex,
			minIndex,
			onLoop: wrappedOnLoop,
			orientation,
			rtl: isRtl
		});
		const isForwardKey = orientation !== "vertical" && event.key === horizontalForwardKey || orientation !== "horizontal" && event.key === "ArrowDown";
		const isBackwardKey = orientation !== "vertical" && event.key === horizontalBackwardKey || orientation !== "horizontal" && event.key === "ArrowUp";
		if (enableHomeAndEndKeys) {
			if (event.key === "Home") nextIndex = minIndex;
			else if (event.key === "End") nextIndex = maxIndex;
		}
		if (nextIndex === highlightedIndex && (isForwardKey || isBackwardKey)) {
			if (loopFocus && nextIndex === maxIndex && isForwardKey) {
				nextIndex = minIndex;
				if (onLoop) nextIndex = onLoop(event, highlightedIndex, nextIndex, elementsRef);
			} else if (loopFocus && nextIndex === minIndex && isBackwardKey) {
				nextIndex = maxIndex;
				if (onLoop) nextIndex = onLoop(event, highlightedIndex, nextIndex, elementsRef);
			} else nextIndex = findNonDisabledListIndex(elementsRef.current, {
				startingIndex: nextIndex,
				decrement: isBackwardKey,
				disabledIndices
			});
		}
		if (nextIndex !== highlightedIndex && !isIndexOutOfListBounds(elementsRef.current, nextIndex)) {
			if (stopEventPropagation) event.stopPropagation();
			if (isGrid || isHomeOrEnd || isForwardKey || isBackwardKey) event.preventDefault();
			onHighlightedIndexChange(nextIndex, true);
			queueMicrotask(() => {
				elementsRef.current[nextIndex]?.focus();
			});
		}
	});
	return {
		props: {
			ref: mergedRef,
			onFocus(event) {
				const element = rootRef.current;
				const target = getTarget(event.nativeEvent);
				if (!element || target == null || !isNativeInput(target)) return;
				target.setSelectionRange(0, target.value.length);
			},
			onKeyDown
		},
		highlightedIndex,
		onHighlightedIndexChange,
		elementsRef,
		onMapChange,
		relayKeyboardEvent: onKeyDown
	};
}
function isModifierKeySet(event, ignoredModifierKeys) {
	for (const key of MODIFIER_KEYS$1) {
		if (ignoredModifierKeys.includes(key)) continue;
		if (event.getModifierState(key)) return true;
	}
	return false;
}
//#endregion
//#region node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs
var DirectionContext = /*#__PURE__*/ import_react.createContext(void 0);
DirectionContext.displayName = "DirectionContext";
function useDirection() {
	return import_react.useContext(DirectionContext)?.direction ?? "ltr";
}
//#endregion
//#region node_modules/@base-ui/react/internals/composite/root/CompositeRoot.mjs
function CompositeRoot(componentProps) {
	const { render, className, style, refs = EMPTY_ARRAY$1, props = EMPTY_ARRAY$1, state = EMPTY_OBJECT, stateAttributesMapping, highlightedIndex: highlightedIndexProp, onHighlightedIndexChange: onHighlightedIndexChangeProp, orientation, grid, loopFocus, onLoop, enableHomeAndEndKeys, onMapChange: onMapChangeProp, stopEventPropagation = true, rootRef, disabledIndices, modifierKeys, highlightItemOnHover = false, tag = "div", ...elementProps } = componentProps;
	const { props: defaultProps, highlightedIndex, onHighlightedIndexChange, elementsRef, onMapChange: onMapChangeUnwrapped, relayKeyboardEvent } = useCompositeRoot({
		grid,
		loopFocus,
		onLoop,
		orientation,
		highlightedIndex: highlightedIndexProp,
		onHighlightedIndexChange: onHighlightedIndexChangeProp,
		rootRef,
		stopEventPropagation,
		enableHomeAndEndKeys,
		direction: useDirection(),
		disabledIndices,
		modifierKeys
	});
	const element = useRenderElement(tag, componentProps, {
		state,
		ref: refs,
		props: [
			defaultProps,
			...props,
			elementProps
		],
		stateAttributesMapping
	});
	const contextValue = import_react.useMemo(() => ({
		highlightedIndex,
		onHighlightedIndexChange,
		highlightItemOnHover,
		relayKeyboardEvent
	}), [
		highlightedIndex,
		onHighlightedIndexChange,
		highlightItemOnHover,
		relayKeyboardEvent
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeRootContext.Provider, {
		value: contextValue,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeList, {
			elementsRef,
			onMapChange: (newMap) => {
				onMapChangeProp?.(newMap);
				onMapChangeUnwrapped(newMap);
			},
			children: element
		})
	});
}
//#endregion
//#region node_modules/@base-ui/react/internals/field-register-control/useRegisterFieldControl.mjs
function useRegisterFieldControl(controlRef, id, value, getFormValueOverride, enabled = true, name) {
	const { registerFieldControl } = useFieldRootContext();
	const sourceRef = useRefWithInit(() => Symbol());
	useIsoLayoutEffect(() => {
		const source = sourceRef.current;
		if (!enabled) {
			registerFieldControl(source, void 0);
			return;
		}
		registerFieldControl(source, {
			controlRef,
			getValue: getFormValueOverride,
			id,
			name,
			value
		});
	}, [
		controlRef,
		enabled,
		getFormValueOverride,
		id,
		name,
		registerFieldControl,
		sourceRef,
		value
	]);
	useIsoLayoutEffect(() => {
		const source = sourceRef.current;
		return () => {
			registerFieldControl(source, void 0);
		};
	}, [registerFieldControl, sourceRef]);
}
//#endregion
//#region node_modules/@base-ui/react/internals/form-context/FormContext.mjs
var FormContext = /*#__PURE__*/ import_react.createContext({
	elementRef: { current: null },
	formRef: { current: { fields: /* @__PURE__ */ new Map() } },
	errors: {},
	clearErrors: NOOP,
	validationMode: "onSubmit",
	submitAttemptedRef: { current: false }
});
FormContext.displayName = "FormContext";
function useFormContext() {
	return import_react.useContext(FormContext);
}
Object.keys(DEFAULT_VALIDITY_STATE);
/**
* Whether an input participates in the surrounding Base UI Form. Inputs that are effectively
* disabled, or whose `form` attribute explicitly associates them with another form, are excluded.
* DOM position only matters when it associates the input with a different form. Otherwise, field
* registration is context-driven, so portaled inputs (for example inside a dialog) still belong to
* the form for both validation and values projected into `onFormSubmit`.
*/
function isEligibleInput(input, formElement) {
	if (input.matches(":disabled")) return false;
	if (!formElement || input.form === formElement) return true;
	return input.form === null && !input.hasAttribute("form");
}
//#endregion
//#region node_modules/@base-ui/react/fieldset/root/FieldsetRootContext.mjs
var FieldsetRootContext = /*#__PURE__*/ import_react.createContext(void 0);
FieldsetRootContext.displayName = "FieldsetRootContext";
function useFieldsetRootContext(optional = false) {
	const context = import_react.useContext(FieldsetRootContext);
	if (!context && !optional) throw new Error("Base UI: FieldsetRootContext is missing. Fieldset parts must be placed within <Fieldset.Root>.");
	return context;
}
//#endregion
//#region node_modules/@base-ui/react/radio-group/RadioGroup.mjs
var MODIFIER_KEYS = [SHIFT];
/**
* Provides a shared state to a series of radio buttons.
* Renders a `<div>` element.
*
* Documentation: [Base UI Radio Group](https://base-ui.com/react/components/radio)
*/
var RadioGroup = /*#__PURE__*/ import_react.forwardRef(function RadioGroup(componentProps, forwardedRef) {
	const { render, className, disabled: disabledProp, readOnly, required, onValueChange: onValueChangeProp, value: externalValue, defaultValue, form, name: nameProp, inputRef: inputRefProp, id: idProp, style, ...elementProps } = componentProps;
	const { setTouched: setFieldTouched, setFocused, validationMode, name: fieldName, disabled: fieldDisabled, state: fieldState, validation, setDirty, setFilled, validityData } = useFieldRootContext();
	const { labelId } = useLabelableContext();
	const { clearErrors, elementRef } = useFormContext();
	const fieldsetContext = useFieldsetRootContext(true);
	const disabled = fieldDisabled || disabledProp;
	const name = fieldName ?? nameProp;
	const id = useBaseUiId(idProp);
	const [checkedValue, setCheckedValueUnwrapped] = useControlled({
		controlled: externalValue,
		default: defaultValue,
		name: "RadioGroup",
		state: "value"
	});
	const [touched, setTouched] = import_react.useState(false);
	const setCheckedValue = useStableCallback((value, eventDetails) => {
		onValueChangeProp?.(value, eventDetails);
		if (eventDetails.isCanceled) return;
		setCheckedValueUnwrapped(value);
	});
	const getInputControl = validation.getInputControl;
	const controlRef = import_react.useMemo(() => ({ get current() {
		return getInputControl();
	} }), [getInputControl]);
	const groupInputRef = import_react.useRef(null);
	const firstEnabledInputRef = import_react.useRef(null);
	function setInputRef(hiddenInput) {
		let cleanup = void 0;
		if (inputRefProp) {
			if (typeof inputRefProp === "function") cleanup = inputRefProp(hiddenInput);
			else inputRefProp.current = hiddenInput;
		}
		groupInputRef.current = hiddenInput;
		return cleanup;
	}
	const registerInputRef = useStableCallback((input) => {
		if (!input || input.disabled) return;
		if (!firstEnabledInputRef.current) firstEnabledInputRef.current = input;
		const currentInput = groupInputRef.current;
		const cleanup = input.checked || currentInput == null || currentInput.disabled ? setInputRef(input) : void 0;
		return () => {
			if (firstEnabledInputRef.current === input) firstEnabledInputRef.current = null;
			if (groupInputRef.current === input) {
				if (cleanup) {
					cleanup();
					groupInputRef.current = null;
				} else setInputRef(null);
			} else cleanup?.();
		};
	});
	const getFormValue = useStableCallback(() => {
		const formElement = elementRef.current;
		if (!formElement) return checkedValue ?? null;
		for (const input of validation.registeredInputs.keys()) if (input.checked && isEligibleInput(input, formElement)) return checkedValue ?? null;
		return null;
	});
	useRegisterFieldControl(controlRef, id, checkedValue ?? null, getFormValue, !disabled, nameProp);
	useValueChanged(checkedValue, () => {
		clearErrors(name);
		setDirty(checkedValue !== validityData.initialValue);
		setFilled(checkedValue != null);
		validation.change(checkedValue);
		const fallbackInput = firstEnabledInputRef.current;
		if (checkedValue == null && fallbackInput && !fallbackInput.disabled) setInputRef(fallbackInput);
	});
	const ariaLabelledby = labelId ?? fieldsetContext?.legendId;
	const state = {
		...fieldState,
		disabled: disabled ?? false,
		required: required ?? false,
		readOnly: readOnly ?? false
	};
	const contextValue = import_react.useMemo(() => ({
		checkedValue,
		disabled,
		form,
		validation,
		name,
		readOnly,
		registerInputRef,
		required,
		setCheckedValue,
		setTouched,
		touched
	}), [
		checkedValue,
		disabled,
		form,
		validation,
		name,
		readOnly,
		registerInputRef,
		required,
		setCheckedValue,
		setTouched,
		touched
	]);
	const defaultProps = {
		id: idProp,
		role: "radiogroup",
		"aria-required": required || void 0,
		"aria-disabled": disabled || void 0,
		"aria-readonly": readOnly || void 0,
		"aria-labelledby": ariaLabelledby,
		onFocus() {
			setFocused(true);
		},
		onBlur(event) {
			if (!contains(event.currentTarget, event.relatedTarget)) {
				setFieldTouched(true);
				setFocused(false);
				if (validationMode === "onBlur") validation.commit(checkedValue);
			}
		},
		onKeyDownCapture(event) {
			if (event.key.startsWith("Arrow")) {
				setTouched(true);
				setFocused(true);
			}
		}
	};
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(RadioGroupContext.Provider, {
		value: contextValue,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeRoot, {
			render,
			className,
			style,
			state,
			props: [
				defaultProps,
				elementProps,
				(props) => validation.getValidationProps(disabled ?? false, props)
			],
			refs: [forwardedRef],
			stateAttributesMapping: fieldValidityMapping,
			enableHomeAndEndKeys: false,
			modifierKeys: MODIFIER_KEYS
		})
	});
});
RadioGroup.displayName = "RadioGroup";
//#endregion
export { RadioGroup };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGJhc2UtdWlfcmVhY3RfcmFkaW8tZ3JvdXAuanMiLCJuYW1lcyI6WyJNT0RJRklFUl9LRVlTIiwiRU1QVFlfQVJSQVkiXSwic291cmNlcyI6WyIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvdXNlVmFsdWVDaGFuZ2VkLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZUNvbnRyb2xsZWQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2NvbXBvc2l0ZS9saXN0L0NvbXBvc2l0ZUxpc3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvaXNFbGVtZW50RGlzYWJsZWQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2NvbXBvc2l0ZS9yb290L3VzZUNvbXBvc2l0ZVJvb3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2RpcmVjdGlvbi1jb250ZXh0L0RpcmVjdGlvbkNvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2NvbXBvc2l0ZS9yb290L0NvbXBvc2l0ZVJvb3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2ZpZWxkLXJlZ2lzdGVyLWNvbnRyb2wvdXNlUmVnaXN0ZXJGaWVsZENvbnRyb2wubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2Zvcm0tY29udGV4dC9Gb3JtQ29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9maWVsZC9yb290L3VzZUZpZWxkVmFsaWRhdGlvbi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9maWVsZHNldC9yb290L0ZpZWxkc2V0Um9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvcmFkaW8tZ3JvdXAvUmFkaW9Hcm91cC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5leHBvcnQgZnVuY3Rpb24gdXNlVmFsdWVDaGFuZ2VkKHZhbHVlLCBvbkNoYW5nZSkge1xuICBjb25zdCB2YWx1ZVJlZiA9IFJlYWN0LnVzZVJlZih2YWx1ZSk7XG4gIGNvbnN0IG9uQ2hhbmdlQ2FsbGJhY2sgPSB1c2VTdGFibGVDYWxsYmFjayhvbkNoYW5nZSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHZhbHVlUmVmLmN1cnJlbnQgIT09IHZhbHVlKSB7XG4gICAgICBvbkNoYW5nZUNhbGxiYWNrKHZhbHVlUmVmLmN1cnJlbnQpO1xuICAgIH1cbiAgICB2YWx1ZVJlZi5jdXJyZW50ID0gdmFsdWU7XG4gIH0sIFt2YWx1ZSwgb25DaGFuZ2VDYWxsYmFja10pO1xufSIsIid1c2UgY2xpZW50JztcblxuLy8gVE9ETzogdW5jb21tZW50IG9uY2Ugd2UgZW5hYmxlIGVzbGludC1wbHVnaW4tcmVhY3QtY29tcGlsZXIgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWNvbXBpbGVyL3JlYWN0LWNvbXBpbGVyIC0tIHByb2Nlc3MuZW52IG5ldmVyIGNoYW5nZXMsIGRlcGVuZGVuY3kgYXJyYXlzIGFyZSBpbnRlbnRpb25hbGx5IGlnbm9yZWRcbi8qIGVzbGludC1kaXNhYmxlIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzLCByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHMgKi9cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGVycm9yIH0gZnJvbSBcIi4vZXJyb3IubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlQ29udHJvbGxlZCh7XG4gIGNvbnRyb2xsZWQsXG4gIGRlZmF1bHQ6IGRlZmF1bHRQcm9wLFxuICBuYW1lLFxuICBzdGF0ZSA9ICd2YWx1ZSdcbn0pIHtcbiAgLy8gaXNDb250cm9sbGVkIGlzIGlnbm9yZWQgaW4gdGhlIGhvb2sgZGVwZW5kZW5jeSBsaXN0cyBhcyBpdCBzaG91bGQgbmV2ZXIgY2hhbmdlLlxuICBjb25zdCB7XG4gICAgY3VycmVudDogaXNDb250cm9sbGVkXG4gIH0gPSBSZWFjdC51c2VSZWYoY29udHJvbGxlZCAhPT0gdW5kZWZpbmVkKTtcbiAgY29uc3QgW3ZhbHVlU3RhdGUsIHNldFZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlKGRlZmF1bHRQcm9wKTtcbiAgY29uc3QgdmFsdWUgPSBpc0NvbnRyb2xsZWQgPyBjb250cm9sbGVkIDogdmFsdWVTdGF0ZTtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKGlzQ29udHJvbGxlZCAhPT0gKGNvbnRyb2xsZWQgIT09IHVuZGVmaW5lZCkpIHtcbiAgICAgICAgZXJyb3IoW2BBIGNvbXBvbmVudCBpcyBjaGFuZ2luZyB0aGUgJHtpc0NvbnRyb2xsZWQgPyAnJyA6ICd1bid9Y29udHJvbGxlZCAke3N0YXRlfSBzdGF0ZSBvZiAke25hbWV9IHRvIGJlICR7aXNDb250cm9sbGVkID8gJ3VuJyA6ICcnfWNvbnRyb2xsZWQuYCwgJ0VsZW1lbnRzIHNob3VsZCBub3Qgc3dpdGNoIGZyb20gdW5jb250cm9sbGVkIHRvIGNvbnRyb2xsZWQgKG9yIHZpY2UgdmVyc2EpLicsIGBEZWNpZGUgYmV0d2VlbiB1c2luZyBhIGNvbnRyb2xsZWQgb3IgdW5jb250cm9sbGVkICR7bmFtZX0gYCArICdlbGVtZW50IGZvciB0aGUgbGlmZXRpbWUgb2YgdGhlIGNvbXBvbmVudC4nLCBcIlRoZSBuYXR1cmUgb2YgdGhlIHN0YXRlIGlzIGRldGVybWluZWQgZHVyaW5nIHRoZSBmaXJzdCByZW5kZXIuIEl0J3MgY29uc2lkZXJlZCBjb250cm9sbGVkIGlmIHRoZSB2YWx1ZSBpcyBub3QgYHVuZGVmaW5lZGAuXCIsICdNb3JlIGluZm86IGh0dHBzOi8vZmIubWUvcmVhY3QtY29udHJvbGxlZC1jb21wb25lbnRzJ10uam9pbignXFxuJykpO1xuICAgICAgfVxuICAgIH0sIFtzdGF0ZSwgbmFtZSwgY29udHJvbGxlZF0pO1xuICAgIGNvbnN0IHtcbiAgICAgIGN1cnJlbnQ6IGRlZmF1bHRWYWx1ZVxuICAgIH0gPSBSZWFjdC51c2VSZWYoZGVmYXVsdFByb3ApO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAoIWlzQ29udHJvbGxlZCAmJiBzZXJpYWxpemVUb0Rldk1vZGVTdHJpbmcoZGVmYXVsdFZhbHVlKSAhPT0gc2VyaWFsaXplVG9EZXZNb2RlU3RyaW5nKGRlZmF1bHRQcm9wKSkge1xuICAgICAgICBlcnJvcihbYEEgY29tcG9uZW50IGlzIGNoYW5naW5nIHRoZSBkZWZhdWx0ICR7c3RhdGV9IHN0YXRlIG9mIGFuIHVuY29udHJvbGxlZCAke25hbWV9IGFmdGVyIGJlaW5nIGluaXRpYWxpemVkLiBgICsgYFRvIHN1cHByZXNzIHRoaXMgd2FybmluZyBvcHQgdG8gdXNlIGEgY29udHJvbGxlZCAke25hbWV9LmBdLmpvaW4oJ1xcbicpKTtcbiAgICAgIH1cbiAgICB9LCBbZGVmYXVsdFByb3BdKTtcbiAgfVxuICBjb25zdCBzZXRWYWx1ZUlmVW5jb250cm9sbGVkID0gUmVhY3QudXNlQ2FsbGJhY2sobmV3VmFsdWUgPT4ge1xuICAgIGlmICghaXNDb250cm9sbGVkKSB7XG4gICAgICBzZXRWYWx1ZShuZXdWYWx1ZSk7XG4gICAgfVxuICB9LCBbXSk7XG4gIHJldHVybiBbdmFsdWUsIHNldFZhbHVlSWZVbmNvbnRyb2xsZWRdO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplVG9EZXZNb2RlU3RyaW5nKGlucHV0KSB7XG4gIGxldCBuZXh0SWQgPSAwO1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtNYXAoKTtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBKU09OLnN0cmluZ2lmeShpbnB1dCwgZnVuY3Rpb24gcmVwbGFjZXIoa2V5LCB2YWx1ZSkge1xuICAgICAgaWYgKGtleSA9PT0gJ19vd25lcicgJiYgdGhpcyAhPSBudWxsICYmIHR5cGVvZiB0aGlzID09PSAnb2JqZWN0JyAmJiAnJCR0eXBlb2YnIGluIHRoaXMpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdiaWdpbnQnKSB7XG4gICAgICAgIHJldHVybiBgX19iaWdpbnRfXzoke3ZhbHVlfWA7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUgIT09IG51bGwgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgICBjb25zdCBpZCA9IHNlZW4uZ2V0KHZhbHVlKTtcbiAgICAgICAgaWYgKGlkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICByZXR1cm4gYF9fb2JqZWN0X186JHtpZH1gO1xuICAgICAgICB9XG4gICAgICAgIHNlZW4uc2V0KHZhbHVlLCBuZXh0SWQpO1xuICAgICAgICBuZXh0SWQgKz0gMTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzdWx0ID8/IGBfX3RvcF9fOiR7dHlwZW9mIGlucHV0fWA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnX191bnNlcmlhbGl6YWJsZV9fJztcbiAgfVxufSIsIi8qIGVzbGludC1kaXNhYmxlIG5vLWJpdHdpc2UgKi9cbid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VSZWZXaXRoSW5pdCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBDb21wb3NpdGVMaXN0Q29udGV4dCB9IGZyb20gXCIuL0NvbXBvc2l0ZUxpc3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8qKlxuICogUHJvdmlkZXMgY29udGV4dCBmb3IgYSBsaXN0IG9mIGl0ZW1zIGluIGEgY29tcG9zaXRlIGNvbXBvbmVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIENvbXBvc2l0ZUxpc3QocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIGVsZW1lbnRzUmVmLFxuICAgIGxhYmVsc1JlZixcbiAgICBvbk1hcENoYW5nZTogb25NYXBDaGFuZ2VQcm9wXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qgb25NYXBDaGFuZ2UgPSB1c2VTdGFibGVDYWxsYmFjayhvbk1hcENoYW5nZVByb3ApO1xuICBjb25zdCBbLCBzZXRNYXBUaWNrXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgbGlzdGVuZXJzID0gdXNlUmVmV2l0aEluaXQoY3JlYXRlTGlzdGVuZXJzKS5jdXJyZW50O1xuICBjb25zdCBtYXAgPSB1c2VSZWZXaXRoSW5pdChjcmVhdGVNYXApLmN1cnJlbnQ7XG4gIGNvbnN0IG5leHRJbmRleFJlZiA9IFJlYWN0LnVzZVJlZigwKTtcbiAgY29uc3QgaXNEaXJ0eVJlZiA9IFJlYWN0LnVzZVJlZih0cnVlKTtcbiAgY29uc3QgaXRlbXNSZWYgPSBSZWFjdC51c2VSZWYoW10pO1xuICBjb25zdCBtdXRhdGlvbk9ic2VydmVyUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuXG4gIC8vIEl0ZW0gZWZmZWN0cyBjYW4gcnVuIHdpdGhvdXQgdGhlaXIgcGFyZW50IHJlbmRlcmluZy4gU2NoZWR1bGUgb25lIHN5bmNocm9ub3VzXG4gIC8vIHBhcmVudCB1cGRhdGUgZm9yIHRoZSB3aG9sZSBjb21taXQgc28gcmVmcyBhcmUgcmVidWlsdCBiZWZvcmUgcGFpbnQgYW5kIHdoaWxlXG4gIC8vIHRoZSBvcmlnaW5hdGluZyBSZWFjdCBldmVudCBpcyBzdGlsbCBpbnNpZGUgYGFjdCgpYCBpbiB0ZXN0cy5cbiAgY29uc3Qgc2NoZWR1bGVNYXBVcGRhdGUgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKGlzRGlydHlSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpc0RpcnR5UmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIHNldE1hcFRpY2sodGljayA9PiAhdGljayk7XG4gIH0pO1xuICBjb25zdCByZWdpc3RlciA9IHVzZVN0YWJsZUNhbGxiYWNrKChub2RlLCByZWdpc3RyYXRpb24pID0+IHtcbiAgICBtYXAuc2V0KG5vZGUsIHJlZ2lzdHJhdGlvbik7XG4gICAgc2NoZWR1bGVNYXBVcGRhdGUoKTtcbiAgfSk7XG4gIGNvbnN0IHVucmVnaXN0ZXIgPSB1c2VTdGFibGVDYWxsYmFjayhub2RlID0+IHtcbiAgICBtYXAuZGVsZXRlKG5vZGUpO1xuICAgIHNjaGVkdWxlTWFwVXBkYXRlKCk7XG4gIH0pO1xuICBjb25zdCBzeW5jUmVmcyA9IHVzZVN0YWJsZUNhbGxiYWNrKGl0ZW1zID0+IHtcbiAgICBjb25zdCBuZXh0TWFwID0gbmV3IE1hcCgpO1xuICAgIGVsZW1lbnRzUmVmLmN1cnJlbnQubGVuZ3RoID0gMDtcbiAgICBpZiAobGFiZWxzUmVmKSB7XG4gICAgICBsYWJlbHNSZWYuY3VycmVudC5sZW5ndGggPSAwO1xuICAgIH1cbiAgICBpdGVtcy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgbmV4dE1hcC5zZXQoaXRlbS5lbGVtZW50LCB7XG4gICAgICAgIC4uLihpdGVtLnJlZ2lzdHJhdGlvbi5tZXRhZGF0YSA/PyB7fSksXG4gICAgICAgIGluZGV4OiBpdGVtLmluZGV4XG4gICAgICB9KTtcbiAgICAgIGVsZW1lbnRzUmVmLmN1cnJlbnRbaXRlbS5pbmRleF0gPSBpdGVtLmVsZW1lbnQ7XG4gICAgICBpZiAobGFiZWxzUmVmKSB7XG4gICAgICAgIGxhYmVsc1JlZi5jdXJyZW50W2l0ZW0uaW5kZXhdID0gaXRlbS5yZWdpc3RyYXRpb24ubGFiZWwgIT09IHVuZGVmaW5lZCA/IGl0ZW0ucmVnaXN0cmF0aW9uLmxhYmVsIDogaXRlbS5yZWdpc3RyYXRpb24udGV4dFJlZj8uY3VycmVudD8udGV4dENvbnRlbnQgPz8gaXRlbS5lbGVtZW50LnRleHRDb250ZW50O1xuICAgICAgfVxuICAgIH0pO1xuICAgIG5leHRJbmRleFJlZi5jdXJyZW50ID0gZWxlbWVudHNSZWYuY3VycmVudC5sZW5ndGg7XG4gICAgcmV0dXJuIG5leHRNYXA7XG4gIH0pO1xuICBmdW5jdGlvbiBvYnNlcnZlKHNvcnRlZE5vZGVzKSB7XG4gICAgbXV0YXRpb25PYnNlcnZlclJlZi5jdXJyZW50Py5kaXNjb25uZWN0KCk7XG4gICAgbXV0YXRpb25PYnNlcnZlclJlZi5jdXJyZW50ID0gbnVsbDtcblxuICAgIC8vIEEgc2luZ2xlIGl0ZW0gY2FuJ3QgcmVvcmRlci5cbiAgICBpZiAodHlwZW9mIE11dGF0aW9uT2JzZXJ2ZXIgIT09ICdmdW5jdGlvbicgfHwgc29ydGVkTm9kZXMubGVuZ3RoIDwgMikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBtdXRhdGlvbk9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoZW50cmllcyA9PiB7XG4gICAgICAvLyBPbmx5IHZlcmlmeSB0aGUgb3JkZXIgYWZ0ZXIgYSBtb3ZlOiBhIG5vZGUgdGhhdCB3YXMgcmVtb3ZlZCBhbmQgbGF0ZXJcbiAgICAgIC8vIHJlLWFkZGVkIHdpdGhpbiB0aGUgc2FtZSBiYXRjaC4gQWRkaXRpb25zIGFuZCByZW1vdmFscyBhbG9uZSBjYW4ndFxuICAgICAgLy8gY2hhbmdlIHRoZSByZWxhdGl2ZSBvcmRlciBvZiB0aGUgcmVtYWluaW5nIGl0ZW1zLCBhbmQgaXRlbXMgdGhhdCBtb3VudFxuICAgICAgLy8gb3IgdW5tb3VudCByZS1zb3J0IHRocm91Z2ggYHJlZ2lzdGVyYC9gdW5yZWdpc3RlcmAuXG4gICAgICBpZiAoIWhhc01vdmVkTm9kZShlbnRyaWVzKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBsZXQgcHJldmlvdXNDb25uZWN0ZWROb2RlID0gbnVsbDtcblxuICAgICAgLy8gSWYgYW55IGNvbm5lY3RlZCBub2RlIG5vdyBhcHBlYXJzIGJlZm9yZSB0aGUgcHJldmlvdXMgY29ubmVjdGVkIG5vZGUsXG4gICAgICAvLyB3cmFwcGVycy9pdGVtcyBtb3ZlZCBhbmQgdGhlIGluZGV4IG1hcCBuZWVkcyB0byBiZSByZWJ1aWx0LlxuICAgICAgZm9yIChjb25zdCBub2RlIG9mIHNvcnRlZE5vZGVzKSB7XG4gICAgICAgIGlmICghbm9kZS5pc0Nvbm5lY3RlZCkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwcmV2aW91c0Nvbm5lY3RlZE5vZGUgJiYgc29ydEJ5RG9jdW1lbnRQb3NpdGlvbihwcmV2aW91c0Nvbm5lY3RlZE5vZGUsIG5vZGUpID4gMCkge1xuICAgICAgICAgIG11dGF0aW9uT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICAgIHNjaGVkdWxlTWFwVXBkYXRlKCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHByZXZpb3VzQ29ubmVjdGVkTm9kZSA9IG5vZGU7XG4gICAgICB9XG4gICAgfSk7XG4gICAgbXV0YXRpb25PYnNlcnZlclJlZi5jdXJyZW50ID0gbXV0YXRpb25PYnNlcnZlcjtcblxuICAgIC8vIEEgcmVvcmRlciB0aGF0IGNoYW5nZXMgaXRlbSBpbmRleGVzIG11c3QgaW52ZXJ0IGF0IGxlYXN0IG9uZSBhZGphY2VudCBwYWlyXG4gICAgLy8gZnJvbSB0aGUgcHJldmlvdXMgc29ydGVkIG9yZGVyLiBPYnNlcnZpbmcgZWFjaCBwYWlyJ3MgY29tbW9uIHBhcmVudCBjYXRjaGVzXG4gICAgLy8gYm90aCBkaXJlY3QgaXRlbSBtb3ZlcyBhbmQgYW5jZXN0b3Igd3JhcHBlciBtb3ZlcyBhdCB0aGUgYm91bmRhcnkuXG4gICAgY29uc3Qgcm9vdHMgPSBuZXcgU2V0KCk7XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBzb3J0ZWROb2Rlcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgY29uc3Qgcm9vdCA9IGdldENvbW1vbkFuY2VzdG9yKHNvcnRlZE5vZGVzW2kgLSAxXSwgc29ydGVkTm9kZXNbaV0pO1xuICAgICAgaWYgKHJvb3QpIHtcbiAgICAgICAgcm9vdHMuYWRkKHJvb3QpO1xuICAgICAgfVxuICAgIH1cbiAgICByb290cy5mb3JFYWNoKHJvb3QgPT4gbXV0YXRpb25PYnNlcnZlci5vYnNlcnZlKHJvb3QsIHtcbiAgICAgIGNoaWxkTGlzdDogdHJ1ZVxuICAgIH0pKTtcbiAgfVxuICBjb25zdCBmbHVzaCA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBbaXRlbXMsIGF1dG9tYXRpY05vZGVzXSA9IGdldENvbXBvc2l0ZUxpc3RTbmFwc2hvdChtYXApO1xuICAgIGNvbnN0IG5leHRNYXAgPSBzeW5jUmVmcyhpdGVtcyk7XG4gICAgb2JzZXJ2ZShhdXRvbWF0aWNOb2Rlcyk7XG4gICAgaXRlbXNSZWYuY3VycmVudCA9IGl0ZW1zO1xuICAgIGlzRGlydHlSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIGxpc3RlbmVycy5mb3JFYWNoKGxpc3RlbmVyID0+IGxpc3RlbmVyKG5leHRNYXApKTtcbiAgICBvbk1hcENoYW5nZShuZXh0TWFwKTtcbiAgfSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgLy8gUmUtY29weSB0aGUgbGFzdCBjb21taXR0ZWQgc25hcHNob3Qgd2hlbiB0aGUgcmVmIG9iamVjdHMgY2hhbmdlIG9yIFN0cmljdCBNb2RlIHJlcGxheXNcbiAgICAvLyBlZmZlY3RzIHdpdGhvdXQgcmVhdHRhY2hpbmcgY2FsbGJhY2sgcmVmcy5cbiAgICBpZiAoIWlzRGlydHlSZWYuY3VycmVudCkge1xuICAgICAgc3luY1JlZnMoaXRlbXNSZWYuY3VycmVudCk7XG4gICAgfVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBlbGVtZW50c1JlZi5jdXJyZW50ID0gW107XG4gICAgICBpZiAobGFiZWxzUmVmKSB7XG4gICAgICAgIGxhYmVsc1JlZi5jdXJyZW50ID0gW107XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2VsZW1lbnRzUmVmLCBsYWJlbHNSZWYsIHN5bmNSZWZzXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzRGlydHlSZWYuY3VycmVudCkge1xuICAgICAgZmx1c2goKTtcbiAgICB9XG4gIH0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBtdXRhdGlvbk9ic2VydmVyUmVmLmN1cnJlbnQ/LmRpc2Nvbm5lY3QoKTtcbiAgICAgIC8vIFJlYWN0IDE4IFN0cmljdCBNb2RlIHJlcGxheXMgZWZmZWN0cyB3aXRob3V0IHJlcGxheWluZyBjYWxsYmFjayByZWZzLlxuICAgICAgLy8gTWFyayB0aGUgcmV0YWluZWQgbWFwIGRpcnR5IHNvIHRoZSByZXBsYXkgcmVidWlsZHMgcmVmcyBhbmQgb2JzZXJ2YXRpb24uXG4gICAgICBpc0RpcnR5UmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH07XG4gIH0sIFtdKTtcbiAgY29uc3Qgc3Vic2NyaWJlTWFwQ2hhbmdlID0gdXNlU3RhYmxlQ2FsbGJhY2soZm4gPT4ge1xuICAgIGxpc3RlbmVycy5hZGQoZm4pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBsaXN0ZW5lcnMuZGVsZXRlKGZuKTtcbiAgICB9O1xuICB9KTtcbiAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHJlZ2lzdGVyLFxuICAgIHVucmVnaXN0ZXIsXG4gICAgc3Vic2NyaWJlTWFwQ2hhbmdlLFxuICAgIG5leHRJbmRleFJlZlxuICB9KSwgW3JlZ2lzdGVyLCB1bnJlZ2lzdGVyLCBzdWJzY3JpYmVNYXBDaGFuZ2UsIG5leHRJbmRleFJlZl0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goQ29tcG9zaXRlTGlzdENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogY29udGV4dFZhbHVlLFxuICAgIGNoaWxkcmVuOiBjaGlsZHJlblxuICB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZU1hcCgpIHtcbiAgcmV0dXJuIG5ldyBNYXAoKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUxpc3RlbmVycygpIHtcbiAgcmV0dXJuIG5ldyBTZXQoKTtcbn1cbmZ1bmN0aW9uIGdldENvbXBvc2l0ZUxpc3RTbmFwc2hvdChtYXApIHtcbiAgY29uc3QgcmVzZXJ2ZWRJbmRpY2VzID0gbmV3IFNldCgpO1xuICBjb25zdCBpdGVtcyA9IFtdO1xuICBjb25zdCBhdXRvbWF0aWNJdGVtcyA9IFtdO1xuICBtYXAuZm9yRWFjaCgocmVnaXN0cmF0aW9uLCBub2RlKSA9PiB7XG4gICAgaWYgKCFub2RlLmlzQ29ubmVjdGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGluZGV4ID0gcmVnaXN0cmF0aW9uLmluZGV4O1xuICAgIGNvbnN0IGl0ZW0gPSB7XG4gICAgICBpbmRleDogaW5kZXggPz8gLTEsXG4gICAgICBlbGVtZW50OiBub2RlLFxuICAgICAgcmVnaXN0cmF0aW9uXG4gICAgfTtcbiAgICBpZiAoaW5kZXggPT09IG51bGwpIHtcbiAgICAgIGF1dG9tYXRpY0l0ZW1zLnB1c2goaXRlbSk7XG4gICAgfSBlbHNlIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICByZXNlcnZlZEluZGljZXMuYWRkKGluZGV4KTtcbiAgICAgIGl0ZW1zLnB1c2goaXRlbSk7XG4gICAgfVxuICB9KTtcbiAgbGV0IG5leHRBdXRvbWF0aWNJbmRleCA9IDA7XG4gIGF1dG9tYXRpY0l0ZW1zLnNvcnQoKGEsIGIpID0+IHNvcnRCeURvY3VtZW50UG9zaXRpb24oYS5lbGVtZW50LCBiLmVsZW1lbnQpKTtcbiAgYXV0b21hdGljSXRlbXMuZm9yRWFjaChpdGVtID0+IHtcbiAgICB3aGlsZSAocmVzZXJ2ZWRJbmRpY2VzLmhhcyhuZXh0QXV0b21hdGljSW5kZXgpKSB7XG4gICAgICBuZXh0QXV0b21hdGljSW5kZXggKz0gMTtcbiAgICB9XG4gICAgaXRlbS5pbmRleCA9IG5leHRBdXRvbWF0aWNJbmRleDtcbiAgICBpdGVtcy5wdXNoKGl0ZW0pO1xuICAgIG5leHRBdXRvbWF0aWNJbmRleCArPSAxO1xuICB9KTtcbiAgaWYgKHJlc2VydmVkSW5kaWNlcy5zaXplID4gMCkge1xuICAgIGl0ZW1zLnNvcnQoKGEsIGIpID0+IGEuaW5kZXggLSBiLmluZGV4KTtcbiAgfVxuICByZXR1cm4gW2l0ZW1zLCBhdXRvbWF0aWNJdGVtcy5tYXAoaXRlbSA9PiBpdGVtLmVsZW1lbnQpXTtcbn1cbmZ1bmN0aW9uIGdldENvbW1vbkFuY2VzdG9yKGZpcnN0Tm9kZSwgbGFzdE5vZGUpIHtcbiAgbGV0IGFuY2VzdG9yID0gZmlyc3ROb2RlLnBhcmVudEVsZW1lbnQ7XG5cbiAgLy8gVGhlIGBwYXJlbnRFbGVtZW50YCB3YWxrIGNhbm5vdCBjcm9zcyBzaGFkb3cgYm91bmRhcmllcywgc28gdGhlIG5hdGl2ZVxuICAvLyBgY29udGFpbnNgIGlzIHN1ZmZpY2llbnQgaGVyZS5cbiAgd2hpbGUgKGFuY2VzdG9yICYmICFhbmNlc3Rvci5jb250YWlucyhsYXN0Tm9kZSkpIHtcbiAgICBhbmNlc3RvciA9IGFuY2VzdG9yLnBhcmVudEVsZW1lbnQ7XG4gIH1cbiAgcmV0dXJuIGFuY2VzdG9yO1xufVxuZnVuY3Rpb24gaGFzTW92ZWROb2RlKGVudHJpZXMpIHtcbiAgZm9yIChjb25zdCBlbnRyeSBvZiBlbnRyaWVzKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlbnRyeS5yZW1vdmVkTm9kZXMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgIGlmIChlbnRyeS5yZW1vdmVkTm9kZXNbaV0uaXNDb25uZWN0ZWQpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIHNvcnRCeURvY3VtZW50UG9zaXRpb24oYSwgYikge1xuICAvLyBgRE9DVU1FTlRfUE9TSVRJT05fQ09OVEFJTkVEX0JZYCBpcyBhbHdheXMgcmVwb3J0ZWQgYWxvbmdzaWRlIGBGT0xMT1dJTkdgLCBhbmQgYENPTlRBSU5TYFxuICAvLyBhbG9uZ3NpZGUgYFBSRUNFRElOR2AsIHNvIHRlc3RpbmcgYEZPTExPV0lOR2AgYWxvbmUgb3JkZXJzIHNpYmxpbmdzIGFuZCBuZXN0ZWQgaXRlbXMgYWxpa2UuXG4gIHJldHVybiBhLmNvbXBhcmVEb2N1bWVudFBvc2l0aW9uKGIpICYgTm9kZS5ET0NVTUVOVF9QT1NJVElPTl9GT0xMT1dJTkcgPyAtMSA6IDE7XG59IiwiZXhwb3J0IGZ1bmN0aW9uIGlzRWxlbWVudERpc2FibGVkKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGVsZW1lbnQgPT0gbnVsbCB8fCBlbGVtZW50Lmhhc0F0dHJpYnV0ZSgnZGlzYWJsZWQnKSB8fCBlbGVtZW50LmdldEF0dHJpYnV0ZSgnYXJpYS1kaXNhYmxlZCcpID09PSAndHJ1ZSc7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBpc0VsZW1lbnREaXNhYmxlZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2lzRWxlbWVudERpc2FibGVkJztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlTWVyZ2VkUmVmcyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZU1lcmdlZFJlZnMnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IENPTVBPU0lURV9LRVlTLCBBUlJPV19ET1dOLCBBUlJPV19MRUZULCBBUlJPV19SSUdIVCwgQVJST1dfVVAsIEVORCwgSE9NRSwgTU9ESUZJRVJfS0VZUywgZmluZE5vbkRpc2FibGVkTGlzdEluZGV4LCBnZXRNYXhMaXN0SW5kZXgsIGdldE1pbkxpc3RJbmRleCwgaXNMaXN0SW5kZXhEaXNhYmxlZCwgaXNJbmRleE91dE9mTGlzdEJvdW5kcywgaXNOYXRpdmVJbnB1dCwgc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCB9IGZyb20gXCIuLi9jb21wb3NpdGUubWpzXCI7XG5pbXBvcnQgeyBBQ1RJVkVfQ09NUE9TSVRFX0lURU0gfSBmcm9tIFwiLi4vY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgZ2V0VGFyZ2V0IH0gZnJvbSBcIi4uLy4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzLm1qc1wiO1xuY29uc3QgRU1QVFlfQVJSQVkgPSBbXTtcbmV4cG9ydCBmdW5jdGlvbiB1c2VDb21wb3NpdGVSb290KHBhcmFtcykge1xuICBjb25zdCB7XG4gICAgbG9vcEZvY3VzID0gdHJ1ZSxcbiAgICBvcmllbnRhdGlvbiA9ICdib3RoJyxcbiAgICBncmlkLFxuICAgIG9uTG9vcCxcbiAgICBkaXJlY3Rpb24sXG4gICAgaGlnaGxpZ2h0ZWRJbmRleDogZXh0ZXJuYWxIaWdobGlnaHRlZEluZGV4LFxuICAgIG9uSGlnaGxpZ2h0ZWRJbmRleENoYW5nZTogZXh0ZXJuYWxTZXRIaWdobGlnaHRlZEluZGV4LFxuICAgIHJvb3RSZWY6IGV4dGVybmFsUmVmLFxuICAgIGVuYWJsZUhvbWVBbmRFbmRLZXlzID0gZmFsc2UsXG4gICAgc3RvcEV2ZW50UHJvcGFnYXRpb24sXG4gICAgZGlzYWJsZWRJbmRpY2VzLFxuICAgIG1vZGlmaWVyS2V5cyA9IEVNUFRZX0FSUkFZXG4gIH0gPSBwYXJhbXM7XG4gIGNvbnN0IFtpbnRlcm5hbEhpZ2hsaWdodGVkSW5kZXgsIGludGVybmFsU2V0SGlnaGxpZ2h0ZWRJbmRleF0gPSBSZWFjdC51c2VTdGF0ZSgwKTtcbiAgY29uc3QgaXNHcmlkID0gZ3JpZCAhPSBudWxsO1xuICBjb25zdCByb290UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBtZXJnZWRSZWYgPSB1c2VNZXJnZWRSZWZzKHJvb3RSZWYsIGV4dGVybmFsUmVmKTtcbiAgY29uc3QgZWxlbWVudHNSZWYgPSBSZWFjdC51c2VSZWYoW10pO1xuICBjb25zdCBoYXNTZXREZWZhdWx0SW5kZXhSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBoaWdobGlnaHRlZEluZGV4ID0gZXh0ZXJuYWxIaWdobGlnaHRlZEluZGV4ID8/IGludGVybmFsSGlnaGxpZ2h0ZWRJbmRleDtcbiAgY29uc3Qgb25IaWdobGlnaHRlZEluZGV4Q2hhbmdlID0gdXNlU3RhYmxlQ2FsbGJhY2soKGluZGV4LCBzaG91bGRTY3JvbGxJbnRvVmlldyA9IGZhbHNlKSA9PiB7XG4gICAgKGV4dGVybmFsU2V0SGlnaGxpZ2h0ZWRJbmRleCA/PyBpbnRlcm5hbFNldEhpZ2hsaWdodGVkSW5kZXgpKGluZGV4KTtcbiAgICBpZiAoc2hvdWxkU2Nyb2xsSW50b1ZpZXcpIHtcbiAgICAgIGNvbnN0IG5ld0FjdGl2ZUl0ZW0gPSBlbGVtZW50c1JlZi5jdXJyZW50W2luZGV4XTtcbiAgICAgIHNjcm9sbEludG9WaWV3SWZOZWVkZWQocm9vdFJlZi5jdXJyZW50LCBuZXdBY3RpdmVJdGVtLCBkaXJlY3Rpb24sIG9yaWVudGF0aW9uKTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBvbk1hcENoYW5nZSA9IHVzZVN0YWJsZUNhbGxiYWNrKG1hcCA9PiB7XG4gICAgaWYgKG1hcC5zaXplID09PSAwIHx8IGhhc1NldERlZmF1bHRJbmRleFJlZi5jdXJyZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGhhc1NldERlZmF1bHRJbmRleFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICBjb25zdCBzb3J0ZWRFbGVtZW50cyA9IEFycmF5LmZyb20obWFwLmtleXMoKSk7XG4gICAgY29uc3QgYWN0aXZlSXRlbSA9IHNvcnRlZEVsZW1lbnRzLmZpbmQoY29tcG9zaXRlRWxlbWVudCA9PiBjb21wb3NpdGVFbGVtZW50Py5oYXNBdHRyaWJ1dGUoQUNUSVZFX0NPTVBPU0lURV9JVEVNKSkgPz8gbnVsbDtcbiAgICAvLyBTZXQgdGhlIGRlZmF1bHQgaGlnaGxpZ2h0ZWQgaW5kZXggb2YgYW4gYXJiaXRyYXJ5IGNvbXBvc2l0ZSBpdGVtLiBUaGUgbWFwIHZhbHVlIGNhcnJpZXNcbiAgICAvLyB0aGUgaXRlbSdzIG93biBpbmRleCwgd2hpY2ggaXMgbm90IGl0cyBwb3NpdGlvbiBhbW9uZyB0aGUga2V5cyBvbmNlIGEgbGlzdCBtaXhlcyBleHBsaWNpdFxuICAgIC8vIGFuZCBhdXRvbWF0aWMgaW5kZXhlcyBhbmQgbGVhdmVzIGdhcHMuXG4gICAgY29uc3QgYWN0aXZlSW5kZXggPSBhY3RpdmVJdGVtID8gbWFwLmdldChhY3RpdmVJdGVtKT8uaW5kZXggPz8gLTEgOiAtMTtcbiAgICBpZiAoYWN0aXZlSW5kZXggIT09IC0xKSB7XG4gICAgICBvbkhpZ2hsaWdodGVkSW5kZXhDaGFuZ2UoYWN0aXZlSW5kZXgpO1xuICAgIH0gZWxzZSBpZiAoaXNMaXN0SW5kZXhEaXNhYmxlZChzb3J0ZWRFbGVtZW50cywgaGlnaGxpZ2h0ZWRJbmRleCwgZGlzYWJsZWRJbmRpY2VzKSkge1xuICAgICAgLy8gVGhlIGRlZmF1bHQgaGlnaGxpZ2h0ZWQgaXRlbSBpcyBkaXNhYmxlZCwgc28gaXQgc2hvdWxkIG5vdCBob2xkIHRoZSBzaW5nbGVcbiAgICAgIC8vIHJvdmluZyB0YWIgc3RvcDogYSBuYXRpdmVseSBkaXNhYmxlZCBlbGVtZW50IGlzIHJlbW92ZWQgZnJvbSB0aGUgdGFiIG9yZGVyLFxuICAgICAgLy8gYW5kIGFuIGFyaWEtZGlzYWJsZWQgb25lIHNob3VsZCBub3QgYmUgdGhlIGVudHJ5IHBvaW50LiBNb3ZlIHRoZSB0YWIgc3RvcFxuICAgICAgLy8gdG8gdGhlIGZpcnN0IGVuYWJsZWQgaXRlbS4gSWYgZXZlcnkgaXRlbSBpcyBkaXNhYmxlZCwga2VlcCB0aGUgY3VycmVudFxuICAgICAgLy8gaGlnaGxpZ2h0ZWQgaW5kZXguXG4gICAgICBjb25zdCBmaXJzdEVuYWJsZWRJbmRleCA9IGZpbmROb25EaXNhYmxlZExpc3RJbmRleChzb3J0ZWRFbGVtZW50cywge1xuICAgICAgICBkaXNhYmxlZEluZGljZXNcbiAgICAgIH0pO1xuICAgICAgaWYgKCFpc0luZGV4T3V0T2ZMaXN0Qm91bmRzKHNvcnRlZEVsZW1lbnRzLCBmaXJzdEVuYWJsZWRJbmRleCkpIHtcbiAgICAgICAgb25IaWdobGlnaHRlZEluZGV4Q2hhbmdlKGZpcnN0RW5hYmxlZEluZGV4KTtcbiAgICAgIH1cbiAgICB9XG4gICAgc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZChyb290UmVmLmN1cnJlbnQsIGFjdGl2ZUl0ZW0sIGRpcmVjdGlvbiwgb3JpZW50YXRpb24pO1xuICB9KTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAvLyBgZGlzYWJsZWRJbmRpY2VzYCBjYW4gcmVzb2x2ZSBhIHJlbmRlciBhZnRlciB0aGUgaW5pdGlhbCBtYXAgcG9wdWxhdGlvblxuICAgIC8vIChlLmcuIFRvb2xiYXIgZGVyaXZlcyBpdCBmcm9tIGl0ZW0gbWV0YWRhdGEgdGhyb3VnaCBhIHN0YXRlIHVwZGF0ZSksIHNvIHRoZVxuICAgIC8vIGRlZmF1bHQgdGFiIHN0b3AgYXQgaW5kZXggMCBtYXkgbm93IHBvaW50IGF0IGEgZGlzYWJsZWQgaXRlbSwgbGVhdmluZyB0aGVcbiAgICAvLyBjb21wb3NpdGUgd2l0aG91dCBhIHJlYWNoYWJsZSB0YWIgc3RvcC4gUmUtdmFsaWRhdGUgYW5kIG1vdmUgaXQgdG8gdGhlIGZpcnN0XG4gICAgLy8gZW5hYmxlZCBpdGVtLiBHYXRlZCBvbiBgZGlzYWJsZWRJbmRpY2VzYCBiZWluZyBwcm92aWRlZCBzbyBjb21wb3NpdGVzIHRoYXRcbiAgICAvLyByZWx5IG9uIHRoZSBET00gZGlzYWJsZWQgZmFsbGJhY2sga2VlcCB0aGVpciBleGlzdGluZyBiZWhhdmlvci5cbiAgICBpZiAoZGlzYWJsZWRJbmRpY2VzID09IG51bGwgfHwgZXh0ZXJuYWxIaWdobGlnaHRlZEluZGV4ICE9IG51bGwgfHwgIWhhc1NldERlZmF1bHRJbmRleFJlZi5jdXJyZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGVsZW1lbnRzID0gZWxlbWVudHNSZWYuY3VycmVudDtcbiAgICBpZiAoaXNMaXN0SW5kZXhEaXNhYmxlZChlbGVtZW50cywgaGlnaGxpZ2h0ZWRJbmRleCwgZGlzYWJsZWRJbmRpY2VzKSkge1xuICAgICAgY29uc3QgZmlyc3RFbmFibGVkSW5kZXggPSBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgoZWxlbWVudHMsIHtcbiAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICB9KTtcbiAgICAgIGlmICghaXNJbmRleE91dE9mTGlzdEJvdW5kcyhlbGVtZW50cywgZmlyc3RFbmFibGVkSW5kZXgpKSB7XG4gICAgICAgIG9uSGlnaGxpZ2h0ZWRJbmRleENoYW5nZShmaXJzdEVuYWJsZWRJbmRleCk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbZGlzYWJsZWRJbmRpY2VzLCBleHRlcm5hbEhpZ2hsaWdodGVkSW5kZXgsIGhpZ2hsaWdodGVkSW5kZXgsIGVsZW1lbnRzUmVmLCBvbkhpZ2hsaWdodGVkSW5kZXhDaGFuZ2VdKTtcbiAgY29uc3Qgd3JhcHBlZE9uTG9vcCA9IHVzZVN0YWJsZUNhbGxiYWNrKChldmVudCwgcHJldkluZGV4LCBuZXh0SW5kZXgpID0+IHtcbiAgICBpZiAoIW9uTG9vcCkge1xuICAgICAgcmV0dXJuIG5leHRJbmRleDtcbiAgICB9XG4gICAgcmV0dXJuIG9uTG9vcChldmVudCwgcHJldkluZGV4LCBuZXh0SW5kZXgsIGVsZW1lbnRzUmVmKTtcbiAgfSk7XG5cbiAgLy8gU3RhYmxlIHNvIHRoYXQgYHJlbGF5S2V5Ym9hcmRFdmVudGAgZG9lcyBub3QgaW52YWxpZGF0ZSBpZGVudGl0eS1zZW5zaXRpdmVcbiAgLy8gY29uc3VtZXJzICh0aGUgYENvbXBvc2l0ZVJvb3RDb250ZXh0YCB2YWx1ZSBhbmQgdHJpZ2dlciBkYXRhIGZvcndhcmRpbmcpLlxuICBjb25zdCBvbktleURvd24gPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgY29uc3QgaXNIb21lT3JFbmQgPSBldmVudC5rZXkgPT09IEhPTUUgfHwgZXZlbnQua2V5ID09PSBFTkQ7XG4gICAgaWYgKCFDT01QT1NJVEVfS0VZUy5oYXMoZXZlbnQua2V5KSB8fCAhZW5hYmxlSG9tZUFuZEVuZEtleXMgJiYgaXNIb21lT3JFbmQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGlzTW9kaWZpZXJLZXlTZXQoZXZlbnQsIG1vZGlmaWVyS2V5cykpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZWxlbWVudCA9IHJvb3RSZWYuY3VycmVudDtcbiAgICBpZiAoIWVsZW1lbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaXNSdGwgPSBkaXJlY3Rpb24gPT09ICdydGwnO1xuICAgIGNvbnN0IGhvcml6b250YWxGb3J3YXJkS2V5ID0gaXNSdGwgPyBBUlJPV19MRUZUIDogQVJST1dfUklHSFQ7XG4gICAgY29uc3QgaG9yaXpvbnRhbEJhY2t3YXJkS2V5ID0gaXNSdGwgPyBBUlJPV19SSUdIVCA6IEFSUk9XX0xFRlQ7XG4gICAgY29uc3QgZm9yd2FyZEtleSA9IG9yaWVudGF0aW9uID09PSAndmVydGljYWwnID8gQVJST1dfRE9XTiA6IGhvcml6b250YWxGb3J3YXJkS2V5O1xuICAgIGNvbnN0IGJhY2t3YXJkS2V5ID0gb3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCcgPyBBUlJPV19VUCA6IGhvcml6b250YWxCYWNrd2FyZEtleTtcbiAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgIGlmICh0YXJnZXQgIT0gbnVsbCAmJiBpc05hdGl2ZUlucHV0KHRhcmdldCkgJiYgIWlzRWxlbWVudERpc2FibGVkKHRhcmdldCkpIHtcbiAgICAgIGNvbnN0IHNlbGVjdGlvblN0YXJ0ID0gdGFyZ2V0LnNlbGVjdGlvblN0YXJ0O1xuICAgICAgY29uc3Qgc2VsZWN0aW9uRW5kID0gdGFyZ2V0LnNlbGVjdGlvbkVuZDtcbiAgICAgIGNvbnN0IHRleHRDb250ZW50ID0gdGFyZ2V0LnZhbHVlO1xuICAgICAgLy8gcmV0dXJuIHRvIG5hdGl2ZSB0ZXh0Ym94IGJlaGF2aW9yIHdoZW5cbiAgICAgIC8vIDEgLSBTaGlmdCBpcyBoZWxkIHRvIG1ha2UgYSB0ZXh0IHNlbGVjdGlvbiwgb3IgaWYgdGhlcmUgYWxyZWFkeSBpcyBhIHRleHQgc2VsZWN0aW9uXG4gICAgICBpZiAoc2VsZWN0aW9uU3RhcnQgPT0gbnVsbCB8fCBldmVudC5zaGlmdEtleSB8fCBzZWxlY3Rpb25TdGFydCAhPT0gc2VsZWN0aW9uRW5kKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIC8vIDIgLSBhcnJvdy1pbmcgZm9yd2FyZCBhbmQgbm90IGluIHRoZSBsYXN0IHBvc2l0aW9uIG9mIHRoZSB0ZXh0XG4gICAgICBpZiAoZXZlbnQua2V5ICE9PSBiYWNrd2FyZEtleSAmJiBzZWxlY3Rpb25TdGFydCA8IHRleHRDb250ZW50Lmxlbmd0aCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICAvLyAzIC1hcnJvdy1pbmcgYmFja3dhcmQgYW5kIG5vdCBpbiB0aGUgZmlyc3QgcG9zaXRpb24gb2YgdGhlIHRleHRcbiAgICAgIGlmIChldmVudC5rZXkgIT09IGZvcndhcmRLZXkgJiYgc2VsZWN0aW9uU3RhcnQgPiAwKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gICAgbGV0IG5leHRJbmRleCA9IGhpZ2hsaWdodGVkSW5kZXg7XG4gICAgY29uc3QgbWluSW5kZXggPSBnZXRNaW5MaXN0SW5kZXgoZWxlbWVudHNSZWYsIGRpc2FibGVkSW5kaWNlcyk7XG4gICAgY29uc3QgbWF4SW5kZXggPSBnZXRNYXhMaXN0SW5kZXgoZWxlbWVudHNSZWYsIGRpc2FibGVkSW5kaWNlcyk7XG4gICAgaWYgKGdyaWQgIT0gbnVsbCkge1xuICAgICAgbmV4dEluZGV4ID0gZ3JpZCh7XG4gICAgICAgIGRpc2FibGVkSW5kaWNlcyxcbiAgICAgICAgZWxlbWVudHNSZWYsXG4gICAgICAgIGV2ZW50LFxuICAgICAgICBoaWdobGlnaHRlZEluZGV4LFxuICAgICAgICBsb29wRm9jdXMsXG4gICAgICAgIG1heEluZGV4LFxuICAgICAgICBtaW5JbmRleCxcbiAgICAgICAgb25Mb29wOiB3cmFwcGVkT25Mb29wLFxuICAgICAgICBvcmllbnRhdGlvbixcbiAgICAgICAgcnRsOiBpc1J0bFxuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IGlzRm9yd2FyZEtleSA9IG9yaWVudGF0aW9uICE9PSAndmVydGljYWwnICYmIGV2ZW50LmtleSA9PT0gaG9yaXpvbnRhbEZvcndhcmRLZXkgfHwgb3JpZW50YXRpb24gIT09ICdob3Jpem9udGFsJyAmJiBldmVudC5rZXkgPT09IEFSUk9XX0RPV047XG4gICAgY29uc3QgaXNCYWNrd2FyZEtleSA9IG9yaWVudGF0aW9uICE9PSAndmVydGljYWwnICYmIGV2ZW50LmtleSA9PT0gaG9yaXpvbnRhbEJhY2t3YXJkS2V5IHx8IG9yaWVudGF0aW9uICE9PSAnaG9yaXpvbnRhbCcgJiYgZXZlbnQua2V5ID09PSBBUlJPV19VUDtcbiAgICBpZiAoZW5hYmxlSG9tZUFuZEVuZEtleXMpIHtcbiAgICAgIGlmIChldmVudC5rZXkgPT09IEhPTUUpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gbWluSW5kZXg7XG4gICAgICB9IGVsc2UgaWYgKGV2ZW50LmtleSA9PT0gRU5EKSB7XG4gICAgICAgIG5leHRJbmRleCA9IG1heEluZGV4O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAobmV4dEluZGV4ID09PSBoaWdobGlnaHRlZEluZGV4ICYmIChpc0ZvcndhcmRLZXkgfHwgaXNCYWNrd2FyZEtleSkpIHtcbiAgICAgIGlmIChsb29wRm9jdXMgJiYgbmV4dEluZGV4ID09PSBtYXhJbmRleCAmJiBpc0ZvcndhcmRLZXkpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gbWluSW5kZXg7XG4gICAgICAgIGlmIChvbkxvb3ApIHtcbiAgICAgICAgICBuZXh0SW5kZXggPSBvbkxvb3AoZXZlbnQsIGhpZ2hsaWdodGVkSW5kZXgsIG5leHRJbmRleCwgZWxlbWVudHNSZWYpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGxvb3BGb2N1cyAmJiBuZXh0SW5kZXggPT09IG1pbkluZGV4ICYmIGlzQmFja3dhcmRLZXkpIHtcbiAgICAgICAgbmV4dEluZGV4ID0gbWF4SW5kZXg7XG4gICAgICAgIGlmIChvbkxvb3ApIHtcbiAgICAgICAgICBuZXh0SW5kZXggPSBvbkxvb3AoZXZlbnQsIGhpZ2hsaWdodGVkSW5kZXgsIG5leHRJbmRleCwgZWxlbWVudHNSZWYpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBuZXh0SW5kZXggPSBmaW5kTm9uRGlzYWJsZWRMaXN0SW5kZXgoZWxlbWVudHNSZWYuY3VycmVudCwge1xuICAgICAgICAgIHN0YXJ0aW5nSW5kZXg6IG5leHRJbmRleCxcbiAgICAgICAgICBkZWNyZW1lbnQ6IGlzQmFja3dhcmRLZXksXG4gICAgICAgICAgZGlzYWJsZWRJbmRpY2VzXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAobmV4dEluZGV4ICE9PSBoaWdobGlnaHRlZEluZGV4ICYmICFpc0luZGV4T3V0T2ZMaXN0Qm91bmRzKGVsZW1lbnRzUmVmLmN1cnJlbnQsIG5leHRJbmRleCkpIHtcbiAgICAgIGlmIChzdG9wRXZlbnRQcm9wYWdhdGlvbikge1xuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIH1cbiAgICAgIGlmIChpc0dyaWQgfHwgaXNIb21lT3JFbmQgfHwgaXNGb3J3YXJkS2V5IHx8IGlzQmFja3dhcmRLZXkpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICAgIG9uSGlnaGxpZ2h0ZWRJbmRleENoYW5nZShuZXh0SW5kZXgsIHRydWUpO1xuXG4gICAgICAvLyBXYWl0IGZvciBGb2N1c01hbmFnZXIgYHJldHVybkZvY3VzYCB0byBleGVjdXRlLlxuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICBlbGVtZW50c1JlZi5jdXJyZW50W25leHRJbmRleF0/LmZvY3VzKCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBwcm9wcyA9IHtcbiAgICByZWY6IG1lcmdlZFJlZixcbiAgICBvbkZvY3VzKGV2ZW50KSB7XG4gICAgICBjb25zdCBlbGVtZW50ID0gcm9vdFJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgIGlmICghZWxlbWVudCB8fCB0YXJnZXQgPT0gbnVsbCB8fCAhaXNOYXRpdmVJbnB1dCh0YXJnZXQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRhcmdldC5zZXRTZWxlY3Rpb25SYW5nZSgwLCB0YXJnZXQudmFsdWUubGVuZ3RoKTtcbiAgICB9LFxuICAgIG9uS2V5RG93blxuICB9O1xuICByZXR1cm4ge1xuICAgIHByb3BzLFxuICAgIGhpZ2hsaWdodGVkSW5kZXgsXG4gICAgb25IaWdobGlnaHRlZEluZGV4Q2hhbmdlLFxuICAgIGVsZW1lbnRzUmVmLFxuICAgIG9uTWFwQ2hhbmdlLFxuICAgIHJlbGF5S2V5Ym9hcmRFdmVudDogb25LZXlEb3duXG4gIH07XG59XG5mdW5jdGlvbiBpc01vZGlmaWVyS2V5U2V0KGV2ZW50LCBpZ25vcmVkTW9kaWZpZXJLZXlzKSB7XG4gIGZvciAoY29uc3Qga2V5IG9mIE1PRElGSUVSX0tFWVMpIHtcbiAgICBpZiAoaWdub3JlZE1vZGlmaWVyS2V5cy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGV2ZW50LmdldE1vZGlmaWVyU3RhdGUoa2V5KSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBEaXJlY3Rpb25Db250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpcmVjdGlvbkNvbnRleHQuZGlzcGxheU5hbWUgPSBcIkRpcmVjdGlvbkNvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VEaXJlY3Rpb24oKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KERpcmVjdGlvbkNvbnRleHQpO1xuICByZXR1cm4gY29udGV4dD8uZGlyZWN0aW9uID8/ICdsdHInO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRU1QVFlfQVJSQVksIEVNUFRZX09CSkVDVCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IENvbXBvc2l0ZUxpc3QgfSBmcm9tIFwiLi4vbGlzdC9Db21wb3NpdGVMaXN0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQ29tcG9zaXRlUm9vdCB9IGZyb20gXCIuL3VzZUNvbXBvc2l0ZVJvb3QubWpzXCI7XG5pbXBvcnQgeyBDb21wb3NpdGVSb290Q29udGV4dCB9IGZyb20gXCIuL0NvbXBvc2l0ZVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlyZWN0aW9uIH0gZnJvbSBcIi4uLy4uL2RpcmVjdGlvbi1jb250ZXh0L0RpcmVjdGlvbkNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGZ1bmN0aW9uIENvbXBvc2l0ZVJvb3QoY29tcG9uZW50UHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgcmVmcyA9IEVNUFRZX0FSUkFZLFxuICAgIHByb3BzID0gRU1QVFlfQVJSQVksXG4gICAgc3RhdGUgPSBFTVBUWV9PQkpFQ1QsXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZyxcbiAgICBoaWdobGlnaHRlZEluZGV4OiBoaWdobGlnaHRlZEluZGV4UHJvcCxcbiAgICBvbkhpZ2hsaWdodGVkSW5kZXhDaGFuZ2U6IG9uSGlnaGxpZ2h0ZWRJbmRleENoYW5nZVByb3AsXG4gICAgb3JpZW50YXRpb24sXG4gICAgZ3JpZCxcbiAgICBsb29wRm9jdXMsXG4gICAgb25Mb29wLFxuICAgIGVuYWJsZUhvbWVBbmRFbmRLZXlzLFxuICAgIG9uTWFwQ2hhbmdlOiBvbk1hcENoYW5nZVByb3AsXG4gICAgc3RvcEV2ZW50UHJvcGFnYXRpb24gPSB0cnVlLFxuICAgIHJvb3RSZWYsXG4gICAgZGlzYWJsZWRJbmRpY2VzLFxuICAgIG1vZGlmaWVyS2V5cyxcbiAgICBoaWdobGlnaHRJdGVtT25Ib3ZlciA9IGZhbHNlLFxuICAgIHRhZyA9ICdkaXYnLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IGRpcmVjdGlvbiA9IHVzZURpcmVjdGlvbigpO1xuICBjb25zdCB7XG4gICAgcHJvcHM6IGRlZmF1bHRQcm9wcyxcbiAgICBoaWdobGlnaHRlZEluZGV4LFxuICAgIG9uSGlnaGxpZ2h0ZWRJbmRleENoYW5nZSxcbiAgICBlbGVtZW50c1JlZixcbiAgICBvbk1hcENoYW5nZTogb25NYXBDaGFuZ2VVbndyYXBwZWQsXG4gICAgcmVsYXlLZXlib2FyZEV2ZW50XG4gIH0gPSB1c2VDb21wb3NpdGVSb290KHtcbiAgICBncmlkLFxuICAgIGxvb3BGb2N1cyxcbiAgICBvbkxvb3AsXG4gICAgb3JpZW50YXRpb24sXG4gICAgaGlnaGxpZ2h0ZWRJbmRleDogaGlnaGxpZ2h0ZWRJbmRleFByb3AsXG4gICAgb25IaWdobGlnaHRlZEluZGV4Q2hhbmdlOiBvbkhpZ2hsaWdodGVkSW5kZXhDaGFuZ2VQcm9wLFxuICAgIHJvb3RSZWYsXG4gICAgc3RvcEV2ZW50UHJvcGFnYXRpb24sXG4gICAgZW5hYmxlSG9tZUFuZEVuZEtleXMsXG4gICAgZGlyZWN0aW9uLFxuICAgIGRpc2FibGVkSW5kaWNlcyxcbiAgICBtb2RpZmllcktleXNcbiAgfSk7XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KHRhZywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IHJlZnMsXG4gICAgcHJvcHM6IFtkZWZhdWx0UHJvcHMsIC4uLnByb3BzLCBlbGVtZW50UHJvcHNdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmdcbiAgfSk7XG4gIGNvbnN0IGNvbnRleHRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBoaWdobGlnaHRlZEluZGV4LFxuICAgIG9uSGlnaGxpZ2h0ZWRJbmRleENoYW5nZSxcbiAgICBoaWdobGlnaHRJdGVtT25Ib3ZlcixcbiAgICByZWxheUtleWJvYXJkRXZlbnRcbiAgfSksIFtoaWdobGlnaHRlZEluZGV4LCBvbkhpZ2hsaWdodGVkSW5kZXhDaGFuZ2UsIGhpZ2hsaWdodEl0ZW1PbkhvdmVyLCByZWxheUtleWJvYXJkRXZlbnRdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KENvbXBvc2l0ZVJvb3RDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IGNvbnRleHRWYWx1ZSxcbiAgICBjaGlsZHJlbjogLyojX19QVVJFX18qL19qc3goQ29tcG9zaXRlTGlzdCwge1xuICAgICAgZWxlbWVudHNSZWY6IGVsZW1lbnRzUmVmLFxuICAgICAgb25NYXBDaGFuZ2U6IG5ld01hcCA9PiB7XG4gICAgICAgIG9uTWFwQ2hhbmdlUHJvcD8uKG5ld01hcCk7XG4gICAgICAgIG9uTWFwQ2hhbmdlVW53cmFwcGVkKG5ld01hcCk7XG4gICAgICB9LFxuICAgICAgY2hpbGRyZW46IGVsZW1lbnRcbiAgICB9KVxuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IHVzZUZpZWxkUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vZmllbGQtcm9vdC1jb250ZXh0L0ZpZWxkUm9vdENvbnRleHQubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlUmVnaXN0ZXJGaWVsZENvbnRyb2woY29udHJvbFJlZiwgaWQsIHZhbHVlLCBnZXRGb3JtVmFsdWVPdmVycmlkZSwgZW5hYmxlZCA9IHRydWUsIG5hbWUpIHtcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyRmllbGRDb250cm9sXG4gIH0gPSB1c2VGaWVsZFJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHNvdXJjZVJlZiA9IHVzZVJlZldpdGhJbml0KCgpID0+IFN5bWJvbCgpKTtcblxuICAvLyBSZS1yZWdpc3RlciB3aXRob3V0IHVucmVnaXN0ZXJpbmcgZmlyc3Q6IHJlLXJlZ2lzdHJhdGlvbiB3aXRoIHRoZSBzYW1lIGlkIHVwZGF0ZXMgdGhlXG4gIC8vIGZvcm0ncyBmaWVsZHMgTWFwIGVudHJ5IGluIHBsYWNlLCB3aGlsZSBhIGRlbGV0ZSArIHJlLWFkZCB3b3VsZCBtb3ZlIHRoZSBmaWVsZCB0byB0aGVcbiAgLy8gZW5kIG9mIHRoZSBNYXAgZXZlcnkgdGltZSBpdHMgdmFsdWUgY2hhbmdlcy5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBzb3VyY2UgPSBzb3VyY2VSZWYuY3VycmVudDtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIHJlZ2lzdGVyRmllbGRDb250cm9sKHNvdXJjZSwgdW5kZWZpbmVkKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcmVnaXN0cmF0aW9uID0ge1xuICAgICAgY29udHJvbFJlZixcbiAgICAgIGdldFZhbHVlOiBnZXRGb3JtVmFsdWVPdmVycmlkZSxcbiAgICAgIGlkLFxuICAgICAgbmFtZSxcbiAgICAgIHZhbHVlXG4gICAgfTtcbiAgICByZWdpc3RlckZpZWxkQ29udHJvbChzb3VyY2UsIHJlZ2lzdHJhdGlvbik7XG4gIH0sIFtjb250cm9sUmVmLCBlbmFibGVkLCBnZXRGb3JtVmFsdWVPdmVycmlkZSwgaWQsIG5hbWUsIHJlZ2lzdGVyRmllbGRDb250cm9sLCBzb3VyY2VSZWYsIHZhbHVlXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgc291cmNlID0gc291cmNlUmVmLmN1cnJlbnQ7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHJlZ2lzdGVyRmllbGRDb250cm9sKHNvdXJjZSwgdW5kZWZpbmVkKTtcbiAgICB9O1xuICB9LCBbcmVnaXN0ZXJGaWVsZENvbnRyb2wsIHNvdXJjZVJlZl0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTk9PUCB9IGZyb20gXCIuLi9ub29wLm1qc1wiO1xuZXhwb3J0IGNvbnN0IEZvcm1Db250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQoe1xuICBlbGVtZW50UmVmOiB7XG4gICAgY3VycmVudDogbnVsbFxuICB9LFxuICBmb3JtUmVmOiB7XG4gICAgY3VycmVudDoge1xuICAgICAgZmllbGRzOiBuZXcgTWFwKClcbiAgICB9XG4gIH0sXG4gIGVycm9yczoge30sXG4gIGNsZWFyRXJyb3JzOiBOT09QLFxuICB2YWxpZGF0aW9uTW9kZTogJ29uU3VibWl0JyxcbiAgc3VibWl0QXR0ZW1wdGVkUmVmOiB7XG4gICAgY3VycmVudDogZmFsc2VcbiAgfVxufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGb3JtQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRm9ybUNvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VGb3JtQ29udGV4dCgpIHtcbiAgcmV0dXJuIFJlYWN0LnVzZUNvbnRleHQoRm9ybUNvbnRleHQpO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IHVzZUxhYmVsYWJsZUNvbnRleHQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2xhYmVsYWJsZS1wcm92aWRlci9MYWJlbGFibGVDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gXCIuLi8uLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IERFRkFVTFRfVkFMSURJVFlfU1RBVEUgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2ZpZWxkLWNvbnN0YW50cy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyB1c2VGb3JtQ29udGV4dCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZm9ybS1jb250ZXh0L0Zvcm1Db250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgZ2V0Q29tYmluZWRGaWVsZFZhbGlkaXR5RGF0YSB9IGZyb20gXCIuLi91dGlscy9nZXRDb21iaW5lZEZpZWxkVmFsaWRpdHlEYXRhLm1qc1wiO1xuY29uc3QgdmFsaWRpdHlLZXlzID0gT2JqZWN0LmtleXMoREVGQVVMVF9WQUxJRElUWV9TVEFURSk7XG4vKipcbiAqIFdoZXRoZXIgYW4gaW5wdXQgcGFydGljaXBhdGVzIGluIHRoZSBzdXJyb3VuZGluZyBCYXNlIFVJIEZvcm0uIElucHV0cyB0aGF0IGFyZSBlZmZlY3RpdmVseVxuICogZGlzYWJsZWQsIG9yIHdob3NlIGBmb3JtYCBhdHRyaWJ1dGUgZXhwbGljaXRseSBhc3NvY2lhdGVzIHRoZW0gd2l0aCBhbm90aGVyIGZvcm0sIGFyZSBleGNsdWRlZC5cbiAqIERPTSBwb3NpdGlvbiBvbmx5IG1hdHRlcnMgd2hlbiBpdCBhc3NvY2lhdGVzIHRoZSBpbnB1dCB3aXRoIGEgZGlmZmVyZW50IGZvcm0uIE90aGVyd2lzZSwgZmllbGRcbiAqIHJlZ2lzdHJhdGlvbiBpcyBjb250ZXh0LWRyaXZlbiwgc28gcG9ydGFsZWQgaW5wdXRzIChmb3IgZXhhbXBsZSBpbnNpZGUgYSBkaWFsb2cpIHN0aWxsIGJlbG9uZyB0b1xuICogdGhlIGZvcm0gZm9yIGJvdGggdmFsaWRhdGlvbiBhbmQgdmFsdWVzIHByb2plY3RlZCBpbnRvIGBvbkZvcm1TdWJtaXRgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNFbGlnaWJsZUlucHV0KGlucHV0LCBmb3JtRWxlbWVudCkge1xuICBpZiAoaW5wdXQubWF0Y2hlcygnOmRpc2FibGVkJykpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKCFmb3JtRWxlbWVudCB8fCBpbnB1dC5mb3JtID09PSBmb3JtRWxlbWVudCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgLy8gUmVhY3QgY29udGV4dCBjcm9zc2VzIHBvcnRhbCBib3VuZGFyaWVzLiBBbiB1bmFzc29jaWF0ZWQgcG9ydGFsZWQgaW5wdXQgc3RpbGwgcGFydGljaXBhdGVzIGluXG4gIC8vIGNvbnRleHR1YWwgdmFsaWRhdGlvbiwgdW5sZXNzIGFuIGV4cGxpY2l0IGBmb3JtYCBhdHRyaWJ1dGUgb3B0cyBpdCBvdXQgb2YgdGhlIHN1cnJvdW5kaW5nIEZvcm0uXG4gIHJldHVybiBpbnB1dC5mb3JtID09PSBudWxsICYmICFpbnB1dC5oYXNBdHRyaWJ1dGUoJ2Zvcm0nKTtcbn1cblxuLyoqXG4gKiBQaWNrcyB0aGUgaW5wdXQgd2hvc2UgbmF0aXZlIHZhbGlkaXR5IHNob3VsZCByZXByZXNlbnQgYSBmaWVsZCB0aGF0IG93bnMgc2V2ZXJhbCBpbnB1dHMgKHN1Y2ggYXMgYVxuICogY2hlY2tib3ggb3IgcmFkaW8gZ3JvdXApLiBQcmVmZXJzIHRoZSBmaXJzdCBlbGlnaWJsZSBjdXJyZW50bHktaW52YWxpZCBpbnB1dCwgd2hlcmUgXCJmaXJzdFwiIGZvbGxvd3NcbiAqIHJlZ2lzdHJhdGlvbiBvcmRlciAobW91bnQgb3JkZXIpLCBhbmQgb3RoZXJ3aXNlIHJldHVybnMgdGhlIGZpcnN0IGVsaWdpYmxlIGlucHV0LlxuICovXG5mdW5jdGlvbiBmaW5kUmVwcmVzZW50YXRpdmVJbnB1dChpbnB1dHMsIGZvcm1FbGVtZW50KSB7XG4gIGxldCBmYWxsYmFjayA9IG51bGw7XG4gIGZvciAoY29uc3QgaW5wdXQgb2YgaW5wdXRzLmtleXMoKSkge1xuICAgIGlmICghaXNFbGlnaWJsZUlucHV0KGlucHV0LCBmb3JtRWxlbWVudCkpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoIWlucHV0LnZhbGlkaXR5LnZhbGlkKSB7XG4gICAgICByZXR1cm4gaW5wdXQ7XG4gICAgfVxuICAgIGZhbGxiYWNrID8/PSBpbnB1dDtcbiAgfVxuICByZXR1cm4gZmFsbGJhY2s7XG59XG5mdW5jdGlvbiBjbGVhckN1c3RvbVZhbGlkaXR5KGVsZW1lbnQsIGlucHV0cykge1xuICBmb3IgKGNvbnN0IGlucHV0IG9mIGlucHV0cy5rZXlzKCkpIHtcbiAgICBpbnB1dC5zZXRDdXN0b21WYWxpZGl0eSgnJyk7XG4gIH1cbiAgZWxlbWVudD8uc2V0Q3VzdG9tVmFsaWRpdHkoJycpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVzZUZpZWxkVmFsaWRhdGlvbihwYXJhbXMpIHtcbiAgY29uc3Qge1xuICAgIGVsZW1lbnRSZWYsXG4gICAgZm9ybVJlZlxuICB9ID0gdXNlRm9ybUNvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIHNldFZhbGlkaXR5RGF0YSxcbiAgICB2YWxpZGF0ZSxcbiAgICB2YWxpZGl0eURhdGEsXG4gICAgdmFsaWRhdGlvbkRlYm91bmNlVGltZSxcbiAgICBpbnZhbGlkLFxuICAgIG1hcmtlZERpcnR5UmVmLFxuICAgIHN0YXRlLFxuICAgIHNob3VsZFZhbGlkYXRlT25DaGFuZ2UsXG4gICAgcmVnaXN0ZXJlZEZpZWxkSWRSZWZcbiAgfSA9IHBhcmFtcztcbiAgY29uc3Qge1xuICAgIGNvbnRyb2xJZCxcbiAgICBnZXREZXNjcmlwdGlvblByb3BzXG4gIH0gPSB1c2VMYWJlbGFibGVDb250ZXh0KCk7XG4gIGNvbnN0IHRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IGlucHV0UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCByZWdpc3RlcmVkSW5wdXRzID0gdXNlUmVmV2l0aEluaXQoKCkgPT4gbmV3IE1hcCgpKS5jdXJyZW50O1xuICBjb25zdCB2YWxpZGF0aW9uQ29tbWl0SWRSZWYgPSBSZWFjdC51c2VSZWYoMCk7XG5cbiAgLy8gR3JvdXBzIHJlZ2lzdGVyIHNldmVyYWwgaW5wdXRzIGFnYWluc3QgYSBzaW5nbGUgZmllbGQgc28gZm9jdXMsIHZhbGlkYXRpb24sIGFuZCBmb3JtLXZhbHVlXG4gIC8vIHByb2plY3Rpb24gY2FuIHVzZSB0aGUgc2FtZSBsaXZlIGNvbnRyb2xzLiBUaGlzIGFsc28gZW5zdXJlcyBhIGByZXF1aXJlZGAgY2hlY2tib3ggY2FuJ3QgYmVcbiAgLy8gc2F0aXNmaWVkIGJ5IGFub3RoZXIgaW5wdXQgaW4gdGhlIGdyb3VwLCBtYXRjaGluZyBuYXRpdmUgcGVyLWNoZWNrYm94IGJlaGF2aW9yLlxuICBjb25zdCByZWdpc3RlcklucHV0ID0gUmVhY3QudXNlQ2FsbGJhY2soKGVsZW1lbnQsIHJlZ2lzdHJhdGlvbikgPT4ge1xuICAgIHJlZ2lzdGVyZWRJbnB1dHMuc2V0KGVsZW1lbnQsIHJlZ2lzdHJhdGlvbik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHJlZ2lzdGVyZWRJbnB1dHMuZGVsZXRlKGVsZW1lbnQpO1xuICAgIH07XG4gIH0sIFtyZWdpc3RlcmVkSW5wdXRzXSk7XG4gIGNvbnN0IGdldElucHV0Q29udHJvbCA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBlbGVtZW50ID0gZmluZFJlcHJlc2VudGF0aXZlSW5wdXQocmVnaXN0ZXJlZElucHV0cywgZWxlbWVudFJlZi5jdXJyZW50KTtcbiAgICByZXR1cm4gZWxlbWVudCAmJiByZWdpc3RlcmVkSW5wdXRzLmdldChlbGVtZW50KT8uY29udHJvbFJlZi5jdXJyZW50IHx8IG51bGw7XG4gIH0pO1xuICBjb25zdCBjb21taXQgPSB1c2VTdGFibGVDYWxsYmFjayhhc3luYyAodmFsdWUsIHJldmFsaWRhdGUgPSBmYWxzZSkgPT4ge1xuICAgIHZhbGlkYXRpb25Db21taXRJZFJlZi5jdXJyZW50ICs9IDE7XG4gICAgY29uc3QgdmFsaWRhdGlvbkNvbW1pdElkID0gdmFsaWRhdGlvbkNvbW1pdElkUmVmLmN1cnJlbnQ7XG4gICAgZnVuY3Rpb24gdXBkYXRlUmVnaXN0ZXJlZEZpZWxkVmFsaWRpdHkobmV4dFZhbGlkaXR5RGF0YSwgZXh0ZXJuYWxJbnZhbGlkID0gaW52YWxpZCkge1xuICAgICAgY29uc3QgZmllbGRJZCA9IHJlZ2lzdGVyZWRGaWVsZElkUmVmLmN1cnJlbnQgPz8gY29udHJvbElkO1xuICAgICAgaWYgKGZpZWxkSWQgPT0gbnVsbCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBjdXJyZW50RmllbGREYXRhID0gZm9ybVJlZi5jdXJyZW50LmZpZWxkcy5nZXQoZmllbGRJZCk7XG4gICAgICBpZiAoIWN1cnJlbnRGaWVsZERhdGEpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgdmFsaWRpdHlEYXRhV2l0aEZvcm1FcnJvcnMgPSBnZXRDb21iaW5lZEZpZWxkVmFsaWRpdHlEYXRhKG5leHRWYWxpZGl0eURhdGEsIGV4dGVybmFsSW52YWxpZCk7XG4gICAgICBmb3JtUmVmLmN1cnJlbnQuZmllbGRzLnNldChmaWVsZElkLCB7XG4gICAgICAgIC4uLmN1cnJlbnRGaWVsZERhdGEsXG4gICAgICAgIHZhbGlkaXR5RGF0YTogdmFsaWRpdHlEYXRhV2l0aEZvcm1FcnJvcnNcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwdWJsaXNoQWxsVmFsaWQoaW5wdXQsIGV4dGVybmFsSW52YWxpZCkge1xuICAgICAgY29uc3QgbmV4dFZhbGlkaXR5RGF0YSA9IHtcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIHN0YXRlOiB7XG4gICAgICAgICAgLi4uREVGQVVMVF9WQUxJRElUWV9TVEFURSxcbiAgICAgICAgICB2YWxpZDogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBlcnJvcjogJycsXG4gICAgICAgIGVycm9yczogW10sXG4gICAgICAgIGluaXRpYWxWYWx1ZTogdmFsaWRpdHlEYXRhLmluaXRpYWxWYWx1ZVxuICAgICAgfTtcbiAgICAgIGNsZWFyQ3VzdG9tVmFsaWRpdHkoaW5wdXQsIHJlZ2lzdGVyZWRJbnB1dHMpO1xuICAgICAgdXBkYXRlUmVnaXN0ZXJlZEZpZWxkVmFsaWRpdHkobmV4dFZhbGlkaXR5RGF0YSwgZXh0ZXJuYWxJbnZhbGlkKTtcbiAgICAgIHNldFZhbGlkaXR5RGF0YShuZXh0VmFsaWRpdHlEYXRhKTtcbiAgICB9XG5cbiAgICAvLyBBIGZpZWxkIGNhbiBvd24gc2V2ZXJhbCBpbnB1dHMgKHN1Y2ggYXMgYSBjaGVja2JveCBvciByYWRpbyBncm91cCksIGJ1dCBvbmx5IHRoZSBsYXN0LW1vdW50ZWRcbiAgICAvLyBvbmUgd2lucyB0aGUgc2hhcmVkIGBpbnB1dFJlZmAuIFZhbGlkYXRlIGFnYWluc3QgdGhlIHJlZ2lzdHJ5IGluc3RlYWQgc28gZXZlcnkgaW5wdXQgY291bnRzO1xuICAgIC8vIGBpbnB1dFJlZmAgaXMgdGhlIGZhbGxiYWNrIG9ubHkgd2hlbiBubyBpbnB1dHMgYXJlIHJlZ2lzdGVyZWQuXG4gICAgY29uc3QgZWxlbWVudCA9IHJlZ2lzdGVyZWRJbnB1dHMuc2l6ZSA+IDAgPyBmaW5kUmVwcmVzZW50YXRpdmVJbnB1dChyZWdpc3RlcmVkSW5wdXRzLCBlbGVtZW50UmVmLmN1cnJlbnQpIDogaW5wdXRSZWYuY3VycmVudDtcbiAgICAvLyBBIGZpZWxkIHdpdGggbm8gZWxpZ2libGUgaW5wdXQgaGFzIG5vIG5hdGl2ZSBjb25zdHJhaW50LCBidXQgaXRzIGN1c3RvbSB2YWxpZGF0b3Igc3RpbGxcbiAgICAvLyBhcHBsaWVzIHRvIHRoZSBsb2dpY2FsIHZhbHVlIGF0IHRoZSBjb25maWd1cmVkIHZhbGlkYXRpb24gYm91bmRhcnkuXG5cbiAgICBpZiAocmV2YWxpZGF0ZSkge1xuICAgICAgaWYgKHN0YXRlLnZhbGlkICE9PSBmYWxzZSB8fCAhZWxlbWVudCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBjdXJyZW50TmF0aXZlVmFsaWRpdHkgPSBlbGVtZW50LnZhbGlkaXR5O1xuICAgICAgaWYgKCFjdXJyZW50TmF0aXZlVmFsaWRpdHkudmFsdWVNaXNzaW5nKSB7XG4gICAgICAgIC8vIFRoZSAndmFsdWVNaXNzaW5nJyAocmVxdWlyZWQpIGNvbmRpdGlvbiBoYXMgYmVlbiByZXNvbHZlZCBieSB0aGUgdXNlciB0eXBpbmcuXG4gICAgICAgIC8vIFRlbXBvcmFyaWx5IG1hcmsgdGhlIGZpZWxkIGFzIHZhbGlkIGZvciB0aGlzIG9uQ2hhbmdlIGV2ZW50LlxuICAgICAgICAvLyBPdGhlciBuYXRpdmUgZXJyb3JzIChlLmcuLCB0eXBlTWlzbWF0Y2gpIHdpbGwgYmUgY2F1Z2h0IGJ5IGZ1bGwgdmFsaWRhdGlvbiBvbiBibHVyIG9yIHN1Ym1pdC5cbiAgICAgICAgLy8gVGhlIHJlcXVpcmVkIHZhbHVlIGlzIG5vdyBwcmVzZW50OyBpZ25vcmUgc3RhbGUgZXh0ZXJuYWwgaW52YWxpZCBzdGF0ZSBmb3IgdGhpcyBwYXNzLlxuICAgICAgICBwdWJsaXNoQWxsVmFsaWQoZWxlbWVudCwgZmFsc2UpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIEEgc3RhbGUgY3VzdG9tIGVycm9yIGNhbiBjb2V4aXN0IHdpdGggdmFsdWVNaXNzaW5nLCBidXQgZGVmZXIgYW55IG90aGVyIG5hdGl2ZSBlcnJvcnMuXG4gICAgICBmb3IgKGNvbnN0IGtleSBvZiB2YWxpZGl0eUtleXMpIHtcbiAgICAgICAgaWYgKGtleSAhPT0gJ3ZhbGlkJyAmJiBrZXkgIT09ICd2YWx1ZU1pc3NpbmcnICYmIGtleSAhPT0gJ2N1c3RvbUVycm9yJyAmJiBjdXJyZW50TmF0aXZlVmFsaWRpdHlba2V5XSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBWYWx1ZSBpcyBzdGlsbCBtaXNzaW5nOiBwdWJsaXNoIHRoZSBjdXJyZW50IG5hdGl2ZSBzdGF0ZSBzbyB2YWx1ZU1pc3NpbmcgYW5kIHRoZSBjaGFuZ2VkXG4gICAgICAvLyB2YWx1ZSBhcmUgb2JzZXJ2YWJsZSBpbW1lZGlhdGVseS4gRnVsbCBjdXN0b20gdmFsaWRhdGlvbiBzdGlsbCB3YWl0cyBmb3IgaXRzIGJvdW5kYXJ5LlxuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRTdGF0ZShlbCkge1xuICAgICAgY29uc3QgY29tcHV0ZWRTdGF0ZSA9IHZhbGlkaXR5S2V5cy5yZWR1Y2UoKGFjYywga2V5KSA9PiB7XG4gICAgICAgIGFjY1trZXldID0gZWwudmFsaWRpdHlba2V5XTtcbiAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgIH0sIHt9KTtcbiAgICAgIGxldCBoYXNPbmx5VmFsdWVNaXNzaW5nRXJyb3IgPSBmYWxzZTtcbiAgICAgIGZvciAoY29uc3Qga2V5IG9mIHZhbGlkaXR5S2V5cykge1xuICAgICAgICBpZiAoa2V5ID09PSAndmFsaWQnKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGtleSA9PT0gJ3ZhbHVlTWlzc2luZycgJiYgY29tcHV0ZWRTdGF0ZVtrZXldKSB7XG4gICAgICAgICAgaGFzT25seVZhbHVlTWlzc2luZ0Vycm9yID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIGlmIChjb21wdXRlZFN0YXRlW2tleV0pIHtcbiAgICAgICAgICByZXR1cm4gY29tcHV0ZWRTdGF0ZTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBPbmx5IG1ha2UgYHZhbHVlTWlzc2luZ2AgbWFyayB0aGUgZmllbGQgaW52YWxpZCBpZiBpdCdzIGJlZW4gY2hhbmdlZFxuICAgICAgLy8gdG8gcmVkdWNlIGVycm9yIG5vaXNlLlxuICAgICAgaWYgKGhhc09ubHlWYWx1ZU1pc3NpbmdFcnJvciAmJiAhbWFya2VkRGlydHlSZWYuY3VycmVudCkge1xuICAgICAgICBjb21wdXRlZFN0YXRlLnZhbGlkID0gdHJ1ZTtcbiAgICAgICAgY29tcHV0ZWRTdGF0ZS52YWx1ZU1pc3NpbmcgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjb21wdXRlZFN0YXRlO1xuICAgIH1cbiAgICB0aW1lb3V0LmNsZWFyKCk7XG4gICAgbGV0IHJlc3VsdCA9IG51bGw7XG4gICAgbGV0IHZhbGlkYXRpb25FcnJvcnMgPSBbXTtcblxuICAgIC8vIFdpdGggbm8gcmVwcmVzZW50YXRpdmUgaW5wdXQgdGhlIGZpZWxkIGNhcnJpZXMgbm8gbmF0aXZlIGNvbnN0cmFpbnQsIHNvIHN0YXJ0IGZyb20gYW5cbiAgICAvLyBhbGwtdmFsaWQgbmF0aXZlIHN0YXRlIGFuZCBsZXQgdGhlIGN1c3RvbSBgdmFsaWRhdGVgIHJlc3VsdCBiZWxvdyBkZWNpZGUgdGhlIG91dGNvbWUuXG4gICAgY29uc3QgbmV4dFN0YXRlID0gZWxlbWVudCA/IGdldFN0YXRlKGVsZW1lbnQpIDoge1xuICAgICAgLi4uREVGQVVMVF9WQUxJRElUWV9TVEFURSxcbiAgICAgIHZhbGlkOiB0cnVlXG4gICAgfTtcbiAgICBsZXQgZGVmYXVsdFZhbGlkYXRpb25NZXNzYWdlO1xuICAgIGNvbnN0IGlzVmFsaWRhdGluZ09uQ2hhbmdlID0gc2hvdWxkVmFsaWRhdGVPbkNoYW5nZSgpO1xuICAgIGlmIChlbGVtZW50ICYmIGVsZW1lbnQudmFsaWRhdGlvbk1lc3NhZ2UgJiYgIWlzVmFsaWRhdGluZ09uQ2hhbmdlKSB7XG4gICAgICAvLyBub3QgdmFsaWRhdGluZyBvbiBjaGFuZ2UsIGlmIHRoZXJlIGlzIGEgYHZhbGlkYXRpb25NZXNzYWdlYCBmcm9tXG4gICAgICAvLyBuYXRpdmUgdmFsaWRpdHksIHNldCBlcnJvcnMgYW5kIHNraXAgY2FsbGluZyB0aGUgY3VzdG9tIHZhbGlkYXRlIGZuXG4gICAgICBkZWZhdWx0VmFsaWRhdGlvbk1lc3NhZ2UgPSBlbGVtZW50LnZhbGlkYXRpb25NZXNzYWdlO1xuICAgICAgdmFsaWRhdGlvbkVycm9ycyA9IFtlbGVtZW50LnZhbGlkYXRpb25NZXNzYWdlXTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gY2FsbCB0aGUgdmFsaWRhdGUgZnVuY3Rpb24gYmVjYXVzZSBlaXRoZXJcbiAgICAgIC8vIC0gdmFsaWRhdGluZyBvbiBjaGFuZ2UsIG9yXG4gICAgICAvLyAtIG5hdGl2ZSBjb25zdHJhaW50IHZhbGlkYXRpb25zIHBhc3NlZCwgY3VzdG9tIHZhbGlkaXR5IGNoZWNrIGlzIG5leHRcbiAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBBcnJheS5mcm9tKGZvcm1SZWYuY3VycmVudC5maWVsZHMudmFsdWVzKCkpLnJlZHVjZSgoYWNjLCBmaWVsZCkgPT4ge1xuICAgICAgICBpZiAoZmllbGQubmFtZSkge1xuICAgICAgICAgIGFjY1tmaWVsZC5uYW1lXSA9IGZpZWxkLmdldFZhbHVlKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgIH0sIHt9KTtcbiAgICAgIGNvbnN0IHJlc3VsdE9yUHJvbWlzZSA9IHZhbGlkYXRlKHZhbHVlLCBmb3JtVmFsdWVzKTtcbiAgICAgIGlmICh0eXBlb2YgcmVzdWx0T3JQcm9taXNlID09PSAnb2JqZWN0JyAmJiByZXN1bHRPclByb21pc2UgIT09IG51bGwgJiYgJ3RoZW4nIGluIHJlc3VsdE9yUHJvbWlzZSkge1xuICAgICAgICByZXN1bHQgPSBhd2FpdCByZXN1bHRPclByb21pc2U7XG4gICAgICAgIGlmICh2YWxpZGF0aW9uQ29tbWl0SWQgIT09IHZhbGlkYXRpb25Db21taXRJZFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXN1bHQgPSByZXN1bHRPclByb21pc2U7XG4gICAgICB9XG4gICAgICBpZiAocmVzdWx0ICE9PSBudWxsKSB7XG4gICAgICAgIG5leHRTdGF0ZS52YWxpZCA9IGZhbHNlO1xuICAgICAgICBuZXh0U3RhdGUuY3VzdG9tRXJyb3IgPSB0cnVlO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShyZXN1bHQpKSB7XG4gICAgICAgICAgdmFsaWRhdGlvbkVycm9ycyA9IHJlc3VsdDtcbiAgICAgICAgICBlbGVtZW50Py5zZXRDdXN0b21WYWxpZGl0eShyZXN1bHQuam9pbignXFxuJykpO1xuICAgICAgICB9IGVsc2UgaWYgKHJlc3VsdCkge1xuICAgICAgICAgIHZhbGlkYXRpb25FcnJvcnMgPSBbcmVzdWx0XTtcbiAgICAgICAgICBlbGVtZW50Py5zZXRDdXN0b21WYWxpZGl0eShyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGlzVmFsaWRhdGluZ09uQ2hhbmdlKSB7XG4gICAgICAgIC8vIHZhbGlkYXRlIGZ1bmN0aW9uIHJldHVybmVkIG5vIGVycm9ycywgaWYgdmFsaWRhdGluZyBvbiBjaGFuZ2VcbiAgICAgICAgLy8gd2UgbmVlZCB0byBjbGVhciB0aGUgY3VzdG9tIHZhbGlkaXR5IHN0YXRlXG4gICAgICAgIGNsZWFyQ3VzdG9tVmFsaWRpdHkoZWxlbWVudCwgcmVnaXN0ZXJlZElucHV0cyk7XG4gICAgICAgIG5leHRTdGF0ZS5jdXN0b21FcnJvciA9IGZhbHNlO1xuICAgICAgICBpZiAoZWxlbWVudCAmJiBlbGVtZW50LnZhbGlkYXRpb25NZXNzYWdlKSB7XG4gICAgICAgICAgZGVmYXVsdFZhbGlkYXRpb25NZXNzYWdlID0gZWxlbWVudC52YWxpZGF0aW9uTWVzc2FnZTtcbiAgICAgICAgICB2YWxpZGF0aW9uRXJyb3JzID0gW2VsZW1lbnQudmFsaWRhdGlvbk1lc3NhZ2VdO1xuICAgICAgICB9IGVsc2UgaWYgKCghZWxlbWVudCB8fCBlbGVtZW50LnZhbGlkaXR5LnZhbGlkKSAmJiAhbmV4dFN0YXRlLnZhbGlkKSB7XG4gICAgICAgICAgbmV4dFN0YXRlLnZhbGlkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBuZXh0VmFsaWRpdHlEYXRhID0ge1xuICAgICAgdmFsdWUsXG4gICAgICBzdGF0ZTogbmV4dFN0YXRlLFxuICAgICAgZXJyb3I6IGRlZmF1bHRWYWxpZGF0aW9uTWVzc2FnZSA/PyAoQXJyYXkuaXNBcnJheShyZXN1bHQpID8gcmVzdWx0WzBdIDogcmVzdWx0ID8/ICcnKSxcbiAgICAgIGVycm9yczogdmFsaWRhdGlvbkVycm9ycyxcbiAgICAgIGluaXRpYWxWYWx1ZTogdmFsaWRpdHlEYXRhLmluaXRpYWxWYWx1ZVxuICAgIH07XG5cbiAgICAvLyBLZWVwIEZvcm0tbGV2ZWwgZXJyb3JzIHBhcnQgb2Ygb3ZlcmFsbCBmaWVsZCB2YWxpZGl0eSBmb3Igc3VibWl0IGJsb2NraW5nL2ZvY3VzIGxvZ2ljLlxuICAgIHVwZGF0ZVJlZ2lzdGVyZWRGaWVsZFZhbGlkaXR5KG5leHRWYWxpZGl0eURhdGEpO1xuICAgIHNldFZhbGlkaXR5RGF0YShuZXh0VmFsaWRpdHlEYXRhKTtcbiAgfSk7XG4gIGNvbnN0IGNoYW5nZSA9IHVzZVN0YWJsZUNhbGxiYWNrKHZhbHVlID0+IHtcbiAgICB0aW1lb3V0LmNsZWFyKCk7XG4gICAgY29uc3QgdmFsaWRhdGVPbkNoYW5nZSA9IHNob3VsZFZhbGlkYXRlT25DaGFuZ2UoKTtcbiAgICBpZiAodmFsaWRhdGVPbkNoYW5nZSAmJiB2YWx1ZSAhPT0gJycgJiYgdmFsaWRhdGlvbkRlYm91bmNlVGltZSkge1xuICAgICAgdmFsaWRhdGlvbkNvbW1pdElkUmVmLmN1cnJlbnQgKz0gMTtcbiAgICAgIHRpbWVvdXQuc3RhcnQodmFsaWRhdGlvbkRlYm91bmNlVGltZSwgKCkgPT4ge1xuICAgICAgICBjb21taXQodmFsdWUpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbW1pdCh2YWx1ZSwgIXZhbGlkYXRlT25DaGFuZ2UpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGdldFZhbGlkYXRpb25Qcm9wcyA9IFJlYWN0LnVzZUNhbGxiYWNrKChkaXNhYmxlZCwgZXh0ZXJuYWxQcm9wcyA9IHt9KSA9PiBtZXJnZVByb3BzKGdldERlc2NyaXB0aW9uUHJvcHMoZXh0ZXJuYWxQcm9wcyksIHN0YXRlLnZhbGlkID09PSBmYWxzZSAmJiAhc3RhdGUuZGlzYWJsZWQgJiYgIWRpc2FibGVkID8ge1xuICAgICdhcmlhLWludmFsaWQnOiB0cnVlXG4gIH0gOiBFTVBUWV9PQkpFQ1QpLCBbZ2V0RGVzY3JpcHRpb25Qcm9wcywgc3RhdGUuZGlzYWJsZWQsIHN0YXRlLnZhbGlkXSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgZ2V0VmFsaWRhdGlvblByb3BzLFxuICAgIGlucHV0UmVmLFxuICAgIHJlZ2lzdGVyZWRJbnB1dHMsXG4gICAgcmVnaXN0ZXJJbnB1dCxcbiAgICBnZXRJbnB1dENvbnRyb2wsXG4gICAgY29tbWl0LFxuICAgIGNoYW5nZVxuICB9KSwgW2dldFZhbGlkYXRpb25Qcm9wcywgcmVnaXN0ZXJlZElucHV0cywgcmVnaXN0ZXJJbnB1dCwgZ2V0SW5wdXRDb250cm9sLCBjb21taXQsIGNoYW5nZV0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IEZpZWxkc2V0Um9vdENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCh1bmRlZmluZWQpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmllbGRzZXRSb290Q29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRmllbGRzZXRSb290Q29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUZpZWxkc2V0Um9vdENvbnRleHQob3B0aW9uYWwgPSBmYWxzZSkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChGaWVsZHNldFJvb3RDb250ZXh0KTtcbiAgaWYgKCFjb250ZXh0ICYmICFvcHRpb25hbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogRmllbGRzZXRSb290Q29udGV4dCBpcyBtaXNzaW5nLiBGaWVsZHNldCBwYXJ0cyBtdXN0IGJlIHBsYWNlZCB3aXRoaW4gPEZpZWxkc2V0LlJvb3Q+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDg2KSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VDb250cm9sbGVkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlQ29udHJvbGxlZCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IGNvbnRhaW5zIH0gZnJvbSBcIi4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzLm1qc1wiO1xuaW1wb3J0IHsgU0hJRlQgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL2NvbXBvc2l0ZS9jb21wb3NpdGUubWpzXCI7XG5pbXBvcnQgeyBDb21wb3NpdGVSb290IH0gZnJvbSBcIi4uL2ludGVybmFscy9jb21wb3NpdGUvcm9vdC9Db21wb3NpdGVSb290Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRmllbGRSb290Q29udGV4dCB9IGZyb20gXCIuLi9pbnRlcm5hbHMvZmllbGQtcm9vdC1jb250ZXh0L0ZpZWxkUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZWdpc3RlckZpZWxkQ29udHJvbCB9IGZyb20gXCIuLi9pbnRlcm5hbHMvZmllbGQtcmVnaXN0ZXItY29udHJvbC91c2VSZWdpc3RlckZpZWxkQ29udHJvbC5tanNcIjtcbmltcG9ydCB7IGZpZWxkVmFsaWRpdHlNYXBwaW5nIH0gZnJvbSBcIi4uL2ludGVybmFscy9maWVsZC1jb25zdGFudHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgaXNFbGlnaWJsZUlucHV0IH0gZnJvbSBcIi4uL2ZpZWxkL3Jvb3QvdXNlRmllbGRWYWxpZGF0aW9uLm1qc1wiO1xuaW1wb3J0IHsgdXNlRmllbGRzZXRSb290Q29udGV4dCB9IGZyb20gXCIuLi9maWVsZHNldC9yb290L0ZpZWxkc2V0Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VGb3JtQ29udGV4dCB9IGZyb20gXCIuLi9pbnRlcm5hbHMvZm9ybS1jb250ZXh0L0Zvcm1Db250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlTGFiZWxhYmxlQ29udGV4dCB9IGZyb20gXCIuLi9pbnRlcm5hbHMvbGFiZWxhYmxlLXByb3ZpZGVyL0xhYmVsYWJsZUNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VWYWx1ZUNoYW5nZWQgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3VzZVZhbHVlQ2hhbmdlZC5tanNcIjtcbmltcG9ydCB7IFJhZGlvR3JvdXBDb250ZXh0IH0gZnJvbSBcIi4vUmFkaW9Hcm91cENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuY29uc3QgTU9ESUZJRVJfS0VZUyA9IFtTSElGVF07XG5cbi8qKlxuICogUHJvdmlkZXMgYSBzaGFyZWQgc3RhdGUgdG8gYSBzZXJpZXMgb2YgcmFkaW8gYnV0dG9ucy5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgUmFkaW8gR3JvdXBdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9yYWRpbylcbiAqL1xuZXhwb3J0IGNvbnN0IFJhZGlvR3JvdXAgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBSYWRpb0dyb3VwKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkUHJvcCxcbiAgICByZWFkT25seSxcbiAgICByZXF1aXJlZCxcbiAgICBvblZhbHVlQ2hhbmdlOiBvblZhbHVlQ2hhbmdlUHJvcCxcbiAgICB2YWx1ZTogZXh0ZXJuYWxWYWx1ZSxcbiAgICBkZWZhdWx0VmFsdWUsXG4gICAgZm9ybSxcbiAgICBuYW1lOiBuYW1lUHJvcCxcbiAgICBpbnB1dFJlZjogaW5wdXRSZWZQcm9wLFxuICAgIGlkOiBpZFByb3AsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHNldFRvdWNoZWQ6IHNldEZpZWxkVG91Y2hlZCxcbiAgICBzZXRGb2N1c2VkLFxuICAgIHZhbGlkYXRpb25Nb2RlLFxuICAgIG5hbWU6IGZpZWxkTmFtZSxcbiAgICBkaXNhYmxlZDogZmllbGREaXNhYmxlZCxcbiAgICBzdGF0ZTogZmllbGRTdGF0ZSxcbiAgICB2YWxpZGF0aW9uLFxuICAgIHNldERpcnR5LFxuICAgIHNldEZpbGxlZCxcbiAgICB2YWxpZGl0eURhdGFcbiAgfSA9IHVzZUZpZWxkUm9vdENvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIGxhYmVsSWRcbiAgfSA9IHVzZUxhYmVsYWJsZUNvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIGNsZWFyRXJyb3JzLFxuICAgIGVsZW1lbnRSZWZcbiAgfSA9IHVzZUZvcm1Db250ZXh0KCk7XG4gIGNvbnN0IGZpZWxkc2V0Q29udGV4dCA9IHVzZUZpZWxkc2V0Um9vdENvbnRleHQodHJ1ZSk7XG4gIGNvbnN0IGRpc2FibGVkID0gZmllbGREaXNhYmxlZCB8fCBkaXNhYmxlZFByb3A7XG4gIGNvbnN0IG5hbWUgPSBmaWVsZE5hbWUgPz8gbmFtZVByb3A7XG4gIGNvbnN0IGlkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgY29uc3QgW2NoZWNrZWRWYWx1ZSwgc2V0Q2hlY2tlZFZhbHVlVW53cmFwcGVkXSA9IHVzZUNvbnRyb2xsZWQoe1xuICAgIGNvbnRyb2xsZWQ6IGV4dGVybmFsVmFsdWUsXG4gICAgZGVmYXVsdDogZGVmYXVsdFZhbHVlLFxuICAgIG5hbWU6ICdSYWRpb0dyb3VwJyxcbiAgICBzdGF0ZTogJ3ZhbHVlJ1xuICB9KTtcbiAgY29uc3QgW3RvdWNoZWQsIHNldFRvdWNoZWRdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBzZXRDaGVja2VkVmFsdWUgPSB1c2VTdGFibGVDYWxsYmFjaygodmFsdWUsIGV2ZW50RGV0YWlscykgPT4ge1xuICAgIG9uVmFsdWVDaGFuZ2VQcm9wPy4odmFsdWUsIGV2ZW50RGV0YWlscyk7XG4gICAgaWYgKGV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldENoZWNrZWRWYWx1ZVVud3JhcHBlZCh2YWx1ZSk7XG4gIH0pO1xuICBjb25zdCBnZXRJbnB1dENvbnRyb2wgPSB2YWxpZGF0aW9uLmdldElucHV0Q29udHJvbDtcbiAgY29uc3QgY29udHJvbFJlZiA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBnZXQgY3VycmVudCgpIHtcbiAgICAgIHJldHVybiBnZXRJbnB1dENvbnRyb2woKTtcbiAgICB9XG4gIH0pLCBbZ2V0SW5wdXRDb250cm9sXSk7XG4gIGNvbnN0IGdyb3VwSW5wdXRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGZpcnN0RW5hYmxlZElucHV0UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuXG4gIC8vIE9ubHkgZm9yd2FyZHMgdGhlIHB1YmxpYyBgaW5wdXRSZWZgIGFuZCB0cmFja3MgdGhlIGN1cnJlbnQgcmVwcmVzZW50YXRpdmUgZm9yIHRoYXQgZm9yd2FyZGluZy5cbiAgLy8gVGhlIHJlZ2lzdHJ5IChgdmFsaWRhdGlvbi5yZWdpc3RlcmVkSW5wdXRzYCkgaXMgYXV0aG9yaXRhdGl2ZSBmb3IgdmFsaWRhdGlvbiBhbmQgZm9ybS12YWx1ZVxuICAvLyBwcm9qZWN0aW9uLCBzbyB0aGUgZ3JvdXAgbXVzdCBub3Qgd3JpdGUgYHZhbGlkYXRpb24uaW5wdXRSZWZgOiBhIHN0YWxlLCB1bm1vdW50ZWQgcmFkaW8gbGVmdFxuICAvLyB0aGVyZSB3b3VsZCBiZWNvbWUgdGhlIEZpZWxkJ3MgZmFsbGJhY2sgb25jZSB0aGUgcmVnaXN0cnkgZW1wdGllcyBhbmQga2VlcCBibG9ja2luZyBzdWJtaXNzaW9uLlxuICBmdW5jdGlvbiBzZXRJbnB1dFJlZihoaWRkZW5JbnB1dCkge1xuICAgIGxldCBjbGVhbnVwID0gdW5kZWZpbmVkO1xuICAgIGlmIChpbnB1dFJlZlByb3ApIHtcbiAgICAgIGlmICh0eXBlb2YgaW5wdXRSZWZQcm9wID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNsZWFudXAgPSBpbnB1dFJlZlByb3AoaGlkZGVuSW5wdXQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaW5wdXRSZWZQcm9wLmN1cnJlbnQgPSBoaWRkZW5JbnB1dDtcbiAgICAgIH1cbiAgICB9XG4gICAgZ3JvdXBJbnB1dFJlZi5jdXJyZW50ID0gaGlkZGVuSW5wdXQ7XG4gICAgcmV0dXJuIGNsZWFudXA7XG4gIH1cbiAgY29uc3QgcmVnaXN0ZXJJbnB1dFJlZiA9IHVzZVN0YWJsZUNhbGxiYWNrKGlucHV0ID0+IHtcbiAgICBpZiAoIWlucHV0IHx8IGlucHV0LmRpc2FibGVkKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoIWZpcnN0RW5hYmxlZElucHV0UmVmLmN1cnJlbnQpIHtcbiAgICAgIGZpcnN0RW5hYmxlZElucHV0UmVmLmN1cnJlbnQgPSBpbnB1dDtcbiAgICB9XG4gICAgY29uc3QgY3VycmVudElucHV0ID0gZ3JvdXBJbnB1dFJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGNsZWFudXAgPSBpbnB1dC5jaGVja2VkIHx8IGN1cnJlbnRJbnB1dCA9PSBudWxsIHx8IGN1cnJlbnRJbnB1dC5kaXNhYmxlZCA/IHNldElucHV0UmVmKGlucHV0KSA6IHVuZGVmaW5lZDtcblxuICAgIC8vIERldGFjaCB3aGVuIHRoaXMgaW5wdXQgdW5tb3VudHMgd2hpbGUgc3RpbGwgZm9yd2FyZGVkLCBzbyBjb25zdW1lcnMgZG9uJ3RcbiAgICAvLyBrZWVwIGhvbGRpbmcgYSBkaXNjb25uZWN0ZWQgbm9kZS4gVGhlIGlucHV0IG1heSBoYXZlIGJlY29tZSB0aGUgZm9yd2FyZGVkXG4gICAgLy8gb25lIGFmdGVyIGF0dGFjaCAodmlhIHRoZSByZS1yZWdpc3RyYXRpb24gZWZmZWN0KSwgc28gYWx3YXlzIHJldHVybiB0aGlzLlxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoZmlyc3RFbmFibGVkSW5wdXRSZWYuY3VycmVudCA9PT0gaW5wdXQpIHtcbiAgICAgICAgZmlyc3RFbmFibGVkSW5wdXRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICBpZiAoZ3JvdXBJbnB1dFJlZi5jdXJyZW50ID09PSBpbnB1dCkge1xuICAgICAgICBpZiAoY2xlYW51cCkge1xuICAgICAgICAgIGNsZWFudXAoKTtcbiAgICAgICAgICBncm91cElucHV0UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZvaWQgc2V0SW5wdXRSZWYobnVsbCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNsZWFudXA/LigpO1xuICAgICAgfVxuICAgIH07XG4gIH0pO1xuICBjb25zdCBnZXRGb3JtVmFsdWUgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3QgZm9ybUVsZW1lbnQgPSBlbGVtZW50UmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFmb3JtRWxlbWVudCkge1xuICAgICAgcmV0dXJuIGNoZWNrZWRWYWx1ZSA/PyBudWxsO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGlucHV0IG9mIHZhbGlkYXRpb24ucmVnaXN0ZXJlZElucHV0cy5rZXlzKCkpIHtcbiAgICAgIGlmIChpbnB1dC5jaGVja2VkICYmIGlzRWxpZ2libGVJbnB1dChpbnB1dCwgZm9ybUVsZW1lbnQpKSB7XG4gICAgICAgIHJldHVybiBjaGVja2VkVmFsdWUgPz8gbnVsbDtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH0pO1xuICB1c2VSZWdpc3RlckZpZWxkQ29udHJvbChjb250cm9sUmVmLCBpZCwgY2hlY2tlZFZhbHVlID8/IG51bGwsIGdldEZvcm1WYWx1ZSwgIWRpc2FibGVkLCBuYW1lUHJvcCk7XG4gIHVzZVZhbHVlQ2hhbmdlZChjaGVja2VkVmFsdWUsICgpID0+IHtcbiAgICBjbGVhckVycm9ycyhuYW1lKTtcbiAgICBzZXREaXJ0eShjaGVja2VkVmFsdWUgIT09IHZhbGlkaXR5RGF0YS5pbml0aWFsVmFsdWUpO1xuICAgIHNldEZpbGxlZChjaGVja2VkVmFsdWUgIT0gbnVsbCk7XG4gICAgdmFsaWRhdGlvbi5jaGFuZ2UoY2hlY2tlZFZhbHVlKTtcbiAgICBjb25zdCBmYWxsYmFja0lucHV0ID0gZmlyc3RFbmFibGVkSW5wdXRSZWYuY3VycmVudDtcbiAgICBpZiAoY2hlY2tlZFZhbHVlID09IG51bGwgJiYgZmFsbGJhY2tJbnB1dCAmJiAhZmFsbGJhY2tJbnB1dC5kaXNhYmxlZCkge1xuICAgICAgLy8gSW1wZXJhdGl2ZSByZS1wb2ludCBvdXRzaWRlIFJlYWN0J3MgcmVmIGxpZmVjeWNsZTsgdGhlIHJlZi1jYWxsYmFjayBjbGVhbnVwIGlzbid0IHRyYWNrZWQgaGVyZS5cbiAgICAgIHZvaWQgc2V0SW5wdXRSZWYoZmFsbGJhY2tJbnB1dCk7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgYXJpYUxhYmVsbGVkYnkgPSBsYWJlbElkID8/IGZpZWxkc2V0Q29udGV4dD8ubGVnZW5kSWQ7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIC4uLmZpZWxkU3RhdGUsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkID8/IGZhbHNlLFxuICAgIHJlcXVpcmVkOiByZXF1aXJlZCA/PyBmYWxzZSxcbiAgICByZWFkT25seTogcmVhZE9ubHkgPz8gZmFsc2VcbiAgfTtcbiAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIGNoZWNrZWRWYWx1ZSxcbiAgICBkaXNhYmxlZCxcbiAgICBmb3JtLFxuICAgIHZhbGlkYXRpb24sXG4gICAgbmFtZSxcbiAgICByZWFkT25seSxcbiAgICByZWdpc3RlcklucHV0UmVmLFxuICAgIHJlcXVpcmVkLFxuICAgIHNldENoZWNrZWRWYWx1ZSxcbiAgICBzZXRUb3VjaGVkLFxuICAgIHRvdWNoZWRcbiAgfSksIFtjaGVja2VkVmFsdWUsIGRpc2FibGVkLCBmb3JtLCB2YWxpZGF0aW9uLCBuYW1lLCByZWFkT25seSwgcmVnaXN0ZXJJbnB1dFJlZiwgcmVxdWlyZWQsIHNldENoZWNrZWRWYWx1ZSwgc2V0VG91Y2hlZCwgdG91Y2hlZF0pO1xuICBjb25zdCBkZWZhdWx0UHJvcHMgPSB7XG4gICAgaWQ6IGlkUHJvcCxcbiAgICByb2xlOiAncmFkaW9ncm91cCcsXG4gICAgJ2FyaWEtcmVxdWlyZWQnOiByZXF1aXJlZCB8fCB1bmRlZmluZWQsXG4gICAgJ2FyaWEtZGlzYWJsZWQnOiBkaXNhYmxlZCB8fCB1bmRlZmluZWQsXG4gICAgJ2FyaWEtcmVhZG9ubHknOiByZWFkT25seSB8fCB1bmRlZmluZWQsXG4gICAgJ2FyaWEtbGFiZWxsZWRieSc6IGFyaWFMYWJlbGxlZGJ5LFxuICAgIG9uRm9jdXMoKSB7XG4gICAgICBzZXRGb2N1c2VkKHRydWUpO1xuICAgIH0sXG4gICAgb25CbHVyKGV2ZW50KSB7XG4gICAgICBpZiAoIWNvbnRhaW5zKGV2ZW50LmN1cnJlbnRUYXJnZXQsIGV2ZW50LnJlbGF0ZWRUYXJnZXQpKSB7XG4gICAgICAgIHNldEZpZWxkVG91Y2hlZCh0cnVlKTtcbiAgICAgICAgc2V0Rm9jdXNlZChmYWxzZSk7XG4gICAgICAgIGlmICh2YWxpZGF0aW9uTW9kZSA9PT0gJ29uQmx1cicpIHtcbiAgICAgICAgICB2YWxpZGF0aW9uLmNvbW1pdChjaGVja2VkVmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBvbktleURvd25DYXB0dXJlKGV2ZW50KSB7XG4gICAgICBpZiAoZXZlbnQua2V5LnN0YXJ0c1dpdGgoJ0Fycm93JykpIHtcbiAgICAgICAgc2V0VG91Y2hlZCh0cnVlKTtcbiAgICAgICAgc2V0Rm9jdXNlZCh0cnVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChSYWRpb0dyb3VwQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBjb250ZXh0VmFsdWUsXG4gICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KENvbXBvc2l0ZVJvb3QsIHtcbiAgICAgIHJlbmRlcjogcmVuZGVyLFxuICAgICAgY2xhc3NOYW1lOiBjbGFzc05hbWUsXG4gICAgICBzdHlsZTogc3R5bGUsXG4gICAgICBzdGF0ZTogc3RhdGUsXG4gICAgICBwcm9wczogW2RlZmF1bHRQcm9wcywgZWxlbWVudFByb3BzLCBwcm9wcyA9PiB2YWxpZGF0aW9uLmdldFZhbGlkYXRpb25Qcm9wcyhkaXNhYmxlZCA/PyBmYWxzZSwgcHJvcHMpXSxcbiAgICAgIHJlZnM6IFtmb3J3YXJkZWRSZWZdLFxuICAgICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogZmllbGRWYWxpZGl0eU1hcHBpbmcsXG4gICAgICBlbmFibGVIb21lQW5kRW5kS2V5czogZmFsc2UsXG4gICAgICBtb2RpZmllcktleXM6IE1PRElGSUVSX0tFWVNcbiAgICB9KVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgUmFkaW9Hcm91cC5kaXNwbGF5TmFtZSA9IFwiUmFkaW9Hcm91cFwiOyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUtBLFNBQWdCLGdCQUFnQixPQUFPLFVBQVU7Q0FDL0MsTUFBTSxXQUFBLGFBQWlCLE9BQU8sS0FBSztDQUNuQyxNQUFNLG1CQUFtQixrQkFBa0IsUUFBUTtDQUNuRCx5QkFBeUI7RUFDdkIsSUFBSSxTQUFTLFlBQVksT0FDdkIsaUJBQWlCLFNBQVMsT0FBTztFQUVuQyxTQUFTLFVBQVU7Q0FDckIsR0FBRyxDQUFDLE9BQU8sZ0JBQWdCLENBQUM7QUFDOUI7OztBQ1JBLFNBQWdCLGNBQWMsRUFDNUIsWUFDQSxTQUFTLGFBQ1QsTUFDQSxRQUFRLFdBQ1A7Q0FFRCxNQUFNLEVBQ0osU0FBUyxpQkFBQSxhQUNELE9BQU8sZUFBZSxLQUFBLENBQVM7Q0FDekMsTUFBTSxDQUFDLFlBQVksWUFBQSxhQUFrQixTQUFTLFdBQVc7Q0FDekQsTUFBTSxRQUFRLGVBQWUsYUFBYTtDQUNDO0VBQ3pDLGFBQU0sZ0JBQWdCO0dBQ3BCLElBQUksa0JBQWtCLGVBQWUsS0FBQSxJQUNuQyxNQUFNO0lBQUMsK0JBQStCLGVBQWUsS0FBSyxLQUFLLGFBQWEsTUFBTSxZQUFZLEtBQUssU0FBUyxlQUFlLE9BQU8sR0FBRztJQUFjO0lBQStFLHFEQUFxRCxLQUFLO0lBQW1EO0lBQThIO0dBQXNELENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQztFQUVuaEIsR0FBRztHQUFDO0dBQU87R0FBTTtFQUFVLENBQUM7RUFDNUIsTUFBTSxFQUNKLFNBQVMsaUJBQUEsYUFDRCxPQUFPLFdBQVc7RUFDNUIsYUFBTSxnQkFBZ0I7R0FDcEIsSUFBSSxDQUFDLGdCQUFnQix5QkFBeUIsWUFBWSxNQUFNLHlCQUF5QixXQUFXLEdBQ2xHLE1BQU0sQ0FBQyx1Q0FBdUMsTUFBTSw0QkFBNEIsS0FBSyw2RUFBa0YsS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQztFQUU5TCxHQUFHLENBQUMsV0FBVyxDQUFDO0NBQ2xCO0NBTUEsT0FBTyxDQUFDLE9BQUEsYUFMNkIsYUFBWSxhQUFZO0VBQzNELElBQUksQ0FBQyxjQUNILFNBQVMsUUFBUTtDQUVyQixHQUFHLENBQUMsQ0FDZ0MsQ0FBQztBQUN2QztBQUNBLFNBQVMseUJBQXlCLE9BQU87Q0FDdkMsSUFBSSxTQUFTO0NBQ2IsTUFBTSx1QkFBTyxJQUFJLFFBQVE7Q0FDekIsSUFBSTtFQWtCRixPQWpCZSxLQUFLLFVBQVUsT0FBTyxTQUFTLFNBQVMsS0FBSyxPQUFPO0dBQ2pFLElBQUksUUFBUSxZQUFZLFFBQVEsUUFBUSxPQUFPLFNBQVMsWUFBWSxjQUFjLE1BQ2hGO0dBRUYsSUFBSSxPQUFPLFVBQVUsVUFDbkIsT0FBTyxjQUFjO0dBRXZCLElBQUksVUFBVSxRQUFRLE9BQU8sVUFBVSxVQUFVO0lBQy9DLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSztJQUN6QixJQUFJLE9BQU8sS0FBQSxHQUNULE9BQU8sY0FBYztJQUV2QixLQUFLLElBQUksT0FBTyxNQUFNO0lBQ3RCLFVBQVU7R0FDWjtHQUNBLE9BQU87RUFDVCxDQUNZLEtBQUssV0FBVyxPQUFPO0NBQ3JDLFFBQVE7RUFDTixPQUFPO0NBQ1Q7QUFDRjs7Ozs7O0FDckRBLFNBQWdCLGNBQWMsT0FBTztDQUNuQyxNQUFNLEVBQ0osVUFDQSxhQUNBLFdBQ0EsYUFBYSxvQkFDWDtDQUNKLE1BQU0sY0FBYyxrQkFBa0IsZUFBZTtDQUNyRCxNQUFNLEdBQUcsY0FBQSxhQUFvQixTQUFTLEtBQUs7Q0FDM0MsTUFBTSxZQUFZLGVBQWUsZUFBZSxDQUFDLENBQUM7Q0FDbEQsTUFBTSxNQUFNLGVBQWUsU0FBUyxDQUFDLENBQUM7Q0FDdEMsTUFBTSxlQUFBLGFBQXFCLE9BQU8sQ0FBQztDQUNuQyxNQUFNLGFBQUEsYUFBbUIsT0FBTyxJQUFJO0NBQ3BDLE1BQU0sV0FBQSxhQUFpQixPQUFPLENBQUMsQ0FBQztDQUNoQyxNQUFNLHNCQUFBLGFBQTRCLE9BQU8sSUFBSTtDQUs3QyxNQUFNLG9CQUFvQix3QkFBd0I7RUFDaEQsSUFBSSxXQUFXLFNBQ2I7RUFFRixXQUFXLFVBQVU7RUFDckIsWUFBVyxTQUFRLENBQUMsSUFBSTtDQUMxQixDQUFDO0NBQ0QsTUFBTSxXQUFXLG1CQUFtQixNQUFNLGlCQUFpQjtFQUN6RCxJQUFJLElBQUksTUFBTSxZQUFZO0VBQzFCLGtCQUFrQjtDQUNwQixDQUFDO0NBQ0QsTUFBTSxhQUFhLG1CQUFrQixTQUFRO0VBQzNDLElBQUksT0FBTyxJQUFJO0VBQ2Ysa0JBQWtCO0NBQ3BCLENBQUM7Q0FDRCxNQUFNLFdBQVcsbUJBQWtCLFVBQVM7RUFDMUMsTUFBTSwwQkFBVSxJQUFJLElBQUk7RUFDeEIsWUFBWSxRQUFRLFNBQVM7RUFDN0IsSUFBSSxXQUNGLFVBQVUsUUFBUSxTQUFTO0VBRTdCLE1BQU0sU0FBUSxTQUFRO0dBQ3BCLFFBQVEsSUFBSSxLQUFLLFNBQVM7SUFDeEIsR0FBSSxLQUFLLGFBQWEsWUFBWSxDQUFDO0lBQ25DLE9BQU8sS0FBSztHQUNkLENBQUM7R0FDRCxZQUFZLFFBQVEsS0FBSyxTQUFTLEtBQUs7R0FDdkMsSUFBSSxXQUNGLFVBQVUsUUFBUSxLQUFLLFNBQVMsS0FBSyxhQUFhLFVBQVUsS0FBQSxJQUFZLEtBQUssYUFBYSxRQUFRLEtBQUssYUFBYSxTQUFTLFNBQVMsZUFBZSxLQUFLLFFBQVE7RUFFdEssQ0FBQztFQUNELGFBQWEsVUFBVSxZQUFZLFFBQVE7RUFDM0MsT0FBTztDQUNULENBQUM7Q0FDRCxTQUFTLFFBQVEsYUFBYTtFQUM1QixvQkFBb0IsU0FBUyxXQUFXO0VBQ3hDLG9CQUFvQixVQUFVO0VBRzlCLElBQUksT0FBTyxxQkFBcUIsY0FBYyxZQUFZLFNBQVMsR0FDakU7RUFFRixNQUFNLG1CQUFtQixJQUFJLGtCQUFpQixZQUFXO0dBS3ZELElBQUksQ0FBQyxhQUFhLE9BQU8sR0FDdkI7R0FFRixJQUFJLHdCQUF3QjtHQUk1QixLQUFLLE1BQU0sUUFBUSxhQUFhO0lBQzlCLElBQUksQ0FBQyxLQUFLLGFBQ1I7SUFFRixJQUFJLHlCQUF5Qix1QkFBdUIsdUJBQXVCLElBQUksSUFBSSxHQUFHO0tBQ3BGLGlCQUFpQixXQUFXO0tBQzVCLGtCQUFrQjtLQUNsQjtJQUNGO0lBQ0Esd0JBQXdCO0dBQzFCO0VBQ0YsQ0FBQztFQUNELG9CQUFvQixVQUFVO0VBSzlCLE1BQU0sd0JBQVEsSUFBSSxJQUFJO0VBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsS0FBSyxHQUFHO0dBQzlDLE1BQU0sT0FBTyxrQkFBa0IsWUFBWSxJQUFJLElBQUksWUFBWSxFQUFFO0dBQ2pFLElBQUksTUFDRixNQUFNLElBQUksSUFBSTtFQUVsQjtFQUNBLE1BQU0sU0FBUSxTQUFRLGlCQUFpQixRQUFRLE1BQU0sRUFDbkQsV0FBVyxLQUNiLENBQUMsQ0FBQztDQUNKO0NBQ0EsTUFBTSxRQUFRLHdCQUF3QjtFQUNwQyxNQUFNLENBQUMsT0FBTyxrQkFBa0IseUJBQXlCLEdBQUc7RUFDNUQsTUFBTSxVQUFVLFNBQVMsS0FBSztFQUM5QixRQUFRLGNBQWM7RUFDdEIsU0FBUyxVQUFVO0VBQ25CLFdBQVcsVUFBVTtFQUNyQixVQUFVLFNBQVEsYUFBWSxTQUFTLE9BQU8sQ0FBQztFQUMvQyxZQUFZLE9BQU87Q0FDckIsQ0FBQztDQUNELHlCQUF5QjtFQUd2QixJQUFJLENBQUMsV0FBVyxTQUNkLFNBQVMsU0FBUyxPQUFPO0VBRTNCLGFBQWE7R0FDWCxZQUFZLFVBQVUsQ0FBQztHQUN2QixJQUFJLFdBQ0YsVUFBVSxVQUFVLENBQUM7RUFFekI7Q0FDRixHQUFHO0VBQUM7RUFBYTtFQUFXO0NBQVEsQ0FBQztDQUNyQyx5QkFBeUI7RUFDdkIsSUFBSSxXQUFXLFNBQ2IsTUFBTTtDQUVWLENBQUM7Q0FDRCx5QkFBeUI7RUFDdkIsYUFBYTtHQUNYLG9CQUFvQixTQUFTLFdBQVc7R0FHeEMsV0FBVyxVQUFVO0VBQ3ZCO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FDTCxNQUFNLHFCQUFxQixtQkFBa0IsT0FBTTtFQUNqRCxVQUFVLElBQUksRUFBRTtFQUNoQixhQUFhO0dBQ1gsVUFBVSxPQUFPLEVBQUU7RUFDckI7Q0FDRixDQUFDO0NBQ0QsTUFBTSxlQUFBLGFBQXFCLGVBQWU7RUFDeEM7RUFDQTtFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBVTtFQUFZO0VBQW9CO0NBQVksQ0FBQztDQUM1RCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHFCQUFxQixVQUFVO0VBQ3RELE9BQU87RUFDRztDQUNaLENBQUM7QUFDSDtBQUNBLFNBQVMsWUFBWTtDQUNuQix1QkFBTyxJQUFJLElBQUk7QUFDakI7QUFDQSxTQUFTLGtCQUFrQjtDQUN6Qix1QkFBTyxJQUFJLElBQUk7QUFDakI7QUFDQSxTQUFTLHlCQUF5QixLQUFLO0NBQ3JDLE1BQU0sa0NBQWtCLElBQUksSUFBSTtDQUNoQyxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0saUJBQWlCLENBQUM7Q0FDeEIsSUFBSSxTQUFTLGNBQWMsU0FBUztFQUNsQyxJQUFJLENBQUMsS0FBSyxhQUNSO0VBRUYsTUFBTSxRQUFRLGFBQWE7RUFDM0IsTUFBTSxPQUFPO0dBQ1gsT0FBTyxTQUFTO0dBQ2hCLFNBQVM7R0FDVDtFQUNGO0VBQ0EsSUFBSSxVQUFVLE1BQ1osZUFBZSxLQUFLLElBQUk7T0FDbkIsSUFBSSxTQUFTLEdBQUc7R0FDckIsZ0JBQWdCLElBQUksS0FBSztHQUN6QixNQUFNLEtBQUssSUFBSTtFQUNqQjtDQUNGLENBQUM7Q0FDRCxJQUFJLHFCQUFxQjtDQUN6QixlQUFlLE1BQU0sR0FBRyxNQUFNLHVCQUF1QixFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUM7Q0FDMUUsZUFBZSxTQUFRLFNBQVE7RUFDN0IsT0FBTyxnQkFBZ0IsSUFBSSxrQkFBa0IsR0FDM0Msc0JBQXNCO0VBRXhCLEtBQUssUUFBUTtFQUNiLE1BQU0sS0FBSyxJQUFJO0VBQ2Ysc0JBQXNCO0NBQ3hCLENBQUM7Q0FDRCxJQUFJLGdCQUFnQixPQUFPLEdBQ3pCLE1BQU0sTUFBTSxHQUFHLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSztDQUV4QyxPQUFPLENBQUMsT0FBTyxlQUFlLEtBQUksU0FBUSxLQUFLLE9BQU8sQ0FBQztBQUN6RDtBQUNBLFNBQVMsa0JBQWtCLFdBQVcsVUFBVTtDQUM5QyxJQUFJLFdBQVcsVUFBVTtDQUl6QixPQUFPLFlBQVksQ0FBQyxTQUFTLFNBQVMsUUFBUSxHQUM1QyxXQUFXLFNBQVM7Q0FFdEIsT0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLFNBQVM7Q0FDN0IsS0FBSyxNQUFNLFNBQVMsU0FDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sYUFBYSxRQUFRLEtBQUssR0FDbEQsSUFBSSxNQUFNLGFBQWEsRUFBRSxDQUFDLGFBQ3hCLE9BQU87Q0FJYixPQUFPO0FBQ1Q7QUFDQSxTQUFTLHVCQUF1QixHQUFHLEdBQUc7Q0FHcEMsT0FBTyxFQUFFLHdCQUF3QixDQUFDLElBQUksS0FBSyw4QkFBOEIsS0FBSztBQUNoRjs7O0FDdk9BLFNBQWdCLGtCQUFrQixTQUFTO0NBQ3pDLE9BQU8sV0FBVyxRQUFRLFFBQVEsYUFBYSxVQUFVLEtBQUssUUFBUSxhQUFhLGVBQWUsTUFBTTtBQUMxRzs7O0FDUUEsSUFBTSxjQUFjLENBQUM7QUFDckIsU0FBZ0IsaUJBQWlCLFFBQVE7Q0FDdkMsTUFBTSxFQUNKLFlBQVksTUFDWixjQUFjLFFBQ2QsTUFDQSxRQUNBLFdBQ0Esa0JBQWtCLDBCQUNsQiwwQkFBMEIsNkJBQzFCLFNBQVMsYUFDVCx1QkFBdUIsT0FDdkIsc0JBQ0EsaUJBQ0EsZUFBZSxnQkFDYjtDQUNKLE1BQU0sQ0FBQywwQkFBMEIsK0JBQUEsYUFBcUMsU0FBUyxDQUFDO0NBQ2hGLE1BQU0sU0FBUyxRQUFRO0NBQ3ZCLE1BQU0sVUFBQSxhQUFnQixPQUFPLElBQUk7Q0FDakMsTUFBTSxZQUFZLGNBQWMsU0FBUyxXQUFXO0NBQ3BELE1BQU0sY0FBQSxhQUFvQixPQUFPLENBQUMsQ0FBQztDQUNuQyxNQUFNLHdCQUFBLGFBQThCLE9BQU8sS0FBSztDQUNoRCxNQUFNLG1CQUFtQiw0QkFBNEI7Q0FDckQsTUFBTSwyQkFBMkIsbUJBQW1CLE9BQU8sdUJBQXVCLFVBQVU7RUFDMUYsQ0FBQywrQkFBK0IsNEJBQUEsQ0FBNkIsS0FBSztFQUNsRSxJQUFJLHNCQUFzQjtHQUN4QixNQUFNLGdCQUFnQixZQUFZLFFBQVE7R0FDMUMsdUJBQXVCLFFBQVEsU0FBUyxlQUFlLFdBQVcsV0FBVztFQUMvRTtDQUNGLENBQUM7Q0FDRCxNQUFNLGNBQWMsbUJBQWtCLFFBQU87RUFDM0MsSUFBSSxJQUFJLFNBQVMsS0FBSyxzQkFBc0IsU0FDMUM7RUFFRixzQkFBc0IsVUFBVTtFQUNoQyxNQUFNLGlCQUFpQixNQUFNLEtBQUssSUFBSSxLQUFLLENBQUM7RUFDNUMsTUFBTSxhQUFhLGVBQWUsTUFBSyxxQkFBb0Isa0JBQWtCLGFBQUEsNEJBQWtDLENBQUMsS0FBSztFQUlySCxNQUFNLGNBQWMsYUFBYSxJQUFJLElBQUksVUFBVSxDQUFDLEVBQUUsU0FBUyxLQUFLO0VBQ3BFLElBQUksZ0JBQWdCLElBQ2xCLHlCQUF5QixXQUFXO09BQy9CLElBQUksb0JBQW9CLGdCQUFnQixrQkFBa0IsZUFBZSxHQUFHO0dBTWpGLE1BQU0sb0JBQW9CLHlCQUF5QixnQkFBZ0IsRUFDakUsZ0JBQ0YsQ0FBQztHQUNELElBQUksQ0FBQyx1QkFBdUIsZ0JBQWdCLGlCQUFpQixHQUMzRCx5QkFBeUIsaUJBQWlCO0VBRTlDO0VBQ0EsdUJBQXVCLFFBQVEsU0FBUyxZQUFZLFdBQVcsV0FBVztDQUM1RSxDQUFDO0NBQ0QseUJBQXlCO0VBT3ZCLElBQUksbUJBQW1CLFFBQVEsNEJBQTRCLFFBQVEsQ0FBQyxzQkFBc0IsU0FDeEY7RUFFRixNQUFNLFdBQVcsWUFBWTtFQUM3QixJQUFJLG9CQUFvQixVQUFVLGtCQUFrQixlQUFlLEdBQUc7R0FDcEUsTUFBTSxvQkFBb0IseUJBQXlCLFVBQVUsRUFDM0QsZ0JBQ0YsQ0FBQztHQUNELElBQUksQ0FBQyx1QkFBdUIsVUFBVSxpQkFBaUIsR0FDckQseUJBQXlCLGlCQUFpQjtFQUU5QztDQUNGLEdBQUc7RUFBQztFQUFpQjtFQUEwQjtFQUFrQjtFQUFhO0NBQXdCLENBQUM7Q0FDdkcsTUFBTSxnQkFBZ0IsbUJBQW1CLE9BQU8sV0FBVyxjQUFjO0VBQ3ZFLElBQUksQ0FBQyxRQUNILE9BQU87RUFFVCxPQUFPLE9BQU8sT0FBTyxXQUFXLFdBQVcsV0FBVztDQUN4RCxDQUFDO0NBSUQsTUFBTSxZQUFZLG1CQUFrQixVQUFTO0VBQzNDLE1BQU0sY0FBYyxNQUFNLFFBQUEsVUFBZ0IsTUFBTSxRQUFBO0VBQ2hELElBQUksQ0FBQyxlQUFlLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQyx3QkFBd0IsYUFDN0Q7RUFFRixJQUFJLGlCQUFpQixPQUFPLFlBQVksR0FDdEM7RUFHRixJQUFJLENBRFksUUFBUSxTQUV0QjtFQUVGLE1BQU0sUUFBUSxjQUFjO0VBQzVCLE1BQU0sdUJBQXVCLFFBQVEsYUFBYTtFQUNsRCxNQUFNLHdCQUF3QixRQUFRLGNBQWM7RUFDcEQsTUFBTSxhQUFhLGdCQUFnQixhQUFhLGFBQWE7RUFDN0QsTUFBTSxjQUFjLGdCQUFnQixhQUFhLFdBQVc7RUFDNUQsTUFBTSxTQUFTLFVBQVUsTUFBTSxXQUFXO0VBQzFDLElBQUksVUFBVSxRQUFRLGNBQWMsTUFBTSxLQUFLLENBQUMsa0JBQWtCLE1BQU0sR0FBRztHQUN6RSxNQUFNLGlCQUFpQixPQUFPO0dBQzlCLE1BQU0sZUFBZSxPQUFPO0dBQzVCLE1BQU0sY0FBYyxPQUFPO0dBRzNCLElBQUksa0JBQWtCLFFBQVEsTUFBTSxZQUFZLG1CQUFtQixjQUNqRTtHQUdGLElBQUksTUFBTSxRQUFRLGVBQWUsaUJBQWlCLFlBQVksUUFDNUQ7R0FHRixJQUFJLE1BQU0sUUFBUSxjQUFjLGlCQUFpQixHQUMvQztFQUVKO0VBQ0EsSUFBSSxZQUFZO0VBQ2hCLE1BQU0sV0FBVyxnQkFBZ0IsYUFBYSxlQUFlO0VBQzdELE1BQU0sV0FBVyxnQkFBZ0IsYUFBYSxlQUFlO0VBQzdELElBQUksUUFBUSxNQUNWLFlBQVksS0FBSztHQUNmO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsUUFBUTtHQUNSO0dBQ0EsS0FBSztFQUNQLENBQUM7RUFFSCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsTUFBTSxRQUFRLHdCQUF3QixnQkFBZ0IsZ0JBQWdCLE1BQU0sUUFBQTtFQUMvSCxNQUFNLGdCQUFnQixnQkFBZ0IsY0FBYyxNQUFNLFFBQVEseUJBQXlCLGdCQUFnQixnQkFBZ0IsTUFBTSxRQUFBO0VBQ2pJLElBQUksc0JBQXNCO0dBQ3hCLElBQUksTUFBTSxRQUFBLFFBQ1IsWUFBWTtRQUNQLElBQUksTUFBTSxRQUFBLE9BQ2YsWUFBWTtFQUVoQjtFQUNBLElBQUksY0FBYyxxQkFBcUIsZ0JBQWdCLGdCQUFnQjtHQUNyRSxJQUFJLGFBQWEsY0FBYyxZQUFZLGNBQWM7SUFDdkQsWUFBWTtJQUNaLElBQUksUUFDRixZQUFZLE9BQU8sT0FBTyxrQkFBa0IsV0FBVyxXQUFXO0dBRXRFLE9BQU8sSUFBSSxhQUFhLGNBQWMsWUFBWSxlQUFlO0lBQy9ELFlBQVk7SUFDWixJQUFJLFFBQ0YsWUFBWSxPQUFPLE9BQU8sa0JBQWtCLFdBQVcsV0FBVztHQUV0RSxPQUNFLFlBQVkseUJBQXlCLFlBQVksU0FBUztJQUN4RCxlQUFlO0lBQ2YsV0FBVztJQUNYO0dBQ0YsQ0FBQztFQUVMO0VBQ0EsSUFBSSxjQUFjLG9CQUFvQixDQUFDLHVCQUF1QixZQUFZLFNBQVMsU0FBUyxHQUFHO0dBQzdGLElBQUksc0JBQ0YsTUFBTSxnQkFBZ0I7R0FFeEIsSUFBSSxVQUFVLGVBQWUsZ0JBQWdCLGVBQzNDLE1BQU0sZUFBZTtHQUV2Qix5QkFBeUIsV0FBVyxJQUFJO0dBR3hDLHFCQUFxQjtJQUNuQixZQUFZLFFBQVEsVUFBVSxFQUFFLE1BQU07R0FDeEMsQ0FBQztFQUNIO0NBQ0YsQ0FBQztDQWFELE9BQU87RUFDTCxPQUFBO0dBWkEsS0FBSztHQUNMLFFBQVEsT0FBTztJQUNiLE1BQU0sVUFBVSxRQUFRO0lBQ3hCLE1BQU0sU0FBUyxVQUFVLE1BQU0sV0FBVztJQUMxQyxJQUFJLENBQUMsV0FBVyxVQUFVLFFBQVEsQ0FBQyxjQUFjLE1BQU0sR0FDckQ7SUFFRixPQUFPLGtCQUFrQixHQUFHLE9BQU8sTUFBTSxNQUFNO0dBQ2pEO0dBQ0E7RUFHSTtFQUNKO0VBQ0E7RUFDQTtFQUNBO0VBQ0Esb0JBQW9CO0NBQ3RCO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixPQUFPLHFCQUFxQjtDQUNwRCxLQUFLLE1BQU0sT0FBT0EsaUJBQWU7RUFDL0IsSUFBSSxvQkFBb0IsU0FBUyxHQUFHLEdBQ2xDO0VBRUYsSUFBSSxNQUFNLGlCQUFpQixHQUFHLEdBQzVCLE9BQU87Q0FFWDtDQUNBLE9BQU87QUFDVDs7O0FDN05BLElBQWEsbUJBQWdDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQy9CLGlCQUFpQixjQUFjO0FBQzFFLFNBQWdCLGVBQWU7Q0FFN0IsT0FBQSxhQURzQixXQUFXLGdCQUNwQixDQUFDLEVBQUUsYUFBYTtBQUMvQjs7O0FDRUEsU0FBZ0IsY0FBYyxnQkFBZ0I7Q0FDNUMsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLE9BQU9DLGVBQ1AsUUFBUUEsZUFDUixRQUFRLGNBQ1Isd0JBQ0Esa0JBQWtCLHNCQUNsQiwwQkFBMEIsOEJBQzFCLGFBQ0EsTUFDQSxXQUNBLFFBQ0Esc0JBQ0EsYUFBYSxpQkFDYix1QkFBdUIsTUFDdkIsU0FDQSxpQkFDQSxjQUNBLHVCQUF1QixPQUN2QixNQUFNLE9BQ04sR0FBRyxpQkFDRDtDQUVKLE1BQU0sRUFDSixPQUFPLGNBQ1Asa0JBQ0EsMEJBQ0EsYUFDQSxhQUFhLHNCQUNiLHVCQUNFLGlCQUFpQjtFQUNuQjtFQUNBO0VBQ0E7RUFDQTtFQUNBLGtCQUFrQjtFQUNsQiwwQkFBMEI7RUFDMUI7RUFDQTtFQUNBO0VBQ0EsV0FsQmdCLGFBa0JoQjtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxVQUFVLGlCQUFpQixLQUFLLGdCQUFnQjtFQUNwRDtFQUNBLEtBQUs7RUFDTCxPQUFPO0dBQUM7R0FBYyxHQUFHO0dBQU87RUFBWTtFQUM1QztDQUNGLENBQUM7Q0FDRCxNQUFNLGVBQUEsYUFBcUIsZUFBZTtFQUN4QztFQUNBO0VBQ0E7RUFDQTtDQUNGLElBQUk7RUFBQztFQUFrQjtFQUEwQjtFQUFzQjtDQUFrQixDQUFDO0NBQzFGLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUsscUJBQXFCLFVBQVU7RUFDdEQsT0FBTztFQUNQLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssZUFBZTtHQUM1QjtHQUNiLGNBQWEsV0FBVTtJQUNyQixrQkFBa0IsTUFBTTtJQUN4QixxQkFBcUIsTUFBTTtHQUM3QjtHQUNBLFVBQVU7RUFDWixDQUFDO0NBQ0gsQ0FBQztBQUNIOzs7QUMzRUEsU0FBZ0Isd0JBQXdCLFlBQVksSUFBSSxPQUFPLHNCQUFzQixVQUFVLE1BQU0sTUFBTTtDQUN6RyxNQUFNLEVBQ0oseUJBQ0Usb0JBQW9CO0NBQ3hCLE1BQU0sWUFBWSxxQkFBcUIsT0FBTyxDQUFDO0NBSy9DLHlCQUF5QjtFQUN2QixNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLENBQUMsU0FBUztHQUNaLHFCQUFxQixRQUFRLEtBQUEsQ0FBUztHQUN0QztFQUNGO0VBUUEscUJBQXFCLFFBQVE7R0FOM0I7R0FDQSxVQUFVO0dBQ1Y7R0FDQTtHQUNBO0VBRXNDLENBQUM7Q0FDM0MsR0FBRztFQUFDO0VBQVk7RUFBUztFQUFzQjtFQUFJO0VBQU07RUFBc0I7RUFBVztDQUFLLENBQUM7Q0FDaEcseUJBQXlCO0VBQ3ZCLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLGFBQWE7R0FDWCxxQkFBcUIsUUFBUSxLQUFBLENBQVM7RUFDeEM7Q0FDRixHQUFHLENBQUMsc0JBQXNCLFNBQVMsQ0FBQztBQUN0Qzs7O0FDL0JBLElBQWEsY0FBMkIsMkJBQU0sY0FBYztDQUMxRCxZQUFZLEVBQ1YsU0FBUyxLQUNYO0NBQ0EsU0FBUyxFQUNQLFNBQVMsRUFDUCx3QkFBUSxJQUFJLElBQUksRUFDbEIsRUFDRjtDQUNBLFFBQVEsQ0FBQztDQUNULGFBQWE7Q0FDYixnQkFBZ0I7Q0FDaEIsb0JBQW9CLEVBQ2xCLFNBQVMsTUFDWDtBQUNGLENBQUM7QUFDMEMsWUFBWSxjQUFjO0FBQ3JFLFNBQWdCLGlCQUFpQjtDQUMvQixPQUFBLGFBQWEsV0FBVyxXQUFXO0FBQ3JDO0FDWHFCLE9BQU8sS0FBSyxzQkFBc0I7Ozs7Ozs7O0FBUXZELFNBQWdCLGdCQUFnQixPQUFPLGFBQWE7Q0FDbEQsSUFBSSxNQUFNLFFBQVEsV0FBVyxHQUMzQixPQUFPO0NBRVQsSUFBSSxDQUFDLGVBQWUsTUFBTSxTQUFTLGFBQ2pDLE9BQU87Q0FLVCxPQUFPLE1BQU0sU0FBUyxRQUFRLENBQUMsTUFBTSxhQUFhLE1BQU07QUFDMUQ7OztBQzNCQSxJQUFhLHNCQUFtQywyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUNsQyxvQkFBb0IsY0FBYztBQUM3RSxTQUFnQix1QkFBdUIsV0FBVyxPQUFPO0NBQ3ZELE1BQU0sVUFBQSxhQUFnQixXQUFXLG1CQUFtQjtDQUNwRCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQ2YsTUFBTSxJQUFJLE1BQThDLGdHQUEwSDtDQUVwTCxPQUFPO0FBQ1Q7OztBQ09BLElBQU0sZ0JBQWdCLENBQUMsS0FBSzs7Ozs7OztBQVE1QixJQUFhLGFBQTBCLDJCQUFNLFdBQVcsU0FBUyxXQUFXLGdCQUFnQixjQUFjO0NBQ3hHLE1BQU0sRUFDSixRQUNBLFdBQ0EsVUFBVSxjQUNWLFVBQ0EsVUFDQSxlQUFlLG1CQUNmLE9BQU8sZUFDUCxjQUNBLE1BQ0EsTUFBTSxVQUNOLFVBQVUsY0FDVixJQUFJLFFBQ0osT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLFlBQVksaUJBQ1osWUFDQSxnQkFDQSxNQUFNLFdBQ04sVUFBVSxlQUNWLE9BQU8sWUFDUCxZQUNBLFVBQ0EsV0FDQSxpQkFDRSxvQkFBb0I7Q0FDeEIsTUFBTSxFQUNKLFlBQ0Usb0JBQW9CO0NBQ3hCLE1BQU0sRUFDSixhQUNBLGVBQ0UsZUFBZTtDQUNuQixNQUFNLGtCQUFrQix1QkFBdUIsSUFBSTtDQUNuRCxNQUFNLFdBQVcsaUJBQWlCO0NBQ2xDLE1BQU0sT0FBTyxhQUFhO0NBQzFCLE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FDN0IsTUFBTSxDQUFDLGNBQWMsNEJBQTRCLGNBQWM7RUFDN0QsWUFBWTtFQUNaLFNBQVM7RUFDVCxNQUFNO0VBQ04sT0FBTztDQUNULENBQUM7Q0FDRCxNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBSztDQUNsRCxNQUFNLGtCQUFrQixtQkFBbUIsT0FBTyxpQkFBaUI7RUFDakUsb0JBQW9CLE9BQU8sWUFBWTtFQUN2QyxJQUFJLGFBQWEsWUFDZjtFQUVGLHlCQUF5QixLQUFLO0NBQ2hDLENBQUM7Q0FDRCxNQUFNLGtCQUFrQixXQUFXO0NBQ25DLE1BQU0sYUFBQSxhQUFtQixlQUFlLEVBQ3RDLElBQUksVUFBVTtFQUNaLE9BQU8sZ0JBQWdCO0NBQ3pCLEVBQ0YsSUFBSSxDQUFDLGVBQWUsQ0FBQztDQUNyQixNQUFNLGdCQUFBLGFBQXNCLE9BQU8sSUFBSTtDQUN2QyxNQUFNLHVCQUFBLGFBQTZCLE9BQU8sSUFBSTtDQU05QyxTQUFTLFlBQVksYUFBYTtFQUNoQyxJQUFJLFVBQVUsS0FBQTtFQUNkLElBQUksY0FBYztHQUNoQixJQUFJLE9BQU8saUJBQWlCLFlBQzFCLFVBQVUsYUFBYSxXQUFXO1FBRWxDLGFBQWEsVUFBVTtFQUUzQjtFQUNBLGNBQWMsVUFBVTtFQUN4QixPQUFPO0NBQ1Q7Q0FDQSxNQUFNLG1CQUFtQixtQkFBa0IsVUFBUztFQUNsRCxJQUFJLENBQUMsU0FBUyxNQUFNLFVBQ2xCO0VBRUYsSUFBSSxDQUFDLHFCQUFxQixTQUN4QixxQkFBcUIsVUFBVTtFQUVqQyxNQUFNLGVBQWUsY0FBYztFQUNuQyxNQUFNLFVBQVUsTUFBTSxXQUFXLGdCQUFnQixRQUFRLGFBQWEsV0FBVyxZQUFZLEtBQUssSUFBSSxLQUFBO0VBS3RHLGFBQWE7R0FDWCxJQUFJLHFCQUFxQixZQUFZLE9BQ25DLHFCQUFxQixVQUFVO0dBRWpDLElBQUksY0FBYyxZQUFZLE9BQU87SUFDbkMsSUFBSSxTQUFTO0tBQ1gsUUFBUTtLQUNSLGNBQWMsVUFBVTtJQUMxQixPQUNFLFlBQWlCLElBQUk7R0FFekIsT0FDRSxVQUFVO0VBRWQ7Q0FDRixDQUFDO0NBQ0QsTUFBTSxlQUFlLHdCQUF3QjtFQUMzQyxNQUFNLGNBQWMsV0FBVztFQUMvQixJQUFJLENBQUMsYUFDSCxPQUFPLGdCQUFnQjtFQUV6QixLQUFLLE1BQU0sU0FBUyxXQUFXLGlCQUFpQixLQUFLLEdBQ25ELElBQUksTUFBTSxXQUFXLGdCQUFnQixPQUFPLFdBQVcsR0FDckQsT0FBTyxnQkFBZ0I7RUFHM0IsT0FBTztDQUNULENBQUM7Q0FDRCx3QkFBd0IsWUFBWSxJQUFJLGdCQUFnQixNQUFNLGNBQWMsQ0FBQyxVQUFVLFFBQVE7Q0FDL0YsZ0JBQWdCLG9CQUFvQjtFQUNsQyxZQUFZLElBQUk7RUFDaEIsU0FBUyxpQkFBaUIsYUFBYSxZQUFZO0VBQ25ELFVBQVUsZ0JBQWdCLElBQUk7RUFDOUIsV0FBVyxPQUFPLFlBQVk7RUFDOUIsTUFBTSxnQkFBZ0IscUJBQXFCO0VBQzNDLElBQUksZ0JBQWdCLFFBQVEsaUJBQWlCLENBQUMsY0FBYyxVQUUxRCxZQUFpQixhQUFhO0NBRWxDLENBQUM7Q0FDRCxNQUFNLGlCQUFpQixXQUFXLGlCQUFpQjtDQUNuRCxNQUFNLFFBQVE7RUFDWixHQUFHO0VBQ0gsVUFBVSxZQUFZO0VBQ3RCLFVBQVUsWUFBWTtFQUN0QixVQUFVLFlBQVk7Q0FDeEI7Q0FDQSxNQUFNLGVBQUEsYUFBcUIsZUFBZTtFQUN4QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsSUFBSTtFQUFDO0VBQWM7RUFBVTtFQUFNO0VBQVk7RUFBTTtFQUFVO0VBQWtCO0VBQVU7RUFBaUI7RUFBWTtDQUFPLENBQUM7Q0FDaEksTUFBTSxlQUFlO0VBQ25CLElBQUk7RUFDSixNQUFNO0VBQ04saUJBQWlCLFlBQVksS0FBQTtFQUM3QixpQkFBaUIsWUFBWSxLQUFBO0VBQzdCLGlCQUFpQixZQUFZLEtBQUE7RUFDN0IsbUJBQW1CO0VBQ25CLFVBQVU7R0FDUixXQUFXLElBQUk7RUFDakI7RUFDQSxPQUFPLE9BQU87R0FDWixJQUFJLENBQUMsU0FBUyxNQUFNLGVBQWUsTUFBTSxhQUFhLEdBQUc7SUFDdkQsZ0JBQWdCLElBQUk7SUFDcEIsV0FBVyxLQUFLO0lBQ2hCLElBQUksbUJBQW1CLFVBQ3JCLFdBQVcsT0FBTyxZQUFZO0dBRWxDO0VBQ0Y7RUFDQSxpQkFBaUIsT0FBTztHQUN0QixJQUFJLE1BQU0sSUFBSSxXQUFXLE9BQU8sR0FBRztJQUNqQyxXQUFXLElBQUk7SUFDZixXQUFXLElBQUk7R0FDakI7RUFDRjtDQUNGO0NBQ0EsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxrQkFBa0IsVUFBVTtFQUNuRCxPQUFPO0VBQ1AsVUFBdUIsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxlQUFlO0dBQ2pDO0dBQ0c7R0FDSjtHQUNBO0dBQ1AsT0FBTztJQUFDO0lBQWM7S0FBYyxVQUFTLFdBQVcsbUJBQW1CLFlBQVksT0FBTyxLQUFLO0dBQUM7R0FDcEcsTUFBTSxDQUFDLFlBQVk7R0FDbkIsd0JBQXdCO0dBQ3hCLHNCQUFzQjtHQUN0QixjQUFjO0VBQ2hCLENBQUM7Q0FDSCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxXQUFXLGNBQWMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMV19