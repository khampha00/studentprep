define(["exports"], (function(exports) {
	"use strict";
	// @ts-ignore
	try {
		self["workbox:core:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Claim any currently available clients once the service worker
	* becomes active. This is normally used in conjunction with `skipWaiting()`.
	*
	* @memberof workbox-core
	*/
	function clientsClaim() {
		self.addEventListener("activate", () => self.clients.claim());
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const logger = (() => {
		// Don't overwrite this value if it's already set.
		// See https://github.com/GoogleChrome/workbox/pull/2284#issuecomment-560470923
		if (!("__WB_DISABLE_DEV_LOGS" in globalThis)) {
			self.__WB_DISABLE_DEV_LOGS = false;
		}
		let inGroup = false;
		const methodToColorMap = {
			debug: `#7f8c8d`,
			log: `#2ecc71`,
			warn: `#f39c12`,
			error: `#c0392b`,
			groupCollapsed: `#3498db`,
			groupEnd: null
		};
		const print = function(method, args) {
			if (self.__WB_DISABLE_DEV_LOGS) {
				return;
			}
			if (method === "groupCollapsed") {
				// Safari doesn't print all console.groupCollapsed() arguments:
				// https://bugs.webkit.org/show_bug.cgi?id=182754
				if (/^((?!chrome|android).)*safari/i.test(navigator.userAgent)) {
					console[method](...args);
					return;
				}
			}
			const styles = [
				`background: ${methodToColorMap[method]}`,
				`border-radius: 0.5em`,
				`color: white`,
				`font-weight: bold`,
				`padding: 2px 0.5em`
			];
			// When in a group, the workbox prefix is not displayed.
			const logPrefix = inGroup ? [] : ["%cworkbox", styles.join(";")];
			console[method](...logPrefix, ...args);
			if (method === "groupCollapsed") {
				inGroup = true;
			}
			if (method === "groupEnd") {
				inGroup = false;
			}
		};
		// eslint-disable-next-line @typescript-eslint/ban-types
		const api = {};
		const loggerMethods = Object.keys(methodToColorMap);
		for (const key of loggerMethods) {
			const method = key;
			api[method] = (...args) => {
				print(method, args);
			};
		}
		return api;
	})();
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const messages = {
		"invalid-value": ({ paramName, validValueDescription, value }) => {
			if (!paramName || !validValueDescription) {
				throw new Error(`Unexpected input to 'invalid-value' error.`);
			}
			return `The '${paramName}' parameter was given a value with an ` + `unexpected value. ${validValueDescription} Received a value of ` + `${JSON.stringify(value)}.`;
		},
		"not-an-array": ({ moduleName, className, funcName, paramName }) => {
			if (!moduleName || !className || !funcName || !paramName) {
				throw new Error(`Unexpected input to 'not-an-array' error.`);
			}
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${className}.${funcName}()' must be an array.`;
		},
		"incorrect-type": ({ expectedType, paramName, moduleName, className, funcName }) => {
			if (!expectedType || !paramName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'incorrect-type' error.`);
			}
			const classNameStr = className ? `${className}.` : "";
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${classNameStr}` + `${funcName}()' must be of type ${expectedType}.`;
		},
		"incorrect-class": ({ expectedClassName, paramName, moduleName, className, funcName, isReturnValueProblem }) => {
			if (!expectedClassName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'incorrect-class' error.`);
			}
			const classNameStr = className ? `${className}.` : "";
			if (isReturnValueProblem) {
				return `The return value from ` + `'${moduleName}.${classNameStr}${funcName}()' ` + `must be an instance of class ${expectedClassName}.`;
			}
			return `The parameter '${paramName}' passed into ` + `'${moduleName}.${classNameStr}${funcName}()' ` + `must be an instance of class ${expectedClassName}.`;
		},
		"missing-a-method": ({ expectedMethod, paramName, moduleName, className, funcName }) => {
			if (!expectedMethod || !paramName || !moduleName || !className || !funcName) {
				throw new Error(`Unexpected input to 'missing-a-method' error.`);
			}
			return `${moduleName}.${className}.${funcName}() expected the ` + `'${paramName}' parameter to expose a '${expectedMethod}' method.`;
		},
		"add-to-cache-list-unexpected-type": ({ entry }) => {
			return `An unexpected entry was passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' The entry ` + `'${JSON.stringify(entry)}' isn't supported. You must supply an array of ` + `strings with one or more characters, objects with a url property or ` + `Request objects.`;
		},
		"add-to-cache-list-conflicting-entries": ({ firstEntry, secondEntry }) => {
			if (!firstEntry || !secondEntry) {
				throw new Error(`Unexpected input to ` + `'add-to-cache-list-duplicate-entries' error.`);
			}
			return `Two of the entries passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' had the URL ` + `${firstEntry} but different revision details. Workbox is ` + `unable to cache and version the asset correctly. Please remove one ` + `of the entries.`;
		},
		"plugin-error-request-will-fetch": ({ thrownErrorMessage }) => {
			if (!thrownErrorMessage) {
				throw new Error(`Unexpected input to ` + `'plugin-error-request-will-fetch', error.`);
			}
			return `An error was thrown by a plugins 'requestWillFetch()' method. ` + `The thrown error message was: '${thrownErrorMessage}'.`;
		},
		"invalid-cache-name": ({ cacheNameId, value }) => {
			if (!cacheNameId) {
				throw new Error(`Expected a 'cacheNameId' for error 'invalid-cache-name'`);
			}
			return `You must provide a name containing at least one character for ` + `setCacheDetails({${cacheNameId}: '...'}). Received a value of ` + `'${JSON.stringify(value)}'`;
		},
		"unregister-route-but-not-found-with-method": ({ method }) => {
			if (!method) {
				throw new Error(`Unexpected input to ` + `'unregister-route-but-not-found-with-method' error.`);
			}
			return `The route you're trying to unregister was not  previously ` + `registered for the method type '${method}'.`;
		},
		"unregister-route-route-not-registered": () => {
			return `The route you're trying to unregister was not previously ` + `registered.`;
		},
		"queue-replay-failed": ({ name }) => {
			return `Replaying the background sync queue '${name}' failed.`;
		},
		"duplicate-queue-name": ({ name }) => {
			return `The Queue name '${name}' is already being used. ` + `All instances of backgroundSync.Queue must be given unique names.`;
		},
		"expired-test-without-max-age": ({ methodName, paramName }) => {
			return `The '${methodName}()' method can only be used when the ` + `'${paramName}' is used in the constructor.`;
		},
		"unsupported-route-type": ({ moduleName, className, funcName, paramName }) => {
			return `The supplied '${paramName}' parameter was an unsupported type. ` + `Please check the docs for ${moduleName}.${className}.${funcName} for ` + `valid input types.`;
		},
		"not-array-of-class": ({ value, expectedClass, moduleName, className, funcName, paramName }) => {
			return `The supplied '${paramName}' parameter must be an array of ` + `'${expectedClass}' objects. Received '${JSON.stringify(value)},'. ` + `Please check the call to ${moduleName}.${className}.${funcName}() ` + `to fix the issue.`;
		},
		"max-entries-or-age-required": ({ moduleName, className, funcName }) => {
			return `You must define either config.maxEntries or config.maxAgeSeconds` + `in ${moduleName}.${className}.${funcName}`;
		},
		"statuses-or-headers-required": ({ moduleName, className, funcName }) => {
			return `You must define either config.statuses or config.headers` + `in ${moduleName}.${className}.${funcName}`;
		},
		"invalid-string": ({ moduleName, funcName, paramName }) => {
			if (!paramName || !moduleName || !funcName) {
				throw new Error(`Unexpected input to 'invalid-string' error.`);
			}
			return `When using strings, the '${paramName}' parameter must start with ` + `'http' (for cross-origin matches) or '/' (for same-origin matches). ` + `Please see the docs for ${moduleName}.${funcName}() for ` + `more info.`;
		},
		"channel-name-required": () => {
			return `You must provide a channelName to construct a ` + `BroadcastCacheUpdate instance.`;
		},
		"invalid-responses-are-same-args": () => {
			return `The arguments passed into responsesAreSame() appear to be ` + `invalid. Please ensure valid Responses are used.`;
		},
		"expire-custom-caches-only": () => {
			return `You must provide a 'cacheName' property when using the ` + `expiration plugin with a runtime caching strategy.`;
		},
		"unit-must-be-bytes": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'unit-must-be-bytes' error.`);
			}
			return `The 'unit' portion of the Range header must be set to 'bytes'. ` + `The Range header provided was "${normalizedRangeHeader}"`;
		},
		"single-range-only": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'single-range-only' error.`);
			}
			return `Multiple ranges are not supported. Please use a  single start ` + `value, and optional end value. The Range header provided was ` + `"${normalizedRangeHeader}"`;
		},
		"invalid-range-values": ({ normalizedRangeHeader }) => {
			if (!normalizedRangeHeader) {
				throw new Error(`Unexpected input to 'invalid-range-values' error.`);
			}
			return `The Range header is missing both start and end values. At least ` + `one of those values is needed. The Range header provided was ` + `"${normalizedRangeHeader}"`;
		},
		"no-range-header": () => {
			return `No Range header was found in the Request provided.`;
		},
		"range-not-satisfiable": ({ size, start, end }) => {
			return `The start (${start}) and end (${end}) values in the Range are ` + `not satisfiable by the cached response, which is ${size} bytes.`;
		},
		"attempt-to-cache-non-get-request": ({ url, method }) => {
			return `Unable to cache '${url}' because it is a '${method}' request and ` + `only 'GET' requests can be cached.`;
		},
		"cache-put-with-no-response": ({ url }) => {
			return `There was an attempt to cache '${url}' but the response was not ` + `defined.`;
		},
		"no-response": ({ url, error }) => {
			let message = `The strategy could not generate a response for '${url}'.`;
			if (error) {
				message += ` The underlying error is ${error}.`;
			}
			return message;
		},
		"bad-precaching-response": ({ url, status }) => {
			return `The precaching request for '${url}' failed` + (status ? ` with an HTTP status of ${status}.` : `.`);
		},
		"non-precached-url": ({ url }) => {
			return `createHandlerBoundToURL('${url}') was called, but that URL is ` + `not precached. Please pass in a URL that is precached instead.`;
		},
		"add-to-cache-list-conflicting-integrities": ({ url }) => {
			return `Two of the entries passed to ` + `'workbox-precaching.PrecacheController.addToCacheList()' had the URL ` + `${url} with different integrity values. Please remove one of them.`;
		},
		"missing-precache-entry": ({ cacheName, url }) => {
			return `Unable to find a precached response in ${cacheName} for ${url}.`;
		},
		"cross-origin-copy-response": ({ origin }) => {
			return `workbox-core.copyResponse() can only be used with same-origin ` + `responses. It was passed a response with origin ${origin}.`;
		},
		"opaque-streams-source": ({ type }) => {
			const message = `One of the workbox-streams sources resulted in an ` + `'${type}' response.`;
			if (type === "opaqueredirect") {
				return `${message} Please do not use a navigation request that results ` + `in a redirect as a source.`;
			}
			return `${message} Please ensure your sources are CORS-enabled.`;
		}
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const generatorFunction = (code, details = {}) => {
		const message = messages[code];
		if (!message) {
			throw new Error(`Unable to find message for code '${code}'.`);
		}
		return message(details);
	};
	const messageGenerator = generatorFunction;
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Workbox errors should be thrown with this class.
	* This allows use to ensure the type easily in tests,
	* helps developers identify errors from workbox
	* easily and allows use to optimise error
	* messages correctly.
	*
	* @private
	*/
	class WorkboxError extends Error {
		/**
		*
		* @param {string} errorCode The error code that
		* identifies this particular error.
		* @param {Object=} details Any relevant arguments
		* that will help developers identify issues should
		* be added as a key on the context object.
		*/
		constructor(errorCode, details) {
			const message = messageGenerator(errorCode, details);
			super(message);
			this.name = errorCode;
			this.details = details;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/*
	* This method throws if the supplied value is not an array.
	* The destructed values are required to produce a meaningful error for users.
	* The destructed and restructured object is so it's clear what is
	* needed.
	*/
	const isArray = (value, details) => {
		if (!Array.isArray(value)) {
			throw new WorkboxError("not-an-array", details);
		}
	};
	const hasMethod = (object, expectedMethod, details) => {
		const type = typeof object[expectedMethod];
		if (type !== "function") {
			details["expectedMethod"] = expectedMethod;
			throw new WorkboxError("missing-a-method", details);
		}
	};
	const isType = (object, expectedType, details) => {
		if (typeof object !== expectedType) {
			details["expectedType"] = expectedType;
			throw new WorkboxError("incorrect-type", details);
		}
	};
	const isInstance = (object, expectedClass, details) => {
		if (!(object instanceof expectedClass)) {
			details["expectedClassName"] = expectedClass.name;
			throw new WorkboxError("incorrect-class", details);
		}
	};
	const isOneOf = (value, validValues, details) => {
		if (!validValues.includes(value)) {
			details["validValueDescription"] = `Valid values are ${JSON.stringify(validValues)}.`;
			throw new WorkboxError("invalid-value", details);
		}
	};
	const isArrayOfClass = (value, expectedClass, details) => {
		const error = new WorkboxError("not-array-of-class", details);
		if (!Array.isArray(value)) {
			throw error;
		}
		for (const item of value) {
			if (!(item instanceof expectedClass)) {
				throw error;
			}
		}
	};
	const finalAssertExports = {
		hasMethod,
		isArray,
		isInstance,
		isOneOf,
		isType,
		isArrayOfClass
	};
	// @ts-ignore
	try {
		self["workbox:routing:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The default HTTP method, 'GET', used when there's no specific method
	* configured for a route.
	*
	* @type {string}
	*
	* @private
	*/
	const defaultMethod = "GET";
	/**
	* The list of valid HTTP methods associated with requests that could be routed.
	*
	* @type {Array<string>}
	*
	* @private
	*/
	const validMethods = [
		"DELETE",
		"GET",
		"HEAD",
		"PATCH",
		"POST",
		"PUT"
	];
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {function()|Object} handler Either a function, or an object with a
	* 'handle' method.
	* @return {Object} An object with a handle method.
	*
	* @private
	*/
	const normalizeHandler = (handler) => {
		if (handler && typeof handler === "object") {
			{
				finalAssertExports.hasMethod(handler, "handle", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "handler"
				});
			}
			return handler;
		} else {
			{
				finalAssertExports.isType(handler, "function", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "handler"
				});
			}
			return { handle: handler };
		}
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A `Route` consists of a pair of callback functions, "match" and "handler".
	* The "match" callback determine if a route should be used to "handle" a
	* request by returning a non-falsy value if it can. The "handler" callback
	* is called when there is a match and should return a Promise that resolves
	* to a `Response`.
	*
	* @memberof workbox-routing
	*/
	class Route {
		/**
		* Constructor for Route class.
		*
		* @param {workbox-routing~matchCallback} match
		* A callback function that determines whether the route matches a given
		* `fetch` event by returning a non-falsy value.
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resolving to a Response.
		* @param {string} [method='GET'] The HTTP method to match the Route
		* against.
		*/
		constructor(match, handler, method = defaultMethod) {
			{
				finalAssertExports.isType(match, "function", {
					moduleName: "workbox-routing",
					className: "Route",
					funcName: "constructor",
					paramName: "match"
				});
				if (method) {
					finalAssertExports.isOneOf(method, validMethods, { paramName: "method" });
				}
			}
			// These values are referenced directly by Router so cannot be
			// altered by minificaton.
			this.handler = normalizeHandler(handler);
			this.match = match;
			this.method = method;
		}
		/**
		*
		* @param {workbox-routing-handlerCallback} handler A callback
		* function that returns a Promise resolving to a Response
		*/
		setCatchHandler(handler) {
			this.catchHandler = normalizeHandler(handler);
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* RegExpRoute makes it easy to create a regular expression based
	* {@link workbox-routing.Route}.
	*
	* For same-origin requests the RegExp only needs to match part of the URL. For
	* requests against third-party servers, you must define a RegExp that matches
	* the start of the URL.
	*
	* @memberof workbox-routing
	* @extends workbox-routing.Route
	*/
	class RegExpRoute extends Route {
		/**
		* If the regular expression contains
		* [capture groups]{@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp#grouping-back-references},
		* the captured values will be passed to the
		* {@link workbox-routing~handlerCallback} `params`
		* argument.
		*
		* @param {RegExp} regExp The regular expression to match against URLs.
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {string} [method='GET'] The HTTP method to match the Route
		* against.
		*/
		constructor(regExp, handler, method) {
			{
				finalAssertExports.isInstance(regExp, RegExp, {
					moduleName: "workbox-routing",
					className: "RegExpRoute",
					funcName: "constructor",
					paramName: "pattern"
				});
			}
			const match = ({ url }) => {
				const result = regExp.exec(url.href);
				// Return immediately if there's no match.
				if (!result) {
					return;
				}
				// Require that the match start at the first character in the URL string
				// if it's a cross-origin request.
				// See https://github.com/GoogleChrome/workbox/issues/281 for the context
				// behind this behavior.
				if (url.origin !== location.origin && result.index !== 0) {
					{
						logger.debug(`The regular expression '${regExp.toString()}' only partially matched ` + `against the cross-origin URL '${url.toString()}'. RegExpRoute's will only ` + `handle cross-origin requests if they match the entire URL.`);
					}
					return;
				}
				// If the route matches, but there aren't any capture groups defined, then
				// this will return [], which is truthy and therefore sufficient to
				// indicate a match.
				// If there are capture groups, then it will return their values.
				return result.slice(1);
			};
			super(match, handler, method);
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const getFriendlyURL = (url) => {
		const urlObj = new URL(String(url), location.href);
		// See https://github.com/GoogleChrome/workbox/issues/2323
		// We want to include everything, except for the origin if it's same-origin.
		return urlObj.href.replace(new RegExp(`^${location.origin}`), "");
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The Router can be used to process a `FetchEvent` using one or more
	* {@link workbox-routing.Route}, responding with a `Response` if
	* a matching route exists.
	*
	* If no route matches a given a request, the Router will use a "default"
	* handler if one is defined.
	*
	* Should the matching Route throw an error, the Router will use a "catch"
	* handler if one is defined to gracefully deal with issues and respond with a
	* Request.
	*
	* If a request matches multiple routes, the **earliest** registered route will
	* be used to respond to the request.
	*
	* @memberof workbox-routing
	*/
	class Router {
		/**
		* Initializes a new Router.
		*/
		constructor() {
			this._routes = new Map();
			this._defaultHandlerMap = new Map();
		}
		/**
		* @return {Map<string, Array<workbox-routing.Route>>} routes A `Map` of HTTP
		* method name ('GET', etc.) to an array of all the corresponding `Route`
		* instances that are registered.
		*/
		get routes() {
			return this._routes;
		}
		/**
		* Adds a fetch event listener to respond to events when a route matches
		* the event's request.
		*/
		addFetchListener() {
			// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
			self.addEventListener("fetch", (event) => {
				const { request } = event;
				const responsePromise = this.handleRequest({
					request,
					event
				});
				if (responsePromise) {
					event.respondWith(responsePromise);
				}
			});
		}
		/**
		* Adds a message event listener for URLs to cache from the window.
		* This is useful to cache resources loaded on the page prior to when the
		* service worker started controlling it.
		*
		* The format of the message data sent from the window should be as follows.
		* Where the `urlsToCache` array may consist of URL strings or an array of
		* URL string + `requestInit` object (the same as you'd pass to `fetch()`).
		*
		* ```
		* {
		*   type: 'CACHE_URLS',
		*   payload: {
		*     urlsToCache: [
		*       './script1.js',
		*       './script2.js',
		*       ['./script3.js', {mode: 'no-cors'}],
		*     ],
		*   },
		* }
		* ```
		*/
		addCacheListener() {
			// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
			self.addEventListener("message", (event) => {
				// event.data is type 'any'
				// eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
				if (event.data && event.data.type === "CACHE_URLS") {
					// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
					const { payload } = event.data;
					{
						logger.debug(`Caching URLs from the window`, payload.urlsToCache);
					}
					const requestPromises = Promise.all(payload.urlsToCache.map((entry) => {
						if (typeof entry === "string") {
							entry = [entry];
						}
						const request = new Request(...entry);
						return this.handleRequest({
							request,
							event
						});
						// TODO(philipwalton): TypeScript errors without this typecast for
						// some reason (probably a bug). The real type here should work but
						// doesn't: `Array<Promise<Response> | undefined>`.
					}));
					event.waitUntil(requestPromises);
					// If a MessageChannel was used, reply to the message on success.
					if (event.ports && event.ports[0]) {
						void requestPromises.then(() => event.ports[0].postMessage(true));
					}
				}
			});
		}
		/**
		* Apply the routing rules to a FetchEvent object to get a Response from an
		* appropriate Route's handler.
		*
		* @param {Object} options
		* @param {Request} options.request The request to handle.
		* @param {ExtendableEvent} options.event The event that triggered the
		*     request.
		* @return {Promise<Response>|undefined} A promise is returned if a
		*     registered route can handle the request. If there is no matching
		*     route and there's no `defaultHandler`, `undefined` is returned.
		*/
		handleRequest({ request, event }) {
			{
				finalAssertExports.isInstance(request, Request, {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "handleRequest",
					paramName: "options.request"
				});
			}
			const url = new URL(request.url, location.href);
			if (!url.protocol.startsWith("http")) {
				{
					logger.debug(`Workbox Router only supports URLs that start with 'http'.`);
				}
				return;
			}
			const sameOrigin = url.origin === location.origin;
			const { params, route } = this.findMatchingRoute({
				event,
				request,
				sameOrigin,
				url
			});
			let handler = route && route.handler;
			const debugMessages = [];
			{
				if (handler) {
					debugMessages.push([`Found a route to handle this request:`, route]);
					if (params) {
						debugMessages.push([`Passing the following params to the route's handler:`, params]);
					}
				}
			}
			// If we don't have a handler because there was no matching route, then
			// fall back to defaultHandler if that's defined.
			const method = request.method;
			if (!handler && this._defaultHandlerMap.has(method)) {
				{
					debugMessages.push(`Failed to find a matching route. Falling ` + `back to the default handler for ${method}.`);
				}
				handler = this._defaultHandlerMap.get(method);
			}
			if (!handler) {
				{
					// No handler so Workbox will do nothing. If logs is set of debug
					// i.e. verbose, we should print out this information.
					logger.debug(`No route found for: ${getFriendlyURL(url)}`);
				}
				return;
			}
			{
				// We have a handler, meaning Workbox is going to handle the route.
				// print the routing details to the console.
				logger.groupCollapsed(`Router is responding to: ${getFriendlyURL(url)}`);
				debugMessages.forEach((msg) => {
					if (Array.isArray(msg)) {
						logger.log(...msg);
					} else {
						logger.log(msg);
					}
				});
				logger.groupEnd();
			}
			// Wrap in try and catch in case the handle method throws a synchronous
			// error. It should still callback to the catch handler.
			let responsePromise;
			try {
				responsePromise = handler.handle({
					url,
					request,
					event,
					params
				});
			} catch (err) {
				responsePromise = Promise.reject(err);
			}
			// Get route's catch handler, if it exists
			const catchHandler = route && route.catchHandler;
			if (responsePromise instanceof Promise && (this._catchHandler || catchHandler)) {
				responsePromise = responsePromise.catch(async (err) => {
					// If there's a route catch handler, process that first
					if (catchHandler) {
						{
							// Still include URL here as it will be async from the console group
							// and may not make sense without the URL
							logger.groupCollapsed(`Error thrown when responding to: ` + ` ${getFriendlyURL(url)}. Falling back to route's Catch Handler.`);
							logger.error(`Error thrown by:`, route);
							logger.error(err);
							logger.groupEnd();
						}
						try {
							return await catchHandler.handle({
								url,
								request,
								event,
								params
							});
						} catch (catchErr) {
							if (catchErr instanceof Error) {
								err = catchErr;
							}
						}
					}
					if (this._catchHandler) {
						{
							// Still include URL here as it will be async from the console group
							// and may not make sense without the URL
							logger.groupCollapsed(`Error thrown when responding to: ` + ` ${getFriendlyURL(url)}. Falling back to global Catch Handler.`);
							logger.error(`Error thrown by:`, route);
							logger.error(err);
							logger.groupEnd();
						}
						return this._catchHandler.handle({
							url,
							request,
							event
						});
					}
					throw err;
				});
			}
			return responsePromise;
		}
		/**
		* Checks a request and URL (and optionally an event) against the list of
		* registered routes, and if there's a match, returns the corresponding
		* route along with any params generated by the match.
		*
		* @param {Object} options
		* @param {URL} options.url
		* @param {boolean} options.sameOrigin The result of comparing `url.origin`
		*     against the current origin.
		* @param {Request} options.request The request to match.
		* @param {Event} options.event The corresponding event.
		* @return {Object} An object with `route` and `params` properties.
		*     They are populated if a matching route was found or `undefined`
		*     otherwise.
		*/
		findMatchingRoute({ url, sameOrigin, request, event }) {
			const routes = this._routes.get(request.method) || [];
			for (const route of routes) {
				let params;
				// route.match returns type any, not possible to change right now.
				// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
				const matchResult = route.match({
					url,
					sameOrigin,
					request,
					event
				});
				if (matchResult) {
					{
						// Warn developers that using an async matchCallback is almost always
						// not the right thing to do.
						if (matchResult instanceof Promise) {
							logger.warn(`While routing ${getFriendlyURL(url)}, an async ` + `matchCallback function was used. Please convert the ` + `following route to use a synchronous matchCallback function:`, route);
						}
					}
					// See https://github.com/GoogleChrome/workbox/issues/2079
					// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
					params = matchResult;
					if (Array.isArray(params) && params.length === 0) {
						// Instead of passing an empty array in as params, use undefined.
						params = undefined;
					} else if (matchResult.constructor === Object && Object.keys(matchResult).length === 0) {
						// Instead of passing an empty object in as params, use undefined.
						params = undefined;
					} else if (typeof matchResult === "boolean") {
						// For the boolean value true (rather than just something truth-y),
						// don't set params.
						// See https://github.com/GoogleChrome/workbox/pull/2134#issuecomment-513924353
						params = undefined;
					}
					// Return early if have a match.
					return {
						route,
						params
					};
				}
			}
			// If no match was found above, return and empty object.
			return {};
		}
		/**
		* Define a default `handler` that's called when no routes explicitly
		* match the incoming request.
		*
		* Each HTTP method ('GET', 'POST', etc.) gets its own default handler.
		*
		* Without a default handler, unmatched requests will go against the
		* network as if there were no service worker present.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {string} [method='GET'] The HTTP method to associate with this
		* default handler. Each method has its own default.
		*/
		setDefaultHandler(handler, method = defaultMethod) {
			this._defaultHandlerMap.set(method, normalizeHandler(handler));
		}
		/**
		* If a Route throws an error while handling a request, this `handler`
		* will be called and given a chance to provide a response.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		*/
		setCatchHandler(handler) {
			this._catchHandler = normalizeHandler(handler);
		}
		/**
		* Registers a route with the router.
		*
		* @param {workbox-routing.Route} route The route to register.
		*/
		registerRoute(route) {
			{
				finalAssertExports.isType(route, "object", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.hasMethod(route, "match", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.isType(route.handler, "object", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route"
				});
				finalAssertExports.hasMethod(route.handler, "handle", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route.handler"
				});
				finalAssertExports.isType(route.method, "string", {
					moduleName: "workbox-routing",
					className: "Router",
					funcName: "registerRoute",
					paramName: "route.method"
				});
			}
			if (!this._routes.has(route.method)) {
				this._routes.set(route.method, []);
			}
			// Give precedence to all of the earlier routes by adding this additional
			// route to the end of the array.
			this._routes.get(route.method).push(route);
		}
		/**
		* Unregisters a route with the router.
		*
		* @param {workbox-routing.Route} route The route to unregister.
		*/
		unregisterRoute(route) {
			if (!this._routes.has(route.method)) {
				throw new WorkboxError("unregister-route-but-not-found-with-method", { method: route.method });
			}
			const routeIndex = this._routes.get(route.method).indexOf(route);
			if (routeIndex > -1) {
				this._routes.get(route.method).splice(routeIndex, 1);
			} else {
				throw new WorkboxError("unregister-route-route-not-registered");
			}
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let defaultRouter;
	/**
	* Creates a new, singleton Router instance if one does not exist. If one
	* does already exist, that instance is returned.
	*
	* @private
	* @return {Router}
	*/
	const getOrCreateDefaultRouter = () => {
		if (!defaultRouter) {
			defaultRouter = new Router();
			// The helpers that use the default Router assume these listeners exist.
			defaultRouter.addFetchListener();
			defaultRouter.addCacheListener();
		}
		return defaultRouter;
	};
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Easily register a RegExp, string, or function with a caching
	* strategy to a singleton Router instance.
	*
	* This method will generate a Route for you if needed and
	* call {@link workbox-routing.Router#registerRoute}.
	*
	* @param {RegExp|string|workbox-routing.Route~matchCallback|workbox-routing.Route} capture
	* If the capture param is a `Route`, all other arguments will be ignored.
	* @param {workbox-routing~handlerCallback} [handler] A callback
	* function that returns a Promise resulting in a Response. This parameter
	* is required if `capture` is not a `Route` object.
	* @param {string} [method='GET'] The HTTP method to match the Route
	* against.
	* @return {workbox-routing.Route} The generated `Route`.
	*
	* @memberof workbox-routing
	*/
	function registerRoute(capture, handler, method) {
		let route;
		if (typeof capture === "string") {
			const captureUrl = new URL(capture, location.href);
			{
				if (!(capture.startsWith("/") || capture.startsWith("http"))) {
					throw new WorkboxError("invalid-string", {
						moduleName: "workbox-routing",
						funcName: "registerRoute",
						paramName: "capture"
					});
				}
				// We want to check if Express-style wildcards are in the pathname only.
				// TODO: Remove this log message in v4.
				const valueToCheck = capture.startsWith("http") ? captureUrl.pathname : capture;
				// See https://github.com/pillarjs/path-to-regexp#parameters
				const wildcards = "[*:?+]";
				if (new RegExp(`${wildcards}`).exec(valueToCheck)) {
					logger.debug(`The '$capture' parameter contains an Express-style wildcard ` + `character (${wildcards}). Strings are now always interpreted as ` + `exact matches; use a RegExp for partial or wildcard matches.`);
				}
			}
			const matchCallback = ({ url }) => {
				{
					if (url.pathname === captureUrl.pathname && url.origin !== captureUrl.origin) {
						logger.debug(`${capture} only partially matches the cross-origin URL ` + `${url.toString()}. This route will only handle cross-origin requests ` + `if they match the entire URL.`);
					}
				}
				return url.href === captureUrl.href;
			};
			// If `capture` is a string then `handler` and `method` must be present.
			route = new Route(matchCallback, handler, method);
		} else if (capture instanceof RegExp) {
			// If `capture` is a `RegExp` then `handler` and `method` must be present.
			route = new RegExpRoute(capture, handler, method);
		} else if (typeof capture === "function") {
			// If `capture` is a function then `handler` and `method` must be present.
			route = new Route(capture, handler, method);
		} else if (capture instanceof Route) {
			route = capture;
		} else {
			throw new WorkboxError("unsupported-route-type", {
				moduleName: "workbox-routing",
				funcName: "registerRoute",
				paramName: "capture"
			});
		}
		const defaultRouter = getOrCreateDefaultRouter();
		defaultRouter.registerRoute(route);
		return route;
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const _cacheNameDetails = {
		googleAnalytics: "googleAnalytics",
		precache: "precache-v2",
		prefix: "workbox",
		runtime: "runtime",
		suffix: typeof registration !== "undefined" ? registration.scope : ""
	};
	const _createCacheName = (cacheName) => {
		return [
			_cacheNameDetails.prefix,
			cacheName,
			_cacheNameDetails.suffix
		].filter((value) => value && value.length > 0).join("-");
	};
	const eachCacheNameDetail = (fn) => {
		for (const key of Object.keys(_cacheNameDetails)) {
			fn(key);
		}
	};
	const cacheNames = {
		updateDetails: (details) => {
			eachCacheNameDetail((key) => {
				if (typeof details[key] === "string") {
					_cacheNameDetails[key] = details[key];
				}
			});
		},
		getGoogleAnalyticsName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.googleAnalytics);
		},
		getPrecacheName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.precache);
		},
		getPrefix: () => {
			return _cacheNameDetails.prefix;
		},
		getRuntimeName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.runtime);
		},
		getSuffix: () => {
			return _cacheNameDetails.suffix;
		}
	};
	/*
	Copyright 2020 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A utility method that makes it easier to use `event.waitUntil` with
	* async functions and return the result.
	*
	* @param {ExtendableEvent} event
	* @param {Function} asyncFn
	* @return {Function}
	* @private
	*/
	function waitUntil(event, asyncFn) {
		const returnPromise = asyncFn();
		event.waitUntil(returnPromise);
		return returnPromise;
	}
	// @ts-ignore
	try {
		self["workbox:precaching:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	// Name of the search parameter used to store revision info.
	const REVISION_SEARCH_PARAM = "__WB_REVISION__";
	/**
	* Converts a manifest entry into a versioned URL suitable for precaching.
	*
	* @param {Object|string} entry
	* @return {string} A URL with versioning info.
	*
	* @private
	* @memberof workbox-precaching
	*/
	function createCacheKey(entry) {
		if (!entry) {
			throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		}
		// If a precache manifest entry is a string, it's assumed to be a versioned
		// URL, like '/app.abcd1234.js'. Return as-is.
		if (typeof entry === "string") {
			const urlObject = new URL(entry, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		const { revision, url } = entry;
		if (!url) {
			throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		}
		// If there's just a URL and no revision, then it's also assumed to be a
		// versioned URL.
		if (!revision) {
			const urlObject = new URL(url, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		// Otherwise, construct a properly versioned URL using the custom Workbox
		// search parameter along with the revision info.
		const cacheKeyURL = new URL(url, location.href);
		const originalURL = new URL(url, location.href);
		cacheKeyURL.searchParams.set(REVISION_SEARCH_PARAM, revision);
		return {
			cacheKey: cacheKeyURL.href,
			url: originalURL.href
		};
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A plugin, designed to be used with PrecacheController, to determine the
	* of assets that were updated (or not updated) during the install event.
	*
	* @private
	*/
	class PrecacheInstallReportPlugin {
		constructor() {
			this.updatedURLs = [];
			this.notUpdatedURLs = [];
			this.handlerWillStart = async ({ request, state }) => {
				// TODO: `state` should never be undefined...
				if (state) {
					state.originalRequest = request;
				}
			};
			this.cachedResponseWillBeUsed = async ({ event, state, cachedResponse }) => {
				if (event.type === "install") {
					if (state && state.originalRequest && state.originalRequest instanceof Request) {
						// TODO: `state` should never be undefined...
						const url = state.originalRequest.url;
						if (cachedResponse) {
							this.notUpdatedURLs.push(url);
						} else {
							this.updatedURLs.push(url);
						}
					}
				}
				return cachedResponse;
			};
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A plugin, designed to be used with PrecacheController, to translate URLs into
	* the corresponding cache key, based on the current revision info.
	*
	* @private
	*/
	class PrecacheCacheKeyPlugin {
		constructor({ precacheController }) {
			this.cacheKeyWillBeUsed = async ({ request, params }) => {
				// Params is type any, can't change right now.
				/* eslint-disable */
				const cacheKey = (params === null || params === void 0 ? void 0 : params.cacheKey) || this._precacheController.getCacheKeyForURL(request.url);
				/* eslint-enable */
				return cacheKey ? new Request(cacheKey, { headers: request.headers }) : request;
			};
			this._precacheController = precacheController;
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {string} groupTitle
	* @param {Array<string>} deletedURLs
	*
	* @private
	*/
	const logGroup = (groupTitle, deletedURLs) => {
		logger.groupCollapsed(groupTitle);
		for (const url of deletedURLs) {
			logger.log(url);
		}
		logger.groupEnd();
	};
	/**
	* @param {Array<string>} deletedURLs
	*
	* @private
	* @memberof workbox-precaching
	*/
	function printCleanupDetails(deletedURLs) {
		const deletionCount = deletedURLs.length;
		if (deletionCount > 0) {
			logger.groupCollapsed(`During precaching cleanup, ` + `${deletionCount} cached ` + `request${deletionCount === 1 ? " was" : "s were"} deleted.`);
			logGroup("Deleted Cache Requests", deletedURLs);
			logger.groupEnd();
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* @param {string} groupTitle
	* @param {Array<string>} urls
	*
	* @private
	*/
	function _nestedGroup(groupTitle, urls) {
		if (urls.length === 0) {
			return;
		}
		logger.groupCollapsed(groupTitle);
		for (const url of urls) {
			logger.log(url);
		}
		logger.groupEnd();
	}
	/**
	* @param {Array<string>} urlsToPrecache
	* @param {Array<string>} urlsAlreadyPrecached
	*
	* @private
	* @memberof workbox-precaching
	*/
	function printInstallDetails(urlsToPrecache, urlsAlreadyPrecached) {
		const precachedCount = urlsToPrecache.length;
		const alreadyPrecachedCount = urlsAlreadyPrecached.length;
		if (precachedCount || alreadyPrecachedCount) {
			let message = `Precaching ${precachedCount} file${precachedCount === 1 ? "" : "s"}.`;
			if (alreadyPrecachedCount > 0) {
				message += ` ${alreadyPrecachedCount} ` + `file${alreadyPrecachedCount === 1 ? " is" : "s are"} already cached.`;
			}
			logger.groupCollapsed(message);
			_nestedGroup(`View newly precached URLs.`, urlsToPrecache);
			_nestedGroup(`View previously precached URLs.`, urlsAlreadyPrecached);
			logger.groupEnd();
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let supportStatus;
	/**
	* A utility function that determines whether the current browser supports
	* constructing a new `Response` from a `response.body` stream.
	*
	* @return {boolean} `true`, if the current browser can successfully
	*     construct a `Response` from a `response.body` stream, `false` otherwise.
	*
	* @private
	*/
	function canConstructResponseFromBodyStream() {
		if (supportStatus === undefined) {
			const testResponse = new Response("");
			if ("body" in testResponse) {
				try {
					new Response(testResponse.body);
					supportStatus = true;
				} catch (error) {
					supportStatus = false;
				}
			}
			supportStatus = false;
		}
		return supportStatus;
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Allows developers to copy a response and modify its `headers`, `status`,
	* or `statusText` values (the values settable via a
	* [`ResponseInit`]{@link https://developer.mozilla.org/en-US/docs/Web/API/Response/Response#Syntax}
	* object in the constructor).
	* To modify these values, pass a function as the second argument. That
	* function will be invoked with a single object with the response properties
	* `{headers, status, statusText}`. The return value of this function will
	* be used as the `ResponseInit` for the new `Response`. To change the values
	* either modify the passed parameter(s) and return it, or return a totally
	* new object.
	*
	* This method is intentionally limited to same-origin responses, regardless of
	* whether CORS was used or not.
	*
	* @param {Response} response
	* @param {Function} modifier
	* @memberof workbox-core
	*/
	async function copyResponse(response, modifier) {
		let origin = null;
		// If response.url isn't set, assume it's cross-origin and keep origin null.
		if (response.url) {
			const responseURL = new URL(response.url);
			origin = responseURL.origin;
		}
		if (origin !== self.location.origin) {
			throw new WorkboxError("cross-origin-copy-response", { origin });
		}
		const clonedResponse = response.clone();
		// Create a fresh `ResponseInit` object by cloning the headers.
		const responseInit = {
			headers: new Headers(clonedResponse.headers),
			status: clonedResponse.status,
			statusText: clonedResponse.statusText
		};
		// Apply any user modifications.
		const modifiedResponseInit = responseInit;
		// Create the new response from the body stream and `ResponseInit`
		// modifications. Note: not all browsers support the Response.body stream,
		// so fall back to reading the entire body into memory as a blob.
		const body = canConstructResponseFromBodyStream() ? clonedResponse.body : await clonedResponse.blob();
		return new Response(body, modifiedResponseInit);
	}
	/*
	Copyright 2020 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	function stripParams(fullURL, ignoreParams) {
		const strippedURL = new URL(fullURL);
		for (const param of ignoreParams) {
			strippedURL.searchParams.delete(param);
		}
		return strippedURL.href;
	}
	/**
	* Matches an item in the cache, ignoring specific URL params. This is similar
	* to the `ignoreSearch` option, but it allows you to ignore just specific
	* params (while continuing to match on the others).
	*
	* @private
	* @param {Cache} cache
	* @param {Request} request
	* @param {Object} matchOptions
	* @param {Array<string>} ignoreParams
	* @return {Promise<Response|undefined>}
	*/
	async function cacheMatchIgnoreParams(cache, request, ignoreParams, matchOptions) {
		const strippedRequestURL = stripParams(request.url, ignoreParams);
		// If the request doesn't include any ignored params, match as normal.
		if (request.url === strippedRequestURL) {
			return cache.match(request, matchOptions);
		}
		// Otherwise, match by comparing keys
		const keysOptions = Object.assign(Object.assign({}, matchOptions), { ignoreSearch: true });
		const cacheKeys = await cache.keys(request, keysOptions);
		for (const cacheKey of cacheKeys) {
			const strippedCacheKeyURL = stripParams(cacheKey.url, ignoreParams);
			if (strippedRequestURL === strippedCacheKeyURL) {
				return cache.match(cacheKey, matchOptions);
			}
		}
		return;
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* The Deferred class composes Promises in a way that allows for them to be
	* resolved or rejected from outside the constructor. In most cases promises
	* should be used directly, but Deferreds can be necessary when the logic to
	* resolve a promise must be separate.
	*
	* @private
	*/
	class Deferred {
		/**
		* Creates a promise and exposes its resolve and reject functions as methods.
		*/
		constructor() {
			this.promise = new Promise((resolve, reject) => {
				this.resolve = resolve;
				this.reject = reject;
			});
		}
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	// Callbacks to be executed whenever there's a quota error.
	// Can't change Function type right now.
	// eslint-disable-next-line @typescript-eslint/ban-types
	const quotaErrorCallbacks = new Set();
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Runs all of the callback functions, one at a time sequentially, in the order
	* in which they were registered.
	*
	* @memberof workbox-core
	* @private
	*/
	async function executeQuotaErrorCallbacks() {
		{
			logger.log(`About to run ${quotaErrorCallbacks.size} ` + `callbacks to clean up caches.`);
		}
		for (const callback of quotaErrorCallbacks) {
			await callback();
			{
				logger.log(callback, "is complete.");
			}
		}
		{
			logger.log("Finished running callbacks.");
		}
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Returns a promise that resolves and the passed number of milliseconds.
	* This utility is an async/await-friendly version of `setTimeout`.
	*
	* @param {number} ms
	* @return {Promise}
	* @private
	*/
	function timeout(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	// @ts-ignore
	try {
		self["workbox:strategies:7.4.0"] && _();
	} catch (e) {}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	function toRequest(input) {
		return typeof input === "string" ? new Request(input) : input;
	}
	/**
	* A class created every time a Strategy instance calls
	* {@link workbox-strategies.Strategy~handle} or
	* {@link workbox-strategies.Strategy~handleAll} that wraps all fetch and
	* cache actions around plugin callbacks and keeps track of when the strategy
	* is "done" (i.e. all added `event.waitUntil()` promises have resolved).
	*
	* @memberof workbox-strategies
	*/
	class StrategyHandler {
		/**
		* Creates a new instance associated with the passed strategy and event
		* that's handling the request.
		*
		* The constructor also initializes the state that will be passed to each of
		* the plugins handling this request.
		*
		* @param {workbox-strategies.Strategy} strategy
		* @param {Object} options
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params] The return value from the
		*     {@link workbox-routing~matchCallback} (if applicable).
		*/
		constructor(strategy, options) {
			this._cacheKeys = {};
			/**
			* The request the strategy is performing (passed to the strategy's
			* `handle()` or `handleAll()` method).
			* @name request
			* @instance
			* @type {Request}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* The event associated with this request.
			* @name event
			* @instance
			* @type {ExtendableEvent}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* A `URL` instance of `request.url` (if passed to the strategy's
			* `handle()` or `handleAll()` method).
			* Note: the `url` param will be present if the strategy was invoked
			* from a workbox `Route` object.
			* @name url
			* @instance
			* @type {URL|undefined}
			* @memberof workbox-strategies.StrategyHandler
			*/
			/**
			* A `param` value (if passed to the strategy's
			* `handle()` or `handleAll()` method).
			* Note: the `param` param will be present if the strategy was invoked
			* from a workbox `Route` object and the
			* {@link workbox-routing~matchCallback} returned
			* a truthy value (it will be that value).
			* @name params
			* @instance
			* @type {*|undefined}
			* @memberof workbox-strategies.StrategyHandler
			*/
			{
				finalAssertExports.isInstance(options.event, ExtendableEvent, {
					moduleName: "workbox-strategies",
					className: "StrategyHandler",
					funcName: "constructor",
					paramName: "options.event"
				});
			}
			Object.assign(this, options);
			this.event = options.event;
			this._strategy = strategy;
			this._handlerDeferred = new Deferred();
			this._extendLifetimePromises = [];
			// Copy the plugins list (since it's mutable on the strategy),
			// so any mutations don't affect this handler instance.
			this._plugins = [...strategy.plugins];
			this._pluginStateMap = new Map();
			for (const plugin of this._plugins) {
				this._pluginStateMap.set(plugin, {});
			}
			this.event.waitUntil(this._handlerDeferred.promise);
		}
		/**
		* Fetches a given request (and invokes any applicable plugin callback
		* methods) using the `fetchOptions` (for non-navigation requests) and
		* `plugins` defined on the `Strategy` object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - `requestWillFetch()`
		* - `fetchDidSucceed()`
		* - `fetchDidFail()`
		*
		* @param {Request|string} input The URL or request to fetch.
		* @return {Promise<Response>}
		*/
		async fetch(input) {
			const { event } = this;
			let request = toRequest(input);
			if (request.mode === "navigate" && event instanceof FetchEvent && event.preloadResponse) {
				const possiblePreloadResponse = await event.preloadResponse;
				if (possiblePreloadResponse) {
					{
						logger.log(`Using a preloaded navigation response for ` + `'${getFriendlyURL(request.url)}'`);
					}
					return possiblePreloadResponse;
				}
			}
			// If there is a fetchDidFail plugin, we need to save a clone of the
			// original request before it's either modified by a requestWillFetch
			// plugin or before the original request's body is consumed via fetch().
			const originalRequest = this.hasCallback("fetchDidFail") ? request.clone() : null;
			try {
				for (const cb of this.iterateCallbacks("requestWillFetch")) {
					request = await cb({
						request: request.clone(),
						event
					});
				}
			} catch (err) {
				if (err instanceof Error) {
					throw new WorkboxError("plugin-error-request-will-fetch", { thrownErrorMessage: err.message });
				}
			}
			// The request can be altered by plugins with `requestWillFetch` making
			// the original request (most likely from a `fetch` event) different
			// from the Request we make. Pass both to `fetchDidFail` to aid debugging.
			const pluginFilteredRequest = request.clone();
			try {
				let fetchResponse;
				// See https://github.com/GoogleChrome/workbox/issues/1796
				fetchResponse = await fetch(request, request.mode === "navigate" ? undefined : this._strategy.fetchOptions);
				if ("development" !== "production") {
					logger.debug(`Network request for ` + `'${getFriendlyURL(request.url)}' returned a response with ` + `status '${fetchResponse.status}'.`);
				}
				for (const callback of this.iterateCallbacks("fetchDidSucceed")) {
					fetchResponse = await callback({
						event,
						request: pluginFilteredRequest,
						response: fetchResponse
					});
				}
				return fetchResponse;
			} catch (error) {
				{
					logger.log(`Network request for ` + `'${getFriendlyURL(request.url)}' threw an error.`, error);
				}
				// `originalRequest` will only exist if a `fetchDidFail` callback
				// is being used (see above).
				if (originalRequest) {
					await this.runCallbacks("fetchDidFail", {
						error,
						event,
						originalRequest: originalRequest.clone(),
						request: pluginFilteredRequest.clone()
					});
				}
				throw error;
			}
		}
		/**
		* Calls `this.fetch()` and (in the background) runs `this.cachePut()` on
		* the response generated by `this.fetch()`.
		*
		* The call to `this.cachePut()` automatically invokes `this.waitUntil()`,
		* so you do not have to manually call `waitUntil()` on the event.
		*
		* @param {Request|string} input The request or URL to fetch and cache.
		* @return {Promise<Response>}
		*/
		async fetchAndCachePut(input) {
			const response = await this.fetch(input);
			const responseClone = response.clone();
			void this.waitUntil(this.cachePut(input, responseClone));
			return response;
		}
		/**
		* Matches a request from the cache (and invokes any applicable plugin
		* callback methods) using the `cacheName`, `matchOptions`, and `plugins`
		* defined on the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cachedResponseWillBeUsed()
		*
		* @param {Request|string} key The Request or URL to use as the cache key.
		* @return {Promise<Response|undefined>} A matching response, if found.
		*/
		async cacheMatch(key) {
			const request = toRequest(key);
			let cachedResponse;
			const { cacheName, matchOptions } = this._strategy;
			const effectiveRequest = await this.getCacheKey(request, "read");
			const multiMatchOptions = Object.assign(Object.assign({}, matchOptions), { cacheName });
			cachedResponse = await caches.match(effectiveRequest, multiMatchOptions);
			{
				if (cachedResponse) {
					logger.debug(`Found a cached response in '${cacheName}'.`);
				} else {
					logger.debug(`No cached response found in '${cacheName}'.`);
				}
			}
			for (const callback of this.iterateCallbacks("cachedResponseWillBeUsed")) {
				cachedResponse = await callback({
					cacheName,
					matchOptions,
					cachedResponse,
					request: effectiveRequest,
					event: this.event
				}) || undefined;
			}
			return cachedResponse;
		}
		/**
		* Puts a request/response pair in the cache (and invokes any applicable
		* plugin callback methods) using the `cacheName` and `plugins` defined on
		* the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cacheWillUpdate()
		* - cacheDidUpdate()
		*
		* @param {Request|string} key The request or URL to use as the cache key.
		* @param {Response} response The response to cache.
		* @return {Promise<boolean>} `false` if a cacheWillUpdate caused the response
		* not be cached, and `true` otherwise.
		*/
		async cachePut(key, response) {
			const request = toRequest(key);
			// Run in the next task to avoid blocking other cache reads.
			// https://github.com/w3c/ServiceWorker/issues/1397
			await timeout(0);
			const effectiveRequest = await this.getCacheKey(request, "write");
			{
				if (effectiveRequest.method && effectiveRequest.method !== "GET") {
					throw new WorkboxError("attempt-to-cache-non-get-request", {
						url: getFriendlyURL(effectiveRequest.url),
						method: effectiveRequest.method
					});
				}
				// See https://github.com/GoogleChrome/workbox/issues/2818
				const vary = response.headers.get("Vary");
				if (vary) {
					logger.debug(`The response for ${getFriendlyURL(effectiveRequest.url)} ` + `has a 'Vary: ${vary}' header. ` + `Consider setting the {ignoreVary: true} option on your strategy ` + `to ensure cache matching and deletion works as expected.`);
				}
			}
			if (!response) {
				{
					logger.error(`Cannot cache non-existent response for ` + `'${getFriendlyURL(effectiveRequest.url)}'.`);
				}
				throw new WorkboxError("cache-put-with-no-response", { url: getFriendlyURL(effectiveRequest.url) });
			}
			const responseToCache = await this._ensureResponseSafeToCache(response);
			if (!responseToCache) {
				{
					logger.debug(`Response '${getFriendlyURL(effectiveRequest.url)}' ` + `will not be cached.`, responseToCache);
				}
				return false;
			}
			const { cacheName, matchOptions } = this._strategy;
			const cache = await self.caches.open(cacheName);
			const hasCacheUpdateCallback = this.hasCallback("cacheDidUpdate");
			const oldResponse = hasCacheUpdateCallback ? await cacheMatchIgnoreParams(
				// TODO(philipwalton): the `__WB_REVISION__` param is a precaching
				// feature. Consider into ways to only add this behavior if using
				// precaching.
				cache,
				effectiveRequest.clone(),
				["__WB_REVISION__"],
				matchOptions
			) : null;
			{
				logger.debug(`Updating the '${cacheName}' cache with a new Response ` + `for ${getFriendlyURL(effectiveRequest.url)}.`);
			}
			try {
				await cache.put(effectiveRequest, hasCacheUpdateCallback ? responseToCache.clone() : responseToCache);
			} catch (error) {
				if (error instanceof Error) {
					// See https://developer.mozilla.org/en-US/docs/Web/API/DOMException#exception-QuotaExceededError
					if (error.name === "QuotaExceededError") {
						await executeQuotaErrorCallbacks();
					}
					throw error;
				}
			}
			for (const callback of this.iterateCallbacks("cacheDidUpdate")) {
				await callback({
					cacheName,
					oldResponse,
					newResponse: responseToCache.clone(),
					request: effectiveRequest,
					event: this.event
				});
			}
			return true;
		}
		/**
		* Checks the list of plugins for the `cacheKeyWillBeUsed` callback, and
		* executes any of those callbacks found in sequence. The final `Request`
		* object returned by the last plugin is treated as the cache key for cache
		* reads and/or writes. If no `cacheKeyWillBeUsed` plugin callbacks have
		* been registered, the passed request is returned unmodified
		*
		* @param {Request} request
		* @param {string} mode
		* @return {Promise<Request>}
		*/
		async getCacheKey(request, mode) {
			const key = `${request.url} | ${mode}`;
			if (!this._cacheKeys[key]) {
				let effectiveRequest = request;
				for (const callback of this.iterateCallbacks("cacheKeyWillBeUsed")) {
					effectiveRequest = toRequest(await callback({
						mode,
						request: effectiveRequest,
						event: this.event,
						// params has a type any can't change right now.
						params: this.params
					}));
				}
				this._cacheKeys[key] = effectiveRequest;
			}
			return this._cacheKeys[key];
		}
		/**
		* Returns true if the strategy has at least one plugin with the given
		* callback.
		*
		* @param {string} name The name of the callback to check for.
		* @return {boolean}
		*/
		hasCallback(name) {
			for (const plugin of this._strategy.plugins) {
				if (name in plugin) {
					return true;
				}
			}
			return false;
		}
		/**
		* Runs all plugin callbacks matching the given name, in order, passing the
		* given param object (merged ith the current plugin state) as the only
		* argument.
		*
		* Note: since this method runs all plugins, it's not suitable for cases
		* where the return value of a callback needs to be applied prior to calling
		* the next callback. See
		* {@link workbox-strategies.StrategyHandler#iterateCallbacks}
		* below for how to handle that case.
		*
		* @param {string} name The name of the callback to run within each plugin.
		* @param {Object} param The object to pass as the first (and only) param
		*     when executing each callback. This object will be merged with the
		*     current plugin state prior to callback execution.
		*/
		async runCallbacks(name, param) {
			for (const callback of this.iterateCallbacks(name)) {
				// TODO(philipwalton): not sure why `any` is needed. It seems like
				// this should work with `as WorkboxPluginCallbackParam[C]`.
				await callback(param);
			}
		}
		/**
		* Accepts a callback and returns an iterable of matching plugin callbacks,
		* where each callback is wrapped with the current handler state (i.e. when
		* you call each callback, whatever object parameter you pass it will
		* be merged with the plugin's current state).
		*
		* @param {string} name The name fo the callback to run
		* @return {Array<Function>}
		*/
		*iterateCallbacks(name) {
			for (const plugin of this._strategy.plugins) {
				if (typeof plugin[name] === "function") {
					const state = this._pluginStateMap.get(plugin);
					const statefulCallback = (param) => {
						const statefulParam = Object.assign(Object.assign({}, param), { state });
						// TODO(philipwalton): not sure why `any` is needed. It seems like
						// this should work with `as WorkboxPluginCallbackParam[C]`.
						return plugin[name](statefulParam);
					};
					yield statefulCallback;
				}
			}
		}
		/**
		* Adds a promise to the
		* [extend lifetime promises]{@link https://w3c.github.io/ServiceWorker/#extendableevent-extend-lifetime-promises}
		* of the event associated with the request being handled (usually a
		* `FetchEvent`).
		*
		* Note: you can await
		* {@link workbox-strategies.StrategyHandler~doneWaiting}
		* to know when all added promises have settled.
		*
		* @param {Promise} promise A promise to add to the extend lifetime promises
		*     of the event that triggered the request.
		*/
		waitUntil(promise) {
			this._extendLifetimePromises.push(promise);
			return promise;
		}
		/**
		* Returns a promise that resolves once all promises passed to
		* {@link workbox-strategies.StrategyHandler~waitUntil}
		* have settled.
		*
		* Note: any work done after `doneWaiting()` settles should be manually
		* passed to an event's `waitUntil()` method (not this handler's
		* `waitUntil()` method), otherwise the service worker thread may be killed
		* prior to your work completing.
		*/
		async doneWaiting() {
			while (this._extendLifetimePromises.length) {
				const promises = this._extendLifetimePromises.splice(0);
				const result = await Promise.allSettled(promises);
				const firstRejection = result.find((i) => i.status === "rejected");
				if (firstRejection) {
					throw firstRejection.reason;
				}
			}
		}
		/**
		* Stops running the strategy and immediately resolves any pending
		* `waitUntil()` promises.
		*/
		destroy() {
			this._handlerDeferred.resolve(null);
		}
		/**
		* This method will call cacheWillUpdate on the available plugins (or use
		* status === 200) to determine if the Response is safe and valid to cache.
		*
		* @param {Request} options.request
		* @param {Response} options.response
		* @return {Promise<Response|undefined>}
		*
		* @private
		*/
		async _ensureResponseSafeToCache(response) {
			let responseToCache = response;
			let pluginsUsed = false;
			for (const callback of this.iterateCallbacks("cacheWillUpdate")) {
				responseToCache = await callback({
					request: this.request,
					response: responseToCache,
					event: this.event
				}) || undefined;
				pluginsUsed = true;
				if (!responseToCache) {
					break;
				}
			}
			if (!pluginsUsed) {
				if (responseToCache && responseToCache.status !== 200) {
					responseToCache = undefined;
				}
				{
					if (responseToCache) {
						if (responseToCache.status !== 200) {
							if (responseToCache.status === 0) {
								logger.warn(`The response for '${this.request.url}' ` + `is an opaque response. The caching strategy that you're ` + `using will not cache opaque responses by default.`);
							} else {
								logger.debug(`The response for '${this.request.url}' ` + `returned a status code of '${response.status}' and won't ` + `be cached as a result.`);
							}
						}
					}
				}
			}
			return responseToCache;
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* An abstract base class that all other strategy classes must extend from:
	*
	* @memberof workbox-strategies
	*/
	class Strategy {
		/**
		* Creates a new instance of the strategy and sets all documented option
		* properties as public instance properties.
		*
		* Note: if a custom strategy class extends the base Strategy class and does
		* not need more than these properties, it does not need to define its own
		* constructor.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
		* of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
		* `fetch()` requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		*/
		constructor(options = {}) {
			/**
			* Cache name to store and retrieve
			* requests. Defaults to the cache names provided by
			* {@link workbox-core.cacheNames}.
			*
			* @type {string}
			*/
			this.cacheName = cacheNames.getRuntimeName(options.cacheName);
			/**
			* The list
			* [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
			* used by this strategy.
			*
			* @type {Array<Object>}
			*/
			this.plugins = options.plugins || [];
			/**
			* Values passed along to the
			* [`init`]{@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters}
			* of all fetch() requests made by this strategy.
			*
			* @type {Object}
			*/
			this.fetchOptions = options.fetchOptions;
			/**
			* The
			* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
			* for any `cache.match()` or `cache.put()` calls made by this strategy.
			*
			* @type {Object}
			*/
			this.matchOptions = options.matchOptions;
		}
		/**
		* Perform a request strategy and returns a `Promise` that will resolve with
		* a `Response`, invoking all relevant plugin callbacks.
		*
		* When a strategy instance is registered with a Workbox
		* {@link workbox-routing.Route}, this method is automatically
		* called when the route matches.
		*
		* Alternatively, this method can be used in a standalone `FetchEvent`
		* listener by passing it to `event.respondWith()`.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		*/
		handle(options) {
			const [responseDone] = this.handleAll(options);
			return responseDone;
		}
		/**
		* Similar to {@link workbox-strategies.Strategy~handle}, but
		* instead of just returning a `Promise` that resolves to a `Response` it
		* it will return an tuple of `[response, done]` promises, where the former
		* (`response`) is equivalent to what `handle()` returns, and the latter is a
		* Promise that will resolve once any promises that were added to
		* `event.waitUntil()` as part of performing the strategy have completed.
		*
		* You can await the `done` promise to ensure any extra work performed by
		* the strategy (usually caching responses) completes successfully.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		* @return {Array<Promise>} A tuple of [response, done]
		*     promises that can be used to determine when the response resolves as
		*     well as when the handler has completed all its work.
		*/
		handleAll(options) {
			// Allow for flexible options to be passed.
			if (options instanceof FetchEvent) {
				options = {
					event: options,
					request: options.request
				};
			}
			const event = options.event;
			const request = typeof options.request === "string" ? new Request(options.request) : options.request;
			const params = "params" in options ? options.params : undefined;
			const handler = new StrategyHandler(this, {
				event,
				request,
				params
			});
			const responseDone = this._getResponse(handler, request, event);
			const handlerDone = this._awaitComplete(responseDone, handler, request, event);
			// Return an array of promises, suitable for use with Promise.all().
			return [responseDone, handlerDone];
		}
		async _getResponse(handler, request, event) {
			await handler.runCallbacks("handlerWillStart", {
				event,
				request
			});
			let response = undefined;
			try {
				response = await this._handle(request, handler);
				// The "official" Strategy subclasses all throw this error automatically,
				// but in case a third-party Strategy doesn't, ensure that we have a
				// consistent failure when there's no response or an error response.
				if (!response || response.type === "error") {
					throw new WorkboxError("no-response", { url: request.url });
				}
			} catch (error) {
				if (error instanceof Error) {
					for (const callback of handler.iterateCallbacks("handlerDidError")) {
						response = await callback({
							error,
							event,
							request
						});
						if (response) {
							break;
						}
					}
				}
				if (!response) {
					throw error;
				} else {
					logger.log(`While responding to '${getFriendlyURL(request.url)}', ` + `an ${error instanceof Error ? error.toString() : ""} error occurred. Using a fallback response provided by ` + `a handlerDidError plugin.`);
				}
			}
			for (const callback of handler.iterateCallbacks("handlerWillRespond")) {
				response = await callback({
					event,
					request,
					response
				});
			}
			return response;
		}
		async _awaitComplete(responseDone, handler, request, event) {
			let response;
			let error;
			try {
				response = await responseDone;
			} catch (error) {}
			try {
				await handler.runCallbacks("handlerDidRespond", {
					event,
					request,
					response
				});
				await handler.doneWaiting();
			} catch (waitUntilError) {
				if (waitUntilError instanceof Error) {
					error = waitUntilError;
				}
			}
			await handler.runCallbacks("handlerDidComplete", {
				event,
				request,
				response,
				error
			});
			handler.destroy();
			if (error) {
				throw error;
			}
		}
	}
	/**
	* Classes extending the `Strategy` based class should implement this method,
	* and leverage the {@link workbox-strategies.StrategyHandler}
	* arg to perform all fetching and cache logic, which will ensure all relevant
	* cache, cache options, fetch options and plugins are used (per the current
	* strategy instance).
	*
	* @name _handle
	* @instance
	* @abstract
	* @function
	* @param {Request} request
	* @param {workbox-strategies.StrategyHandler} handler
	* @return {Promise<Response>}
	*
	* @memberof workbox-strategies.Strategy
	*/
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A {@link workbox-strategies.Strategy} implementation
	* specifically designed to work with
	* {@link workbox-precaching.PrecacheController}
	* to both cache and fetch precached assets.
	*
	* Note: an instance of this class is created automatically when creating a
	* `PrecacheController`; it's generally not necessary to create this yourself.
	*
	* @extends workbox-strategies.Strategy
	* @memberof workbox-precaching
	*/
	class PrecacheStrategy extends Strategy {
		/**
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] {@link https://developers.google.com/web/tools/workbox/guides/using-plugins|Plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* {@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters|init}
		* of all fetch() requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* {@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions|CacheQueryOptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor(options = {}) {
			options.cacheName = cacheNames.getPrecacheName(options.cacheName);
			super(options);
			this._fallbackToNetwork = options.fallbackToNetwork === false ? false : true;
			// Redirected responses cannot be used to satisfy a navigation request, so
			// any redirected response must be "copied" rather than cloned, so the new
			// response doesn't contain the `redirected` flag. See:
			// https://bugs.chromium.org/p/chromium/issues/detail?id=669363&desc=2#c1
			this.plugins.push(PrecacheStrategy.copyRedirectedCacheableResponsesPlugin);
		}
		/**
		* @private
		* @param {Request|string} request A request to run this strategy for.
		* @param {workbox-strategies.StrategyHandler} handler The event that
		*     triggered the request.
		* @return {Promise<Response>}
		*/
		async _handle(request, handler) {
			const response = await handler.cacheMatch(request);
			if (response) {
				return response;
			}
			// If this is an `install` event for an entry that isn't already cached,
			// then populate the cache.
			if (handler.event && handler.event.type === "install") {
				return await this._handleInstall(request, handler);
			}
			// Getting here means something went wrong. An entry that should have been
			// precached wasn't found in the cache.
			return await this._handleFetch(request, handler);
		}
		async _handleFetch(request, handler) {
			let response;
			const params = handler.params || {};
			// Fall back to the network if we're configured to do so.
			if (this._fallbackToNetwork) {
				{
					logger.warn(`The precached response for ` + `${getFriendlyURL(request.url)} in ${this.cacheName} was not ` + `found. Falling back to the network.`);
				}
				const integrityInManifest = params.integrity;
				const integrityInRequest = request.integrity;
				const noIntegrityConflict = !integrityInRequest || integrityInRequest === integrityInManifest;
				// Do not add integrity if the original request is no-cors
				// See https://github.com/GoogleChrome/workbox/issues/3096
				response = await handler.fetch(new Request(request, { integrity: request.mode !== "no-cors" ? integrityInRequest || integrityInManifest : undefined }));
				// It's only "safe" to repair the cache if we're using SRI to guarantee
				// that the response matches the precache manifest's expectations,
				// and there's either a) no integrity property in the incoming request
				// or b) there is an integrity, and it matches the precache manifest.
				// See https://github.com/GoogleChrome/workbox/issues/2858
				// Also if the original request users no-cors we don't use integrity.
				// See https://github.com/GoogleChrome/workbox/issues/3096
				if (integrityInManifest && noIntegrityConflict && request.mode !== "no-cors") {
					this._useDefaultCacheabilityPluginIfNeeded();
					const wasCached = await handler.cachePut(request, response.clone());
					{
						if (wasCached) {
							logger.log(`A response for ${getFriendlyURL(request.url)} ` + `was used to "repair" the precache.`);
						}
					}
				}
			} else {
				// This shouldn't normally happen, but there are edge cases:
				// https://github.com/GoogleChrome/workbox/issues/1441
				throw new WorkboxError("missing-precache-entry", {
					cacheName: this.cacheName,
					url: request.url
				});
			}
			{
				const cacheKey = params.cacheKey || await handler.getCacheKey(request, "read");
				// Workbox is going to handle the route.
				// print the routing details to the console.
				logger.groupCollapsed(`Precaching is responding to: ` + getFriendlyURL(request.url));
				logger.log(`Serving the precached url: ${getFriendlyURL(cacheKey instanceof Request ? cacheKey.url : cacheKey)}`);
				logger.groupCollapsed(`View request details here.`);
				logger.log(request);
				logger.groupEnd();
				logger.groupCollapsed(`View response details here.`);
				logger.log(response);
				logger.groupEnd();
				logger.groupEnd();
			}
			return response;
		}
		async _handleInstall(request, handler) {
			this._useDefaultCacheabilityPluginIfNeeded();
			const response = await handler.fetch(request);
			// Make sure we defer cachePut() until after we know the response
			// should be cached; see https://github.com/GoogleChrome/workbox/issues/2737
			const wasCached = await handler.cachePut(request, response.clone());
			if (!wasCached) {
				// Throwing here will lead to the `install` handler failing, which
				// we want to do if *any* of the responses aren't safe to cache.
				throw new WorkboxError("bad-precaching-response", {
					url: request.url,
					status: response.status
				});
			}
			return response;
		}
		/**
		* This method is complex, as there a number of things to account for:
		*
		* The `plugins` array can be set at construction, and/or it might be added to
		* to at any time before the strategy is used.
		*
		* At the time the strategy is used (i.e. during an `install` event), there
		* needs to be at least one plugin that implements `cacheWillUpdate` in the
		* array, other than `copyRedirectedCacheableResponsesPlugin`.
		*
		* - If this method is called and there are no suitable `cacheWillUpdate`
		* plugins, we need to add `defaultPrecacheCacheabilityPlugin`.
		*
		* - If this method is called and there is exactly one `cacheWillUpdate`, then
		* we don't have to do anything (this might be a previously added
		* `defaultPrecacheCacheabilityPlugin`, or it might be a custom plugin).
		*
		* - If this method is called and there is more than one `cacheWillUpdate`,
		* then we need to check if one is `defaultPrecacheCacheabilityPlugin`. If so,
		* we need to remove it. (This situation is unlikely, but it could happen if
		* the strategy is used multiple times, the first without a `cacheWillUpdate`,
		* and then later on after manually adding a custom `cacheWillUpdate`.)
		*
		* See https://github.com/GoogleChrome/workbox/issues/2737 for more context.
		*
		* @private
		*/
		_useDefaultCacheabilityPluginIfNeeded() {
			let defaultPluginIndex = null;
			let cacheWillUpdatePluginCount = 0;
			for (const [index, plugin] of this.plugins.entries()) {
				// Ignore the copy redirected plugin when determining what to do.
				if (plugin === PrecacheStrategy.copyRedirectedCacheableResponsesPlugin) {
					continue;
				}
				// Save the default plugin's index, in case it needs to be removed.
				if (plugin === PrecacheStrategy.defaultPrecacheCacheabilityPlugin) {
					defaultPluginIndex = index;
				}
				if (plugin.cacheWillUpdate) {
					cacheWillUpdatePluginCount++;
				}
			}
			if (cacheWillUpdatePluginCount === 0) {
				this.plugins.push(PrecacheStrategy.defaultPrecacheCacheabilityPlugin);
			} else if (cacheWillUpdatePluginCount > 1 && defaultPluginIndex !== null) {
				// Only remove the default plugin; multiple custom plugins are allowed.
				this.plugins.splice(defaultPluginIndex, 1);
			}
			// Nothing needs to be done if cacheWillUpdatePluginCount is 1
		}
	}
	PrecacheStrategy.defaultPrecacheCacheabilityPlugin = { async cacheWillUpdate({ response }) {
		if (!response || response.status >= 400) {
			return null;
		}
		return response;
	} };
	PrecacheStrategy.copyRedirectedCacheableResponsesPlugin = { async cacheWillUpdate({ response }) {
		return response.redirected ? await copyResponse(response) : response;
	} };
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Performs efficient precaching of assets.
	*
	* @memberof workbox-precaching
	*/
	class PrecacheController {
		/**
		* Create a new PrecacheController.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] The cache to use for precaching.
		* @param {string} [options.plugins] Plugins to use when precaching as well
		* as responding to fetch events for precached assets.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor({ cacheName, plugins = [], fallbackToNetwork = true } = {}) {
			this._urlsToCacheKeys = new Map();
			this._urlsToCacheModes = new Map();
			this._cacheKeysToIntegrities = new Map();
			this._strategy = new PrecacheStrategy({
				cacheName: cacheNames.getPrecacheName(cacheName),
				plugins: [...plugins, new PrecacheCacheKeyPlugin({ precacheController: this })],
				fallbackToNetwork
			});
			// Bind the install and activate methods to the instance.
			this.install = this.install.bind(this);
			this.activate = this.activate.bind(this);
		}
		/**
		* @type {workbox-precaching.PrecacheStrategy} The strategy created by this controller and
		* used to cache assets and respond to fetch events.
		*/
		get strategy() {
			return this._strategy;
		}
		/**
		* Adds items to the precache list, removing any duplicates and
		* stores the files in the
		* {@link workbox-core.cacheNames|"precache cache"} when the service
		* worker installs.
		*
		* This method can be called multiple times.
		*
		* @param {Array<Object|string>} [entries=[]] Array of entries to precache.
		*/
		precache(entries) {
			this.addToCacheList(entries);
			if (!this._installAndActiveListenersAdded) {
				self.addEventListener("install", this.install);
				self.addEventListener("activate", this.activate);
				this._installAndActiveListenersAdded = true;
			}
		}
		/**
		* This method will add items to the precache list, removing duplicates
		* and ensuring the information is valid.
		*
		* @param {Array<workbox-precaching.PrecacheController.PrecacheEntry|string>} entries
		*     Array of entries to precache.
		*/
		addToCacheList(entries) {
			{
				finalAssertExports.isArray(entries, {
					moduleName: "workbox-precaching",
					className: "PrecacheController",
					funcName: "addToCacheList",
					paramName: "entries"
				});
			}
			const urlsToWarnAbout = [];
			for (const entry of entries) {
				// See https://github.com/GoogleChrome/workbox/issues/2259
				if (typeof entry === "string") {
					urlsToWarnAbout.push(entry);
				} else if (entry && entry.revision === undefined) {
					urlsToWarnAbout.push(entry.url);
				}
				const { cacheKey, url } = createCacheKey(entry);
				const cacheMode = typeof entry !== "string" && entry.revision ? "reload" : "default";
				if (this._urlsToCacheKeys.has(url) && this._urlsToCacheKeys.get(url) !== cacheKey) {
					throw new WorkboxError("add-to-cache-list-conflicting-entries", {
						firstEntry: this._urlsToCacheKeys.get(url),
						secondEntry: cacheKey
					});
				}
				if (typeof entry !== "string" && entry.integrity) {
					if (this._cacheKeysToIntegrities.has(cacheKey) && this._cacheKeysToIntegrities.get(cacheKey) !== entry.integrity) {
						throw new WorkboxError("add-to-cache-list-conflicting-integrities", { url });
					}
					this._cacheKeysToIntegrities.set(cacheKey, entry.integrity);
				}
				this._urlsToCacheKeys.set(url, cacheKey);
				this._urlsToCacheModes.set(url, cacheMode);
				if (urlsToWarnAbout.length > 0) {
					const warningMessage = `Workbox is precaching URLs without revision ` + `info: ${urlsToWarnAbout.join(", ")}\nThis is generally NOT safe. ` + `Learn more at https://bit.ly/wb-precache`;
					{
						logger.warn(warningMessage);
					}
				}
			}
		}
		/**
		* Precaches new and updated assets. Call this method from the service worker
		* install event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.InstallResult>}
		*/
		install(event) {
			// waitUntil returns Promise<any>
			// eslint-disable-next-line @typescript-eslint/no-unsafe-return
			return waitUntil(event, async () => {
				const installReportPlugin = new PrecacheInstallReportPlugin();
				this.strategy.plugins.push(installReportPlugin);
				// Cache entries one at a time.
				// See https://github.com/GoogleChrome/workbox/issues/2528
				for (const [url, cacheKey] of this._urlsToCacheKeys) {
					const integrity = this._cacheKeysToIntegrities.get(cacheKey);
					const cacheMode = this._urlsToCacheModes.get(url);
					const request = new Request(url, {
						integrity,
						cache: cacheMode,
						credentials: "same-origin"
					});
					await Promise.all(this.strategy.handleAll({
						params: { cacheKey },
						request,
						event
					}));
				}
				const { updatedURLs, notUpdatedURLs } = installReportPlugin;
				{
					printInstallDetails(updatedURLs, notUpdatedURLs);
				}
				return {
					updatedURLs,
					notUpdatedURLs
				};
			});
		}
		/**
		* Deletes assets that are no longer present in the current precache manifest.
		* Call this method from the service worker activate event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.CleanupResult>}
		*/
		activate(event) {
			// waitUntil returns Promise<any>
			// eslint-disable-next-line @typescript-eslint/no-unsafe-return
			return waitUntil(event, async () => {
				const cache = await self.caches.open(this.strategy.cacheName);
				const currentlyCachedRequests = await cache.keys();
				const expectedCacheKeys = new Set(this._urlsToCacheKeys.values());
				const deletedURLs = [];
				for (const request of currentlyCachedRequests) {
					if (!expectedCacheKeys.has(request.url)) {
						await cache.delete(request);
						deletedURLs.push(request.url);
					}
				}
				{
					printCleanupDetails(deletedURLs);
				}
				return { deletedURLs };
			});
		}
		/**
		* Returns a mapping of a precached URL to the corresponding cache key, taking
		* into account the revision information for the URL.
		*
		* @return {Map<string, string>} A URL to cache key mapping.
		*/
		getURLsToCacheKeys() {
			return this._urlsToCacheKeys;
		}
		/**
		* Returns a list of all the URLs that have been precached by the current
		* service worker.
		*
		* @return {Array<string>} The precached URLs.
		*/
		getCachedURLs() {
			return [...this._urlsToCacheKeys.keys()];
		}
		/**
		* Returns the cache key used for storing a given URL. If that URL is
		* unversioned, like `/index.html', then the cache key will be the original
		* URL with a search parameter appended to it.
		*
		* @param {string} url A URL whose cache key you want to look up.
		* @return {string} The versioned URL that corresponds to a cache key
		* for the original URL, or undefined if that URL isn't precached.
		*/
		getCacheKeyForURL(url) {
			const urlObject = new URL(url, location.href);
			return this._urlsToCacheKeys.get(urlObject.href);
		}
		/**
		* @param {string} url A cache key whose SRI you want to look up.
		* @return {string} The subresource integrity associated with the cache key,
		* or undefined if it's not set.
		*/
		getIntegrityForCacheKey(cacheKey) {
			return this._cacheKeysToIntegrities.get(cacheKey);
		}
		/**
		* This acts as a drop-in replacement for
		* [`cache.match()`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/match)
		* with the following differences:
		*
		* - It knows what the name of the precache is, and only checks in that cache.
		* - It allows you to pass in an "original" URL without versioning parameters,
		* and it will automatically look up the correct cache key for the currently
		* active revision of that URL.
		*
		* E.g., `matchPrecache('index.html')` will find the correct precached
		* response for the currently active service worker, even if the actual cache
		* key is `'/index.html?__WB_REVISION__=1234abcd'`.
		*
		* @param {string|Request} request The key (without revisioning parameters)
		* to look up in the precache.
		* @return {Promise<Response|undefined>}
		*/
		async matchPrecache(request) {
			const url = request instanceof Request ? request.url : request;
			const cacheKey = this.getCacheKeyForURL(url);
			if (cacheKey) {
				const cache = await self.caches.open(this.strategy.cacheName);
				return cache.match(cacheKey);
			}
			return undefined;
		}
		/**
		* Returns a function that looks up `url` in the precache (taking into
		* account revision information), and returns the corresponding `Response`.
		*
		* @param {string} url The precached URL which will be used to lookup the
		* `Response`.
		* @return {workbox-routing~handlerCallback}
		*/
		createHandlerBoundToURL(url) {
			const cacheKey = this.getCacheKeyForURL(url);
			if (!cacheKey) {
				throw new WorkboxError("non-precached-url", { url });
			}
			return (options) => {
				options.request = new Request(url);
				options.params = Object.assign({ cacheKey }, options.params);
				return this.strategy.handle(options);
			};
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	let precacheController;
	/**
	* @return {PrecacheController}
	* @private
	*/
	const getOrCreatePrecacheController = () => {
		if (!precacheController) {
			precacheController = new PrecacheController();
		}
		return precacheController;
	};
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Removes any URL search parameters that should be ignored.
	*
	* @param {URL} urlObject The original URL.
	* @param {Array<RegExp>} ignoreURLParametersMatching RegExps to test against
	* each search parameter name. Matches mean that the search parameter should be
	* ignored.
	* @return {URL} The URL with any ignored search parameters removed.
	*
	* @private
	* @memberof workbox-precaching
	*/
	function removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching = []) {
		// Convert the iterable into an array at the start of the loop to make sure
		// deletion doesn't mess up iteration.
		for (const paramName of [...urlObject.searchParams.keys()]) {
			if (ignoreURLParametersMatching.some((regExp) => regExp.test(paramName))) {
				urlObject.searchParams.delete(paramName);
			}
		}
		return urlObject;
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Generator function that yields possible variations on the original URL to
	* check, one at a time.
	*
	* @param {string} url
	* @param {Object} options
	*
	* @private
	* @memberof workbox-precaching
	*/
	function* generateURLVariations(url, { ignoreURLParametersMatching = [/^utm_/, /^fbclid$/], directoryIndex = "index.html", cleanURLs = true, urlManipulation } = {}) {
		const urlObject = new URL(url, location.href);
		urlObject.hash = "";
		yield urlObject.href;
		const urlWithoutIgnoredParams = removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching);
		yield urlWithoutIgnoredParams.href;
		if (directoryIndex && urlWithoutIgnoredParams.pathname.endsWith("/")) {
			const directoryURL = new URL(urlWithoutIgnoredParams.href);
			directoryURL.pathname += directoryIndex;
			yield directoryURL.href;
		}
		if (cleanURLs) {
			const cleanURL = new URL(urlWithoutIgnoredParams.href);
			cleanURL.pathname += ".html";
			yield cleanURL.href;
		}
		if (urlManipulation) {
			const additionalURLs = urlManipulation({ url: urlObject });
			for (const urlToAttempt of additionalURLs) {
				yield urlToAttempt.href;
			}
		}
	}
	/*
	Copyright 2020 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* A subclass of {@link workbox-routing.Route} that takes a
	* {@link workbox-precaching.PrecacheController}
	* instance and uses it to match incoming requests and handle fetching
	* responses from the precache.
	*
	* @memberof workbox-precaching
	* @extends workbox-routing.Route
	*/
	class PrecacheRoute extends Route {
		/**
		* @param {PrecacheController} precacheController A `PrecacheController`
		* instance used to both match requests and respond to fetch events.
		* @param {Object} [options] Options to control how requests are matched
		* against the list of precached URLs.
		* @param {string} [options.directoryIndex=index.html] The `directoryIndex` will
		* check cache entries for a URLs ending with '/' to see if there is a hit when
		* appending the `directoryIndex` value.
		* @param {Array<RegExp>} [options.ignoreURLParametersMatching=[/^utm_/, /^fbclid$/]] An
		* array of regex's to remove search params when looking for a cache match.
		* @param {boolean} [options.cleanURLs=true] The `cleanURLs` option will
		* check the cache for the URL with a `.html` added to the end of the end.
		* @param {workbox-precaching~urlManipulation} [options.urlManipulation]
		* This is a function that should take a URL and return an array of
		* alternative URLs that should be checked for precache matches.
		*/
		constructor(precacheController, options) {
			const match = ({ request }) => {
				const urlsToCacheKeys = precacheController.getURLsToCacheKeys();
				for (const possibleURL of generateURLVariations(request.url, options)) {
					const cacheKey = urlsToCacheKeys.get(possibleURL);
					if (cacheKey) {
						const integrity = precacheController.getIntegrityForCacheKey(cacheKey);
						return {
							cacheKey,
							integrity
						};
					}
				}
				{
					logger.debug(`Precaching did not find a match for ` + getFriendlyURL(request.url));
				}
				return;
			};
			super(match, precacheController.strategy);
		}
	}
	/*
	Copyright 2019 Google LLC
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Add a `fetch` listener to the service worker that will
	* respond to
	* [network requests]{@link https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers#Custom_responses_to_requests}
	* with precached assets.
	*
	* Requests for assets that aren't precached, the `FetchEvent` will not be
	* responded to, allowing the event to fall through to other `fetch` event
	* listeners.
	*
	* @param {Object} [options] See the {@link workbox-precaching.PrecacheRoute}
	* options.
	*
	* @memberof workbox-precaching
	*/
	function addRoute(options) {
		const precacheController = getOrCreatePrecacheController();
		const precacheRoute = new PrecacheRoute(precacheController, options);
		registerRoute(precacheRoute);
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Adds items to the precache list, removing any duplicates and
	* stores the files in the
	* {@link workbox-core.cacheNames|"precache cache"} when the service
	* worker installs.
	*
	* This method can be called multiple times.
	*
	* Please note: This method **will not** serve any of the cached files for you.
	* It only precaches files. To respond to a network request you call
	* {@link workbox-precaching.addRoute}.
	*
	* If you have a single array of files to precache, you can just call
	* {@link workbox-precaching.precacheAndRoute}.
	*
	* @param {Array<Object|string>} [entries=[]] Array of entries to precache.
	*
	* @memberof workbox-precaching
	*/
	function precache(entries) {
		const precacheController = getOrCreatePrecacheController();
		precacheController.precache(entries);
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* This method will add entries to the precache list and add a route to
	* respond to fetch events.
	*
	* This is a convenience method that will call
	* {@link workbox-precaching.precache} and
	* {@link workbox-precaching.addRoute} in a single call.
	*
	* @param {Array<Object|string>} entries Array of entries to precache.
	* @param {Object} [options] See the
	* {@link workbox-precaching.PrecacheRoute} options.
	*
	* @memberof workbox-precaching
	*/
	function precacheAndRoute(entries, options) {
		precache(entries);
		addRoute(options);
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	const SUBSTRING_TO_FIND = "-precache-";
	/**
	* Cleans up incompatible precaches that were created by older versions of
	* Workbox, by a service worker registered under the current scope.
	*
	* This is meant to be called as part of the `activate` event.
	*
	* This should be safe to use as long as you don't include `substringToFind`
	* (defaulting to `-precache-`) in your non-precache cache names.
	*
	* @param {string} currentPrecacheName The cache name currently in use for
	* precaching. This cache won't be deleted.
	* @param {string} [substringToFind='-precache-'] Cache names which include this
	* substring will be deleted (excluding `currentPrecacheName`).
	* @return {Array<string>} A list of all the cache names that were deleted.
	*
	* @private
	* @memberof workbox-precaching
	*/
	const deleteOutdatedCaches = async (currentPrecacheName, substringToFind = SUBSTRING_TO_FIND) => {
		const cacheNames = await self.caches.keys();
		const cacheNamesToDelete = cacheNames.filter((cacheName) => {
			return cacheName.includes(substringToFind) && cacheName.includes(self.registration.scope) && cacheName !== currentPrecacheName;
		});
		await Promise.all(cacheNamesToDelete.map((cacheName) => self.caches.delete(cacheName)));
		return cacheNamesToDelete;
	};
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Adds an `activate` event listener which will clean up incompatible
	* precaches that were created by older versions of Workbox.
	*
	* @memberof workbox-precaching
	*/
	function cleanupOutdatedCaches() {
		// See https://github.com/Microsoft/TypeScript/issues/28357#issuecomment-436484705
		self.addEventListener("activate", (event) => {
			const cacheName = cacheNames.getPrecacheName();
			event.waitUntil(deleteOutdatedCaches(cacheName).then((cachesDeleted) => {
				{
					if (cachesDeleted.length > 0) {
						logger.log(`The following out-of-date precaches were cleaned up ` + `automatically:`, cachesDeleted);
					}
				}
			}));
		});
	}
	/*
	Copyright 2018 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* NavigationRoute makes it easy to create a
	* {@link workbox-routing.Route} that matches for browser
	* [navigation requests]{@link https://developers.google.com/web/fundamentals/primers/service-workers/high-performance-loading#first_what_are_navigation_requests}.
	*
	* It will only match incoming Requests whose
	* {@link https://fetch.spec.whatwg.org/#concept-request-mode|mode}
	* is set to `navigate`.
	*
	* You can optionally only apply this route to a subset of navigation requests
	* by using one or both of the `denylist` and `allowlist` parameters.
	*
	* @memberof workbox-routing
	* @extends workbox-routing.Route
	*/
	class NavigationRoute extends Route {
		/**
		* If both `denylist` and `allowlist` are provided, the `denylist` will
		* take precedence and the request will not match this route.
		*
		* The regular expressions in `allowlist` and `denylist`
		* are matched against the concatenated
		* [`pathname`]{@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/pathname}
		* and [`search`]{@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/search}
		* portions of the requested URL.
		*
		* *Note*: These RegExps may be evaluated against every destination URL during
		* a navigation. Avoid using
		* [complex RegExps](https://github.com/GoogleChrome/workbox/issues/3077),
		* or else your users may see delays when navigating your site.
		*
		* @param {workbox-routing~handlerCallback} handler A callback
		* function that returns a Promise resulting in a Response.
		* @param {Object} options
		* @param {Array<RegExp>} [options.denylist] If any of these patterns match,
		* the route will not handle the request (even if a allowlist RegExp matches).
		* @param {Array<RegExp>} [options.allowlist=[/./]] If any of these patterns
		* match the URL's pathname and search parameter, the route will handle the
		* request (assuming the denylist doesn't match).
		*/
		constructor(handler, { allowlist = [/./], denylist = [] } = {}) {
			{
				finalAssertExports.isArrayOfClass(allowlist, RegExp, {
					moduleName: "workbox-routing",
					className: "NavigationRoute",
					funcName: "constructor",
					paramName: "options.allowlist"
				});
				finalAssertExports.isArrayOfClass(denylist, RegExp, {
					moduleName: "workbox-routing",
					className: "NavigationRoute",
					funcName: "constructor",
					paramName: "options.denylist"
				});
			}
			super((options) => this._match(options), handler);
			this._allowlist = allowlist;
			this._denylist = denylist;
		}
		/**
		* Routes match handler.
		*
		* @param {Object} options
		* @param {URL} options.url
		* @param {Request} options.request
		* @return {boolean}
		*
		* @private
		*/
		_match({ url, request }) {
			if (request && request.mode !== "navigate") {
				return false;
			}
			const pathnameAndSearch = url.pathname + url.search;
			for (const regExp of this._denylist) {
				if (regExp.test(pathnameAndSearch)) {
					{
						logger.log(`The navigation route ${pathnameAndSearch} is not ` + `being used, since the URL matches this denylist pattern: ` + `${regExp.toString()}`);
					}
					return false;
				}
			}
			if (this._allowlist.some((regExp) => regExp.test(pathnameAndSearch))) {
				{
					logger.debug(`The navigation route ${pathnameAndSearch} ` + `is being used.`);
				}
				return true;
			}
			{
				logger.log(`The navigation route ${pathnameAndSearch} is not ` + `being used, since the URL being navigated to doesn't ` + `match the allowlist.`);
			}
			return false;
		}
	}
	/*
	Copyright 2019 Google LLC
	
	Use of this source code is governed by an MIT-style
	license that can be found in the LICENSE file or at
	https://opensource.org/licenses/MIT.
	*/
	/**
	* Helper function that calls
	* {@link PrecacheController#createHandlerBoundToURL} on the default
	* {@link PrecacheController} instance.
	*
	* If you are creating your own {@link PrecacheController}, then call the
	* {@link PrecacheController#createHandlerBoundToURL} on that instance,
	* instead of using this function.
	*
	* @param {string} url The precached URL which will be used to lookup the
	* `Response`.
	* @param {boolean} [fallbackToNetwork=true] Whether to attempt to get the
	* response from the network if there's a precache miss.
	* @return {workbox-routing~handlerCallback}
	*
	* @memberof workbox-precaching
	*/
	function createHandlerBoundToURL(url) {
		const precacheController = getOrCreatePrecacheController();
		return precacheController.createHandlerBoundToURL(url);
	}
	exports.NavigationRoute = NavigationRoute;
	exports.cleanupOutdatedCaches = cleanupOutdatedCaches;
	exports.clientsClaim = clientsClaim;
	exports.createHandlerBoundToURL = createHandlerBoundToURL;
	exports.precacheAndRoute = precacheAndRoute;
	exports.registerRoute = registerRoute;
}));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxDQUFDLFNBQVMsSUFBSSxTQUFVLFNBQVM7Q0FBRTs7Q0FHdEMsSUFBSTtFQUNGLEtBQUsseUJBQXlCLEVBQUU7Q0FDbEMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7O0NBZWIsU0FBUyxlQUFlO0VBQ3RCLEtBQUssaUJBQWlCLGtCQUFrQixLQUFLLFFBQVEsTUFBTSxDQUFDO0NBQzlEOzs7Ozs7O0NBUUEsTUFBTSxnQkFBZ0I7OztFQUdwQixJQUFJLEVBQUUsMkJBQTJCLGFBQWE7R0FDNUMsS0FBSyx3QkFBd0I7RUFDL0I7RUFDQSxJQUFJLFVBQVU7RUFDZCxNQUFNLG1CQUFtQjtHQUN2QixPQUFPO0dBQ1AsS0FBSztHQUNMLE1BQU07R0FDTixPQUFPO0dBQ1AsZ0JBQWdCO0dBQ2hCLFVBQVU7RUFDWjtFQUNBLE1BQU0sUUFBUSxTQUFVLFFBQVEsTUFBTTtHQUNwQyxJQUFJLEtBQUssdUJBQXVCO0lBQzlCO0dBQ0Y7R0FDQSxJQUFJLFdBQVcsa0JBQWtCOzs7SUFHL0IsSUFBSSxpQ0FBaUMsS0FBSyxVQUFVLFNBQVMsR0FBRztLQUM5RCxRQUFRLE9BQU8sQ0FBQyxHQUFHLElBQUk7S0FDdkI7SUFDRjtHQUNGO0dBQ0EsTUFBTSxTQUFTO0lBQUMsZUFBZSxpQkFBaUI7SUFBVztJQUF3QjtJQUFnQjtJQUFxQjtHQUFvQjs7R0FFNUksTUFBTSxZQUFZLFVBQVUsQ0FBQyxJQUFJLENBQUMsYUFBYSxPQUFPLEtBQUssR0FBRyxDQUFDO0dBQy9ELFFBQVEsT0FBTyxDQUFDLEdBQUcsV0FBVyxHQUFHLElBQUk7R0FDckMsSUFBSSxXQUFXLGtCQUFrQjtJQUMvQixVQUFVO0dBQ1o7R0FDQSxJQUFJLFdBQVcsWUFBWTtJQUN6QixVQUFVO0dBQ1o7RUFDRjs7RUFFQSxNQUFNLE1BQU0sQ0FBQztFQUNiLE1BQU0sZ0JBQWdCLE9BQU8sS0FBSyxnQkFBZ0I7RUFDbEQsS0FBSyxNQUFNLE9BQU8sZUFBZTtHQUMvQixNQUFNLFNBQVM7R0FDZixJQUFJLFdBQVcsR0FBRyxTQUFTO0lBQ3pCLE1BQU0sUUFBUSxJQUFJO0dBQ3BCO0VBQ0Y7RUFDQSxPQUFPO0NBQ1QsRUFBQyxDQUFFOzs7Ozs7OztDQVNILE1BQU0sV0FBVztFQUNmLGtCQUFrQixFQUNoQixXQUNBLHVCQUNBLFlBQ0k7R0FDSixJQUFJLENBQUMsYUFBYSxDQUFDLHVCQUF1QjtJQUN4QyxNQUFNLElBQUksTUFBTSw0Q0FBNEM7R0FDOUQ7R0FDQSxPQUFPLFFBQVEsVUFBVSwwQ0FBMEMscUJBQXFCLHNCQUFzQix5QkFBeUIsR0FBRyxLQUFLLFVBQVUsS0FBSyxFQUFFO0VBQ2xLO0VBQ0EsaUJBQWlCLEVBQ2YsWUFDQSxXQUNBLFVBQ0EsZ0JBQ0k7R0FDSixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVztJQUN4RCxNQUFNLElBQUksTUFBTSwyQ0FBMkM7R0FDN0Q7R0FDQSxPQUFPLGtCQUFrQixVQUFVLGtCQUFrQixJQUFJLFdBQVcsR0FBRyxVQUFVLEdBQUcsU0FBUztFQUMvRjtFQUNBLG1CQUFtQixFQUNqQixjQUNBLFdBQ0EsWUFDQSxXQUNBLGVBQ0k7R0FDSixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxVQUFVO0lBQzNELE1BQU0sSUFBSSxNQUFNLDZDQUE2QztHQUMvRDtHQUNBLE1BQU0sZUFBZSxZQUFZLEdBQUcsVUFBVSxLQUFLO0dBQ25ELE9BQU8sa0JBQWtCLFVBQVUsa0JBQWtCLElBQUksV0FBVyxHQUFHLGlCQUFpQixHQUFHLFNBQVMsc0JBQXNCLGFBQWE7RUFDekk7RUFDQSxvQkFBb0IsRUFDbEIsbUJBQ0EsV0FDQSxZQUNBLFdBQ0EsVUFDQSwyQkFDSTtHQUNKLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxjQUFjLENBQUMsVUFBVTtJQUNsRCxNQUFNLElBQUksTUFBTSw4Q0FBOEM7R0FDaEU7R0FDQSxNQUFNLGVBQWUsWUFBWSxHQUFHLFVBQVUsS0FBSztHQUNuRCxJQUFJLHNCQUFzQjtJQUN4QixPQUFPLDJCQUEyQixJQUFJLFdBQVcsR0FBRyxlQUFlLFNBQVMsUUFBUSxnQ0FBZ0Msa0JBQWtCO0dBQ3hJO0dBQ0EsT0FBTyxrQkFBa0IsVUFBVSxrQkFBa0IsSUFBSSxXQUFXLEdBQUcsZUFBZSxTQUFTLFFBQVEsZ0NBQWdDLGtCQUFrQjtFQUMzSjtFQUNBLHFCQUFxQixFQUNuQixnQkFDQSxXQUNBLFlBQ0EsV0FDQSxlQUNJO0dBQ0osSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLFVBQVU7SUFDM0UsTUFBTSxJQUFJLE1BQU0sK0NBQStDO0dBQ2pFO0dBQ0EsT0FBTyxHQUFHLFdBQVcsR0FBRyxVQUFVLEdBQUcsU0FBUyxvQkFBb0IsSUFBSSxVQUFVLDJCQUEyQixlQUFlO0VBQzVIO0VBQ0Esc0NBQXNDLEVBQ3BDLFlBQ0k7R0FDSixPQUFPLHVDQUF1Qyx3RUFBd0UsSUFBSSxLQUFLLFVBQVUsS0FBSyxFQUFFLG1EQUFtRCx5RUFBeUU7RUFDOVE7RUFDQSwwQ0FBMEMsRUFDeEMsWUFDQSxrQkFDSTtHQUNKLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYTtJQUMvQixNQUFNLElBQUksTUFBTSx5QkFBeUIsOENBQThDO0dBQ3pGO0dBQ0EsT0FBTyxrQ0FBa0MsMEVBQTBFLEdBQUcsV0FBVyxnREFBZ0Qsd0VBQXdFO0VBQzNQO0VBQ0Esb0NBQW9DLEVBQ2xDLHlCQUNJO0dBQ0osSUFBSSxDQUFDLG9CQUFvQjtJQUN2QixNQUFNLElBQUksTUFBTSx5QkFBeUIsMkNBQTJDO0dBQ3RGO0dBQ0EsT0FBTyxtRUFBbUUsa0NBQWtDLG1CQUFtQjtFQUNqSTtFQUNBLHVCQUF1QixFQUNyQixhQUNBLFlBQ0k7R0FDSixJQUFJLENBQUMsYUFBYTtJQUNoQixNQUFNLElBQUksTUFBTSx5REFBeUQ7R0FDM0U7R0FDQSxPQUFPLG1FQUFtRSxvQkFBb0IsWUFBWSxtQ0FBbUMsSUFBSSxLQUFLLFVBQVUsS0FBSyxFQUFFO0VBQ3pLO0VBQ0EsK0NBQStDLEVBQzdDLGFBQ0k7R0FDSixJQUFJLENBQUMsUUFBUTtJQUNYLE1BQU0sSUFBSSxNQUFNLHlCQUF5QixxREFBcUQ7R0FDaEc7R0FDQSxPQUFPLCtEQUErRCxtQ0FBbUMsT0FBTztFQUNsSDtFQUNBLCtDQUErQztHQUM3QyxPQUFPLDhEQUE4RDtFQUN2RTtFQUNBLHdCQUF3QixFQUN0QixXQUNJO0dBQ0osT0FBTyx3Q0FBd0MsS0FBSztFQUN0RDtFQUNBLHlCQUF5QixFQUN2QixXQUNJO0dBQ0osT0FBTyxtQkFBbUIsS0FBSyw2QkFBNkI7RUFDOUQ7RUFDQSxpQ0FBaUMsRUFDL0IsWUFDQSxnQkFDSTtHQUNKLE9BQU8sUUFBUSxXQUFXLHlDQUF5QyxJQUFJLFVBQVU7RUFDbkY7RUFDQSwyQkFBMkIsRUFDekIsWUFDQSxXQUNBLFVBQ0EsZ0JBQ0k7R0FDSixPQUFPLGlCQUFpQixVQUFVLHlDQUF5Qyw2QkFBNkIsV0FBVyxHQUFHLFVBQVUsR0FBRyxTQUFTLFNBQVM7RUFDdko7RUFDQSx1QkFBdUIsRUFDckIsT0FDQSxlQUNBLFlBQ0EsV0FDQSxVQUNBLGdCQUNJO0dBQ0osT0FBTyxpQkFBaUIsVUFBVSxvQ0FBb0MsSUFBSSxjQUFjLHVCQUF1QixLQUFLLFVBQVUsS0FBSyxFQUFFLFFBQVEsNEJBQTRCLFdBQVcsR0FBRyxVQUFVLEdBQUcsU0FBUyxPQUFPO0VBQ3ROO0VBQ0EsZ0NBQWdDLEVBQzlCLFlBQ0EsV0FDQSxlQUNJO0dBQ0osT0FBTyxxRUFBcUUsTUFBTSxXQUFXLEdBQUcsVUFBVSxHQUFHO0VBQy9HO0VBQ0EsaUNBQWlDLEVBQy9CLFlBQ0EsV0FDQSxlQUNJO0dBQ0osT0FBTyw2REFBNkQsTUFBTSxXQUFXLEdBQUcsVUFBVSxHQUFHO0VBQ3ZHO0VBQ0EsbUJBQW1CLEVBQ2pCLFlBQ0EsVUFDQSxnQkFDSTtHQUNKLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLFVBQVU7SUFDMUMsTUFBTSxJQUFJLE1BQU0sNkNBQTZDO0dBQy9EO0dBQ0EsT0FBTyw0QkFBNEIsVUFBVSxnQ0FBZ0MseUVBQXlFLDJCQUEyQixXQUFXLEdBQUcsU0FBUyxXQUFXO0VBQ3JOO0VBQ0EsK0JBQStCO0dBQzdCLE9BQU8sbURBQW1EO0VBQzVEO0VBQ0EseUNBQXlDO0dBQ3ZDLE9BQU8sK0RBQStEO0VBQ3hFO0VBQ0EsbUNBQW1DO0dBQ2pDLE9BQU8sNERBQTREO0VBQ3JFO0VBQ0EsdUJBQXVCLEVBQ3JCLDRCQUNJO0dBQ0osSUFBSSxDQUFDLHVCQUF1QjtJQUMxQixNQUFNLElBQUksTUFBTSxpREFBaUQ7R0FDbkU7R0FDQSxPQUFPLG9FQUFvRSxrQ0FBa0Msc0JBQXNCO0VBQ3JJO0VBQ0Esc0JBQXNCLEVBQ3BCLDRCQUNJO0dBQ0osSUFBSSxDQUFDLHVCQUF1QjtJQUMxQixNQUFNLElBQUksTUFBTSxnREFBZ0Q7R0FDbEU7R0FDQSxPQUFPLG1FQUFtRSxrRUFBa0UsSUFBSSxzQkFBc0I7RUFDeEs7RUFDQSx5QkFBeUIsRUFDdkIsNEJBQ0k7R0FDSixJQUFJLENBQUMsdUJBQXVCO0lBQzFCLE1BQU0sSUFBSSxNQUFNLG1EQUFtRDtHQUNyRTtHQUNBLE9BQU8scUVBQXFFLGtFQUFrRSxJQUFJLHNCQUFzQjtFQUMxSztFQUNBLHlCQUF5QjtHQUN2QixPQUFPO0VBQ1Q7RUFDQSwwQkFBMEIsRUFDeEIsTUFDQSxPQUNBLFVBQ0k7R0FDSixPQUFPLGNBQWMsTUFBTSxhQUFhLElBQUksOEJBQThCLG9EQUFvRCxLQUFLO0VBQ3JJO0VBQ0EscUNBQXFDLEVBQ25DLEtBQ0EsYUFDSTtHQUNKLE9BQU8sb0JBQW9CLElBQUkscUJBQXFCLE9BQU8sa0JBQWtCO0VBQy9FO0VBQ0EsK0JBQStCLEVBQzdCLFVBQ0k7R0FDSixPQUFPLGtDQUFrQyxJQUFJLCtCQUErQjtFQUM5RTtFQUNBLGdCQUFnQixFQUNkLEtBQ0EsWUFDSTtHQUNKLElBQUksVUFBVSxtREFBbUQsSUFBSTtHQUNyRSxJQUFJLE9BQU87SUFDVCxXQUFXLDRCQUE0QixNQUFNO0dBQy9DO0dBQ0EsT0FBTztFQUNUO0VBQ0EsNEJBQTRCLEVBQzFCLEtBQ0EsYUFDSTtHQUNKLE9BQU8sK0JBQStCLElBQUksYUFBYSxTQUFTLDJCQUEyQixPQUFPLEtBQUs7RUFDekc7RUFDQSxzQkFBc0IsRUFDcEIsVUFDSTtHQUNKLE9BQU8sNEJBQTRCLElBQUksbUNBQW1DO0VBQzVFO0VBQ0EsOENBQThDLEVBQzVDLFVBQ0k7R0FDSixPQUFPLGtDQUFrQywwRUFBMEUsR0FBRyxJQUFJO0VBQzVIO0VBQ0EsMkJBQTJCLEVBQ3pCLFdBQ0EsVUFDSTtHQUNKLE9BQU8sMENBQTBDLFVBQVUsT0FBTyxJQUFJO0VBQ3hFO0VBQ0EsK0JBQStCLEVBQzdCLGFBQ0k7R0FDSixPQUFPLG1FQUFtRSxtREFBbUQsT0FBTztFQUN0STtFQUNBLDBCQUEwQixFQUN4QixXQUNJO0dBQ0osTUFBTSxVQUFVLHVEQUF1RCxJQUFJLEtBQUs7R0FDaEYsSUFBSSxTQUFTLGtCQUFrQjtJQUM3QixPQUFPLEdBQUcsUUFBUSx5REFBeUQ7R0FDN0U7R0FDQSxPQUFPLEdBQUcsUUFBUTtFQUNwQjtDQUNGOzs7Ozs7OztDQVNBLE1BQU0scUJBQXFCLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDaEQsTUFBTSxVQUFVLFNBQVM7RUFDekIsSUFBSSxDQUFDLFNBQVM7R0FDWixNQUFNLElBQUksTUFBTSxvQ0FBb0MsS0FBSyxHQUFHO0VBQzlEO0VBQ0EsT0FBTyxRQUFRLE9BQU87Q0FDeEI7Q0FDQSxNQUFNLG1CQUFtQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQnpCLE1BQU0scUJBQXFCLE1BQU07Ozs7Ozs7OztFQVMvQixZQUFZLFdBQVcsU0FBUztHQUM5QixNQUFNLFVBQVUsaUJBQWlCLFdBQVcsT0FBTztHQUNuRCxNQUFNLE9BQU87R0FDYixLQUFLLE9BQU87R0FDWixLQUFLLFVBQVU7RUFDakI7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxNQUFNLFdBQVcsT0FBTyxZQUFZO0VBQ2xDLElBQUksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUFHO0dBQ3pCLE1BQU0sSUFBSSxhQUFhLGdCQUFnQixPQUFPO0VBQ2hEO0NBQ0Y7Q0FDQSxNQUFNLGFBQWEsUUFBUSxnQkFBZ0IsWUFBWTtFQUNyRCxNQUFNLE9BQU8sT0FBTyxPQUFPO0VBQzNCLElBQUksU0FBUyxZQUFZO0dBQ3ZCLFFBQVEsb0JBQW9CO0dBQzVCLE1BQU0sSUFBSSxhQUFhLG9CQUFvQixPQUFPO0VBQ3BEO0NBQ0Y7Q0FDQSxNQUFNLFVBQVUsUUFBUSxjQUFjLFlBQVk7RUFDaEQsSUFBSSxPQUFPLFdBQVcsY0FBYztHQUNsQyxRQUFRLGtCQUFrQjtHQUMxQixNQUFNLElBQUksYUFBYSxrQkFBa0IsT0FBTztFQUNsRDtDQUNGO0NBQ0EsTUFBTSxjQUFjLFFBR3BCLGVBQWUsWUFBWTtFQUN6QixJQUFJLEVBQUUsa0JBQWtCLGdCQUFnQjtHQUN0QyxRQUFRLHVCQUF1QixjQUFjO0dBQzdDLE1BQU0sSUFBSSxhQUFhLG1CQUFtQixPQUFPO0VBQ25EO0NBQ0Y7Q0FDQSxNQUFNLFdBQVcsT0FBTyxhQUFhLFlBQVk7RUFDL0MsSUFBSSxDQUFDLFlBQVksU0FBUyxLQUFLLEdBQUc7R0FDaEMsUUFBUSwyQkFBMkIsb0JBQW9CLEtBQUssVUFBVSxXQUFXLEVBQUU7R0FDbkYsTUFBTSxJQUFJLGFBQWEsaUJBQWlCLE9BQU87RUFDakQ7Q0FDRjtDQUNBLE1BQU0sa0JBQWtCLE9BRXhCLGVBRUEsWUFBWTtFQUNWLE1BQU0sUUFBUSxJQUFJLGFBQWEsc0JBQXNCLE9BQU87RUFDNUQsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUc7R0FDekIsTUFBTTtFQUNSO0VBQ0EsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN4QixJQUFJLEVBQUUsZ0JBQWdCLGdCQUFnQjtJQUNwQyxNQUFNO0dBQ1I7RUFDRjtDQUNGO0NBQ0EsTUFBTSxxQkFBcUI7RUFDekI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7O0NBR0EsSUFBSTtFQUNGLEtBQUssNEJBQTRCLEVBQUU7Q0FDckMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQmIsTUFBTSxnQkFBZ0I7Ozs7Ozs7O0NBUXRCLE1BQU0sZUFBZTtFQUFDO0VBQVU7RUFBTztFQUFRO0VBQVM7RUFBUTtDQUFLOzs7Ozs7Ozs7Ozs7Ozs7Q0FnQnJFLE1BQU0sb0JBQW1CLFlBQVc7RUFDbEMsSUFBSSxXQUFXLE9BQU8sWUFBWSxVQUFVO0dBQzFDO0lBQ0UsbUJBQW1CLFVBQVUsU0FBUyxVQUFVO0tBQzlDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxPQUFPO0VBQ1QsT0FBTztHQUNMO0lBQ0UsbUJBQW1CLE9BQU8sU0FBUyxZQUFZO0tBQzdDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxPQUFPLEVBQ0wsUUFBUSxRQUNWO0VBQ0Y7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsTUFBTSxNQUFNOzs7Ozs7Ozs7Ozs7RUFZVixZQUFZLE9BQU8sU0FBUyxTQUFTLGVBQWU7R0FDbEQ7SUFDRSxtQkFBbUIsT0FBTyxPQUFPLFlBQVk7S0FDM0MsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxJQUFJLFFBQVE7S0FDVixtQkFBbUIsUUFBUSxRQUFRLGNBQWMsRUFDL0MsV0FBVyxTQUNiLENBQUM7SUFDSDtHQUNGOzs7R0FHQSxLQUFLLFVBQVUsaUJBQWlCLE9BQU87R0FDdkMsS0FBSyxRQUFRO0dBQ2IsS0FBSyxTQUFTO0VBQ2hCOzs7Ozs7RUFNQSxnQkFBZ0IsU0FBUztHQUN2QixLQUFLLGVBQWUsaUJBQWlCLE9BQU87RUFDOUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSxNQUFNLG9CQUFvQixNQUFNOzs7Ozs7Ozs7Ozs7OztFQWM5QixZQUFZLFFBQVEsU0FBUyxRQUFRO0dBQ25DO0lBQ0UsbUJBQW1CLFdBQVcsUUFBUSxRQUFRO0tBQzVDLFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxNQUFNLFNBQVMsRUFDYixVQUNJO0lBQ0osTUFBTSxTQUFTLE9BQU8sS0FBSyxJQUFJLElBQUk7O0lBRW5DLElBQUksQ0FBQyxRQUFRO0tBQ1g7SUFDRjs7Ozs7SUFLQSxJQUFJLElBQUksV0FBVyxTQUFTLFVBQVUsT0FBTyxVQUFVLEdBQUc7S0FDeEQ7TUFDRSxPQUFPLE1BQU0sMkJBQTJCLE9BQU8sU0FBUyxFQUFFLDZCQUE2QixpQ0FBaUMsSUFBSSxTQUFTLEVBQUUsK0JBQStCLDREQUE0RDtLQUNwTztLQUNBO0lBQ0Y7Ozs7O0lBS0EsT0FBTyxPQUFPLE1BQU0sQ0FBQztHQUN2QjtHQUNBLE1BQU0sT0FBTyxTQUFTLE1BQU07RUFDOUI7Q0FDRjs7Ozs7Ozs7Q0FTQSxNQUFNLGtCQUFpQixRQUFPO0VBQzVCLE1BQU0sU0FBUyxJQUFJLElBQUksT0FBTyxHQUFHLEdBQUcsU0FBUyxJQUFJOzs7RUFHakQsT0FBTyxPQUFPLEtBQUssUUFBUSxJQUFJLE9BQU8sSUFBSSxTQUFTLFFBQVEsR0FBRyxFQUFFO0NBQ2xFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLE1BQU0sT0FBTzs7OztFQUlYLGNBQWM7R0FDWixLQUFLLFVBQVUsSUFBSSxJQUFJO0dBQ3ZCLEtBQUsscUJBQXFCLElBQUksSUFBSTtFQUNwQzs7Ozs7O0VBTUEsSUFBSSxTQUFTO0dBQ1gsT0FBTyxLQUFLO0VBQ2Q7Ozs7O0VBS0EsbUJBQW1COztHQUVqQixLQUFLLGlCQUFpQixVQUFTLFVBQVM7SUFDdEMsTUFBTSxFQUNKLFlBQ0U7SUFDSixNQUFNLGtCQUFrQixLQUFLLGNBQWM7S0FDekM7S0FDQTtJQUNGLENBQUM7SUFDRCxJQUFJLGlCQUFpQjtLQUNuQixNQUFNLFlBQVksZUFBZTtJQUNuQztHQUNGLENBQUM7RUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF1QkEsbUJBQW1COztHQUVqQixLQUFLLGlCQUFpQixZQUFXLFVBQVM7OztJQUd4QyxJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssU0FBUyxjQUFjOztLQUVsRCxNQUFNLEVBQ0osWUFDRSxNQUFNO0tBQ1Y7TUFDRSxPQUFPLE1BQU0sZ0NBQWdDLFFBQVEsV0FBVztLQUNsRTtLQUNBLE1BQU0sa0JBQWtCLFFBQVEsSUFBSSxRQUFRLFlBQVksS0FBSSxVQUFTO01BQ25FLElBQUksT0FBTyxVQUFVLFVBQVU7T0FDN0IsUUFBUSxDQUFDLEtBQUs7TUFDaEI7TUFDQSxNQUFNLFVBQVUsSUFBSSxRQUFRLEdBQUcsS0FBSztNQUNwQyxPQUFPLEtBQUssY0FBYztPQUN4QjtPQUNBO01BQ0YsQ0FBQzs7OztLQUlILENBQUMsQ0FBQztLQUNGLE1BQU0sVUFBVSxlQUFlOztLQUUvQixJQUFJLE1BQU0sU0FBUyxNQUFNLE1BQU0sSUFBSTtNQUNqQyxLQUFLLGdCQUFnQixXQUFXLE1BQU0sTUFBTSxFQUFFLENBQUMsWUFBWSxJQUFJLENBQUM7S0FDbEU7SUFDRjtHQUNGLENBQUM7RUFDSDs7Ozs7Ozs7Ozs7OztFQWFBLGNBQWMsRUFDWixTQUNBLFNBQ0M7R0FDRDtJQUNFLG1CQUFtQixXQUFXLFNBQVMsU0FBUztLQUM5QyxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsTUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLEtBQUssU0FBUyxJQUFJO0dBQzlDLElBQUksQ0FBQyxJQUFJLFNBQVMsV0FBVyxNQUFNLEdBQUc7SUFDcEM7S0FDRSxPQUFPLE1BQU0sMkRBQTJEO0lBQzFFO0lBQ0E7R0FDRjtHQUNBLE1BQU0sYUFBYSxJQUFJLFdBQVcsU0FBUztHQUMzQyxNQUFNLEVBQ0osUUFDQSxVQUNFLEtBQUssa0JBQWtCO0lBQ3pCO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQztHQUNELElBQUksVUFBVSxTQUFTLE1BQU07R0FDN0IsTUFBTSxnQkFBZ0IsQ0FBQztHQUN2QjtJQUNFLElBQUksU0FBUztLQUNYLGNBQWMsS0FBSyxDQUFDLHlDQUF5QyxLQUFLLENBQUM7S0FDbkUsSUFBSSxRQUFRO01BQ1YsY0FBYyxLQUFLLENBQUMsd0RBQXdELE1BQU0sQ0FBQztLQUNyRjtJQUNGO0dBQ0Y7OztHQUdBLE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLElBQUksQ0FBQyxXQUFXLEtBQUssbUJBQW1CLElBQUksTUFBTSxHQUFHO0lBQ25EO0tBQ0UsY0FBYyxLQUFLLDhDQUE4QyxtQ0FBbUMsT0FBTyxFQUFFO0lBQy9HO0lBQ0EsVUFBVSxLQUFLLG1CQUFtQixJQUFJLE1BQU07R0FDOUM7R0FDQSxJQUFJLENBQUMsU0FBUztJQUNaOzs7S0FHRSxPQUFPLE1BQU0sdUJBQXVCLGVBQWUsR0FBRyxHQUFHO0lBQzNEO0lBQ0E7R0FDRjtHQUNBOzs7SUFHRSxPQUFPLGVBQWUsNEJBQTRCLGVBQWUsR0FBRyxHQUFHO0lBQ3ZFLGNBQWMsU0FBUSxRQUFPO0tBQzNCLElBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztNQUN0QixPQUFPLElBQUksR0FBRyxHQUFHO0tBQ25CLE9BQU87TUFDTCxPQUFPLElBQUksR0FBRztLQUNoQjtJQUNGLENBQUM7SUFDRCxPQUFPLFNBQVM7R0FDbEI7OztHQUdBLElBQUk7R0FDSixJQUFJO0lBQ0Ysa0JBQWtCLFFBQVEsT0FBTztLQUMvQjtLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7R0FDSCxTQUFTLEtBQUs7SUFDWixrQkFBa0IsUUFBUSxPQUFPLEdBQUc7R0FDdEM7O0dBRUEsTUFBTSxlQUFlLFNBQVMsTUFBTTtHQUNwQyxJQUFJLDJCQUEyQixZQUFZLEtBQUssaUJBQWlCLGVBQWU7SUFDOUUsa0JBQWtCLGdCQUFnQixNQUFNLE9BQU0sUUFBTzs7S0FFbkQsSUFBSSxjQUFjO01BQ2hCOzs7T0FHRSxPQUFPLGVBQWUsc0NBQXNDLElBQUksZUFBZSxHQUFHLEVBQUUseUNBQXlDO09BQzdILE9BQU8sTUFBTSxvQkFBb0IsS0FBSztPQUN0QyxPQUFPLE1BQU0sR0FBRztPQUNoQixPQUFPLFNBQVM7TUFDbEI7TUFDQSxJQUFJO09BQ0YsT0FBTyxNQUFNLGFBQWEsT0FBTztRQUMvQjtRQUNBO1FBQ0E7UUFDQTtPQUNGLENBQUM7TUFDSCxTQUFTLFVBQVU7T0FDakIsSUFBSSxvQkFBb0IsT0FBTztRQUM3QixNQUFNO09BQ1I7TUFDRjtLQUNGO0tBQ0EsSUFBSSxLQUFLLGVBQWU7TUFDdEI7OztPQUdFLE9BQU8sZUFBZSxzQ0FBc0MsSUFBSSxlQUFlLEdBQUcsRUFBRSx3Q0FBd0M7T0FDNUgsT0FBTyxNQUFNLG9CQUFvQixLQUFLO09BQ3RDLE9BQU8sTUFBTSxHQUFHO09BQ2hCLE9BQU8sU0FBUztNQUNsQjtNQUNBLE9BQU8sS0FBSyxjQUFjLE9BQU87T0FDL0I7T0FDQTtPQUNBO01BQ0YsQ0FBQztLQUNIO0tBQ0EsTUFBTTtJQUNSLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7Ozs7OztFQWdCQSxrQkFBa0IsRUFDaEIsS0FDQSxZQUNBLFNBQ0EsU0FDQztHQUNELE1BQU0sU0FBUyxLQUFLLFFBQVEsSUFBSSxRQUFRLE1BQU0sS0FBSyxDQUFDO0dBQ3BELEtBQUssTUFBTSxTQUFTLFFBQVE7SUFDMUIsSUFBSTs7O0lBR0osTUFBTSxjQUFjLE1BQU0sTUFBTTtLQUM5QjtLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFDRCxJQUFJLGFBQWE7S0FDZjs7O01BR0UsSUFBSSx1QkFBdUIsU0FBUztPQUNsQyxPQUFPLEtBQUssaUJBQWlCLGVBQWUsR0FBRyxFQUFFLGVBQWUseURBQXlELGdFQUFnRSxLQUFLO01BQ2hNO0tBQ0Y7OztLQUdBLFNBQVM7S0FDVCxJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxXQUFXLEdBQUc7O01BRWhELFNBQVM7S0FDWCxPQUFPLElBQUksWUFBWSxnQkFBZ0IsVUFFdkMsT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLFdBQVcsR0FBRzs7TUFFckMsU0FBUztLQUNYLE9BQU8sSUFBSSxPQUFPLGdCQUFnQixXQUFXOzs7O01BSTNDLFNBQVM7S0FDWDs7S0FFQSxPQUFPO01BQ0w7TUFDQTtLQUNGO0lBQ0Y7R0FDRjs7R0FFQSxPQUFPLENBQUM7RUFDVjs7Ozs7Ozs7Ozs7Ozs7O0VBZUEsa0JBQWtCLFNBQVMsU0FBUyxlQUFlO0dBQ2pELEtBQUssbUJBQW1CLElBQUksUUFBUSxpQkFBaUIsT0FBTyxDQUFDO0VBQy9EOzs7Ozs7OztFQVFBLGdCQUFnQixTQUFTO0dBQ3ZCLEtBQUssZ0JBQWdCLGlCQUFpQixPQUFPO0VBQy9DOzs7Ozs7RUFNQSxjQUFjLE9BQU87R0FDbkI7SUFDRSxtQkFBbUIsT0FBTyxPQUFPLFVBQVU7S0FDekMsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxtQkFBbUIsVUFBVSxPQUFPLFNBQVM7S0FDM0MsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7SUFDRCxtQkFBbUIsT0FBTyxNQUFNLFNBQVMsVUFBVTtLQUNqRCxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztJQUNELG1CQUFtQixVQUFVLE1BQU0sU0FBUyxVQUFVO0tBQ3BELFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0lBQ0QsbUJBQW1CLE9BQU8sTUFBTSxRQUFRLFVBQVU7S0FDaEQsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLElBQUksQ0FBQyxLQUFLLFFBQVEsSUFBSSxNQUFNLE1BQU0sR0FBRztJQUNuQyxLQUFLLFFBQVEsSUFBSSxNQUFNLFFBQVEsQ0FBQyxDQUFDO0dBQ25DOzs7R0FHQSxLQUFLLFFBQVEsSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDLEtBQUssS0FBSztFQUMzQzs7Ozs7O0VBTUEsZ0JBQWdCLE9BQU87R0FDckIsSUFBSSxDQUFDLEtBQUssUUFBUSxJQUFJLE1BQU0sTUFBTSxHQUFHO0lBQ25DLE1BQU0sSUFBSSxhQUFhLDhDQUE4QyxFQUNuRSxRQUFRLE1BQU0sT0FDaEIsQ0FBQztHQUNIO0dBQ0EsTUFBTSxhQUFhLEtBQUssUUFBUSxJQUFJLE1BQU0sTUFBTSxDQUFDLENBQUMsUUFBUSxLQUFLO0dBQy9ELElBQUksYUFBYSxDQUFDLEdBQUc7SUFDbkIsS0FBSyxRQUFRLElBQUksTUFBTSxNQUFNLENBQUMsQ0FBQyxPQUFPLFlBQVksQ0FBQztHQUNyRCxPQUFPO0lBQ0wsTUFBTSxJQUFJLGFBQWEsdUNBQXVDO0dBQ2hFO0VBQ0Y7Q0FDRjs7Ozs7Ozs7Q0FTQSxJQUFJOzs7Ozs7OztDQVFKLE1BQU0saUNBQWlDO0VBQ3JDLElBQUksQ0FBQyxlQUFlO0dBQ2xCLGdCQUFnQixJQUFJLE9BQU87O0dBRTNCLGNBQWMsaUJBQWlCO0dBQy9CLGNBQWMsaUJBQWlCO0VBQ2pDO0VBQ0EsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCQSxTQUFTLGNBQWMsU0FBUyxTQUFTLFFBQVE7RUFDL0MsSUFBSTtFQUNKLElBQUksT0FBTyxZQUFZLFVBQVU7R0FDL0IsTUFBTSxhQUFhLElBQUksSUFBSSxTQUFTLFNBQVMsSUFBSTtHQUNqRDtJQUNFLElBQUksRUFBRSxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsV0FBVyxNQUFNLElBQUk7S0FDNUQsTUFBTSxJQUFJLGFBQWEsa0JBQWtCO01BQ3ZDLFlBQVk7TUFDWixVQUFVO01BQ1YsV0FBVztLQUNiLENBQUM7SUFDSDs7O0lBR0EsTUFBTSxlQUFlLFFBQVEsV0FBVyxNQUFNLElBQUksV0FBVyxXQUFXOztJQUV4RSxNQUFNLFlBQVk7SUFDbEIsSUFBSSxJQUFJLE9BQU8sR0FBRyxXQUFXLENBQUMsQ0FBQyxLQUFLLFlBQVksR0FBRztLQUNqRCxPQUFPLE1BQU0saUVBQWlFLGNBQWMsVUFBVSw2Q0FBNkMsOERBQThEO0lBQ25OO0dBQ0Y7R0FDQSxNQUFNLGlCQUFpQixFQUNyQixVQUNJO0lBQ0o7S0FDRSxJQUFJLElBQUksYUFBYSxXQUFXLFlBQVksSUFBSSxXQUFXLFdBQVcsUUFBUTtNQUM1RSxPQUFPLE1BQU0sR0FBRyxRQUFRLGlEQUFpRCxHQUFHLElBQUksU0FBUyxFQUFFLHdEQUF3RCwrQkFBK0I7S0FDcEw7SUFDRjtJQUNBLE9BQU8sSUFBSSxTQUFTLFdBQVc7R0FDakM7O0dBRUEsUUFBUSxJQUFJLE1BQU0sZUFBZSxTQUFTLE1BQU07RUFDbEQsT0FBTyxJQUFJLG1CQUFtQixRQUFROztHQUVwQyxRQUFRLElBQUksWUFBWSxTQUFTLFNBQVMsTUFBTTtFQUNsRCxPQUFPLElBQUksT0FBTyxZQUFZLFlBQVk7O0dBRXhDLFFBQVEsSUFBSSxNQUFNLFNBQVMsU0FBUyxNQUFNO0VBQzVDLE9BQU8sSUFBSSxtQkFBbUIsT0FBTztHQUNuQyxRQUFRO0VBQ1YsT0FBTztHQUNMLE1BQU0sSUFBSSxhQUFhLDBCQUEwQjtJQUMvQyxZQUFZO0lBQ1osVUFBVTtJQUNWLFdBQVc7R0FDYixDQUFDO0VBQ0g7RUFDQSxNQUFNLGdCQUFnQix5QkFBeUI7RUFDL0MsY0FBYyxjQUFjLEtBQUs7RUFDakMsT0FBTztDQUNUOzs7Ozs7OztDQVNBLE1BQU0sb0JBQW9CO0VBQ3hCLGlCQUFpQjtFQUNqQixVQUFVO0VBQ1YsUUFBUTtFQUNSLFNBQVM7RUFDVCxRQUFRLE9BQU8saUJBQWlCLGNBQWMsYUFBYSxRQUFRO0NBQ3JFO0NBQ0EsTUFBTSxvQkFBbUIsY0FBYTtFQUNwQyxPQUFPO0dBQUMsa0JBQWtCO0dBQVE7R0FBVyxrQkFBa0I7RUFBTSxDQUFDLENBQUMsUUFBTyxVQUFTLFNBQVMsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRztDQUM1SDtDQUNBLE1BQU0sdUJBQXNCLE9BQU07RUFDaEMsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLGlCQUFpQixHQUFHO0dBQ2hELEdBQUcsR0FBRztFQUNSO0NBQ0Y7Q0FDQSxNQUFNLGFBQWE7RUFDakIsZ0JBQWUsWUFBVztHQUN4QixxQkFBb0IsUUFBTztJQUN6QixJQUFJLE9BQU8sUUFBUSxTQUFTLFVBQVU7S0FDcEMsa0JBQWtCLE9BQU8sUUFBUTtJQUNuQztHQUNGLENBQUM7RUFDSDtFQUNBLHlCQUF3QixrQkFBaUI7R0FDdkMsT0FBTyxpQkFBaUIsaUJBQWlCLGtCQUFrQixlQUFlO0VBQzVFO0VBQ0Esa0JBQWlCLGtCQUFpQjtHQUNoQyxPQUFPLGlCQUFpQixpQkFBaUIsa0JBQWtCLFFBQVE7RUFDckU7RUFDQSxpQkFBaUI7R0FDZixPQUFPLGtCQUFrQjtFQUMzQjtFQUNBLGlCQUFnQixrQkFBaUI7R0FDL0IsT0FBTyxpQkFBaUIsaUJBQWlCLGtCQUFrQixPQUFPO0VBQ3BFO0VBQ0EsaUJBQWlCO0dBQ2YsT0FBTyxrQkFBa0I7RUFDM0I7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxTQUFTLFVBQVUsT0FBTyxTQUFTO0VBQ2pDLE1BQU0sZ0JBQWdCLFFBQVE7RUFDOUIsTUFBTSxVQUFVLGFBQWE7RUFDN0IsT0FBTztDQUNUOztDQUdBLElBQUk7RUFDRixLQUFLLCtCQUErQixFQUFFO0NBQ3hDLFNBQVMsR0FBRyxDQUFDOzs7Ozs7Ozs7Q0FVYixNQUFNLHdCQUF3Qjs7Ozs7Ozs7OztDQVU5QixTQUFTLGVBQWUsT0FBTztFQUM3QixJQUFJLENBQUMsT0FBTztHQUNWLE1BQU0sSUFBSSxhQUFhLHFDQUFxQyxFQUMxRCxNQUNGLENBQUM7RUFDSDs7O0VBR0EsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM3QixNQUFNLFlBQVksSUFBSSxJQUFJLE9BQU8sU0FBUyxJQUFJO0dBQzlDLE9BQU87SUFDTCxVQUFVLFVBQVU7SUFDcEIsS0FBSyxVQUFVO0dBQ2pCO0VBQ0Y7RUFDQSxNQUFNLEVBQ0osVUFDQSxRQUNFO0VBQ0osSUFBSSxDQUFDLEtBQUs7R0FDUixNQUFNLElBQUksYUFBYSxxQ0FBcUMsRUFDMUQsTUFDRixDQUFDO0VBQ0g7OztFQUdBLElBQUksQ0FBQyxVQUFVO0dBQ2IsTUFBTSxZQUFZLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSTtHQUM1QyxPQUFPO0lBQ0wsVUFBVSxVQUFVO0lBQ3BCLEtBQUssVUFBVTtHQUNqQjtFQUNGOzs7RUFHQSxNQUFNLGNBQWMsSUFBSSxJQUFJLEtBQUssU0FBUyxJQUFJO0VBQzlDLE1BQU0sY0FBYyxJQUFJLElBQUksS0FBSyxTQUFTLElBQUk7RUFDOUMsWUFBWSxhQUFhLElBQUksdUJBQXVCLFFBQVE7RUFDNUQsT0FBTztHQUNMLFVBQVUsWUFBWTtHQUN0QixLQUFLLFlBQVk7RUFDbkI7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxNQUFNLDRCQUE0QjtFQUNoQyxjQUFjO0dBQ1osS0FBSyxjQUFjLENBQUM7R0FDcEIsS0FBSyxpQkFBaUIsQ0FBQztHQUN2QixLQUFLLG1CQUFtQixPQUFPLEVBQzdCLFNBQ0EsWUFDSTs7SUFFSixJQUFJLE9BQU87S0FDVCxNQUFNLGtCQUFrQjtJQUMxQjtHQUNGO0dBQ0EsS0FBSywyQkFBMkIsT0FBTyxFQUNyQyxPQUNBLE9BQ0EscUJBQ0k7SUFDSixJQUFJLE1BQU0sU0FBUyxXQUFXO0tBQzVCLElBQUksU0FBUyxNQUFNLG1CQUFtQixNQUFNLDJCQUEyQixTQUFTOztNQUU5RSxNQUFNLE1BQU0sTUFBTSxnQkFBZ0I7TUFDbEMsSUFBSSxnQkFBZ0I7T0FDbEIsS0FBSyxlQUFlLEtBQUssR0FBRztNQUM5QixPQUFPO09BQ0wsS0FBSyxZQUFZLEtBQUssR0FBRztNQUMzQjtLQUNGO0lBQ0Y7SUFDQSxPQUFPO0dBQ1Q7RUFDRjtDQUNGOzs7Ozs7Ozs7Ozs7OztDQWVBLE1BQU0sdUJBQXVCO0VBQzNCLFlBQVksRUFDVixzQkFDQztHQUNELEtBQUsscUJBQXFCLE9BQU8sRUFDL0IsU0FDQSxhQUNJOzs7SUFHSixNQUFNLFlBQVksV0FBVyxRQUFRLFdBQVcsS0FBSyxJQUFJLEtBQUssSUFBSSxPQUFPLGFBQWEsS0FBSyxvQkFBb0Isa0JBQWtCLFFBQVEsR0FBRzs7SUFFNUksT0FBTyxXQUFXLElBQUksUUFBUSxVQUFVLEVBQ3RDLFNBQVMsUUFBUSxRQUNuQixDQUFDLElBQUk7R0FDUDtHQUNBLEtBQUssc0JBQXNCO0VBQzdCO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7O0NBZUEsTUFBTSxZQUFZLFlBQVksZ0JBQWdCO0VBQzVDLE9BQU8sZUFBZSxVQUFVO0VBQ2hDLEtBQUssTUFBTSxPQUFPLGFBQWE7R0FDN0IsT0FBTyxJQUFJLEdBQUc7RUFDaEI7RUFDQSxPQUFPLFNBQVM7Q0FDbEI7Ozs7Ozs7Q0FPQSxTQUFTLG9CQUFvQixhQUFhO0VBQ3hDLE1BQU0sZ0JBQWdCLFlBQVk7RUFDbEMsSUFBSSxnQkFBZ0IsR0FBRztHQUNyQixPQUFPLGVBQWUsZ0NBQWdDLEdBQUcsY0FBYyxZQUFZLFVBQVUsa0JBQWtCLElBQUksU0FBUyxTQUFTLFVBQVU7R0FDL0ksU0FBUywwQkFBMEIsV0FBVztHQUM5QyxPQUFPLFNBQVM7RUFDbEI7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxTQUFTLGFBQWEsWUFBWSxNQUFNO0VBQ3RDLElBQUksS0FBSyxXQUFXLEdBQUc7R0FDckI7RUFDRjtFQUNBLE9BQU8sZUFBZSxVQUFVO0VBQ2hDLEtBQUssTUFBTSxPQUFPLE1BQU07R0FDdEIsT0FBTyxJQUFJLEdBQUc7RUFDaEI7RUFDQSxPQUFPLFNBQVM7Q0FDbEI7Ozs7Ozs7O0NBUUEsU0FBUyxvQkFBb0IsZ0JBQWdCLHNCQUFzQjtFQUNqRSxNQUFNLGlCQUFpQixlQUFlO0VBQ3RDLE1BQU0sd0JBQXdCLHFCQUFxQjtFQUNuRCxJQUFJLGtCQUFrQix1QkFBdUI7R0FDM0MsSUFBSSxVQUFVLGNBQWMsZUFBZSxPQUFPLG1CQUFtQixJQUFJLEtBQUssSUFBSTtHQUNsRixJQUFJLHdCQUF3QixHQUFHO0lBQzdCLFdBQVcsSUFBSSxzQkFBc0IsS0FBSyxPQUFPLDBCQUEwQixJQUFJLFFBQVEsUUFBUTtHQUNqRztHQUNBLE9BQU8sZUFBZSxPQUFPO0dBQzdCLGFBQWEsOEJBQThCLGNBQWM7R0FDekQsYUFBYSxtQ0FBbUMsb0JBQW9CO0dBQ3BFLE9BQU8sU0FBUztFQUNsQjtDQUNGOzs7Ozs7OztDQVNBLElBQUk7Ozs7Ozs7Ozs7Q0FVSixTQUFTLHFDQUFxQztFQUM1QyxJQUFJLGtCQUFrQixXQUFXO0dBQy9CLE1BQU0sZUFBZSxJQUFJLFNBQVMsRUFBRTtHQUNwQyxJQUFJLFVBQVUsY0FBYztJQUMxQixJQUFJO0tBQ0YsSUFBSSxTQUFTLGFBQWEsSUFBSTtLQUM5QixnQkFBZ0I7SUFDbEIsU0FBUyxPQUFPO0tBQ2QsZ0JBQWdCO0lBQ2xCO0dBQ0Y7R0FDQSxnQkFBZ0I7RUFDbEI7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTRCQSxlQUFlLGFBQWEsVUFBVSxVQUFVO0VBQzlDLElBQUksU0FBUzs7RUFFYixJQUFJLFNBQVMsS0FBSztHQUNoQixNQUFNLGNBQWMsSUFBSSxJQUFJLFNBQVMsR0FBRztHQUN4QyxTQUFTLFlBQVk7RUFDdkI7RUFDQSxJQUFJLFdBQVcsS0FBSyxTQUFTLFFBQVE7R0FDbkMsTUFBTSxJQUFJLGFBQWEsOEJBQThCLEVBQ25ELE9BQ0YsQ0FBQztFQUNIO0VBQ0EsTUFBTSxpQkFBaUIsU0FBUyxNQUFNOztFQUV0QyxNQUFNLGVBQWU7R0FDbkIsU0FBUyxJQUFJLFFBQVEsZUFBZSxPQUFPO0dBQzNDLFFBQVEsZUFBZTtHQUN2QixZQUFZLGVBQWU7RUFDN0I7O0VBRUEsTUFBTSx1QkFBdUI7Ozs7RUFJN0IsTUFBTSxPQUFPLG1DQUFtQyxJQUFJLGVBQWUsT0FBTyxNQUFNLGVBQWUsS0FBSztFQUNwRyxPQUFPLElBQUksU0FBUyxNQUFNLG9CQUFvQjtDQUNoRDs7Ozs7OztDQVFBLFNBQVMsWUFBWSxTQUFTLGNBQWM7RUFDMUMsTUFBTSxjQUFjLElBQUksSUFBSSxPQUFPO0VBQ25DLEtBQUssTUFBTSxTQUFTLGNBQWM7R0FDaEMsWUFBWSxhQUFhLE9BQU8sS0FBSztFQUN2QztFQUNBLE9BQU8sWUFBWTtDQUNyQjs7Ozs7Ozs7Ozs7OztDQWFBLGVBQWUsdUJBQXVCLE9BQU8sU0FBUyxjQUFjLGNBQWM7RUFDaEYsTUFBTSxxQkFBcUIsWUFBWSxRQUFRLEtBQUssWUFBWTs7RUFFaEUsSUFBSSxRQUFRLFFBQVEsb0JBQW9CO0dBQ3RDLE9BQU8sTUFBTSxNQUFNLFNBQVMsWUFBWTtFQUMxQzs7RUFFQSxNQUFNLGNBQWMsT0FBTyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsWUFBWSxHQUFHLEVBQ2pFLGNBQWMsS0FDaEIsQ0FBQztFQUNELE1BQU0sWUFBWSxNQUFNLE1BQU0sS0FBSyxTQUFTLFdBQVc7RUFDdkQsS0FBSyxNQUFNLFlBQVksV0FBVztHQUNoQyxNQUFNLHNCQUFzQixZQUFZLFNBQVMsS0FBSyxZQUFZO0dBQ2xFLElBQUksdUJBQXVCLHFCQUFxQjtJQUM5QyxPQUFPLE1BQU0sTUFBTSxVQUFVLFlBQVk7R0FDM0M7RUFDRjtFQUNBO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsTUFBTSxTQUFTOzs7O0VBSWIsY0FBYztHQUNaLEtBQUssVUFBVSxJQUFJLFNBQVMsU0FBUyxXQUFXO0lBQzlDLEtBQUssVUFBVTtJQUNmLEtBQUssU0FBUztHQUNoQixDQUFDO0VBQ0g7Q0FDRjs7Ozs7Ozs7Ozs7Q0FZQSxNQUFNLHNCQUFzQixJQUFJLElBQUk7Ozs7Ozs7Ozs7Ozs7OztDQWdCcEMsZUFBZSw2QkFBNkI7RUFDMUM7R0FDRSxPQUFPLElBQUksZ0JBQWdCLG9CQUFvQixLQUFLLEtBQUssK0JBQStCO0VBQzFGO0VBQ0EsS0FBSyxNQUFNLFlBQVkscUJBQXFCO0dBQzFDLE1BQU0sU0FBUztHQUNmO0lBQ0UsT0FBTyxJQUFJLFVBQVUsY0FBYztHQUNyQztFQUNGO0VBQ0E7R0FDRSxPQUFPLElBQUksNkJBQTZCO0VBQzFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxTQUFTLFFBQVEsSUFBSTtFQUNuQixPQUFPLElBQUksU0FBUSxZQUFXLFdBQVcsU0FBUyxFQUFFLENBQUM7Q0FDdkQ7O0NBR0EsSUFBSTtFQUNGLEtBQUssK0JBQStCLEVBQUU7Q0FDeEMsU0FBUyxHQUFHLENBQUM7Ozs7Ozs7O0NBU2IsU0FBUyxVQUFVLE9BQU87RUFDeEIsT0FBTyxPQUFPLFVBQVUsV0FBVyxJQUFJLFFBQVEsS0FBSyxJQUFJO0NBQzFEOzs7Ozs7Ozs7O0NBVUEsTUFBTSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBaUJwQixZQUFZLFVBQVUsU0FBUztHQUM3QixLQUFLLGFBQWEsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FzQ25CO0lBQ0UsbUJBQW1CLFdBQVcsUUFBUSxPQUFPLGlCQUFpQjtLQUM1RCxZQUFZO0tBQ1osV0FBVztLQUNYLFVBQVU7S0FDVixXQUFXO0lBQ2IsQ0FBQztHQUNIO0dBQ0EsT0FBTyxPQUFPLE1BQU0sT0FBTztHQUMzQixLQUFLLFFBQVEsUUFBUTtHQUNyQixLQUFLLFlBQVk7R0FDakIsS0FBSyxtQkFBbUIsSUFBSSxTQUFTO0dBQ3JDLEtBQUssMEJBQTBCLENBQUM7OztHQUdoQyxLQUFLLFdBQVcsQ0FBQyxHQUFHLFNBQVMsT0FBTztHQUNwQyxLQUFLLGtCQUFrQixJQUFJLElBQUk7R0FDL0IsS0FBSyxNQUFNLFVBQVUsS0FBSyxVQUFVO0lBQ2xDLEtBQUssZ0JBQWdCLElBQUksUUFBUSxDQUFDLENBQUM7R0FDckM7R0FDQSxLQUFLLE1BQU0sVUFBVSxLQUFLLGlCQUFpQixPQUFPO0VBQ3BEOzs7Ozs7Ozs7Ozs7OztFQWNBLE1BQU0sTUFBTSxPQUFPO0dBQ2pCLE1BQU0sRUFDSixVQUNFO0dBQ0osSUFBSSxVQUFVLFVBQVUsS0FBSztHQUM3QixJQUFJLFFBQVEsU0FBUyxjQUFjLGlCQUFpQixjQUFjLE1BQU0saUJBQWlCO0lBQ3ZGLE1BQU0sMEJBQTBCLE1BQU0sTUFBTTtJQUM1QyxJQUFJLHlCQUF5QjtLQUMzQjtNQUNFLE9BQU8sSUFBSSwrQ0FBK0MsSUFBSSxlQUFlLFFBQVEsR0FBRyxFQUFFLEVBQUU7S0FDOUY7S0FDQSxPQUFPO0lBQ1Q7R0FDRjs7OztHQUlBLE1BQU0sa0JBQWtCLEtBQUssWUFBWSxjQUFjLElBQUksUUFBUSxNQUFNLElBQUk7R0FDN0UsSUFBSTtJQUNGLEtBQUssTUFBTSxNQUFNLEtBQUssaUJBQWlCLGtCQUFrQixHQUFHO0tBQzFELFVBQVUsTUFBTSxHQUFHO01BQ2pCLFNBQVMsUUFBUSxNQUFNO01BQ3ZCO0tBQ0YsQ0FBQztJQUNIO0dBQ0YsU0FBUyxLQUFLO0lBQ1osSUFBSSxlQUFlLE9BQU87S0FDeEIsTUFBTSxJQUFJLGFBQWEsbUNBQW1DLEVBQ3hELG9CQUFvQixJQUFJLFFBQzFCLENBQUM7SUFDSDtHQUNGOzs7O0dBSUEsTUFBTSx3QkFBd0IsUUFBUSxNQUFNO0dBQzVDLElBQUk7SUFDRixJQUFJOztJQUVKLGdCQUFnQixNQUFNLE1BQU0sU0FBUyxRQUFRLFNBQVMsYUFBYSxZQUFZLEtBQUssVUFBVSxZQUFZO0lBQzFHLElBQUksa0JBQWtCLGNBQWM7S0FDbEMsT0FBTyxNQUFNLHlCQUF5QixJQUFJLGVBQWUsUUFBUSxHQUFHLEVBQUUsK0JBQStCLFdBQVcsY0FBYyxPQUFPLEdBQUc7SUFDMUk7SUFDQSxLQUFLLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixpQkFBaUIsR0FBRztLQUMvRCxnQkFBZ0IsTUFBTSxTQUFTO01BQzdCO01BQ0EsU0FBUztNQUNULFVBQVU7S0FDWixDQUFDO0lBQ0g7SUFDQSxPQUFPO0dBQ1QsU0FBUyxPQUFPO0lBQ2Q7S0FDRSxPQUFPLElBQUkseUJBQXlCLElBQUksZUFBZSxRQUFRLEdBQUcsRUFBRSxvQkFBb0IsS0FBSztJQUMvRjs7O0lBR0EsSUFBSSxpQkFBaUI7S0FDbkIsTUFBTSxLQUFLLGFBQWEsZ0JBQWdCO01BQy9CO01BQ1A7TUFDQSxpQkFBaUIsZ0JBQWdCLE1BQU07TUFDdkMsU0FBUyxzQkFBc0IsTUFBTTtLQUN2QyxDQUFDO0lBQ0g7SUFDQSxNQUFNO0dBQ1I7RUFDRjs7Ozs7Ozs7Ozs7RUFXQSxNQUFNLGlCQUFpQixPQUFPO0dBQzVCLE1BQU0sV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLO0dBQ3ZDLE1BQU0sZ0JBQWdCLFNBQVMsTUFBTTtHQUNyQyxLQUFLLEtBQUssVUFBVSxLQUFLLFNBQVMsT0FBTyxhQUFhLENBQUM7R0FDdkQsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7O0VBYUEsTUFBTSxXQUFXLEtBQUs7R0FDcEIsTUFBTSxVQUFVLFVBQVUsR0FBRztHQUM3QixJQUFJO0dBQ0osTUFBTSxFQUNKLFdBQ0EsaUJBQ0UsS0FBSztHQUNULE1BQU0sbUJBQW1CLE1BQU0sS0FBSyxZQUFZLFNBQVMsTUFBTTtHQUMvRCxNQUFNLG9CQUFvQixPQUFPLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxZQUFZLEdBQUcsRUFDdkUsVUFDRixDQUFDO0dBQ0QsaUJBQWlCLE1BQU0sT0FBTyxNQUFNLGtCQUFrQixpQkFBaUI7R0FDdkU7SUFDRSxJQUFJLGdCQUFnQjtLQUNsQixPQUFPLE1BQU0sK0JBQStCLFVBQVUsR0FBRztJQUMzRCxPQUFPO0tBQ0wsT0FBTyxNQUFNLGdDQUFnQyxVQUFVLEdBQUc7SUFDNUQ7R0FDRjtHQUNBLEtBQUssTUFBTSxZQUFZLEtBQUssaUJBQWlCLDBCQUEwQixHQUFHO0lBQ3hFLGlCQUFrQixNQUFNLFNBQVM7S0FDL0I7S0FDQTtLQUNBO0tBQ0EsU0FBUztLQUNULE9BQU8sS0FBSztJQUNkLENBQUMsS0FBTTtHQUNUO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7O0VBZ0JBLE1BQU0sU0FBUyxLQUFLLFVBQVU7R0FDNUIsTUFBTSxVQUFVLFVBQVUsR0FBRzs7O0dBRzdCLE1BQU0sUUFBUSxDQUFDO0dBQ2YsTUFBTSxtQkFBbUIsTUFBTSxLQUFLLFlBQVksU0FBUyxPQUFPO0dBQ2hFO0lBQ0UsSUFBSSxpQkFBaUIsVUFBVSxpQkFBaUIsV0FBVyxPQUFPO0tBQ2hFLE1BQU0sSUFBSSxhQUFhLG9DQUFvQztNQUN6RCxLQUFLLGVBQWUsaUJBQWlCLEdBQUc7TUFDeEMsUUFBUSxpQkFBaUI7S0FDM0IsQ0FBQztJQUNIOztJQUVBLE1BQU0sT0FBTyxTQUFTLFFBQVEsSUFBSSxNQUFNO0lBQ3hDLElBQUksTUFBTTtLQUNSLE9BQU8sTUFBTSxvQkFBb0IsZUFBZSxpQkFBaUIsR0FBRyxFQUFFLEtBQUssZ0JBQWdCLEtBQUssY0FBYyxxRUFBcUUsMERBQTBEO0lBQy9PO0dBQ0Y7R0FDQSxJQUFJLENBQUMsVUFBVTtJQUNiO0tBQ0UsT0FBTyxNQUFNLDRDQUE0QyxJQUFJLGVBQWUsaUJBQWlCLEdBQUcsRUFBRSxHQUFHO0lBQ3ZHO0lBQ0EsTUFBTSxJQUFJLGFBQWEsOEJBQThCLEVBQ25ELEtBQUssZUFBZSxpQkFBaUIsR0FBRyxFQUMxQyxDQUFDO0dBQ0g7R0FDQSxNQUFNLGtCQUFrQixNQUFNLEtBQUssMkJBQTJCLFFBQVE7R0FDdEUsSUFBSSxDQUFDLGlCQUFpQjtJQUNwQjtLQUNFLE9BQU8sTUFBTSxhQUFhLGVBQWUsaUJBQWlCLEdBQUcsRUFBRSxNQUFNLHVCQUF1QixlQUFlO0lBQzdHO0lBQ0EsT0FBTztHQUNUO0dBQ0EsTUFBTSxFQUNKLFdBQ0EsaUJBQ0UsS0FBSztHQUNULE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxLQUFLLFNBQVM7R0FDOUMsTUFBTSx5QkFBeUIsS0FBSyxZQUFZLGdCQUFnQjtHQUNoRSxNQUFNLGNBQWMseUJBQXlCLE1BQU07Ozs7SUFJbkQ7SUFBTyxpQkFBaUIsTUFBTTtJQUFHLENBQUMsaUJBQWlCO0lBQUc7R0FBWSxJQUFJO0dBQ3RFO0lBQ0UsT0FBTyxNQUFNLGlCQUFpQixVQUFVLGdDQUFnQyxPQUFPLGVBQWUsaUJBQWlCLEdBQUcsRUFBRSxFQUFFO0dBQ3hIO0dBQ0EsSUFBSTtJQUNGLE1BQU0sTUFBTSxJQUFJLGtCQUFrQix5QkFBeUIsZ0JBQWdCLE1BQU0sSUFBSSxlQUFlO0dBQ3RHLFNBQVMsT0FBTztJQUNkLElBQUksaUJBQWlCLE9BQU87O0tBRTFCLElBQUksTUFBTSxTQUFTLHNCQUFzQjtNQUN2QyxNQUFNLDJCQUEyQjtLQUNuQztLQUNBLE1BQU07SUFDUjtHQUNGO0dBQ0EsS0FBSyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsZ0JBQWdCLEdBQUc7SUFDOUQsTUFBTSxTQUFTO0tBQ2I7S0FDQTtLQUNBLGFBQWEsZ0JBQWdCLE1BQU07S0FDbkMsU0FBUztLQUNULE9BQU8sS0FBSztJQUNkLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7O0VBWUEsTUFBTSxZQUFZLFNBQVMsTUFBTTtHQUMvQixNQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksS0FBSztHQUNoQyxJQUFJLENBQUMsS0FBSyxXQUFXLE1BQU07SUFDekIsSUFBSSxtQkFBbUI7SUFDdkIsS0FBSyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsb0JBQW9CLEdBQUc7S0FDbEUsbUJBQW1CLFVBQVUsTUFBTSxTQUFTO01BQzFDO01BQ0EsU0FBUztNQUNULE9BQU8sS0FBSzs7TUFFWixRQUFRLEtBQUs7S0FDZixDQUFDLENBQUM7SUFDSjtJQUNBLEtBQUssV0FBVyxPQUFPO0dBQ3pCO0dBQ0EsT0FBTyxLQUFLLFdBQVc7RUFDekI7Ozs7Ozs7O0VBUUEsWUFBWSxNQUFNO0dBQ2hCLEtBQUssTUFBTSxVQUFVLEtBQUssVUFBVSxTQUFTO0lBQzNDLElBQUksUUFBUSxRQUFRO0tBQ2xCLE9BQU87SUFDVDtHQUNGO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7OztFQWlCQSxNQUFNLGFBQWEsTUFBTSxPQUFPO0dBQzlCLEtBQUssTUFBTSxZQUFZLEtBQUssaUJBQWlCLElBQUksR0FBRzs7O0lBR2xELE1BQU0sU0FBUyxLQUFLO0dBQ3RCO0VBQ0Y7Ozs7Ozs7Ozs7RUFVQSxDQUFDLGlCQUFpQixNQUFNO0dBQ3RCLEtBQUssTUFBTSxVQUFVLEtBQUssVUFBVSxTQUFTO0lBQzNDLElBQUksT0FBTyxPQUFPLFVBQVUsWUFBWTtLQUN0QyxNQUFNLFFBQVEsS0FBSyxnQkFBZ0IsSUFBSSxNQUFNO0tBQzdDLE1BQU0sb0JBQW1CLFVBQVM7TUFDaEMsTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsS0FBSyxHQUFHLEVBQzVELE1BQ0YsQ0FBQzs7O01BR0QsT0FBTyxPQUFPLEtBQUssQ0FBQyxhQUFhO0tBQ25DO0tBQ0EsTUFBTTtJQUNSO0dBQ0Y7RUFDRjs7Ozs7Ozs7Ozs7Ozs7RUFjQSxVQUFVLFNBQVM7R0FDakIsS0FBSyx3QkFBd0IsS0FBSyxPQUFPO0dBQ3pDLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7RUFXQSxNQUFNLGNBQWM7R0FDbEIsT0FBTyxLQUFLLHdCQUF3QixRQUFRO0lBQzFDLE1BQU0sV0FBVyxLQUFLLHdCQUF3QixPQUFPLENBQUM7SUFDdEQsTUFBTSxTQUFTLE1BQU0sUUFBUSxXQUFXLFFBQVE7SUFDaEQsTUFBTSxpQkFBaUIsT0FBTyxNQUFLLE1BQUssRUFBRSxXQUFXLFVBQVU7SUFDL0QsSUFBSSxnQkFBZ0I7S0FDbEIsTUFBTSxlQUFlO0lBQ3ZCO0dBQ0Y7RUFDRjs7Ozs7RUFLQSxVQUFVO0dBQ1IsS0FBSyxpQkFBaUIsUUFBUSxJQUFJO0VBQ3BDOzs7Ozs7Ozs7OztFQVdBLE1BQU0sMkJBQTJCLFVBQVU7R0FDekMsSUFBSSxrQkFBa0I7R0FDdEIsSUFBSSxjQUFjO0dBQ2xCLEtBQUssTUFBTSxZQUFZLEtBQUssaUJBQWlCLGlCQUFpQixHQUFHO0lBQy9ELGtCQUFtQixNQUFNLFNBQVM7S0FDaEMsU0FBUyxLQUFLO0tBQ2QsVUFBVTtLQUNWLE9BQU8sS0FBSztJQUNkLENBQUMsS0FBTTtJQUNQLGNBQWM7SUFDZCxJQUFJLENBQUMsaUJBQWlCO0tBQ3BCO0lBQ0Y7R0FDRjtHQUNBLElBQUksQ0FBQyxhQUFhO0lBQ2hCLElBQUksbUJBQW1CLGdCQUFnQixXQUFXLEtBQUs7S0FDckQsa0JBQWtCO0lBQ3BCO0lBQ0E7S0FDRSxJQUFJLGlCQUFpQjtNQUNuQixJQUFJLGdCQUFnQixXQUFXLEtBQUs7T0FDbEMsSUFBSSxnQkFBZ0IsV0FBVyxHQUFHO1FBQ2hDLE9BQU8sS0FBSyxxQkFBcUIsS0FBSyxRQUFRLElBQUksTUFBTSw2REFBNkQsbURBQW1EO09BQzFLLE9BQU87UUFDTCxPQUFPLE1BQU0scUJBQXFCLEtBQUssUUFBUSxJQUFJLE1BQU0sOEJBQThCLFNBQVMsT0FBTyxnQkFBZ0Isd0JBQXdCO09BQ2pKO01BQ0Y7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7Q0FDRjs7Ozs7Ozs7Ozs7OztDQWNBLE1BQU0sU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF1QmIsWUFBWSxVQUFVLENBQUMsR0FBRzs7Ozs7Ozs7R0FReEIsS0FBSyxZQUFZLFdBQVcsZUFBZSxRQUFRLFNBQVM7Ozs7Ozs7O0dBUTVELEtBQUssVUFBVSxRQUFRLFdBQVcsQ0FBQzs7Ozs7Ozs7R0FRbkMsS0FBSyxlQUFlLFFBQVE7Ozs7Ozs7O0dBUTVCLEtBQUssZUFBZSxRQUFRO0VBQzlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW9CQSxPQUFPLFNBQVM7R0FDZCxNQUFNLENBQUMsZ0JBQWdCLEtBQUssVUFBVSxPQUFPO0dBQzdDLE9BQU87RUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF1QkEsVUFBVSxTQUFTOztHQUVqQixJQUFJLG1CQUFtQixZQUFZO0lBQ2pDLFVBQVU7S0FDUixPQUFPO0tBQ1AsU0FBUyxRQUFRO0lBQ25CO0dBQ0Y7R0FDQSxNQUFNLFFBQVEsUUFBUTtHQUN0QixNQUFNLFVBQVUsT0FBTyxRQUFRLFlBQVksV0FBVyxJQUFJLFFBQVEsUUFBUSxPQUFPLElBQUksUUFBUTtHQUM3RixNQUFNLFNBQVMsWUFBWSxVQUFVLFFBQVEsU0FBUztHQUN0RCxNQUFNLFVBQVUsSUFBSSxnQkFBZ0IsTUFBTTtJQUN4QztJQUNBO0lBQ0E7R0FDRixDQUFDO0dBQ0QsTUFBTSxlQUFlLEtBQUssYUFBYSxTQUFTLFNBQVMsS0FBSztHQUM5RCxNQUFNLGNBQWMsS0FBSyxlQUFlLGNBQWMsU0FBUyxTQUFTLEtBQUs7O0dBRTdFLE9BQU8sQ0FBQyxjQUFjLFdBQVc7RUFDbkM7RUFDQSxNQUFNLGFBQWEsU0FBUyxTQUFTLE9BQU87R0FDMUMsTUFBTSxRQUFRLGFBQWEsb0JBQW9CO0lBQzdDO0lBQ0E7R0FDRixDQUFDO0dBQ0QsSUFBSSxXQUFXO0dBQ2YsSUFBSTtJQUNGLFdBQVcsTUFBTSxLQUFLLFFBQVEsU0FBUyxPQUFPOzs7O0lBSTlDLElBQUksQ0FBQyxZQUFZLFNBQVMsU0FBUyxTQUFTO0tBQzFDLE1BQU0sSUFBSSxhQUFhLGVBQWUsRUFDcEMsS0FBSyxRQUFRLElBQ2YsQ0FBQztJQUNIO0dBQ0YsU0FBUyxPQUFPO0lBQ2QsSUFBSSxpQkFBaUIsT0FBTztLQUMxQixLQUFLLE1BQU0sWUFBWSxRQUFRLGlCQUFpQixpQkFBaUIsR0FBRztNQUNsRSxXQUFXLE1BQU0sU0FBUztPQUN4QjtPQUNBO09BQ0E7TUFDRixDQUFDO01BQ0QsSUFBSSxVQUFVO09BQ1o7TUFDRjtLQUNGO0lBQ0Y7SUFDQSxJQUFJLENBQUMsVUFBVTtLQUNiLE1BQU07SUFDUixPQUFPO0tBQ0wsT0FBTyxJQUFJLHdCQUF3QixlQUFlLFFBQVEsR0FBRyxFQUFFLE9BQU8sTUFBTSxpQkFBaUIsUUFBUSxNQUFNLFNBQVMsSUFBSSxHQUFHLDJEQUEyRCwyQkFBMkI7SUFDbk47R0FDRjtHQUNBLEtBQUssTUFBTSxZQUFZLFFBQVEsaUJBQWlCLG9CQUFvQixHQUFHO0lBQ3JFLFdBQVcsTUFBTSxTQUFTO0tBQ3hCO0tBQ0E7S0FDQTtJQUNGLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDtFQUNBLE1BQU0sZUFBZSxjQUFjLFNBQVMsU0FBUyxPQUFPO0dBQzFELElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtJQUNGLFdBQVcsTUFBTTtHQUNuQixTQUFTLE9BQU8sQ0FJaEI7R0FDQSxJQUFJO0lBQ0YsTUFBTSxRQUFRLGFBQWEscUJBQXFCO0tBQzlDO0tBQ0E7S0FDQTtJQUNGLENBQUM7SUFDRCxNQUFNLFFBQVEsWUFBWTtHQUM1QixTQUFTLGdCQUFnQjtJQUN2QixJQUFJLDBCQUEwQixPQUFPO0tBQ25DLFFBQVE7SUFDVjtHQUNGO0dBQ0EsTUFBTSxRQUFRLGFBQWEsc0JBQXNCO0lBQy9DO0lBQ0E7SUFDQTtJQUNPO0dBQ1QsQ0FBQztHQUNELFFBQVEsUUFBUTtHQUNoQixJQUFJLE9BQU87SUFDVCxNQUFNO0dBQ1I7RUFDRjtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0NBLE1BQU0seUJBQXlCLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQWtCdEMsWUFBWSxVQUFVLENBQUMsR0FBRztHQUN4QixRQUFRLFlBQVksV0FBVyxnQkFBZ0IsUUFBUSxTQUFTO0dBQ2hFLE1BQU0sT0FBTztHQUNiLEtBQUsscUJBQXFCLFFBQVEsc0JBQXNCLFFBQVEsUUFBUTs7Ozs7R0FLeEUsS0FBSyxRQUFRLEtBQUssaUJBQWlCLHNDQUFzQztFQUMzRTs7Ozs7Ozs7RUFRQSxNQUFNLFFBQVEsU0FBUyxTQUFTO0dBQzlCLE1BQU0sV0FBVyxNQUFNLFFBQVEsV0FBVyxPQUFPO0dBQ2pELElBQUksVUFBVTtJQUNaLE9BQU87R0FDVDs7O0dBR0EsSUFBSSxRQUFRLFNBQVMsUUFBUSxNQUFNLFNBQVMsV0FBVztJQUNyRCxPQUFPLE1BQU0sS0FBSyxlQUFlLFNBQVMsT0FBTztHQUNuRDs7O0dBR0EsT0FBTyxNQUFNLEtBQUssYUFBYSxTQUFTLE9BQU87RUFDakQ7RUFDQSxNQUFNLGFBQWEsU0FBUyxTQUFTO0dBQ25DLElBQUk7R0FDSixNQUFNLFNBQVMsUUFBUSxVQUFVLENBQUM7O0dBRWxDLElBQUksS0FBSyxvQkFBb0I7SUFDM0I7S0FDRSxPQUFPLEtBQUssZ0NBQWdDLEdBQUcsZUFBZSxRQUFRLEdBQUcsRUFBRSxNQUFNLEtBQUssVUFBVSxhQUFhLHFDQUFxQztJQUNwSjtJQUNBLE1BQU0sc0JBQXNCLE9BQU87SUFDbkMsTUFBTSxxQkFBcUIsUUFBUTtJQUNuQyxNQUFNLHNCQUFzQixDQUFDLHNCQUFzQix1QkFBdUI7OztJQUcxRSxXQUFXLE1BQU0sUUFBUSxNQUFNLElBQUksUUFBUSxTQUFTLEVBQ2xELFdBQVcsUUFBUSxTQUFTLFlBQVksc0JBQXNCLHNCQUFzQixVQUN0RixDQUFDLENBQUM7Ozs7Ozs7O0lBUUYsSUFBSSx1QkFBdUIsdUJBQXVCLFFBQVEsU0FBUyxXQUFXO0tBQzVFLEtBQUssc0NBQXNDO0tBQzNDLE1BQU0sWUFBWSxNQUFNLFFBQVEsU0FBUyxTQUFTLFNBQVMsTUFBTSxDQUFDO0tBQ2xFO01BQ0UsSUFBSSxXQUFXO09BQ2IsT0FBTyxJQUFJLGtCQUFrQixlQUFlLFFBQVEsR0FBRyxFQUFFLEtBQUssb0NBQW9DO01BQ3BHO0tBQ0Y7SUFDRjtHQUNGLE9BQU87OztJQUdMLE1BQU0sSUFBSSxhQUFhLDBCQUEwQjtLQUMvQyxXQUFXLEtBQUs7S0FDaEIsS0FBSyxRQUFRO0lBQ2YsQ0FBQztHQUNIO0dBQ0E7SUFDRSxNQUFNLFdBQVcsT0FBTyxZQUFhLE1BQU0sUUFBUSxZQUFZLFNBQVMsTUFBTTs7O0lBRzlFLE9BQU8sZUFBZSxrQ0FBa0MsZUFBZSxRQUFRLEdBQUcsQ0FBQztJQUNuRixPQUFPLElBQUksOEJBQThCLGVBQWUsb0JBQW9CLFVBQVUsU0FBUyxNQUFNLFFBQVEsR0FBRztJQUNoSCxPQUFPLGVBQWUsNEJBQTRCO0lBQ2xELE9BQU8sSUFBSSxPQUFPO0lBQ2xCLE9BQU8sU0FBUztJQUNoQixPQUFPLGVBQWUsNkJBQTZCO0lBQ25ELE9BQU8sSUFBSSxRQUFRO0lBQ25CLE9BQU8sU0FBUztJQUNoQixPQUFPLFNBQVM7R0FDbEI7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxNQUFNLGVBQWUsU0FBUyxTQUFTO0dBQ3JDLEtBQUssc0NBQXNDO0dBQzNDLE1BQU0sV0FBVyxNQUFNLFFBQVEsTUFBTSxPQUFPOzs7R0FHNUMsTUFBTSxZQUFZLE1BQU0sUUFBUSxTQUFTLFNBQVMsU0FBUyxNQUFNLENBQUM7R0FDbEUsSUFBSSxDQUFDLFdBQVc7OztJQUdkLE1BQU0sSUFBSSxhQUFhLDJCQUEyQjtLQUNoRCxLQUFLLFFBQVE7S0FDYixRQUFRLFNBQVM7SUFDbkIsQ0FBQztHQUNIO0dBQ0EsT0FBTztFQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBNEJBLHdDQUF3QztHQUN0QyxJQUFJLHFCQUFxQjtHQUN6QixJQUFJLDZCQUE2QjtHQUNqQyxLQUFLLE1BQU0sQ0FBQyxPQUFPLFdBQVcsS0FBSyxRQUFRLFFBQVEsR0FBRzs7SUFFcEQsSUFBSSxXQUFXLGlCQUFpQix3Q0FBd0M7S0FDdEU7SUFDRjs7SUFFQSxJQUFJLFdBQVcsaUJBQWlCLG1DQUFtQztLQUNqRSxxQkFBcUI7SUFDdkI7SUFDQSxJQUFJLE9BQU8saUJBQWlCO0tBQzFCO0lBQ0Y7R0FDRjtHQUNBLElBQUksK0JBQStCLEdBQUc7SUFDcEMsS0FBSyxRQUFRLEtBQUssaUJBQWlCLGlDQUFpQztHQUN0RSxPQUFPLElBQUksNkJBQTZCLEtBQUssdUJBQXVCLE1BQU07O0lBRXhFLEtBQUssUUFBUSxPQUFPLG9CQUFvQixDQUFDO0dBQzNDOztFQUVGO0NBQ0Y7Q0FDQSxpQkFBaUIsb0NBQW9DLEVBQ25ELE1BQU0sZ0JBQWdCLEVBQ3BCLFlBQ0M7RUFDRCxJQUFJLENBQUMsWUFBWSxTQUFTLFVBQVUsS0FBSztHQUN2QyxPQUFPO0VBQ1Q7RUFDQSxPQUFPO0NBQ1QsRUFDRjtDQUNBLGlCQUFpQix5Q0FBeUMsRUFDeEQsTUFBTSxnQkFBZ0IsRUFDcEIsWUFDQztFQUNELE9BQU8sU0FBUyxhQUFhLE1BQU0sYUFBYSxRQUFRLElBQUk7Q0FDOUQsRUFDRjs7Ozs7Ozs7Ozs7OztDQWNBLE1BQU0sbUJBQW1COzs7Ozs7Ozs7OztFQVd2QixZQUFZLEVBQ1YsV0FDQSxVQUFVLENBQUMsR0FDWCxvQkFBb0IsU0FDbEIsQ0FBQyxHQUFHO0dBQ04sS0FBSyxtQkFBbUIsSUFBSSxJQUFJO0dBQ2hDLEtBQUssb0JBQW9CLElBQUksSUFBSTtHQUNqQyxLQUFLLDBCQUEwQixJQUFJLElBQUk7R0FDdkMsS0FBSyxZQUFZLElBQUksaUJBQWlCO0lBQ3BDLFdBQVcsV0FBVyxnQkFBZ0IsU0FBUztJQUMvQyxTQUFTLENBQUMsR0FBRyxTQUFTLElBQUksdUJBQXVCLEVBQy9DLG9CQUFvQixLQUN0QixDQUFDLENBQUM7SUFDRjtHQUNGLENBQUM7O0dBRUQsS0FBSyxVQUFVLEtBQUssUUFBUSxLQUFLLElBQUk7R0FDckMsS0FBSyxXQUFXLEtBQUssU0FBUyxLQUFLLElBQUk7RUFDekM7Ozs7O0VBS0EsSUFBSSxXQUFXO0dBQ2IsT0FBTyxLQUFLO0VBQ2Q7Ozs7Ozs7Ozs7O0VBV0EsU0FBUyxTQUFTO0dBQ2hCLEtBQUssZUFBZSxPQUFPO0dBQzNCLElBQUksQ0FBQyxLQUFLLGlDQUFpQztJQUN6QyxLQUFLLGlCQUFpQixXQUFXLEtBQUssT0FBTztJQUM3QyxLQUFLLGlCQUFpQixZQUFZLEtBQUssUUFBUTtJQUMvQyxLQUFLLGtDQUFrQztHQUN6QztFQUNGOzs7Ozs7OztFQVFBLGVBQWUsU0FBUztHQUN0QjtJQUNFLG1CQUFtQixRQUFRLFNBQVM7S0FDbEMsWUFBWTtLQUNaLFdBQVc7S0FDWCxVQUFVO0tBQ1YsV0FBVztJQUNiLENBQUM7R0FDSDtHQUNBLE1BQU0sa0JBQWtCLENBQUM7R0FDekIsS0FBSyxNQUFNLFNBQVMsU0FBUzs7SUFFM0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtLQUM3QixnQkFBZ0IsS0FBSyxLQUFLO0lBQzVCLE9BQU8sSUFBSSxTQUFTLE1BQU0sYUFBYSxXQUFXO0tBQ2hELGdCQUFnQixLQUFLLE1BQU0sR0FBRztJQUNoQztJQUNBLE1BQU0sRUFDSixVQUNBLFFBQ0UsZUFBZSxLQUFLO0lBQ3hCLE1BQU0sWUFBWSxPQUFPLFVBQVUsWUFBWSxNQUFNLFdBQVcsV0FBVztJQUMzRSxJQUFJLEtBQUssaUJBQWlCLElBQUksR0FBRyxLQUFLLEtBQUssaUJBQWlCLElBQUksR0FBRyxNQUFNLFVBQVU7S0FDakYsTUFBTSxJQUFJLGFBQWEseUNBQXlDO01BQzlELFlBQVksS0FBSyxpQkFBaUIsSUFBSSxHQUFHO01BQ3pDLGFBQWE7S0FDZixDQUFDO0lBQ0g7SUFDQSxJQUFJLE9BQU8sVUFBVSxZQUFZLE1BQU0sV0FBVztLQUNoRCxJQUFJLEtBQUssd0JBQXdCLElBQUksUUFBUSxLQUFLLEtBQUssd0JBQXdCLElBQUksUUFBUSxNQUFNLE1BQU0sV0FBVztNQUNoSCxNQUFNLElBQUksYUFBYSw2Q0FBNkMsRUFDbEUsSUFDRixDQUFDO0tBQ0g7S0FDQSxLQUFLLHdCQUF3QixJQUFJLFVBQVUsTUFBTSxTQUFTO0lBQzVEO0lBQ0EsS0FBSyxpQkFBaUIsSUFBSSxLQUFLLFFBQVE7SUFDdkMsS0FBSyxrQkFBa0IsSUFBSSxLQUFLLFNBQVM7SUFDekMsSUFBSSxnQkFBZ0IsU0FBUyxHQUFHO0tBQzlCLE1BQU0saUJBQWlCLGlEQUFpRCxTQUFTLGdCQUFnQixLQUFLLElBQUksRUFBRSxrQ0FBa0M7S0FDOUk7TUFDRSxPQUFPLEtBQUssY0FBYztLQUM1QjtJQUNGO0dBQ0Y7RUFDRjs7Ozs7Ozs7Ozs7RUFXQSxRQUFRLE9BQU87OztHQUdiLE9BQU8sVUFBVSxPQUFPLFlBQVk7SUFDbEMsTUFBTSxzQkFBc0IsSUFBSSw0QkFBNEI7SUFDNUQsS0FBSyxTQUFTLFFBQVEsS0FBSyxtQkFBbUI7OztJQUc5QyxLQUFLLE1BQU0sQ0FBQyxLQUFLLGFBQWEsS0FBSyxrQkFBa0I7S0FDbkQsTUFBTSxZQUFZLEtBQUssd0JBQXdCLElBQUksUUFBUTtLQUMzRCxNQUFNLFlBQVksS0FBSyxrQkFBa0IsSUFBSSxHQUFHO0tBQ2hELE1BQU0sVUFBVSxJQUFJLFFBQVEsS0FBSztNQUMvQjtNQUNBLE9BQU87TUFDUCxhQUFhO0tBQ2YsQ0FBQztLQUNELE1BQU0sUUFBUSxJQUFJLEtBQUssU0FBUyxVQUFVO01BQ3hDLFFBQVEsRUFDTixTQUNGO01BQ0E7TUFDQTtLQUNGLENBQUMsQ0FBQztJQUNKO0lBQ0EsTUFBTSxFQUNKLGFBQ0EsbUJBQ0U7SUFDSjtLQUNFLG9CQUFvQixhQUFhLGNBQWM7SUFDakQ7SUFDQSxPQUFPO0tBQ0w7S0FDQTtJQUNGO0dBQ0YsQ0FBQztFQUNIOzs7Ozs7Ozs7OztFQVdBLFNBQVMsT0FBTzs7O0dBR2QsT0FBTyxVQUFVLE9BQU8sWUFBWTtJQUNsQyxNQUFNLFFBQVEsTUFBTSxLQUFLLE9BQU8sS0FBSyxLQUFLLFNBQVMsU0FBUztJQUM1RCxNQUFNLDBCQUEwQixNQUFNLE1BQU0sS0FBSztJQUNqRCxNQUFNLG9CQUFvQixJQUFJLElBQUksS0FBSyxpQkFBaUIsT0FBTyxDQUFDO0lBQ2hFLE1BQU0sY0FBYyxDQUFDO0lBQ3JCLEtBQUssTUFBTSxXQUFXLHlCQUF5QjtLQUM3QyxJQUFJLENBQUMsa0JBQWtCLElBQUksUUFBUSxHQUFHLEdBQUc7TUFDdkMsTUFBTSxNQUFNLE9BQU8sT0FBTztNQUMxQixZQUFZLEtBQUssUUFBUSxHQUFHO0tBQzlCO0lBQ0Y7SUFDQTtLQUNFLG9CQUFvQixXQUFXO0lBQ2pDO0lBQ0EsT0FBTyxFQUNMLFlBQ0Y7R0FDRixDQUFDO0VBQ0g7Ozs7Ozs7RUFPQSxxQkFBcUI7R0FDbkIsT0FBTyxLQUFLO0VBQ2Q7Ozs7Ozs7RUFPQSxnQkFBZ0I7R0FDZCxPQUFPLENBQUMsR0FBRyxLQUFLLGlCQUFpQixLQUFLLENBQUM7RUFDekM7Ozs7Ozs7Ozs7RUFVQSxrQkFBa0IsS0FBSztHQUNyQixNQUFNLFlBQVksSUFBSSxJQUFJLEtBQUssU0FBUyxJQUFJO0dBQzVDLE9BQU8sS0FBSyxpQkFBaUIsSUFBSSxVQUFVLElBQUk7RUFDakQ7Ozs7OztFQU1BLHdCQUF3QixVQUFVO0dBQ2hDLE9BQU8sS0FBSyx3QkFBd0IsSUFBSSxRQUFRO0VBQ2xEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBbUJBLE1BQU0sY0FBYyxTQUFTO0dBQzNCLE1BQU0sTUFBTSxtQkFBbUIsVUFBVSxRQUFRLE1BQU07R0FDdkQsTUFBTSxXQUFXLEtBQUssa0JBQWtCLEdBQUc7R0FDM0MsSUFBSSxVQUFVO0lBQ1osTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLEtBQUssS0FBSyxTQUFTLFNBQVM7SUFDNUQsT0FBTyxNQUFNLE1BQU0sUUFBUTtHQUM3QjtHQUNBLE9BQU87RUFDVDs7Ozs7Ozs7O0VBU0Esd0JBQXdCLEtBQUs7R0FDM0IsTUFBTSxXQUFXLEtBQUssa0JBQWtCLEdBQUc7R0FDM0MsSUFBSSxDQUFDLFVBQVU7SUFDYixNQUFNLElBQUksYUFBYSxxQkFBcUIsRUFDMUMsSUFDRixDQUFDO0dBQ0g7R0FDQSxRQUFPLFlBQVc7SUFDaEIsUUFBUSxVQUFVLElBQUksUUFBUSxHQUFHO0lBQ2pDLFFBQVEsU0FBUyxPQUFPLE9BQU8sRUFDN0IsU0FDRixHQUFHLFFBQVEsTUFBTTtJQUNqQixPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU87R0FDckM7RUFDRjtDQUNGOzs7Ozs7OztDQVNBLElBQUk7Ozs7O0NBS0osTUFBTSxzQ0FBc0M7RUFDMUMsSUFBSSxDQUFDLG9CQUFvQjtHQUN2QixxQkFBcUIsSUFBSSxtQkFBbUI7RUFDOUM7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLFNBQVMsMEJBQTBCLFdBQVcsOEJBQThCLENBQUMsR0FBRzs7O0VBRzlFLEtBQUssTUFBTSxhQUFhLENBQUMsR0FBRyxVQUFVLGFBQWEsS0FBSyxDQUFDLEdBQUc7R0FDMUQsSUFBSSw0QkFBNEIsTUFBSyxXQUFVLE9BQU8sS0FBSyxTQUFTLENBQUMsR0FBRztJQUN0RSxVQUFVLGFBQWEsT0FBTyxTQUFTO0dBQ3pDO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CQSxVQUFVLHNCQUFzQixLQUFLLEVBQ25DLDhCQUE4QixDQUFDLFNBQVMsVUFBVSxHQUNsRCxpQkFBaUIsY0FDakIsWUFBWSxNQUNaLG9CQUNFLENBQUMsR0FBRztFQUNOLE1BQU0sWUFBWSxJQUFJLElBQUksS0FBSyxTQUFTLElBQUk7RUFDNUMsVUFBVSxPQUFPO0VBQ2pCLE1BQU0sVUFBVTtFQUNoQixNQUFNLDBCQUEwQiwwQkFBMEIsV0FBVywyQkFBMkI7RUFDaEcsTUFBTSx3QkFBd0I7RUFDOUIsSUFBSSxrQkFBa0Isd0JBQXdCLFNBQVMsU0FBUyxHQUFHLEdBQUc7R0FDcEUsTUFBTSxlQUFlLElBQUksSUFBSSx3QkFBd0IsSUFBSTtHQUN6RCxhQUFhLFlBQVk7R0FDekIsTUFBTSxhQUFhO0VBQ3JCO0VBQ0EsSUFBSSxXQUFXO0dBQ2IsTUFBTSxXQUFXLElBQUksSUFBSSx3QkFBd0IsSUFBSTtHQUNyRCxTQUFTLFlBQVk7R0FDckIsTUFBTSxTQUFTO0VBQ2pCO0VBQ0EsSUFBSSxpQkFBaUI7R0FDbkIsTUFBTSxpQkFBaUIsZ0JBQWdCLEVBQ3JDLEtBQUssVUFDUCxDQUFDO0dBQ0QsS0FBSyxNQUFNLGdCQUFnQixnQkFBZ0I7SUFDekMsTUFBTSxhQUFhO0dBQ3JCO0VBQ0Y7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsTUFBTSxzQkFBc0IsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFpQmhDLFlBQVksb0JBQW9CLFNBQVM7R0FDdkMsTUFBTSxTQUFTLEVBQ2IsY0FDSTtJQUNKLE1BQU0sa0JBQWtCLG1CQUFtQixtQkFBbUI7SUFDOUQsS0FBSyxNQUFNLGVBQWUsc0JBQXNCLFFBQVEsS0FBSyxPQUFPLEdBQUc7S0FDckUsTUFBTSxXQUFXLGdCQUFnQixJQUFJLFdBQVc7S0FDaEQsSUFBSSxVQUFVO01BQ1osTUFBTSxZQUFZLG1CQUFtQix3QkFBd0IsUUFBUTtNQUNyRSxPQUFPO09BQ0w7T0FDQTtNQUNGO0tBQ0Y7SUFDRjtJQUNBO0tBQ0UsT0FBTyxNQUFNLHlDQUF5QyxlQUFlLFFBQVEsR0FBRyxDQUFDO0lBQ25GO0lBQ0E7R0FDRjtHQUNBLE1BQU0sT0FBTyxtQkFBbUIsUUFBUTtFQUMxQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLFNBQVMsU0FBUyxTQUFTO0VBQ3pCLE1BQU0scUJBQXFCLDhCQUE4QjtFQUN6RCxNQUFNLGdCQUFnQixJQUFJLGNBQWMsb0JBQW9CLE9BQU87RUFDbkUsY0FBYyxhQUFhO0NBQzdCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E0QkEsU0FBUyxTQUFTLFNBQVM7RUFDekIsTUFBTSxxQkFBcUIsOEJBQThCO0VBQ3pELG1CQUFtQixTQUFTLE9BQU87Q0FDckM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1QkEsU0FBUyxpQkFBaUIsU0FBUyxTQUFTO0VBQzFDLFNBQVMsT0FBTztFQUNoQixTQUFTLE9BQU87Q0FDbEI7Ozs7Ozs7O0NBU0EsTUFBTSxvQkFBb0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQjFCLE1BQU0sdUJBQXVCLE9BQU8scUJBQXFCLGtCQUFrQixzQkFBc0I7RUFDL0YsTUFBTSxhQUFhLE1BQU0sS0FBSyxPQUFPLEtBQUs7RUFDMUMsTUFBTSxxQkFBcUIsV0FBVyxRQUFPLGNBQWE7R0FDeEQsT0FBTyxVQUFVLFNBQVMsZUFBZSxLQUFLLFVBQVUsU0FBUyxLQUFLLGFBQWEsS0FBSyxLQUFLLGNBQWM7RUFDN0csQ0FBQztFQUNELE1BQU0sUUFBUSxJQUFJLG1CQUFtQixLQUFJLGNBQWEsS0FBSyxPQUFPLE9BQU8sU0FBUyxDQUFDLENBQUM7RUFDcEYsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7OztDQWVBLFNBQVMsd0JBQXdCOztFQUUvQixLQUFLLGlCQUFpQixhQUFZLFVBQVM7R0FDekMsTUFBTSxZQUFZLFdBQVcsZ0JBQWdCO0dBQzdDLE1BQU0sVUFBVSxxQkFBcUIsU0FBUyxDQUFDLENBQUMsTUFBSyxrQkFBaUI7SUFDcEU7S0FDRSxJQUFJLGNBQWMsU0FBUyxHQUFHO01BQzVCLE9BQU8sSUFBSSx5REFBeUQsa0JBQWtCLGFBQWE7S0FDckc7SUFDRjtHQUNGLENBQUMsQ0FBQztFQUNKLENBQUM7Q0FDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsTUFBTSx3QkFBd0IsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXlCbEMsWUFBWSxTQUFTLEVBQ25CLFlBQVksQ0FBQyxHQUFHLEdBQ2hCLFdBQVcsQ0FBQyxNQUNWLENBQUMsR0FBRztHQUNOO0lBQ0UsbUJBQW1CLGVBQWUsV0FBVyxRQUFRO0tBQ25ELFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0lBQ0QsbUJBQW1CLGVBQWUsVUFBVSxRQUFRO0tBQ2xELFlBQVk7S0FDWixXQUFXO0tBQ1gsVUFBVTtLQUNWLFdBQVc7SUFDYixDQUFDO0dBQ0g7R0FDQSxPQUFNLFlBQVcsS0FBSyxPQUFPLE9BQU8sR0FBRyxPQUFPO0dBQzlDLEtBQUssYUFBYTtHQUNsQixLQUFLLFlBQVk7RUFDbkI7Ozs7Ozs7Ozs7O0VBV0EsT0FBTyxFQUNMLEtBQ0EsV0FDQztHQUNELElBQUksV0FBVyxRQUFRLFNBQVMsWUFBWTtJQUMxQyxPQUFPO0dBQ1Q7R0FDQSxNQUFNLG9CQUFvQixJQUFJLFdBQVcsSUFBSTtHQUM3QyxLQUFLLE1BQU0sVUFBVSxLQUFLLFdBQVc7SUFDbkMsSUFBSSxPQUFPLEtBQUssaUJBQWlCLEdBQUc7S0FDbEM7TUFDRSxPQUFPLElBQUksd0JBQXdCLGtCQUFrQixZQUFZLDhEQUE4RCxHQUFHLE9BQU8sU0FBUyxHQUFHO0tBQ3ZKO0tBQ0EsT0FBTztJQUNUO0dBQ0Y7R0FDQSxJQUFJLEtBQUssV0FBVyxNQUFLLFdBQVUsT0FBTyxLQUFLLGlCQUFpQixDQUFDLEdBQUc7SUFDbEU7S0FDRSxPQUFPLE1BQU0sd0JBQXdCLGtCQUFrQixLQUFLLGdCQUFnQjtJQUM5RTtJQUNBLE9BQU87R0FDVDtHQUNBO0lBQ0UsT0FBTyxJQUFJLHdCQUF3QixrQkFBa0IsWUFBWSwwREFBMEQsc0JBQXNCO0dBQ25KO0dBQ0EsT0FBTztFQUNUO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQkEsU0FBUyx3QkFBd0IsS0FBSztFQUNwQyxNQUFNLHFCQUFxQiw4QkFBOEI7RUFDekQsT0FBTyxtQkFBbUIsd0JBQXdCLEdBQUc7Q0FDdkQ7Q0FFQSxRQUFRLGtCQUFrQjtDQUMxQixRQUFRLHdCQUF3QjtDQUNoQyxRQUFRLGVBQWU7Q0FDdkIsUUFBUSwwQkFBMEI7Q0FDbEMsUUFBUSxtQkFBbUI7Q0FDM0IsUUFBUSxnQkFBZ0I7QUFFNUIsRUFBRSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ3b3JrYm94LTdlNWViNDJiLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImRlZmluZShbJ2V4cG9ydHMnXSwgKGZ1bmN0aW9uIChleHBvcnRzKSB7ICd1c2Ugc3RyaWN0JztcblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB0cnkge1xuICAgICAgc2VsZlsnd29ya2JveDpjb3JlOjcuNC4wJ10gJiYgXygpO1xuICAgIH0gY2F0Y2ggKGUpIHt9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBDbGFpbSBhbnkgY3VycmVudGx5IGF2YWlsYWJsZSBjbGllbnRzIG9uY2UgdGhlIHNlcnZpY2Ugd29ya2VyXG4gICAgICogYmVjb21lcyBhY3RpdmUuIFRoaXMgaXMgbm9ybWFsbHkgdXNlZCBpbiBjb25qdW5jdGlvbiB3aXRoIGBza2lwV2FpdGluZygpYC5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LWNvcmVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjbGllbnRzQ2xhaW0oKSB7XG4gICAgICBzZWxmLmFkZEV2ZW50TGlzdGVuZXIoJ2FjdGl2YXRlJywgKCkgPT4gc2VsZi5jbGllbnRzLmNsYWltKCkpO1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBsb2dnZXIgPSAoKCkgPT4ge1xuICAgICAgLy8gRG9uJ3Qgb3ZlcndyaXRlIHRoaXMgdmFsdWUgaWYgaXQncyBhbHJlYWR5IHNldC5cbiAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvcHVsbC8yMjg0I2lzc3VlY29tbWVudC01NjA0NzA5MjNcbiAgICAgIGlmICghKCdfX1dCX0RJU0FCTEVfREVWX0xPR1MnIGluIGdsb2JhbFRoaXMpKSB7XG4gICAgICAgIHNlbGYuX19XQl9ESVNBQkxFX0RFVl9MT0dTID0gZmFsc2U7XG4gICAgICB9XG4gICAgICBsZXQgaW5Hcm91cCA9IGZhbHNlO1xuICAgICAgY29uc3QgbWV0aG9kVG9Db2xvck1hcCA9IHtcbiAgICAgICAgZGVidWc6IGAjN2Y4YzhkYCxcbiAgICAgICAgbG9nOiBgIzJlY2M3MWAsXG4gICAgICAgIHdhcm46IGAjZjM5YzEyYCxcbiAgICAgICAgZXJyb3I6IGAjYzAzOTJiYCxcbiAgICAgICAgZ3JvdXBDb2xsYXBzZWQ6IGAjMzQ5OGRiYCxcbiAgICAgICAgZ3JvdXBFbmQ6IG51bGwgLy8gTm8gY29sb3JlZCBwcmVmaXggb24gZ3JvdXBFbmRcbiAgICAgIH07XG4gICAgICBjb25zdCBwcmludCA9IGZ1bmN0aW9uIChtZXRob2QsIGFyZ3MpIHtcbiAgICAgICAgaWYgKHNlbGYuX19XQl9ESVNBQkxFX0RFVl9MT0dTKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgPT09ICdncm91cENvbGxhcHNlZCcpIHtcbiAgICAgICAgICAvLyBTYWZhcmkgZG9lc24ndCBwcmludCBhbGwgY29uc29sZS5ncm91cENvbGxhcHNlZCgpIGFyZ3VtZW50czpcbiAgICAgICAgICAvLyBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTgyNzU0XG4gICAgICAgICAgaWYgKC9eKCg/IWNocm9tZXxhbmRyb2lkKS4pKnNhZmFyaS9pLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCkpIHtcbiAgICAgICAgICAgIGNvbnNvbGVbbWV0aG9kXSguLi5hcmdzKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc3R5bGVzID0gW2BiYWNrZ3JvdW5kOiAke21ldGhvZFRvQ29sb3JNYXBbbWV0aG9kXX1gLCBgYm9yZGVyLXJhZGl1czogMC41ZW1gLCBgY29sb3I6IHdoaXRlYCwgYGZvbnQtd2VpZ2h0OiBib2xkYCwgYHBhZGRpbmc6IDJweCAwLjVlbWBdO1xuICAgICAgICAvLyBXaGVuIGluIGEgZ3JvdXAsIHRoZSB3b3JrYm94IHByZWZpeCBpcyBub3QgZGlzcGxheWVkLlxuICAgICAgICBjb25zdCBsb2dQcmVmaXggPSBpbkdyb3VwID8gW10gOiBbJyVjd29ya2JveCcsIHN0eWxlcy5qb2luKCc7JyldO1xuICAgICAgICBjb25zb2xlW21ldGhvZF0oLi4ubG9nUHJlZml4LCAuLi5hcmdzKTtcbiAgICAgICAgaWYgKG1ldGhvZCA9PT0gJ2dyb3VwQ29sbGFwc2VkJykge1xuICAgICAgICAgIGluR3JvdXAgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtZXRob2QgPT09ICdncm91cEVuZCcpIHtcbiAgICAgICAgICBpbkdyb3VwID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10eXBlc1xuICAgICAgY29uc3QgYXBpID0ge307XG4gICAgICBjb25zdCBsb2dnZXJNZXRob2RzID0gT2JqZWN0LmtleXMobWV0aG9kVG9Db2xvck1hcCk7XG4gICAgICBmb3IgKGNvbnN0IGtleSBvZiBsb2dnZXJNZXRob2RzKSB7XG4gICAgICAgIGNvbnN0IG1ldGhvZCA9IGtleTtcbiAgICAgICAgYXBpW21ldGhvZF0gPSAoLi4uYXJncykgPT4ge1xuICAgICAgICAgIHByaW50KG1ldGhvZCwgYXJncyk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4gYXBpO1xuICAgIH0pKCk7XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBtZXNzYWdlcyA9IHtcbiAgICAgICdpbnZhbGlkLXZhbHVlJzogKHtcbiAgICAgICAgcGFyYW1OYW1lLFxuICAgICAgICB2YWxpZFZhbHVlRGVzY3JpcHRpb24sXG4gICAgICAgIHZhbHVlXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghcGFyYW1OYW1lIHx8ICF2YWxpZFZhbHVlRGVzY3JpcHRpb24pIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ2ludmFsaWQtdmFsdWUnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgVGhlICcke3BhcmFtTmFtZX0nIHBhcmFtZXRlciB3YXMgZ2l2ZW4gYSB2YWx1ZSB3aXRoIGFuIGAgKyBgdW5leHBlY3RlZCB2YWx1ZS4gJHt2YWxpZFZhbHVlRGVzY3JpcHRpb259IFJlY2VpdmVkIGEgdmFsdWUgb2YgYCArIGAke0pTT04uc3RyaW5naWZ5KHZhbHVlKX0uYDtcbiAgICAgIH0sXG4gICAgICAnbm90LWFuLWFycmF5JzogKHtcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZSxcbiAgICAgICAgcGFyYW1OYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghbW9kdWxlTmFtZSB8fCAhY2xhc3NOYW1lIHx8ICFmdW5jTmFtZSB8fCAhcGFyYW1OYW1lKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdub3QtYW4tYXJyYXknIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgVGhlIHBhcmFtZXRlciAnJHtwYXJhbU5hbWV9JyBwYXNzZWQgaW50byBgICsgYCcke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lfS4ke2Z1bmNOYW1lfSgpJyBtdXN0IGJlIGFuIGFycmF5LmA7XG4gICAgICB9LFxuICAgICAgJ2luY29ycmVjdC10eXBlJzogKHtcbiAgICAgICAgZXhwZWN0ZWRUeXBlLFxuICAgICAgICBwYXJhbU5hbWUsXG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFleHBlY3RlZFR5cGUgfHwgIXBhcmFtTmFtZSB8fCAhbW9kdWxlTmFtZSB8fCAhZnVuY05hbWUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ2luY29ycmVjdC10eXBlJyBlcnJvci5gKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjbGFzc05hbWVTdHIgPSBjbGFzc05hbWUgPyBgJHtjbGFzc05hbWV9LmAgOiAnJztcbiAgICAgICAgcmV0dXJuIGBUaGUgcGFyYW1ldGVyICcke3BhcmFtTmFtZX0nIHBhc3NlZCBpbnRvIGAgKyBgJyR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWVTdHJ9YCArIGAke2Z1bmNOYW1lfSgpJyBtdXN0IGJlIG9mIHR5cGUgJHtleHBlY3RlZFR5cGV9LmA7XG4gICAgICB9LFxuICAgICAgJ2luY29ycmVjdC1jbGFzcyc6ICh7XG4gICAgICAgIGV4cGVjdGVkQ2xhc3NOYW1lLFxuICAgICAgICBwYXJhbU5hbWUsXG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWUsXG4gICAgICAgIGlzUmV0dXJuVmFsdWVQcm9ibGVtXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghZXhwZWN0ZWRDbGFzc05hbWUgfHwgIW1vZHVsZU5hbWUgfHwgIWZ1bmNOYW1lKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvICdpbmNvcnJlY3QtY2xhc3MnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNsYXNzTmFtZVN0ciA9IGNsYXNzTmFtZSA/IGAke2NsYXNzTmFtZX0uYCA6ICcnO1xuICAgICAgICBpZiAoaXNSZXR1cm5WYWx1ZVByb2JsZW0pIHtcbiAgICAgICAgICByZXR1cm4gYFRoZSByZXR1cm4gdmFsdWUgZnJvbSBgICsgYCcke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lU3RyfSR7ZnVuY05hbWV9KCknIGAgKyBgbXVzdCBiZSBhbiBpbnN0YW5jZSBvZiBjbGFzcyAke2V4cGVjdGVkQ2xhc3NOYW1lfS5gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgVGhlIHBhcmFtZXRlciAnJHtwYXJhbU5hbWV9JyBwYXNzZWQgaW50byBgICsgYCcke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lU3RyfSR7ZnVuY05hbWV9KCknIGAgKyBgbXVzdCBiZSBhbiBpbnN0YW5jZSBvZiBjbGFzcyAke2V4cGVjdGVkQ2xhc3NOYW1lfS5gO1xuICAgICAgfSxcbiAgICAgICdtaXNzaW5nLWEtbWV0aG9kJzogKHtcbiAgICAgICAgZXhwZWN0ZWRNZXRob2QsXG4gICAgICAgIHBhcmFtTmFtZSxcbiAgICAgICAgbW9kdWxlTmFtZSxcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICBmdW5jTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIWV4cGVjdGVkTWV0aG9kIHx8ICFwYXJhbU5hbWUgfHwgIW1vZHVsZU5hbWUgfHwgIWNsYXNzTmFtZSB8fCAhZnVuY05hbWUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ21pc3NpbmctYS1tZXRob2QnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZX0uJHtmdW5jTmFtZX0oKSBleHBlY3RlZCB0aGUgYCArIGAnJHtwYXJhbU5hbWV9JyBwYXJhbWV0ZXIgdG8gZXhwb3NlIGEgJyR7ZXhwZWN0ZWRNZXRob2R9JyBtZXRob2QuYDtcbiAgICAgIH0sXG4gICAgICAnYWRkLXRvLWNhY2hlLWxpc3QtdW5leHBlY3RlZC10eXBlJzogKHtcbiAgICAgICAgZW50cnlcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBBbiB1bmV4cGVjdGVkIGVudHJ5IHdhcyBwYXNzZWQgdG8gYCArIGAnd29ya2JveC1wcmVjYWNoaW5nLlByZWNhY2hlQ29udHJvbGxlci5hZGRUb0NhY2hlTGlzdCgpJyBUaGUgZW50cnkgYCArIGAnJHtKU09OLnN0cmluZ2lmeShlbnRyeSl9JyBpc24ndCBzdXBwb3J0ZWQuIFlvdSBtdXN0IHN1cHBseSBhbiBhcnJheSBvZiBgICsgYHN0cmluZ3Mgd2l0aCBvbmUgb3IgbW9yZSBjaGFyYWN0ZXJzLCBvYmplY3RzIHdpdGggYSB1cmwgcHJvcGVydHkgb3IgYCArIGBSZXF1ZXN0IG9iamVjdHMuYDtcbiAgICAgIH0sXG4gICAgICAnYWRkLXRvLWNhY2hlLWxpc3QtY29uZmxpY3RpbmctZW50cmllcyc6ICh7XG4gICAgICAgIGZpcnN0RW50cnksXG4gICAgICAgIHNlY29uZEVudHJ5XG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghZmlyc3RFbnRyeSB8fCAhc2Vjb25kRW50cnkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gYCArIGAnYWRkLXRvLWNhY2hlLWxpc3QtZHVwbGljYXRlLWVudHJpZXMnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgVHdvIG9mIHRoZSBlbnRyaWVzIHBhc3NlZCB0byBgICsgYCd3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVDb250cm9sbGVyLmFkZFRvQ2FjaGVMaXN0KCknIGhhZCB0aGUgVVJMIGAgKyBgJHtmaXJzdEVudHJ5fSBidXQgZGlmZmVyZW50IHJldmlzaW9uIGRldGFpbHMuIFdvcmtib3ggaXMgYCArIGB1bmFibGUgdG8gY2FjaGUgYW5kIHZlcnNpb24gdGhlIGFzc2V0IGNvcnJlY3RseS4gUGxlYXNlIHJlbW92ZSBvbmUgYCArIGBvZiB0aGUgZW50cmllcy5gO1xuICAgICAgfSxcbiAgICAgICdwbHVnaW4tZXJyb3ItcmVxdWVzdC13aWxsLWZldGNoJzogKHtcbiAgICAgICAgdGhyb3duRXJyb3JNZXNzYWdlXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghdGhyb3duRXJyb3JNZXNzYWdlKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIGlucHV0IHRvIGAgKyBgJ3BsdWdpbi1lcnJvci1yZXF1ZXN0LXdpbGwtZmV0Y2gnLCBlcnJvci5gKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYEFuIGVycm9yIHdhcyB0aHJvd24gYnkgYSBwbHVnaW5zICdyZXF1ZXN0V2lsbEZldGNoKCknIG1ldGhvZC4gYCArIGBUaGUgdGhyb3duIGVycm9yIG1lc3NhZ2Ugd2FzOiAnJHt0aHJvd25FcnJvck1lc3NhZ2V9Jy5gO1xuICAgICAgfSxcbiAgICAgICdpbnZhbGlkLWNhY2hlLW5hbWUnOiAoe1xuICAgICAgICBjYWNoZU5hbWVJZCxcbiAgICAgICAgdmFsdWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFjYWNoZU5hbWVJZCkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYSAnY2FjaGVOYW1lSWQnIGZvciBlcnJvciAnaW52YWxpZC1jYWNoZS1uYW1lJ2ApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgWW91IG11c3QgcHJvdmlkZSBhIG5hbWUgY29udGFpbmluZyBhdCBsZWFzdCBvbmUgY2hhcmFjdGVyIGZvciBgICsgYHNldENhY2hlRGV0YWlscyh7JHtjYWNoZU5hbWVJZH06ICcuLi4nfSkuIFJlY2VpdmVkIGEgdmFsdWUgb2YgYCArIGAnJHtKU09OLnN0cmluZ2lmeSh2YWx1ZSl9J2A7XG4gICAgICB9LFxuICAgICAgJ3VucmVnaXN0ZXItcm91dGUtYnV0LW5vdC1mb3VuZC13aXRoLW1ldGhvZCc6ICh7XG4gICAgICAgIG1ldGhvZFxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIW1ldGhvZCkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byBgICsgYCd1bnJlZ2lzdGVyLXJvdXRlLWJ1dC1ub3QtZm91bmQtd2l0aC1tZXRob2QnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgVGhlIHJvdXRlIHlvdSdyZSB0cnlpbmcgdG8gdW5yZWdpc3RlciB3YXMgbm90ICBwcmV2aW91c2x5IGAgKyBgcmVnaXN0ZXJlZCBmb3IgdGhlIG1ldGhvZCB0eXBlICcke21ldGhvZH0nLmA7XG4gICAgICB9LFxuICAgICAgJ3VucmVnaXN0ZXItcm91dGUtcm91dGUtbm90LXJlZ2lzdGVyZWQnOiAoKSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlIHJvdXRlIHlvdSdyZSB0cnlpbmcgdG8gdW5yZWdpc3RlciB3YXMgbm90IHByZXZpb3VzbHkgYCArIGByZWdpc3RlcmVkLmA7XG4gICAgICB9LFxuICAgICAgJ3F1ZXVlLXJlcGxheS1mYWlsZWQnOiAoe1xuICAgICAgICBuYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgUmVwbGF5aW5nIHRoZSBiYWNrZ3JvdW5kIHN5bmMgcXVldWUgJyR7bmFtZX0nIGZhaWxlZC5gO1xuICAgICAgfSxcbiAgICAgICdkdXBsaWNhdGUtcXVldWUtbmFtZSc6ICh7XG4gICAgICAgIG5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGUgUXVldWUgbmFtZSAnJHtuYW1lfScgaXMgYWxyZWFkeSBiZWluZyB1c2VkLiBgICsgYEFsbCBpbnN0YW5jZXMgb2YgYmFja2dyb3VuZFN5bmMuUXVldWUgbXVzdCBiZSBnaXZlbiB1bmlxdWUgbmFtZXMuYDtcbiAgICAgIH0sXG4gICAgICAnZXhwaXJlZC10ZXN0LXdpdGhvdXQtbWF4LWFnZSc6ICh7XG4gICAgICAgIG1ldGhvZE5hbWUsXG4gICAgICAgIHBhcmFtTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSAnJHttZXRob2ROYW1lfSgpJyBtZXRob2QgY2FuIG9ubHkgYmUgdXNlZCB3aGVuIHRoZSBgICsgYCcke3BhcmFtTmFtZX0nIGlzIHVzZWQgaW4gdGhlIGNvbnN0cnVjdG9yLmA7XG4gICAgICB9LFxuICAgICAgJ3Vuc3VwcG9ydGVkLXJvdXRlLXR5cGUnOiAoe1xuICAgICAgICBtb2R1bGVOYW1lLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICAgIGZ1bmNOYW1lLFxuICAgICAgICBwYXJhbU5hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGUgc3VwcGxpZWQgJyR7cGFyYW1OYW1lfScgcGFyYW1ldGVyIHdhcyBhbiB1bnN1cHBvcnRlZCB0eXBlLiBgICsgYFBsZWFzZSBjaGVjayB0aGUgZG9jcyBmb3IgJHttb2R1bGVOYW1lfS4ke2NsYXNzTmFtZX0uJHtmdW5jTmFtZX0gZm9yIGAgKyBgdmFsaWQgaW5wdXQgdHlwZXMuYDtcbiAgICAgIH0sXG4gICAgICAnbm90LWFycmF5LW9mLWNsYXNzJzogKHtcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIGV4cGVjdGVkQ2xhc3MsXG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWUsXG4gICAgICAgIHBhcmFtTmFtZVxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBzdXBwbGllZCAnJHtwYXJhbU5hbWV9JyBwYXJhbWV0ZXIgbXVzdCBiZSBhbiBhcnJheSBvZiBgICsgYCcke2V4cGVjdGVkQ2xhc3N9JyBvYmplY3RzLiBSZWNlaXZlZCAnJHtKU09OLnN0cmluZ2lmeSh2YWx1ZSl9LCcuIGAgKyBgUGxlYXNlIGNoZWNrIHRoZSBjYWxsIHRvICR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWV9LiR7ZnVuY05hbWV9KCkgYCArIGB0byBmaXggdGhlIGlzc3VlLmA7XG4gICAgICB9LFxuICAgICAgJ21heC1lbnRyaWVzLW9yLWFnZS1yZXF1aXJlZCc6ICh7XG4gICAgICAgIG1vZHVsZU5hbWUsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgZnVuY05hbWVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBkZWZpbmUgZWl0aGVyIGNvbmZpZy5tYXhFbnRyaWVzIG9yIGNvbmZpZy5tYXhBZ2VTZWNvbmRzYCArIGBpbiAke21vZHVsZU5hbWV9LiR7Y2xhc3NOYW1lfS4ke2Z1bmNOYW1lfWA7XG4gICAgICB9LFxuICAgICAgJ3N0YXR1c2VzLW9yLWhlYWRlcnMtcmVxdWlyZWQnOiAoe1xuICAgICAgICBtb2R1bGVOYW1lLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICAgIGZ1bmNOYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgWW91IG11c3QgZGVmaW5lIGVpdGhlciBjb25maWcuc3RhdHVzZXMgb3IgY29uZmlnLmhlYWRlcnNgICsgYGluICR7bW9kdWxlTmFtZX0uJHtjbGFzc05hbWV9LiR7ZnVuY05hbWV9YDtcbiAgICAgIH0sXG4gICAgICAnaW52YWxpZC1zdHJpbmcnOiAoe1xuICAgICAgICBtb2R1bGVOYW1lLFxuICAgICAgICBmdW5jTmFtZSxcbiAgICAgICAgcGFyYW1OYW1lXG4gICAgICB9KSA9PiB7XG4gICAgICAgIGlmICghcGFyYW1OYW1lIHx8ICFtb2R1bGVOYW1lIHx8ICFmdW5jTmFtZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnaW52YWxpZC1zdHJpbmcnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgV2hlbiB1c2luZyBzdHJpbmdzLCB0aGUgJyR7cGFyYW1OYW1lfScgcGFyYW1ldGVyIG11c3Qgc3RhcnQgd2l0aCBgICsgYCdodHRwJyAoZm9yIGNyb3NzLW9yaWdpbiBtYXRjaGVzKSBvciAnLycgKGZvciBzYW1lLW9yaWdpbiBtYXRjaGVzKS4gYCArIGBQbGVhc2Ugc2VlIHRoZSBkb2NzIGZvciAke21vZHVsZU5hbWV9LiR7ZnVuY05hbWV9KCkgZm9yIGAgKyBgbW9yZSBpbmZvLmA7XG4gICAgICB9LFxuICAgICAgJ2NoYW5uZWwtbmFtZS1yZXF1aXJlZCc6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGBZb3UgbXVzdCBwcm92aWRlIGEgY2hhbm5lbE5hbWUgdG8gY29uc3RydWN0IGEgYCArIGBCcm9hZGNhc3RDYWNoZVVwZGF0ZSBpbnN0YW5jZS5gO1xuICAgICAgfSxcbiAgICAgICdpbnZhbGlkLXJlc3BvbnNlcy1hcmUtc2FtZS1hcmdzJzogKCkgPT4ge1xuICAgICAgICByZXR1cm4gYFRoZSBhcmd1bWVudHMgcGFzc2VkIGludG8gcmVzcG9uc2VzQXJlU2FtZSgpIGFwcGVhciB0byBiZSBgICsgYGludmFsaWQuIFBsZWFzZSBlbnN1cmUgdmFsaWQgUmVzcG9uc2VzIGFyZSB1c2VkLmA7XG4gICAgICB9LFxuICAgICAgJ2V4cGlyZS1jdXN0b20tY2FjaGVzLW9ubHknOiAoKSA9PiB7XG4gICAgICAgIHJldHVybiBgWW91IG11c3QgcHJvdmlkZSBhICdjYWNoZU5hbWUnIHByb3BlcnR5IHdoZW4gdXNpbmcgdGhlIGAgKyBgZXhwaXJhdGlvbiBwbHVnaW4gd2l0aCBhIHJ1bnRpbWUgY2FjaGluZyBzdHJhdGVneS5gO1xuICAgICAgfSxcbiAgICAgICd1bml0LW11c3QtYmUtYnl0ZXMnOiAoe1xuICAgICAgICBub3JtYWxpemVkUmFuZ2VIZWFkZXJcbiAgICAgIH0pID0+IHtcbiAgICAgICAgaWYgKCFub3JtYWxpemVkUmFuZ2VIZWFkZXIpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgaW5wdXQgdG8gJ3VuaXQtbXVzdC1iZS1ieXRlcycgZXJyb3IuYCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGBUaGUgJ3VuaXQnIHBvcnRpb24gb2YgdGhlIFJhbmdlIGhlYWRlciBtdXN0IGJlIHNldCB0byAnYnl0ZXMnLiBgICsgYFRoZSBSYW5nZSBoZWFkZXIgcHJvdmlkZWQgd2FzIFwiJHtub3JtYWxpemVkUmFuZ2VIZWFkZXJ9XCJgO1xuICAgICAgfSxcbiAgICAgICdzaW5nbGUtcmFuZ2Utb25seSc6ICh7XG4gICAgICAgIG5vcm1hbGl6ZWRSYW5nZUhlYWRlclxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIW5vcm1hbGl6ZWRSYW5nZUhlYWRlcikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnc2luZ2xlLXJhbmdlLW9ubHknIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgTXVsdGlwbGUgcmFuZ2VzIGFyZSBub3Qgc3VwcG9ydGVkLiBQbGVhc2UgdXNlIGEgIHNpbmdsZSBzdGFydCBgICsgYHZhbHVlLCBhbmQgb3B0aW9uYWwgZW5kIHZhbHVlLiBUaGUgUmFuZ2UgaGVhZGVyIHByb3ZpZGVkIHdhcyBgICsgYFwiJHtub3JtYWxpemVkUmFuZ2VIZWFkZXJ9XCJgO1xuICAgICAgfSxcbiAgICAgICdpbnZhbGlkLXJhbmdlLXZhbHVlcyc6ICh7XG4gICAgICAgIG5vcm1hbGl6ZWRSYW5nZUhlYWRlclxuICAgICAgfSkgPT4ge1xuICAgICAgICBpZiAoIW5vcm1hbGl6ZWRSYW5nZUhlYWRlcikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCBpbnB1dCB0byAnaW52YWxpZC1yYW5nZS12YWx1ZXMnIGVycm9yLmApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgVGhlIFJhbmdlIGhlYWRlciBpcyBtaXNzaW5nIGJvdGggc3RhcnQgYW5kIGVuZCB2YWx1ZXMuIEF0IGxlYXN0IGAgKyBgb25lIG9mIHRob3NlIHZhbHVlcyBpcyBuZWVkZWQuIFRoZSBSYW5nZSBoZWFkZXIgcHJvdmlkZWQgd2FzIGAgKyBgXCIke25vcm1hbGl6ZWRSYW5nZUhlYWRlcn1cImA7XG4gICAgICB9LFxuICAgICAgJ25vLXJhbmdlLWhlYWRlcic6ICgpID0+IHtcbiAgICAgICAgcmV0dXJuIGBObyBSYW5nZSBoZWFkZXIgd2FzIGZvdW5kIGluIHRoZSBSZXF1ZXN0IHByb3ZpZGVkLmA7XG4gICAgICB9LFxuICAgICAgJ3JhbmdlLW5vdC1zYXRpc2ZpYWJsZSc6ICh7XG4gICAgICAgIHNpemUsXG4gICAgICAgIHN0YXJ0LFxuICAgICAgICBlbmRcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGUgc3RhcnQgKCR7c3RhcnR9KSBhbmQgZW5kICgke2VuZH0pIHZhbHVlcyBpbiB0aGUgUmFuZ2UgYXJlIGAgKyBgbm90IHNhdGlzZmlhYmxlIGJ5IHRoZSBjYWNoZWQgcmVzcG9uc2UsIHdoaWNoIGlzICR7c2l6ZX0gYnl0ZXMuYDtcbiAgICAgIH0sXG4gICAgICAnYXR0ZW1wdC10by1jYWNoZS1ub24tZ2V0LXJlcXVlc3QnOiAoe1xuICAgICAgICB1cmwsXG4gICAgICAgIG1ldGhvZFxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYFVuYWJsZSB0byBjYWNoZSAnJHt1cmx9JyBiZWNhdXNlIGl0IGlzIGEgJyR7bWV0aG9kfScgcmVxdWVzdCBhbmQgYCArIGBvbmx5ICdHRVQnIHJlcXVlc3RzIGNhbiBiZSBjYWNoZWQuYDtcbiAgICAgIH0sXG4gICAgICAnY2FjaGUtcHV0LXdpdGgtbm8tcmVzcG9uc2UnOiAoe1xuICAgICAgICB1cmxcbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGBUaGVyZSB3YXMgYW4gYXR0ZW1wdCB0byBjYWNoZSAnJHt1cmx9JyBidXQgdGhlIHJlc3BvbnNlIHdhcyBub3QgYCArIGBkZWZpbmVkLmA7XG4gICAgICB9LFxuICAgICAgJ25vLXJlc3BvbnNlJzogKHtcbiAgICAgICAgdXJsLFxuICAgICAgICBlcnJvclxuICAgICAgfSkgPT4ge1xuICAgICAgICBsZXQgbWVzc2FnZSA9IGBUaGUgc3RyYXRlZ3kgY291bGQgbm90IGdlbmVyYXRlIGEgcmVzcG9uc2UgZm9yICcke3VybH0nLmA7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgIG1lc3NhZ2UgKz0gYCBUaGUgdW5kZXJseWluZyBlcnJvciBpcyAke2Vycm9yfS5gO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgfSxcbiAgICAgICdiYWQtcHJlY2FjaGluZy1yZXNwb25zZSc6ICh7XG4gICAgICAgIHVybCxcbiAgICAgICAgc3RhdHVzXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVGhlIHByZWNhY2hpbmcgcmVxdWVzdCBmb3IgJyR7dXJsfScgZmFpbGVkYCArIChzdGF0dXMgPyBgIHdpdGggYW4gSFRUUCBzdGF0dXMgb2YgJHtzdGF0dXN9LmAgOiBgLmApO1xuICAgICAgfSxcbiAgICAgICdub24tcHJlY2FjaGVkLXVybCc6ICh7XG4gICAgICAgIHVybFxuICAgICAgfSkgPT4ge1xuICAgICAgICByZXR1cm4gYGNyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMKCcke3VybH0nKSB3YXMgY2FsbGVkLCBidXQgdGhhdCBVUkwgaXMgYCArIGBub3QgcHJlY2FjaGVkLiBQbGVhc2UgcGFzcyBpbiBhIFVSTCB0aGF0IGlzIHByZWNhY2hlZCBpbnN0ZWFkLmA7XG4gICAgICB9LFxuICAgICAgJ2FkZC10by1jYWNoZS1saXN0LWNvbmZsaWN0aW5nLWludGVncml0aWVzJzogKHtcbiAgICAgICAgdXJsXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVHdvIG9mIHRoZSBlbnRyaWVzIHBhc3NlZCB0byBgICsgYCd3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVDb250cm9sbGVyLmFkZFRvQ2FjaGVMaXN0KCknIGhhZCB0aGUgVVJMIGAgKyBgJHt1cmx9IHdpdGggZGlmZmVyZW50IGludGVncml0eSB2YWx1ZXMuIFBsZWFzZSByZW1vdmUgb25lIG9mIHRoZW0uYDtcbiAgICAgIH0sXG4gICAgICAnbWlzc2luZy1wcmVjYWNoZS1lbnRyeSc6ICh7XG4gICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgdXJsXG4gICAgICB9KSA9PiB7XG4gICAgICAgIHJldHVybiBgVW5hYmxlIHRvIGZpbmQgYSBwcmVjYWNoZWQgcmVzcG9uc2UgaW4gJHtjYWNoZU5hbWV9IGZvciAke3VybH0uYDtcbiAgICAgIH0sXG4gICAgICAnY3Jvc3Mtb3JpZ2luLWNvcHktcmVzcG9uc2UnOiAoe1xuICAgICAgICBvcmlnaW5cbiAgICAgIH0pID0+IHtcbiAgICAgICAgcmV0dXJuIGB3b3JrYm94LWNvcmUuY29weVJlc3BvbnNlKCkgY2FuIG9ubHkgYmUgdXNlZCB3aXRoIHNhbWUtb3JpZ2luIGAgKyBgcmVzcG9uc2VzLiBJdCB3YXMgcGFzc2VkIGEgcmVzcG9uc2Ugd2l0aCBvcmlnaW4gJHtvcmlnaW59LmA7XG4gICAgICB9LFxuICAgICAgJ29wYXF1ZS1zdHJlYW1zLXNvdXJjZSc6ICh7XG4gICAgICAgIHR5cGVcbiAgICAgIH0pID0+IHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGBPbmUgb2YgdGhlIHdvcmtib3gtc3RyZWFtcyBzb3VyY2VzIHJlc3VsdGVkIGluIGFuIGAgKyBgJyR7dHlwZX0nIHJlc3BvbnNlLmA7XG4gICAgICAgIGlmICh0eXBlID09PSAnb3BhcXVlcmVkaXJlY3QnKSB7XG4gICAgICAgICAgcmV0dXJuIGAke21lc3NhZ2V9IFBsZWFzZSBkbyBub3QgdXNlIGEgbmF2aWdhdGlvbiByZXF1ZXN0IHRoYXQgcmVzdWx0cyBgICsgYGluIGEgcmVkaXJlY3QgYXMgYSBzb3VyY2UuYDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYCR7bWVzc2FnZX0gUGxlYXNlIGVuc3VyZSB5b3VyIHNvdXJjZXMgYXJlIENPUlMtZW5hYmxlZC5gO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBnZW5lcmF0b3JGdW5jdGlvbiA9IChjb2RlLCBkZXRhaWxzID0ge30pID0+IHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSBtZXNzYWdlc1tjb2RlXTtcbiAgICAgIGlmICghbWVzc2FnZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuYWJsZSB0byBmaW5kIG1lc3NhZ2UgZm9yIGNvZGUgJyR7Y29kZX0nLmApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG1lc3NhZ2UoZGV0YWlscyk7XG4gICAgfTtcbiAgICBjb25zdCBtZXNzYWdlR2VuZXJhdG9yID0gZ2VuZXJhdG9yRnVuY3Rpb247XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBXb3JrYm94IGVycm9ycyBzaG91bGQgYmUgdGhyb3duIHdpdGggdGhpcyBjbGFzcy5cbiAgICAgKiBUaGlzIGFsbG93cyB1c2UgdG8gZW5zdXJlIHRoZSB0eXBlIGVhc2lseSBpbiB0ZXN0cyxcbiAgICAgKiBoZWxwcyBkZXZlbG9wZXJzIGlkZW50aWZ5IGVycm9ycyBmcm9tIHdvcmtib3hcbiAgICAgKiBlYXNpbHkgYW5kIGFsbG93cyB1c2UgdG8gb3B0aW1pc2UgZXJyb3JcbiAgICAgKiBtZXNzYWdlcyBjb3JyZWN0bHkuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNsYXNzIFdvcmtib3hFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICAgIC8qKlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBlcnJvckNvZGUgVGhlIGVycm9yIGNvZGUgdGhhdFxuICAgICAgICogaWRlbnRpZmllcyB0aGlzIHBhcnRpY3VsYXIgZXJyb3IuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdD19IGRldGFpbHMgQW55IHJlbGV2YW50IGFyZ3VtZW50c1xuICAgICAgICogdGhhdCB3aWxsIGhlbHAgZGV2ZWxvcGVycyBpZGVudGlmeSBpc3N1ZXMgc2hvdWxkXG4gICAgICAgKiBiZSBhZGRlZCBhcyBhIGtleSBvbiB0aGUgY29udGV4dCBvYmplY3QuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKGVycm9yQ29kZSwgZGV0YWlscykge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gbWVzc2FnZUdlbmVyYXRvcihlcnJvckNvZGUsIGRldGFpbHMpO1xuICAgICAgICBzdXBlcihtZXNzYWdlKTtcbiAgICAgICAgdGhpcy5uYW1lID0gZXJyb3JDb2RlO1xuICAgICAgICB0aGlzLmRldGFpbHMgPSBkZXRhaWxzO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qXG4gICAgICogVGhpcyBtZXRob2QgdGhyb3dzIGlmIHRoZSBzdXBwbGllZCB2YWx1ZSBpcyBub3QgYW4gYXJyYXkuXG4gICAgICogVGhlIGRlc3RydWN0ZWQgdmFsdWVzIGFyZSByZXF1aXJlZCB0byBwcm9kdWNlIGEgbWVhbmluZ2Z1bCBlcnJvciBmb3IgdXNlcnMuXG4gICAgICogVGhlIGRlc3RydWN0ZWQgYW5kIHJlc3RydWN0dXJlZCBvYmplY3QgaXMgc28gaXQncyBjbGVhciB3aGF0IGlzXG4gICAgICogbmVlZGVkLlxuICAgICAqL1xuICAgIGNvbnN0IGlzQXJyYXkgPSAodmFsdWUsIGRldGFpbHMpID0+IHtcbiAgICAgIGlmICghQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignbm90LWFuLWFycmF5JywgZGV0YWlscyk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBoYXNNZXRob2QgPSAob2JqZWN0LCBleHBlY3RlZE1ldGhvZCwgZGV0YWlscykgPT4ge1xuICAgICAgY29uc3QgdHlwZSA9IHR5cGVvZiBvYmplY3RbZXhwZWN0ZWRNZXRob2RdO1xuICAgICAgaWYgKHR5cGUgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgZGV0YWlsc1snZXhwZWN0ZWRNZXRob2QnXSA9IGV4cGVjdGVkTWV0aG9kO1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdtaXNzaW5nLWEtbWV0aG9kJywgZGV0YWlscyk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBpc1R5cGUgPSAob2JqZWN0LCBleHBlY3RlZFR5cGUsIGRldGFpbHMpID0+IHtcbiAgICAgIGlmICh0eXBlb2Ygb2JqZWN0ICE9PSBleHBlY3RlZFR5cGUpIHtcbiAgICAgICAgZGV0YWlsc1snZXhwZWN0ZWRUeXBlJ10gPSBleHBlY3RlZFR5cGU7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2luY29ycmVjdC10eXBlJywgZGV0YWlscyk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBpc0luc3RhbmNlID0gKG9iamVjdCxcbiAgICAvLyBOZWVkIHRoZSBnZW5lcmFsIHR5cGUgdG8gZG8gdGhlIGNoZWNrIGxhdGVyLlxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXR5cGVzXG4gICAgZXhwZWN0ZWRDbGFzcywgZGV0YWlscykgPT4ge1xuICAgICAgaWYgKCEob2JqZWN0IGluc3RhbmNlb2YgZXhwZWN0ZWRDbGFzcykpIHtcbiAgICAgICAgZGV0YWlsc1snZXhwZWN0ZWRDbGFzc05hbWUnXSA9IGV4cGVjdGVkQ2xhc3MubmFtZTtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignaW5jb3JyZWN0LWNsYXNzJywgZGV0YWlscyk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBpc09uZU9mID0gKHZhbHVlLCB2YWxpZFZhbHVlcywgZGV0YWlscykgPT4ge1xuICAgICAgaWYgKCF2YWxpZFZhbHVlcy5pbmNsdWRlcyh2YWx1ZSkpIHtcbiAgICAgICAgZGV0YWlsc1sndmFsaWRWYWx1ZURlc2NyaXB0aW9uJ10gPSBgVmFsaWQgdmFsdWVzIGFyZSAke0pTT04uc3RyaW5naWZ5KHZhbGlkVmFsdWVzKX0uYDtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignaW52YWxpZC12YWx1ZScsIGRldGFpbHMpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgaXNBcnJheU9mQ2xhc3MgPSAodmFsdWUsXG4gICAgLy8gTmVlZCBnZW5lcmFsIHR5cGUgdG8gZG8gY2hlY2sgbGF0ZXIuXG4gICAgZXhwZWN0ZWRDbGFzcyxcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgZGV0YWlscykgPT4ge1xuICAgICAgY29uc3QgZXJyb3IgPSBuZXcgV29ya2JveEVycm9yKCdub3QtYXJyYXktb2YtY2xhc3MnLCBkZXRhaWxzKTtcbiAgICAgIGlmICghQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgdmFsdWUpIHtcbiAgICAgICAgaWYgKCEoaXRlbSBpbnN0YW5jZW9mIGV4cGVjdGVkQ2xhc3MpKSB7XG4gICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGZpbmFsQXNzZXJ0RXhwb3J0cyA9IHtcbiAgICAgIGhhc01ldGhvZCxcbiAgICAgIGlzQXJyYXksXG4gICAgICBpc0luc3RhbmNlLFxuICAgICAgaXNPbmVPZixcbiAgICAgIGlzVHlwZSxcbiAgICAgIGlzQXJyYXlPZkNsYXNzXG4gICAgfTtcblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB0cnkge1xuICAgICAgc2VsZlsnd29ya2JveDpyb3V0aW5nOjcuNC4wJ10gJiYgXygpO1xuICAgIH0gY2F0Y2ggKGUpIHt9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBUaGUgZGVmYXVsdCBIVFRQIG1ldGhvZCwgJ0dFVCcsIHVzZWQgd2hlbiB0aGVyZSdzIG5vIHNwZWNpZmljIG1ldGhvZFxuICAgICAqIGNvbmZpZ3VyZWQgZm9yIGEgcm91dGUuXG4gICAgICpcbiAgICAgKiBAdHlwZSB7c3RyaW5nfVxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjb25zdCBkZWZhdWx0TWV0aG9kID0gJ0dFVCc7XG4gICAgLyoqXG4gICAgICogVGhlIGxpc3Qgb2YgdmFsaWQgSFRUUCBtZXRob2RzIGFzc29jaWF0ZWQgd2l0aCByZXF1ZXN0cyB0aGF0IGNvdWxkIGJlIHJvdXRlZC5cbiAgICAgKlxuICAgICAqIEB0eXBlIHtBcnJheTxzdHJpbmc+fVxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjb25zdCB2YWxpZE1ldGhvZHMgPSBbJ0RFTEVURScsICdHRVQnLCAnSEVBRCcsICdQQVRDSCcsICdQT1NUJywgJ1BVVCddO1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtmdW5jdGlvbigpfE9iamVjdH0gaGFuZGxlciBFaXRoZXIgYSBmdW5jdGlvbiwgb3IgYW4gb2JqZWN0IHdpdGggYVxuICAgICAqICdoYW5kbGUnIG1ldGhvZC5cbiAgICAgKiBAcmV0dXJuIHtPYmplY3R9IEFuIG9iamVjdCB3aXRoIGEgaGFuZGxlIG1ldGhvZC5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY29uc3Qgbm9ybWFsaXplSGFuZGxlciA9IGhhbmRsZXIgPT4ge1xuICAgICAgaWYgKGhhbmRsZXIgJiYgdHlwZW9mIGhhbmRsZXIgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaGFzTWV0aG9kKGhhbmRsZXIsICdoYW5kbGUnLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnaGFuZGxlcidcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaGFuZGxlcjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNUeXBlKGhhbmRsZXIsICdmdW5jdGlvbicsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGUnLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdoYW5kbGVyJ1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgaGFuZGxlOiBoYW5kbGVyXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEgYFJvdXRlYCBjb25zaXN0cyBvZiBhIHBhaXIgb2YgY2FsbGJhY2sgZnVuY3Rpb25zLCBcIm1hdGNoXCIgYW5kIFwiaGFuZGxlclwiLlxuICAgICAqIFRoZSBcIm1hdGNoXCIgY2FsbGJhY2sgZGV0ZXJtaW5lIGlmIGEgcm91dGUgc2hvdWxkIGJlIHVzZWQgdG8gXCJoYW5kbGVcIiBhXG4gICAgICogcmVxdWVzdCBieSByZXR1cm5pbmcgYSBub24tZmFsc3kgdmFsdWUgaWYgaXQgY2FuLiBUaGUgXCJoYW5kbGVyXCIgY2FsbGJhY2tcbiAgICAgKiBpcyBjYWxsZWQgd2hlbiB0aGVyZSBpcyBhIG1hdGNoIGFuZCBzaG91bGQgcmV0dXJuIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzXG4gICAgICogdG8gYSBgUmVzcG9uc2VgLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcm91dGluZ1xuICAgICAqL1xuICAgIGNsYXNzIFJvdXRlIHtcbiAgICAgIC8qKlxuICAgICAgICogQ29uc3RydWN0b3IgZm9yIFJvdXRlIGNsYXNzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nfm1hdGNoQ2FsbGJhY2t9IG1hdGNoXG4gICAgICAgKiBBIGNhbGxiYWNrIGZ1bmN0aW9uIHRoYXQgZGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSByb3V0ZSBtYXRjaGVzIGEgZ2l2ZW5cbiAgICAgICAqIGBmZXRjaGAgZXZlbnQgYnkgcmV0dXJuaW5nIGEgbm9uLWZhbHN5IHZhbHVlLlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfSBoYW5kbGVyIEEgY2FsbGJhY2tcbiAgICAgICAqIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UgcmVzb2x2aW5nIHRvIGEgUmVzcG9uc2UuXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gW21ldGhvZD0nR0VUJ10gVGhlIEhUVFAgbWV0aG9kIHRvIG1hdGNoIHRoZSBSb3V0ZVxuICAgICAgICogYWdhaW5zdC5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IobWF0Y2gsIGhhbmRsZXIsIG1ldGhvZCA9IGRlZmF1bHRNZXRob2QpIHtcbiAgICAgICAge1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUobWF0Y2gsICdmdW5jdGlvbicsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGUnLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdjb25zdHJ1Y3RvcicsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdtYXRjaCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZiAobWV0aG9kKSB7XG4gICAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNPbmVPZihtZXRob2QsIHZhbGlkTWV0aG9kcywge1xuICAgICAgICAgICAgICBwYXJhbU5hbWU6ICdtZXRob2QnXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gVGhlc2UgdmFsdWVzIGFyZSByZWZlcmVuY2VkIGRpcmVjdGx5IGJ5IFJvdXRlciBzbyBjYW5ub3QgYmVcbiAgICAgICAgLy8gYWx0ZXJlZCBieSBtaW5pZmljYXRvbi5cbiAgICAgICAgdGhpcy5oYW5kbGVyID0gbm9ybWFsaXplSGFuZGxlcihoYW5kbGVyKTtcbiAgICAgICAgdGhpcy5tYXRjaCA9IG1hdGNoO1xuICAgICAgICB0aGlzLm1ldGhvZCA9IG1ldGhvZDtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nLWhhbmRsZXJDYWxsYmFja30gaGFuZGxlciBBIGNhbGxiYWNrXG4gICAgICAgKiBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlIHJlc29sdmluZyB0byBhIFJlc3BvbnNlXG4gICAgICAgKi9cbiAgICAgIHNldENhdGNoSGFuZGxlcihoYW5kbGVyKSB7XG4gICAgICAgIHRoaXMuY2F0Y2hIYW5kbGVyID0gbm9ybWFsaXplSGFuZGxlcihoYW5kbGVyKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBSZWdFeHBSb3V0ZSBtYWtlcyBpdCBlYXN5IHRvIGNyZWF0ZSBhIHJlZ3VsYXIgZXhwcmVzc2lvbiBiYXNlZFxuICAgICAqIHtAbGluayB3b3JrYm94LXJvdXRpbmcuUm91dGV9LlxuICAgICAqXG4gICAgICogRm9yIHNhbWUtb3JpZ2luIHJlcXVlc3RzIHRoZSBSZWdFeHAgb25seSBuZWVkcyB0byBtYXRjaCBwYXJ0IG9mIHRoZSBVUkwuIEZvclxuICAgICAqIHJlcXVlc3RzIGFnYWluc3QgdGhpcmQtcGFydHkgc2VydmVycywgeW91IG11c3QgZGVmaW5lIGEgUmVnRXhwIHRoYXQgbWF0Y2hlc1xuICAgICAqIHRoZSBzdGFydCBvZiB0aGUgVVJMLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcm91dGluZ1xuICAgICAqIEBleHRlbmRzIHdvcmtib3gtcm91dGluZy5Sb3V0ZVxuICAgICAqL1xuICAgIGNsYXNzIFJlZ0V4cFJvdXRlIGV4dGVuZHMgUm91dGUge1xuICAgICAgLyoqXG4gICAgICAgKiBJZiB0aGUgcmVndWxhciBleHByZXNzaW9uIGNvbnRhaW5zXG4gICAgICAgKiBbY2FwdHVyZSBncm91cHNde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL1JlZ0V4cCNncm91cGluZy1iYWNrLXJlZmVyZW5jZXN9LFxuICAgICAgICogdGhlIGNhcHR1cmVkIHZhbHVlcyB3aWxsIGJlIHBhc3NlZCB0byB0aGVcbiAgICAgICAqIHtAbGluayB3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfSBgcGFyYW1zYFxuICAgICAgICogYXJndW1lbnQuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtSZWdFeHB9IHJlZ0V4cCBUaGUgcmVndWxhciBleHByZXNzaW9uIHRvIG1hdGNoIGFnYWluc3QgVVJMcy5cbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja30gaGFuZGxlciBBIGNhbGxiYWNrXG4gICAgICAgKiBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlIHJlc3VsdGluZyBpbiBhIFJlc3BvbnNlLlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFttZXRob2Q9J0dFVCddIFRoZSBIVFRQIG1ldGhvZCB0byBtYXRjaCB0aGUgUm91dGVcbiAgICAgICAqIGFnYWluc3QuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKHJlZ0V4cCwgaGFuZGxlciwgbWV0aG9kKSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNJbnN0YW5jZShyZWdFeHAsIFJlZ0V4cCwge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSZWdFeHBSb3V0ZScsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2NvbnN0cnVjdG9yJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ3BhdHRlcm4nXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbWF0Y2ggPSAoe1xuICAgICAgICAgIHVybFxuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gcmVnRXhwLmV4ZWModXJsLmhyZWYpO1xuICAgICAgICAgIC8vIFJldHVybiBpbW1lZGlhdGVseSBpZiB0aGVyZSdzIG5vIG1hdGNoLlxuICAgICAgICAgIGlmICghcmVzdWx0KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIFJlcXVpcmUgdGhhdCB0aGUgbWF0Y2ggc3RhcnQgYXQgdGhlIGZpcnN0IGNoYXJhY3RlciBpbiB0aGUgVVJMIHN0cmluZ1xuICAgICAgICAgIC8vIGlmIGl0J3MgYSBjcm9zcy1vcmlnaW4gcmVxdWVzdC5cbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yODEgZm9yIHRoZSBjb250ZXh0XG4gICAgICAgICAgLy8gYmVoaW5kIHRoaXMgYmVoYXZpb3IuXG4gICAgICAgICAgaWYgKHVybC5vcmlnaW4gIT09IGxvY2F0aW9uLm9yaWdpbiAmJiByZXN1bHQuaW5kZXggIT09IDApIHtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBUaGUgcmVndWxhciBleHByZXNzaW9uICcke3JlZ0V4cC50b1N0cmluZygpfScgb25seSBwYXJ0aWFsbHkgbWF0Y2hlZCBgICsgYGFnYWluc3QgdGhlIGNyb3NzLW9yaWdpbiBVUkwgJyR7dXJsLnRvU3RyaW5nKCl9Jy4gUmVnRXhwUm91dGUncyB3aWxsIG9ubHkgYCArIGBoYW5kbGUgY3Jvc3Mtb3JpZ2luIHJlcXVlc3RzIGlmIHRoZXkgbWF0Y2ggdGhlIGVudGlyZSBVUkwuYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIElmIHRoZSByb3V0ZSBtYXRjaGVzLCBidXQgdGhlcmUgYXJlbid0IGFueSBjYXB0dXJlIGdyb3VwcyBkZWZpbmVkLCB0aGVuXG4gICAgICAgICAgLy8gdGhpcyB3aWxsIHJldHVybiBbXSwgd2hpY2ggaXMgdHJ1dGh5IGFuZCB0aGVyZWZvcmUgc3VmZmljaWVudCB0b1xuICAgICAgICAgIC8vIGluZGljYXRlIGEgbWF0Y2guXG4gICAgICAgICAgLy8gSWYgdGhlcmUgYXJlIGNhcHR1cmUgZ3JvdXBzLCB0aGVuIGl0IHdpbGwgcmV0dXJuIHRoZWlyIHZhbHVlcy5cbiAgICAgICAgICByZXR1cm4gcmVzdWx0LnNsaWNlKDEpO1xuICAgICAgICB9O1xuICAgICAgICBzdXBlcihtYXRjaCwgaGFuZGxlciwgbWV0aG9kKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBnZXRGcmllbmRseVVSTCA9IHVybCA9PiB7XG4gICAgICBjb25zdCB1cmxPYmogPSBuZXcgVVJMKFN0cmluZyh1cmwpLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzIzMjNcbiAgICAgIC8vIFdlIHdhbnQgdG8gaW5jbHVkZSBldmVyeXRoaW5nLCBleGNlcHQgZm9yIHRoZSBvcmlnaW4gaWYgaXQncyBzYW1lLW9yaWdpbi5cbiAgICAgIHJldHVybiB1cmxPYmouaHJlZi5yZXBsYWNlKG5ldyBSZWdFeHAoYF4ke2xvY2F0aW9uLm9yaWdpbn1gKSwgJycpO1xuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBUaGUgUm91dGVyIGNhbiBiZSB1c2VkIHRvIHByb2Nlc3MgYSBgRmV0Y2hFdmVudGAgdXNpbmcgb25lIG9yIG1vcmVcbiAgICAgKiB7QGxpbmsgd29ya2JveC1yb3V0aW5nLlJvdXRlfSwgcmVzcG9uZGluZyB3aXRoIGEgYFJlc3BvbnNlYCBpZlxuICAgICAqIGEgbWF0Y2hpbmcgcm91dGUgZXhpc3RzLlxuICAgICAqXG4gICAgICogSWYgbm8gcm91dGUgbWF0Y2hlcyBhIGdpdmVuIGEgcmVxdWVzdCwgdGhlIFJvdXRlciB3aWxsIHVzZSBhIFwiZGVmYXVsdFwiXG4gICAgICogaGFuZGxlciBpZiBvbmUgaXMgZGVmaW5lZC5cbiAgICAgKlxuICAgICAqIFNob3VsZCB0aGUgbWF0Y2hpbmcgUm91dGUgdGhyb3cgYW4gZXJyb3IsIHRoZSBSb3V0ZXIgd2lsbCB1c2UgYSBcImNhdGNoXCJcbiAgICAgKiBoYW5kbGVyIGlmIG9uZSBpcyBkZWZpbmVkIHRvIGdyYWNlZnVsbHkgZGVhbCB3aXRoIGlzc3VlcyBhbmQgcmVzcG9uZCB3aXRoIGFcbiAgICAgKiBSZXF1ZXN0LlxuICAgICAqXG4gICAgICogSWYgYSByZXF1ZXN0IG1hdGNoZXMgbXVsdGlwbGUgcm91dGVzLCB0aGUgKiplYXJsaWVzdCoqIHJlZ2lzdGVyZWQgcm91dGUgd2lsbFxuICAgICAqIGJlIHVzZWQgdG8gcmVzcG9uZCB0byB0aGUgcmVxdWVzdC5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXJvdXRpbmdcbiAgICAgKi9cbiAgICBjbGFzcyBSb3V0ZXIge1xuICAgICAgLyoqXG4gICAgICAgKiBJbml0aWFsaXplcyBhIG5ldyBSb3V0ZXIuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLl9yb3V0ZXMgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMuX2RlZmF1bHRIYW5kbGVyTWFwID0gbmV3IE1hcCgpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBAcmV0dXJuIHtNYXA8c3RyaW5nLCBBcnJheTx3b3JrYm94LXJvdXRpbmcuUm91dGU+Pn0gcm91dGVzIEEgYE1hcGAgb2YgSFRUUFxuICAgICAgICogbWV0aG9kIG5hbWUgKCdHRVQnLCBldGMuKSB0byBhbiBhcnJheSBvZiBhbGwgdGhlIGNvcnJlc3BvbmRpbmcgYFJvdXRlYFxuICAgICAgICogaW5zdGFuY2VzIHRoYXQgYXJlIHJlZ2lzdGVyZWQuXG4gICAgICAgKi9cbiAgICAgIGdldCByb3V0ZXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yb3V0ZXM7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEFkZHMgYSBmZXRjaCBldmVudCBsaXN0ZW5lciB0byByZXNwb25kIHRvIGV2ZW50cyB3aGVuIGEgcm91dGUgbWF0Y2hlc1xuICAgICAgICogdGhlIGV2ZW50J3MgcmVxdWVzdC5cbiAgICAgICAqL1xuICAgICAgYWRkRmV0Y2hMaXN0ZW5lcigpIHtcbiAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9NaWNyb3NvZnQvVHlwZVNjcmlwdC9pc3N1ZXMvMjgzNTcjaXNzdWVjb21tZW50LTQzNjQ4NDcwNVxuICAgICAgICBzZWxmLmFkZEV2ZW50TGlzdGVuZXIoJ2ZldGNoJywgZXZlbnQgPT4ge1xuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICB9ID0gZXZlbnQ7XG4gICAgICAgICAgY29uc3QgcmVzcG9uc2VQcm9taXNlID0gdGhpcy5oYW5kbGVSZXF1ZXN0KHtcbiAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICBldmVudFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChyZXNwb25zZVByb21pc2UpIHtcbiAgICAgICAgICAgIGV2ZW50LnJlc3BvbmRXaXRoKHJlc3BvbnNlUHJvbWlzZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQWRkcyBhIG1lc3NhZ2UgZXZlbnQgbGlzdGVuZXIgZm9yIFVSTHMgdG8gY2FjaGUgZnJvbSB0aGUgd2luZG93LlxuICAgICAgICogVGhpcyBpcyB1c2VmdWwgdG8gY2FjaGUgcmVzb3VyY2VzIGxvYWRlZCBvbiB0aGUgcGFnZSBwcmlvciB0byB3aGVuIHRoZVxuICAgICAgICogc2VydmljZSB3b3JrZXIgc3RhcnRlZCBjb250cm9sbGluZyBpdC5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgZm9ybWF0IG9mIHRoZSBtZXNzYWdlIGRhdGEgc2VudCBmcm9tIHRoZSB3aW5kb3cgc2hvdWxkIGJlIGFzIGZvbGxvd3MuXG4gICAgICAgKiBXaGVyZSB0aGUgYHVybHNUb0NhY2hlYCBhcnJheSBtYXkgY29uc2lzdCBvZiBVUkwgc3RyaW5ncyBvciBhbiBhcnJheSBvZlxuICAgICAgICogVVJMIHN0cmluZyArIGByZXF1ZXN0SW5pdGAgb2JqZWN0ICh0aGUgc2FtZSBhcyB5b3UnZCBwYXNzIHRvIGBmZXRjaCgpYCkuXG4gICAgICAgKlxuICAgICAgICogYGBgXG4gICAgICAgKiB7XG4gICAgICAgKiAgIHR5cGU6ICdDQUNIRV9VUkxTJyxcbiAgICAgICAqICAgcGF5bG9hZDoge1xuICAgICAgICogICAgIHVybHNUb0NhY2hlOiBbXG4gICAgICAgKiAgICAgICAnLi9zY3JpcHQxLmpzJyxcbiAgICAgICAqICAgICAgICcuL3NjcmlwdDIuanMnLFxuICAgICAgICogICAgICAgWycuL3NjcmlwdDMuanMnLCB7bW9kZTogJ25vLWNvcnMnfV0sXG4gICAgICAgKiAgICAgXSxcbiAgICAgICAqICAgfSxcbiAgICAgICAqIH1cbiAgICAgICAqIGBgYFxuICAgICAgICovXG4gICAgICBhZGRDYWNoZUxpc3RlbmVyKCkge1xuICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL01pY3Jvc29mdC9UeXBlU2NyaXB0L2lzc3Vlcy8yODM1NyNpc3N1ZWNvbW1lbnQtNDM2NDg0NzA1XG4gICAgICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIGV2ZW50ID0+IHtcbiAgICAgICAgICAvLyBldmVudC5kYXRhIGlzIHR5cGUgJ2FueSdcbiAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1tZW1iZXItYWNjZXNzXG4gICAgICAgICAgaWYgKGV2ZW50LmRhdGEgJiYgZXZlbnQuZGF0YS50eXBlID09PSAnQ0FDSEVfVVJMUycpIHtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLWFzc2lnbm1lbnRcbiAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAgcGF5bG9hZFxuICAgICAgICAgICAgfSA9IGV2ZW50LmRhdGE7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgQ2FjaGluZyBVUkxzIGZyb20gdGhlIHdpbmRvd2AsIHBheWxvYWQudXJsc1RvQ2FjaGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcmVxdWVzdFByb21pc2VzID0gUHJvbWlzZS5hbGwocGF5bG9hZC51cmxzVG9DYWNoZS5tYXAoZW50cnkgPT4ge1xuICAgICAgICAgICAgICBpZiAodHlwZW9mIGVudHJ5ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgIGVudHJ5ID0gW2VudHJ5XTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjb25zdCByZXF1ZXN0ID0gbmV3IFJlcXVlc3QoLi4uZW50cnkpO1xuICAgICAgICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVSZXF1ZXN0KHtcbiAgICAgICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgICAgIGV2ZW50XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAvLyBUT0RPKHBoaWxpcHdhbHRvbik6IFR5cGVTY3JpcHQgZXJyb3JzIHdpdGhvdXQgdGhpcyB0eXBlY2FzdCBmb3JcbiAgICAgICAgICAgICAgLy8gc29tZSByZWFzb24gKHByb2JhYmx5IGEgYnVnKS4gVGhlIHJlYWwgdHlwZSBoZXJlIHNob3VsZCB3b3JrIGJ1dFxuICAgICAgICAgICAgICAvLyBkb2Vzbid0OiBgQXJyYXk8UHJvbWlzZTxSZXNwb25zZT4gfCB1bmRlZmluZWQ+YC5cbiAgICAgICAgICAgIH0pKTsgLy8gVHlwZVNjcmlwdFxuICAgICAgICAgICAgZXZlbnQud2FpdFVudGlsKHJlcXVlc3RQcm9taXNlcyk7XG4gICAgICAgICAgICAvLyBJZiBhIE1lc3NhZ2VDaGFubmVsIHdhcyB1c2VkLCByZXBseSB0byB0aGUgbWVzc2FnZSBvbiBzdWNjZXNzLlxuICAgICAgICAgICAgaWYgKGV2ZW50LnBvcnRzICYmIGV2ZW50LnBvcnRzWzBdKSB7XG4gICAgICAgICAgICAgIHZvaWQgcmVxdWVzdFByb21pc2VzLnRoZW4oKCkgPT4gZXZlbnQucG9ydHNbMF0ucG9zdE1lc3NhZ2UodHJ1ZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEFwcGx5IHRoZSByb3V0aW5nIHJ1bGVzIHRvIGEgRmV0Y2hFdmVudCBvYmplY3QgdG8gZ2V0IGEgUmVzcG9uc2UgZnJvbSBhblxuICAgICAgICogYXBwcm9wcmlhdGUgUm91dGUncyBoYW5kbGVyLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IG9wdGlvbnMucmVxdWVzdCBUaGUgcmVxdWVzdCB0byBoYW5kbGUuXG4gICAgICAgKiBAcGFyYW0ge0V4dGVuZGFibGVFdmVudH0gb3B0aW9ucy5ldmVudCBUaGUgZXZlbnQgdGhhdCB0cmlnZ2VyZWQgdGhlXG4gICAgICAgKiAgICAgcmVxdWVzdC5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2U+fHVuZGVmaW5lZH0gQSBwcm9taXNlIGlzIHJldHVybmVkIGlmIGFcbiAgICAgICAqICAgICByZWdpc3RlcmVkIHJvdXRlIGNhbiBoYW5kbGUgdGhlIHJlcXVlc3QuIElmIHRoZXJlIGlzIG5vIG1hdGNoaW5nXG4gICAgICAgKiAgICAgcm91dGUgYW5kIHRoZXJlJ3Mgbm8gYGRlZmF1bHRIYW5kbGVyYCwgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG4gICAgICAgKi9cbiAgICAgIGhhbmRsZVJlcXVlc3Qoe1xuICAgICAgICByZXF1ZXN0LFxuICAgICAgICBldmVudFxuICAgICAgfSkge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzSW5zdGFuY2UocmVxdWVzdCwgUmVxdWVzdCwge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdoYW5kbGVSZXF1ZXN0JyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ29wdGlvbnMucmVxdWVzdCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJlcXVlc3QudXJsLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgaWYgKCF1cmwucHJvdG9jb2wuc3RhcnRzV2l0aCgnaHR0cCcpKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBXb3JrYm94IFJvdXRlciBvbmx5IHN1cHBvcnRzIFVSTHMgdGhhdCBzdGFydCB3aXRoICdodHRwJy5gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNhbWVPcmlnaW4gPSB1cmwub3JpZ2luID09PSBsb2NhdGlvbi5vcmlnaW47XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBwYXJhbXMsXG4gICAgICAgICAgcm91dGVcbiAgICAgICAgfSA9IHRoaXMuZmluZE1hdGNoaW5nUm91dGUoe1xuICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgc2FtZU9yaWdpbixcbiAgICAgICAgICB1cmxcbiAgICAgICAgfSk7XG4gICAgICAgIGxldCBoYW5kbGVyID0gcm91dGUgJiYgcm91dGUuaGFuZGxlcjtcbiAgICAgICAgY29uc3QgZGVidWdNZXNzYWdlcyA9IFtdO1xuICAgICAgICB7XG4gICAgICAgICAgaWYgKGhhbmRsZXIpIHtcbiAgICAgICAgICAgIGRlYnVnTWVzc2FnZXMucHVzaChbYEZvdW5kIGEgcm91dGUgdG8gaGFuZGxlIHRoaXMgcmVxdWVzdDpgLCByb3V0ZV0pO1xuICAgICAgICAgICAgaWYgKHBhcmFtcykge1xuICAgICAgICAgICAgICBkZWJ1Z01lc3NhZ2VzLnB1c2goW2BQYXNzaW5nIHRoZSBmb2xsb3dpbmcgcGFyYW1zIHRvIHRoZSByb3V0ZSdzIGhhbmRsZXI6YCwgcGFyYW1zXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIElmIHdlIGRvbid0IGhhdmUgYSBoYW5kbGVyIGJlY2F1c2UgdGhlcmUgd2FzIG5vIG1hdGNoaW5nIHJvdXRlLCB0aGVuXG4gICAgICAgIC8vIGZhbGwgYmFjayB0byBkZWZhdWx0SGFuZGxlciBpZiB0aGF0J3MgZGVmaW5lZC5cbiAgICAgICAgY29uc3QgbWV0aG9kID0gcmVxdWVzdC5tZXRob2Q7XG4gICAgICAgIGlmICghaGFuZGxlciAmJiB0aGlzLl9kZWZhdWx0SGFuZGxlck1hcC5oYXMobWV0aG9kKSkge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGRlYnVnTWVzc2FnZXMucHVzaChgRmFpbGVkIHRvIGZpbmQgYSBtYXRjaGluZyByb3V0ZS4gRmFsbGluZyBgICsgYGJhY2sgdG8gdGhlIGRlZmF1bHQgaGFuZGxlciBmb3IgJHttZXRob2R9LmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBoYW5kbGVyID0gdGhpcy5fZGVmYXVsdEhhbmRsZXJNYXAuZ2V0KG1ldGhvZCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFoYW5kbGVyKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgLy8gTm8gaGFuZGxlciBzbyBXb3JrYm94IHdpbGwgZG8gbm90aGluZy4gSWYgbG9ncyBpcyBzZXQgb2YgZGVidWdcbiAgICAgICAgICAgIC8vIGkuZS4gdmVyYm9zZSwgd2Ugc2hvdWxkIHByaW50IG91dCB0aGlzIGluZm9ybWF0aW9uLlxuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBObyByb3V0ZSBmb3VuZCBmb3I6ICR7Z2V0RnJpZW5kbHlVUkwodXJsKX1gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICAvLyBXZSBoYXZlIGEgaGFuZGxlciwgbWVhbmluZyBXb3JrYm94IGlzIGdvaW5nIHRvIGhhbmRsZSB0aGUgcm91dGUuXG4gICAgICAgICAgLy8gcHJpbnQgdGhlIHJvdXRpbmcgZGV0YWlscyB0byB0aGUgY29uc29sZS5cbiAgICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYFJvdXRlciBpcyByZXNwb25kaW5nIHRvOiAke2dldEZyaWVuZGx5VVJMKHVybCl9YCk7XG4gICAgICAgICAgZGVidWdNZXNzYWdlcy5mb3JFYWNoKG1zZyA9PiB7XG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShtc2cpKSB7XG4gICAgICAgICAgICAgIGxvZ2dlci5sb2coLi4ubXNnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGxvZ2dlci5sb2cobXNnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBXcmFwIGluIHRyeSBhbmQgY2F0Y2ggaW4gY2FzZSB0aGUgaGFuZGxlIG1ldGhvZCB0aHJvd3MgYSBzeW5jaHJvbm91c1xuICAgICAgICAvLyBlcnJvci4gSXQgc2hvdWxkIHN0aWxsIGNhbGxiYWNrIHRvIHRoZSBjYXRjaCBoYW5kbGVyLlxuICAgICAgICBsZXQgcmVzcG9uc2VQcm9taXNlO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJlc3BvbnNlUHJvbWlzZSA9IGhhbmRsZXIuaGFuZGxlKHtcbiAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgIHBhcmFtc1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICByZXNwb25zZVByb21pc2UgPSBQcm9taXNlLnJlamVjdChlcnIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIEdldCByb3V0ZSdzIGNhdGNoIGhhbmRsZXIsIGlmIGl0IGV4aXN0c1xuICAgICAgICBjb25zdCBjYXRjaEhhbmRsZXIgPSByb3V0ZSAmJiByb3V0ZS5jYXRjaEhhbmRsZXI7XG4gICAgICAgIGlmIChyZXNwb25zZVByb21pc2UgaW5zdGFuY2VvZiBQcm9taXNlICYmICh0aGlzLl9jYXRjaEhhbmRsZXIgfHwgY2F0Y2hIYW5kbGVyKSkge1xuICAgICAgICAgIHJlc3BvbnNlUHJvbWlzZSA9IHJlc3BvbnNlUHJvbWlzZS5jYXRjaChhc3luYyBlcnIgPT4ge1xuICAgICAgICAgICAgLy8gSWYgdGhlcmUncyBhIHJvdXRlIGNhdGNoIGhhbmRsZXIsIHByb2Nlc3MgdGhhdCBmaXJzdFxuICAgICAgICAgICAgaWYgKGNhdGNoSGFuZGxlcikge1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgLy8gU3RpbGwgaW5jbHVkZSBVUkwgaGVyZSBhcyBpdCB3aWxsIGJlIGFzeW5jIGZyb20gdGhlIGNvbnNvbGUgZ3JvdXBcbiAgICAgICAgICAgICAgICAvLyBhbmQgbWF5IG5vdCBtYWtlIHNlbnNlIHdpdGhvdXQgdGhlIFVSTFxuICAgICAgICAgICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgRXJyb3IgdGhyb3duIHdoZW4gcmVzcG9uZGluZyB0bzogYCArIGAgJHtnZXRGcmllbmRseVVSTCh1cmwpfS4gRmFsbGluZyBiYWNrIHRvIHJvdXRlJ3MgQ2F0Y2ggSGFuZGxlci5gKTtcbiAgICAgICAgICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIHRocm93biBieTpgLCByb3V0ZSk7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgY2F0Y2hIYW5kbGVyLmhhbmRsZSh7XG4gICAgICAgICAgICAgICAgICB1cmwsXG4gICAgICAgICAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgICAgICBwYXJhbXNcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfSBjYXRjaCAoY2F0Y2hFcnIpIHtcbiAgICAgICAgICAgICAgICBpZiAoY2F0Y2hFcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgICAgICAgZXJyID0gY2F0Y2hFcnI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodGhpcy5fY2F0Y2hIYW5kbGVyKSB7XG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAvLyBTdGlsbCBpbmNsdWRlIFVSTCBoZXJlIGFzIGl0IHdpbGwgYmUgYXN5bmMgZnJvbSB0aGUgY29uc29sZSBncm91cFxuICAgICAgICAgICAgICAgIC8vIGFuZCBtYXkgbm90IG1ha2Ugc2Vuc2Ugd2l0aG91dCB0aGUgVVJMXG4gICAgICAgICAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBFcnJvciB0aHJvd24gd2hlbiByZXNwb25kaW5nIHRvOiBgICsgYCAke2dldEZyaWVuZGx5VVJMKHVybCl9LiBGYWxsaW5nIGJhY2sgdG8gZ2xvYmFsIENhdGNoIEhhbmRsZXIuYCk7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciB0aHJvd24gYnk6YCwgcm91dGUpO1xuICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jYXRjaEhhbmRsZXIuaGFuZGxlKHtcbiAgICAgICAgICAgICAgICB1cmwsXG4gICAgICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgICAgICBldmVudFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2VQcm9taXNlO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBDaGVja3MgYSByZXF1ZXN0IGFuZCBVUkwgKGFuZCBvcHRpb25hbGx5IGFuIGV2ZW50KSBhZ2FpbnN0IHRoZSBsaXN0IG9mXG4gICAgICAgKiByZWdpc3RlcmVkIHJvdXRlcywgYW5kIGlmIHRoZXJlJ3MgYSBtYXRjaCwgcmV0dXJucyB0aGUgY29ycmVzcG9uZGluZ1xuICAgICAgICogcm91dGUgYWxvbmcgd2l0aCBhbnkgcGFyYW1zIGdlbmVyYXRlZCBieSB0aGUgbWF0Y2guXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnNcbiAgICAgICAqIEBwYXJhbSB7VVJMfSBvcHRpb25zLnVybFxuICAgICAgICogQHBhcmFtIHtib29sZWFufSBvcHRpb25zLnNhbWVPcmlnaW4gVGhlIHJlc3VsdCBvZiBjb21wYXJpbmcgYHVybC5vcmlnaW5gXG4gICAgICAgKiAgICAgYWdhaW5zdCB0aGUgY3VycmVudCBvcmlnaW4uXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IG9wdGlvbnMucmVxdWVzdCBUaGUgcmVxdWVzdCB0byBtYXRjaC5cbiAgICAgICAqIEBwYXJhbSB7RXZlbnR9IG9wdGlvbnMuZXZlbnQgVGhlIGNvcnJlc3BvbmRpbmcgZXZlbnQuXG4gICAgICAgKiBAcmV0dXJuIHtPYmplY3R9IEFuIG9iamVjdCB3aXRoIGByb3V0ZWAgYW5kIGBwYXJhbXNgIHByb3BlcnRpZXMuXG4gICAgICAgKiAgICAgVGhleSBhcmUgcG9wdWxhdGVkIGlmIGEgbWF0Y2hpbmcgcm91dGUgd2FzIGZvdW5kIG9yIGB1bmRlZmluZWRgXG4gICAgICAgKiAgICAgb3RoZXJ3aXNlLlxuICAgICAgICovXG4gICAgICBmaW5kTWF0Y2hpbmdSb3V0ZSh7XG4gICAgICAgIHVybCxcbiAgICAgICAgc2FtZU9yaWdpbixcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgZXZlbnRcbiAgICAgIH0pIHtcbiAgICAgICAgY29uc3Qgcm91dGVzID0gdGhpcy5fcm91dGVzLmdldChyZXF1ZXN0Lm1ldGhvZCkgfHwgW107XG4gICAgICAgIGZvciAoY29uc3Qgcm91dGUgb2Ygcm91dGVzKSB7XG4gICAgICAgICAgbGV0IHBhcmFtcztcbiAgICAgICAgICAvLyByb3V0ZS5tYXRjaCByZXR1cm5zIHR5cGUgYW55LCBub3QgcG9zc2libGUgdG8gY2hhbmdlIHJpZ2h0IG5vdy5cbiAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1hc3NpZ25tZW50XG4gICAgICAgICAgY29uc3QgbWF0Y2hSZXN1bHQgPSByb3V0ZS5tYXRjaCh7XG4gICAgICAgICAgICB1cmwsXG4gICAgICAgICAgICBzYW1lT3JpZ2luLFxuICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgIGV2ZW50XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKG1hdGNoUmVzdWx0KSB7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIC8vIFdhcm4gZGV2ZWxvcGVycyB0aGF0IHVzaW5nIGFuIGFzeW5jIG1hdGNoQ2FsbGJhY2sgaXMgYWxtb3N0IGFsd2F5c1xuICAgICAgICAgICAgICAvLyBub3QgdGhlIHJpZ2h0IHRoaW5nIHRvIGRvLlxuICAgICAgICAgICAgICBpZiAobWF0Y2hSZXN1bHQgaW5zdGFuY2VvZiBQcm9taXNlKSB7XG4gICAgICAgICAgICAgICAgbG9nZ2VyLndhcm4oYFdoaWxlIHJvdXRpbmcgJHtnZXRGcmllbmRseVVSTCh1cmwpfSwgYW4gYXN5bmMgYCArIGBtYXRjaENhbGxiYWNrIGZ1bmN0aW9uIHdhcyB1c2VkLiBQbGVhc2UgY29udmVydCB0aGUgYCArIGBmb2xsb3dpbmcgcm91dGUgdG8gdXNlIGEgc3luY2hyb25vdXMgbWF0Y2hDYWxsYmFjayBmdW5jdGlvbjpgLCByb3V0ZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzIwNzlcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLWFzc2lnbm1lbnRcbiAgICAgICAgICAgIHBhcmFtcyA9IG1hdGNoUmVzdWx0O1xuICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocGFyYW1zKSAmJiBwYXJhbXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgIC8vIEluc3RlYWQgb2YgcGFzc2luZyBhbiBlbXB0eSBhcnJheSBpbiBhcyBwYXJhbXMsIHVzZSB1bmRlZmluZWQuXG4gICAgICAgICAgICAgIHBhcmFtcyA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobWF0Y2hSZXN1bHQuY29uc3RydWN0b3IgPT09IE9iamVjdCAmJlxuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgICAgICAgICAgT2JqZWN0LmtleXMobWF0Y2hSZXN1bHQpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAvLyBJbnN0ZWFkIG9mIHBhc3NpbmcgYW4gZW1wdHkgb2JqZWN0IGluIGFzIHBhcmFtcywgdXNlIHVuZGVmaW5lZC5cbiAgICAgICAgICAgICAgcGFyYW1zID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgbWF0Y2hSZXN1bHQgPT09ICdib29sZWFuJykge1xuICAgICAgICAgICAgICAvLyBGb3IgdGhlIGJvb2xlYW4gdmFsdWUgdHJ1ZSAocmF0aGVyIHRoYW4ganVzdCBzb21ldGhpbmcgdHJ1dGgteSksXG4gICAgICAgICAgICAgIC8vIGRvbid0IHNldCBwYXJhbXMuXG4gICAgICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvcHVsbC8yMTM0I2lzc3VlY29tbWVudC01MTM5MjQzNTNcbiAgICAgICAgICAgICAgcGFyYW1zID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gUmV0dXJuIGVhcmx5IGlmIGhhdmUgYSBtYXRjaC5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHJvdXRlLFxuICAgICAgICAgICAgICBwYXJhbXNcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIElmIG5vIG1hdGNoIHdhcyBmb3VuZCBhYm92ZSwgcmV0dXJuIGFuZCBlbXB0eSBvYmplY3QuXG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogRGVmaW5lIGEgZGVmYXVsdCBgaGFuZGxlcmAgdGhhdCdzIGNhbGxlZCB3aGVuIG5vIHJvdXRlcyBleHBsaWNpdGx5XG4gICAgICAgKiBtYXRjaCB0aGUgaW5jb21pbmcgcmVxdWVzdC5cbiAgICAgICAqXG4gICAgICAgKiBFYWNoIEhUVFAgbWV0aG9kICgnR0VUJywgJ1BPU1QnLCBldGMuKSBnZXRzIGl0cyBvd24gZGVmYXVsdCBoYW5kbGVyLlxuICAgICAgICpcbiAgICAgICAqIFdpdGhvdXQgYSBkZWZhdWx0IGhhbmRsZXIsIHVubWF0Y2hlZCByZXF1ZXN0cyB3aWxsIGdvIGFnYWluc3QgdGhlXG4gICAgICAgKiBuZXR3b3JrIGFzIGlmIHRoZXJlIHdlcmUgbm8gc2VydmljZSB3b3JrZXIgcHJlc2VudC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9IGhhbmRsZXIgQSBjYWxsYmFja1xuICAgICAgICogZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgUHJvbWlzZSByZXN1bHRpbmcgaW4gYSBSZXNwb25zZS5cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbbWV0aG9kPSdHRVQnXSBUaGUgSFRUUCBtZXRob2QgdG8gYXNzb2NpYXRlIHdpdGggdGhpc1xuICAgICAgICogZGVmYXVsdCBoYW5kbGVyLiBFYWNoIG1ldGhvZCBoYXMgaXRzIG93biBkZWZhdWx0LlxuICAgICAgICovXG4gICAgICBzZXREZWZhdWx0SGFuZGxlcihoYW5kbGVyLCBtZXRob2QgPSBkZWZhdWx0TWV0aG9kKSB7XG4gICAgICAgIHRoaXMuX2RlZmF1bHRIYW5kbGVyTWFwLnNldChtZXRob2QsIG5vcm1hbGl6ZUhhbmRsZXIoaGFuZGxlcikpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBJZiBhIFJvdXRlIHRocm93cyBhbiBlcnJvciB3aGlsZSBoYW5kbGluZyBhIHJlcXVlc3QsIHRoaXMgYGhhbmRsZXJgXG4gICAgICAgKiB3aWxsIGJlIGNhbGxlZCBhbmQgZ2l2ZW4gYSBjaGFuY2UgdG8gcHJvdmlkZSBhIHJlc3BvbnNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja30gaGFuZGxlciBBIGNhbGxiYWNrXG4gICAgICAgKiBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlIHJlc3VsdGluZyBpbiBhIFJlc3BvbnNlLlxuICAgICAgICovXG4gICAgICBzZXRDYXRjaEhhbmRsZXIoaGFuZGxlcikge1xuICAgICAgICB0aGlzLl9jYXRjaEhhbmRsZXIgPSBub3JtYWxpemVIYW5kbGVyKGhhbmRsZXIpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZWdpc3RlcnMgYSByb3V0ZSB3aXRoIHRoZSByb3V0ZXIuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmcuUm91dGV9IHJvdXRlIFRoZSByb3V0ZSB0byByZWdpc3Rlci5cbiAgICAgICAqL1xuICAgICAgcmVnaXN0ZXJSb3V0ZShyb3V0ZSkge1xuICAgICAgICB7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShyb3V0ZSwgJ29iamVjdCcsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXJSb3V0ZScsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdyb3V0ZSdcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaGFzTWV0aG9kKHJvdXRlLCAnbWF0Y2gnLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1JvdXRlcicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ3JlZ2lzdGVyUm91dGUnLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAncm91dGUnXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzVHlwZShyb3V0ZS5oYW5kbGVyLCAnb2JqZWN0Jywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdyZWdpc3RlclJvdXRlJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ3JvdXRlJ1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5oYXNNZXRob2Qocm91dGUuaGFuZGxlciwgJ2hhbmRsZScsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnUm91dGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAncmVnaXN0ZXJSb3V0ZScsXG4gICAgICAgICAgICBwYXJhbU5hbWU6ICdyb3V0ZS5oYW5kbGVyJ1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGZpbmFsQXNzZXJ0RXhwb3J0cy5pc1R5cGUocm91dGUubWV0aG9kLCAnc3RyaW5nJywge1xuICAgICAgICAgICAgbW9kdWxlTmFtZTogJ3dvcmtib3gtcm91dGluZycsXG4gICAgICAgICAgICBjbGFzc05hbWU6ICdSb3V0ZXInLFxuICAgICAgICAgICAgZnVuY05hbWU6ICdyZWdpc3RlclJvdXRlJyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ3JvdXRlLm1ldGhvZCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuX3JvdXRlcy5oYXMocm91dGUubWV0aG9kKSkge1xuICAgICAgICAgIHRoaXMuX3JvdXRlcy5zZXQocm91dGUubWV0aG9kLCBbXSk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gR2l2ZSBwcmVjZWRlbmNlIHRvIGFsbCBvZiB0aGUgZWFybGllciByb3V0ZXMgYnkgYWRkaW5nIHRoaXMgYWRkaXRpb25hbFxuICAgICAgICAvLyByb3V0ZSB0byB0aGUgZW5kIG9mIHRoZSBhcnJheS5cbiAgICAgICAgdGhpcy5fcm91dGVzLmdldChyb3V0ZS5tZXRob2QpLnB1c2gocm91dGUpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBVbnJlZ2lzdGVycyBhIHJvdXRlIHdpdGggdGhlIHJvdXRlci5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtcm91dGluZy5Sb3V0ZX0gcm91dGUgVGhlIHJvdXRlIHRvIHVucmVnaXN0ZXIuXG4gICAgICAgKi9cbiAgICAgIHVucmVnaXN0ZXJSb3V0ZShyb3V0ZSkge1xuICAgICAgICBpZiAoIXRoaXMuX3JvdXRlcy5oYXMocm91dGUubWV0aG9kKSkge1xuICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ3VucmVnaXN0ZXItcm91dGUtYnV0LW5vdC1mb3VuZC13aXRoLW1ldGhvZCcsIHtcbiAgICAgICAgICAgIG1ldGhvZDogcm91dGUubWV0aG9kXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgcm91dGVJbmRleCA9IHRoaXMuX3JvdXRlcy5nZXQocm91dGUubWV0aG9kKS5pbmRleE9mKHJvdXRlKTtcbiAgICAgICAgaWYgKHJvdXRlSW5kZXggPiAtMSkge1xuICAgICAgICAgIHRoaXMuX3JvdXRlcy5nZXQocm91dGUubWV0aG9kKS5zcGxpY2Uocm91dGVJbmRleCwgMSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcigndW5yZWdpc3Rlci1yb3V0ZS1yb3V0ZS1ub3QtcmVnaXN0ZXJlZCcpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgbGV0IGRlZmF1bHRSb3V0ZXI7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIG5ldywgc2luZ2xldG9uIFJvdXRlciBpbnN0YW5jZSBpZiBvbmUgZG9lcyBub3QgZXhpc3QuIElmIG9uZVxuICAgICAqIGRvZXMgYWxyZWFkeSBleGlzdCwgdGhhdCBpbnN0YW5jZSBpcyByZXR1cm5lZC5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQHJldHVybiB7Um91dGVyfVxuICAgICAqL1xuICAgIGNvbnN0IGdldE9yQ3JlYXRlRGVmYXVsdFJvdXRlciA9ICgpID0+IHtcbiAgICAgIGlmICghZGVmYXVsdFJvdXRlcikge1xuICAgICAgICBkZWZhdWx0Um91dGVyID0gbmV3IFJvdXRlcigpO1xuICAgICAgICAvLyBUaGUgaGVscGVycyB0aGF0IHVzZSB0aGUgZGVmYXVsdCBSb3V0ZXIgYXNzdW1lIHRoZXNlIGxpc3RlbmVycyBleGlzdC5cbiAgICAgICAgZGVmYXVsdFJvdXRlci5hZGRGZXRjaExpc3RlbmVyKCk7XG4gICAgICAgIGRlZmF1bHRSb3V0ZXIuYWRkQ2FjaGVMaXN0ZW5lcigpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGRlZmF1bHRSb3V0ZXI7XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEVhc2lseSByZWdpc3RlciBhIFJlZ0V4cCwgc3RyaW5nLCBvciBmdW5jdGlvbiB3aXRoIGEgY2FjaGluZ1xuICAgICAqIHN0cmF0ZWd5IHRvIGEgc2luZ2xldG9uIFJvdXRlciBpbnN0YW5jZS5cbiAgICAgKlxuICAgICAqIFRoaXMgbWV0aG9kIHdpbGwgZ2VuZXJhdGUgYSBSb3V0ZSBmb3IgeW91IGlmIG5lZWRlZCBhbmRcbiAgICAgKiBjYWxsIHtAbGluayB3b3JrYm94LXJvdXRpbmcuUm91dGVyI3JlZ2lzdGVyUm91dGV9LlxuICAgICAqXG4gICAgICogQHBhcmFtIHtSZWdFeHB8c3RyaW5nfHdvcmtib3gtcm91dGluZy5Sb3V0ZX5tYXRjaENhbGxiYWNrfHdvcmtib3gtcm91dGluZy5Sb3V0ZX0gY2FwdHVyZVxuICAgICAqIElmIHRoZSBjYXB0dXJlIHBhcmFtIGlzIGEgYFJvdXRlYCwgYWxsIG90aGVyIGFyZ3VtZW50cyB3aWxsIGJlIGlnbm9yZWQuXG4gICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfSBbaGFuZGxlcl0gQSBjYWxsYmFja1xuICAgICAqIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UgcmVzdWx0aW5nIGluIGEgUmVzcG9uc2UuIFRoaXMgcGFyYW1ldGVyXG4gICAgICogaXMgcmVxdWlyZWQgaWYgYGNhcHR1cmVgIGlzIG5vdCBhIGBSb3V0ZWAgb2JqZWN0LlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbbWV0aG9kPSdHRVQnXSBUaGUgSFRUUCBtZXRob2QgdG8gbWF0Y2ggdGhlIFJvdXRlXG4gICAgICogYWdhaW5zdC5cbiAgICAgKiBAcmV0dXJuIHt3b3JrYm94LXJvdXRpbmcuUm91dGV9IFRoZSBnZW5lcmF0ZWQgYFJvdXRlYC5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXJvdXRpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiByZWdpc3RlclJvdXRlKGNhcHR1cmUsIGhhbmRsZXIsIG1ldGhvZCkge1xuICAgICAgbGV0IHJvdXRlO1xuICAgICAgaWYgKHR5cGVvZiBjYXB0dXJlID09PSAnc3RyaW5nJykge1xuICAgICAgICBjb25zdCBjYXB0dXJlVXJsID0gbmV3IFVSTChjYXB0dXJlLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgICAge1xuICAgICAgICAgIGlmICghKGNhcHR1cmUuc3RhcnRzV2l0aCgnLycpIHx8IGNhcHR1cmUuc3RhcnRzV2l0aCgnaHR0cCcpKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignaW52YWxpZC1zdHJpbmcnLCB7XG4gICAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgICBmdW5jTmFtZTogJ3JlZ2lzdGVyUm91dGUnLFxuICAgICAgICAgICAgICBwYXJhbU5hbWU6ICdjYXB0dXJlJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIFdlIHdhbnQgdG8gY2hlY2sgaWYgRXhwcmVzcy1zdHlsZSB3aWxkY2FyZHMgYXJlIGluIHRoZSBwYXRobmFtZSBvbmx5LlxuICAgICAgICAgIC8vIFRPRE86IFJlbW92ZSB0aGlzIGxvZyBtZXNzYWdlIGluIHY0LlxuICAgICAgICAgIGNvbnN0IHZhbHVlVG9DaGVjayA9IGNhcHR1cmUuc3RhcnRzV2l0aCgnaHR0cCcpID8gY2FwdHVyZVVybC5wYXRobmFtZSA6IGNhcHR1cmU7XG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9waWxsYXJqcy9wYXRoLXRvLXJlZ2V4cCNwYXJhbWV0ZXJzXG4gICAgICAgICAgY29uc3Qgd2lsZGNhcmRzID0gJ1sqOj8rXSc7XG4gICAgICAgICAgaWYgKG5ldyBSZWdFeHAoYCR7d2lsZGNhcmRzfWApLmV4ZWModmFsdWVUb0NoZWNrKSkge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBUaGUgJyRjYXB0dXJlJyBwYXJhbWV0ZXIgY29udGFpbnMgYW4gRXhwcmVzcy1zdHlsZSB3aWxkY2FyZCBgICsgYGNoYXJhY3RlciAoJHt3aWxkY2FyZHN9KS4gU3RyaW5ncyBhcmUgbm93IGFsd2F5cyBpbnRlcnByZXRlZCBhcyBgICsgYGV4YWN0IG1hdGNoZXM7IHVzZSBhIFJlZ0V4cCBmb3IgcGFydGlhbCBvciB3aWxkY2FyZCBtYXRjaGVzLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBtYXRjaENhbGxiYWNrID0gKHtcbiAgICAgICAgICB1cmxcbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlmICh1cmwucGF0aG5hbWUgPT09IGNhcHR1cmVVcmwucGF0aG5hbWUgJiYgdXJsLm9yaWdpbiAhPT0gY2FwdHVyZVVybC5vcmlnaW4pIHtcbiAgICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGAke2NhcHR1cmV9IG9ubHkgcGFydGlhbGx5IG1hdGNoZXMgdGhlIGNyb3NzLW9yaWdpbiBVUkwgYCArIGAke3VybC50b1N0cmluZygpfS4gVGhpcyByb3V0ZSB3aWxsIG9ubHkgaGFuZGxlIGNyb3NzLW9yaWdpbiByZXF1ZXN0cyBgICsgYGlmIHRoZXkgbWF0Y2ggdGhlIGVudGlyZSBVUkwuYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB1cmwuaHJlZiA9PT0gY2FwdHVyZVVybC5ocmVmO1xuICAgICAgICB9O1xuICAgICAgICAvLyBJZiBgY2FwdHVyZWAgaXMgYSBzdHJpbmcgdGhlbiBgaGFuZGxlcmAgYW5kIGBtZXRob2RgIG11c3QgYmUgcHJlc2VudC5cbiAgICAgICAgcm91dGUgPSBuZXcgUm91dGUobWF0Y2hDYWxsYmFjaywgaGFuZGxlciwgbWV0aG9kKTtcbiAgICAgIH0gZWxzZSBpZiAoY2FwdHVyZSBpbnN0YW5jZW9mIFJlZ0V4cCkge1xuICAgICAgICAvLyBJZiBgY2FwdHVyZWAgaXMgYSBgUmVnRXhwYCB0aGVuIGBoYW5kbGVyYCBhbmQgYG1ldGhvZGAgbXVzdCBiZSBwcmVzZW50LlxuICAgICAgICByb3V0ZSA9IG5ldyBSZWdFeHBSb3V0ZShjYXB0dXJlLCBoYW5kbGVyLCBtZXRob2QpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgY2FwdHVyZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAvLyBJZiBgY2FwdHVyZWAgaXMgYSBmdW5jdGlvbiB0aGVuIGBoYW5kbGVyYCBhbmQgYG1ldGhvZGAgbXVzdCBiZSBwcmVzZW50LlxuICAgICAgICByb3V0ZSA9IG5ldyBSb3V0ZShjYXB0dXJlLCBoYW5kbGVyLCBtZXRob2QpO1xuICAgICAgfSBlbHNlIGlmIChjYXB0dXJlIGluc3RhbmNlb2YgUm91dGUpIHtcbiAgICAgICAgcm91dGUgPSBjYXB0dXJlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcigndW5zdXBwb3J0ZWQtcm91dGUtdHlwZScsIHtcbiAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1yb3V0aW5nJyxcbiAgICAgICAgICBmdW5jTmFtZTogJ3JlZ2lzdGVyUm91dGUnLFxuICAgICAgICAgIHBhcmFtTmFtZTogJ2NhcHR1cmUnXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgZGVmYXVsdFJvdXRlciA9IGdldE9yQ3JlYXRlRGVmYXVsdFJvdXRlcigpO1xuICAgICAgZGVmYXVsdFJvdXRlci5yZWdpc3RlclJvdXRlKHJvdXRlKTtcbiAgICAgIHJldHVybiByb3V0ZTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBfY2FjaGVOYW1lRGV0YWlscyA9IHtcbiAgICAgIGdvb2dsZUFuYWx5dGljczogJ2dvb2dsZUFuYWx5dGljcycsXG4gICAgICBwcmVjYWNoZTogJ3ByZWNhY2hlLXYyJyxcbiAgICAgIHByZWZpeDogJ3dvcmtib3gnLFxuICAgICAgcnVudGltZTogJ3J1bnRpbWUnLFxuICAgICAgc3VmZml4OiB0eXBlb2YgcmVnaXN0cmF0aW9uICE9PSAndW5kZWZpbmVkJyA/IHJlZ2lzdHJhdGlvbi5zY29wZSA6ICcnXG4gICAgfTtcbiAgICBjb25zdCBfY3JlYXRlQ2FjaGVOYW1lID0gY2FjaGVOYW1lID0+IHtcbiAgICAgIHJldHVybiBbX2NhY2hlTmFtZURldGFpbHMucHJlZml4LCBjYWNoZU5hbWUsIF9jYWNoZU5hbWVEZXRhaWxzLnN1ZmZpeF0uZmlsdGVyKHZhbHVlID0+IHZhbHVlICYmIHZhbHVlLmxlbmd0aCA+IDApLmpvaW4oJy0nKTtcbiAgICB9O1xuICAgIGNvbnN0IGVhY2hDYWNoZU5hbWVEZXRhaWwgPSBmbiA9PiB7XG4gICAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhfY2FjaGVOYW1lRGV0YWlscykpIHtcbiAgICAgICAgZm4oa2V5KTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGNhY2hlTmFtZXMgPSB7XG4gICAgICB1cGRhdGVEZXRhaWxzOiBkZXRhaWxzID0+IHtcbiAgICAgICAgZWFjaENhY2hlTmFtZURldGFpbChrZXkgPT4ge1xuICAgICAgICAgIGlmICh0eXBlb2YgZGV0YWlsc1trZXldID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgX2NhY2hlTmFtZURldGFpbHNba2V5XSA9IGRldGFpbHNba2V5XTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIGdldEdvb2dsZUFuYWx5dGljc05hbWU6IHVzZXJDYWNoZU5hbWUgPT4ge1xuICAgICAgICByZXR1cm4gdXNlckNhY2hlTmFtZSB8fCBfY3JlYXRlQ2FjaGVOYW1lKF9jYWNoZU5hbWVEZXRhaWxzLmdvb2dsZUFuYWx5dGljcyk7XG4gICAgICB9LFxuICAgICAgZ2V0UHJlY2FjaGVOYW1lOiB1c2VyQ2FjaGVOYW1lID0+IHtcbiAgICAgICAgcmV0dXJuIHVzZXJDYWNoZU5hbWUgfHwgX2NyZWF0ZUNhY2hlTmFtZShfY2FjaGVOYW1lRGV0YWlscy5wcmVjYWNoZSk7XG4gICAgICB9LFxuICAgICAgZ2V0UHJlZml4OiAoKSA9PiB7XG4gICAgICAgIHJldHVybiBfY2FjaGVOYW1lRGV0YWlscy5wcmVmaXg7XG4gICAgICB9LFxuICAgICAgZ2V0UnVudGltZU5hbWU6IHVzZXJDYWNoZU5hbWUgPT4ge1xuICAgICAgICByZXR1cm4gdXNlckNhY2hlTmFtZSB8fCBfY3JlYXRlQ2FjaGVOYW1lKF9jYWNoZU5hbWVEZXRhaWxzLnJ1bnRpbWUpO1xuICAgICAgfSxcbiAgICAgIGdldFN1ZmZpeDogKCkgPT4ge1xuICAgICAgICByZXR1cm4gX2NhY2hlTmFtZURldGFpbHMuc3VmZml4O1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQSB1dGlsaXR5IG1ldGhvZCB0aGF0IG1ha2VzIGl0IGVhc2llciB0byB1c2UgYGV2ZW50LndhaXRVbnRpbGAgd2l0aFxuICAgICAqIGFzeW5jIGZ1bmN0aW9ucyBhbmQgcmV0dXJuIHRoZSByZXN1bHQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge0V4dGVuZGFibGVFdmVudH0gZXZlbnRcbiAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBhc3luY0ZuXG4gICAgICogQHJldHVybiB7RnVuY3Rpb259XG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiB3YWl0VW50aWwoZXZlbnQsIGFzeW5jRm4pIHtcbiAgICAgIGNvbnN0IHJldHVyblByb21pc2UgPSBhc3luY0ZuKCk7XG4gICAgICBldmVudC53YWl0VW50aWwocmV0dXJuUHJvbWlzZSk7XG4gICAgICByZXR1cm4gcmV0dXJuUHJvbWlzZTtcbiAgICB9XG5cbiAgICAvLyBAdHMtaWdub3JlXG4gICAgdHJ5IHtcbiAgICAgIHNlbGZbJ3dvcmtib3g6cHJlY2FjaGluZzo3LjQuMCddICYmIF8oKTtcbiAgICB9IGNhdGNoIChlKSB7fVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLy8gTmFtZSBvZiB0aGUgc2VhcmNoIHBhcmFtZXRlciB1c2VkIHRvIHN0b3JlIHJldmlzaW9uIGluZm8uXG4gICAgY29uc3QgUkVWSVNJT05fU0VBUkNIX1BBUkFNID0gJ19fV0JfUkVWSVNJT05fXyc7XG4gICAgLyoqXG4gICAgICogQ29udmVydHMgYSBtYW5pZmVzdCBlbnRyeSBpbnRvIGEgdmVyc2lvbmVkIFVSTCBzdWl0YWJsZSBmb3IgcHJlY2FjaGluZy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7T2JqZWN0fHN0cmluZ30gZW50cnlcbiAgICAgKiBAcmV0dXJuIHtzdHJpbmd9IEEgVVJMIHdpdGggdmVyc2lvbmluZyBpbmZvLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gY3JlYXRlQ2FjaGVLZXkoZW50cnkpIHtcbiAgICAgIGlmICghZW50cnkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignYWRkLXRvLWNhY2hlLWxpc3QtdW5leHBlY3RlZC10eXBlJywge1xuICAgICAgICAgIGVudHJ5XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgLy8gSWYgYSBwcmVjYWNoZSBtYW5pZmVzdCBlbnRyeSBpcyBhIHN0cmluZywgaXQncyBhc3N1bWVkIHRvIGJlIGEgdmVyc2lvbmVkXG4gICAgICAvLyBVUkwsIGxpa2UgJy9hcHAuYWJjZDEyMzQuanMnLiBSZXR1cm4gYXMtaXMuXG4gICAgICBpZiAodHlwZW9mIGVudHJ5ID09PSAnc3RyaW5nJykge1xuICAgICAgICBjb25zdCB1cmxPYmplY3QgPSBuZXcgVVJMKGVudHJ5LCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjYWNoZUtleTogdXJsT2JqZWN0LmhyZWYsXG4gICAgICAgICAgdXJsOiB1cmxPYmplY3QuaHJlZlxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgY29uc3Qge1xuICAgICAgICByZXZpc2lvbixcbiAgICAgICAgdXJsXG4gICAgICB9ID0gZW50cnk7XG4gICAgICBpZiAoIXVybCkge1xuICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdhZGQtdG8tY2FjaGUtbGlzdC11bmV4cGVjdGVkLXR5cGUnLCB7XG4gICAgICAgICAgZW50cnlcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICAvLyBJZiB0aGVyZSdzIGp1c3QgYSBVUkwgYW5kIG5vIHJldmlzaW9uLCB0aGVuIGl0J3MgYWxzbyBhc3N1bWVkIHRvIGJlIGFcbiAgICAgIC8vIHZlcnNpb25lZCBVUkwuXG4gICAgICBpZiAoIXJldmlzaW9uKSB7XG4gICAgICAgIGNvbnN0IHVybE9iamVjdCA9IG5ldyBVUkwodXJsLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjYWNoZUtleTogdXJsT2JqZWN0LmhyZWYsXG4gICAgICAgICAgdXJsOiB1cmxPYmplY3QuaHJlZlxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgLy8gT3RoZXJ3aXNlLCBjb25zdHJ1Y3QgYSBwcm9wZXJseSB2ZXJzaW9uZWQgVVJMIHVzaW5nIHRoZSBjdXN0b20gV29ya2JveFxuICAgICAgLy8gc2VhcmNoIHBhcmFtZXRlciBhbG9uZyB3aXRoIHRoZSByZXZpc2lvbiBpbmZvLlxuICAgICAgY29uc3QgY2FjaGVLZXlVUkwgPSBuZXcgVVJMKHVybCwgbG9jYXRpb24uaHJlZik7XG4gICAgICBjb25zdCBvcmlnaW5hbFVSTCA9IG5ldyBVUkwodXJsLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgIGNhY2hlS2V5VVJMLnNlYXJjaFBhcmFtcy5zZXQoUkVWSVNJT05fU0VBUkNIX1BBUkFNLCByZXZpc2lvbik7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjYWNoZUtleTogY2FjaGVLZXlVUkwuaHJlZixcbiAgICAgICAgdXJsOiBvcmlnaW5hbFVSTC5ocmVmXG4gICAgICB9O1xuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEEgcGx1Z2luLCBkZXNpZ25lZCB0byBiZSB1c2VkIHdpdGggUHJlY2FjaGVDb250cm9sbGVyLCB0byBkZXRlcm1pbmUgdGhlXG4gICAgICogb2YgYXNzZXRzIHRoYXQgd2VyZSB1cGRhdGVkIChvciBub3QgdXBkYXRlZCkgZHVyaW5nIHRoZSBpbnN0YWxsIGV2ZW50LlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjbGFzcyBQcmVjYWNoZUluc3RhbGxSZXBvcnRQbHVnaW4ge1xuICAgICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMudXBkYXRlZFVSTHMgPSBbXTtcbiAgICAgICAgdGhpcy5ub3RVcGRhdGVkVVJMcyA9IFtdO1xuICAgICAgICB0aGlzLmhhbmRsZXJXaWxsU3RhcnQgPSBhc3luYyAoe1xuICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgc3RhdGVcbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIC8vIFRPRE86IGBzdGF0ZWAgc2hvdWxkIG5ldmVyIGJlIHVuZGVmaW5lZC4uLlxuICAgICAgICAgIGlmIChzdGF0ZSkge1xuICAgICAgICAgICAgc3RhdGUub3JpZ2luYWxSZXF1ZXN0ID0gcmVxdWVzdDtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuY2FjaGVkUmVzcG9uc2VXaWxsQmVVc2VkID0gYXN5bmMgKHtcbiAgICAgICAgICBldmVudCxcbiAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICBjYWNoZWRSZXNwb25zZVxuICAgICAgICB9KSA9PiB7XG4gICAgICAgICAgaWYgKGV2ZW50LnR5cGUgPT09ICdpbnN0YWxsJykge1xuICAgICAgICAgICAgaWYgKHN0YXRlICYmIHN0YXRlLm9yaWdpbmFsUmVxdWVzdCAmJiBzdGF0ZS5vcmlnaW5hbFJlcXVlc3QgaW5zdGFuY2VvZiBSZXF1ZXN0KSB7XG4gICAgICAgICAgICAgIC8vIFRPRE86IGBzdGF0ZWAgc2hvdWxkIG5ldmVyIGJlIHVuZGVmaW5lZC4uLlxuICAgICAgICAgICAgICBjb25zdCB1cmwgPSBzdGF0ZS5vcmlnaW5hbFJlcXVlc3QudXJsO1xuICAgICAgICAgICAgICBpZiAoY2FjaGVkUmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm5vdFVwZGF0ZWRVUkxzLnB1c2godXJsKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZWRVUkxzLnB1c2godXJsKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gY2FjaGVkUmVzcG9uc2U7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQSBwbHVnaW4sIGRlc2lnbmVkIHRvIGJlIHVzZWQgd2l0aCBQcmVjYWNoZUNvbnRyb2xsZXIsIHRvIHRyYW5zbGF0ZSBVUkxzIGludG9cbiAgICAgKiB0aGUgY29ycmVzcG9uZGluZyBjYWNoZSBrZXksIGJhc2VkIG9uIHRoZSBjdXJyZW50IHJldmlzaW9uIGluZm8uXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGNsYXNzIFByZWNhY2hlQ2FjaGVLZXlQbHVnaW4ge1xuICAgICAgY29uc3RydWN0b3Ioe1xuICAgICAgICBwcmVjYWNoZUNvbnRyb2xsZXJcbiAgICAgIH0pIHtcbiAgICAgICAgdGhpcy5jYWNoZUtleVdpbGxCZVVzZWQgPSBhc3luYyAoe1xuICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgcGFyYW1zXG4gICAgICAgIH0pID0+IHtcbiAgICAgICAgICAvLyBQYXJhbXMgaXMgdHlwZSBhbnksIGNhbid0IGNoYW5nZSByaWdodCBub3cuXG4gICAgICAgICAgLyogZXNsaW50LWRpc2FibGUgKi9cbiAgICAgICAgICBjb25zdCBjYWNoZUtleSA9IChwYXJhbXMgPT09IG51bGwgfHwgcGFyYW1zID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwYXJhbXMuY2FjaGVLZXkpIHx8IHRoaXMuX3ByZWNhY2hlQ29udHJvbGxlci5nZXRDYWNoZUtleUZvclVSTChyZXF1ZXN0LnVybCk7XG4gICAgICAgICAgLyogZXNsaW50LWVuYWJsZSAqL1xuICAgICAgICAgIHJldHVybiBjYWNoZUtleSA/IG5ldyBSZXF1ZXN0KGNhY2hlS2V5LCB7XG4gICAgICAgICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnNcbiAgICAgICAgICB9KSA6IHJlcXVlc3Q7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuX3ByZWNhY2hlQ29udHJvbGxlciA9IHByZWNhY2hlQ29udHJvbGxlcjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZ3JvdXBUaXRsZVxuICAgICAqIEBwYXJhbSB7QXJyYXk8c3RyaW5nPn0gZGVsZXRlZFVSTHNcbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY29uc3QgbG9nR3JvdXAgPSAoZ3JvdXBUaXRsZSwgZGVsZXRlZFVSTHMpID0+IHtcbiAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChncm91cFRpdGxlKTtcbiAgICAgIGZvciAoY29uc3QgdXJsIG9mIGRlbGV0ZWRVUkxzKSB7XG4gICAgICAgIGxvZ2dlci5sb2codXJsKTtcbiAgICAgIH1cbiAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSBkZWxldGVkVVJMc1xuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gcHJpbnRDbGVhbnVwRGV0YWlscyhkZWxldGVkVVJMcykge1xuICAgICAgY29uc3QgZGVsZXRpb25Db3VudCA9IGRlbGV0ZWRVUkxzLmxlbmd0aDtcbiAgICAgIGlmIChkZWxldGlvbkNvdW50ID4gMCkge1xuICAgICAgICBsb2dnZXIuZ3JvdXBDb2xsYXBzZWQoYER1cmluZyBwcmVjYWNoaW5nIGNsZWFudXAsIGAgKyBgJHtkZWxldGlvbkNvdW50fSBjYWNoZWQgYCArIGByZXF1ZXN0JHtkZWxldGlvbkNvdW50ID09PSAxID8gJyB3YXMnIDogJ3Mgd2VyZSd9IGRlbGV0ZWQuYCk7XG4gICAgICAgIGxvZ0dyb3VwKCdEZWxldGVkIENhY2hlIFJlcXVlc3RzJywgZGVsZXRlZFVSTHMpO1xuICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZ3JvdXBUaXRsZVxuICAgICAqIEBwYXJhbSB7QXJyYXk8c3RyaW5nPn0gdXJsc1xuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBfbmVzdGVkR3JvdXAoZ3JvdXBUaXRsZSwgdXJscykge1xuICAgICAgaWYgKHVybHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChncm91cFRpdGxlKTtcbiAgICAgIGZvciAoY29uc3QgdXJsIG9mIHVybHMpIHtcbiAgICAgICAgbG9nZ2VyLmxvZyh1cmwpO1xuICAgICAgfVxuICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7QXJyYXk8c3RyaW5nPn0gdXJsc1RvUHJlY2FjaGVcbiAgICAgKiBAcGFyYW0ge0FycmF5PHN0cmluZz59IHVybHNBbHJlYWR5UHJlY2FjaGVkXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBwcmludEluc3RhbGxEZXRhaWxzKHVybHNUb1ByZWNhY2hlLCB1cmxzQWxyZWFkeVByZWNhY2hlZCkge1xuICAgICAgY29uc3QgcHJlY2FjaGVkQ291bnQgPSB1cmxzVG9QcmVjYWNoZS5sZW5ndGg7XG4gICAgICBjb25zdCBhbHJlYWR5UHJlY2FjaGVkQ291bnQgPSB1cmxzQWxyZWFkeVByZWNhY2hlZC5sZW5ndGg7XG4gICAgICBpZiAocHJlY2FjaGVkQ291bnQgfHwgYWxyZWFkeVByZWNhY2hlZENvdW50KSB7XG4gICAgICAgIGxldCBtZXNzYWdlID0gYFByZWNhY2hpbmcgJHtwcmVjYWNoZWRDb3VudH0gZmlsZSR7cHJlY2FjaGVkQ291bnQgPT09IDEgPyAnJyA6ICdzJ30uYDtcbiAgICAgICAgaWYgKGFscmVhZHlQcmVjYWNoZWRDb3VudCA+IDApIHtcbiAgICAgICAgICBtZXNzYWdlICs9IGAgJHthbHJlYWR5UHJlY2FjaGVkQ291bnR9IGAgKyBgZmlsZSR7YWxyZWFkeVByZWNhY2hlZENvdW50ID09PSAxID8gJyBpcycgOiAncyBhcmUnfSBhbHJlYWR5IGNhY2hlZC5gO1xuICAgICAgICB9XG4gICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChtZXNzYWdlKTtcbiAgICAgICAgX25lc3RlZEdyb3VwKGBWaWV3IG5ld2x5IHByZWNhY2hlZCBVUkxzLmAsIHVybHNUb1ByZWNhY2hlKTtcbiAgICAgICAgX25lc3RlZEdyb3VwKGBWaWV3IHByZXZpb3VzbHkgcHJlY2FjaGVkIFVSTHMuYCwgdXJsc0FscmVhZHlQcmVjYWNoZWQpO1xuICAgICAgICBsb2dnZXIuZ3JvdXBFbmQoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBsZXQgc3VwcG9ydFN0YXR1cztcbiAgICAvKipcbiAgICAgKiBBIHV0aWxpdHkgZnVuY3Rpb24gdGhhdCBkZXRlcm1pbmVzIHdoZXRoZXIgdGhlIGN1cnJlbnQgYnJvd3NlciBzdXBwb3J0c1xuICAgICAqIGNvbnN0cnVjdGluZyBhIG5ldyBgUmVzcG9uc2VgIGZyb20gYSBgcmVzcG9uc2UuYm9keWAgc3RyZWFtLlxuICAgICAqXG4gICAgICogQHJldHVybiB7Ym9vbGVhbn0gYHRydWVgLCBpZiB0aGUgY3VycmVudCBicm93c2VyIGNhbiBzdWNjZXNzZnVsbHlcbiAgICAgKiAgICAgY29uc3RydWN0IGEgYFJlc3BvbnNlYCBmcm9tIGEgYHJlc3BvbnNlLmJvZHlgIHN0cmVhbSwgYGZhbHNlYCBvdGhlcndpc2UuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNhbkNvbnN0cnVjdFJlc3BvbnNlRnJvbUJvZHlTdHJlYW0oKSB7XG4gICAgICBpZiAoc3VwcG9ydFN0YXR1cyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGNvbnN0IHRlc3RSZXNwb25zZSA9IG5ldyBSZXNwb25zZSgnJyk7XG4gICAgICAgIGlmICgnYm9keScgaW4gdGVzdFJlc3BvbnNlKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIG5ldyBSZXNwb25zZSh0ZXN0UmVzcG9uc2UuYm9keSk7XG4gICAgICAgICAgICBzdXBwb3J0U3RhdHVzID0gdHJ1ZTtcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgc3VwcG9ydFN0YXR1cyA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzdXBwb3J0U3RhdHVzID0gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4gc3VwcG9ydFN0YXR1cztcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBbGxvd3MgZGV2ZWxvcGVycyB0byBjb3B5IGEgcmVzcG9uc2UgYW5kIG1vZGlmeSBpdHMgYGhlYWRlcnNgLCBgc3RhdHVzYCxcbiAgICAgKiBvciBgc3RhdHVzVGV4dGAgdmFsdWVzICh0aGUgdmFsdWVzIHNldHRhYmxlIHZpYSBhXG4gICAgICogW2BSZXNwb25zZUluaXRgXXtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUmVzcG9uc2UvUmVzcG9uc2UjU3ludGF4fVxuICAgICAqIG9iamVjdCBpbiB0aGUgY29uc3RydWN0b3IpLlxuICAgICAqIFRvIG1vZGlmeSB0aGVzZSB2YWx1ZXMsIHBhc3MgYSBmdW5jdGlvbiBhcyB0aGUgc2Vjb25kIGFyZ3VtZW50LiBUaGF0XG4gICAgICogZnVuY3Rpb24gd2lsbCBiZSBpbnZva2VkIHdpdGggYSBzaW5nbGUgb2JqZWN0IHdpdGggdGhlIHJlc3BvbnNlIHByb3BlcnRpZXNcbiAgICAgKiBge2hlYWRlcnMsIHN0YXR1cywgc3RhdHVzVGV4dH1gLiBUaGUgcmV0dXJuIHZhbHVlIG9mIHRoaXMgZnVuY3Rpb24gd2lsbFxuICAgICAqIGJlIHVzZWQgYXMgdGhlIGBSZXNwb25zZUluaXRgIGZvciB0aGUgbmV3IGBSZXNwb25zZWAuIFRvIGNoYW5nZSB0aGUgdmFsdWVzXG4gICAgICogZWl0aGVyIG1vZGlmeSB0aGUgcGFzc2VkIHBhcmFtZXRlcihzKSBhbmQgcmV0dXJuIGl0LCBvciByZXR1cm4gYSB0b3RhbGx5XG4gICAgICogbmV3IG9iamVjdC5cbiAgICAgKlxuICAgICAqIFRoaXMgbWV0aG9kIGlzIGludGVudGlvbmFsbHkgbGltaXRlZCB0byBzYW1lLW9yaWdpbiByZXNwb25zZXMsIHJlZ2FyZGxlc3Mgb2ZcbiAgICAgKiB3aGV0aGVyIENPUlMgd2FzIHVzZWQgb3Igbm90LlxuICAgICAqXG4gICAgICogQHBhcmFtIHtSZXNwb25zZX0gcmVzcG9uc2VcbiAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBtb2RpZmllclxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LWNvcmVcbiAgICAgKi9cbiAgICBhc3luYyBmdW5jdGlvbiBjb3B5UmVzcG9uc2UocmVzcG9uc2UsIG1vZGlmaWVyKSB7XG4gICAgICBsZXQgb3JpZ2luID0gbnVsbDtcbiAgICAgIC8vIElmIHJlc3BvbnNlLnVybCBpc24ndCBzZXQsIGFzc3VtZSBpdCdzIGNyb3NzLW9yaWdpbiBhbmQga2VlcCBvcmlnaW4gbnVsbC5cbiAgICAgIGlmIChyZXNwb25zZS51cmwpIHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VVUkwgPSBuZXcgVVJMKHJlc3BvbnNlLnVybCk7XG4gICAgICAgIG9yaWdpbiA9IHJlc3BvbnNlVVJMLm9yaWdpbjtcbiAgICAgIH1cbiAgICAgIGlmIChvcmlnaW4gIT09IHNlbGYubG9jYXRpb24ub3JpZ2luKSB7XG4gICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2Nyb3NzLW9yaWdpbi1jb3B5LXJlc3BvbnNlJywge1xuICAgICAgICAgIG9yaWdpblxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNsb25lZFJlc3BvbnNlID0gcmVzcG9uc2UuY2xvbmUoKTtcbiAgICAgIC8vIENyZWF0ZSBhIGZyZXNoIGBSZXNwb25zZUluaXRgIG9iamVjdCBieSBjbG9uaW5nIHRoZSBoZWFkZXJzLlxuICAgICAgY29uc3QgcmVzcG9uc2VJbml0ID0ge1xuICAgICAgICBoZWFkZXJzOiBuZXcgSGVhZGVycyhjbG9uZWRSZXNwb25zZS5oZWFkZXJzKSxcbiAgICAgICAgc3RhdHVzOiBjbG9uZWRSZXNwb25zZS5zdGF0dXMsXG4gICAgICAgIHN0YXR1c1RleHQ6IGNsb25lZFJlc3BvbnNlLnN0YXR1c1RleHRcbiAgICAgIH07XG4gICAgICAvLyBBcHBseSBhbnkgdXNlciBtb2RpZmljYXRpb25zLlxuICAgICAgY29uc3QgbW9kaWZpZWRSZXNwb25zZUluaXQgPSByZXNwb25zZUluaXQ7XG4gICAgICAvLyBDcmVhdGUgdGhlIG5ldyByZXNwb25zZSBmcm9tIHRoZSBib2R5IHN0cmVhbSBhbmQgYFJlc3BvbnNlSW5pdGBcbiAgICAgIC8vIG1vZGlmaWNhdGlvbnMuIE5vdGU6IG5vdCBhbGwgYnJvd3NlcnMgc3VwcG9ydCB0aGUgUmVzcG9uc2UuYm9keSBzdHJlYW0sXG4gICAgICAvLyBzbyBmYWxsIGJhY2sgdG8gcmVhZGluZyB0aGUgZW50aXJlIGJvZHkgaW50byBtZW1vcnkgYXMgYSBibG9iLlxuICAgICAgY29uc3QgYm9keSA9IGNhbkNvbnN0cnVjdFJlc3BvbnNlRnJvbUJvZHlTdHJlYW0oKSA/IGNsb25lZFJlc3BvbnNlLmJvZHkgOiBhd2FpdCBjbG9uZWRSZXNwb25zZS5ibG9iKCk7XG4gICAgICByZXR1cm4gbmV3IFJlc3BvbnNlKGJvZHksIG1vZGlmaWVkUmVzcG9uc2VJbml0KTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgZnVuY3Rpb24gc3RyaXBQYXJhbXMoZnVsbFVSTCwgaWdub3JlUGFyYW1zKSB7XG4gICAgICBjb25zdCBzdHJpcHBlZFVSTCA9IG5ldyBVUkwoZnVsbFVSTCk7XG4gICAgICBmb3IgKGNvbnN0IHBhcmFtIG9mIGlnbm9yZVBhcmFtcykge1xuICAgICAgICBzdHJpcHBlZFVSTC5zZWFyY2hQYXJhbXMuZGVsZXRlKHBhcmFtKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHJpcHBlZFVSTC5ocmVmO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBNYXRjaGVzIGFuIGl0ZW0gaW4gdGhlIGNhY2hlLCBpZ25vcmluZyBzcGVjaWZpYyBVUkwgcGFyYW1zLiBUaGlzIGlzIHNpbWlsYXJcbiAgICAgKiB0byB0aGUgYGlnbm9yZVNlYXJjaGAgb3B0aW9uLCBidXQgaXQgYWxsb3dzIHlvdSB0byBpZ25vcmUganVzdCBzcGVjaWZpY1xuICAgICAqIHBhcmFtcyAod2hpbGUgY29udGludWluZyB0byBtYXRjaCBvbiB0aGUgb3RoZXJzKS5cbiAgICAgKlxuICAgICAqIEBwcml2YXRlXG4gICAgICogQHBhcmFtIHtDYWNoZX0gY2FjaGVcbiAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3RcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gbWF0Y2hPcHRpb25zXG4gICAgICogQHBhcmFtIHtBcnJheTxzdHJpbmc+fSBpZ25vcmVQYXJhbXNcbiAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlfHVuZGVmaW5lZD59XG4gICAgICovXG4gICAgYXN5bmMgZnVuY3Rpb24gY2FjaGVNYXRjaElnbm9yZVBhcmFtcyhjYWNoZSwgcmVxdWVzdCwgaWdub3JlUGFyYW1zLCBtYXRjaE9wdGlvbnMpIHtcbiAgICAgIGNvbnN0IHN0cmlwcGVkUmVxdWVzdFVSTCA9IHN0cmlwUGFyYW1zKHJlcXVlc3QudXJsLCBpZ25vcmVQYXJhbXMpO1xuICAgICAgLy8gSWYgdGhlIHJlcXVlc3QgZG9lc24ndCBpbmNsdWRlIGFueSBpZ25vcmVkIHBhcmFtcywgbWF0Y2ggYXMgbm9ybWFsLlxuICAgICAgaWYgKHJlcXVlc3QudXJsID09PSBzdHJpcHBlZFJlcXVlc3RVUkwpIHtcbiAgICAgICAgcmV0dXJuIGNhY2hlLm1hdGNoKHJlcXVlc3QsIG1hdGNoT3B0aW9ucyk7XG4gICAgICB9XG4gICAgICAvLyBPdGhlcndpc2UsIG1hdGNoIGJ5IGNvbXBhcmluZyBrZXlzXG4gICAgICBjb25zdCBrZXlzT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgbWF0Y2hPcHRpb25zKSwge1xuICAgICAgICBpZ25vcmVTZWFyY2g6IHRydWVcbiAgICAgIH0pO1xuICAgICAgY29uc3QgY2FjaGVLZXlzID0gYXdhaXQgY2FjaGUua2V5cyhyZXF1ZXN0LCBrZXlzT3B0aW9ucyk7XG4gICAgICBmb3IgKGNvbnN0IGNhY2hlS2V5IG9mIGNhY2hlS2V5cykge1xuICAgICAgICBjb25zdCBzdHJpcHBlZENhY2hlS2V5VVJMID0gc3RyaXBQYXJhbXMoY2FjaGVLZXkudXJsLCBpZ25vcmVQYXJhbXMpO1xuICAgICAgICBpZiAoc3RyaXBwZWRSZXF1ZXN0VVJMID09PSBzdHJpcHBlZENhY2hlS2V5VVJMKSB7XG4gICAgICAgICAgcmV0dXJuIGNhY2hlLm1hdGNoKGNhY2hlS2V5LCBtYXRjaE9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogVGhlIERlZmVycmVkIGNsYXNzIGNvbXBvc2VzIFByb21pc2VzIGluIGEgd2F5IHRoYXQgYWxsb3dzIGZvciB0aGVtIHRvIGJlXG4gICAgICogcmVzb2x2ZWQgb3IgcmVqZWN0ZWQgZnJvbSBvdXRzaWRlIHRoZSBjb25zdHJ1Y3Rvci4gSW4gbW9zdCBjYXNlcyBwcm9taXNlc1xuICAgICAqIHNob3VsZCBiZSB1c2VkIGRpcmVjdGx5LCBidXQgRGVmZXJyZWRzIGNhbiBiZSBuZWNlc3Nhcnkgd2hlbiB0aGUgbG9naWMgdG9cbiAgICAgKiByZXNvbHZlIGEgcHJvbWlzZSBtdXN0IGJlIHNlcGFyYXRlLlxuICAgICAqXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBjbGFzcyBEZWZlcnJlZCB7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBwcm9taXNlIGFuZCBleHBvc2VzIGl0cyByZXNvbHZlIGFuZCByZWplY3QgZnVuY3Rpb25zIGFzIG1ldGhvZHMuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgdGhpcy5yZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgICAgICB0aGlzLnJlamVjdCA9IHJlamVjdDtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLy8gQ2FsbGJhY2tzIHRvIGJlIGV4ZWN1dGVkIHdoZW5ldmVyIHRoZXJlJ3MgYSBxdW90YSBlcnJvci5cbiAgICAvLyBDYW4ndCBjaGFuZ2UgRnVuY3Rpb24gdHlwZSByaWdodCBub3cuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHlwZXNcbiAgICBjb25zdCBxdW90YUVycm9yQ2FsbGJhY2tzID0gbmV3IFNldCgpO1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogUnVucyBhbGwgb2YgdGhlIGNhbGxiYWNrIGZ1bmN0aW9ucywgb25lIGF0IGEgdGltZSBzZXF1ZW50aWFsbHksIGluIHRoZSBvcmRlclxuICAgICAqIGluIHdoaWNoIHRoZXkgd2VyZSByZWdpc3RlcmVkLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtY29yZVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZVF1b3RhRXJyb3JDYWxsYmFja3MoKSB7XG4gICAgICB7XG4gICAgICAgIGxvZ2dlci5sb2coYEFib3V0IHRvIHJ1biAke3F1b3RhRXJyb3JDYWxsYmFja3Muc2l6ZX0gYCArIGBjYWxsYmFja3MgdG8gY2xlYW4gdXAgY2FjaGVzLmApO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiBxdW90YUVycm9yQ2FsbGJhY2tzKSB7XG4gICAgICAgIGF3YWl0IGNhbGxiYWNrKCk7XG4gICAgICAgIHtcbiAgICAgICAgICBsb2dnZXIubG9nKGNhbGxiYWNrLCAnaXMgY29tcGxldGUuJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHtcbiAgICAgICAgbG9nZ2VyLmxvZygnRmluaXNoZWQgcnVubmluZyBjYWxsYmFja3MuJyk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgYW5kIHRoZSBwYXNzZWQgbnVtYmVyIG9mIG1pbGxpc2Vjb25kcy5cbiAgICAgKiBUaGlzIHV0aWxpdHkgaXMgYW4gYXN5bmMvYXdhaXQtZnJpZW5kbHkgdmVyc2lvbiBvZiBgc2V0VGltZW91dGAuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gbXNcbiAgICAgKiBAcmV0dXJuIHtQcm9taXNlfVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgZnVuY3Rpb24gdGltZW91dChtcykge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCBtcykpO1xuICAgIH1cblxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICB0cnkge1xuICAgICAgc2VsZlsnd29ya2JveDpzdHJhdGVnaWVzOjcuNC4wJ10gJiYgXygpO1xuICAgIH0gY2F0Y2ggKGUpIHt9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBmdW5jdGlvbiB0b1JlcXVlc3QoaW5wdXQpIHtcbiAgICAgIHJldHVybiB0eXBlb2YgaW5wdXQgPT09ICdzdHJpbmcnID8gbmV3IFJlcXVlc3QoaW5wdXQpIDogaW5wdXQ7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEEgY2xhc3MgY3JlYXRlZCBldmVyeSB0aW1lIGEgU3RyYXRlZ3kgaW5zdGFuY2UgY2FsbHNcbiAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5fmhhbmRsZX0gb3JcbiAgICAgKiB7QGxpbmsgd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5fmhhbmRsZUFsbH0gdGhhdCB3cmFwcyBhbGwgZmV0Y2ggYW5kXG4gICAgICogY2FjaGUgYWN0aW9ucyBhcm91bmQgcGx1Z2luIGNhbGxiYWNrcyBhbmQga2VlcHMgdHJhY2sgb2Ygd2hlbiB0aGUgc3RyYXRlZ3lcbiAgICAgKiBpcyBcImRvbmVcIiAoaS5lLiBhbGwgYWRkZWQgYGV2ZW50LndhaXRVbnRpbCgpYCBwcm9taXNlcyBoYXZlIHJlc29sdmVkKS5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXNcbiAgICAgKi9cbiAgICBjbGFzcyBTdHJhdGVneUhhbmRsZXIge1xuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIGFzc29jaWF0ZWQgd2l0aCB0aGUgcGFzc2VkIHN0cmF0ZWd5IGFuZCBldmVudFxuICAgICAgICogdGhhdCdzIGhhbmRsaW5nIHRoZSByZXF1ZXN0LlxuICAgICAgICpcbiAgICAgICAqIFRoZSBjb25zdHJ1Y3RvciBhbHNvIGluaXRpYWxpemVzIHRoZSBzdGF0ZSB0aGF0IHdpbGwgYmUgcGFzc2VkIHRvIGVhY2ggb2ZcbiAgICAgICAqIHRoZSBwbHVnaW5zIGhhbmRsaW5nIHRoaXMgcmVxdWVzdC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneX0gc3RyYXRlZ3lcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBvcHRpb25zLnJlcXVlc3QgQSByZXF1ZXN0IHRvIHJ1biB0aGlzIHN0cmF0ZWd5IGZvci5cbiAgICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBvcHRpb25zLmV2ZW50IFRoZSBldmVudCBhc3NvY2lhdGVkIHdpdGggdGhlXG4gICAgICAgKiAgICAgcmVxdWVzdC5cbiAgICAgICAqIEBwYXJhbSB7VVJMfSBbb3B0aW9ucy51cmxdXG4gICAgICAgKiBAcGFyYW0geyp9IFtvcHRpb25zLnBhcmFtc10gVGhlIHJldHVybiB2YWx1ZSBmcm9tIHRoZVxuICAgICAgICogICAgIHtAbGluayB3b3JrYm94LXJvdXRpbmd+bWF0Y2hDYWxsYmFja30gKGlmIGFwcGxpY2FibGUpLlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihzdHJhdGVneSwgb3B0aW9ucykge1xuICAgICAgICB0aGlzLl9jYWNoZUtleXMgPSB7fTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSByZXF1ZXN0IHRoZSBzdHJhdGVneSBpcyBwZXJmb3JtaW5nIChwYXNzZWQgdG8gdGhlIHN0cmF0ZWd5J3NcbiAgICAgICAgICogYGhhbmRsZSgpYCBvciBgaGFuZGxlQWxsKClgIG1ldGhvZCkuXG4gICAgICAgICAqIEBuYW1lIHJlcXVlc3RcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEB0eXBlIHtSZXF1ZXN0fVxuICAgICAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5SGFuZGxlclxuICAgICAgICAgKi9cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSBldmVudCBhc3NvY2lhdGVkIHdpdGggdGhpcyByZXF1ZXN0LlxuICAgICAgICAgKiBAbmFtZSBldmVudFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHR5cGUge0V4dGVuZGFibGVFdmVudH1cbiAgICAgICAgICogQG1lbWJlcm9mIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJcbiAgICAgICAgICovXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBBIGBVUkxgIGluc3RhbmNlIG9mIGByZXF1ZXN0LnVybGAgKGlmIHBhc3NlZCB0byB0aGUgc3RyYXRlZ3knc1xuICAgICAgICAgKiBgaGFuZGxlKClgIG9yIGBoYW5kbGVBbGwoKWAgbWV0aG9kKS5cbiAgICAgICAgICogTm90ZTogdGhlIGB1cmxgIHBhcmFtIHdpbGwgYmUgcHJlc2VudCBpZiB0aGUgc3RyYXRlZ3kgd2FzIGludm9rZWRcbiAgICAgICAgICogZnJvbSBhIHdvcmtib3ggYFJvdXRlYCBvYmplY3QuXG4gICAgICAgICAqIEBuYW1lIHVybFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHR5cGUge1VSTHx1bmRlZmluZWR9XG4gICAgICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lIYW5kbGVyXG4gICAgICAgICAqL1xuICAgICAgICAvKipcbiAgICAgICAgICogQSBgcGFyYW1gIHZhbHVlIChpZiBwYXNzZWQgdG8gdGhlIHN0cmF0ZWd5J3NcbiAgICAgICAgICogYGhhbmRsZSgpYCBvciBgaGFuZGxlQWxsKClgIG1ldGhvZCkuXG4gICAgICAgICAqIE5vdGU6IHRoZSBgcGFyYW1gIHBhcmFtIHdpbGwgYmUgcHJlc2VudCBpZiB0aGUgc3RyYXRlZ3kgd2FzIGludm9rZWRcbiAgICAgICAgICogZnJvbSBhIHdvcmtib3ggYFJvdXRlYCBvYmplY3QgYW5kIHRoZVxuICAgICAgICAgKiB7QGxpbmsgd29ya2JveC1yb3V0aW5nfm1hdGNoQ2FsbGJhY2t9IHJldHVybmVkXG4gICAgICAgICAqIGEgdHJ1dGh5IHZhbHVlIChpdCB3aWxsIGJlIHRoYXQgdmFsdWUpLlxuICAgICAgICAgKiBAbmFtZSBwYXJhbXNcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEB0eXBlIHsqfHVuZGVmaW5lZH1cbiAgICAgICAgICogQG1lbWJlcm9mIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJcbiAgICAgICAgICovXG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNJbnN0YW5jZShvcHRpb25zLmV2ZW50LCBFeHRlbmRhYmxlRXZlbnQsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXN0cmF0ZWdpZXMnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnU3RyYXRlZ3lIYW5kbGVyJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnb3B0aW9ucy5ldmVudCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBPYmplY3QuYXNzaWduKHRoaXMsIG9wdGlvbnMpO1xuICAgICAgICB0aGlzLmV2ZW50ID0gb3B0aW9ucy5ldmVudDtcbiAgICAgICAgdGhpcy5fc3RyYXRlZ3kgPSBzdHJhdGVneTtcbiAgICAgICAgdGhpcy5faGFuZGxlckRlZmVycmVkID0gbmV3IERlZmVycmVkKCk7XG4gICAgICAgIHRoaXMuX2V4dGVuZExpZmV0aW1lUHJvbWlzZXMgPSBbXTtcbiAgICAgICAgLy8gQ29weSB0aGUgcGx1Z2lucyBsaXN0IChzaW5jZSBpdCdzIG11dGFibGUgb24gdGhlIHN0cmF0ZWd5KSxcbiAgICAgICAgLy8gc28gYW55IG11dGF0aW9ucyBkb24ndCBhZmZlY3QgdGhpcyBoYW5kbGVyIGluc3RhbmNlLlxuICAgICAgICB0aGlzLl9wbHVnaW5zID0gWy4uLnN0cmF0ZWd5LnBsdWdpbnNdO1xuICAgICAgICB0aGlzLl9wbHVnaW5TdGF0ZU1hcCA9IG5ldyBNYXAoKTtcbiAgICAgICAgZm9yIChjb25zdCBwbHVnaW4gb2YgdGhpcy5fcGx1Z2lucykge1xuICAgICAgICAgIHRoaXMuX3BsdWdpblN0YXRlTWFwLnNldChwbHVnaW4sIHt9KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmV2ZW50LndhaXRVbnRpbCh0aGlzLl9oYW5kbGVyRGVmZXJyZWQucHJvbWlzZSk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEZldGNoZXMgYSBnaXZlbiByZXF1ZXN0IChhbmQgaW52b2tlcyBhbnkgYXBwbGljYWJsZSBwbHVnaW4gY2FsbGJhY2tcbiAgICAgICAqIG1ldGhvZHMpIHVzaW5nIHRoZSBgZmV0Y2hPcHRpb25zYCAoZm9yIG5vbi1uYXZpZ2F0aW9uIHJlcXVlc3RzKSBhbmRcbiAgICAgICAqIGBwbHVnaW5zYCBkZWZpbmVkIG9uIHRoZSBgU3RyYXRlZ3lgIG9iamVjdC5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgZm9sbG93aW5nIHBsdWdpbiBsaWZlY3ljbGUgbWV0aG9kcyBhcmUgaW52b2tlZCB3aGVuIHVzaW5nIHRoaXMgbWV0aG9kOlxuICAgICAgICogLSBgcmVxdWVzdFdpbGxGZXRjaCgpYFxuICAgICAgICogLSBgZmV0Y2hEaWRTdWNjZWVkKClgXG4gICAgICAgKiAtIGBmZXRjaERpZEZhaWwoKWBcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBpbnB1dCBUaGUgVVJMIG9yIHJlcXVlc3QgdG8gZmV0Y2guXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlPn1cbiAgICAgICAqL1xuICAgICAgYXN5bmMgZmV0Y2goaW5wdXQpIHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGV2ZW50XG4gICAgICAgIH0gPSB0aGlzO1xuICAgICAgICBsZXQgcmVxdWVzdCA9IHRvUmVxdWVzdChpbnB1dCk7XG4gICAgICAgIGlmIChyZXF1ZXN0Lm1vZGUgPT09ICduYXZpZ2F0ZScgJiYgZXZlbnQgaW5zdGFuY2VvZiBGZXRjaEV2ZW50ICYmIGV2ZW50LnByZWxvYWRSZXNwb25zZSkge1xuICAgICAgICAgIGNvbnN0IHBvc3NpYmxlUHJlbG9hZFJlc3BvbnNlID0gYXdhaXQgZXZlbnQucHJlbG9hZFJlc3BvbnNlO1xuICAgICAgICAgIGlmIChwb3NzaWJsZVByZWxvYWRSZXNwb25zZSkge1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBsb2dnZXIubG9nKGBVc2luZyBhIHByZWxvYWRlZCBuYXZpZ2F0aW9uIHJlc3BvbnNlIGZvciBgICsgYCcke2dldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKX0nYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcG9zc2libGVQcmVsb2FkUmVzcG9uc2U7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIElmIHRoZXJlIGlzIGEgZmV0Y2hEaWRGYWlsIHBsdWdpbiwgd2UgbmVlZCB0byBzYXZlIGEgY2xvbmUgb2YgdGhlXG4gICAgICAgIC8vIG9yaWdpbmFsIHJlcXVlc3QgYmVmb3JlIGl0J3MgZWl0aGVyIG1vZGlmaWVkIGJ5IGEgcmVxdWVzdFdpbGxGZXRjaFxuICAgICAgICAvLyBwbHVnaW4gb3IgYmVmb3JlIHRoZSBvcmlnaW5hbCByZXF1ZXN0J3MgYm9keSBpcyBjb25zdW1lZCB2aWEgZmV0Y2goKS5cbiAgICAgICAgY29uc3Qgb3JpZ2luYWxSZXF1ZXN0ID0gdGhpcy5oYXNDYWxsYmFjaygnZmV0Y2hEaWRGYWlsJykgPyByZXF1ZXN0LmNsb25lKCkgOiBudWxsO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGZvciAoY29uc3QgY2Igb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKCdyZXF1ZXN0V2lsbEZldGNoJykpIHtcbiAgICAgICAgICAgIHJlcXVlc3QgPSBhd2FpdCBjYih7XG4gICAgICAgICAgICAgIHJlcXVlc3Q6IHJlcXVlc3QuY2xvbmUoKSxcbiAgICAgICAgICAgICAgZXZlbnRcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdwbHVnaW4tZXJyb3ItcmVxdWVzdC13aWxsLWZldGNoJywge1xuICAgICAgICAgICAgICB0aHJvd25FcnJvck1lc3NhZ2U6IGVyci5tZXNzYWdlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gVGhlIHJlcXVlc3QgY2FuIGJlIGFsdGVyZWQgYnkgcGx1Z2lucyB3aXRoIGByZXF1ZXN0V2lsbEZldGNoYCBtYWtpbmdcbiAgICAgICAgLy8gdGhlIG9yaWdpbmFsIHJlcXVlc3QgKG1vc3QgbGlrZWx5IGZyb20gYSBgZmV0Y2hgIGV2ZW50KSBkaWZmZXJlbnRcbiAgICAgICAgLy8gZnJvbSB0aGUgUmVxdWVzdCB3ZSBtYWtlLiBQYXNzIGJvdGggdG8gYGZldGNoRGlkRmFpbGAgdG8gYWlkIGRlYnVnZ2luZy5cbiAgICAgICAgY29uc3QgcGx1Z2luRmlsdGVyZWRSZXF1ZXN0ID0gcmVxdWVzdC5jbG9uZSgpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGxldCBmZXRjaFJlc3BvbnNlO1xuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzE3OTZcbiAgICAgICAgICBmZXRjaFJlc3BvbnNlID0gYXdhaXQgZmV0Y2gocmVxdWVzdCwgcmVxdWVzdC5tb2RlID09PSAnbmF2aWdhdGUnID8gdW5kZWZpbmVkIDogdGhpcy5fc3RyYXRlZ3kuZmV0Y2hPcHRpb25zKTtcbiAgICAgICAgICBpZiAoXCJkZXZlbG9wbWVudFwiICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgTmV0d29yayByZXF1ZXN0IGZvciBgICsgYCcke2dldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKX0nIHJldHVybmVkIGEgcmVzcG9uc2Ugd2l0aCBgICsgYHN0YXR1cyAnJHtmZXRjaFJlc3BvbnNlLnN0YXR1c30nLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIHRoaXMuaXRlcmF0ZUNhbGxiYWNrcygnZmV0Y2hEaWRTdWNjZWVkJykpIHtcbiAgICAgICAgICAgIGZldGNoUmVzcG9uc2UgPSBhd2FpdCBjYWxsYmFjayh7XG4gICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICByZXF1ZXN0OiBwbHVnaW5GaWx0ZXJlZFJlcXVlc3QsXG4gICAgICAgICAgICAgIHJlc3BvbnNlOiBmZXRjaFJlc3BvbnNlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGZldGNoUmVzcG9uc2U7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmxvZyhgTmV0d29yayByZXF1ZXN0IGZvciBgICsgYCcke2dldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKX0nIHRocmV3IGFuIGVycm9yLmAsIGVycm9yKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gYG9yaWdpbmFsUmVxdWVzdGAgd2lsbCBvbmx5IGV4aXN0IGlmIGEgYGZldGNoRGlkRmFpbGAgY2FsbGJhY2tcbiAgICAgICAgICAvLyBpcyBiZWluZyB1c2VkIChzZWUgYWJvdmUpLlxuICAgICAgICAgIGlmIChvcmlnaW5hbFJlcXVlc3QpIHtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMucnVuQ2FsbGJhY2tzKCdmZXRjaERpZEZhaWwnLCB7XG4gICAgICAgICAgICAgIGVycm9yOiBlcnJvcixcbiAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgIG9yaWdpbmFsUmVxdWVzdDogb3JpZ2luYWxSZXF1ZXN0LmNsb25lKCksXG4gICAgICAgICAgICAgIHJlcXVlc3Q6IHBsdWdpbkZpbHRlcmVkUmVxdWVzdC5jbG9uZSgpXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQ2FsbHMgYHRoaXMuZmV0Y2goKWAgYW5kIChpbiB0aGUgYmFja2dyb3VuZCkgcnVucyBgdGhpcy5jYWNoZVB1dCgpYCBvblxuICAgICAgICogdGhlIHJlc3BvbnNlIGdlbmVyYXRlZCBieSBgdGhpcy5mZXRjaCgpYC5cbiAgICAgICAqXG4gICAgICAgKiBUaGUgY2FsbCB0byBgdGhpcy5jYWNoZVB1dCgpYCBhdXRvbWF0aWNhbGx5IGludm9rZXMgYHRoaXMud2FpdFVudGlsKClgLFxuICAgICAgICogc28geW91IGRvIG5vdCBoYXZlIHRvIG1hbnVhbGx5IGNhbGwgYHdhaXRVbnRpbCgpYCBvbiB0aGUgZXZlbnQuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fHN0cmluZ30gaW5wdXQgVGhlIHJlcXVlc3Qgb3IgVVJMIHRvIGZldGNoIGFuZCBjYWNoZS5cbiAgICAgICAqIEByZXR1cm4ge1Byb21pc2U8UmVzcG9uc2U+fVxuICAgICAgICovXG4gICAgICBhc3luYyBmZXRjaEFuZENhY2hlUHV0KGlucHV0KSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5mZXRjaChpbnB1dCk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQ2xvbmUgPSByZXNwb25zZS5jbG9uZSgpO1xuICAgICAgICB2b2lkIHRoaXMud2FpdFVudGlsKHRoaXMuY2FjaGVQdXQoaW5wdXQsIHJlc3BvbnNlQ2xvbmUpKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBNYXRjaGVzIGEgcmVxdWVzdCBmcm9tIHRoZSBjYWNoZSAoYW5kIGludm9rZXMgYW55IGFwcGxpY2FibGUgcGx1Z2luXG4gICAgICAgKiBjYWxsYmFjayBtZXRob2RzKSB1c2luZyB0aGUgYGNhY2hlTmFtZWAsIGBtYXRjaE9wdGlvbnNgLCBhbmQgYHBsdWdpbnNgXG4gICAgICAgKiBkZWZpbmVkIG9uIHRoZSBzdHJhdGVneSBvYmplY3QuXG4gICAgICAgKlxuICAgICAgICogVGhlIGZvbGxvd2luZyBwbHVnaW4gbGlmZWN5Y2xlIG1ldGhvZHMgYXJlIGludm9rZWQgd2hlbiB1c2luZyB0aGlzIG1ldGhvZDpcbiAgICAgICAqIC0gY2FjaGVLZXlXaWxsQmVVc2VkKClcbiAgICAgICAqIC0gY2FjaGVkUmVzcG9uc2VXaWxsQmVVc2VkKClcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBrZXkgVGhlIFJlcXVlc3Qgb3IgVVJMIHRvIHVzZSBhcyB0aGUgY2FjaGUga2V5LlxuICAgICAgICogQHJldHVybiB7UHJvbWlzZTxSZXNwb25zZXx1bmRlZmluZWQ+fSBBIG1hdGNoaW5nIHJlc3BvbnNlLCBpZiBmb3VuZC5cbiAgICAgICAqL1xuICAgICAgYXN5bmMgY2FjaGVNYXRjaChrZXkpIHtcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHRvUmVxdWVzdChrZXkpO1xuICAgICAgICBsZXQgY2FjaGVkUmVzcG9uc2U7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBjYWNoZU5hbWUsXG4gICAgICAgICAgbWF0Y2hPcHRpb25zXG4gICAgICAgIH0gPSB0aGlzLl9zdHJhdGVneTtcbiAgICAgICAgY29uc3QgZWZmZWN0aXZlUmVxdWVzdCA9IGF3YWl0IHRoaXMuZ2V0Q2FjaGVLZXkocmVxdWVzdCwgJ3JlYWQnKTtcbiAgICAgICAgY29uc3QgbXVsdGlNYXRjaE9wdGlvbnMgPSBPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIG1hdGNoT3B0aW9ucyksIHtcbiAgICAgICAgICBjYWNoZU5hbWVcbiAgICAgICAgfSk7XG4gICAgICAgIGNhY2hlZFJlc3BvbnNlID0gYXdhaXQgY2FjaGVzLm1hdGNoKGVmZmVjdGl2ZVJlcXVlc3QsIG11bHRpTWF0Y2hPcHRpb25zKTtcbiAgICAgICAge1xuICAgICAgICAgIGlmIChjYWNoZWRSZXNwb25zZSkge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBGb3VuZCBhIGNhY2hlZCByZXNwb25zZSBpbiAnJHtjYWNoZU5hbWV9Jy5gKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBObyBjYWNoZWQgcmVzcG9uc2UgZm91bmQgaW4gJyR7Y2FjaGVOYW1lfScuYCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKCdjYWNoZWRSZXNwb25zZVdpbGxCZVVzZWQnKSkge1xuICAgICAgICAgIGNhY2hlZFJlc3BvbnNlID0gKGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgICAgIG1hdGNoT3B0aW9ucyxcbiAgICAgICAgICAgIGNhY2hlZFJlc3BvbnNlLFxuICAgICAgICAgICAgcmVxdWVzdDogZWZmZWN0aXZlUmVxdWVzdCxcbiAgICAgICAgICAgIGV2ZW50OiB0aGlzLmV2ZW50XG4gICAgICAgICAgfSkpIHx8IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY2FjaGVkUmVzcG9uc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFB1dHMgYSByZXF1ZXN0L3Jlc3BvbnNlIHBhaXIgaW4gdGhlIGNhY2hlIChhbmQgaW52b2tlcyBhbnkgYXBwbGljYWJsZVxuICAgICAgICogcGx1Z2luIGNhbGxiYWNrIG1ldGhvZHMpIHVzaW5nIHRoZSBgY2FjaGVOYW1lYCBhbmQgYHBsdWdpbnNgIGRlZmluZWQgb25cbiAgICAgICAqIHRoZSBzdHJhdGVneSBvYmplY3QuXG4gICAgICAgKlxuICAgICAgICogVGhlIGZvbGxvd2luZyBwbHVnaW4gbGlmZWN5Y2xlIG1ldGhvZHMgYXJlIGludm9rZWQgd2hlbiB1c2luZyB0aGlzIG1ldGhvZDpcbiAgICAgICAqIC0gY2FjaGVLZXlXaWxsQmVVc2VkKClcbiAgICAgICAqIC0gY2FjaGVXaWxsVXBkYXRlKClcbiAgICAgICAqIC0gY2FjaGVEaWRVcGRhdGUoKVxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdHxzdHJpbmd9IGtleSBUaGUgcmVxdWVzdCBvciBVUkwgdG8gdXNlIGFzIHRoZSBjYWNoZSBrZXkuXG4gICAgICAgKiBAcGFyYW0ge1Jlc3BvbnNlfSByZXNwb25zZSBUaGUgcmVzcG9uc2UgdG8gY2FjaGUuXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPGJvb2xlYW4+fSBgZmFsc2VgIGlmIGEgY2FjaGVXaWxsVXBkYXRlIGNhdXNlZCB0aGUgcmVzcG9uc2VcbiAgICAgICAqIG5vdCBiZSBjYWNoZWQsIGFuZCBgdHJ1ZWAgb3RoZXJ3aXNlLlxuICAgICAgICovXG4gICAgICBhc3luYyBjYWNoZVB1dChrZXksIHJlc3BvbnNlKSB7XG4gICAgICAgIGNvbnN0IHJlcXVlc3QgPSB0b1JlcXVlc3Qoa2V5KTtcbiAgICAgICAgLy8gUnVuIGluIHRoZSBuZXh0IHRhc2sgdG8gYXZvaWQgYmxvY2tpbmcgb3RoZXIgY2FjaGUgcmVhZHMuXG4gICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS93M2MvU2VydmljZVdvcmtlci9pc3N1ZXMvMTM5N1xuICAgICAgICBhd2FpdCB0aW1lb3V0KDApO1xuICAgICAgICBjb25zdCBlZmZlY3RpdmVSZXF1ZXN0ID0gYXdhaXQgdGhpcy5nZXRDYWNoZUtleShyZXF1ZXN0LCAnd3JpdGUnKTtcbiAgICAgICAge1xuICAgICAgICAgIGlmIChlZmZlY3RpdmVSZXF1ZXN0Lm1ldGhvZCAmJiBlZmZlY3RpdmVSZXF1ZXN0Lm1ldGhvZCAhPT0gJ0dFVCcpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2F0dGVtcHQtdG8tY2FjaGUtbm9uLWdldC1yZXF1ZXN0Jywge1xuICAgICAgICAgICAgICB1cmw6IGdldEZyaWVuZGx5VVJMKGVmZmVjdGl2ZVJlcXVlc3QudXJsKSxcbiAgICAgICAgICAgICAgbWV0aG9kOiBlZmZlY3RpdmVSZXF1ZXN0Lm1ldGhvZFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzI4MThcbiAgICAgICAgICBjb25zdCB2YXJ5ID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ1ZhcnknKTtcbiAgICAgICAgICBpZiAodmFyeSkge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBUaGUgcmVzcG9uc2UgZm9yICR7Z2V0RnJpZW5kbHlVUkwoZWZmZWN0aXZlUmVxdWVzdC51cmwpfSBgICsgYGhhcyBhICdWYXJ5OiAke3Zhcnl9JyBoZWFkZXIuIGAgKyBgQ29uc2lkZXIgc2V0dGluZyB0aGUge2lnbm9yZVZhcnk6IHRydWV9IG9wdGlvbiBvbiB5b3VyIHN0cmF0ZWd5IGAgKyBgdG8gZW5zdXJlIGNhY2hlIG1hdGNoaW5nIGFuZCBkZWxldGlvbiB3b3JrcyBhcyBleHBlY3RlZC5gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFyZXNwb25zZSkge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGxvZ2dlci5lcnJvcihgQ2Fubm90IGNhY2hlIG5vbi1leGlzdGVudCByZXNwb25zZSBmb3IgYCArIGAnJHtnZXRGcmllbmRseVVSTChlZmZlY3RpdmVSZXF1ZXN0LnVybCl9Jy5gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignY2FjaGUtcHV0LXdpdGgtbm8tcmVzcG9uc2UnLCB7XG4gICAgICAgICAgICB1cmw6IGdldEZyaWVuZGx5VVJMKGVmZmVjdGl2ZVJlcXVlc3QudXJsKVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlVG9DYWNoZSA9IGF3YWl0IHRoaXMuX2Vuc3VyZVJlc3BvbnNlU2FmZVRvQ2FjaGUocmVzcG9uc2UpO1xuICAgICAgICBpZiAoIXJlc3BvbnNlVG9DYWNoZSkge1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgUmVzcG9uc2UgJyR7Z2V0RnJpZW5kbHlVUkwoZWZmZWN0aXZlUmVxdWVzdC51cmwpfScgYCArIGB3aWxsIG5vdCBiZSBjYWNoZWQuYCwgcmVzcG9uc2VUb0NhY2hlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBjYWNoZU5hbWUsXG4gICAgICAgICAgbWF0Y2hPcHRpb25zXG4gICAgICAgIH0gPSB0aGlzLl9zdHJhdGVneTtcbiAgICAgICAgY29uc3QgY2FjaGUgPSBhd2FpdCBzZWxmLmNhY2hlcy5vcGVuKGNhY2hlTmFtZSk7XG4gICAgICAgIGNvbnN0IGhhc0NhY2hlVXBkYXRlQ2FsbGJhY2sgPSB0aGlzLmhhc0NhbGxiYWNrKCdjYWNoZURpZFVwZGF0ZScpO1xuICAgICAgICBjb25zdCBvbGRSZXNwb25zZSA9IGhhc0NhY2hlVXBkYXRlQ2FsbGJhY2sgPyBhd2FpdCBjYWNoZU1hdGNoSWdub3JlUGFyYW1zKFxuICAgICAgICAvLyBUT0RPKHBoaWxpcHdhbHRvbik6IHRoZSBgX19XQl9SRVZJU0lPTl9fYCBwYXJhbSBpcyBhIHByZWNhY2hpbmdcbiAgICAgICAgLy8gZmVhdHVyZS4gQ29uc2lkZXIgaW50byB3YXlzIHRvIG9ubHkgYWRkIHRoaXMgYmVoYXZpb3IgaWYgdXNpbmdcbiAgICAgICAgLy8gcHJlY2FjaGluZy5cbiAgICAgICAgY2FjaGUsIGVmZmVjdGl2ZVJlcXVlc3QuY2xvbmUoKSwgWydfX1dCX1JFVklTSU9OX18nXSwgbWF0Y2hPcHRpb25zKSA6IG51bGw7XG4gICAgICAgIHtcbiAgICAgICAgICBsb2dnZXIuZGVidWcoYFVwZGF0aW5nIHRoZSAnJHtjYWNoZU5hbWV9JyBjYWNoZSB3aXRoIGEgbmV3IFJlc3BvbnNlIGAgKyBgZm9yICR7Z2V0RnJpZW5kbHlVUkwoZWZmZWN0aXZlUmVxdWVzdC51cmwpfS5gKTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IGNhY2hlLnB1dChlZmZlY3RpdmVSZXF1ZXN0LCBoYXNDYWNoZVVwZGF0ZUNhbGxiYWNrID8gcmVzcG9uc2VUb0NhY2hlLmNsb25lKCkgOiByZXNwb25zZVRvQ2FjaGUpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0RPTUV4Y2VwdGlvbiNleGNlcHRpb24tUXVvdGFFeGNlZWRlZEVycm9yXG4gICAgICAgICAgICBpZiAoZXJyb3IubmFtZSA9PT0gJ1F1b3RhRXhjZWVkZWRFcnJvcicpIHtcbiAgICAgICAgICAgICAgYXdhaXQgZXhlY3V0ZVF1b3RhRXJyb3JDYWxsYmFja3MoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIHRoaXMuaXRlcmF0ZUNhbGxiYWNrcygnY2FjaGVEaWRVcGRhdGUnKSkge1xuICAgICAgICAgIGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgICAgIG9sZFJlc3BvbnNlLFxuICAgICAgICAgICAgbmV3UmVzcG9uc2U6IHJlc3BvbnNlVG9DYWNoZS5jbG9uZSgpLFxuICAgICAgICAgICAgcmVxdWVzdDogZWZmZWN0aXZlUmVxdWVzdCxcbiAgICAgICAgICAgIGV2ZW50OiB0aGlzLmV2ZW50XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIENoZWNrcyB0aGUgbGlzdCBvZiBwbHVnaW5zIGZvciB0aGUgYGNhY2hlS2V5V2lsbEJlVXNlZGAgY2FsbGJhY2ssIGFuZFxuICAgICAgICogZXhlY3V0ZXMgYW55IG9mIHRob3NlIGNhbGxiYWNrcyBmb3VuZCBpbiBzZXF1ZW5jZS4gVGhlIGZpbmFsIGBSZXF1ZXN0YFxuICAgICAgICogb2JqZWN0IHJldHVybmVkIGJ5IHRoZSBsYXN0IHBsdWdpbiBpcyB0cmVhdGVkIGFzIHRoZSBjYWNoZSBrZXkgZm9yIGNhY2hlXG4gICAgICAgKiByZWFkcyBhbmQvb3Igd3JpdGVzLiBJZiBubyBgY2FjaGVLZXlXaWxsQmVVc2VkYCBwbHVnaW4gY2FsbGJhY2tzIGhhdmVcbiAgICAgICAqIGJlZW4gcmVnaXN0ZXJlZCwgdGhlIHBhc3NlZCByZXF1ZXN0IGlzIHJldHVybmVkIHVubW9kaWZpZWRcbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IHJlcXVlc3RcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBtb2RlXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlcXVlc3Q+fVxuICAgICAgICovXG4gICAgICBhc3luYyBnZXRDYWNoZUtleShyZXF1ZXN0LCBtb2RlKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IGAke3JlcXVlc3QudXJsfSB8ICR7bW9kZX1gO1xuICAgICAgICBpZiAoIXRoaXMuX2NhY2hlS2V5c1trZXldKSB7XG4gICAgICAgICAgbGV0IGVmZmVjdGl2ZVJlcXVlc3QgPSByZXF1ZXN0O1xuICAgICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKCdjYWNoZUtleVdpbGxCZVVzZWQnKSkge1xuICAgICAgICAgICAgZWZmZWN0aXZlUmVxdWVzdCA9IHRvUmVxdWVzdChhd2FpdCBjYWxsYmFjayh7XG4gICAgICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgICAgIHJlcXVlc3Q6IGVmZmVjdGl2ZVJlcXVlc3QsXG4gICAgICAgICAgICAgIGV2ZW50OiB0aGlzLmV2ZW50LFxuICAgICAgICAgICAgICAvLyBwYXJhbXMgaGFzIGEgdHlwZSBhbnkgY2FuJ3QgY2hhbmdlIHJpZ2h0IG5vdy5cbiAgICAgICAgICAgICAgcGFyYW1zOiB0aGlzLnBhcmFtcyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuX2NhY2hlS2V5c1trZXldID0gZWZmZWN0aXZlUmVxdWVzdDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fY2FjaGVLZXlzW2tleV07XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgc3RyYXRlZ3kgaGFzIGF0IGxlYXN0IG9uZSBwbHVnaW4gd2l0aCB0aGUgZ2l2ZW5cbiAgICAgICAqIGNhbGxiYWNrLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIFRoZSBuYW1lIG9mIHRoZSBjYWxsYmFjayB0byBjaGVjayBmb3IuXG4gICAgICAgKiBAcmV0dXJuIHtib29sZWFufVxuICAgICAgICovXG4gICAgICBoYXNDYWxsYmFjayhuYW1lKSB7XG4gICAgICAgIGZvciAoY29uc3QgcGx1Z2luIG9mIHRoaXMuX3N0cmF0ZWd5LnBsdWdpbnMpIHtcbiAgICAgICAgICBpZiAobmFtZSBpbiBwbHVnaW4pIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJ1bnMgYWxsIHBsdWdpbiBjYWxsYmFja3MgbWF0Y2hpbmcgdGhlIGdpdmVuIG5hbWUsIGluIG9yZGVyLCBwYXNzaW5nIHRoZVxuICAgICAgICogZ2l2ZW4gcGFyYW0gb2JqZWN0IChtZXJnZWQgaXRoIHRoZSBjdXJyZW50IHBsdWdpbiBzdGF0ZSkgYXMgdGhlIG9ubHlcbiAgICAgICAqIGFyZ3VtZW50LlxuICAgICAgICpcbiAgICAgICAqIE5vdGU6IHNpbmNlIHRoaXMgbWV0aG9kIHJ1bnMgYWxsIHBsdWdpbnMsIGl0J3Mgbm90IHN1aXRhYmxlIGZvciBjYXNlc1xuICAgICAgICogd2hlcmUgdGhlIHJldHVybiB2YWx1ZSBvZiBhIGNhbGxiYWNrIG5lZWRzIHRvIGJlIGFwcGxpZWQgcHJpb3IgdG8gY2FsbGluZ1xuICAgICAgICogdGhlIG5leHQgY2FsbGJhY2suIFNlZVxuICAgICAgICoge0BsaW5rIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXIjaXRlcmF0ZUNhbGxiYWNrc31cbiAgICAgICAqIGJlbG93IGZvciBob3cgdG8gaGFuZGxlIHRoYXQgY2FzZS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZSBUaGUgbmFtZSBvZiB0aGUgY2FsbGJhY2sgdG8gcnVuIHdpdGhpbiBlYWNoIHBsdWdpbi5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBwYXJhbSBUaGUgb2JqZWN0IHRvIHBhc3MgYXMgdGhlIGZpcnN0IChhbmQgb25seSkgcGFyYW1cbiAgICAgICAqICAgICB3aGVuIGV4ZWN1dGluZyBlYWNoIGNhbGxiYWNrLiBUaGlzIG9iamVjdCB3aWxsIGJlIG1lcmdlZCB3aXRoIHRoZVxuICAgICAgICogICAgIGN1cnJlbnQgcGx1Z2luIHN0YXRlIHByaW9yIHRvIGNhbGxiYWNrIGV4ZWN1dGlvbi5cbiAgICAgICAqL1xuICAgICAgYXN5bmMgcnVuQ2FsbGJhY2tzKG5hbWUsIHBhcmFtKSB7XG4gICAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgdGhpcy5pdGVyYXRlQ2FsbGJhY2tzKG5hbWUpKSB7XG4gICAgICAgICAgLy8gVE9ETyhwaGlsaXB3YWx0b24pOiBub3Qgc3VyZSB3aHkgYGFueWAgaXMgbmVlZGVkLiBJdCBzZWVtcyBsaWtlXG4gICAgICAgICAgLy8gdGhpcyBzaG91bGQgd29yayB3aXRoIGBhcyBXb3JrYm94UGx1Z2luQ2FsbGJhY2tQYXJhbVtDXWAuXG4gICAgICAgICAgYXdhaXQgY2FsbGJhY2socGFyYW0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEFjY2VwdHMgYSBjYWxsYmFjayBhbmQgcmV0dXJucyBhbiBpdGVyYWJsZSBvZiBtYXRjaGluZyBwbHVnaW4gY2FsbGJhY2tzLFxuICAgICAgICogd2hlcmUgZWFjaCBjYWxsYmFjayBpcyB3cmFwcGVkIHdpdGggdGhlIGN1cnJlbnQgaGFuZGxlciBzdGF0ZSAoaS5lLiB3aGVuXG4gICAgICAgKiB5b3UgY2FsbCBlYWNoIGNhbGxiYWNrLCB3aGF0ZXZlciBvYmplY3QgcGFyYW1ldGVyIHlvdSBwYXNzIGl0IHdpbGxcbiAgICAgICAqIGJlIG1lcmdlZCB3aXRoIHRoZSBwbHVnaW4ncyBjdXJyZW50IHN0YXRlKS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZSBUaGUgbmFtZSBmbyB0aGUgY2FsbGJhY2sgdG8gcnVuXG4gICAgICAgKiBAcmV0dXJuIHtBcnJheTxGdW5jdGlvbj59XG4gICAgICAgKi9cbiAgICAgICppdGVyYXRlQ2FsbGJhY2tzKG5hbWUpIHtcbiAgICAgICAgZm9yIChjb25zdCBwbHVnaW4gb2YgdGhpcy5fc3RyYXRlZ3kucGx1Z2lucykge1xuICAgICAgICAgIGlmICh0eXBlb2YgcGx1Z2luW25hbWVdID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICBjb25zdCBzdGF0ZSA9IHRoaXMuX3BsdWdpblN0YXRlTWFwLmdldChwbHVnaW4pO1xuICAgICAgICAgICAgY29uc3Qgc3RhdGVmdWxDYWxsYmFjayA9IHBhcmFtID0+IHtcbiAgICAgICAgICAgICAgY29uc3Qgc3RhdGVmdWxQYXJhbSA9IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgcGFyYW0pLCB7XG4gICAgICAgICAgICAgICAgc3RhdGVcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIC8vIFRPRE8ocGhpbGlwd2FsdG9uKTogbm90IHN1cmUgd2h5IGBhbnlgIGlzIG5lZWRlZC4gSXQgc2VlbXMgbGlrZVxuICAgICAgICAgICAgICAvLyB0aGlzIHNob3VsZCB3b3JrIHdpdGggYGFzIFdvcmtib3hQbHVnaW5DYWxsYmFja1BhcmFtW0NdYC5cbiAgICAgICAgICAgICAgcmV0dXJuIHBsdWdpbltuYW1lXShzdGF0ZWZ1bFBhcmFtKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB5aWVsZCBzdGF0ZWZ1bENhbGxiYWNrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBBZGRzIGEgcHJvbWlzZSB0byB0aGVcbiAgICAgICAqIFtleHRlbmQgbGlmZXRpbWUgcHJvbWlzZXNde0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby9TZXJ2aWNlV29ya2VyLyNleHRlbmRhYmxlZXZlbnQtZXh0ZW5kLWxpZmV0aW1lLXByb21pc2VzfVxuICAgICAgICogb2YgdGhlIGV2ZW50IGFzc29jaWF0ZWQgd2l0aCB0aGUgcmVxdWVzdCBiZWluZyBoYW5kbGVkICh1c3VhbGx5IGFcbiAgICAgICAqIGBGZXRjaEV2ZW50YCkuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogeW91IGNhbiBhd2FpdFxuICAgICAgICoge0BsaW5rIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ+ZG9uZVdhaXRpbmd9XG4gICAgICAgKiB0byBrbm93IHdoZW4gYWxsIGFkZGVkIHByb21pc2VzIGhhdmUgc2V0dGxlZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge1Byb21pc2V9IHByb21pc2UgQSBwcm9taXNlIHRvIGFkZCB0byB0aGUgZXh0ZW5kIGxpZmV0aW1lIHByb21pc2VzXG4gICAgICAgKiAgICAgb2YgdGhlIGV2ZW50IHRoYXQgdHJpZ2dlcmVkIHRoZSByZXF1ZXN0LlxuICAgICAgICovXG4gICAgICB3YWl0VW50aWwocHJvbWlzZSkge1xuICAgICAgICB0aGlzLl9leHRlbmRMaWZldGltZVByb21pc2VzLnB1c2gocHJvbWlzZSk7XG4gICAgICAgIHJldHVybiBwcm9taXNlO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgYWxsIHByb21pc2VzIHBhc3NlZCB0b1xuICAgICAgICoge0BsaW5rIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ+d2FpdFVudGlsfVxuICAgICAgICogaGF2ZSBzZXR0bGVkLlxuICAgICAgICpcbiAgICAgICAqIE5vdGU6IGFueSB3b3JrIGRvbmUgYWZ0ZXIgYGRvbmVXYWl0aW5nKClgIHNldHRsZXMgc2hvdWxkIGJlIG1hbnVhbGx5XG4gICAgICAgKiBwYXNzZWQgdG8gYW4gZXZlbnQncyBgd2FpdFVudGlsKClgIG1ldGhvZCAobm90IHRoaXMgaGFuZGxlcidzXG4gICAgICAgKiBgd2FpdFVudGlsKClgIG1ldGhvZCksIG90aGVyd2lzZSB0aGUgc2VydmljZSB3b3JrZXIgdGhyZWFkIG1heSBiZSBraWxsZWRcbiAgICAgICAqIHByaW9yIHRvIHlvdXIgd29yayBjb21wbGV0aW5nLlxuICAgICAgICovXG4gICAgICBhc3luYyBkb25lV2FpdGluZygpIHtcbiAgICAgICAgd2hpbGUgKHRoaXMuX2V4dGVuZExpZmV0aW1lUHJvbWlzZXMubGVuZ3RoKSB7XG4gICAgICAgICAgY29uc3QgcHJvbWlzZXMgPSB0aGlzLl9leHRlbmRMaWZldGltZVByb21pc2VzLnNwbGljZSgwKTtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQocHJvbWlzZXMpO1xuICAgICAgICAgIGNvbnN0IGZpcnN0UmVqZWN0aW9uID0gcmVzdWx0LmZpbmQoaSA9PiBpLnN0YXR1cyA9PT0gJ3JlamVjdGVkJyk7XG4gICAgICAgICAgaWYgKGZpcnN0UmVqZWN0aW9uKSB7XG4gICAgICAgICAgICB0aHJvdyBmaXJzdFJlamVjdGlvbi5yZWFzb247XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFN0b3BzIHJ1bm5pbmcgdGhlIHN0cmF0ZWd5IGFuZCBpbW1lZGlhdGVseSByZXNvbHZlcyBhbnkgcGVuZGluZ1xuICAgICAgICogYHdhaXRVbnRpbCgpYCBwcm9taXNlcy5cbiAgICAgICAqL1xuICAgICAgZGVzdHJveSgpIHtcbiAgICAgICAgdGhpcy5faGFuZGxlckRlZmVycmVkLnJlc29sdmUobnVsbCk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFRoaXMgbWV0aG9kIHdpbGwgY2FsbCBjYWNoZVdpbGxVcGRhdGUgb24gdGhlIGF2YWlsYWJsZSBwbHVnaW5zIChvciB1c2VcbiAgICAgICAqIHN0YXR1cyA9PT0gMjAwKSB0byBkZXRlcm1pbmUgaWYgdGhlIFJlc3BvbnNlIGlzIHNhZmUgYW5kIHZhbGlkIHRvIGNhY2hlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7UmVxdWVzdH0gb3B0aW9ucy5yZXF1ZXN0XG4gICAgICAgKiBAcGFyYW0ge1Jlc3BvbnNlfSBvcHRpb25zLnJlc3BvbnNlXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlfHVuZGVmaW5lZD59XG4gICAgICAgKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqL1xuICAgICAgYXN5bmMgX2Vuc3VyZVJlc3BvbnNlU2FmZVRvQ2FjaGUocmVzcG9uc2UpIHtcbiAgICAgICAgbGV0IHJlc3BvbnNlVG9DYWNoZSA9IHJlc3BvbnNlO1xuICAgICAgICBsZXQgcGx1Z2luc1VzZWQgPSBmYWxzZTtcbiAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiB0aGlzLml0ZXJhdGVDYWxsYmFja3MoJ2NhY2hlV2lsbFVwZGF0ZScpKSB7XG4gICAgICAgICAgcmVzcG9uc2VUb0NhY2hlID0gKGF3YWl0IGNhbGxiYWNrKHtcbiAgICAgICAgICAgIHJlcXVlc3Q6IHRoaXMucmVxdWVzdCxcbiAgICAgICAgICAgIHJlc3BvbnNlOiByZXNwb25zZVRvQ2FjaGUsXG4gICAgICAgICAgICBldmVudDogdGhpcy5ldmVudFxuICAgICAgICAgIH0pKSB8fCB1bmRlZmluZWQ7XG4gICAgICAgICAgcGx1Z2luc1VzZWQgPSB0cnVlO1xuICAgICAgICAgIGlmICghcmVzcG9uc2VUb0NhY2hlKSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFwbHVnaW5zVXNlZCkge1xuICAgICAgICAgIGlmIChyZXNwb25zZVRvQ2FjaGUgJiYgcmVzcG9uc2VUb0NhY2hlLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgICAgICAgICByZXNwb25zZVRvQ2FjaGUgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZVRvQ2FjaGUpIHtcbiAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlVG9DYWNoZS5zdGF0dXMgIT09IDIwMCkge1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZVRvQ2FjaGUuc3RhdHVzID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICBsb2dnZXIud2FybihgVGhlIHJlc3BvbnNlIGZvciAnJHt0aGlzLnJlcXVlc3QudXJsfScgYCArIGBpcyBhbiBvcGFxdWUgcmVzcG9uc2UuIFRoZSBjYWNoaW5nIHN0cmF0ZWd5IHRoYXQgeW91J3JlIGAgKyBgdXNpbmcgd2lsbCBub3QgY2FjaGUgb3BhcXVlIHJlc3BvbnNlcyBieSBkZWZhdWx0LmApO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYFRoZSByZXNwb25zZSBmb3IgJyR7dGhpcy5yZXF1ZXN0LnVybH0nIGAgKyBgcmV0dXJuZWQgYSBzdGF0dXMgY29kZSBvZiAnJHtyZXNwb25zZS5zdGF0dXN9JyBhbmQgd29uJ3QgYCArIGBiZSBjYWNoZWQgYXMgYSByZXN1bHQuYCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZVRvQ2FjaGU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQW4gYWJzdHJhY3QgYmFzZSBjbGFzcyB0aGF0IGFsbCBvdGhlciBzdHJhdGVneSBjbGFzc2VzIG11c3QgZXh0ZW5kIGZyb206XG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1zdHJhdGVnaWVzXG4gICAgICovXG4gICAgY2xhc3MgU3RyYXRlZ3kge1xuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGEgbmV3IGluc3RhbmNlIG9mIHRoZSBzdHJhdGVneSBhbmQgc2V0cyBhbGwgZG9jdW1lbnRlZCBvcHRpb25cbiAgICAgICAqIHByb3BlcnRpZXMgYXMgcHVibGljIGluc3RhbmNlIHByb3BlcnRpZXMuXG4gICAgICAgKlxuICAgICAgICogTm90ZTogaWYgYSBjdXN0b20gc3RyYXRlZ3kgY2xhc3MgZXh0ZW5kcyB0aGUgYmFzZSBTdHJhdGVneSBjbGFzcyBhbmQgZG9lc1xuICAgICAgICogbm90IG5lZWQgbW9yZSB0aGFuIHRoZXNlIHByb3BlcnRpZXMsIGl0IGRvZXMgbm90IG5lZWQgdG8gZGVmaW5lIGl0cyBvd25cbiAgICAgICAqIGNvbnN0cnVjdG9yLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy5jYWNoZU5hbWVdIENhY2hlIG5hbWUgdG8gc3RvcmUgYW5kIHJldHJpZXZlXG4gICAgICAgKiByZXF1ZXN0cy4gRGVmYXVsdHMgdG8gdGhlIGNhY2hlIG5hbWVzIHByb3ZpZGVkIGJ5XG4gICAgICAgKiB7QGxpbmsgd29ya2JveC1jb3JlLmNhY2hlTmFtZXN9LlxuICAgICAgICogQHBhcmFtIHtBcnJheTxPYmplY3Q+fSBbb3B0aW9ucy5wbHVnaW5zXSBbUGx1Z2luc117QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vd2ViL3Rvb2xzL3dvcmtib3gvZ3VpZGVzL3VzaW5nLXBsdWdpbnN9XG4gICAgICAgKiB0byB1c2UgaW4gY29uanVuY3Rpb24gd2l0aCB0aGlzIGNhY2hpbmcgc3RyYXRlZ3kuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnMuZmV0Y2hPcHRpb25zXSBWYWx1ZXMgcGFzc2VkIGFsb25nIHRvIHRoZVxuICAgICAgICogW2Bpbml0YF0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1dpbmRvd09yV29ya2VyR2xvYmFsU2NvcGUvZmV0Y2gjUGFyYW1ldGVycylcbiAgICAgICAqIG9mIFtub24tbmF2aWdhdGlvbl0oaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8xNzk2KVxuICAgICAgICogYGZldGNoKClgIHJlcXVlc3RzIG1hZGUgYnkgdGhpcyBzdHJhdGVneS5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucy5tYXRjaE9wdGlvbnNdIFRoZVxuICAgICAgICogW2BDYWNoZVF1ZXJ5T3B0aW9uc2Bde0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby9TZXJ2aWNlV29ya2VyLyNkaWN0ZGVmLWNhY2hlcXVlcnlvcHRpb25zfVxuICAgICAgICogZm9yIGFueSBgY2FjaGUubWF0Y2goKWAgb3IgYGNhY2hlLnB1dCgpYCBjYWxscyBtYWRlIGJ5IHRoaXMgc3RyYXRlZ3kuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgICAgICAvKipcbiAgICAgICAgICogQ2FjaGUgbmFtZSB0byBzdG9yZSBhbmQgcmV0cmlldmVcbiAgICAgICAgICogcmVxdWVzdHMuIERlZmF1bHRzIHRvIHRoZSBjYWNoZSBuYW1lcyBwcm92aWRlZCBieVxuICAgICAgICAgKiB7QGxpbmsgd29ya2JveC1jb3JlLmNhY2hlTmFtZXN9LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAdHlwZSB7c3RyaW5nfVxuICAgICAgICAgKi9cbiAgICAgICAgdGhpcy5jYWNoZU5hbWUgPSBjYWNoZU5hbWVzLmdldFJ1bnRpbWVOYW1lKG9wdGlvbnMuY2FjaGVOYW1lKTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSBsaXN0XG4gICAgICAgICAqIFtQbHVnaW5zXXtAbGluayBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS93ZWIvdG9vbHMvd29ya2JveC9ndWlkZXMvdXNpbmctcGx1Z2luc31cbiAgICAgICAgICogdXNlZCBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICAgKlxuICAgICAgICAgKiBAdHlwZSB7QXJyYXk8T2JqZWN0Pn1cbiAgICAgICAgICovXG4gICAgICAgIHRoaXMucGx1Z2lucyA9IG9wdGlvbnMucGx1Z2lucyB8fCBbXTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZhbHVlcyBwYXNzZWQgYWxvbmcgdG8gdGhlXG4gICAgICAgICAqIFtgaW5pdGBde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9XaW5kb3dPcldvcmtlckdsb2JhbFNjb3BlL2ZldGNoI1BhcmFtZXRlcnN9XG4gICAgICAgICAqIG9mIGFsbCBmZXRjaCgpIHJlcXVlc3RzIG1hZGUgYnkgdGhpcyBzdHJhdGVneS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHR5cGUge09iamVjdH1cbiAgICAgICAgICovXG4gICAgICAgIHRoaXMuZmV0Y2hPcHRpb25zID0gb3B0aW9ucy5mZXRjaE9wdGlvbnM7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBUaGVcbiAgICAgICAgICogW2BDYWNoZVF1ZXJ5T3B0aW9uc2Bde0BsaW5rIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby9TZXJ2aWNlV29ya2VyLyNkaWN0ZGVmLWNhY2hlcXVlcnlvcHRpb25zfVxuICAgICAgICAgKiBmb3IgYW55IGBjYWNoZS5tYXRjaCgpYCBvciBgY2FjaGUucHV0KClgIGNhbGxzIG1hZGUgYnkgdGhpcyBzdHJhdGVneS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHR5cGUge09iamVjdH1cbiAgICAgICAgICovXG4gICAgICAgIHRoaXMubWF0Y2hPcHRpb25zID0gb3B0aW9ucy5tYXRjaE9wdGlvbnM7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFBlcmZvcm0gYSByZXF1ZXN0IHN0cmF0ZWd5IGFuZCByZXR1cm5zIGEgYFByb21pc2VgIHRoYXQgd2lsbCByZXNvbHZlIHdpdGhcbiAgICAgICAqIGEgYFJlc3BvbnNlYCwgaW52b2tpbmcgYWxsIHJlbGV2YW50IHBsdWdpbiBjYWxsYmFja3MuXG4gICAgICAgKlxuICAgICAgICogV2hlbiBhIHN0cmF0ZWd5IGluc3RhbmNlIGlzIHJlZ2lzdGVyZWQgd2l0aCBhIFdvcmtib3hcbiAgICAgICAqIHtAbGluayB3b3JrYm94LXJvdXRpbmcuUm91dGV9LCB0aGlzIG1ldGhvZCBpcyBhdXRvbWF0aWNhbGx5XG4gICAgICAgKiBjYWxsZWQgd2hlbiB0aGUgcm91dGUgbWF0Y2hlcy5cbiAgICAgICAqXG4gICAgICAgKiBBbHRlcm5hdGl2ZWx5LCB0aGlzIG1ldGhvZCBjYW4gYmUgdXNlZCBpbiBhIHN0YW5kYWxvbmUgYEZldGNoRXZlbnRgXG4gICAgICAgKiBsaXN0ZW5lciBieSBwYXNzaW5nIGl0IHRvIGBldmVudC5yZXNwb25kV2l0aCgpYC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0ZldGNoRXZlbnR8T2JqZWN0fSBvcHRpb25zIEEgYEZldGNoRXZlbnRgIG9yIGFuIG9iamVjdCB3aXRoIHRoZVxuICAgICAgICogICAgIHByb3BlcnRpZXMgbGlzdGVkIGJlbG93LlxuICAgICAgICogQHBhcmFtIHtSZXF1ZXN0fHN0cmluZ30gb3B0aW9ucy5yZXF1ZXN0IEEgcmVxdWVzdCB0byBydW4gdGhpcyBzdHJhdGVneSBmb3IuXG4gICAgICAgKiBAcGFyYW0ge0V4dGVuZGFibGVFdmVudH0gb3B0aW9ucy5ldmVudCBUaGUgZXZlbnQgYXNzb2NpYXRlZCB3aXRoIHRoZVxuICAgICAgICogICAgIHJlcXVlc3QuXG4gICAgICAgKiBAcGFyYW0ge1VSTH0gW29wdGlvbnMudXJsXVxuICAgICAgICogQHBhcmFtIHsqfSBbb3B0aW9ucy5wYXJhbXNdXG4gICAgICAgKi9cbiAgICAgIGhhbmRsZShvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IFtyZXNwb25zZURvbmVdID0gdGhpcy5oYW5kbGVBbGwob3B0aW9ucyk7XG4gICAgICAgIHJldHVybiByZXNwb25zZURvbmU7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFNpbWlsYXIgdG8ge0BsaW5rIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneX5oYW5kbGV9LCBidXRcbiAgICAgICAqIGluc3RlYWQgb2YganVzdCByZXR1cm5pbmcgYSBgUHJvbWlzZWAgdGhhdCByZXNvbHZlcyB0byBhIGBSZXNwb25zZWAgaXRcbiAgICAgICAqIGl0IHdpbGwgcmV0dXJuIGFuIHR1cGxlIG9mIGBbcmVzcG9uc2UsIGRvbmVdYCBwcm9taXNlcywgd2hlcmUgdGhlIGZvcm1lclxuICAgICAgICogKGByZXNwb25zZWApIGlzIGVxdWl2YWxlbnQgdG8gd2hhdCBgaGFuZGxlKClgIHJldHVybnMsIGFuZCB0aGUgbGF0dGVyIGlzIGFcbiAgICAgICAqIFByb21pc2UgdGhhdCB3aWxsIHJlc29sdmUgb25jZSBhbnkgcHJvbWlzZXMgdGhhdCB3ZXJlIGFkZGVkIHRvXG4gICAgICAgKiBgZXZlbnQud2FpdFVudGlsKClgIGFzIHBhcnQgb2YgcGVyZm9ybWluZyB0aGUgc3RyYXRlZ3kgaGF2ZSBjb21wbGV0ZWQuXG4gICAgICAgKlxuICAgICAgICogWW91IGNhbiBhd2FpdCB0aGUgYGRvbmVgIHByb21pc2UgdG8gZW5zdXJlIGFueSBleHRyYSB3b3JrIHBlcmZvcm1lZCBieVxuICAgICAgICogdGhlIHN0cmF0ZWd5ICh1c3VhbGx5IGNhY2hpbmcgcmVzcG9uc2VzKSBjb21wbGV0ZXMgc3VjY2Vzc2Z1bGx5LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7RmV0Y2hFdmVudHxPYmplY3R9IG9wdGlvbnMgQSBgRmV0Y2hFdmVudGAgb3IgYW4gb2JqZWN0IHdpdGggdGhlXG4gICAgICAgKiAgICAgcHJvcGVydGllcyBsaXN0ZWQgYmVsb3cuXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSBvcHRpb25zLnJlcXVlc3QgQSByZXF1ZXN0IHRvIHJ1biB0aGlzIHN0cmF0ZWd5IGZvci5cbiAgICAgICAqIEBwYXJhbSB7RXh0ZW5kYWJsZUV2ZW50fSBvcHRpb25zLmV2ZW50IFRoZSBldmVudCBhc3NvY2lhdGVkIHdpdGggdGhlXG4gICAgICAgKiAgICAgcmVxdWVzdC5cbiAgICAgICAqIEBwYXJhbSB7VVJMfSBbb3B0aW9ucy51cmxdXG4gICAgICAgKiBAcGFyYW0geyp9IFtvcHRpb25zLnBhcmFtc11cbiAgICAgICAqIEByZXR1cm4ge0FycmF5PFByb21pc2U+fSBBIHR1cGxlIG9mIFtyZXNwb25zZSwgZG9uZV1cbiAgICAgICAqICAgICBwcm9taXNlcyB0aGF0IGNhbiBiZSB1c2VkIHRvIGRldGVybWluZSB3aGVuIHRoZSByZXNwb25zZSByZXNvbHZlcyBhc1xuICAgICAgICogICAgIHdlbGwgYXMgd2hlbiB0aGUgaGFuZGxlciBoYXMgY29tcGxldGVkIGFsbCBpdHMgd29yay5cbiAgICAgICAqL1xuICAgICAgaGFuZGxlQWxsKG9wdGlvbnMpIHtcbiAgICAgICAgLy8gQWxsb3cgZm9yIGZsZXhpYmxlIG9wdGlvbnMgdG8gYmUgcGFzc2VkLlxuICAgICAgICBpZiAob3B0aW9ucyBpbnN0YW5jZW9mIEZldGNoRXZlbnQpIHtcbiAgICAgICAgICBvcHRpb25zID0ge1xuICAgICAgICAgICAgZXZlbnQ6IG9wdGlvbnMsXG4gICAgICAgICAgICByZXF1ZXN0OiBvcHRpb25zLnJlcXVlc3RcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGV2ZW50ID0gb3B0aW9ucy5ldmVudDtcbiAgICAgICAgY29uc3QgcmVxdWVzdCA9IHR5cGVvZiBvcHRpb25zLnJlcXVlc3QgPT09ICdzdHJpbmcnID8gbmV3IFJlcXVlc3Qob3B0aW9ucy5yZXF1ZXN0KSA6IG9wdGlvbnMucmVxdWVzdDtcbiAgICAgICAgY29uc3QgcGFyYW1zID0gJ3BhcmFtcycgaW4gb3B0aW9ucyA/IG9wdGlvbnMucGFyYW1zIDogdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCBoYW5kbGVyID0gbmV3IFN0cmF0ZWd5SGFuZGxlcih0aGlzLCB7XG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICBwYXJhbXNcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRG9uZSA9IHRoaXMuX2dldFJlc3BvbnNlKGhhbmRsZXIsIHJlcXVlc3QsIGV2ZW50KTtcbiAgICAgICAgY29uc3QgaGFuZGxlckRvbmUgPSB0aGlzLl9hd2FpdENvbXBsZXRlKHJlc3BvbnNlRG9uZSwgaGFuZGxlciwgcmVxdWVzdCwgZXZlbnQpO1xuICAgICAgICAvLyBSZXR1cm4gYW4gYXJyYXkgb2YgcHJvbWlzZXMsIHN1aXRhYmxlIGZvciB1c2Ugd2l0aCBQcm9taXNlLmFsbCgpLlxuICAgICAgICByZXR1cm4gW3Jlc3BvbnNlRG9uZSwgaGFuZGxlckRvbmVdO1xuICAgICAgfVxuICAgICAgYXN5bmMgX2dldFJlc3BvbnNlKGhhbmRsZXIsIHJlcXVlc3QsIGV2ZW50KSB7XG4gICAgICAgIGF3YWl0IGhhbmRsZXIucnVuQ2FsbGJhY2tzKCdoYW5kbGVyV2lsbFN0YXJ0Jywge1xuICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgfSk7XG4gICAgICAgIGxldCByZXNwb25zZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IHRoaXMuX2hhbmRsZShyZXF1ZXN0LCBoYW5kbGVyKTtcbiAgICAgICAgICAvLyBUaGUgXCJvZmZpY2lhbFwiIFN0cmF0ZWd5IHN1YmNsYXNzZXMgYWxsIHRocm93IHRoaXMgZXJyb3IgYXV0b21hdGljYWxseSxcbiAgICAgICAgICAvLyBidXQgaW4gY2FzZSBhIHRoaXJkLXBhcnR5IFN0cmF0ZWd5IGRvZXNuJ3QsIGVuc3VyZSB0aGF0IHdlIGhhdmUgYVxuICAgICAgICAgIC8vIGNvbnNpc3RlbnQgZmFpbHVyZSB3aGVuIHRoZXJlJ3Mgbm8gcmVzcG9uc2Ugb3IgYW4gZXJyb3IgcmVzcG9uc2UuXG4gICAgICAgICAgaWYgKCFyZXNwb25zZSB8fCByZXNwb25zZS50eXBlID09PSAnZXJyb3InKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCduby1yZXNwb25zZScsIHtcbiAgICAgICAgICAgICAgdXJsOiByZXF1ZXN0LnVybFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGNhbGxiYWNrIG9mIGhhbmRsZXIuaXRlcmF0ZUNhbGxiYWNrcygnaGFuZGxlckRpZEVycm9yJykpIHtcbiAgICAgICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCBjYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgICAgcmVxdWVzdFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFyZXNwb25zZSkge1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGxvZ2dlci5sb2coYFdoaWxlIHJlc3BvbmRpbmcgdG8gJyR7Z2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpfScsIGAgKyBgYW4gJHtlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IudG9TdHJpbmcoKSA6ICcnfSBlcnJvciBvY2N1cnJlZC4gVXNpbmcgYSBmYWxsYmFjayByZXNwb25zZSBwcm92aWRlZCBieSBgICsgYGEgaGFuZGxlckRpZEVycm9yIHBsdWdpbi5gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBjYWxsYmFjayBvZiBoYW5kbGVyLml0ZXJhdGVDYWxsYmFja3MoJ2hhbmRsZXJXaWxsUmVzcG9uZCcpKSB7XG4gICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCBjYWxsYmFjayh7XG4gICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgICByZXNwb25zZVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICAgIGFzeW5jIF9hd2FpdENvbXBsZXRlKHJlc3BvbnNlRG9uZSwgaGFuZGxlciwgcmVxdWVzdCwgZXZlbnQpIHtcbiAgICAgICAgbGV0IHJlc3BvbnNlO1xuICAgICAgICBsZXQgZXJyb3I7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCByZXNwb25zZURvbmU7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgLy8gSWdub3JlIGVycm9ycywgYXMgcmVzcG9uc2UgZXJyb3JzIHNob3VsZCBiZSBjYXVnaHQgdmlhIHRoZSBgcmVzcG9uc2VgXG4gICAgICAgICAgLy8gcHJvbWlzZSBhYm92ZS4gVGhlIGBkb25lYCBwcm9taXNlIHdpbGwgb25seSB0aHJvdyBmb3IgZXJyb3JzIGluXG4gICAgICAgICAgLy8gcHJvbWlzZXMgcGFzc2VkIHRvIGBoYW5kbGVyLndhaXRVbnRpbCgpYC5cbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IGhhbmRsZXIucnVuQ2FsbGJhY2tzKCdoYW5kbGVyRGlkUmVzcG9uZCcsIHtcbiAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgYXdhaXQgaGFuZGxlci5kb25lV2FpdGluZygpO1xuICAgICAgICB9IGNhdGNoICh3YWl0VW50aWxFcnJvcikge1xuICAgICAgICAgIGlmICh3YWl0VW50aWxFcnJvciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICBlcnJvciA9IHdhaXRVbnRpbEVycm9yO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBhd2FpdCBoYW5kbGVyLnJ1bkNhbGxiYWNrcygnaGFuZGxlckRpZENvbXBsZXRlJywge1xuICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgIHJlcXVlc3QsXG4gICAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgICAgZXJyb3I6IGVycm9yXG4gICAgICAgIH0pO1xuICAgICAgICBoYW5kbGVyLmRlc3Ryb3koKTtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICogQ2xhc3NlcyBleHRlbmRpbmcgdGhlIGBTdHJhdGVneWAgYmFzZWQgY2xhc3Mgc2hvdWxkIGltcGxlbWVudCB0aGlzIG1ldGhvZCxcbiAgICAgKiBhbmQgbGV2ZXJhZ2UgdGhlIHtAbGluayB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lIYW5kbGVyfVxuICAgICAqIGFyZyB0byBwZXJmb3JtIGFsbCBmZXRjaGluZyBhbmQgY2FjaGUgbG9naWMsIHdoaWNoIHdpbGwgZW5zdXJlIGFsbCByZWxldmFudFxuICAgICAqIGNhY2hlLCBjYWNoZSBvcHRpb25zLCBmZXRjaCBvcHRpb25zIGFuZCBwbHVnaW5zIGFyZSB1c2VkIChwZXIgdGhlIGN1cnJlbnRcbiAgICAgKiBzdHJhdGVneSBpbnN0YW5jZSkuXG4gICAgICpcbiAgICAgKiBAbmFtZSBfaGFuZGxlXG4gICAgICogQGluc3RhbmNlXG4gICAgICogQGFic3RyYWN0XG4gICAgICogQGZ1bmN0aW9uXG4gICAgICogQHBhcmFtIHtSZXF1ZXN0fSByZXF1ZXN0XG4gICAgICogQHBhcmFtIHt3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3lIYW5kbGVyfSBoYW5kbGVyXG4gICAgICogQHJldHVybiB7UHJvbWlzZTxSZXNwb25zZT59XG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1zdHJhdGVnaWVzLlN0cmF0ZWd5XG4gICAgICovXG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBIHtAbGluayB3b3JrYm94LXN0cmF0ZWdpZXMuU3RyYXRlZ3l9IGltcGxlbWVudGF0aW9uXG4gICAgICogc3BlY2lmaWNhbGx5IGRlc2lnbmVkIHRvIHdvcmsgd2l0aFxuICAgICAqIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVDb250cm9sbGVyfVxuICAgICAqIHRvIGJvdGggY2FjaGUgYW5kIGZldGNoIHByZWNhY2hlZCBhc3NldHMuXG4gICAgICpcbiAgICAgKiBOb3RlOiBhbiBpbnN0YW5jZSBvZiB0aGlzIGNsYXNzIGlzIGNyZWF0ZWQgYXV0b21hdGljYWxseSB3aGVuIGNyZWF0aW5nIGFcbiAgICAgKiBgUHJlY2FjaGVDb250cm9sbGVyYDsgaXQncyBnZW5lcmFsbHkgbm90IG5lY2Vzc2FyeSB0byBjcmVhdGUgdGhpcyB5b3Vyc2VsZi5cbiAgICAgKlxuICAgICAqIEBleHRlbmRzIHdvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBjbGFzcyBQcmVjYWNoZVN0cmF0ZWd5IGV4dGVuZHMgU3RyYXRlZ3kge1xuICAgICAgLyoqXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRpb25zLmNhY2hlTmFtZV0gQ2FjaGUgbmFtZSB0byBzdG9yZSBhbmQgcmV0cmlldmVcbiAgICAgICAqIHJlcXVlc3RzLiBEZWZhdWx0cyB0byB0aGUgY2FjaGUgbmFtZXMgcHJvdmlkZWQgYnlcbiAgICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc30uXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IFtvcHRpb25zLnBsdWdpbnNdIHtAbGluayBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS93ZWIvdG9vbHMvd29ya2JveC9ndWlkZXMvdXNpbmctcGx1Z2luc3xQbHVnaW5zfVxuICAgICAgICogdG8gdXNlIGluIGNvbmp1bmN0aW9uIHdpdGggdGhpcyBjYWNoaW5nIHN0cmF0ZWd5LlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zLmZldGNoT3B0aW9uc10gVmFsdWVzIHBhc3NlZCBhbG9uZyB0byB0aGVcbiAgICAgICAqIHtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvV2luZG93T3JXb3JrZXJHbG9iYWxTY29wZS9mZXRjaCNQYXJhbWV0ZXJzfGluaXR9XG4gICAgICAgKiBvZiBhbGwgZmV0Y2goKSByZXF1ZXN0cyBtYWRlIGJ5IHRoaXMgc3RyYXRlZ3kuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnMubWF0Y2hPcHRpb25zXSBUaGVcbiAgICAgICAqIHtAbGluayBodHRwczovL3czYy5naXRodWIuaW8vU2VydmljZVdvcmtlci8jZGljdGRlZi1jYWNoZXF1ZXJ5b3B0aW9uc3xDYWNoZVF1ZXJ5T3B0aW9uc31cbiAgICAgICAqIGZvciBhbnkgYGNhY2hlLm1hdGNoKClgIG9yIGBjYWNoZS5wdXQoKWAgY2FsbHMgbWFkZSBieSB0aGlzIHN0cmF0ZWd5LlxuICAgICAgICogQHBhcmFtIHtib29sZWFufSBbb3B0aW9ucy5mYWxsYmFja1RvTmV0d29yaz10cnVlXSBXaGV0aGVyIHRvIGF0dGVtcHQgdG9cbiAgICAgICAqIGdldCB0aGUgcmVzcG9uc2UgZnJvbSB0aGUgbmV0d29yayBpZiB0aGVyZSdzIGEgcHJlY2FjaGUgbWlzcy5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3Iob3B0aW9ucyA9IHt9KSB7XG4gICAgICAgIG9wdGlvbnMuY2FjaGVOYW1lID0gY2FjaGVOYW1lcy5nZXRQcmVjYWNoZU5hbWUob3B0aW9ucy5jYWNoZU5hbWUpO1xuICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgdGhpcy5fZmFsbGJhY2tUb05ldHdvcmsgPSBvcHRpb25zLmZhbGxiYWNrVG9OZXR3b3JrID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcbiAgICAgICAgLy8gUmVkaXJlY3RlZCByZXNwb25zZXMgY2Fubm90IGJlIHVzZWQgdG8gc2F0aXNmeSBhIG5hdmlnYXRpb24gcmVxdWVzdCwgc29cbiAgICAgICAgLy8gYW55IHJlZGlyZWN0ZWQgcmVzcG9uc2UgbXVzdCBiZSBcImNvcGllZFwiIHJhdGhlciB0aGFuIGNsb25lZCwgc28gdGhlIG5ld1xuICAgICAgICAvLyByZXNwb25zZSBkb2Vzbid0IGNvbnRhaW4gdGhlIGByZWRpcmVjdGVkYCBmbGFnLiBTZWU6XG4gICAgICAgIC8vIGh0dHBzOi8vYnVncy5jaHJvbWl1bS5vcmcvcC9jaHJvbWl1bS9pc3N1ZXMvZGV0YWlsP2lkPTY2OTM2MyZkZXNjPTIjYzFcbiAgICAgICAgdGhpcy5wbHVnaW5zLnB1c2goUHJlY2FjaGVTdHJhdGVneS5jb3B5UmVkaXJlY3RlZENhY2hlYWJsZVJlc3BvbnNlc1BsdWdpbik7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEBwcml2YXRlXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R8c3RyaW5nfSByZXF1ZXN0IEEgcmVxdWVzdCB0byBydW4gdGhpcyBzdHJhdGVneSBmb3IuXG4gICAgICAgKiBAcGFyYW0ge3dvcmtib3gtc3RyYXRlZ2llcy5TdHJhdGVneUhhbmRsZXJ9IGhhbmRsZXIgVGhlIGV2ZW50IHRoYXRcbiAgICAgICAqICAgICB0cmlnZ2VyZWQgdGhlIHJlcXVlc3QuXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlPn1cbiAgICAgICAqL1xuICAgICAgYXN5bmMgX2hhbmRsZShyZXF1ZXN0LCBoYW5kbGVyKSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgaGFuZGxlci5jYWNoZU1hdGNoKHJlcXVlc3QpO1xuICAgICAgICBpZiAocmVzcG9uc2UpIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhpcyBpcyBhbiBgaW5zdGFsbGAgZXZlbnQgZm9yIGFuIGVudHJ5IHRoYXQgaXNuJ3QgYWxyZWFkeSBjYWNoZWQsXG4gICAgICAgIC8vIHRoZW4gcG9wdWxhdGUgdGhlIGNhY2hlLlxuICAgICAgICBpZiAoaGFuZGxlci5ldmVudCAmJiBoYW5kbGVyLmV2ZW50LnR5cGUgPT09ICdpbnN0YWxsJykge1xuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9oYW5kbGVJbnN0YWxsKHJlcXVlc3QsIGhhbmRsZXIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIEdldHRpbmcgaGVyZSBtZWFucyBzb21ldGhpbmcgd2VudCB3cm9uZy4gQW4gZW50cnkgdGhhdCBzaG91bGQgaGF2ZSBiZWVuXG4gICAgICAgIC8vIHByZWNhY2hlZCB3YXNuJ3QgZm91bmQgaW4gdGhlIGNhY2hlLlxuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5faGFuZGxlRmV0Y2gocmVxdWVzdCwgaGFuZGxlcik7XG4gICAgICB9XG4gICAgICBhc3luYyBfaGFuZGxlRmV0Y2gocmVxdWVzdCwgaGFuZGxlcikge1xuICAgICAgICBsZXQgcmVzcG9uc2U7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IGhhbmRsZXIucGFyYW1zIHx8IHt9O1xuICAgICAgICAvLyBGYWxsIGJhY2sgdG8gdGhlIG5ldHdvcmsgaWYgd2UncmUgY29uZmlndXJlZCB0byBkbyBzby5cbiAgICAgICAgaWYgKHRoaXMuX2ZhbGxiYWNrVG9OZXR3b3JrKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLndhcm4oYFRoZSBwcmVjYWNoZWQgcmVzcG9uc2UgZm9yIGAgKyBgJHtnZXRGcmllbmRseVVSTChyZXF1ZXN0LnVybCl9IGluICR7dGhpcy5jYWNoZU5hbWV9IHdhcyBub3QgYCArIGBmb3VuZC4gRmFsbGluZyBiYWNrIHRvIHRoZSBuZXR3b3JrLmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpbnRlZ3JpdHlJbk1hbmlmZXN0ID0gcGFyYW1zLmludGVncml0eTtcbiAgICAgICAgICBjb25zdCBpbnRlZ3JpdHlJblJlcXVlc3QgPSByZXF1ZXN0LmludGVncml0eTtcbiAgICAgICAgICBjb25zdCBub0ludGVncml0eUNvbmZsaWN0ID0gIWludGVncml0eUluUmVxdWVzdCB8fCBpbnRlZ3JpdHlJblJlcXVlc3QgPT09IGludGVncml0eUluTWFuaWZlc3Q7XG4gICAgICAgICAgLy8gRG8gbm90IGFkZCBpbnRlZ3JpdHkgaWYgdGhlIG9yaWdpbmFsIHJlcXVlc3QgaXMgbm8tY29yc1xuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzMwOTZcbiAgICAgICAgICByZXNwb25zZSA9IGF3YWl0IGhhbmRsZXIuZmV0Y2gobmV3IFJlcXVlc3QocmVxdWVzdCwge1xuICAgICAgICAgICAgaW50ZWdyaXR5OiByZXF1ZXN0Lm1vZGUgIT09ICduby1jb3JzJyA/IGludGVncml0eUluUmVxdWVzdCB8fCBpbnRlZ3JpdHlJbk1hbmlmZXN0IDogdW5kZWZpbmVkXG4gICAgICAgICAgfSkpO1xuICAgICAgICAgIC8vIEl0J3Mgb25seSBcInNhZmVcIiB0byByZXBhaXIgdGhlIGNhY2hlIGlmIHdlJ3JlIHVzaW5nIFNSSSB0byBndWFyYW50ZWVcbiAgICAgICAgICAvLyB0aGF0IHRoZSByZXNwb25zZSBtYXRjaGVzIHRoZSBwcmVjYWNoZSBtYW5pZmVzdCdzIGV4cGVjdGF0aW9ucyxcbiAgICAgICAgICAvLyBhbmQgdGhlcmUncyBlaXRoZXIgYSkgbm8gaW50ZWdyaXR5IHByb3BlcnR5IGluIHRoZSBpbmNvbWluZyByZXF1ZXN0XG4gICAgICAgICAgLy8gb3IgYikgdGhlcmUgaXMgYW4gaW50ZWdyaXR5LCBhbmQgaXQgbWF0Y2hlcyB0aGUgcHJlY2FjaGUgbWFuaWZlc3QuXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Hb29nbGVDaHJvbWUvd29ya2JveC9pc3N1ZXMvMjg1OFxuICAgICAgICAgIC8vIEFsc28gaWYgdGhlIG9yaWdpbmFsIHJlcXVlc3QgdXNlcnMgbm8tY29ycyB3ZSBkb24ndCB1c2UgaW50ZWdyaXR5LlxuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzMwOTZcbiAgICAgICAgICBpZiAoaW50ZWdyaXR5SW5NYW5pZmVzdCAmJiBub0ludGVncml0eUNvbmZsaWN0ICYmIHJlcXVlc3QubW9kZSAhPT0gJ25vLWNvcnMnKSB7XG4gICAgICAgICAgICB0aGlzLl91c2VEZWZhdWx0Q2FjaGVhYmlsaXR5UGx1Z2luSWZOZWVkZWQoKTtcbiAgICAgICAgICAgIGNvbnN0IHdhc0NhY2hlZCA9IGF3YWl0IGhhbmRsZXIuY2FjaGVQdXQocmVxdWVzdCwgcmVzcG9uc2UuY2xvbmUoKSk7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlmICh3YXNDYWNoZWQpIHtcbiAgICAgICAgICAgICAgICBsb2dnZXIubG9nKGBBIHJlc3BvbnNlIGZvciAke2dldEZyaWVuZGx5VVJMKHJlcXVlc3QudXJsKX0gYCArIGB3YXMgdXNlZCB0byBcInJlcGFpclwiIHRoZSBwcmVjYWNoZS5gKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBUaGlzIHNob3VsZG4ndCBub3JtYWxseSBoYXBwZW4sIGJ1dCB0aGVyZSBhcmUgZWRnZSBjYXNlczpcbiAgICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzE0NDFcbiAgICAgICAgICB0aHJvdyBuZXcgV29ya2JveEVycm9yKCdtaXNzaW5nLXByZWNhY2hlLWVudHJ5Jywge1xuICAgICAgICAgICAgY2FjaGVOYW1lOiB0aGlzLmNhY2hlTmFtZSxcbiAgICAgICAgICAgIHVybDogcmVxdWVzdC51cmxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB7XG4gICAgICAgICAgY29uc3QgY2FjaGVLZXkgPSBwYXJhbXMuY2FjaGVLZXkgfHwgKGF3YWl0IGhhbmRsZXIuZ2V0Q2FjaGVLZXkocmVxdWVzdCwgJ3JlYWQnKSk7XG4gICAgICAgICAgLy8gV29ya2JveCBpcyBnb2luZyB0byBoYW5kbGUgdGhlIHJvdXRlLlxuICAgICAgICAgIC8vIHByaW50IHRoZSByb3V0aW5nIGRldGFpbHMgdG8gdGhlIGNvbnNvbGUuXG4gICAgICAgICAgbG9nZ2VyLmdyb3VwQ29sbGFwc2VkKGBQcmVjYWNoaW5nIGlzIHJlc3BvbmRpbmcgdG86IGAgKyBnZXRGcmllbmRseVVSTChyZXF1ZXN0LnVybCkpO1xuICAgICAgICAgIGxvZ2dlci5sb2coYFNlcnZpbmcgdGhlIHByZWNhY2hlZCB1cmw6ICR7Z2V0RnJpZW5kbHlVUkwoY2FjaGVLZXkgaW5zdGFuY2VvZiBSZXF1ZXN0ID8gY2FjaGVLZXkudXJsIDogY2FjaGVLZXkpfWApO1xuICAgICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgVmlldyByZXF1ZXN0IGRldGFpbHMgaGVyZS5gKTtcbiAgICAgICAgICBsb2dnZXIubG9nKHJlcXVlc3QpO1xuICAgICAgICAgIGxvZ2dlci5ncm91cEVuZCgpO1xuICAgICAgICAgIGxvZ2dlci5ncm91cENvbGxhcHNlZChgVmlldyByZXNwb25zZSBkZXRhaWxzIGhlcmUuYCk7XG4gICAgICAgICAgbG9nZ2VyLmxvZyhyZXNwb25zZSk7XG4gICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgICAgbG9nZ2VyLmdyb3VwRW5kKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgYXN5bmMgX2hhbmRsZUluc3RhbGwocmVxdWVzdCwgaGFuZGxlcikge1xuICAgICAgICB0aGlzLl91c2VEZWZhdWx0Q2FjaGVhYmlsaXR5UGx1Z2luSWZOZWVkZWQoKTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBoYW5kbGVyLmZldGNoKHJlcXVlc3QpO1xuICAgICAgICAvLyBNYWtlIHN1cmUgd2UgZGVmZXIgY2FjaGVQdXQoKSB1bnRpbCBhZnRlciB3ZSBrbm93IHRoZSByZXNwb25zZVxuICAgICAgICAvLyBzaG91bGQgYmUgY2FjaGVkOyBzZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yNzM3XG4gICAgICAgIGNvbnN0IHdhc0NhY2hlZCA9IGF3YWl0IGhhbmRsZXIuY2FjaGVQdXQocmVxdWVzdCwgcmVzcG9uc2UuY2xvbmUoKSk7XG4gICAgICAgIGlmICghd2FzQ2FjaGVkKSB7XG4gICAgICAgICAgLy8gVGhyb3dpbmcgaGVyZSB3aWxsIGxlYWQgdG8gdGhlIGBpbnN0YWxsYCBoYW5kbGVyIGZhaWxpbmcsIHdoaWNoXG4gICAgICAgICAgLy8gd2Ugd2FudCB0byBkbyBpZiAqYW55KiBvZiB0aGUgcmVzcG9uc2VzIGFyZW4ndCBzYWZlIHRvIGNhY2hlLlxuICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2JhZC1wcmVjYWNoaW5nLXJlc3BvbnNlJywge1xuICAgICAgICAgICAgdXJsOiByZXF1ZXN0LnVybCxcbiAgICAgICAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBUaGlzIG1ldGhvZCBpcyBjb21wbGV4LCBhcyB0aGVyZSBhIG51bWJlciBvZiB0aGluZ3MgdG8gYWNjb3VudCBmb3I6XG4gICAgICAgKlxuICAgICAgICogVGhlIGBwbHVnaW5zYCBhcnJheSBjYW4gYmUgc2V0IGF0IGNvbnN0cnVjdGlvbiwgYW5kL29yIGl0IG1pZ2h0IGJlIGFkZGVkIHRvXG4gICAgICAgKiB0byBhdCBhbnkgdGltZSBiZWZvcmUgdGhlIHN0cmF0ZWd5IGlzIHVzZWQuXG4gICAgICAgKlxuICAgICAgICogQXQgdGhlIHRpbWUgdGhlIHN0cmF0ZWd5IGlzIHVzZWQgKGkuZS4gZHVyaW5nIGFuIGBpbnN0YWxsYCBldmVudCksIHRoZXJlXG4gICAgICAgKiBuZWVkcyB0byBiZSBhdCBsZWFzdCBvbmUgcGx1Z2luIHRoYXQgaW1wbGVtZW50cyBgY2FjaGVXaWxsVXBkYXRlYCBpbiB0aGVcbiAgICAgICAqIGFycmF5LCBvdGhlciB0aGFuIGBjb3B5UmVkaXJlY3RlZENhY2hlYWJsZVJlc3BvbnNlc1BsdWdpbmAuXG4gICAgICAgKlxuICAgICAgICogLSBJZiB0aGlzIG1ldGhvZCBpcyBjYWxsZWQgYW5kIHRoZXJlIGFyZSBubyBzdWl0YWJsZSBgY2FjaGVXaWxsVXBkYXRlYFxuICAgICAgICogcGx1Z2lucywgd2UgbmVlZCB0byBhZGQgYGRlZmF1bHRQcmVjYWNoZUNhY2hlYWJpbGl0eVBsdWdpbmAuXG4gICAgICAgKlxuICAgICAgICogLSBJZiB0aGlzIG1ldGhvZCBpcyBjYWxsZWQgYW5kIHRoZXJlIGlzIGV4YWN0bHkgb25lIGBjYWNoZVdpbGxVcGRhdGVgLCB0aGVuXG4gICAgICAgKiB3ZSBkb24ndCBoYXZlIHRvIGRvIGFueXRoaW5nICh0aGlzIG1pZ2h0IGJlIGEgcHJldmlvdXNseSBhZGRlZFxuICAgICAgICogYGRlZmF1bHRQcmVjYWNoZUNhY2hlYWJpbGl0eVBsdWdpbmAsIG9yIGl0IG1pZ2h0IGJlIGEgY3VzdG9tIHBsdWdpbikuXG4gICAgICAgKlxuICAgICAgICogLSBJZiB0aGlzIG1ldGhvZCBpcyBjYWxsZWQgYW5kIHRoZXJlIGlzIG1vcmUgdGhhbiBvbmUgYGNhY2hlV2lsbFVwZGF0ZWAsXG4gICAgICAgKiB0aGVuIHdlIG5lZWQgdG8gY2hlY2sgaWYgb25lIGlzIGBkZWZhdWx0UHJlY2FjaGVDYWNoZWFiaWxpdHlQbHVnaW5gLiBJZiBzbyxcbiAgICAgICAqIHdlIG5lZWQgdG8gcmVtb3ZlIGl0LiAoVGhpcyBzaXR1YXRpb24gaXMgdW5saWtlbHksIGJ1dCBpdCBjb3VsZCBoYXBwZW4gaWZcbiAgICAgICAqIHRoZSBzdHJhdGVneSBpcyB1c2VkIG11bHRpcGxlIHRpbWVzLCB0aGUgZmlyc3Qgd2l0aG91dCBhIGBjYWNoZVdpbGxVcGRhdGVgLFxuICAgICAgICogYW5kIHRoZW4gbGF0ZXIgb24gYWZ0ZXIgbWFudWFsbHkgYWRkaW5nIGEgY3VzdG9tIGBjYWNoZVdpbGxVcGRhdGVgLilcbiAgICAgICAqXG4gICAgICAgKiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yNzM3IGZvciBtb3JlIGNvbnRleHQuXG4gICAgICAgKlxuICAgICAgICogQHByaXZhdGVcbiAgICAgICAqL1xuICAgICAgX3VzZURlZmF1bHRDYWNoZWFiaWxpdHlQbHVnaW5JZk5lZWRlZCgpIHtcbiAgICAgICAgbGV0IGRlZmF1bHRQbHVnaW5JbmRleCA9IG51bGw7XG4gICAgICAgIGxldCBjYWNoZVdpbGxVcGRhdGVQbHVnaW5Db3VudCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgW2luZGV4LCBwbHVnaW5dIG9mIHRoaXMucGx1Z2lucy5lbnRyaWVzKCkpIHtcbiAgICAgICAgICAvLyBJZ25vcmUgdGhlIGNvcHkgcmVkaXJlY3RlZCBwbHVnaW4gd2hlbiBkZXRlcm1pbmluZyB3aGF0IHRvIGRvLlxuICAgICAgICAgIGlmIChwbHVnaW4gPT09IFByZWNhY2hlU3RyYXRlZ3kuY29weVJlZGlyZWN0ZWRDYWNoZWFibGVSZXNwb25zZXNQbHVnaW4pIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyBTYXZlIHRoZSBkZWZhdWx0IHBsdWdpbidzIGluZGV4LCBpbiBjYXNlIGl0IG5lZWRzIHRvIGJlIHJlbW92ZWQuXG4gICAgICAgICAgaWYgKHBsdWdpbiA9PT0gUHJlY2FjaGVTdHJhdGVneS5kZWZhdWx0UHJlY2FjaGVDYWNoZWFiaWxpdHlQbHVnaW4pIHtcbiAgICAgICAgICAgIGRlZmF1bHRQbHVnaW5JbmRleCA9IGluZGV4O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAocGx1Z2luLmNhY2hlV2lsbFVwZGF0ZSkge1xuICAgICAgICAgICAgY2FjaGVXaWxsVXBkYXRlUGx1Z2luQ291bnQrKztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNhY2hlV2lsbFVwZGF0ZVBsdWdpbkNvdW50ID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5wbHVnaW5zLnB1c2goUHJlY2FjaGVTdHJhdGVneS5kZWZhdWx0UHJlY2FjaGVDYWNoZWFiaWxpdHlQbHVnaW4pO1xuICAgICAgICB9IGVsc2UgaWYgKGNhY2hlV2lsbFVwZGF0ZVBsdWdpbkNvdW50ID4gMSAmJiBkZWZhdWx0UGx1Z2luSW5kZXggIT09IG51bGwpIHtcbiAgICAgICAgICAvLyBPbmx5IHJlbW92ZSB0aGUgZGVmYXVsdCBwbHVnaW47IG11bHRpcGxlIGN1c3RvbSBwbHVnaW5zIGFyZSBhbGxvd2VkLlxuICAgICAgICAgIHRoaXMucGx1Z2lucy5zcGxpY2UoZGVmYXVsdFBsdWdpbkluZGV4LCAxKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBOb3RoaW5nIG5lZWRzIHRvIGJlIGRvbmUgaWYgY2FjaGVXaWxsVXBkYXRlUGx1Z2luQ291bnQgaXMgMVxuICAgICAgfVxuICAgIH1cbiAgICBQcmVjYWNoZVN0cmF0ZWd5LmRlZmF1bHRQcmVjYWNoZUNhY2hlYWJpbGl0eVBsdWdpbiA9IHtcbiAgICAgIGFzeW5jIGNhY2hlV2lsbFVwZGF0ZSh7XG4gICAgICAgIHJlc3BvbnNlXG4gICAgICB9KSB7XG4gICAgICAgIGlmICghcmVzcG9uc2UgfHwgcmVzcG9uc2Uuc3RhdHVzID49IDQwMCkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgIH1cbiAgICB9O1xuICAgIFByZWNhY2hlU3RyYXRlZ3kuY29weVJlZGlyZWN0ZWRDYWNoZWFibGVSZXNwb25zZXNQbHVnaW4gPSB7XG4gICAgICBhc3luYyBjYWNoZVdpbGxVcGRhdGUoe1xuICAgICAgICByZXNwb25zZVxuICAgICAgfSkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UucmVkaXJlY3RlZCA/IGF3YWl0IGNvcHlSZXNwb25zZShyZXNwb25zZSkgOiByZXNwb25zZTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogUGVyZm9ybXMgZWZmaWNpZW50IHByZWNhY2hpbmcgb2YgYXNzZXRzLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGNsYXNzIFByZWNhY2hlQ29udHJvbGxlciB7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZSBhIG5ldyBQcmVjYWNoZUNvbnRyb2xsZXIuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRpb25zLmNhY2hlTmFtZV0gVGhlIGNhY2hlIHRvIHVzZSBmb3IgcHJlY2FjaGluZy5cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy5wbHVnaW5zXSBQbHVnaW5zIHRvIHVzZSB3aGVuIHByZWNhY2hpbmcgYXMgd2VsbFxuICAgICAgICogYXMgcmVzcG9uZGluZyB0byBmZXRjaCBldmVudHMgZm9yIHByZWNhY2hlZCBhc3NldHMuXG4gICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IFtvcHRpb25zLmZhbGxiYWNrVG9OZXR3b3JrPXRydWVdIFdoZXRoZXIgdG8gYXR0ZW1wdCB0b1xuICAgICAgICogZ2V0IHRoZSByZXNwb25zZSBmcm9tIHRoZSBuZXR3b3JrIGlmIHRoZXJlJ3MgYSBwcmVjYWNoZSBtaXNzLlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3Rvcih7XG4gICAgICAgIGNhY2hlTmFtZSxcbiAgICAgICAgcGx1Z2lucyA9IFtdLFxuICAgICAgICBmYWxsYmFja1RvTmV0d29yayA9IHRydWVcbiAgICAgIH0gPSB7fSkge1xuICAgICAgICB0aGlzLl91cmxzVG9DYWNoZUtleXMgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMuX3VybHNUb0NhY2hlTW9kZXMgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMuX2NhY2hlS2V5c1RvSW50ZWdyaXRpZXMgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMuX3N0cmF0ZWd5ID0gbmV3IFByZWNhY2hlU3RyYXRlZ3koe1xuICAgICAgICAgIGNhY2hlTmFtZTogY2FjaGVOYW1lcy5nZXRQcmVjYWNoZU5hbWUoY2FjaGVOYW1lKSxcbiAgICAgICAgICBwbHVnaW5zOiBbLi4ucGx1Z2lucywgbmV3IFByZWNhY2hlQ2FjaGVLZXlQbHVnaW4oe1xuICAgICAgICAgICAgcHJlY2FjaGVDb250cm9sbGVyOiB0aGlzXG4gICAgICAgICAgfSldLFxuICAgICAgICAgIGZhbGxiYWNrVG9OZXR3b3JrXG4gICAgICAgIH0pO1xuICAgICAgICAvLyBCaW5kIHRoZSBpbnN0YWxsIGFuZCBhY3RpdmF0ZSBtZXRob2RzIHRvIHRoZSBpbnN0YW5jZS5cbiAgICAgICAgdGhpcy5pbnN0YWxsID0gdGhpcy5pbnN0YWxsLmJpbmQodGhpcyk7XG4gICAgICAgIHRoaXMuYWN0aXZhdGUgPSB0aGlzLmFjdGl2YXRlLmJpbmQodGhpcyk7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEB0eXBlIHt3b3JrYm94LXByZWNhY2hpbmcuUHJlY2FjaGVTdHJhdGVneX0gVGhlIHN0cmF0ZWd5IGNyZWF0ZWQgYnkgdGhpcyBjb250cm9sbGVyIGFuZFxuICAgICAgICogdXNlZCB0byBjYWNoZSBhc3NldHMgYW5kIHJlc3BvbmQgdG8gZmV0Y2ggZXZlbnRzLlxuICAgICAgICovXG4gICAgICBnZXQgc3RyYXRlZ3koKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9zdHJhdGVneTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogQWRkcyBpdGVtcyB0byB0aGUgcHJlY2FjaGUgbGlzdCwgcmVtb3ZpbmcgYW55IGR1cGxpY2F0ZXMgYW5kXG4gICAgICAgKiBzdG9yZXMgdGhlIGZpbGVzIGluIHRoZVxuICAgICAgICoge0BsaW5rIHdvcmtib3gtY29yZS5jYWNoZU5hbWVzfFwicHJlY2FjaGUgY2FjaGVcIn0gd2hlbiB0aGUgc2VydmljZVxuICAgICAgICogd29ya2VyIGluc3RhbGxzLlxuICAgICAgICpcbiAgICAgICAqIFRoaXMgbWV0aG9kIGNhbiBiZSBjYWxsZWQgbXVsdGlwbGUgdGltZXMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtBcnJheTxPYmplY3R8c3RyaW5nPn0gW2VudHJpZXM9W11dIEFycmF5IG9mIGVudHJpZXMgdG8gcHJlY2FjaGUuXG4gICAgICAgKi9cbiAgICAgIHByZWNhY2hlKGVudHJpZXMpIHtcbiAgICAgICAgdGhpcy5hZGRUb0NhY2hlTGlzdChlbnRyaWVzKTtcbiAgICAgICAgaWYgKCF0aGlzLl9pbnN0YWxsQW5kQWN0aXZlTGlzdGVuZXJzQWRkZWQpIHtcbiAgICAgICAgICBzZWxmLmFkZEV2ZW50TGlzdGVuZXIoJ2luc3RhbGwnLCB0aGlzLmluc3RhbGwpO1xuICAgICAgICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lcignYWN0aXZhdGUnLCB0aGlzLmFjdGl2YXRlKTtcbiAgICAgICAgICB0aGlzLl9pbnN0YWxsQW5kQWN0aXZlTGlzdGVuZXJzQWRkZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFRoaXMgbWV0aG9kIHdpbGwgYWRkIGl0ZW1zIHRvIHRoZSBwcmVjYWNoZSBsaXN0LCByZW1vdmluZyBkdXBsaWNhdGVzXG4gICAgICAgKiBhbmQgZW5zdXJpbmcgdGhlIGluZm9ybWF0aW9uIGlzIHZhbGlkLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7QXJyYXk8d29ya2JveC1wcmVjYWNoaW5nLlByZWNhY2hlQ29udHJvbGxlci5QcmVjYWNoZUVudHJ5fHN0cmluZz59IGVudHJpZXNcbiAgICAgICAqICAgICBBcnJheSBvZiBlbnRyaWVzIHRvIHByZWNhY2hlLlxuICAgICAgICovXG4gICAgICBhZGRUb0NhY2hlTGlzdChlbnRyaWVzKSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNBcnJheShlbnRyaWVzLCB7XG4gICAgICAgICAgICBtb2R1bGVOYW1lOiAnd29ya2JveC1wcmVjYWNoaW5nJyxcbiAgICAgICAgICAgIGNsYXNzTmFtZTogJ1ByZWNhY2hlQ29udHJvbGxlcicsXG4gICAgICAgICAgICBmdW5jTmFtZTogJ2FkZFRvQ2FjaGVMaXN0JyxcbiAgICAgICAgICAgIHBhcmFtTmFtZTogJ2VudHJpZXMnXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXJsc1RvV2FybkFib3V0ID0gW107XG4gICAgICAgIGZvciAoY29uc3QgZW50cnkgb2YgZW50cmllcykge1xuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzIyNTlcbiAgICAgICAgICBpZiAodHlwZW9mIGVudHJ5ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgdXJsc1RvV2FybkFib3V0LnB1c2goZW50cnkpO1xuICAgICAgICAgIH0gZWxzZSBpZiAoZW50cnkgJiYgZW50cnkucmV2aXNpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdXJsc1RvV2FybkFib3V0LnB1c2goZW50cnkudXJsKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgY2FjaGVLZXksXG4gICAgICAgICAgICB1cmxcbiAgICAgICAgICB9ID0gY3JlYXRlQ2FjaGVLZXkoZW50cnkpO1xuICAgICAgICAgIGNvbnN0IGNhY2hlTW9kZSA9IHR5cGVvZiBlbnRyeSAhPT0gJ3N0cmluZycgJiYgZW50cnkucmV2aXNpb24gPyAncmVsb2FkJyA6ICdkZWZhdWx0JztcbiAgICAgICAgICBpZiAodGhpcy5fdXJsc1RvQ2FjaGVLZXlzLmhhcyh1cmwpICYmIHRoaXMuX3VybHNUb0NhY2hlS2V5cy5nZXQodXJsKSAhPT0gY2FjaGVLZXkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2FkZC10by1jYWNoZS1saXN0LWNvbmZsaWN0aW5nLWVudHJpZXMnLCB7XG4gICAgICAgICAgICAgIGZpcnN0RW50cnk6IHRoaXMuX3VybHNUb0NhY2hlS2V5cy5nZXQodXJsKSxcbiAgICAgICAgICAgICAgc2Vjb25kRW50cnk6IGNhY2hlS2V5XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHR5cGVvZiBlbnRyeSAhPT0gJ3N0cmluZycgJiYgZW50cnkuaW50ZWdyaXR5KSB7XG4gICAgICAgICAgICBpZiAodGhpcy5fY2FjaGVLZXlzVG9JbnRlZ3JpdGllcy5oYXMoY2FjaGVLZXkpICYmIHRoaXMuX2NhY2hlS2V5c1RvSW50ZWdyaXRpZXMuZ2V0KGNhY2hlS2V5KSAhPT0gZW50cnkuaW50ZWdyaXR5KSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBXb3JrYm94RXJyb3IoJ2FkZC10by1jYWNoZS1saXN0LWNvbmZsaWN0aW5nLWludGVncml0aWVzJywge1xuICAgICAgICAgICAgICAgIHVybFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuX2NhY2hlS2V5c1RvSW50ZWdyaXRpZXMuc2V0KGNhY2hlS2V5LCBlbnRyeS5pbnRlZ3JpdHkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLl91cmxzVG9DYWNoZUtleXMuc2V0KHVybCwgY2FjaGVLZXkpO1xuICAgICAgICAgIHRoaXMuX3VybHNUb0NhY2hlTW9kZXMuc2V0KHVybCwgY2FjaGVNb2RlKTtcbiAgICAgICAgICBpZiAodXJsc1RvV2FybkFib3V0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IHdhcm5pbmdNZXNzYWdlID0gYFdvcmtib3ggaXMgcHJlY2FjaGluZyBVUkxzIHdpdGhvdXQgcmV2aXNpb24gYCArIGBpbmZvOiAke3VybHNUb1dhcm5BYm91dC5qb2luKCcsICcpfVxcblRoaXMgaXMgZ2VuZXJhbGx5IE5PVCBzYWZlLiBgICsgYExlYXJuIG1vcmUgYXQgaHR0cHM6Ly9iaXQubHkvd2ItcHJlY2FjaGVgO1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBsb2dnZXIud2Fybih3YXJuaW5nTWVzc2FnZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFByZWNhY2hlcyBuZXcgYW5kIHVwZGF0ZWQgYXNzZXRzLiBDYWxsIHRoaXMgbWV0aG9kIGZyb20gdGhlIHNlcnZpY2Ugd29ya2VyXG4gICAgICAgKiBpbnN0YWxsIGV2ZW50LlxuICAgICAgICpcbiAgICAgICAqIE5vdGU6IHRoaXMgbWV0aG9kIGNhbGxzIGBldmVudC53YWl0VW50aWwoKWAgZm9yIHlvdSwgc28geW91IGRvIG5vdCBuZWVkXG4gICAgICAgKiB0byBjYWxsIGl0IHlvdXJzZWxmIGluIHlvdXIgZXZlbnQgaGFuZGxlcnMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IGV2ZW50XG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPHdvcmtib3gtcHJlY2FjaGluZy5JbnN0YWxsUmVzdWx0Pn1cbiAgICAgICAqL1xuICAgICAgaW5zdGFsbChldmVudCkge1xuICAgICAgICAvLyB3YWl0VW50aWwgcmV0dXJucyBQcm9taXNlPGFueT5cbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnNhZmUtcmV0dXJuXG4gICAgICAgIHJldHVybiB3YWl0VW50aWwoZXZlbnQsIGFzeW5jICgpID0+IHtcbiAgICAgICAgICBjb25zdCBpbnN0YWxsUmVwb3J0UGx1Z2luID0gbmV3IFByZWNhY2hlSW5zdGFsbFJlcG9ydFBsdWdpbigpO1xuICAgICAgICAgIHRoaXMuc3RyYXRlZ3kucGx1Z2lucy5wdXNoKGluc3RhbGxSZXBvcnRQbHVnaW4pO1xuICAgICAgICAgIC8vIENhY2hlIGVudHJpZXMgb25lIGF0IGEgdGltZS5cbiAgICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0dvb2dsZUNocm9tZS93b3JrYm94L2lzc3Vlcy8yNTI4XG4gICAgICAgICAgZm9yIChjb25zdCBbdXJsLCBjYWNoZUtleV0gb2YgdGhpcy5fdXJsc1RvQ2FjaGVLZXlzKSB7XG4gICAgICAgICAgICBjb25zdCBpbnRlZ3JpdHkgPSB0aGlzLl9jYWNoZUtleXNUb0ludGVncml0aWVzLmdldChjYWNoZUtleSk7XG4gICAgICAgICAgICBjb25zdCBjYWNoZU1vZGUgPSB0aGlzLl91cmxzVG9DYWNoZU1vZGVzLmdldCh1cmwpO1xuICAgICAgICAgICAgY29uc3QgcmVxdWVzdCA9IG5ldyBSZXF1ZXN0KHVybCwge1xuICAgICAgICAgICAgICBpbnRlZ3JpdHksXG4gICAgICAgICAgICAgIGNhY2hlOiBjYWNoZU1vZGUsXG4gICAgICAgICAgICAgIGNyZWRlbnRpYWxzOiAnc2FtZS1vcmlnaW4nXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKHRoaXMuc3RyYXRlZ3kuaGFuZGxlQWxsKHtcbiAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgY2FjaGVLZXlcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgICAgICAgZXZlbnRcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgdXBkYXRlZFVSTHMsXG4gICAgICAgICAgICBub3RVcGRhdGVkVVJMc1xuICAgICAgICAgIH0gPSBpbnN0YWxsUmVwb3J0UGx1Z2luO1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIHByaW50SW5zdGFsbERldGFpbHModXBkYXRlZFVSTHMsIG5vdFVwZGF0ZWRVUkxzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHVwZGF0ZWRVUkxzLFxuICAgICAgICAgICAgbm90VXBkYXRlZFVSTHNcbiAgICAgICAgICB9O1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogRGVsZXRlcyBhc3NldHMgdGhhdCBhcmUgbm8gbG9uZ2VyIHByZXNlbnQgaW4gdGhlIGN1cnJlbnQgcHJlY2FjaGUgbWFuaWZlc3QuXG4gICAgICAgKiBDYWxsIHRoaXMgbWV0aG9kIGZyb20gdGhlIHNlcnZpY2Ugd29ya2VyIGFjdGl2YXRlIGV2ZW50LlxuICAgICAgICpcbiAgICAgICAqIE5vdGU6IHRoaXMgbWV0aG9kIGNhbGxzIGBldmVudC53YWl0VW50aWwoKWAgZm9yIHlvdSwgc28geW91IGRvIG5vdCBuZWVkXG4gICAgICAgKiB0byBjYWxsIGl0IHlvdXJzZWxmIGluIHlvdXIgZXZlbnQgaGFuZGxlcnMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtFeHRlbmRhYmxlRXZlbnR9IGV2ZW50XG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPHdvcmtib3gtcHJlY2FjaGluZy5DbGVhbnVwUmVzdWx0Pn1cbiAgICAgICAqL1xuICAgICAgYWN0aXZhdGUoZXZlbnQpIHtcbiAgICAgICAgLy8gd2FpdFVudGlsIHJldHVybnMgUHJvbWlzZTxhbnk+XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLXJldHVyblxuICAgICAgICByZXR1cm4gd2FpdFVudGlsKGV2ZW50LCBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgY29uc3QgY2FjaGUgPSBhd2FpdCBzZWxmLmNhY2hlcy5vcGVuKHRoaXMuc3RyYXRlZ3kuY2FjaGVOYW1lKTtcbiAgICAgICAgICBjb25zdCBjdXJyZW50bHlDYWNoZWRSZXF1ZXN0cyA9IGF3YWl0IGNhY2hlLmtleXMoKTtcbiAgICAgICAgICBjb25zdCBleHBlY3RlZENhY2hlS2V5cyA9IG5ldyBTZXQodGhpcy5fdXJsc1RvQ2FjaGVLZXlzLnZhbHVlcygpKTtcbiAgICAgICAgICBjb25zdCBkZWxldGVkVVJMcyA9IFtdO1xuICAgICAgICAgIGZvciAoY29uc3QgcmVxdWVzdCBvZiBjdXJyZW50bHlDYWNoZWRSZXF1ZXN0cykge1xuICAgICAgICAgICAgaWYgKCFleHBlY3RlZENhY2hlS2V5cy5oYXMocmVxdWVzdC51cmwpKSB7XG4gICAgICAgICAgICAgIGF3YWl0IGNhY2hlLmRlbGV0ZShyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgZGVsZXRlZFVSTHMucHVzaChyZXF1ZXN0LnVybCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHByaW50Q2xlYW51cERldGFpbHMoZGVsZXRlZFVSTHMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZGVsZXRlZFVSTHNcbiAgICAgICAgICB9O1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyBhIG1hcHBpbmcgb2YgYSBwcmVjYWNoZWQgVVJMIHRvIHRoZSBjb3JyZXNwb25kaW5nIGNhY2hlIGtleSwgdGFraW5nXG4gICAgICAgKiBpbnRvIGFjY291bnQgdGhlIHJldmlzaW9uIGluZm9ybWF0aW9uIGZvciB0aGUgVVJMLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm4ge01hcDxzdHJpbmcsIHN0cmluZz59IEEgVVJMIHRvIGNhY2hlIGtleSBtYXBwaW5nLlxuICAgICAgICovXG4gICAgICBnZXRVUkxzVG9DYWNoZUtleXMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl91cmxzVG9DYWNoZUtleXM7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgYSBsaXN0IG9mIGFsbCB0aGUgVVJMcyB0aGF0IGhhdmUgYmVlbiBwcmVjYWNoZWQgYnkgdGhlIGN1cnJlbnRcbiAgICAgICAqIHNlcnZpY2Ugd29ya2VyLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm4ge0FycmF5PHN0cmluZz59IFRoZSBwcmVjYWNoZWQgVVJMcy5cbiAgICAgICAqL1xuICAgICAgZ2V0Q2FjaGVkVVJMcygpIHtcbiAgICAgICAgcmV0dXJuIFsuLi50aGlzLl91cmxzVG9DYWNoZUtleXMua2V5cygpXTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyB0aGUgY2FjaGUga2V5IHVzZWQgZm9yIHN0b3JpbmcgYSBnaXZlbiBVUkwuIElmIHRoYXQgVVJMIGlzXG4gICAgICAgKiB1bnZlcnNpb25lZCwgbGlrZSBgL2luZGV4Lmh0bWwnLCB0aGVuIHRoZSBjYWNoZSBrZXkgd2lsbCBiZSB0aGUgb3JpZ2luYWxcbiAgICAgICAqIFVSTCB3aXRoIGEgc2VhcmNoIHBhcmFtZXRlciBhcHBlbmRlZCB0byBpdC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsIEEgVVJMIHdob3NlIGNhY2hlIGtleSB5b3Ugd2FudCB0byBsb29rIHVwLlxuICAgICAgICogQHJldHVybiB7c3RyaW5nfSBUaGUgdmVyc2lvbmVkIFVSTCB0aGF0IGNvcnJlc3BvbmRzIHRvIGEgY2FjaGUga2V5XG4gICAgICAgKiBmb3IgdGhlIG9yaWdpbmFsIFVSTCwgb3IgdW5kZWZpbmVkIGlmIHRoYXQgVVJMIGlzbid0IHByZWNhY2hlZC5cbiAgICAgICAqL1xuICAgICAgZ2V0Q2FjaGVLZXlGb3JVUkwodXJsKSB7XG4gICAgICAgIGNvbnN0IHVybE9iamVjdCA9IG5ldyBVUkwodXJsLCBsb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3VybHNUb0NhY2hlS2V5cy5nZXQodXJsT2JqZWN0LmhyZWYpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsIEEgY2FjaGUga2V5IHdob3NlIFNSSSB5b3Ugd2FudCB0byBsb29rIHVwLlxuICAgICAgICogQHJldHVybiB7c3RyaW5nfSBUaGUgc3VicmVzb3VyY2UgaW50ZWdyaXR5IGFzc29jaWF0ZWQgd2l0aCB0aGUgY2FjaGUga2V5LFxuICAgICAgICogb3IgdW5kZWZpbmVkIGlmIGl0J3Mgbm90IHNldC5cbiAgICAgICAqL1xuICAgICAgZ2V0SW50ZWdyaXR5Rm9yQ2FjaGVLZXkoY2FjaGVLZXkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NhY2hlS2V5c1RvSW50ZWdyaXRpZXMuZ2V0KGNhY2hlS2V5KTtcbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogVGhpcyBhY3RzIGFzIGEgZHJvcC1pbiByZXBsYWNlbWVudCBmb3JcbiAgICAgICAqIFtgY2FjaGUubWF0Y2goKWBdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9DYWNoZS9tYXRjaClcbiAgICAgICAqIHdpdGggdGhlIGZvbGxvd2luZyBkaWZmZXJlbmNlczpcbiAgICAgICAqXG4gICAgICAgKiAtIEl0IGtub3dzIHdoYXQgdGhlIG5hbWUgb2YgdGhlIHByZWNhY2hlIGlzLCBhbmQgb25seSBjaGVja3MgaW4gdGhhdCBjYWNoZS5cbiAgICAgICAqIC0gSXQgYWxsb3dzIHlvdSB0byBwYXNzIGluIGFuIFwib3JpZ2luYWxcIiBVUkwgd2l0aG91dCB2ZXJzaW9uaW5nIHBhcmFtZXRlcnMsXG4gICAgICAgKiBhbmQgaXQgd2lsbCBhdXRvbWF0aWNhbGx5IGxvb2sgdXAgdGhlIGNvcnJlY3QgY2FjaGUga2V5IGZvciB0aGUgY3VycmVudGx5XG4gICAgICAgKiBhY3RpdmUgcmV2aXNpb24gb2YgdGhhdCBVUkwuXG4gICAgICAgKlxuICAgICAgICogRS5nLiwgYG1hdGNoUHJlY2FjaGUoJ2luZGV4Lmh0bWwnKWAgd2lsbCBmaW5kIHRoZSBjb3JyZWN0IHByZWNhY2hlZFxuICAgICAgICogcmVzcG9uc2UgZm9yIHRoZSBjdXJyZW50bHkgYWN0aXZlIHNlcnZpY2Ugd29ya2VyLCBldmVuIGlmIHRoZSBhY3R1YWwgY2FjaGVcbiAgICAgICAqIGtleSBpcyBgJy9pbmRleC5odG1sP19fV0JfUkVWSVNJT05fXz0xMjM0YWJjZCdgLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfFJlcXVlc3R9IHJlcXVlc3QgVGhlIGtleSAod2l0aG91dCByZXZpc2lvbmluZyBwYXJhbWV0ZXJzKVxuICAgICAgICogdG8gbG9vayB1cCBpbiB0aGUgcHJlY2FjaGUuXG4gICAgICAgKiBAcmV0dXJuIHtQcm9taXNlPFJlc3BvbnNlfHVuZGVmaW5lZD59XG4gICAgICAgKi9cbiAgICAgIGFzeW5jIG1hdGNoUHJlY2FjaGUocmVxdWVzdCkge1xuICAgICAgICBjb25zdCB1cmwgPSByZXF1ZXN0IGluc3RhbmNlb2YgUmVxdWVzdCA/IHJlcXVlc3QudXJsIDogcmVxdWVzdDtcbiAgICAgICAgY29uc3QgY2FjaGVLZXkgPSB0aGlzLmdldENhY2hlS2V5Rm9yVVJMKHVybCk7XG4gICAgICAgIGlmIChjYWNoZUtleSkge1xuICAgICAgICAgIGNvbnN0IGNhY2hlID0gYXdhaXQgc2VsZi5jYWNoZXMub3Blbih0aGlzLnN0cmF0ZWd5LmNhY2hlTmFtZSk7XG4gICAgICAgICAgcmV0dXJuIGNhY2hlLm1hdGNoKGNhY2hlS2V5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSZXR1cm5zIGEgZnVuY3Rpb24gdGhhdCBsb29rcyB1cCBgdXJsYCBpbiB0aGUgcHJlY2FjaGUgKHRha2luZyBpbnRvXG4gICAgICAgKiBhY2NvdW50IHJldmlzaW9uIGluZm9ybWF0aW9uKSwgYW5kIHJldHVybnMgdGhlIGNvcnJlc3BvbmRpbmcgYFJlc3BvbnNlYC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsIFRoZSBwcmVjYWNoZWQgVVJMIHdoaWNoIHdpbGwgYmUgdXNlZCB0byBsb29rdXAgdGhlXG4gICAgICAgKiBgUmVzcG9uc2VgLlxuICAgICAgICogQHJldHVybiB7d29ya2JveC1yb3V0aW5nfmhhbmRsZXJDYWxsYmFja31cbiAgICAgICAqL1xuICAgICAgY3JlYXRlSGFuZGxlckJvdW5kVG9VUkwodXJsKSB7XG4gICAgICAgIGNvbnN0IGNhY2hlS2V5ID0gdGhpcy5nZXRDYWNoZUtleUZvclVSTCh1cmwpO1xuICAgICAgICBpZiAoIWNhY2hlS2V5KSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFdvcmtib3hFcnJvcignbm9uLXByZWNhY2hlZC11cmwnLCB7XG4gICAgICAgICAgICB1cmxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3B0aW9ucyA9PiB7XG4gICAgICAgICAgb3B0aW9ucy5yZXF1ZXN0ID0gbmV3IFJlcXVlc3QodXJsKTtcbiAgICAgICAgICBvcHRpb25zLnBhcmFtcyA9IE9iamVjdC5hc3NpZ24oe1xuICAgICAgICAgICAgY2FjaGVLZXlcbiAgICAgICAgICB9LCBvcHRpb25zLnBhcmFtcyk7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuc3RyYXRlZ3kuaGFuZGxlKG9wdGlvbnMpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIGxldCBwcmVjYWNoZUNvbnRyb2xsZXI7XG4gICAgLyoqXG4gICAgICogQHJldHVybiB7UHJlY2FjaGVDb250cm9sbGVyfVxuICAgICAqIEBwcml2YXRlXG4gICAgICovXG4gICAgY29uc3QgZ2V0T3JDcmVhdGVQcmVjYWNoZUNvbnRyb2xsZXIgPSAoKSA9PiB7XG4gICAgICBpZiAoIXByZWNhY2hlQ29udHJvbGxlcikge1xuICAgICAgICBwcmVjYWNoZUNvbnRyb2xsZXIgPSBuZXcgUHJlY2FjaGVDb250cm9sbGVyKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcHJlY2FjaGVDb250cm9sbGVyO1xuICAgIH07XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBSZW1vdmVzIGFueSBVUkwgc2VhcmNoIHBhcmFtZXRlcnMgdGhhdCBzaG91bGQgYmUgaWdub3JlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7VVJMfSB1cmxPYmplY3QgVGhlIG9yaWdpbmFsIFVSTC5cbiAgICAgKiBAcGFyYW0ge0FycmF5PFJlZ0V4cD59IGlnbm9yZVVSTFBhcmFtZXRlcnNNYXRjaGluZyBSZWdFeHBzIHRvIHRlc3QgYWdhaW5zdFxuICAgICAqIGVhY2ggc2VhcmNoIHBhcmFtZXRlciBuYW1lLiBNYXRjaGVzIG1lYW4gdGhhdCB0aGUgc2VhcmNoIHBhcmFtZXRlciBzaG91bGQgYmVcbiAgICAgKiBpZ25vcmVkLlxuICAgICAqIEByZXR1cm4ge1VSTH0gVGhlIFVSTCB3aXRoIGFueSBpZ25vcmVkIHNlYXJjaCBwYXJhbWV0ZXJzIHJlbW92ZWQuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiByZW1vdmVJZ25vcmVkU2VhcmNoUGFyYW1zKHVybE9iamVjdCwgaWdub3JlVVJMUGFyYW1ldGVyc01hdGNoaW5nID0gW10pIHtcbiAgICAgIC8vIENvbnZlcnQgdGhlIGl0ZXJhYmxlIGludG8gYW4gYXJyYXkgYXQgdGhlIHN0YXJ0IG9mIHRoZSBsb29wIHRvIG1ha2Ugc3VyZVxuICAgICAgLy8gZGVsZXRpb24gZG9lc24ndCBtZXNzIHVwIGl0ZXJhdGlvbi5cbiAgICAgIGZvciAoY29uc3QgcGFyYW1OYW1lIG9mIFsuLi51cmxPYmplY3Quc2VhcmNoUGFyYW1zLmtleXMoKV0pIHtcbiAgICAgICAgaWYgKGlnbm9yZVVSTFBhcmFtZXRlcnNNYXRjaGluZy5zb21lKHJlZ0V4cCA9PiByZWdFeHAudGVzdChwYXJhbU5hbWUpKSkge1xuICAgICAgICAgIHVybE9iamVjdC5zZWFyY2hQYXJhbXMuZGVsZXRlKHBhcmFtTmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB1cmxPYmplY3Q7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogR2VuZXJhdG9yIGZ1bmN0aW9uIHRoYXQgeWllbGRzIHBvc3NpYmxlIHZhcmlhdGlvbnMgb24gdGhlIG9yaWdpbmFsIFVSTCB0b1xuICAgICAqIGNoZWNrLCBvbmUgYXQgYSB0aW1lLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBmdW5jdGlvbiogZ2VuZXJhdGVVUkxWYXJpYXRpb25zKHVybCwge1xuICAgICAgaWdub3JlVVJMUGFyYW1ldGVyc01hdGNoaW5nID0gWy9edXRtXy8sIC9eZmJjbGlkJC9dLFxuICAgICAgZGlyZWN0b3J5SW5kZXggPSAnaW5kZXguaHRtbCcsXG4gICAgICBjbGVhblVSTHMgPSB0cnVlLFxuICAgICAgdXJsTWFuaXB1bGF0aW9uXG4gICAgfSA9IHt9KSB7XG4gICAgICBjb25zdCB1cmxPYmplY3QgPSBuZXcgVVJMKHVybCwgbG9jYXRpb24uaHJlZik7XG4gICAgICB1cmxPYmplY3QuaGFzaCA9ICcnO1xuICAgICAgeWllbGQgdXJsT2JqZWN0LmhyZWY7XG4gICAgICBjb25zdCB1cmxXaXRob3V0SWdub3JlZFBhcmFtcyA9IHJlbW92ZUlnbm9yZWRTZWFyY2hQYXJhbXModXJsT2JqZWN0LCBpZ25vcmVVUkxQYXJhbWV0ZXJzTWF0Y2hpbmcpO1xuICAgICAgeWllbGQgdXJsV2l0aG91dElnbm9yZWRQYXJhbXMuaHJlZjtcbiAgICAgIGlmIChkaXJlY3RvcnlJbmRleCAmJiB1cmxXaXRob3V0SWdub3JlZFBhcmFtcy5wYXRobmFtZS5lbmRzV2l0aCgnLycpKSB7XG4gICAgICAgIGNvbnN0IGRpcmVjdG9yeVVSTCA9IG5ldyBVUkwodXJsV2l0aG91dElnbm9yZWRQYXJhbXMuaHJlZik7XG4gICAgICAgIGRpcmVjdG9yeVVSTC5wYXRobmFtZSArPSBkaXJlY3RvcnlJbmRleDtcbiAgICAgICAgeWllbGQgZGlyZWN0b3J5VVJMLmhyZWY7XG4gICAgICB9XG4gICAgICBpZiAoY2xlYW5VUkxzKSB7XG4gICAgICAgIGNvbnN0IGNsZWFuVVJMID0gbmV3IFVSTCh1cmxXaXRob3V0SWdub3JlZFBhcmFtcy5ocmVmKTtcbiAgICAgICAgY2xlYW5VUkwucGF0aG5hbWUgKz0gJy5odG1sJztcbiAgICAgICAgeWllbGQgY2xlYW5VUkwuaHJlZjtcbiAgICAgIH1cbiAgICAgIGlmICh1cmxNYW5pcHVsYXRpb24pIHtcbiAgICAgICAgY29uc3QgYWRkaXRpb25hbFVSTHMgPSB1cmxNYW5pcHVsYXRpb24oe1xuICAgICAgICAgIHVybDogdXJsT2JqZWN0XG4gICAgICAgIH0pO1xuICAgICAgICBmb3IgKGNvbnN0IHVybFRvQXR0ZW1wdCBvZiBhZGRpdGlvbmFsVVJMcykge1xuICAgICAgICAgIHlpZWxkIHVybFRvQXR0ZW1wdC5ocmVmO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQSBzdWJjbGFzcyBvZiB7QGxpbmsgd29ya2JveC1yb3V0aW5nLlJvdXRlfSB0aGF0IHRha2VzIGFcbiAgICAgKiB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLlByZWNhY2hlQ29udHJvbGxlcn1cbiAgICAgKiBpbnN0YW5jZSBhbmQgdXNlcyBpdCB0byBtYXRjaCBpbmNvbWluZyByZXF1ZXN0cyBhbmQgaGFuZGxlIGZldGNoaW5nXG4gICAgICogcmVzcG9uc2VzIGZyb20gdGhlIHByZWNhY2hlLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqIEBleHRlbmRzIHdvcmtib3gtcm91dGluZy5Sb3V0ZVxuICAgICAqL1xuICAgIGNsYXNzIFByZWNhY2hlUm91dGUgZXh0ZW5kcyBSb3V0ZSB7XG4gICAgICAvKipcbiAgICAgICAqIEBwYXJhbSB7UHJlY2FjaGVDb250cm9sbGVyfSBwcmVjYWNoZUNvbnRyb2xsZXIgQSBgUHJlY2FjaGVDb250cm9sbGVyYFxuICAgICAgICogaW5zdGFuY2UgdXNlZCB0byBib3RoIG1hdGNoIHJlcXVlc3RzIGFuZCByZXNwb25kIHRvIGZldGNoIGV2ZW50cy5cbiAgICAgICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gT3B0aW9ucyB0byBjb250cm9sIGhvdyByZXF1ZXN0cyBhcmUgbWF0Y2hlZFxuICAgICAgICogYWdhaW5zdCB0aGUgbGlzdCBvZiBwcmVjYWNoZWQgVVJMcy5cbiAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy5kaXJlY3RvcnlJbmRleD1pbmRleC5odG1sXSBUaGUgYGRpcmVjdG9yeUluZGV4YCB3aWxsXG4gICAgICAgKiBjaGVjayBjYWNoZSBlbnRyaWVzIGZvciBhIFVSTHMgZW5kaW5nIHdpdGggJy8nIHRvIHNlZSBpZiB0aGVyZSBpcyBhIGhpdCB3aGVuXG4gICAgICAgKiBhcHBlbmRpbmcgdGhlIGBkaXJlY3RvcnlJbmRleGAgdmFsdWUuXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PFJlZ0V4cD59IFtvcHRpb25zLmlnbm9yZVVSTFBhcmFtZXRlcnNNYXRjaGluZz1bL151dG1fLywgL15mYmNsaWQkL11dIEFuXG4gICAgICAgKiBhcnJheSBvZiByZWdleCdzIHRvIHJlbW92ZSBzZWFyY2ggcGFyYW1zIHdoZW4gbG9va2luZyBmb3IgYSBjYWNoZSBtYXRjaC5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gW29wdGlvbnMuY2xlYW5VUkxzPXRydWVdIFRoZSBgY2xlYW5VUkxzYCBvcHRpb24gd2lsbFxuICAgICAgICogY2hlY2sgdGhlIGNhY2hlIGZvciB0aGUgVVJMIHdpdGggYSBgLmh0bWxgIGFkZGVkIHRvIHRoZSBlbmQgb2YgdGhlIGVuZC5cbiAgICAgICAqIEBwYXJhbSB7d29ya2JveC1wcmVjYWNoaW5nfnVybE1hbmlwdWxhdGlvbn0gW29wdGlvbnMudXJsTWFuaXB1bGF0aW9uXVxuICAgICAgICogVGhpcyBpcyBhIGZ1bmN0aW9uIHRoYXQgc2hvdWxkIHRha2UgYSBVUkwgYW5kIHJldHVybiBhbiBhcnJheSBvZlxuICAgICAgICogYWx0ZXJuYXRpdmUgVVJMcyB0aGF0IHNob3VsZCBiZSBjaGVja2VkIGZvciBwcmVjYWNoZSBtYXRjaGVzLlxuICAgICAgICovXG4gICAgICBjb25zdHJ1Y3RvcihwcmVjYWNoZUNvbnRyb2xsZXIsIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3QgbWF0Y2ggPSAoe1xuICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgfSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHVybHNUb0NhY2hlS2V5cyA9IHByZWNhY2hlQ29udHJvbGxlci5nZXRVUkxzVG9DYWNoZUtleXMoKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHBvc3NpYmxlVVJMIG9mIGdlbmVyYXRlVVJMVmFyaWF0aW9ucyhyZXF1ZXN0LnVybCwgb3B0aW9ucykpIHtcbiAgICAgICAgICAgIGNvbnN0IGNhY2hlS2V5ID0gdXJsc1RvQ2FjaGVLZXlzLmdldChwb3NzaWJsZVVSTCk7XG4gICAgICAgICAgICBpZiAoY2FjaGVLZXkpIHtcbiAgICAgICAgICAgICAgY29uc3QgaW50ZWdyaXR5ID0gcHJlY2FjaGVDb250cm9sbGVyLmdldEludGVncml0eUZvckNhY2hlS2V5KGNhY2hlS2V5KTtcbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBjYWNoZUtleSxcbiAgICAgICAgICAgICAgICBpbnRlZ3JpdHlcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBQcmVjYWNoaW5nIGRpZCBub3QgZmluZCBhIG1hdGNoIGZvciBgICsgZ2V0RnJpZW5kbHlVUkwocmVxdWVzdC51cmwpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9O1xuICAgICAgICBzdXBlcihtYXRjaCwgcHJlY2FjaGVDb250cm9sbGVyLnN0cmF0ZWd5KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogQWRkIGEgYGZldGNoYCBsaXN0ZW5lciB0byB0aGUgc2VydmljZSB3b3JrZXIgdGhhdCB3aWxsXG4gICAgICogcmVzcG9uZCB0b1xuICAgICAqIFtuZXR3b3JrIHJlcXVlc3RzXXtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvU2VydmljZV9Xb3JrZXJfQVBJL1VzaW5nX1NlcnZpY2VfV29ya2VycyNDdXN0b21fcmVzcG9uc2VzX3RvX3JlcXVlc3RzfVxuICAgICAqIHdpdGggcHJlY2FjaGVkIGFzc2V0cy5cbiAgICAgKlxuICAgICAqIFJlcXVlc3RzIGZvciBhc3NldHMgdGhhdCBhcmVuJ3QgcHJlY2FjaGVkLCB0aGUgYEZldGNoRXZlbnRgIHdpbGwgbm90IGJlXG4gICAgICogcmVzcG9uZGVkIHRvLCBhbGxvd2luZyB0aGUgZXZlbnQgdG8gZmFsbCB0aHJvdWdoIHRvIG90aGVyIGBmZXRjaGAgZXZlbnRcbiAgICAgKiBsaXN0ZW5lcnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdIFNlZSB0aGUge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZVJvdXRlfVxuICAgICAqIG9wdGlvbnMuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gYWRkUm91dGUob3B0aW9ucykge1xuICAgICAgY29uc3QgcHJlY2FjaGVDb250cm9sbGVyID0gZ2V0T3JDcmVhdGVQcmVjYWNoZUNvbnRyb2xsZXIoKTtcbiAgICAgIGNvbnN0IHByZWNhY2hlUm91dGUgPSBuZXcgUHJlY2FjaGVSb3V0ZShwcmVjYWNoZUNvbnRyb2xsZXIsIG9wdGlvbnMpO1xuICAgICAgcmVnaXN0ZXJSb3V0ZShwcmVjYWNoZVJvdXRlKTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBBZGRzIGl0ZW1zIHRvIHRoZSBwcmVjYWNoZSBsaXN0LCByZW1vdmluZyBhbnkgZHVwbGljYXRlcyBhbmRcbiAgICAgKiBzdG9yZXMgdGhlIGZpbGVzIGluIHRoZVxuICAgICAqIHtAbGluayB3b3JrYm94LWNvcmUuY2FjaGVOYW1lc3xcInByZWNhY2hlIGNhY2hlXCJ9IHdoZW4gdGhlIHNlcnZpY2VcbiAgICAgKiB3b3JrZXIgaW5zdGFsbHMuXG4gICAgICpcbiAgICAgKiBUaGlzIG1ldGhvZCBjYW4gYmUgY2FsbGVkIG11bHRpcGxlIHRpbWVzLlxuICAgICAqXG4gICAgICogUGxlYXNlIG5vdGU6IFRoaXMgbWV0aG9kICoqd2lsbCBub3QqKiBzZXJ2ZSBhbnkgb2YgdGhlIGNhY2hlZCBmaWxlcyBmb3IgeW91LlxuICAgICAqIEl0IG9ubHkgcHJlY2FjaGVzIGZpbGVzLiBUbyByZXNwb25kIHRvIGEgbmV0d29yayByZXF1ZXN0IHlvdSBjYWxsXG4gICAgICoge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5hZGRSb3V0ZX0uXG4gICAgICpcbiAgICAgKiBJZiB5b3UgaGF2ZSBhIHNpbmdsZSBhcnJheSBvZiBmaWxlcyB0byBwcmVjYWNoZSwgeW91IGNhbiBqdXN0IGNhbGxcbiAgICAgKiB7QGxpbmsgd29ya2JveC1wcmVjYWNoaW5nLnByZWNhY2hlQW5kUm91dGV9LlxuICAgICAqXG4gICAgICogQHBhcmFtIHtBcnJheTxPYmplY3R8c3RyaW5nPn0gW2VudHJpZXM9W11dIEFycmF5IG9mIGVudHJpZXMgdG8gcHJlY2FjaGUuXG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gcHJlY2FjaGUoZW50cmllcykge1xuICAgICAgY29uc3QgcHJlY2FjaGVDb250cm9sbGVyID0gZ2V0T3JDcmVhdGVQcmVjYWNoZUNvbnRyb2xsZXIoKTtcbiAgICAgIHByZWNhY2hlQ29udHJvbGxlci5wcmVjYWNoZShlbnRyaWVzKTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICAvKipcbiAgICAgKiBUaGlzIG1ldGhvZCB3aWxsIGFkZCBlbnRyaWVzIHRvIHRoZSBwcmVjYWNoZSBsaXN0IGFuZCBhZGQgYSByb3V0ZSB0b1xuICAgICAqIHJlc3BvbmQgdG8gZmV0Y2ggZXZlbnRzLlxuICAgICAqXG4gICAgICogVGhpcyBpcyBhIGNvbnZlbmllbmNlIG1ldGhvZCB0aGF0IHdpbGwgY2FsbFxuICAgICAqIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcucHJlY2FjaGV9IGFuZFxuICAgICAqIHtAbGluayB3b3JrYm94LXByZWNhY2hpbmcuYWRkUm91dGV9IGluIGEgc2luZ2xlIGNhbGwuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdHxzdHJpbmc+fSBlbnRyaWVzIEFycmF5IG9mIGVudHJpZXMgdG8gcHJlY2FjaGUuXG4gICAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSBTZWUgdGhlXG4gICAgICoge0BsaW5rIHdvcmtib3gtcHJlY2FjaGluZy5QcmVjYWNoZVJvdXRlfSBvcHRpb25zLlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIHByZWNhY2hlQW5kUm91dGUoZW50cmllcywgb3B0aW9ucykge1xuICAgICAgcHJlY2FjaGUoZW50cmllcyk7XG4gICAgICBhZGRSb3V0ZShvcHRpb25zKTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAgQ29weXJpZ2h0IDIwMTggR29vZ2xlIExMQ1xuXG4gICAgICBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGVcbiAgICAgIGxpY2Vuc2UgdGhhdCBjYW4gYmUgZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBvciBhdFxuICAgICAgaHR0cHM6Ly9vcGVuc291cmNlLm9yZy9saWNlbnNlcy9NSVQuXG4gICAgKi9cbiAgICBjb25zdCBTVUJTVFJJTkdfVE9fRklORCA9ICctcHJlY2FjaGUtJztcbiAgICAvKipcbiAgICAgKiBDbGVhbnMgdXAgaW5jb21wYXRpYmxlIHByZWNhY2hlcyB0aGF0IHdlcmUgY3JlYXRlZCBieSBvbGRlciB2ZXJzaW9ucyBvZlxuICAgICAqIFdvcmtib3gsIGJ5IGEgc2VydmljZSB3b3JrZXIgcmVnaXN0ZXJlZCB1bmRlciB0aGUgY3VycmVudCBzY29wZS5cbiAgICAgKlxuICAgICAqIFRoaXMgaXMgbWVhbnQgdG8gYmUgY2FsbGVkIGFzIHBhcnQgb2YgdGhlIGBhY3RpdmF0ZWAgZXZlbnQuXG4gICAgICpcbiAgICAgKiBUaGlzIHNob3VsZCBiZSBzYWZlIHRvIHVzZSBhcyBsb25nIGFzIHlvdSBkb24ndCBpbmNsdWRlIGBzdWJzdHJpbmdUb0ZpbmRgXG4gICAgICogKGRlZmF1bHRpbmcgdG8gYC1wcmVjYWNoZS1gKSBpbiB5b3VyIG5vbi1wcmVjYWNoZSBjYWNoZSBuYW1lcy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBjdXJyZW50UHJlY2FjaGVOYW1lIFRoZSBjYWNoZSBuYW1lIGN1cnJlbnRseSBpbiB1c2UgZm9yXG4gICAgICogcHJlY2FjaGluZy4gVGhpcyBjYWNoZSB3b24ndCBiZSBkZWxldGVkLlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBbc3Vic3RyaW5nVG9GaW5kPSctcHJlY2FjaGUtJ10gQ2FjaGUgbmFtZXMgd2hpY2ggaW5jbHVkZSB0aGlzXG4gICAgICogc3Vic3RyaW5nIHdpbGwgYmUgZGVsZXRlZCAoZXhjbHVkaW5nIGBjdXJyZW50UHJlY2FjaGVOYW1lYCkuXG4gICAgICogQHJldHVybiB7QXJyYXk8c3RyaW5nPn0gQSBsaXN0IG9mIGFsbCB0aGUgY2FjaGUgbmFtZXMgdGhhdCB3ZXJlIGRlbGV0ZWQuXG4gICAgICpcbiAgICAgKiBAcHJpdmF0ZVxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXByZWNhY2hpbmdcbiAgICAgKi9cbiAgICBjb25zdCBkZWxldGVPdXRkYXRlZENhY2hlcyA9IGFzeW5jIChjdXJyZW50UHJlY2FjaGVOYW1lLCBzdWJzdHJpbmdUb0ZpbmQgPSBTVUJTVFJJTkdfVE9fRklORCkgPT4ge1xuICAgICAgY29uc3QgY2FjaGVOYW1lcyA9IGF3YWl0IHNlbGYuY2FjaGVzLmtleXMoKTtcbiAgICAgIGNvbnN0IGNhY2hlTmFtZXNUb0RlbGV0ZSA9IGNhY2hlTmFtZXMuZmlsdGVyKGNhY2hlTmFtZSA9PiB7XG4gICAgICAgIHJldHVybiBjYWNoZU5hbWUuaW5jbHVkZXMoc3Vic3RyaW5nVG9GaW5kKSAmJiBjYWNoZU5hbWUuaW5jbHVkZXMoc2VsZi5yZWdpc3RyYXRpb24uc2NvcGUpICYmIGNhY2hlTmFtZSAhPT0gY3VycmVudFByZWNhY2hlTmFtZTtcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoY2FjaGVOYW1lc1RvRGVsZXRlLm1hcChjYWNoZU5hbWUgPT4gc2VsZi5jYWNoZXMuZGVsZXRlKGNhY2hlTmFtZSkpKTtcbiAgICAgIHJldHVybiBjYWNoZU5hbWVzVG9EZWxldGU7XG4gICAgfTtcblxuICAgIC8qXG4gICAgICBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG5cbiAgICAgIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGFuIE1JVC1zdHlsZVxuICAgICAgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIG9yIGF0XG4gICAgICBodHRwczovL29wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL01JVC5cbiAgICAqL1xuICAgIC8qKlxuICAgICAqIEFkZHMgYW4gYGFjdGl2YXRlYCBldmVudCBsaXN0ZW5lciB3aGljaCB3aWxsIGNsZWFuIHVwIGluY29tcGF0aWJsZVxuICAgICAqIHByZWNhY2hlcyB0aGF0IHdlcmUgY3JlYXRlZCBieSBvbGRlciB2ZXJzaW9ucyBvZiBXb3JrYm94LlxuICAgICAqXG4gICAgICogQG1lbWJlcm9mIHdvcmtib3gtcHJlY2FjaGluZ1xuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNsZWFudXBPdXRkYXRlZENhY2hlcygpIHtcbiAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vTWljcm9zb2Z0L1R5cGVTY3JpcHQvaXNzdWVzLzI4MzU3I2lzc3VlY29tbWVudC00MzY0ODQ3MDVcbiAgICAgIHNlbGYuYWRkRXZlbnRMaXN0ZW5lcignYWN0aXZhdGUnLCBldmVudCA9PiB7XG4gICAgICAgIGNvbnN0IGNhY2hlTmFtZSA9IGNhY2hlTmFtZXMuZ2V0UHJlY2FjaGVOYW1lKCk7XG4gICAgICAgIGV2ZW50LndhaXRVbnRpbChkZWxldGVPdXRkYXRlZENhY2hlcyhjYWNoZU5hbWUpLnRoZW4oY2FjaGVzRGVsZXRlZCA9PiB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgaWYgKGNhY2hlc0RlbGV0ZWQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICBsb2dnZXIubG9nKGBUaGUgZm9sbG93aW5nIG91dC1vZi1kYXRlIHByZWNhY2hlcyB3ZXJlIGNsZWFuZWQgdXAgYCArIGBhdXRvbWF0aWNhbGx5OmAsIGNhY2hlc0RlbGV0ZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSkpO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE4IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogTmF2aWdhdGlvblJvdXRlIG1ha2VzIGl0IGVhc3kgdG8gY3JlYXRlIGFcbiAgICAgKiB7QGxpbmsgd29ya2JveC1yb3V0aW5nLlJvdXRlfSB0aGF0IG1hdGNoZXMgZm9yIGJyb3dzZXJcbiAgICAgKiBbbmF2aWdhdGlvbiByZXF1ZXN0c117QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vd2ViL2Z1bmRhbWVudGFscy9wcmltZXJzL3NlcnZpY2Utd29ya2Vycy9oaWdoLXBlcmZvcm1hbmNlLWxvYWRpbmcjZmlyc3Rfd2hhdF9hcmVfbmF2aWdhdGlvbl9yZXF1ZXN0c30uXG4gICAgICpcbiAgICAgKiBJdCB3aWxsIG9ubHkgbWF0Y2ggaW5jb21pbmcgUmVxdWVzdHMgd2hvc2VcbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9mZXRjaC5zcGVjLndoYXR3Zy5vcmcvI2NvbmNlcHQtcmVxdWVzdC1tb2RlfG1vZGV9XG4gICAgICogaXMgc2V0IHRvIGBuYXZpZ2F0ZWAuXG4gICAgICpcbiAgICAgKiBZb3UgY2FuIG9wdGlvbmFsbHkgb25seSBhcHBseSB0aGlzIHJvdXRlIHRvIGEgc3Vic2V0IG9mIG5hdmlnYXRpb24gcmVxdWVzdHNcbiAgICAgKiBieSB1c2luZyBvbmUgb3IgYm90aCBvZiB0aGUgYGRlbnlsaXN0YCBhbmQgYGFsbG93bGlzdGAgcGFyYW1ldGVycy5cbiAgICAgKlxuICAgICAqIEBtZW1iZXJvZiB3b3JrYm94LXJvdXRpbmdcbiAgICAgKiBAZXh0ZW5kcyB3b3JrYm94LXJvdXRpbmcuUm91dGVcbiAgICAgKi9cbiAgICBjbGFzcyBOYXZpZ2F0aW9uUm91dGUgZXh0ZW5kcyBSb3V0ZSB7XG4gICAgICAvKipcbiAgICAgICAqIElmIGJvdGggYGRlbnlsaXN0YCBhbmQgYGFsbG93bGlzdGAgYXJlIHByb3ZpZGVkLCB0aGUgYGRlbnlsaXN0YCB3aWxsXG4gICAgICAgKiB0YWtlIHByZWNlZGVuY2UgYW5kIHRoZSByZXF1ZXN0IHdpbGwgbm90IG1hdGNoIHRoaXMgcm91dGUuXG4gICAgICAgKlxuICAgICAgICogVGhlIHJlZ3VsYXIgZXhwcmVzc2lvbnMgaW4gYGFsbG93bGlzdGAgYW5kIGBkZW55bGlzdGBcbiAgICAgICAqIGFyZSBtYXRjaGVkIGFnYWluc3QgdGhlIGNvbmNhdGVuYXRlZFxuICAgICAgICogW2BwYXRobmFtZWBde0BsaW5rIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IVE1MSHlwZXJsaW5rRWxlbWVudFV0aWxzL3BhdGhuYW1lfVxuICAgICAgICogYW5kIFtgc2VhcmNoYF17QGxpbmsgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0hUTUxIeXBlcmxpbmtFbGVtZW50VXRpbHMvc2VhcmNofVxuICAgICAgICogcG9ydGlvbnMgb2YgdGhlIHJlcXVlc3RlZCBVUkwuXG4gICAgICAgKlxuICAgICAgICogKk5vdGUqOiBUaGVzZSBSZWdFeHBzIG1heSBiZSBldmFsdWF0ZWQgYWdhaW5zdCBldmVyeSBkZXN0aW5hdGlvbiBVUkwgZHVyaW5nXG4gICAgICAgKiBhIG5hdmlnYXRpb24uIEF2b2lkIHVzaW5nXG4gICAgICAgKiBbY29tcGxleCBSZWdFeHBzXShodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lL3dvcmtib3gvaXNzdWVzLzMwNzcpLFxuICAgICAgICogb3IgZWxzZSB5b3VyIHVzZXJzIG1heSBzZWUgZGVsYXlzIHdoZW4gbmF2aWdhdGluZyB5b3VyIHNpdGUuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHt3b3JrYm94LXJvdXRpbmd+aGFuZGxlckNhbGxiYWNrfSBoYW5kbGVyIEEgY2FsbGJhY2tcbiAgICAgICAqIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIFByb21pc2UgcmVzdWx0aW5nIGluIGEgUmVzcG9uc2UuXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgICAgICogQHBhcmFtIHtBcnJheTxSZWdFeHA+fSBbb3B0aW9ucy5kZW55bGlzdF0gSWYgYW55IG9mIHRoZXNlIHBhdHRlcm5zIG1hdGNoLFxuICAgICAgICogdGhlIHJvdXRlIHdpbGwgbm90IGhhbmRsZSB0aGUgcmVxdWVzdCAoZXZlbiBpZiBhIGFsbG93bGlzdCBSZWdFeHAgbWF0Y2hlcykuXG4gICAgICAgKiBAcGFyYW0ge0FycmF5PFJlZ0V4cD59IFtvcHRpb25zLmFsbG93bGlzdD1bLy4vXV0gSWYgYW55IG9mIHRoZXNlIHBhdHRlcm5zXG4gICAgICAgKiBtYXRjaCB0aGUgVVJMJ3MgcGF0aG5hbWUgYW5kIHNlYXJjaCBwYXJhbWV0ZXIsIHRoZSByb3V0ZSB3aWxsIGhhbmRsZSB0aGVcbiAgICAgICAqIHJlcXVlc3QgKGFzc3VtaW5nIHRoZSBkZW55bGlzdCBkb2Vzbid0IG1hdGNoKS5cbiAgICAgICAqL1xuICAgICAgY29uc3RydWN0b3IoaGFuZGxlciwge1xuICAgICAgICBhbGxvd2xpc3QgPSBbLy4vXSxcbiAgICAgICAgZGVueWxpc3QgPSBbXVxuICAgICAgfSA9IHt9KSB7XG4gICAgICAgIHtcbiAgICAgICAgICBmaW5hbEFzc2VydEV4cG9ydHMuaXNBcnJheU9mQ2xhc3MoYWxsb3dsaXN0LCBSZWdFeHAsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnTmF2aWdhdGlvblJvdXRlJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnb3B0aW9ucy5hbGxvd2xpc3QnXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZmluYWxBc3NlcnRFeHBvcnRzLmlzQXJyYXlPZkNsYXNzKGRlbnlsaXN0LCBSZWdFeHAsIHtcbiAgICAgICAgICAgIG1vZHVsZU5hbWU6ICd3b3JrYm94LXJvdXRpbmcnLFxuICAgICAgICAgICAgY2xhc3NOYW1lOiAnTmF2aWdhdGlvblJvdXRlJyxcbiAgICAgICAgICAgIGZ1bmNOYW1lOiAnY29uc3RydWN0b3InLFxuICAgICAgICAgICAgcGFyYW1OYW1lOiAnb3B0aW9ucy5kZW55bGlzdCdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBzdXBlcihvcHRpb25zID0+IHRoaXMuX21hdGNoKG9wdGlvbnMpLCBoYW5kbGVyKTtcbiAgICAgICAgdGhpcy5fYWxsb3dsaXN0ID0gYWxsb3dsaXN0O1xuICAgICAgICB0aGlzLl9kZW55bGlzdCA9IGRlbnlsaXN0O1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBSb3V0ZXMgbWF0Y2ggaGFuZGxlci5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge09iamVjdH0gb3B0aW9uc1xuICAgICAgICogQHBhcmFtIHtVUkx9IG9wdGlvbnMudXJsXG4gICAgICAgKiBAcGFyYW0ge1JlcXVlc3R9IG9wdGlvbnMucmVxdWVzdFxuICAgICAgICogQHJldHVybiB7Ym9vbGVhbn1cbiAgICAgICAqXG4gICAgICAgKiBAcHJpdmF0ZVxuICAgICAgICovXG4gICAgICBfbWF0Y2goe1xuICAgICAgICB1cmwsXG4gICAgICAgIHJlcXVlc3RcbiAgICAgIH0pIHtcbiAgICAgICAgaWYgKHJlcXVlc3QgJiYgcmVxdWVzdC5tb2RlICE9PSAnbmF2aWdhdGUnKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHBhdGhuYW1lQW5kU2VhcmNoID0gdXJsLnBhdGhuYW1lICsgdXJsLnNlYXJjaDtcbiAgICAgICAgZm9yIChjb25zdCByZWdFeHAgb2YgdGhpcy5fZGVueWxpc3QpIHtcbiAgICAgICAgICBpZiAocmVnRXhwLnRlc3QocGF0aG5hbWVBbmRTZWFyY2gpKSB7XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGxvZ2dlci5sb2coYFRoZSBuYXZpZ2F0aW9uIHJvdXRlICR7cGF0aG5hbWVBbmRTZWFyY2h9IGlzIG5vdCBgICsgYGJlaW5nIHVzZWQsIHNpbmNlIHRoZSBVUkwgbWF0Y2hlcyB0aGlzIGRlbnlsaXN0IHBhdHRlcm46IGAgKyBgJHtyZWdFeHAudG9TdHJpbmcoKX1gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuX2FsbG93bGlzdC5zb21lKHJlZ0V4cCA9PiByZWdFeHAudGVzdChwYXRobmFtZUFuZFNlYXJjaCkpKSB7XG4gICAgICAgICAge1xuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBUaGUgbmF2aWdhdGlvbiByb3V0ZSAke3BhdGhuYW1lQW5kU2VhcmNofSBgICsgYGlzIGJlaW5nIHVzZWQuYCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHtcbiAgICAgICAgICBsb2dnZXIubG9nKGBUaGUgbmF2aWdhdGlvbiByb3V0ZSAke3BhdGhuYW1lQW5kU2VhcmNofSBpcyBub3QgYCArIGBiZWluZyB1c2VkLCBzaW5jZSB0aGUgVVJMIGJlaW5nIG5hdmlnYXRlZCB0byBkb2Vzbid0IGAgKyBgbWF0Y2ggdGhlIGFsbG93bGlzdC5gKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICAgIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcblxuICAgICAgVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYW4gTUlULXN0eWxlXG4gICAgICBsaWNlbnNlIHRoYXQgY2FuIGJlIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUgb3IgYXRcbiAgICAgIGh0dHBzOi8vb3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvTUlULlxuICAgICovXG4gICAgLyoqXG4gICAgICogSGVscGVyIGZ1bmN0aW9uIHRoYXQgY2FsbHNcbiAgICAgKiB7QGxpbmsgUHJlY2FjaGVDb250cm9sbGVyI2NyZWF0ZUhhbmRsZXJCb3VuZFRvVVJMfSBvbiB0aGUgZGVmYXVsdFxuICAgICAqIHtAbGluayBQcmVjYWNoZUNvbnRyb2xsZXJ9IGluc3RhbmNlLlxuICAgICAqXG4gICAgICogSWYgeW91IGFyZSBjcmVhdGluZyB5b3VyIG93biB7QGxpbmsgUHJlY2FjaGVDb250cm9sbGVyfSwgdGhlbiBjYWxsIHRoZVxuICAgICAqIHtAbGluayBQcmVjYWNoZUNvbnRyb2xsZXIjY3JlYXRlSGFuZGxlckJvdW5kVG9VUkx9IG9uIHRoYXQgaW5zdGFuY2UsXG4gICAgICogaW5zdGVhZCBvZiB1c2luZyB0aGlzIGZ1bmN0aW9uLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtzdHJpbmd9IHVybCBUaGUgcHJlY2FjaGVkIFVSTCB3aGljaCB3aWxsIGJlIHVzZWQgdG8gbG9va3VwIHRoZVxuICAgICAqIGBSZXNwb25zZWAuXG4gICAgICogQHBhcmFtIHtib29sZWFufSBbZmFsbGJhY2tUb05ldHdvcms9dHJ1ZV0gV2hldGhlciB0byBhdHRlbXB0IHRvIGdldCB0aGVcbiAgICAgKiByZXNwb25zZSBmcm9tIHRoZSBuZXR3b3JrIGlmIHRoZXJlJ3MgYSBwcmVjYWNoZSBtaXNzLlxuICAgICAqIEByZXR1cm4ge3dvcmtib3gtcm91dGluZ35oYW5kbGVyQ2FsbGJhY2t9XG4gICAgICpcbiAgICAgKiBAbWVtYmVyb2Ygd29ya2JveC1wcmVjYWNoaW5nXG4gICAgICovXG4gICAgZnVuY3Rpb24gY3JlYXRlSGFuZGxlckJvdW5kVG9VUkwodXJsKSB7XG4gICAgICBjb25zdCBwcmVjYWNoZUNvbnRyb2xsZXIgPSBnZXRPckNyZWF0ZVByZWNhY2hlQ29udHJvbGxlcigpO1xuICAgICAgcmV0dXJuIHByZWNhY2hlQ29udHJvbGxlci5jcmVhdGVIYW5kbGVyQm91bmRUb1VSTCh1cmwpO1xuICAgIH1cblxuICAgIGV4cG9ydHMuTmF2aWdhdGlvblJvdXRlID0gTmF2aWdhdGlvblJvdXRlO1xuICAgIGV4cG9ydHMuY2xlYW51cE91dGRhdGVkQ2FjaGVzID0gY2xlYW51cE91dGRhdGVkQ2FjaGVzO1xuICAgIGV4cG9ydHMuY2xpZW50c0NsYWltID0gY2xpZW50c0NsYWltO1xuICAgIGV4cG9ydHMuY3JlYXRlSGFuZGxlckJvdW5kVG9VUkwgPSBjcmVhdGVIYW5kbGVyQm91bmRUb1VSTDtcbiAgICBleHBvcnRzLnByZWNhY2hlQW5kUm91dGUgPSBwcmVjYWNoZUFuZFJvdXRlO1xuICAgIGV4cG9ydHMucmVnaXN0ZXJSb3V0ZSA9IHJlZ2lzdGVyUm91dGU7XG5cbn0pKTtcbiJdfQ==