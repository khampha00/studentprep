import { _ as ok, g as codes, h as constants, l as markdownLineEnding, m as types, t as factorySpace } from "/node_modules/.vite/deps/dev-CbuUJWGD.js?v=076f3cfd";
import { t as longestStreak } from "/node_modules/.vite/deps/longest-streak-B5A-0zLa.js?v=076f3cfd";
//#region node_modules/mdast-util-math/lib/index.js
/**
* @typedef {import('hast').Element} HastElement
* @typedef {import('hast').ElementContent} HastElementContent
* @typedef {import('mdast-util-from-markdown').CompileContext} CompileContext
* @typedef {import('mdast-util-from-markdown').Extension} FromMarkdownExtension
* @typedef {import('mdast-util-from-markdown').Handle} FromMarkdownHandle
* @typedef {import('mdast-util-to-markdown').Handle} ToMarkdownHandle
* @typedef {import('mdast-util-to-markdown').Options} ToMarkdownExtension
* @typedef {import('../index.js').InlineMath} InlineMath
* @typedef {import('../index.js').Math} Math
*
* @typedef ToOptions
*   Configuration.
* @property {boolean | null | undefined} [singleDollarTextMath=true]
*   Whether to support math (text) with a single dollar (default: `true`).
*
*   Single dollars work in Pandoc and many other places, but often interfere
*   with “normal” dollars in text.
*   If you turn this off, you can still use two or more dollars for text math.
*/
/**
* Create an extension for `mdast-util-from-markdown`.
*
* @returns {FromMarkdownExtension}
*   Extension for `mdast-util-from-markdown`.
*/
function mathFromMarkdown() {
	return {
		enter: {
			mathFlow: enterMathFlow,
			mathFlowFenceMeta: enterMathFlowMeta,
			mathText: enterMathText
		},
		exit: {
			mathFlow: exitMathFlow,
			mathFlowFence: exitMathFlowFence,
			mathFlowFenceMeta: exitMathFlowMeta,
			mathFlowValue: exitMathData,
			mathText: exitMathText,
			mathTextData: exitMathData
		}
	};
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function enterMathFlow(token) {
		this.enter({
			type: "math",
			meta: null,
			value: "",
			data: {
				hName: "pre",
				hChildren: [{
					type: "element",
					tagName: "code",
					properties: { className: ["language-math", "math-display"] },
					children: []
				}]
			}
		}, token);
	}
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function enterMathFlowMeta() {
		this.buffer();
	}
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function exitMathFlowMeta() {
		const data = this.resume();
		const node = this.stack[this.stack.length - 1];
		ok(node.type === "math");
		node.meta = data;
	}
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function exitMathFlowFence() {
		if (this.data.mathFlowInside) return;
		this.buffer();
		this.data.mathFlowInside = true;
	}
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function exitMathFlow(token) {
		const data = this.resume().replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, "");
		const node = this.stack[this.stack.length - 1];
		ok(node.type === "math");
		this.exit(token);
		node.value = data;
		const code = node.data.hChildren[0];
		ok(code.type === "element");
		ok(code.tagName === "code");
		code.children.push({
			type: "text",
			value: data
		});
		this.data.mathFlowInside = void 0;
	}
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function enterMathText(token) {
		this.enter({
			type: "inlineMath",
			value: "",
			data: {
				hName: "code",
				hProperties: { className: ["language-math", "math-inline"] },
				hChildren: []
			}
		}, token);
		this.buffer();
	}
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function exitMathText(token) {
		const data = this.resume();
		const node = this.stack[this.stack.length - 1];
		ok(node.type === "inlineMath");
		this.exit(token);
		node.value = data;
		node.data.hChildren.push({
			type: "text",
			value: data
		});
	}
	/**
	* @this {CompileContext}
	* @type {FromMarkdownHandle}
	*/
	function exitMathData(token) {
		this.config.enter.data.call(this, token);
		this.config.exit.data.call(this, token);
	}
}
/**
* Create an extension for `mdast-util-to-markdown`.
*
* @param {ToOptions | null | undefined} [options]
*   Configuration (optional).
* @returns {ToMarkdownExtension}
*   Extension for `mdast-util-to-markdown`.
*/
function mathToMarkdown(options) {
	let single = (options || {}).singleDollarTextMath;
	if (single === null || single === void 0) single = true;
	inlineMath.peek = inlineMathPeek;
	return {
		unsafe: [
			{
				character: "\r",
				inConstruct: "mathFlowMeta"
			},
			{
				character: "\n",
				inConstruct: "mathFlowMeta"
			},
			{
				character: "$",
				after: single ? void 0 : "\\$",
				inConstruct: "phrasing"
			},
			{
				character: "$",
				inConstruct: "mathFlowMeta"
			},
			{
				atBreak: true,
				character: "$",
				after: "\\$"
			}
		],
		handlers: {
			math,
			inlineMath
		}
	};
	/**
	* @type {ToMarkdownHandle}
	* @param {Math} node
	*/
	function math(node, _, state, info) {
		const raw = node.value || "";
		const tracker = state.createTracker(info);
		const sequence = "$".repeat(Math.max(longestStreak(raw, "$") + 1, 2));
		const exit = state.enter("mathFlow");
		let value = tracker.move(sequence);
		if (node.meta) {
			const subexit = state.enter("mathFlowMeta");
			value += tracker.move(state.safe(node.meta, {
				after: "\n",
				before: value,
				encode: ["$"],
				...tracker.current()
			}));
			subexit();
		}
		value += tracker.move("\n");
		if (raw) value += tracker.move(raw + "\n");
		value += tracker.move(sequence);
		exit();
		return value;
	}
	/**
	* @type {ToMarkdownHandle}
	* @param {InlineMath} node
	*/
	function inlineMath(node, _, state) {
		let value = node.value || "";
		let size = 1;
		if (!single) size++;
		while (new RegExp("(^|[^$])" + "\\$".repeat(size) + "([^$]|$)").test(value)) size++;
		const sequence = "$".repeat(size);
		if (/[^ \r\n]/.test(value) && (/^[ \r\n]/.test(value) && /[ \r\n]$/.test(value) || /^\$|\$$/.test(value))) value = " " + value + " ";
		let index = -1;
		while (++index < state.unsafe.length) {
			const pattern = state.unsafe[index];
			if (!pattern.atBreak) continue;
			const expression = state.compilePattern(pattern);
			/** @type {RegExpExecArray | null} */
			let match;
			while (match = expression.exec(value)) {
				let position = match.index;
				if (value.codePointAt(position) === 10 && value.codePointAt(position - 1) === 13) position--;
				value = value.slice(0, position) + " " + value.slice(match.index + 1);
			}
		}
		return sequence + value + sequence;
	}
	/**
	* @returns {string}
	*/
	function inlineMathPeek() {
		return "$";
	}
}
//#endregion
//#region node_modules/micromark-extension-math/dev/lib/math-flow.js
/**
* @import {Construct, State, TokenizeContext, Tokenizer} from 'micromark-util-types'
*/
/** @type {Construct} */
var mathFlow = {
	tokenize: tokenizeMathFenced,
	concrete: true,
	name: "mathFlow"
};
/** @type {Construct} */
var nonLazyContinuation = {
	tokenize: tokenizeNonLazyContinuation,
	partial: true
};
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeMathFenced(effects, ok$2, nok) {
	const self = this;
	const tail = self.events[self.events.length - 1];
	const initialSize = tail && tail[1].type === types.linePrefix ? tail[2].sliceSerialize(tail[1], true).length : 0;
	let sizeOpen = 0;
	return start;
	/**
	* Start of math.
	*
	* ```markdown
	* > | $$
	*     ^
	*   | \frac{1}{2}
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function start(code) {
		ok(code === codes.dollarSign, "expected `$`");
		effects.enter("mathFlow");
		effects.enter("mathFlowFence");
		effects.enter("mathFlowFenceSequence");
		return sequenceOpen(code);
	}
	/**
	* In opening fence sequence.
	*
	* ```markdown
	* > | $$
	*      ^
	*   | \frac{1}{2}
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function sequenceOpen(code) {
		if (code === codes.dollarSign) {
			effects.consume(code);
			sizeOpen++;
			return sequenceOpen;
		}
		if (sizeOpen < 2) return nok(code);
		effects.exit("mathFlowFenceSequence");
		return factorySpace(effects, metaBefore, types.whitespace)(code);
	}
	/**
	* In opening fence, before meta.
	*
	* ```markdown
	* > | $$asciimath
	*       ^
	*   | x < y
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function metaBefore(code) {
		if (code === codes.eof || markdownLineEnding(code)) return metaAfter(code);
		effects.enter("mathFlowFenceMeta");
		effects.enter(types.chunkString, { contentType: constants.contentTypeString });
		return meta(code);
	}
	/**
	* In meta.
	*
	* ```markdown
	* > | $$asciimath
	*        ^
	*   | x < y
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function meta(code) {
		if (code === codes.eof || markdownLineEnding(code)) {
			effects.exit(types.chunkString);
			effects.exit("mathFlowFenceMeta");
			return metaAfter(code);
		}
		if (code === codes.dollarSign) return nok(code);
		effects.consume(code);
		return meta;
	}
	/**
	* After meta.
	*
	* ```markdown
	* > | $$
	*       ^
	*   | \frac{1}{2}
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function metaAfter(code) {
		effects.exit("mathFlowFence");
		if (self.interrupt) return ok$2(code);
		return effects.attempt(nonLazyContinuation, beforeNonLazyContinuation, after)(code);
	}
	/**
	* After eol/eof in math, at a non-lazy closing fence or content.
	*
	* ```markdown
	*   | $$
	* > | \frac{1}{2}
	*     ^
	* > | $$
	*     ^
	* ```
	*
	* @type {State}
	*/
	function beforeNonLazyContinuation(code) {
		return effects.attempt({
			tokenize: tokenizeClosingFence,
			partial: true
		}, after, contentStart)(code);
	}
	/**
	* Before math content, definitely not before a closing fence.
	*
	* ```markdown
	*   | $$
	* > | \frac{1}{2}
	*     ^
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function contentStart(code) {
		return (initialSize ? factorySpace(effects, beforeContentChunk, types.linePrefix, initialSize + 1) : beforeContentChunk)(code);
	}
	/**
	* Before math content, after optional prefix.
	*
	* ```markdown
	*   | $$
	* > | \frac{1}{2}
	*     ^
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function beforeContentChunk(code) {
		if (code === codes.eof) return after(code);
		if (markdownLineEnding(code)) return effects.attempt(nonLazyContinuation, beforeNonLazyContinuation, after)(code);
		effects.enter("mathFlowValue");
		return contentChunk(code);
	}
	/**
	* In math content.
	*
	* ```markdown
	*   | $$
	* > | \frac{1}{2}
	*      ^
	*   | $$
	* ```
	*
	* @type {State}
	*/
	function contentChunk(code) {
		if (code === codes.eof || markdownLineEnding(code)) {
			effects.exit("mathFlowValue");
			return beforeContentChunk(code);
		}
		effects.consume(code);
		return contentChunk;
	}
	/**
	* After math (ha!).
	*
	* ```markdown
	*   | $$
	*   | \frac{1}{2}
	* > | $$
	*       ^
	* ```
	*
	* @type {State}
	*/
	function after(code) {
		effects.exit("mathFlow");
		return ok$2(code);
	}
	/** @type {Tokenizer} */
	function tokenizeClosingFence(effects, ok$3, nok) {
		let size = 0;
		ok(self.parser.constructs.disable.null, "expected `disable.null`");
		/**
		* Before closing fence, at optional whitespace.
		*
		* ```markdown
		*   | $$
		*   | \frac{1}{2}
		* > | $$
		*     ^
		* ```
		*/
		return factorySpace(effects, beforeSequenceClose, types.linePrefix, self.parser.constructs.disable.null.includes("codeIndented") ? void 0 : constants.tabSize);
		/**
		* In closing fence, after optional whitespace, at sequence.
		*
		* ```markdown
		*   | $$
		*   | \frac{1}{2}
		* > | $$
		*     ^
		* ```
		*
		* @type {State}
		*/
		function beforeSequenceClose(code) {
			effects.enter("mathFlowFence");
			effects.enter("mathFlowFenceSequence");
			return sequenceClose(code);
		}
		/**
		* In closing fence sequence.
		*
		* ```markdown
		*   | $$
		*   | \frac{1}{2}
		* > | $$
		*      ^
		* ```
		*
		* @type {State}
		*/
		function sequenceClose(code) {
			if (code === codes.dollarSign) {
				size++;
				effects.consume(code);
				return sequenceClose;
			}
			if (size < sizeOpen) return nok(code);
			effects.exit("mathFlowFenceSequence");
			return factorySpace(effects, afterSequenceClose, types.whitespace)(code);
		}
		/**
		* After closing fence sequence, after optional whitespace.
		*
		* ```markdown
		*   | $$
		*   | \frac{1}{2}
		* > | $$
		*       ^
		* ```
		*
		* @type {State}
		*/
		function afterSequenceClose(code) {
			if (code === codes.eof || markdownLineEnding(code)) {
				effects.exit("mathFlowFence");
				return ok$3(code);
			}
			return nok(code);
		}
	}
}
/**
* @this {TokenizeContext}
* @type {Tokenizer}
*/
function tokenizeNonLazyContinuation(effects, ok$4, nok) {
	const self = this;
	return start;
	/** @type {State} */
	function start(code) {
		if (code === null) return ok$4(code);
		ok(markdownLineEnding(code), "expected eol");
		effects.enter(types.lineEnding);
		effects.consume(code);
		effects.exit(types.lineEnding);
		return lineStart;
	}
	/** @type {State} */
	function lineStart(code) {
		return self.parser.lazy[self.now().line] ? nok(code) : ok$4(code);
	}
}
//#endregion
//#region node_modules/micromark-extension-math/dev/lib/math-text.js
/**
* @import {Options} from 'micromark-extension-math'
* @import {Construct, Previous, Resolver, State, Token, TokenizeContext, Tokenizer} from 'micromark-util-types'
*/
/**
* @param {Options | null | undefined} [options={}]
*   Configuration (default: `{}`).
* @returns {Construct}
*   Construct.
*/
function mathText(options) {
	let single = (options || {}).singleDollarTextMath;
	if (single === null || single === void 0) single = true;
	return {
		tokenize: tokenizeMathText,
		resolve: resolveMathText,
		previous,
		name: "mathText"
	};
	/**
	* @this {TokenizeContext}
	* @type {Tokenizer}
	*/
	function tokenizeMathText(effects, ok$1, nok) {
		const self = this;
		let sizeOpen = 0;
		/** @type {number} */
		let size;
		/** @type {Token} */
		let token;
		return start;
		/**
		* Start of math (text).
		*
		* ```markdown
		* > | $a$
		*     ^
		* > | \$a$
		*      ^
		* ```
		*
		* @type {State}
		*/
		function start(code) {
			ok(code === codes.dollarSign, "expected `$`");
			ok(previous.call(self, self.previous), "expected correct previous");
			effects.enter("mathText");
			effects.enter("mathTextSequence");
			return sequenceOpen(code);
		}
		/**
		* In opening sequence.
		*
		* ```markdown
		* > | $a$
		*     ^
		* ```
		*
		* @type {State}
		*/
		function sequenceOpen(code) {
			if (code === codes.dollarSign) {
				effects.consume(code);
				sizeOpen++;
				return sequenceOpen;
			}
			if (sizeOpen < 2 && !single) return nok(code);
			effects.exit("mathTextSequence");
			return between(code);
		}
		/**
		* Between something and something else.
		*
		* ```markdown
		* > | $a$
		*      ^^
		* ```
		*
		* @type {State}
		*/
		function between(code) {
			if (code === codes.eof) return nok(code);
			if (code === codes.dollarSign) {
				token = effects.enter("mathTextSequence");
				size = 0;
				return sequenceClose(code);
			}
			if (code === codes.space) {
				effects.enter("space");
				effects.consume(code);
				effects.exit("space");
				return between;
			}
			if (markdownLineEnding(code)) {
				effects.enter(types.lineEnding);
				effects.consume(code);
				effects.exit(types.lineEnding);
				return between;
			}
			effects.enter("mathTextData");
			return data(code);
		}
		/**
		* In data.
		*
		* ```markdown
		* > | $a$
		*      ^
		* ```
		*
		* @type {State}
		*/
		function data(code) {
			if (code === codes.eof || code === codes.space || code === codes.dollarSign || markdownLineEnding(code)) {
				effects.exit("mathTextData");
				return between(code);
			}
			effects.consume(code);
			return data;
		}
		/**
		* In closing sequence.
		*
		* ```markdown
		* > | `a`
		*       ^
		* ```
		*
		* @type {State}
		*/
		function sequenceClose(code) {
			if (code === codes.dollarSign) {
				effects.consume(code);
				size++;
				return sequenceClose;
			}
			if (size === sizeOpen) {
				effects.exit("mathTextSequence");
				effects.exit("mathText");
				return ok$1(code);
			}
			token.type = "mathTextData";
			return data(code);
		}
	}
}
/** @type {Resolver} */
function resolveMathText(events) {
	let tailExitIndex = events.length - 4;
	let headEnterIndex = 3;
	/** @type {number} */
	let index;
	/** @type {number | undefined} */
	let enter;
	if ((events[headEnterIndex][1].type === types.lineEnding || events[headEnterIndex][1].type === "space") && (events[tailExitIndex][1].type === types.lineEnding || events[tailExitIndex][1].type === "space")) {
		index = headEnterIndex;
		while (++index < tailExitIndex) if (events[index][1].type === "mathTextData") {
			events[tailExitIndex][1].type = "mathTextPadding";
			events[headEnterIndex][1].type = "mathTextPadding";
			headEnterIndex += 2;
			tailExitIndex -= 2;
			break;
		}
	}
	index = headEnterIndex - 1;
	tailExitIndex++;
	while (++index <= tailExitIndex) if (enter === void 0) {
		if (index !== tailExitIndex && events[index][1].type !== types.lineEnding) enter = index;
	} else if (index === tailExitIndex || events[index][1].type === types.lineEnding) {
		events[enter][1].type = "mathTextData";
		if (index !== enter + 2) {
			events[enter][1].end = events[index - 1][1].end;
			events.splice(enter + 2, index - enter - 2);
			tailExitIndex -= index - enter - 2;
			index = enter + 2;
		}
		enter = void 0;
	}
	return events;
}
/**
* @this {TokenizeContext}
* @type {Previous}
*/
function previous(code) {
	return code !== codes.dollarSign || this.events[this.events.length - 1][1].type === types.characterEscape;
}
//#endregion
//#region node_modules/micromark-extension-math/dev/lib/syntax.js
/**
* @import {Options} from 'micromark-extension-math'
* @import {Extension} from 'micromark-util-types'
*/
/**
* Create an extension for `micromark` to enable math syntax.
*
* @param {Options | null | undefined} [options={}]
*   Configuration (default: `{}`).
* @returns {Extension}
*   Extension for `micromark` that can be passed in `extensions`, to
*   enable math syntax.
*/
function math(options) {
	return {
		flow: { [codes.dollarSign]: mathFlow },
		text: { [codes.dollarSign]: mathText(options) }
	};
}
//#endregion
//#region node_modules/remark-math/lib/index.js
/**
* @typedef {import('mdast').Root} Root
* @typedef {import('mdast-util-math').ToOptions} Options
* @typedef {import('unified').Processor<Root>} Processor
*/
/** @type {Readonly<Options>} */
var emptyOptions = {};
/**
* Add support for math.
*
* @param {Readonly<Options> | null | undefined} [options]
*   Configuration (optional).
* @returns {undefined}
*   Nothing.
*/
function remarkMath(options) {
	const self = this;
	const settings = options || emptyOptions;
	const data = self.data();
	const micromarkExtensions = data.micromarkExtensions || (data.micromarkExtensions = []);
	const fromMarkdownExtensions = data.fromMarkdownExtensions || (data.fromMarkdownExtensions = []);
	const toMarkdownExtensions = data.toMarkdownExtensions || (data.toMarkdownExtensions = []);
	micromarkExtensions.push(math(settings));
	fromMarkdownExtensions.push(mathFromMarkdown());
	toMarkdownExtensions.push(mathToMarkdown(settings));
}
//#endregion
export { remarkMath as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVtYXJrLW1hdGguanMiLCJuYW1lcyI6WyJvayIsIm9rIl0sInNvdXJjZXMiOlsiLi4vLi4vbWRhc3QtdXRpbC1tYXRoL2xpYi9pbmRleC5qcyIsIi4uLy4uL21pY3JvbWFyay1leHRlbnNpb24tbWF0aC9kZXYvbGliL21hdGgtZmxvdy5qcyIsIi4uLy4uL21pY3JvbWFyay1leHRlbnNpb24tbWF0aC9kZXYvbGliL21hdGgtdGV4dC5qcyIsIi4uLy4uL21pY3JvbWFyay1leHRlbnNpb24tbWF0aC9kZXYvbGliL3N5bnRheC5qcyIsIi4uLy4uL3JlbWFyay1tYXRoL2xpYi9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ2hhc3QnKS5FbGVtZW50fSBIYXN0RWxlbWVudFxuICogQHR5cGVkZWYge2ltcG9ydCgnaGFzdCcpLkVsZW1lbnRDb250ZW50fSBIYXN0RWxlbWVudENvbnRlbnRcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0LXV0aWwtZnJvbS1tYXJrZG93bicpLkNvbXBpbGVDb250ZXh0fSBDb21waWxlQ29udGV4dFxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC1mcm9tLW1hcmtkb3duJykuRXh0ZW5zaW9ufSBGcm9tTWFya2Rvd25FeHRlbnNpb25cbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0LXV0aWwtZnJvbS1tYXJrZG93bicpLkhhbmRsZX0gRnJvbU1hcmtkb3duSGFuZGxlXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLXRvLW1hcmtkb3duJykuSGFuZGxlfSBUb01hcmtkb3duSGFuZGxlXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCdtZGFzdC11dGlsLXRvLW1hcmtkb3duJykuT3B0aW9uc30gVG9NYXJrZG93bkV4dGVuc2lvblxuICogQHR5cGVkZWYge2ltcG9ydCgnLi4vaW5kZXguanMnKS5JbmxpbmVNYXRofSBJbmxpbmVNYXRoXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCcuLi9pbmRleC5qcycpLk1hdGh9IE1hdGhcbiAqXG4gKiBAdHlwZWRlZiBUb09wdGlvbnNcbiAqICAgQ29uZmlndXJhdGlvbi5cbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbiB8IG51bGwgfCB1bmRlZmluZWR9IFtzaW5nbGVEb2xsYXJUZXh0TWF0aD10cnVlXVxuICogICBXaGV0aGVyIHRvIHN1cHBvcnQgbWF0aCAodGV4dCkgd2l0aCBhIHNpbmdsZSBkb2xsYXIgKGRlZmF1bHQ6IGB0cnVlYCkuXG4gKlxuICogICBTaW5nbGUgZG9sbGFycyB3b3JrIGluIFBhbmRvYyBhbmQgbWFueSBvdGhlciBwbGFjZXMsIGJ1dCBvZnRlbiBpbnRlcmZlcmVcbiAqICAgd2l0aCDigJxub3JtYWzigJ0gZG9sbGFycyBpbiB0ZXh0LlxuICogICBJZiB5b3UgdHVybiB0aGlzIG9mZiwgeW91IGNhbiBzdGlsbCB1c2UgdHdvIG9yIG1vcmUgZG9sbGFycyBmb3IgdGV4dCBtYXRoLlxuICovXG5cbmltcG9ydCB7b2sgYXMgYXNzZXJ0fSBmcm9tICdkZXZsb3AnXG5pbXBvcnQge2xvbmdlc3RTdHJlYWt9IGZyb20gJ2xvbmdlc3Qtc3RyZWFrJ1xuXG4vKipcbiAqIENyZWF0ZSBhbiBleHRlbnNpb24gZm9yIGBtZGFzdC11dGlsLWZyb20tbWFya2Rvd25gLlxuICpcbiAqIEByZXR1cm5zIHtGcm9tTWFya2Rvd25FeHRlbnNpb259XG4gKiAgIEV4dGVuc2lvbiBmb3IgYG1kYXN0LXV0aWwtZnJvbS1tYXJrZG93bmAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYXRoRnJvbU1hcmtkb3duKCkge1xuICByZXR1cm4ge1xuICAgIGVudGVyOiB7XG4gICAgICBtYXRoRmxvdzogZW50ZXJNYXRoRmxvdyxcbiAgICAgIG1hdGhGbG93RmVuY2VNZXRhOiBlbnRlck1hdGhGbG93TWV0YSxcbiAgICAgIG1hdGhUZXh0OiBlbnRlck1hdGhUZXh0XG4gICAgfSxcbiAgICBleGl0OiB7XG4gICAgICBtYXRoRmxvdzogZXhpdE1hdGhGbG93LFxuICAgICAgbWF0aEZsb3dGZW5jZTogZXhpdE1hdGhGbG93RmVuY2UsXG4gICAgICBtYXRoRmxvd0ZlbmNlTWV0YTogZXhpdE1hdGhGbG93TWV0YSxcbiAgICAgIG1hdGhGbG93VmFsdWU6IGV4aXRNYXRoRGF0YSxcbiAgICAgIG1hdGhUZXh0OiBleGl0TWF0aFRleHQsXG4gICAgICBtYXRoVGV4dERhdGE6IGV4aXRNYXRoRGF0YVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gICAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gICAqL1xuICBmdW5jdGlvbiBlbnRlck1hdGhGbG93KHRva2VuKSB7XG4gICAgLyoqIEB0eXBlIHtIYXN0RWxlbWVudH0gKi9cbiAgICBjb25zdCBjb2RlID0ge1xuICAgICAgdHlwZTogJ2VsZW1lbnQnLFxuICAgICAgdGFnTmFtZTogJ2NvZGUnLFxuICAgICAgcHJvcGVydGllczoge2NsYXNzTmFtZTogWydsYW5ndWFnZS1tYXRoJywgJ21hdGgtZGlzcGxheSddfSxcbiAgICAgIGNoaWxkcmVuOiBbXVxuICAgIH1cbiAgICB0aGlzLmVudGVyKFxuICAgICAge1xuICAgICAgICB0eXBlOiAnbWF0aCcsXG4gICAgICAgIG1ldGE6IG51bGwsXG4gICAgICAgIHZhbHVlOiAnJyxcbiAgICAgICAgZGF0YToge2hOYW1lOiAncHJlJywgaENoaWxkcmVuOiBbY29kZV19XG4gICAgICB9LFxuICAgICAgdG9rZW5cbiAgICApXG4gIH1cblxuICAvKipcbiAgICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICAgKiBAdHlwZSB7RnJvbU1hcmtkb3duSGFuZGxlfVxuICAgKi9cbiAgZnVuY3Rpb24gZW50ZXJNYXRoRmxvd01ldGEoKSB7XG4gICAgdGhpcy5idWZmZXIoKVxuICB9XG5cbiAgLyoqXG4gICAqIEB0aGlzIHtDb21waWxlQ29udGV4dH1cbiAgICogQHR5cGUge0Zyb21NYXJrZG93bkhhbmRsZX1cbiAgICovXG4gIGZ1bmN0aW9uIGV4aXRNYXRoRmxvd01ldGEoKSB7XG4gICAgY29uc3QgZGF0YSA9IHRoaXMucmVzdW1lKClcbiAgICBjb25zdCBub2RlID0gdGhpcy5zdGFja1t0aGlzLnN0YWNrLmxlbmd0aCAtIDFdXG4gICAgYXNzZXJ0KG5vZGUudHlwZSA9PT0gJ21hdGgnKVxuICAgIG5vZGUubWV0YSA9IGRhdGFcbiAgfVxuXG4gIC8qKlxuICAgKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gICAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gICAqL1xuICBmdW5jdGlvbiBleGl0TWF0aEZsb3dGZW5jZSgpIHtcbiAgICAvLyBFeGl0IGlmIHRoaXMgaXMgdGhlIGNsb3NpbmcgZmVuY2UuXG4gICAgaWYgKHRoaXMuZGF0YS5tYXRoRmxvd0luc2lkZSkgcmV0dXJuXG4gICAgdGhpcy5idWZmZXIoKVxuICAgIHRoaXMuZGF0YS5tYXRoRmxvd0luc2lkZSA9IHRydWVcbiAgfVxuXG4gIC8qKlxuICAgKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gICAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gICAqL1xuICBmdW5jdGlvbiBleGl0TWF0aEZsb3codG9rZW4pIHtcbiAgICBjb25zdCBkYXRhID0gdGhpcy5yZXN1bWUoKS5yZXBsYWNlKC9eKFxccj9cXG58XFxyKXwoXFxyP1xcbnxcXHIpJC9nLCAnJylcbiAgICBjb25zdCBub2RlID0gdGhpcy5zdGFja1t0aGlzLnN0YWNrLmxlbmd0aCAtIDFdXG4gICAgYXNzZXJ0KG5vZGUudHlwZSA9PT0gJ21hdGgnKVxuICAgIHRoaXMuZXhpdCh0b2tlbilcbiAgICBub2RlLnZhbHVlID0gZGF0YVxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3I6IHdlIGRlZmluZWQgaXQgaW4gYGVudGVyTWF0aEZsb3dgLlxuICAgIGNvbnN0IGNvZGUgPSAvKiogQHR5cGUge0hhc3RFbGVtZW50fSAqLyAobm9kZS5kYXRhLmhDaGlsZHJlblswXSlcbiAgICBhc3NlcnQoY29kZS50eXBlID09PSAnZWxlbWVudCcpXG4gICAgYXNzZXJ0KGNvZGUudGFnTmFtZSA9PT0gJ2NvZGUnKVxuICAgIGNvZGUuY2hpbGRyZW4ucHVzaCh7dHlwZTogJ3RleHQnLCB2YWx1ZTogZGF0YX0pXG4gICAgdGhpcy5kYXRhLm1hdGhGbG93SW5zaWRlID0gdW5kZWZpbmVkXG4gIH1cblxuICAvKipcbiAgICogQHRoaXMge0NvbXBpbGVDb250ZXh0fVxuICAgKiBAdHlwZSB7RnJvbU1hcmtkb3duSGFuZGxlfVxuICAgKi9cbiAgZnVuY3Rpb24gZW50ZXJNYXRoVGV4dCh0b2tlbikge1xuICAgIHRoaXMuZW50ZXIoXG4gICAgICB7XG4gICAgICAgIHR5cGU6ICdpbmxpbmVNYXRoJyxcbiAgICAgICAgdmFsdWU6ICcnLFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgaE5hbWU6ICdjb2RlJyxcbiAgICAgICAgICBoUHJvcGVydGllczoge2NsYXNzTmFtZTogWydsYW5ndWFnZS1tYXRoJywgJ21hdGgtaW5saW5lJ119LFxuICAgICAgICAgIGhDaGlsZHJlbjogW11cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHRva2VuXG4gICAgKVxuICAgIHRoaXMuYnVmZmVyKClcbiAgfVxuXG4gIC8qKlxuICAgKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gICAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gICAqL1xuICBmdW5jdGlvbiBleGl0TWF0aFRleHQodG9rZW4pIHtcbiAgICBjb25zdCBkYXRhID0gdGhpcy5yZXN1bWUoKVxuICAgIGNvbnN0IG5vZGUgPSB0aGlzLnN0YWNrW3RoaXMuc3RhY2subGVuZ3RoIC0gMV1cbiAgICBhc3NlcnQobm9kZS50eXBlID09PSAnaW5saW5lTWF0aCcpXG4gICAgdGhpcy5leGl0KHRva2VuKVxuICAgIG5vZGUudmFsdWUgPSBkYXRhXG4gICAgY29uc3QgY2hpbGRyZW4gPSAvKiogQHR5cGUge0FycmF5PEhhc3RFbGVtZW50Q29udGVudD59ICovIChcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3I6IHdlIGRlZmluZWQgaXQgaW4gYGVudGVyTWF0aEZsb3dgLlxuICAgICAgbm9kZS5kYXRhLmhDaGlsZHJlblxuICAgIClcbiAgICBjaGlsZHJlbi5wdXNoKHt0eXBlOiAndGV4dCcsIHZhbHVlOiBkYXRhfSlcbiAgfVxuXG4gIC8qKlxuICAgKiBAdGhpcyB7Q29tcGlsZUNvbnRleHR9XG4gICAqIEB0eXBlIHtGcm9tTWFya2Rvd25IYW5kbGV9XG4gICAqL1xuICBmdW5jdGlvbiBleGl0TWF0aERhdGEodG9rZW4pIHtcbiAgICB0aGlzLmNvbmZpZy5lbnRlci5kYXRhLmNhbGwodGhpcywgdG9rZW4pXG4gICAgdGhpcy5jb25maWcuZXhpdC5kYXRhLmNhbGwodGhpcywgdG9rZW4pXG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGUgYW4gZXh0ZW5zaW9uIGZvciBgbWRhc3QtdXRpbC10by1tYXJrZG93bmAuXG4gKlxuICogQHBhcmFtIHtUb09wdGlvbnMgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0aW9uc11cbiAqICAgQ29uZmlndXJhdGlvbiAob3B0aW9uYWwpLlxuICogQHJldHVybnMge1RvTWFya2Rvd25FeHRlbnNpb259XG4gKiAgIEV4dGVuc2lvbiBmb3IgYG1kYXN0LXV0aWwtdG8tbWFya2Rvd25gLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWF0aFRvTWFya2Rvd24ob3B0aW9ucykge1xuICBsZXQgc2luZ2xlID0gKG9wdGlvbnMgfHwge30pLnNpbmdsZURvbGxhclRleHRNYXRoXG5cbiAgaWYgKHNpbmdsZSA9PT0gbnVsbCB8fCBzaW5nbGUgPT09IHVuZGVmaW5lZCkge1xuICAgIHNpbmdsZSA9IHRydWVcbiAgfVxuXG4gIGlubGluZU1hdGgucGVlayA9IGlubGluZU1hdGhQZWVrXG5cbiAgcmV0dXJuIHtcbiAgICB1bnNhZmU6IFtcbiAgICAgIHtjaGFyYWN0ZXI6ICdcXHInLCBpbkNvbnN0cnVjdDogJ21hdGhGbG93TWV0YSd9LFxuICAgICAge2NoYXJhY3RlcjogJ1xcbicsIGluQ29uc3RydWN0OiAnbWF0aEZsb3dNZXRhJ30sXG4gICAgICB7XG4gICAgICAgIGNoYXJhY3RlcjogJyQnLFxuICAgICAgICBhZnRlcjogc2luZ2xlID8gdW5kZWZpbmVkIDogJ1xcXFwkJyxcbiAgICAgICAgaW5Db25zdHJ1Y3Q6ICdwaHJhc2luZydcbiAgICAgIH0sXG4gICAgICB7Y2hhcmFjdGVyOiAnJCcsIGluQ29uc3RydWN0OiAnbWF0aEZsb3dNZXRhJ30sXG4gICAgICB7YXRCcmVhazogdHJ1ZSwgY2hhcmFjdGVyOiAnJCcsIGFmdGVyOiAnXFxcXCQnfVxuICAgIF0sXG4gICAgaGFuZGxlcnM6IHttYXRoLCBpbmxpbmVNYXRofVxuICB9XG5cbiAgLyoqXG4gICAqIEB0eXBlIHtUb01hcmtkb3duSGFuZGxlfVxuICAgKiBAcGFyYW0ge01hdGh9IG5vZGVcbiAgICovXG4gIC8vIE5vdGU6IGZpeGluZyB0aGlzIGNvZGU/IFBsZWFzZSBhbHNvIGZpeCB0aGUgc2ltaWxhciBjb2RlIGZvciBjb2RlOlxuICAvLyA8aHR0cHM6Ly9naXRodWIuY29tL3N5bnRheC10cmVlL21kYXN0LXV0aWwtdG8tbWFya2Rvd24vYmxvYi9tYWluL2xpYi9oYW5kbGUvY29kZS5qcz5cbiAgZnVuY3Rpb24gbWF0aChub2RlLCBfLCBzdGF0ZSwgaW5mbykge1xuICAgIGNvbnN0IHJhdyA9IG5vZGUudmFsdWUgfHwgJydcbiAgICBjb25zdCB0cmFja2VyID0gc3RhdGUuY3JlYXRlVHJhY2tlcihpbmZvKVxuICAgIGNvbnN0IHNlcXVlbmNlID0gJyQnLnJlcGVhdChNYXRoLm1heChsb25nZXN0U3RyZWFrKHJhdywgJyQnKSArIDEsIDIpKVxuICAgIGNvbnN0IGV4aXQgPSBzdGF0ZS5lbnRlcignbWF0aEZsb3cnKVxuICAgIGxldCB2YWx1ZSA9IHRyYWNrZXIubW92ZShzZXF1ZW5jZSlcblxuICAgIGlmIChub2RlLm1ldGEpIHtcbiAgICAgIGNvbnN0IHN1YmV4aXQgPSBzdGF0ZS5lbnRlcignbWF0aEZsb3dNZXRhJylcbiAgICAgIHZhbHVlICs9IHRyYWNrZXIubW92ZShcbiAgICAgICAgc3RhdGUuc2FmZShub2RlLm1ldGEsIHtcbiAgICAgICAgICBhZnRlcjogJ1xcbicsXG4gICAgICAgICAgYmVmb3JlOiB2YWx1ZSxcbiAgICAgICAgICBlbmNvZGU6IFsnJCddLFxuICAgICAgICAgIC4uLnRyYWNrZXIuY3VycmVudCgpXG4gICAgICAgIH0pXG4gICAgICApXG4gICAgICBzdWJleGl0KClcbiAgICB9XG5cbiAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUoJ1xcbicpXG5cbiAgICBpZiAocmF3KSB7XG4gICAgICB2YWx1ZSArPSB0cmFja2VyLm1vdmUocmF3ICsgJ1xcbicpXG4gICAgfVxuXG4gICAgdmFsdWUgKz0gdHJhY2tlci5tb3ZlKHNlcXVlbmNlKVxuICAgIGV4aXQoKVxuICAgIHJldHVybiB2YWx1ZVxuICB9XG5cbiAgLyoqXG4gICAqIEB0eXBlIHtUb01hcmtkb3duSGFuZGxlfVxuICAgKiBAcGFyYW0ge0lubGluZU1hdGh9IG5vZGVcbiAgICovXG4gIC8vIE5vdGU6IGZpeGluZyB0aGlzIGNvZGU/IFBsZWFzZSBhbHNvIGZpeCB0aGUgc2ltaWxhciBjb2RlIGZvciBpbmxpbmUgY29kZTpcbiAgLy8gPGh0dHBzOi8vZ2l0aHViLmNvbS9zeW50YXgtdHJlZS9tZGFzdC11dGlsLXRvLW1hcmtkb3duL2Jsb2IvbWFpbi9saWIvaGFuZGxlL2lubGluZS1jb2RlLmpzPlxuICBmdW5jdGlvbiBpbmxpbmVNYXRoKG5vZGUsIF8sIHN0YXRlKSB7XG4gICAgbGV0IHZhbHVlID0gbm9kZS52YWx1ZSB8fCAnJ1xuICAgIGxldCBzaXplID0gMVxuXG4gICAgaWYgKCFzaW5nbGUpIHNpemUrK1xuXG4gICAgLy8gSWYgdGhlcmUgaXMgYSBzaW5nbGUgZG9sbGFyIHNpZ24gb24gaXRzIG93biBpbiB0aGUgbWF0aCwgdXNlIGEgZmVuY2Ugb2ZcbiAgICAvLyB0d28uXG4gICAgLy8gSWYgdGhlcmUgYXJlIHR3byBpbiBhIHJvdywgdXNlIG9uZS5cbiAgICB3aGlsZSAoXG4gICAgICBuZXcgUmVnRXhwKCcoXnxbXiRdKScgKyAnXFxcXCQnLnJlcGVhdChzaXplKSArICcoW14kXXwkKScpLnRlc3QodmFsdWUpXG4gICAgKSB7XG4gICAgICBzaXplKytcbiAgICB9XG5cbiAgICBjb25zdCBzZXF1ZW5jZSA9ICckJy5yZXBlYXQoc2l6ZSlcblxuICAgIC8vIElmIHRoaXMgaXMgbm90IGp1c3Qgc3BhY2VzIG9yIGVvbHMgKHRhYnMgZG9u4oCZdCBjb3VudCksIGFuZCBlaXRoZXIgdGhlXG4gICAgLy8gZmlyc3QgYW5kIGxhc3QgY2hhcmFjdGVyIGFyZSBhIHNwYWNlIG9yIGVvbCwgb3IgdGhlIGZpcnN0IG9yIGxhc3RcbiAgICAvLyBjaGFyYWN0ZXIgYXJlIGRvbGxhciBzaWducywgdGhlbiBwYWQgd2l0aCBzcGFjZXMuXG4gICAgaWYgKFxuICAgICAgLy8gQ29udGFpbnMgbm9uLXNwYWNlLlxuICAgICAgL1teIFxcclxcbl0vLnRlc3QodmFsdWUpICYmXG4gICAgICAvLyBTdGFydHMgd2l0aCBzcGFjZSBhbmQgZW5kcyB3aXRoIHNwYWNlLlxuICAgICAgKCgvXlsgXFxyXFxuXS8udGVzdCh2YWx1ZSkgJiYgL1sgXFxyXFxuXSQvLnRlc3QodmFsdWUpKSB8fFxuICAgICAgICAvLyBTdGFydHMgb3IgZW5kcyB3aXRoIGRvbGxhci5cbiAgICAgICAgL15cXCR8XFwkJC8udGVzdCh2YWx1ZSkpXG4gICAgKSB7XG4gICAgICB2YWx1ZSA9ICcgJyArIHZhbHVlICsgJyAnXG4gICAgfVxuXG4gICAgbGV0IGluZGV4ID0gLTFcblxuICAgIC8vIFdlIGhhdmUgYSBwb3RlbnRpYWwgcHJvYmxlbTogY2VydGFpbiBjaGFyYWN0ZXJzIGFmdGVyIGVvbHMgY291bGQgcmVzdWx0IGluXG4gICAgLy8gYmxvY2tzIGJlaW5nIHNlZW4uXG4gICAgLy8gRm9yIGV4YW1wbGUsIGlmIHNvbWVvbmUgaW5qZWN0ZWQgdGhlIHN0cmluZyBgJ1xcbiMgYidgLCB0aGVuIHRoYXQgd291bGRcbiAgICAvLyByZXN1bHQgaW4gYW4gQVRYIGhlYWRpbmcuXG4gICAgLy8gV2UgY2Fu4oCZdCBlc2NhcGUgY2hhcmFjdGVycyBpbiBgaW5saW5lTWF0aGAsIGJ1dCBiZWNhdXNlIGVvbHMgYXJlXG4gICAgLy8gdHJhbnNmb3JtZWQgdG8gc3BhY2VzIHdoZW4gZ29pbmcgZnJvbSBtYXJrZG93biB0byBIVE1MIGFueXdheSwgd2UgY2FuIHN3YXBcbiAgICAvLyB0aGVtIG91dC5cbiAgICB3aGlsZSAoKytpbmRleCA8IHN0YXRlLnVuc2FmZS5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IHBhdHRlcm4gPSBzdGF0ZS51bnNhZmVbaW5kZXhdXG5cbiAgICAgIC8vIE9ubHkgbG9vayBmb3IgYGF0QnJlYWtgcy5cbiAgICAgIC8vIEJ0dzogbm90ZSB0aGF0IGBhdEJyZWFrYCBwYXR0ZXJucyB3aWxsIGFsd2F5cyBzdGFydCB0aGUgcmVnZXggYXQgTEYgb3JcbiAgICAgIC8vIENSLlxuICAgICAgaWYgKCFwYXR0ZXJuLmF0QnJlYWspIGNvbnRpbnVlXG5cbiAgICAgIGNvbnN0IGV4cHJlc3Npb24gPSBzdGF0ZS5jb21waWxlUGF0dGVybihwYXR0ZXJuKVxuICAgICAgLyoqIEB0eXBlIHtSZWdFeHBFeGVjQXJyYXkgfCBudWxsfSAqL1xuICAgICAgbGV0IG1hdGNoXG5cbiAgICAgIHdoaWxlICgobWF0Y2ggPSBleHByZXNzaW9uLmV4ZWModmFsdWUpKSkge1xuICAgICAgICBsZXQgcG9zaXRpb24gPSBtYXRjaC5pbmRleFxuXG4gICAgICAgIC8vIFN1cHBvcnQgQ1JMRiAocGF0dGVybnMgb25seSBsb29rIGZvciBvbmUgb2YgdGhlIGNoYXJhY3RlcnMpLlxuICAgICAgICBpZiAoXG4gICAgICAgICAgdmFsdWUuY29kZVBvaW50QXQocG9zaXRpb24pID09PSAxMCAvKiBgXFxuYCAqLyAmJlxuICAgICAgICAgIHZhbHVlLmNvZGVQb2ludEF0KHBvc2l0aW9uIC0gMSkgPT09IDEzIC8qIGBcXHJgICovXG4gICAgICAgICkge1xuICAgICAgICAgIHBvc2l0aW9uLS1cbiAgICAgICAgfVxuXG4gICAgICAgIHZhbHVlID0gdmFsdWUuc2xpY2UoMCwgcG9zaXRpb24pICsgJyAnICsgdmFsdWUuc2xpY2UobWF0Y2guaW5kZXggKyAxKVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBzZXF1ZW5jZSArIHZhbHVlICsgc2VxdWVuY2VcbiAgfVxuXG4gIC8qKlxuICAgKiBAcmV0dXJucyB7c3RyaW5nfVxuICAgKi9cbiAgZnVuY3Rpb24gaW5saW5lTWF0aFBlZWsoKSB7XG4gICAgcmV0dXJuICckJ1xuICB9XG59XG4iLCIvKipcbiAqIEBpbXBvcnQge0NvbnN0cnVjdCwgU3RhdGUsIFRva2VuaXplQ29udGV4dCwgVG9rZW5pemVyfSBmcm9tICdtaWNyb21hcmstdXRpbC10eXBlcydcbiAqL1xuXG5pbXBvcnQge29rIGFzIGFzc2VydH0gZnJvbSAnZGV2bG9wJ1xuaW1wb3J0IHtmYWN0b3J5U3BhY2V9IGZyb20gJ21pY3JvbWFyay1mYWN0b3J5LXNwYWNlJ1xuaW1wb3J0IHttYXJrZG93bkxpbmVFbmRpbmd9IGZyb20gJ21pY3JvbWFyay11dGlsLWNoYXJhY3RlcidcbmltcG9ydCB7Y29kZXMsIGNvbnN0YW50cywgdHlwZXN9IGZyb20gJ21pY3JvbWFyay11dGlsLXN5bWJvbCdcblxuLyoqIEB0eXBlIHtDb25zdHJ1Y3R9ICovXG5leHBvcnQgY29uc3QgbWF0aEZsb3cgPSB7XG4gIHRva2VuaXplOiB0b2tlbml6ZU1hdGhGZW5jZWQsXG4gIGNvbmNyZXRlOiB0cnVlLFxuICBuYW1lOiAnbWF0aEZsb3cnXG59XG5cbi8qKiBAdHlwZSB7Q29uc3RydWN0fSAqL1xuY29uc3Qgbm9uTGF6eUNvbnRpbnVhdGlvbiA9IHtcbiAgdG9rZW5pemU6IHRva2VuaXplTm9uTGF6eUNvbnRpbnVhdGlvbixcbiAgcGFydGlhbDogdHJ1ZVxufVxuXG4vKipcbiAqIEB0aGlzIHtUb2tlbml6ZUNvbnRleHR9XG4gKiBAdHlwZSB7VG9rZW5pemVyfVxuICovXG5mdW5jdGlvbiB0b2tlbml6ZU1hdGhGZW5jZWQoZWZmZWN0cywgb2ssIG5vaykge1xuICBjb25zdCBzZWxmID0gdGhpc1xuICBjb25zdCB0YWlsID0gc2VsZi5ldmVudHNbc2VsZi5ldmVudHMubGVuZ3RoIC0gMV1cbiAgY29uc3QgaW5pdGlhbFNpemUgPVxuICAgIHRhaWwgJiYgdGFpbFsxXS50eXBlID09PSB0eXBlcy5saW5lUHJlZml4XG4gICAgICA/IHRhaWxbMl0uc2xpY2VTZXJpYWxpemUodGFpbFsxXSwgdHJ1ZSkubGVuZ3RoXG4gICAgICA6IDBcbiAgbGV0IHNpemVPcGVuID0gMFxuXG4gIHJldHVybiBzdGFydFxuXG4gIC8qKlxuICAgKiBTdGFydCBvZiBtYXRoLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgJCRcbiAgICogICAgIF5cbiAgICogICB8IFxcZnJhY3sxfXsyfVxuICAgKiAgIHwgJCRcbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIHN0YXJ0KGNvZGUpIHtcbiAgICBhc3NlcnQoY29kZSA9PT0gY29kZXMuZG9sbGFyU2lnbiwgJ2V4cGVjdGVkIGAkYCcpXG4gICAgZWZmZWN0cy5lbnRlcignbWF0aEZsb3cnKVxuICAgIGVmZmVjdHMuZW50ZXIoJ21hdGhGbG93RmVuY2UnKVxuICAgIGVmZmVjdHMuZW50ZXIoJ21hdGhGbG93RmVuY2VTZXF1ZW5jZScpXG4gICAgcmV0dXJuIHNlcXVlbmNlT3Blbihjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEluIG9wZW5pbmcgZmVuY2Ugc2VxdWVuY2UuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCAkJFxuICAgKiAgICAgIF5cbiAgICogICB8IFxcZnJhY3sxfXsyfVxuICAgKiAgIHwgJCRcbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIHNlcXVlbmNlT3Blbihjb2RlKSB7XG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLmRvbGxhclNpZ24pIHtcbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgc2l6ZU9wZW4rK1xuICAgICAgcmV0dXJuIHNlcXVlbmNlT3BlblxuICAgIH1cblxuICAgIGlmIChzaXplT3BlbiA8IDIpIHtcbiAgICAgIHJldHVybiBub2soY29kZSlcbiAgICB9XG5cbiAgICBlZmZlY3RzLmV4aXQoJ21hdGhGbG93RmVuY2VTZXF1ZW5jZScpXG4gICAgcmV0dXJuIGZhY3RvcnlTcGFjZShlZmZlY3RzLCBtZXRhQmVmb3JlLCB0eXBlcy53aGl0ZXNwYWNlKShjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEluIG9wZW5pbmcgZmVuY2UsIGJlZm9yZSBtZXRhLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiA+IHwgJCRhc2NpaW1hdGhcbiAgICogICAgICAgXlxuICAgKiAgIHwgeCA8IHlcbiAgICogICB8ICQkXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuXG4gIGZ1bmN0aW9uIG1ldGFCZWZvcmUoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5lb2YgfHwgbWFya2Rvd25MaW5lRW5kaW5nKGNvZGUpKSB7XG4gICAgICByZXR1cm4gbWV0YUFmdGVyKGNvZGUpXG4gICAgfVxuXG4gICAgZWZmZWN0cy5lbnRlcignbWF0aEZsb3dGZW5jZU1ldGEnKVxuICAgIGVmZmVjdHMuZW50ZXIodHlwZXMuY2h1bmtTdHJpbmcsIHtjb250ZW50VHlwZTogY29uc3RhbnRzLmNvbnRlbnRUeXBlU3RyaW5nfSlcbiAgICByZXR1cm4gbWV0YShjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEluIG1ldGEuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCAkJGFzY2lpbWF0aFxuICAgKiAgICAgICAgXlxuICAgKiAgIHwgeCA8IHlcbiAgICogICB8ICQkXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBtZXRhKGNvZGUpIHtcbiAgICBpZiAoY29kZSA9PT0gY29kZXMuZW9mIHx8IG1hcmtkb3duTGluZUVuZGluZyhjb2RlKSkge1xuICAgICAgZWZmZWN0cy5leGl0KHR5cGVzLmNodW5rU3RyaW5nKVxuICAgICAgZWZmZWN0cy5leGl0KCdtYXRoRmxvd0ZlbmNlTWV0YScpXG4gICAgICByZXR1cm4gbWV0YUFmdGVyKGNvZGUpXG4gICAgfVxuXG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLmRvbGxhclNpZ24pIHtcbiAgICAgIHJldHVybiBub2soY29kZSlcbiAgICB9XG5cbiAgICBlZmZlY3RzLmNvbnN1bWUoY29kZSlcbiAgICByZXR1cm4gbWV0YVxuICB9XG5cbiAgLyoqXG4gICAqIEFmdGVyIG1ldGEuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqID4gfCAkJFxuICAgKiAgICAgICBeXG4gICAqICAgfCBcXGZyYWN7MX17Mn1cbiAgICogICB8ICQkXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBtZXRhQWZ0ZXIoY29kZSkge1xuICAgIC8vIEd1YXJhbnRlZWQgdG8gYmUgZW9sL2VvZi5cbiAgICBlZmZlY3RzLmV4aXQoJ21hdGhGbG93RmVuY2UnKVxuXG4gICAgaWYgKHNlbGYuaW50ZXJydXB0KSB7XG4gICAgICByZXR1cm4gb2soY29kZSlcbiAgICB9XG5cbiAgICByZXR1cm4gZWZmZWN0cy5hdHRlbXB0KFxuICAgICAgbm9uTGF6eUNvbnRpbnVhdGlvbixcbiAgICAgIGJlZm9yZU5vbkxhenlDb250aW51YXRpb24sXG4gICAgICBhZnRlclxuICAgICkoY29kZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBlb2wvZW9mIGluIG1hdGgsIGF0IGEgbm9uLWxhenkgY2xvc2luZyBmZW5jZSBvciBjb250ZW50LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgJCRcbiAgICogPiB8IFxcZnJhY3sxfXsyfVxuICAgKiAgICAgXlxuICAgKiA+IHwgJCRcbiAgICogICAgIF5cbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGJlZm9yZU5vbkxhenlDb250aW51YXRpb24oY29kZSkge1xuICAgIHJldHVybiBlZmZlY3RzLmF0dGVtcHQoXG4gICAgICB7dG9rZW5pemU6IHRva2VuaXplQ2xvc2luZ0ZlbmNlLCBwYXJ0aWFsOiB0cnVlfSxcbiAgICAgIGFmdGVyLFxuICAgICAgY29udGVudFN0YXJ0XG4gICAgKShjb2RlKVxuICB9XG5cbiAgLyoqXG4gICAqIEJlZm9yZSBtYXRoIGNvbnRlbnQsIGRlZmluaXRlbHkgbm90IGJlZm9yZSBhIGNsb3NpbmcgZmVuY2UuXG4gICAqXG4gICAqIGBgYG1hcmtkb3duXG4gICAqICAgfCAkJFxuICAgKiA+IHwgXFxmcmFjezF9ezJ9XG4gICAqICAgICBeXG4gICAqICAgfCAkJFxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gY29udGVudFN0YXJ0KGNvZGUpIHtcbiAgICByZXR1cm4gKFxuICAgICAgaW5pdGlhbFNpemVcbiAgICAgICAgPyBmYWN0b3J5U3BhY2UoXG4gICAgICAgICAgICBlZmZlY3RzLFxuICAgICAgICAgICAgYmVmb3JlQ29udGVudENodW5rLFxuICAgICAgICAgICAgdHlwZXMubGluZVByZWZpeCxcbiAgICAgICAgICAgIGluaXRpYWxTaXplICsgMVxuICAgICAgICAgIClcbiAgICAgICAgOiBiZWZvcmVDb250ZW50Q2h1bmtcbiAgICApKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogQmVmb3JlIG1hdGggY29udGVudCwgYWZ0ZXIgb3B0aW9uYWwgcHJlZml4LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgJCRcbiAgICogPiB8IFxcZnJhY3sxfXsyfVxuICAgKiAgICAgXlxuICAgKiAgIHwgJCRcbiAgICogYGBgXG4gICAqXG4gICAqIEB0eXBlIHtTdGF0ZX1cbiAgICovXG4gIGZ1bmN0aW9uIGJlZm9yZUNvbnRlbnRDaHVuayhjb2RlKSB7XG4gICAgaWYgKGNvZGUgPT09IGNvZGVzLmVvZikge1xuICAgICAgcmV0dXJuIGFmdGVyKGNvZGUpXG4gICAgfVxuXG4gICAgaWYgKG1hcmtkb3duTGluZUVuZGluZyhjb2RlKSkge1xuICAgICAgcmV0dXJuIGVmZmVjdHMuYXR0ZW1wdChcbiAgICAgICAgbm9uTGF6eUNvbnRpbnVhdGlvbixcbiAgICAgICAgYmVmb3JlTm9uTGF6eUNvbnRpbnVhdGlvbixcbiAgICAgICAgYWZ0ZXJcbiAgICAgICkoY29kZSlcbiAgICB9XG5cbiAgICBlZmZlY3RzLmVudGVyKCdtYXRoRmxvd1ZhbHVlJylcbiAgICByZXR1cm4gY29udGVudENodW5rKGNvZGUpXG4gIH1cblxuICAvKipcbiAgICogSW4gbWF0aCBjb250ZW50LlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgJCRcbiAgICogPiB8IFxcZnJhY3sxfXsyfVxuICAgKiAgICAgIF5cbiAgICogICB8ICQkXG4gICAqIGBgYFxuICAgKlxuICAgKiBAdHlwZSB7U3RhdGV9XG4gICAqL1xuICBmdW5jdGlvbiBjb250ZW50Q2h1bmsoY29kZSkge1xuICAgIGlmIChjb2RlID09PSBjb2Rlcy5lb2YgfHwgbWFya2Rvd25MaW5lRW5kaW5nKGNvZGUpKSB7XG4gICAgICBlZmZlY3RzLmV4aXQoJ21hdGhGbG93VmFsdWUnKVxuICAgICAgcmV0dXJuIGJlZm9yZUNvbnRlbnRDaHVuayhjb2RlKVxuICAgIH1cblxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIHJldHVybiBjb250ZW50Q2h1bmtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZnRlciBtYXRoIChoYSEpLlxuICAgKlxuICAgKiBgYGBtYXJrZG93blxuICAgKiAgIHwgJCRcbiAgICogICB8IFxcZnJhY3sxfXsyfVxuICAgKiA+IHwgJCRcbiAgICogICAgICAgXlxuICAgKiBgYGBcbiAgICpcbiAgICogQHR5cGUge1N0YXRlfVxuICAgKi9cbiAgZnVuY3Rpb24gYWZ0ZXIoY29kZSkge1xuICAgIGVmZmVjdHMuZXhpdCgnbWF0aEZsb3cnKVxuICAgIHJldHVybiBvayhjb2RlKVxuICB9XG5cbiAgLyoqIEB0eXBlIHtUb2tlbml6ZXJ9ICovXG4gIGZ1bmN0aW9uIHRva2VuaXplQ2xvc2luZ0ZlbmNlKGVmZmVjdHMsIG9rLCBub2spIHtcbiAgICBsZXQgc2l6ZSA9IDBcblxuICAgIGFzc2VydChzZWxmLnBhcnNlci5jb25zdHJ1Y3RzLmRpc2FibGUubnVsbCwgJ2V4cGVjdGVkIGBkaXNhYmxlLm51bGxgJylcbiAgICAvKipcbiAgICAgKiBCZWZvcmUgY2xvc2luZyBmZW5jZSwgYXQgb3B0aW9uYWwgd2hpdGVzcGFjZS5cbiAgICAgKlxuICAgICAqIGBgYG1hcmtkb3duXG4gICAgICogICB8ICQkXG4gICAgICogICB8IFxcZnJhY3sxfXsyfVxuICAgICAqID4gfCAkJFxuICAgICAqICAgICBeXG4gICAgICogYGBgXG4gICAgICovXG4gICAgcmV0dXJuIGZhY3RvcnlTcGFjZShcbiAgICAgIGVmZmVjdHMsXG4gICAgICBiZWZvcmVTZXF1ZW5jZUNsb3NlLFxuICAgICAgdHlwZXMubGluZVByZWZpeCxcbiAgICAgIHNlbGYucGFyc2VyLmNvbnN0cnVjdHMuZGlzYWJsZS5udWxsLmluY2x1ZGVzKCdjb2RlSW5kZW50ZWQnKVxuICAgICAgICA/IHVuZGVmaW5lZFxuICAgICAgICA6IGNvbnN0YW50cy50YWJTaXplXG4gICAgKVxuXG4gICAgLyoqXG4gICAgICogSW4gY2xvc2luZyBmZW5jZSwgYWZ0ZXIgb3B0aW9uYWwgd2hpdGVzcGFjZSwgYXQgc2VxdWVuY2UuXG4gICAgICpcbiAgICAgKiBgYGBtYXJrZG93blxuICAgICAqICAgfCAkJFxuICAgICAqICAgfCBcXGZyYWN7MX17Mn1cbiAgICAgKiA+IHwgJCRcbiAgICAgKiAgICAgXlxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQHR5cGUge1N0YXRlfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGJlZm9yZVNlcXVlbmNlQ2xvc2UoY29kZSkge1xuICAgICAgZWZmZWN0cy5lbnRlcignbWF0aEZsb3dGZW5jZScpXG4gICAgICBlZmZlY3RzLmVudGVyKCdtYXRoRmxvd0ZlbmNlU2VxdWVuY2UnKVxuICAgICAgcmV0dXJuIHNlcXVlbmNlQ2xvc2UoY29kZSlcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJbiBjbG9zaW5nIGZlbmNlIHNlcXVlbmNlLlxuICAgICAqXG4gICAgICogYGBgbWFya2Rvd25cbiAgICAgKiAgIHwgJCRcbiAgICAgKiAgIHwgXFxmcmFjezF9ezJ9XG4gICAgICogPiB8ICQkXG4gICAgICogICAgICBeXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAdHlwZSB7U3RhdGV9XG4gICAgICovXG4gICAgZnVuY3Rpb24gc2VxdWVuY2VDbG9zZShjb2RlKSB7XG4gICAgICBpZiAoY29kZSA9PT0gY29kZXMuZG9sbGFyU2lnbikge1xuICAgICAgICBzaXplKytcbiAgICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICAgIHJldHVybiBzZXF1ZW5jZUNsb3NlXG4gICAgICB9XG5cbiAgICAgIGlmIChzaXplIDwgc2l6ZU9wZW4pIHtcbiAgICAgICAgcmV0dXJuIG5vayhjb2RlKVxuICAgICAgfVxuXG4gICAgICBlZmZlY3RzLmV4aXQoJ21hdGhGbG93RmVuY2VTZXF1ZW5jZScpXG4gICAgICByZXR1cm4gZmFjdG9yeVNwYWNlKGVmZmVjdHMsIGFmdGVyU2VxdWVuY2VDbG9zZSwgdHlwZXMud2hpdGVzcGFjZSkoY29kZSlcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBBZnRlciBjbG9zaW5nIGZlbmNlIHNlcXVlbmNlLCBhZnRlciBvcHRpb25hbCB3aGl0ZXNwYWNlLlxuICAgICAqXG4gICAgICogYGBgbWFya2Rvd25cbiAgICAgKiAgIHwgJCRcbiAgICAgKiAgIHwgXFxmcmFjezF9ezJ9XG4gICAgICogPiB8ICQkXG4gICAgICogICAgICAgXlxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQHR5cGUge1N0YXRlfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGFmdGVyU2VxdWVuY2VDbG9zZShjb2RlKSB7XG4gICAgICBpZiAoY29kZSA9PT0gY29kZXMuZW9mIHx8IG1hcmtkb3duTGluZUVuZGluZyhjb2RlKSkge1xuICAgICAgICBlZmZlY3RzLmV4aXQoJ21hdGhGbG93RmVuY2UnKVxuICAgICAgICByZXR1cm4gb2soY29kZSlcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIG5vayhjb2RlKVxuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIEB0aGlzIHtUb2tlbml6ZUNvbnRleHR9XG4gKiBAdHlwZSB7VG9rZW5pemVyfVxuICovXG5mdW5jdGlvbiB0b2tlbml6ZU5vbkxhenlDb250aW51YXRpb24oZWZmZWN0cywgb2ssIG5vaykge1xuICBjb25zdCBzZWxmID0gdGhpc1xuXG4gIHJldHVybiBzdGFydFxuXG4gIC8qKiBAdHlwZSB7U3RhdGV9ICovXG4gIGZ1bmN0aW9uIHN0YXJ0KGNvZGUpIHtcbiAgICBpZiAoY29kZSA9PT0gbnVsbCkge1xuICAgICAgcmV0dXJuIG9rKGNvZGUpXG4gICAgfVxuXG4gICAgYXNzZXJ0KG1hcmtkb3duTGluZUVuZGluZyhjb2RlKSwgJ2V4cGVjdGVkIGVvbCcpXG4gICAgZWZmZWN0cy5lbnRlcih0eXBlcy5saW5lRW5kaW5nKVxuICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgIGVmZmVjdHMuZXhpdCh0eXBlcy5saW5lRW5kaW5nKVxuICAgIHJldHVybiBsaW5lU3RhcnRcbiAgfVxuXG4gIC8qKiBAdHlwZSB7U3RhdGV9ICovXG4gIGZ1bmN0aW9uIGxpbmVTdGFydChjb2RlKSB7XG4gICAgcmV0dXJuIHNlbGYucGFyc2VyLmxhenlbc2VsZi5ub3coKS5saW5lXSA/IG5vayhjb2RlKSA6IG9rKGNvZGUpXG4gIH1cbn1cbiIsIi8qKlxuICogQGltcG9ydCB7T3B0aW9uc30gZnJvbSAnbWljcm9tYXJrLWV4dGVuc2lvbi1tYXRoJ1xuICogQGltcG9ydCB7Q29uc3RydWN0LCBQcmV2aW91cywgUmVzb2x2ZXIsIFN0YXRlLCBUb2tlbiwgVG9rZW5pemVDb250ZXh0LCBUb2tlbml6ZXJ9IGZyb20gJ21pY3JvbWFyay11dGlsLXR5cGVzJ1xuICovXG5cbi8vIFRvIGRvOiBuZXh0IG1ham9yOiBjbGVhbiBzcGFjZXMgaW4gSFRNTCBjb21waWxlci5cbi8vIFRoaXMgaGFzIHRvIGJlIGNvb3JkaW5hdGVkIHRvZ2V0aGVyIHdpdGggYG1kYXN0LXV0aWwtbWF0aGAuXG5cbmltcG9ydCB7b2sgYXMgYXNzZXJ0fSBmcm9tICdkZXZsb3AnXG5pbXBvcnQge21hcmtkb3duTGluZUVuZGluZ30gZnJvbSAnbWljcm9tYXJrLXV0aWwtY2hhcmFjdGVyJ1xuaW1wb3J0IHtjb2RlcywgdHlwZXN9IGZyb20gJ21pY3JvbWFyay11dGlsLXN5bWJvbCdcblxuLyoqXG4gKiBAcGFyYW0ge09wdGlvbnMgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0aW9ucz17fV1cbiAqICAgQ29uZmlndXJhdGlvbiAoZGVmYXVsdDogYHt9YCkuXG4gKiBAcmV0dXJucyB7Q29uc3RydWN0fVxuICogICBDb25zdHJ1Y3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYXRoVGV4dChvcHRpb25zKSB7XG4gIGNvbnN0IG9wdGlvbnNfID0gb3B0aW9ucyB8fCB7fVxuICBsZXQgc2luZ2xlID0gb3B0aW9uc18uc2luZ2xlRG9sbGFyVGV4dE1hdGhcblxuICBpZiAoc2luZ2xlID09PSBudWxsIHx8IHNpbmdsZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgc2luZ2xlID0gdHJ1ZVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICB0b2tlbml6ZTogdG9rZW5pemVNYXRoVGV4dCxcbiAgICByZXNvbHZlOiByZXNvbHZlTWF0aFRleHQsXG4gICAgcHJldmlvdXMsXG4gICAgbmFtZTogJ21hdGhUZXh0J1xuICB9XG5cbiAgLyoqXG4gICAqIEB0aGlzIHtUb2tlbml6ZUNvbnRleHR9XG4gICAqIEB0eXBlIHtUb2tlbml6ZXJ9XG4gICAqL1xuICBmdW5jdGlvbiB0b2tlbml6ZU1hdGhUZXh0KGVmZmVjdHMsIG9rLCBub2spIHtcbiAgICBjb25zdCBzZWxmID0gdGhpc1xuICAgIGxldCBzaXplT3BlbiA9IDBcbiAgICAvKiogQHR5cGUge251bWJlcn0gKi9cbiAgICBsZXQgc2l6ZVxuICAgIC8qKiBAdHlwZSB7VG9rZW59ICovXG4gICAgbGV0IHRva2VuXG5cbiAgICByZXR1cm4gc3RhcnRcblxuICAgIC8qKlxuICAgICAqIFN0YXJ0IG9mIG1hdGggKHRleHQpLlxuICAgICAqXG4gICAgICogYGBgbWFya2Rvd25cbiAgICAgKiA+IHwgJGEkXG4gICAgICogICAgIF5cbiAgICAgKiA+IHwgXFwkYSRcbiAgICAgKiAgICAgIF5cbiAgICAgKiBgYGBcbiAgICAgKlxuICAgICAqIEB0eXBlIHtTdGF0ZX1cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBzdGFydChjb2RlKSB7XG4gICAgICBhc3NlcnQoY29kZSA9PT0gY29kZXMuZG9sbGFyU2lnbiwgJ2V4cGVjdGVkIGAkYCcpXG4gICAgICBhc3NlcnQocHJldmlvdXMuY2FsbChzZWxmLCBzZWxmLnByZXZpb3VzKSwgJ2V4cGVjdGVkIGNvcnJlY3QgcHJldmlvdXMnKVxuICAgICAgZWZmZWN0cy5lbnRlcignbWF0aFRleHQnKVxuICAgICAgZWZmZWN0cy5lbnRlcignbWF0aFRleHRTZXF1ZW5jZScpXG4gICAgICByZXR1cm4gc2VxdWVuY2VPcGVuKGNvZGUpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW4gb3BlbmluZyBzZXF1ZW5jZS5cbiAgICAgKlxuICAgICAqIGBgYG1hcmtkb3duXG4gICAgICogPiB8ICRhJFxuICAgICAqICAgICBeXG4gICAgICogYGBgXG4gICAgICpcbiAgICAgKiBAdHlwZSB7U3RhdGV9XG4gICAgICovXG5cbiAgICBmdW5jdGlvbiBzZXF1ZW5jZU9wZW4oY29kZSkge1xuICAgICAgaWYgKGNvZGUgPT09IGNvZGVzLmRvbGxhclNpZ24pIHtcbiAgICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICAgIHNpemVPcGVuKytcbiAgICAgICAgcmV0dXJuIHNlcXVlbmNlT3BlblxuICAgICAgfVxuXG4gICAgICAvLyBOb3QgZW5vdWdoIG1hcmtlcnMgaW4gdGhlIHNlcXVlbmNlLlxuICAgICAgaWYgKHNpemVPcGVuIDwgMiAmJiAhc2luZ2xlKSB7XG4gICAgICAgIHJldHVybiBub2soY29kZSlcbiAgICAgIH1cblxuICAgICAgZWZmZWN0cy5leGl0KCdtYXRoVGV4dFNlcXVlbmNlJylcbiAgICAgIHJldHVybiBiZXR3ZWVuKGNvZGUpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQmV0d2VlbiBzb21ldGhpbmcgYW5kIHNvbWV0aGluZyBlbHNlLlxuICAgICAqXG4gICAgICogYGBgbWFya2Rvd25cbiAgICAgKiA+IHwgJGEkXG4gICAgICogICAgICBeXlxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQHR5cGUge1N0YXRlfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGJldHdlZW4oY29kZSkge1xuICAgICAgaWYgKGNvZGUgPT09IGNvZGVzLmVvZikge1xuICAgICAgICByZXR1cm4gbm9rKGNvZGUpXG4gICAgICB9XG5cbiAgICAgIGlmIChjb2RlID09PSBjb2Rlcy5kb2xsYXJTaWduKSB7XG4gICAgICAgIHRva2VuID0gZWZmZWN0cy5lbnRlcignbWF0aFRleHRTZXF1ZW5jZScpXG4gICAgICAgIHNpemUgPSAwXG4gICAgICAgIHJldHVybiBzZXF1ZW5jZUNsb3NlKGNvZGUpXG4gICAgICB9XG5cbiAgICAgIC8vIFRhYnMgZG9u4oCZdCB3b3JrLCBhbmQgdmlydHVhbCBzcGFjZXMgZG9u4oCZdCBtYWtlIHNlbnNlLlxuICAgICAgaWYgKGNvZGUgPT09IGNvZGVzLnNwYWNlKSB7XG4gICAgICAgIGVmZmVjdHMuZW50ZXIoJ3NwYWNlJylcbiAgICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICAgIGVmZmVjdHMuZXhpdCgnc3BhY2UnKVxuICAgICAgICByZXR1cm4gYmV0d2VlblxuICAgICAgfVxuXG4gICAgICBpZiAobWFya2Rvd25MaW5lRW5kaW5nKGNvZGUpKSB7XG4gICAgICAgIGVmZmVjdHMuZW50ZXIodHlwZXMubGluZUVuZGluZylcbiAgICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICAgIGVmZmVjdHMuZXhpdCh0eXBlcy5saW5lRW5kaW5nKVxuICAgICAgICByZXR1cm4gYmV0d2VlblxuICAgICAgfVxuXG4gICAgICAvLyBEYXRhLlxuICAgICAgZWZmZWN0cy5lbnRlcignbWF0aFRleHREYXRhJylcbiAgICAgIHJldHVybiBkYXRhKGNvZGUpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogSW4gZGF0YS5cbiAgICAgKlxuICAgICAqIGBgYG1hcmtkb3duXG4gICAgICogPiB8ICRhJFxuICAgICAqICAgICAgXlxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQHR5cGUge1N0YXRlfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGRhdGEoY29kZSkge1xuICAgICAgaWYgKFxuICAgICAgICBjb2RlID09PSBjb2Rlcy5lb2YgfHxcbiAgICAgICAgY29kZSA9PT0gY29kZXMuc3BhY2UgfHxcbiAgICAgICAgY29kZSA9PT0gY29kZXMuZG9sbGFyU2lnbiB8fFxuICAgICAgICBtYXJrZG93bkxpbmVFbmRpbmcoY29kZSlcbiAgICAgICkge1xuICAgICAgICBlZmZlY3RzLmV4aXQoJ21hdGhUZXh0RGF0YScpXG4gICAgICAgIHJldHVybiBiZXR3ZWVuKGNvZGUpXG4gICAgICB9XG5cbiAgICAgIGVmZmVjdHMuY29uc3VtZShjb2RlKVxuICAgICAgcmV0dXJuIGRhdGFcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBJbiBjbG9zaW5nIHNlcXVlbmNlLlxuICAgICAqXG4gICAgICogYGBgbWFya2Rvd25cbiAgICAgKiA+IHwgYGFgXG4gICAgICogICAgICAgXlxuICAgICAqIGBgYFxuICAgICAqXG4gICAgICogQHR5cGUge1N0YXRlfVxuICAgICAqL1xuXG4gICAgZnVuY3Rpb24gc2VxdWVuY2VDbG9zZShjb2RlKSB7XG4gICAgICAvLyBNb3JlLlxuICAgICAgaWYgKGNvZGUgPT09IGNvZGVzLmRvbGxhclNpZ24pIHtcbiAgICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICAgIHNpemUrK1xuICAgICAgICByZXR1cm4gc2VxdWVuY2VDbG9zZVxuICAgICAgfVxuXG4gICAgICAvLyBEb25lIVxuICAgICAgaWYgKHNpemUgPT09IHNpemVPcGVuKSB7XG4gICAgICAgIGVmZmVjdHMuZXhpdCgnbWF0aFRleHRTZXF1ZW5jZScpXG4gICAgICAgIGVmZmVjdHMuZXhpdCgnbWF0aFRleHQnKVxuICAgICAgICByZXR1cm4gb2soY29kZSlcbiAgICAgIH1cblxuICAgICAgLy8gTW9yZSBvciBsZXNzIGFjY2VudHM6IG1hcmsgYXMgZGF0YS5cbiAgICAgIHRva2VuLnR5cGUgPSAnbWF0aFRleHREYXRhJ1xuICAgICAgcmV0dXJuIGRhdGEoY29kZSlcbiAgICB9XG4gIH1cbn1cblxuLyoqIEB0eXBlIHtSZXNvbHZlcn0gKi9cbmZ1bmN0aW9uIHJlc29sdmVNYXRoVGV4dChldmVudHMpIHtcbiAgbGV0IHRhaWxFeGl0SW5kZXggPSBldmVudHMubGVuZ3RoIC0gNFxuICBsZXQgaGVhZEVudGVySW5kZXggPSAzXG4gIC8qKiBAdHlwZSB7bnVtYmVyfSAqL1xuICBsZXQgaW5kZXhcbiAgLyoqIEB0eXBlIHtudW1iZXIgfCB1bmRlZmluZWR9ICovXG4gIGxldCBlbnRlclxuXG4gIC8vIElmIHdlIHN0YXJ0IGFuZCBlbmQgd2l0aCBhbiBFT0wgb3IgYSBzcGFjZS5cbiAgaWYgKFxuICAgIChldmVudHNbaGVhZEVudGVySW5kZXhdWzFdLnR5cGUgPT09IHR5cGVzLmxpbmVFbmRpbmcgfHxcbiAgICAgIGV2ZW50c1toZWFkRW50ZXJJbmRleF1bMV0udHlwZSA9PT0gJ3NwYWNlJykgJiZcbiAgICAoZXZlbnRzW3RhaWxFeGl0SW5kZXhdWzFdLnR5cGUgPT09IHR5cGVzLmxpbmVFbmRpbmcgfHxcbiAgICAgIGV2ZW50c1t0YWlsRXhpdEluZGV4XVsxXS50eXBlID09PSAnc3BhY2UnKVxuICApIHtcbiAgICBpbmRleCA9IGhlYWRFbnRlckluZGV4XG5cbiAgICAvLyBBbmQgd2UgaGF2ZSBkYXRhLlxuICAgIHdoaWxlICgrK2luZGV4IDwgdGFpbEV4aXRJbmRleCkge1xuICAgICAgaWYgKGV2ZW50c1tpbmRleF1bMV0udHlwZSA9PT0gJ21hdGhUZXh0RGF0YScpIHtcbiAgICAgICAgLy8gVGhlbiB3ZSBoYXZlIHBhZGRpbmcuXG4gICAgICAgIGV2ZW50c1t0YWlsRXhpdEluZGV4XVsxXS50eXBlID0gJ21hdGhUZXh0UGFkZGluZydcbiAgICAgICAgZXZlbnRzW2hlYWRFbnRlckluZGV4XVsxXS50eXBlID0gJ21hdGhUZXh0UGFkZGluZydcbiAgICAgICAgaGVhZEVudGVySW5kZXggKz0gMlxuICAgICAgICB0YWlsRXhpdEluZGV4IC09IDJcbiAgICAgICAgYnJlYWtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBNZXJnZSBhZGphY2VudCBzcGFjZXMgYW5kIGRhdGEuXG4gIGluZGV4ID0gaGVhZEVudGVySW5kZXggLSAxXG4gIHRhaWxFeGl0SW5kZXgrK1xuXG4gIHdoaWxlICgrK2luZGV4IDw9IHRhaWxFeGl0SW5kZXgpIHtcbiAgICBpZiAoZW50ZXIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKFxuICAgICAgICBpbmRleCAhPT0gdGFpbEV4aXRJbmRleCAmJlxuICAgICAgICBldmVudHNbaW5kZXhdWzFdLnR5cGUgIT09IHR5cGVzLmxpbmVFbmRpbmdcbiAgICAgICkge1xuICAgICAgICBlbnRlciA9IGluZGV4XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChcbiAgICAgIGluZGV4ID09PSB0YWlsRXhpdEluZGV4IHx8XG4gICAgICBldmVudHNbaW5kZXhdWzFdLnR5cGUgPT09IHR5cGVzLmxpbmVFbmRpbmdcbiAgICApIHtcbiAgICAgIGV2ZW50c1tlbnRlcl1bMV0udHlwZSA9ICdtYXRoVGV4dERhdGEnXG5cbiAgICAgIGlmIChpbmRleCAhPT0gZW50ZXIgKyAyKSB7XG4gICAgICAgIGV2ZW50c1tlbnRlcl1bMV0uZW5kID0gZXZlbnRzW2luZGV4IC0gMV1bMV0uZW5kXG4gICAgICAgIGV2ZW50cy5zcGxpY2UoZW50ZXIgKyAyLCBpbmRleCAtIGVudGVyIC0gMilcbiAgICAgICAgdGFpbEV4aXRJbmRleCAtPSBpbmRleCAtIGVudGVyIC0gMlxuICAgICAgICBpbmRleCA9IGVudGVyICsgMlxuICAgICAgfVxuXG4gICAgICBlbnRlciA9IHVuZGVmaW5lZFxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBldmVudHNcbn1cblxuLyoqXG4gKiBAdGhpcyB7VG9rZW5pemVDb250ZXh0fVxuICogQHR5cGUge1ByZXZpb3VzfVxuICovXG5mdW5jdGlvbiBwcmV2aW91cyhjb2RlKSB7XG4gIC8vIElmIHRoZXJlIGlzIGEgcHJldmlvdXMgY29kZSwgdGhlcmUgd2lsbCBhbHdheXMgYmUgYSB0YWlsLlxuICByZXR1cm4gKFxuICAgIGNvZGUgIT09IGNvZGVzLmRvbGxhclNpZ24gfHxcbiAgICB0aGlzLmV2ZW50c1t0aGlzLmV2ZW50cy5sZW5ndGggLSAxXVsxXS50eXBlID09PSB0eXBlcy5jaGFyYWN0ZXJFc2NhcGVcbiAgKVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtPcHRpb25zfSBmcm9tICdtaWNyb21hcmstZXh0ZW5zaW9uLW1hdGgnXG4gKiBAaW1wb3J0IHtFeHRlbnNpb259IGZyb20gJ21pY3JvbWFyay11dGlsLXR5cGVzJ1xuICovXG5cbmltcG9ydCB7Y29kZXN9IGZyb20gJ21pY3JvbWFyay11dGlsLXN5bWJvbCdcbmltcG9ydCB7bWF0aEZsb3d9IGZyb20gJy4vbWF0aC1mbG93LmpzJ1xuaW1wb3J0IHttYXRoVGV4dH0gZnJvbSAnLi9tYXRoLXRleHQuanMnXG5cbi8qKlxuICogQ3JlYXRlIGFuIGV4dGVuc2lvbiBmb3IgYG1pY3JvbWFya2AgdG8gZW5hYmxlIG1hdGggc3ludGF4LlxuICpcbiAqIEBwYXJhbSB7T3B0aW9ucyB8IG51bGwgfCB1bmRlZmluZWR9IFtvcHRpb25zPXt9XVxuICogICBDb25maWd1cmF0aW9uIChkZWZhdWx0OiBge31gKS5cbiAqIEByZXR1cm5zIHtFeHRlbnNpb259XG4gKiAgIEV4dGVuc2lvbiBmb3IgYG1pY3JvbWFya2AgdGhhdCBjYW4gYmUgcGFzc2VkIGluIGBleHRlbnNpb25zYCwgdG9cbiAqICAgZW5hYmxlIG1hdGggc3ludGF4LlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWF0aChvcHRpb25zKSB7XG4gIHJldHVybiB7XG4gICAgZmxvdzoge1tjb2Rlcy5kb2xsYXJTaWduXTogbWF0aEZsb3d9LFxuICAgIHRleHQ6IHtbY29kZXMuZG9sbGFyU2lnbl06IG1hdGhUZXh0KG9wdGlvbnMpfVxuICB9XG59XG4iLCIvLy8gPHJlZmVyZW5jZSB0eXBlcz1cIm1kYXN0LXV0aWwtbWF0aFwiIC8+XG4vLy8gPHJlZmVyZW5jZSB0eXBlcz1cInJlbWFyay1wYXJzZVwiIC8+XG4vLy8gPHJlZmVyZW5jZSB0eXBlcz1cInJlbWFyay1zdHJpbmdpZnlcIiAvPlxuXG4vKipcbiAqIEB0eXBlZGVmIHtpbXBvcnQoJ21kYXN0JykuUm9vdH0gUm9vdFxuICogQHR5cGVkZWYge2ltcG9ydCgnbWRhc3QtdXRpbC1tYXRoJykuVG9PcHRpb25zfSBPcHRpb25zXG4gKiBAdHlwZWRlZiB7aW1wb3J0KCd1bmlmaWVkJykuUHJvY2Vzc29yPFJvb3Q+fSBQcm9jZXNzb3JcbiAqL1xuXG5pbXBvcnQge21hdGhGcm9tTWFya2Rvd24sIG1hdGhUb01hcmtkb3dufSBmcm9tICdtZGFzdC11dGlsLW1hdGgnXG5pbXBvcnQge21hdGh9IGZyb20gJ21pY3JvbWFyay1leHRlbnNpb24tbWF0aCdcblxuLyoqIEB0eXBlIHtSZWFkb25seTxPcHRpb25zPn0gKi9cbmNvbnN0IGVtcHR5T3B0aW9ucyA9IHt9XG5cbi8qKlxuICogQWRkIHN1cHBvcnQgZm9yIG1hdGguXG4gKlxuICogQHBhcmFtIHtSZWFkb25seTxPcHRpb25zPiB8IG51bGwgfCB1bmRlZmluZWR9IFtvcHRpb25zXVxuICogICBDb25maWd1cmF0aW9uIChvcHRpb25hbCkuXG4gKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICogICBOb3RoaW5nLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiByZW1hcmtNYXRoKG9wdGlvbnMpIHtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvcjogVFMgaXMgd3JvbmcgYWJvdXQgYHRoaXNgLlxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgdW5pY29ybi9uby10aGlzLWFzc2lnbm1lbnRcbiAgY29uc3Qgc2VsZiA9IC8qKiBAdHlwZSB7UHJvY2Vzc29yfSAqLyAodGhpcylcbiAgY29uc3Qgc2V0dGluZ3MgPSBvcHRpb25zIHx8IGVtcHR5T3B0aW9uc1xuICBjb25zdCBkYXRhID0gc2VsZi5kYXRhKClcblxuICBjb25zdCBtaWNyb21hcmtFeHRlbnNpb25zID1cbiAgICBkYXRhLm1pY3JvbWFya0V4dGVuc2lvbnMgfHwgKGRhdGEubWljcm9tYXJrRXh0ZW5zaW9ucyA9IFtdKVxuICBjb25zdCBmcm9tTWFya2Rvd25FeHRlbnNpb25zID1cbiAgICBkYXRhLmZyb21NYXJrZG93bkV4dGVuc2lvbnMgfHwgKGRhdGEuZnJvbU1hcmtkb3duRXh0ZW5zaW9ucyA9IFtdKVxuICBjb25zdCB0b01hcmtkb3duRXh0ZW5zaW9ucyA9XG4gICAgZGF0YS50b01hcmtkb3duRXh0ZW5zaW9ucyB8fCAoZGF0YS50b01hcmtkb3duRXh0ZW5zaW9ucyA9IFtdKVxuXG4gIG1pY3JvbWFya0V4dGVuc2lvbnMucHVzaChtYXRoKHNldHRpbmdzKSlcbiAgZnJvbU1hcmtkb3duRXh0ZW5zaW9ucy5wdXNoKG1hdGhGcm9tTWFya2Rvd24oKSlcbiAgdG9NYXJrZG93bkV4dGVuc2lvbnMucHVzaChtYXRoVG9NYXJrZG93bihzZXR0aW5ncykpXG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBOEJBLFNBQWdCLG1CQUFtQjtDQUNqQyxPQUFPO0VBQ0wsT0FBTztHQUNMLFVBQVU7R0FDVixtQkFBbUI7R0FDbkIsVUFBVTtFQUNaO0VBQ0EsTUFBTTtHQUNKLFVBQVU7R0FDVixlQUFlO0dBQ2YsbUJBQW1CO0dBQ25CLGVBQWU7R0FDZixVQUFVO0dBQ1YsY0FBYztFQUNoQjtDQUNGOzs7OztDQU1BLFNBQVMsY0FBYyxPQUFPO0VBUTVCLEtBQUssTUFDSDtHQUNFLE1BQU07R0FDTixNQUFNO0dBQ04sT0FBTztHQUNQLE1BQU07SUFBQyxPQUFPO0lBQU8sV0FBVyxDQUFDO0tBVm5DLE1BQU07S0FDTixTQUFTO0tBQ1QsWUFBWSxFQUFDLFdBQVcsQ0FBQyxpQkFBaUIsY0FBYyxFQUFDO0tBQ3pELFVBQVUsQ0FBQztJQU8yQixDQUFDO0dBQUM7RUFDeEMsR0FDQSxLQUNGO0NBQ0Y7Ozs7O0NBTUEsU0FBUyxvQkFBb0I7RUFDM0IsS0FBSyxPQUFPO0NBQ2Q7Ozs7O0NBTUEsU0FBUyxtQkFBbUI7RUFDMUIsTUFBTSxPQUFPLEtBQUssT0FBTztFQUN6QixNQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxTQUFTO0VBQzVDLEdBQU8sS0FBSyxTQUFTLE1BQU07RUFDM0IsS0FBSyxPQUFPO0NBQ2Q7Ozs7O0NBTUEsU0FBUyxvQkFBb0I7RUFFM0IsSUFBSSxLQUFLLEtBQUssZ0JBQWdCO0VBQzlCLEtBQUssT0FBTztFQUNaLEtBQUssS0FBSyxpQkFBaUI7Q0FDN0I7Ozs7O0NBTUEsU0FBUyxhQUFhLE9BQU87RUFDM0IsTUFBTSxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsUUFBUSw0QkFBNEIsRUFBRTtFQUNqRSxNQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssTUFBTSxTQUFTO0VBQzVDLEdBQU8sS0FBSyxTQUFTLE1BQU07RUFDM0IsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLFFBQVE7RUFFYixNQUFNLE9BQW1DLEtBQUssS0FBSyxVQUFVO0VBQzdELEdBQU8sS0FBSyxTQUFTLFNBQVM7RUFDOUIsR0FBTyxLQUFLLFlBQVksTUFBTTtFQUM5QixLQUFLLFNBQVMsS0FBSztHQUFDLE1BQU07R0FBUSxPQUFPO0VBQUksQ0FBQztFQUM5QyxLQUFLLEtBQUssaUJBQWlCLEtBQUE7Q0FDN0I7Ozs7O0NBTUEsU0FBUyxjQUFjLE9BQU87RUFDNUIsS0FBSyxNQUNIO0dBQ0UsTUFBTTtHQUNOLE9BQU87R0FDUCxNQUFNO0lBQ0osT0FBTztJQUNQLGFBQWEsRUFBQyxXQUFXLENBQUMsaUJBQWlCLGFBQWEsRUFBQztJQUN6RCxXQUFXLENBQUM7R0FDZDtFQUNGLEdBQ0EsS0FDRjtFQUNBLEtBQUssT0FBTztDQUNkOzs7OztDQU1BLFNBQVMsYUFBYSxPQUFPO0VBQzNCLE1BQU0sT0FBTyxLQUFLLE9BQU87RUFDekIsTUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUztFQUM1QyxHQUFPLEtBQUssU0FBUyxZQUFZO0VBQ2pDLEtBQUssS0FBSyxLQUFLO0VBQ2YsS0FBSyxRQUFRO0VBS2IsS0FGTyxLQUFLLFVBRUgsS0FBSztHQUFDLE1BQU07R0FBUSxPQUFPO0VBQUksQ0FBQztDQUMzQzs7Ozs7Q0FNQSxTQUFTLGFBQWEsT0FBTztFQUMzQixLQUFLLE9BQU8sTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLO0VBQ3ZDLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxNQUFNLEtBQUs7Q0FDeEM7QUFDRjs7Ozs7Ozs7O0FBVUEsU0FBZ0IsZUFBZSxTQUFTO0NBQ3RDLElBQUksVUFBVSxXQUFXLENBQUMsRUFBQSxDQUFHO0NBRTdCLElBQUksV0FBVyxRQUFRLFdBQVcsS0FBQSxHQUNoQyxTQUFTO0NBR1gsV0FBVyxPQUFPO0NBRWxCLE9BQU87RUFDTCxRQUFRO0dBQ047SUFBQyxXQUFXO0lBQU0sYUFBYTtHQUFjO0dBQzdDO0lBQUMsV0FBVztJQUFNLGFBQWE7R0FBYztHQUM3QztJQUNFLFdBQVc7SUFDWCxPQUFPLFNBQVMsS0FBQSxJQUFZO0lBQzVCLGFBQWE7R0FDZjtHQUNBO0lBQUMsV0FBVztJQUFLLGFBQWE7R0FBYztHQUM1QztJQUFDLFNBQVM7SUFBTSxXQUFXO0lBQUssT0FBTztHQUFLO0VBQzlDO0VBQ0EsVUFBVTtHQUFDO0dBQU07RUFBVTtDQUM3Qjs7Ozs7Q0FRQSxTQUFTLEtBQUssTUFBTSxHQUFHLE9BQU8sTUFBTTtFQUNsQyxNQUFNLE1BQU0sS0FBSyxTQUFTO0VBQzFCLE1BQU0sVUFBVSxNQUFNLGNBQWMsSUFBSTtFQUN4QyxNQUFNLFdBQVcsSUFBSSxPQUFPLEtBQUssSUFBSSxjQUFjLEtBQUssR0FBRyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0VBQ3BFLE1BQU0sT0FBTyxNQUFNLE1BQU0sVUFBVTtFQUNuQyxJQUFJLFFBQVEsUUFBUSxLQUFLLFFBQVE7RUFFakMsSUFBSSxLQUFLLE1BQU07R0FDYixNQUFNLFVBQVUsTUFBTSxNQUFNLGNBQWM7R0FDMUMsU0FBUyxRQUFRLEtBQ2YsTUFBTSxLQUFLLEtBQUssTUFBTTtJQUNwQixPQUFPO0lBQ1AsUUFBUTtJQUNSLFFBQVEsQ0FBQyxHQUFHO0lBQ1osR0FBRyxRQUFRLFFBQVE7R0FDckIsQ0FBQyxDQUNIO0dBQ0EsUUFBUTtFQUNWO0VBRUEsU0FBUyxRQUFRLEtBQUssSUFBSTtFQUUxQixJQUFJLEtBQ0YsU0FBUyxRQUFRLEtBQUssTUFBTSxJQUFJO0VBR2xDLFNBQVMsUUFBUSxLQUFLLFFBQVE7RUFDOUIsS0FBSztFQUNMLE9BQU87Q0FDVDs7Ozs7Q0FRQSxTQUFTLFdBQVcsTUFBTSxHQUFHLE9BQU87RUFDbEMsSUFBSSxRQUFRLEtBQUssU0FBUztFQUMxQixJQUFJLE9BQU87RUFFWCxJQUFJLENBQUMsUUFBUTtFQUtiLE9BQ0UsSUFBSSxPQUFPLGFBQWEsTUFBTSxPQUFPLElBQUksSUFBSSxVQUFVLENBQUMsQ0FBQyxLQUFLLEtBQUssR0FFbkU7RUFHRixNQUFNLFdBQVcsSUFBSSxPQUFPLElBQUk7RUFLaEMsSUFFRSxXQUFXLEtBQUssS0FBSyxNQUVuQixXQUFXLEtBQUssS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLEtBRS9DLFVBQVUsS0FBSyxLQUFLLElBRXRCLFFBQVEsTUFBTSxRQUFRO0VBR3hCLElBQUksUUFBUTtFQVNaLE9BQU8sRUFBRSxRQUFRLE1BQU0sT0FBTyxRQUFRO0dBQ3BDLE1BQU0sVUFBVSxNQUFNLE9BQU87R0FLN0IsSUFBSSxDQUFDLFFBQVEsU0FBUztHQUV0QixNQUFNLGFBQWEsTUFBTSxlQUFlLE9BQU87O0dBRS9DLElBQUk7R0FFSixPQUFRLFFBQVEsV0FBVyxLQUFLLEtBQUssR0FBSTtJQUN2QyxJQUFJLFdBQVcsTUFBTTtJQUdyQixJQUNFLE1BQU0sWUFBWSxRQUFRLE1BQU0sTUFDaEMsTUFBTSxZQUFZLFdBQVcsQ0FBQyxNQUFNLElBRXBDO0lBR0YsUUFBUSxNQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksTUFBTSxNQUFNLE1BQU0sTUFBTSxRQUFRLENBQUM7R0FDdEU7RUFDRjtFQUVBLE9BQU8sV0FBVyxRQUFRO0NBQzVCOzs7O0NBS0EsU0FBUyxpQkFBaUI7RUFDeEIsT0FBTztDQUNUO0FBQ0Y7Ozs7Ozs7QUNsVEEsSUFBYSxXQUFXO0NBQ3RCLFVBQVU7Q0FDVixVQUFVO0NBQ1YsTUFBTTtBQUNSOztBQUdBLElBQU0sc0JBQXNCO0NBQzFCLFVBQVU7Q0FDVixTQUFTO0FBQ1g7Ozs7O0FBTUEsU0FBUyxtQkFBbUIsU0FBUyxNQUFJLEtBQUs7Q0FDNUMsTUFBTSxPQUFPO0NBQ2IsTUFBTSxPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sU0FBUztDQUM5QyxNQUFNLGNBQ0osUUFBUSxLQUFLLEVBQUUsQ0FBQyxTQUFTLE1BQU0sYUFDM0IsS0FBSyxFQUFFLENBQUMsZUFBZSxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsU0FDdEM7Q0FDTixJQUFJLFdBQVc7Q0FFZixPQUFPOzs7Ozs7Ozs7Ozs7O0NBY1AsU0FBUyxNQUFNLE1BQU07RUFDbkIsR0FBTyxTQUFTLE1BQU0sWUFBWSxjQUFjO0VBQ2hELFFBQVEsTUFBTSxVQUFVO0VBQ3hCLFFBQVEsTUFBTSxlQUFlO0VBQzdCLFFBQVEsTUFBTSx1QkFBdUI7RUFDckMsT0FBTyxhQUFhLElBQUk7Q0FDMUI7Ozs7Ozs7Ozs7Ozs7Q0FjQSxTQUFTLGFBQWEsTUFBTTtFQUMxQixJQUFJLFNBQVMsTUFBTSxZQUFZO0dBQzdCLFFBQVEsUUFBUSxJQUFJO0dBQ3BCO0dBQ0EsT0FBTztFQUNUO0VBRUEsSUFBSSxXQUFXLEdBQ2IsT0FBTyxJQUFJLElBQUk7RUFHakIsUUFBUSxLQUFLLHVCQUF1QjtFQUNwQyxPQUFPLGFBQWEsU0FBUyxZQUFZLE1BQU0sVUFBVSxDQUFDLENBQUMsSUFBSTtDQUNqRTs7Ozs7Ozs7Ozs7OztDQWVBLFNBQVMsV0FBVyxNQUFNO0VBQ3hCLElBQUksU0FBUyxNQUFNLE9BQU8sbUJBQW1CLElBQUksR0FDL0MsT0FBTyxVQUFVLElBQUk7RUFHdkIsUUFBUSxNQUFNLG1CQUFtQjtFQUNqQyxRQUFRLE1BQU0sTUFBTSxhQUFhLEVBQUMsYUFBYSxVQUFVLGtCQUFpQixDQUFDO0VBQzNFLE9BQU8sS0FBSyxJQUFJO0NBQ2xCOzs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxLQUFLLE1BQU07RUFDbEIsSUFBSSxTQUFTLE1BQU0sT0FBTyxtQkFBbUIsSUFBSSxHQUFHO0dBQ2xELFFBQVEsS0FBSyxNQUFNLFdBQVc7R0FDOUIsUUFBUSxLQUFLLG1CQUFtQjtHQUNoQyxPQUFPLFVBQVUsSUFBSTtFQUN2QjtFQUVBLElBQUksU0FBUyxNQUFNLFlBQ2pCLE9BQU8sSUFBSSxJQUFJO0VBR2pCLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7OztDQWNBLFNBQVMsVUFBVSxNQUFNO0VBRXZCLFFBQVEsS0FBSyxlQUFlO0VBRTVCLElBQUksS0FBSyxXQUNQLE9BQU9BLEtBQUcsSUFBSTtFQUdoQixPQUFPLFFBQVEsUUFDYixxQkFDQSwyQkFDQSxLQUNGLENBQUMsQ0FBQyxJQUFJO0NBQ1I7Ozs7Ozs7Ozs7Ozs7O0NBZUEsU0FBUywwQkFBMEIsTUFBTTtFQUN2QyxPQUFPLFFBQVEsUUFDYjtHQUFDLFVBQVU7R0FBc0IsU0FBUztFQUFJLEdBQzlDLE9BQ0EsWUFDRixDQUFDLENBQUMsSUFBSTtDQUNSOzs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxhQUFhLE1BQU07RUFDMUIsUUFDRSxjQUNJLGFBQ0UsU0FDQSxvQkFDQSxNQUFNLFlBQ04sY0FBYyxDQUNoQixJQUNBLG1CQUFBLENBQ0osSUFBSTtDQUNSOzs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxtQkFBbUIsTUFBTTtFQUNoQyxJQUFJLFNBQVMsTUFBTSxLQUNqQixPQUFPLE1BQU0sSUFBSTtFQUduQixJQUFJLG1CQUFtQixJQUFJLEdBQ3pCLE9BQU8sUUFBUSxRQUNiLHFCQUNBLDJCQUNBLEtBQ0YsQ0FBQyxDQUFDLElBQUk7RUFHUixRQUFRLE1BQU0sZUFBZTtFQUM3QixPQUFPLGFBQWEsSUFBSTtDQUMxQjs7Ozs7Ozs7Ozs7OztDQWNBLFNBQVMsYUFBYSxNQUFNO0VBQzFCLElBQUksU0FBUyxNQUFNLE9BQU8sbUJBQW1CLElBQUksR0FBRztHQUNsRCxRQUFRLEtBQUssZUFBZTtHQUM1QixPQUFPLG1CQUFtQixJQUFJO0VBQ2hDO0VBRUEsUUFBUSxRQUFRLElBQUk7RUFDcEIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxNQUFNLE1BQU07RUFDbkIsUUFBUSxLQUFLLFVBQVU7RUFDdkIsT0FBT0EsS0FBRyxJQUFJO0NBQ2hCOztDQUdBLFNBQVMscUJBQXFCLFNBQVMsTUFBSSxLQUFLO0VBQzlDLElBQUksT0FBTztFQUVYLEdBQU8sS0FBSyxPQUFPLFdBQVcsUUFBUSxNQUFNLHlCQUF5Qjs7Ozs7Ozs7Ozs7RUFXckUsT0FBTyxhQUNMLFNBQ0EscUJBQ0EsTUFBTSxZQUNOLEtBQUssT0FBTyxXQUFXLFFBQVEsS0FBSyxTQUFTLGNBQWMsSUFDdkQsS0FBQSxJQUNBLFVBQVUsT0FDaEI7Ozs7Ozs7Ozs7Ozs7RUFjQSxTQUFTLG9CQUFvQixNQUFNO0dBQ2pDLFFBQVEsTUFBTSxlQUFlO0dBQzdCLFFBQVEsTUFBTSx1QkFBdUI7R0FDckMsT0FBTyxjQUFjLElBQUk7RUFDM0I7Ozs7Ozs7Ozs7Ozs7RUFjQSxTQUFTLGNBQWMsTUFBTTtHQUMzQixJQUFJLFNBQVMsTUFBTSxZQUFZO0lBQzdCO0lBQ0EsUUFBUSxRQUFRLElBQUk7SUFDcEIsT0FBTztHQUNUO0dBRUEsSUFBSSxPQUFPLFVBQ1QsT0FBTyxJQUFJLElBQUk7R0FHakIsUUFBUSxLQUFLLHVCQUF1QjtHQUNwQyxPQUFPLGFBQWEsU0FBUyxvQkFBb0IsTUFBTSxVQUFVLENBQUMsQ0FBQyxJQUFJO0VBQ3pFOzs7Ozs7Ozs7Ozs7O0VBY0EsU0FBUyxtQkFBbUIsTUFBTTtHQUNoQyxJQUFJLFNBQVMsTUFBTSxPQUFPLG1CQUFtQixJQUFJLEdBQUc7SUFDbEQsUUFBUSxLQUFLLGVBQWU7SUFDNUIsT0FBT0EsS0FBRyxJQUFJO0dBQ2hCO0dBRUEsT0FBTyxJQUFJLElBQUk7RUFDakI7Q0FDRjtBQUNGOzs7OztBQU1BLFNBQVMsNEJBQTRCLFNBQVMsTUFBSSxLQUFLO0NBQ3JELE1BQU0sT0FBTztDQUViLE9BQU87O0NBR1AsU0FBUyxNQUFNLE1BQU07RUFDbkIsSUFBSSxTQUFTLE1BQ1gsT0FBT0EsS0FBRyxJQUFJO0VBR2hCLEdBQU8sbUJBQW1CLElBQUksR0FBRyxjQUFjO0VBQy9DLFFBQVEsTUFBTSxNQUFNLFVBQVU7RUFDOUIsUUFBUSxRQUFRLElBQUk7RUFDcEIsUUFBUSxLQUFLLE1BQU0sVUFBVTtFQUM3QixPQUFPO0NBQ1Q7O0NBR0EsU0FBUyxVQUFVLE1BQU07RUFDdkIsT0FBTyxLQUFLLE9BQU8sS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDLFFBQVEsSUFBSSxJQUFJLElBQUlBLEtBQUcsSUFBSTtDQUNoRTtBQUNGOzs7Ozs7Ozs7Ozs7O0FDdlhBLFNBQWdCLFNBQVMsU0FBUztDQUVoQyxJQUFJLFVBRGEsV0FBVyxDQUFDLEVBQUEsQ0FDUDtDQUV0QixJQUFJLFdBQVcsUUFBUSxXQUFXLEtBQUEsR0FDaEMsU0FBUztDQUdYLE9BQU87RUFDTCxVQUFVO0VBQ1YsU0FBUztFQUNUO0VBQ0EsTUFBTTtDQUNSOzs7OztDQU1BLFNBQVMsaUJBQWlCLFNBQVMsTUFBSSxLQUFLO0VBQzFDLE1BQU0sT0FBTztFQUNiLElBQUksV0FBVzs7RUFFZixJQUFJOztFQUVKLElBQUk7RUFFSixPQUFPOzs7Ozs7Ozs7Ozs7O0VBY1AsU0FBUyxNQUFNLE1BQU07R0FDbkIsR0FBTyxTQUFTLE1BQU0sWUFBWSxjQUFjO0dBQ2hELEdBQU8sU0FBUyxLQUFLLE1BQU0sS0FBSyxRQUFRLEdBQUcsMkJBQTJCO0dBQ3RFLFFBQVEsTUFBTSxVQUFVO0dBQ3hCLFFBQVEsTUFBTSxrQkFBa0I7R0FDaEMsT0FBTyxhQUFhLElBQUk7RUFDMUI7Ozs7Ozs7Ozs7O0VBYUEsU0FBUyxhQUFhLE1BQU07R0FDMUIsSUFBSSxTQUFTLE1BQU0sWUFBWTtJQUM3QixRQUFRLFFBQVEsSUFBSTtJQUNwQjtJQUNBLE9BQU87R0FDVDtHQUdBLElBQUksV0FBVyxLQUFLLENBQUMsUUFDbkIsT0FBTyxJQUFJLElBQUk7R0FHakIsUUFBUSxLQUFLLGtCQUFrQjtHQUMvQixPQUFPLFFBQVEsSUFBSTtFQUNyQjs7Ozs7Ozs7Ozs7RUFZQSxTQUFTLFFBQVEsTUFBTTtHQUNyQixJQUFJLFNBQVMsTUFBTSxLQUNqQixPQUFPLElBQUksSUFBSTtHQUdqQixJQUFJLFNBQVMsTUFBTSxZQUFZO0lBQzdCLFFBQVEsUUFBUSxNQUFNLGtCQUFrQjtJQUN4QyxPQUFPO0lBQ1AsT0FBTyxjQUFjLElBQUk7R0FDM0I7R0FHQSxJQUFJLFNBQVMsTUFBTSxPQUFPO0lBQ3hCLFFBQVEsTUFBTSxPQUFPO0lBQ3JCLFFBQVEsUUFBUSxJQUFJO0lBQ3BCLFFBQVEsS0FBSyxPQUFPO0lBQ3BCLE9BQU87R0FDVDtHQUVBLElBQUksbUJBQW1CLElBQUksR0FBRztJQUM1QixRQUFRLE1BQU0sTUFBTSxVQUFVO0lBQzlCLFFBQVEsUUFBUSxJQUFJO0lBQ3BCLFFBQVEsS0FBSyxNQUFNLFVBQVU7SUFDN0IsT0FBTztHQUNUO0dBR0EsUUFBUSxNQUFNLGNBQWM7R0FDNUIsT0FBTyxLQUFLLElBQUk7RUFDbEI7Ozs7Ozs7Ozs7O0VBWUEsU0FBUyxLQUFLLE1BQU07R0FDbEIsSUFDRSxTQUFTLE1BQU0sT0FDZixTQUFTLE1BQU0sU0FDZixTQUFTLE1BQU0sY0FDZixtQkFBbUIsSUFBSSxHQUN2QjtJQUNBLFFBQVEsS0FBSyxjQUFjO0lBQzNCLE9BQU8sUUFBUSxJQUFJO0dBQ3JCO0dBRUEsUUFBUSxRQUFRLElBQUk7R0FDcEIsT0FBTztFQUNUOzs7Ozs7Ozs7OztFQWFBLFNBQVMsY0FBYyxNQUFNO0dBRTNCLElBQUksU0FBUyxNQUFNLFlBQVk7SUFDN0IsUUFBUSxRQUFRLElBQUk7SUFDcEI7SUFDQSxPQUFPO0dBQ1Q7R0FHQSxJQUFJLFNBQVMsVUFBVTtJQUNyQixRQUFRLEtBQUssa0JBQWtCO0lBQy9CLFFBQVEsS0FBSyxVQUFVO0lBQ3ZCLE9BQU9DLEtBQUcsSUFBSTtHQUNoQjtHQUdBLE1BQU0sT0FBTztHQUNiLE9BQU8sS0FBSyxJQUFJO0VBQ2xCO0NBQ0Y7QUFDRjs7QUFHQSxTQUFTLGdCQUFnQixRQUFRO0NBQy9CLElBQUksZ0JBQWdCLE9BQU8sU0FBUztDQUNwQyxJQUFJLGlCQUFpQjs7Q0FFckIsSUFBSTs7Q0FFSixJQUFJO0NBR0osS0FDRyxPQUFPLGVBQWUsQ0FBQyxFQUFFLENBQUMsU0FBUyxNQUFNLGNBQ3hDLE9BQU8sZUFBZSxDQUFDLEVBQUUsQ0FBQyxTQUFTLGFBQ3BDLE9BQU8sY0FBYyxDQUFDLEVBQUUsQ0FBQyxTQUFTLE1BQU0sY0FDdkMsT0FBTyxjQUFjLENBQUMsRUFBRSxDQUFDLFNBQVMsVUFDcEM7RUFDQSxRQUFRO0VBR1IsT0FBTyxFQUFFLFFBQVEsZUFDZixJQUFJLE9BQU8sTUFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLGdCQUFnQjtHQUU1QyxPQUFPLGNBQWMsQ0FBQyxFQUFFLENBQUMsT0FBTztHQUNoQyxPQUFPLGVBQWUsQ0FBQyxFQUFFLENBQUMsT0FBTztHQUNqQyxrQkFBa0I7R0FDbEIsaUJBQWlCO0dBQ2pCO0VBQ0Y7Q0FFSjtDQUdBLFFBQVEsaUJBQWlCO0NBQ3pCO0NBRUEsT0FBTyxFQUFFLFNBQVMsZUFDaEIsSUFBSSxVQUFVLEtBQUEsR0FFVjtNQUFBLFVBQVUsaUJBQ1YsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDLFNBQVMsTUFBTSxZQUVoQyxRQUFRO0NBQUEsT0FFTCxJQUNMLFVBQVUsaUJBQ1YsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDLFNBQVMsTUFBTSxZQUNoQztFQUNBLE9BQU8sTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPO0VBRXhCLElBQUksVUFBVSxRQUFRLEdBQUc7R0FDdkIsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sT0FBTyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUM7R0FDNUMsT0FBTyxPQUFPLFFBQVEsR0FBRyxRQUFRLFFBQVEsQ0FBQztHQUMxQyxpQkFBaUIsUUFBUSxRQUFRO0dBQ2pDLFFBQVEsUUFBUTtFQUNsQjtFQUVBLFFBQVEsS0FBQTtDQUNWO0NBR0YsT0FBTztBQUNUOzs7OztBQU1BLFNBQVMsU0FBUyxNQUFNO0NBRXRCLE9BQ0UsU0FBUyxNQUFNLGNBQ2YsS0FBSyxPQUFPLEtBQUssT0FBTyxTQUFTLEVBQUUsQ0FBQyxFQUFFLENBQUMsU0FBUyxNQUFNO0FBRTFEOzs7Ozs7Ozs7Ozs7Ozs7O0FDeFBBLFNBQWdCLEtBQUssU0FBUztDQUM1QixPQUFPO0VBQ0wsTUFBTSxHQUFFLE1BQU0sYUFBYSxTQUFRO0VBQ25DLE1BQU0sR0FBRSxNQUFNLGFBQWEsU0FBUyxPQUFPLEVBQUM7Q0FDOUM7QUFDRjs7Ozs7Ozs7O0FDVEEsSUFBTSxlQUFlLENBQUM7Ozs7Ozs7OztBQVV0QixTQUF3QixXQUFXLFNBQVM7Q0FHMUMsTUFBTSxPQUFpQztDQUN2QyxNQUFNLFdBQVcsV0FBVztDQUM1QixNQUFNLE9BQU8sS0FBSyxLQUFLO0NBRXZCLE1BQU0sc0JBQ0osS0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsQ0FBQztDQUMzRCxNQUFNLHlCQUNKLEtBQUssMkJBQTJCLEtBQUsseUJBQXlCLENBQUM7Q0FDakUsTUFBTSx1QkFDSixLQUFLLHlCQUF5QixLQUFLLHVCQUF1QixDQUFDO0NBRTdELG9CQUFvQixLQUFLLEtBQUssUUFBUSxDQUFDO0NBQ3ZDLHVCQUF1QixLQUFLLGlCQUFpQixDQUFDO0NBQzlDLHFCQUFxQixLQUFLLGVBQWUsUUFBUSxDQUFDO0FBQ3BEIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNF19