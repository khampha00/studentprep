//#region node_modules/devlop/lib/development.js
var AssertionError = class extends Error {
	name = "Assertion";
	code = "ERR_ASSERTION";
	/**
	* Create an assertion error.
	*
	* @param {string} message
	*   Message explaining error.
	* @param {unknown} actual
	*   Value.
	* @param {unknown} expected
	*   Baseline.
	* @param {string} operator
	*   Name of equality operation.
	* @param {boolean} generated
	*   Whether `message` is a custom message or not
	* @returns
	*   Instance.
	*/
	constructor(message, actual, expected, operator, generated) {
		super(message);
		if (Error.captureStackTrace) Error.captureStackTrace(this, this.constructor);
		/**
		* @type {unknown}
		*/
		this.actual = actual;
		/**
		* @type {unknown}
		*/
		this.expected = expected;
		/**
		* @type {boolean}
		*/
		this.generated = generated;
		/**
		* @type {string}
		*/
		this.operator = operator;
	}
};
/**
* Assert if `value` is truthy.
*
* > 👉 **Important**: only asserts when the `development` condition is used,
* > does nothing in production.
*
* @param {unknown} value
*   Value to assert.
* @param {Error | string | null | undefined} [message]
*   Message for assertion error (default: `'Expected value to be truthy'`).
* @returns {asserts value}
*   Nothing; throws when `value` is falsey.
* @throws {AssertionError}
*   Throws when `value` is falsey.
*/
function ok(value, message) {
	assert(Boolean(value), false, true, "ok", "Expected value to be truthy", message);
}
/**
* Assert that a code path never happens.
*
* > 👉 **Important**: only asserts when the `development` condition is used,
* > does nothing in production.
*
* @param {Error | string | null | undefined} [message]
*   Message for assertion error (default: `'Unreachable'`).
* @returns {never}
*   Nothing; always throws.
* @throws {AssertionError}
*   Throws when `value` is falsey.
*/
function unreachable(message) {
	assert(false, false, true, "ok", "Unreachable", message);
}
/**
* @param {boolean} bool
*   Whether to skip this operation.
* @param {unknown} actual
*   Actual value.
* @param {unknown} expected
*   Expected value.
* @param {string} operator
*   Operator.
* @param {string} defaultMessage
*   Default message for operation.
* @param {Error | string | null | undefined} userMessage
*   User-provided message.
* @returns {asserts bool}
*   Nothing; throws when falsey.
*/
function assert(bool, actual, expected, operator, defaultMessage, userMessage) {
	if (!bool) throw userMessage instanceof Error ? userMessage : new AssertionError(userMessage || defaultMessage, actual, expected, operator, !userMessage);
}
//#endregion
//#region node_modules/micromark-util-symbol/lib/codes.js
/**
* Character codes.
*
* This module is compiled away!
*
* micromark works based on character codes.
* This module contains constants for the ASCII block and the replacement
* character.
* A couple of them are handled in a special way, such as the line endings
* (CR, LF, and CR+LF, commonly known as end-of-line: EOLs), the tab (horizontal
* tab) and its expansion based on what column it’s at (virtual space),
* and the end-of-file (eof) character.
* As values are preprocessed before handling them, the actual characters LF,
* CR, HT, and NUL (which is present as the replacement character), are
* guaranteed to not exist.
*
* Unicode basic latin block.
*/
var codes = {
	carriageReturn: -5,
	lineFeed: -4,
	carriageReturnLineFeed: -3,
	horizontalTab: -2,
	virtualSpace: -1,
	eof: null,
	nul: 0,
	soh: 1,
	stx: 2,
	etx: 3,
	eot: 4,
	enq: 5,
	ack: 6,
	bel: 7,
	bs: 8,
	ht: 9,
	lf: 10,
	vt: 11,
	ff: 12,
	cr: 13,
	so: 14,
	si: 15,
	dle: 16,
	dc1: 17,
	dc2: 18,
	dc3: 19,
	dc4: 20,
	nak: 21,
	syn: 22,
	etb: 23,
	can: 24,
	em: 25,
	sub: 26,
	esc: 27,
	fs: 28,
	gs: 29,
	rs: 30,
	us: 31,
	space: 32,
	exclamationMark: 33,
	quotationMark: 34,
	numberSign: 35,
	dollarSign: 36,
	percentSign: 37,
	ampersand: 38,
	apostrophe: 39,
	leftParenthesis: 40,
	rightParenthesis: 41,
	asterisk: 42,
	plusSign: 43,
	comma: 44,
	dash: 45,
	dot: 46,
	slash: 47,
	digit0: 48,
	digit1: 49,
	digit2: 50,
	digit3: 51,
	digit4: 52,
	digit5: 53,
	digit6: 54,
	digit7: 55,
	digit8: 56,
	digit9: 57,
	colon: 58,
	semicolon: 59,
	lessThan: 60,
	equalsTo: 61,
	greaterThan: 62,
	questionMark: 63,
	atSign: 64,
	uppercaseA: 65,
	uppercaseB: 66,
	uppercaseC: 67,
	uppercaseD: 68,
	uppercaseE: 69,
	uppercaseF: 70,
	uppercaseG: 71,
	uppercaseH: 72,
	uppercaseI: 73,
	uppercaseJ: 74,
	uppercaseK: 75,
	uppercaseL: 76,
	uppercaseM: 77,
	uppercaseN: 78,
	uppercaseO: 79,
	uppercaseP: 80,
	uppercaseQ: 81,
	uppercaseR: 82,
	uppercaseS: 83,
	uppercaseT: 84,
	uppercaseU: 85,
	uppercaseV: 86,
	uppercaseW: 87,
	uppercaseX: 88,
	uppercaseY: 89,
	uppercaseZ: 90,
	leftSquareBracket: 91,
	backslash: 92,
	rightSquareBracket: 93,
	caret: 94,
	underscore: 95,
	graveAccent: 96,
	lowercaseA: 97,
	lowercaseB: 98,
	lowercaseC: 99,
	lowercaseD: 100,
	lowercaseE: 101,
	lowercaseF: 102,
	lowercaseG: 103,
	lowercaseH: 104,
	lowercaseI: 105,
	lowercaseJ: 106,
	lowercaseK: 107,
	lowercaseL: 108,
	lowercaseM: 109,
	lowercaseN: 110,
	lowercaseO: 111,
	lowercaseP: 112,
	lowercaseQ: 113,
	lowercaseR: 114,
	lowercaseS: 115,
	lowercaseT: 116,
	lowercaseU: 117,
	lowercaseV: 118,
	lowercaseW: 119,
	lowercaseX: 120,
	lowercaseY: 121,
	lowercaseZ: 122,
	leftCurlyBrace: 123,
	verticalBar: 124,
	rightCurlyBrace: 125,
	tilde: 126,
	del: 127,
	byteOrderMarker: 65279,
	replacementCharacter: 65533
};
//#endregion
//#region node_modules/micromark-util-symbol/lib/constants.js
/**
* This module is compiled away!
*
* Parsing markdown comes with a couple of constants, such as minimum or maximum
* sizes of certain sequences.
* Additionally, there are a couple symbols used inside micromark.
* These are all defined here, but compiled away by scripts.
*/
var constants = {
	attentionSideAfter: 2,
	attentionSideBefore: 1,
	atxHeadingOpeningFenceSizeMax: 6,
	autolinkDomainSizeMax: 63,
	autolinkSchemeSizeMax: 32,
	cdataOpeningString: "CDATA[",
	characterGroupPunctuation: 2,
	characterGroupWhitespace: 1,
	characterReferenceDecimalSizeMax: 7,
	characterReferenceHexadecimalSizeMax: 6,
	characterReferenceNamedSizeMax: 31,
	codeFencedSequenceSizeMin: 3,
	contentTypeContent: "content",
	contentTypeDocument: "document",
	contentTypeFlow: "flow",
	contentTypeString: "string",
	contentTypeText: "text",
	hardBreakPrefixSizeMin: 2,
	htmlBasic: 6,
	htmlCdata: 5,
	htmlComment: 2,
	htmlComplete: 7,
	htmlDeclaration: 4,
	htmlInstruction: 3,
	htmlRawSizeMax: 8,
	htmlRaw: 1,
	linkResourceDestinationBalanceMax: 32,
	linkReferenceSizeMax: 999,
	listItemValueSizeMax: 10,
	numericBaseDecimal: 10,
	numericBaseHexadecimal: 16,
	tabSize: 4,
	thematicBreakMarkerCountMin: 3,
	v8MaxSafeChunkSize: 1e4
};
//#endregion
//#region node_modules/micromark-util-symbol/lib/types.js
/**
* This module is compiled away!
*
* Here is the list of all types of tokens exposed by micromark, with a short
* explanation of what they include and where they are found.
* In picking names, generally, the rule is to be as explicit as possible
* instead of reusing names.
* For example, there is a `definitionDestination` and a `resourceDestination`,
* instead of one shared name.
*/
var types = {
	data: "data",
	whitespace: "whitespace",
	lineEnding: "lineEnding",
	lineEndingBlank: "lineEndingBlank",
	linePrefix: "linePrefix",
	lineSuffix: "lineSuffix",
	atxHeading: "atxHeading",
	atxHeadingSequence: "atxHeadingSequence",
	atxHeadingText: "atxHeadingText",
	autolink: "autolink",
	autolinkEmail: "autolinkEmail",
	autolinkMarker: "autolinkMarker",
	autolinkProtocol: "autolinkProtocol",
	characterEscape: "characterEscape",
	characterEscapeValue: "characterEscapeValue",
	characterReference: "characterReference",
	characterReferenceMarker: "characterReferenceMarker",
	characterReferenceMarkerNumeric: "characterReferenceMarkerNumeric",
	characterReferenceMarkerHexadecimal: "characterReferenceMarkerHexadecimal",
	characterReferenceValue: "characterReferenceValue",
	codeFenced: "codeFenced",
	codeFencedFence: "codeFencedFence",
	codeFencedFenceSequence: "codeFencedFenceSequence",
	codeFencedFenceInfo: "codeFencedFenceInfo",
	codeFencedFenceMeta: "codeFencedFenceMeta",
	codeFlowValue: "codeFlowValue",
	codeIndented: "codeIndented",
	codeText: "codeText",
	codeTextData: "codeTextData",
	codeTextPadding: "codeTextPadding",
	codeTextSequence: "codeTextSequence",
	content: "content",
	definition: "definition",
	definitionDestination: "definitionDestination",
	definitionDestinationLiteral: "definitionDestinationLiteral",
	definitionDestinationLiteralMarker: "definitionDestinationLiteralMarker",
	definitionDestinationRaw: "definitionDestinationRaw",
	definitionDestinationString: "definitionDestinationString",
	definitionLabel: "definitionLabel",
	definitionLabelMarker: "definitionLabelMarker",
	definitionLabelString: "definitionLabelString",
	definitionMarker: "definitionMarker",
	definitionTitle: "definitionTitle",
	definitionTitleMarker: "definitionTitleMarker",
	definitionTitleString: "definitionTitleString",
	emphasis: "emphasis",
	emphasisSequence: "emphasisSequence",
	emphasisText: "emphasisText",
	escapeMarker: "escapeMarker",
	hardBreakEscape: "hardBreakEscape",
	hardBreakTrailing: "hardBreakTrailing",
	htmlFlow: "htmlFlow",
	htmlFlowData: "htmlFlowData",
	htmlText: "htmlText",
	htmlTextData: "htmlTextData",
	image: "image",
	label: "label",
	labelText: "labelText",
	labelLink: "labelLink",
	labelImage: "labelImage",
	labelMarker: "labelMarker",
	labelImageMarker: "labelImageMarker",
	labelEnd: "labelEnd",
	link: "link",
	paragraph: "paragraph",
	reference: "reference",
	referenceMarker: "referenceMarker",
	referenceString: "referenceString",
	resource: "resource",
	resourceDestination: "resourceDestination",
	resourceDestinationLiteral: "resourceDestinationLiteral",
	resourceDestinationLiteralMarker: "resourceDestinationLiteralMarker",
	resourceDestinationRaw: "resourceDestinationRaw",
	resourceDestinationString: "resourceDestinationString",
	resourceMarker: "resourceMarker",
	resourceTitle: "resourceTitle",
	resourceTitleMarker: "resourceTitleMarker",
	resourceTitleString: "resourceTitleString",
	setextHeading: "setextHeading",
	setextHeadingText: "setextHeadingText",
	setextHeadingLine: "setextHeadingLine",
	setextHeadingLineSequence: "setextHeadingLineSequence",
	strong: "strong",
	strongSequence: "strongSequence",
	strongText: "strongText",
	thematicBreak: "thematicBreak",
	thematicBreakSequence: "thematicBreakSequence",
	blockQuote: "blockQuote",
	blockQuotePrefix: "blockQuotePrefix",
	blockQuoteMarker: "blockQuoteMarker",
	blockQuotePrefixWhitespace: "blockQuotePrefixWhitespace",
	listOrdered: "listOrdered",
	listUnordered: "listUnordered",
	listItemIndent: "listItemIndent",
	listItemMarker: "listItemMarker",
	listItemPrefix: "listItemPrefix",
	listItemPrefixWhitespace: "listItemPrefixWhitespace",
	listItemValue: "listItemValue",
	chunkDocument: "chunkDocument",
	chunkContent: "chunkContent",
	chunkFlow: "chunkFlow",
	chunkText: "chunkText",
	chunkString: "chunkString"
};
//#endregion
//#region node_modules/micromark-util-character/dev/index.js
/**
* @import {Code} from 'micromark-util-types'
*/
/**
* Check whether the character code represents an ASCII alpha (`a` through `z`,
* case insensitive).
*
* An **ASCII alpha** is an ASCII upper alpha or ASCII lower alpha.
*
* An **ASCII upper alpha** is a character in the inclusive range U+0041 (`A`)
* to U+005A (`Z`).
*
* An **ASCII lower alpha** is a character in the inclusive range U+0061 (`a`)
* to U+007A (`z`).
*
* @param code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
var asciiAlpha = regexCheck(/[A-Za-z]/);
/**
* Check whether the character code represents an ASCII alphanumeric (`a`
* through `z`, case insensitive, or `0` through `9`).
*
* An **ASCII alphanumeric** is an ASCII digit (see `asciiDigit`) or ASCII alpha
* (see `asciiAlpha`).
*
* @param code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
var asciiAlphanumeric = regexCheck(/[\dA-Za-z]/);
/**
* Check whether the character code represents an ASCII atext.
*
* atext is an ASCII alphanumeric (see `asciiAlphanumeric`), or a character in
* the inclusive ranges U+0023 NUMBER SIGN (`#`) to U+0027 APOSTROPHE (`'`),
* U+002A ASTERISK (`*`), U+002B PLUS SIGN (`+`), U+002D DASH (`-`), U+002F
* SLASH (`/`), U+003D EQUALS TO (`=`), U+003F QUESTION MARK (`?`), U+005E
* CARET (`^`) to U+0060 GRAVE ACCENT (`` ` ``), or U+007B LEFT CURLY BRACE
* (`{`) to U+007E TILDE (`~`).
*
* See:
* **\[RFC5322]**:
* [Internet Message Format](https://tools.ietf.org/html/rfc5322).
* P. Resnick.
* IETF.
*
* @param code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
var asciiAtext = regexCheck(/[#-'*+\--9=?A-Z^-~]/);
/**
* Check whether a character code is an ASCII control character.
*
* An **ASCII control** is a character in the inclusive range U+0000 NULL (NUL)
* to U+001F (US), or U+007F (DEL).
*
* @param {Code} code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
function asciiControl(code) {
	return code !== null && (code < codes.space || code === codes.del);
}
/**
* Check whether the character code represents an ASCII digit (`0` through `9`).
*
* An **ASCII digit** is a character in the inclusive range U+0030 (`0`) to
* U+0039 (`9`).
*
* @param code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
var asciiDigit = regexCheck(/\d/);
/**
* Check whether the character code represents an ASCII hex digit (`a` through
* `f`, case insensitive, or `0` through `9`).
*
* An **ASCII hex digit** is an ASCII digit (see `asciiDigit`), ASCII upper hex
* digit, or an ASCII lower hex digit.
*
* An **ASCII upper hex digit** is a character in the inclusive range U+0041
* (`A`) to U+0046 (`F`).
*
* An **ASCII lower hex digit** is a character in the inclusive range U+0061
* (`a`) to U+0066 (`f`).
*
* @param code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
var asciiHexDigit = regexCheck(/[\dA-Fa-f]/);
/**
* Check whether the character code represents ASCII punctuation.
*
* An **ASCII punctuation** is a character in the inclusive ranges U+0021
* EXCLAMATION MARK (`!`) to U+002F SLASH (`/`), U+003A COLON (`:`) to U+0040 AT
* SIGN (`@`), U+005B LEFT SQUARE BRACKET (`[`) to U+0060 GRAVE ACCENT
* (`` ` ``), or U+007B LEFT CURLY BRACE (`{`) to U+007E TILDE (`~`).
*
* @param code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
var asciiPunctuation = regexCheck(/[!-/:-@[-`{-~]/);
/**
* Check whether a character code is a markdown line ending.
*
* A **markdown line ending** is the virtual characters M-0003 CARRIAGE RETURN
* LINE FEED (CRLF), M-0004 LINE FEED (LF) and M-0005 CARRIAGE RETURN (CR).
*
* In micromark, the actual character U+000A LINE FEED (LF) and U+000D CARRIAGE
* RETURN (CR) are replaced by these virtual characters depending on whether
* they occurred together.
*
* @param {Code} code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
function markdownLineEnding(code) {
	return code !== null && code < codes.horizontalTab;
}
/**
* Check whether a character code is a markdown line ending (see
* `markdownLineEnding`) or markdown space (see `markdownSpace`).
*
* @param {Code} code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
function markdownLineEndingOrSpace(code) {
	return code !== null && (code < codes.nul || code === codes.space);
}
/**
* Check whether a character code is a markdown space.
*
* A **markdown space** is the concrete character U+0020 SPACE (SP) and the
* virtual characters M-0001 VIRTUAL SPACE (VS) and M-0002 HORIZONTAL TAB (HT).
*
* In micromark, the actual character U+0009 CHARACTER TABULATION (HT) is
* replaced by one M-0002 HORIZONTAL TAB (HT) and between 0 and 3 M-0001 VIRTUAL
* SPACE (VS) characters, depending on the column at which the tab occurred.
*
* @param {Code} code
*   Code.
* @returns {boolean}
*   Whether it matches.
*/
function markdownSpace(code) {
	return code === codes.horizontalTab || code === codes.virtualSpace || code === codes.space;
}
/**
* Check whether the character code represents Unicode punctuation.
*
* A **Unicode punctuation** is a character in the Unicode `Pc` (Punctuation,
* Connector), `Pd` (Punctuation, Dash), `Pe` (Punctuation, Close), `Pf`
* (Punctuation, Final quote), `Pi` (Punctuation, Initial quote), `Po`
* (Punctuation, Other), or `Ps` (Punctuation, Open) categories, or an ASCII
* punctuation (see `asciiPunctuation`).
*
* See:
* **\[UNICODE]**:
* [The Unicode Standard](https://www.unicode.org/versions/).
* Unicode Consortium.
*
* @param code
*   Code.
* @returns
*   Whether it matches.
*/
var unicodePunctuation = regexCheck(/\p{P}|\p{S}/u);
/**
* Check whether the character code represents Unicode whitespace.
*
* Note that this does handle micromark specific markdown whitespace characters.
* See `markdownLineEndingOrSpace` to check that.
*
* A **Unicode whitespace** is a character in the Unicode `Zs` (Separator,
* Space) category, or U+0009 CHARACTER TABULATION (HT), U+000A LINE FEED (LF),
* U+000C (FF), or U+000D CARRIAGE RETURN (CR) (**\[UNICODE]**).
*
* See:
* **\[UNICODE]**:
* [The Unicode Standard](https://www.unicode.org/versions/).
* Unicode Consortium.
*
* @param code
*   Code.
* @returns
*   Whether it matches.
*/
var unicodeWhitespace = regexCheck(/\s/);
/**
* Create a code check from a regex.
*
* @param {RegExp} regex
*   Expression.
* @returns {(code: Code) => boolean}
*   Check.
*/
function regexCheck(regex) {
	return check;
	/**
	* Check whether a code matches the bound regex.
	*
	* @param {Code} code
	*   Character code.
	* @returns {boolean}
	*   Whether the character code matches the bound regex.
	*/
	function check(code) {
		return code !== null && code > -1 && regex.test(String.fromCharCode(code));
	}
}
//#endregion
//#region node_modules/micromark-factory-space/dev/index.js
/**
* @import {Effects, State, TokenType} from 'micromark-util-types'
*/
/**
* Parse spaces and tabs.
*
* There is no `nok` parameter:
*
* *   spaces in markdown are often optional, in which case this factory can be
*     used and `ok` will be switched to whether spaces were found or not
* *   one line ending or space can be detected with `markdownSpace(code)` right
*     before using `factorySpace`
*
* ###### Examples
*
* Where `␉` represents a tab (plus how much it expands) and `␠` represents a
* single space.
*
* ```markdown
* ␉
* ␠␠␠␠
* ␉␠
* ```
*
* @param {Effects} effects
*   Context.
* @param {State} ok
*   State switched to when successful.
* @param {TokenType} type
*   Type (`' \t'`).
* @param {number | undefined} [max=Infinity]
*   Max (exclusive).
* @returns {State}
*   Start state.
*/
function factorySpace(effects, ok, type, max) {
	const limit = max ? max - 1 : Number.POSITIVE_INFINITY;
	let size = 0;
	return start;
	/** @type {State} */
	function start(code) {
		if (markdownSpace(code)) {
			effects.enter(type);
			return prefix(code);
		}
		return ok(code);
	}
	/** @type {State} */
	function prefix(code) {
		if (markdownSpace(code) && size++ < limit) {
			effects.consume(code);
			return prefix;
		}
		effects.exit(type);
		return ok(code);
	}
}
//#endregion
export { ok as _, asciiControl as a, asciiPunctuation as c, markdownSpace as d, unicodePunctuation as f, codes as g, constants as h, asciiAtext as i, markdownLineEnding as l, types as m, asciiAlpha as n, asciiDigit as o, unicodeWhitespace as p, asciiAlphanumeric as r, asciiHexDigit as s, factorySpace as t, markdownLineEndingOrSpace as u, unreachable as v };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGV2LUNidVVKV0dELmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL2RldmxvcC9saWIvZGV2ZWxvcG1lbnQuanMiLCIuLi8uLi9taWNyb21hcmstdXRpbC1zeW1ib2wvbGliL2NvZGVzLmpzIiwiLi4vLi4vbWljcm9tYXJrLXV0aWwtc3ltYm9sL2xpYi9jb25zdGFudHMuanMiLCIuLi8uLi9taWNyb21hcmstdXRpbC1zeW1ib2wvbGliL3R5cGVzLmpzIiwiLi4vLi4vbWljcm9tYXJrLXV0aWwtY2hhcmFjdGVyL2Rldi9pbmRleC5qcyIsIi4uLy4uL21pY3JvbWFyay1mYWN0b3J5LXNwYWNlL2Rldi9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2RlcXVhbH0gZnJvbSAnZGVxdWFsJ1xuXG4vKipcbiAqIEB0eXBlIHtTZXQ8c3RyaW5nPn1cbiAqL1xuY29uc3QgY29kZXNXYXJuZWQgPSBuZXcgU2V0KClcblxuY2xhc3MgQXNzZXJ0aW9uRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIG5hbWUgPSAvKiogQHR5cGUge2NvbnN0fSAqLyAoJ0Fzc2VydGlvbicpXG4gIGNvZGUgPSAvKiogQHR5cGUge2NvbnN0fSAqLyAoJ0VSUl9BU1NFUlRJT04nKVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYW4gYXNzZXJ0aW9uIGVycm9yLlxuICAgKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gbWVzc2FnZVxuICAgKiAgIE1lc3NhZ2UgZXhwbGFpbmluZyBlcnJvci5cbiAgICogQHBhcmFtIHt1bmtub3dufSBhY3R1YWxcbiAgICogICBWYWx1ZS5cbiAgICogQHBhcmFtIHt1bmtub3dufSBleHBlY3RlZFxuICAgKiAgIEJhc2VsaW5lLlxuICAgKiBAcGFyYW0ge3N0cmluZ30gb3BlcmF0b3JcbiAgICogICBOYW1lIG9mIGVxdWFsaXR5IG9wZXJhdGlvbi5cbiAgICogQHBhcmFtIHtib29sZWFufSBnZW5lcmF0ZWRcbiAgICogICBXaGV0aGVyIGBtZXNzYWdlYCBpcyBhIGN1c3RvbSBtZXNzYWdlIG9yIG5vdFxuICAgKiBAcmV0dXJuc1xuICAgKiAgIEluc3RhbmNlLlxuICAgKi9cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG1heC1wYXJhbXNcbiAgY29uc3RydWN0b3IobWVzc2FnZSwgYWN0dWFsLCBleHBlY3RlZCwgb3BlcmF0b3IsIGdlbmVyYXRlZCkge1xuICAgIHN1cGVyKG1lc3NhZ2UpXG5cbiAgICBpZiAoRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UpIHtcbiAgICAgIEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKHRoaXMsIHRoaXMuY29uc3RydWN0b3IpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQHR5cGUge3Vua25vd259XG4gICAgICovXG4gICAgdGhpcy5hY3R1YWwgPSBhY3R1YWxcblxuICAgIC8qKlxuICAgICAqIEB0eXBlIHt1bmtub3dufVxuICAgICAqL1xuICAgIHRoaXMuZXhwZWN0ZWQgPSBleHBlY3RlZFxuXG4gICAgLyoqXG4gICAgICogQHR5cGUge2Jvb2xlYW59XG4gICAgICovXG4gICAgdGhpcy5nZW5lcmF0ZWQgPSBnZW5lcmF0ZWRcblxuICAgIC8qKlxuICAgICAqIEB0eXBlIHtzdHJpbmd9XG4gICAgICovXG4gICAgdGhpcy5vcGVyYXRvciA9IG9wZXJhdG9yXG4gIH1cbn1cblxuY2xhc3MgRGVwcmVjYXRpb25FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgbmFtZSA9IC8qKiBAdHlwZSB7Y29uc3R9ICovICgnRGVwcmVjYXRpb25XYXJuaW5nJylcblxuICAvKipcbiAgICogQ3JlYXRlIGEgZGVwcmVjYXRpb24gbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmd9IG1lc3NhZ2VcbiAgICogICBNZXNzYWdlIGV4cGxhaW5pbmcgZGVwcmVjYXRpb24uXG4gICAqIEBwYXJhbSB7c3RyaW5nIHwgdW5kZWZpbmVkfSBjb2RlXG4gICAqICAgRGVwcmVjYXRpb24gaWRlbnRpZmllcjsgZGVwcmVjYXRpb24gbWVzc2FnZXMgd2lsbCBiZSBnZW5lcmF0ZWQgb25seSBvbmNlIHBlciBjb2RlLlxuICAgKiBAcmV0dXJuc1xuICAgKiAgIEluc3RhbmNlLlxuICAgKi9cbiAgY29uc3RydWN0b3IobWVzc2FnZSwgY29kZSkge1xuICAgIHN1cGVyKG1lc3NhZ2UpXG5cbiAgICAvKipcbiAgICAgKiBAdHlwZSB7c3RyaW5nIHwgdW5kZWZpbmVkfVxuICAgICAqL1xuICAgIHRoaXMuY29kZSA9IGNvZGVcbiAgfVxufVxuXG4vKipcbiAqIFdyYXAgYSBmdW5jdGlvbiBvciBjbGFzcyB0byBzaG93IGEgZGVwcmVjYXRpb24gbWVzc2FnZSB3aGVuIGZpcnN0IGNhbGxlZC5cbiAqXG4gKiA+IPCfkYkgKipJbXBvcnRhbnQqKjogb25seSBzaG93cyBhIG1lc3NhZ2Ugd2hlbiB0aGUgYGRldmVsb3BtZW50YCBjb25kaXRpb24gaXNcbiAqID4gdXNlZCwgZG9lcyBub3RoaW5nIGluIHByb2R1Y3Rpb24uXG4gKlxuICogV2hlbiB0aGUgcmVzdWx0aW5nIHdyYXBwZWQgYGZuYCBpcyBjYWxsZWQsIGVtaXRzIGEgd2FybmluZyBvbmNlIHRvXG4gKiBgY29uc29sZS5lcnJvcmAgKGBzdGRlcnJgKS5cbiAqIElmIGEgY29kZSBpcyBnaXZlbiwgb25lIHdhcm5pbmcgbWVzc2FnZSB3aWxsIGJlIGVtaXR0ZWQgaW4gdG90YWwgcGVyIGNvZGUuXG4gKlxuICogQHRlbXBsYXRlIHtGdW5jdGlvbn0gVFxuICogICBGdW5jdGlvbiBvciBjbGFzcyBraW5kLlxuICogQHBhcmFtIHtUfSBmblxuICogICBGdW5jdGlvbiBvciBjbGFzcy5cbiAqIEBwYXJhbSB7c3RyaW5nfSBtZXNzYWdlXG4gKiAgIE1lc3NhZ2UgZXhwbGFpbmluZyBkZXByZWNhdGlvbi5cbiAqIEBwYXJhbSB7c3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gW2NvZGVdXG4gKiAgIERlcHJlY2F0aW9uIGlkZW50aWZpZXIgKG9wdGlvbmFsKTsgZGVwcmVjYXRpb24gbWVzc2FnZXMgd2lsbCBiZSBnZW5lcmF0ZWRcbiAqICAgb25seSBvbmNlIHBlciBjb2RlLlxuICogQHJldHVybnMge1R9XG4gKiAgIFdyYXBwZWQgYGZuYC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlcHJlY2F0ZShmbiwgbWVzc2FnZSwgY29kZSkge1xuICBsZXQgd2FybmVkID0gZmFsc2VcblxuICAvLyBUaGUgd3JhcHBlciB3aWxsIGtlZXAgdGhlIHNhbWUgcHJvdG90eXBlIGFzIGZuIHRvIG1haW50YWluIHByb3RvdHlwZSBjaGFpblxuICBPYmplY3Quc2V0UHJvdG90eXBlT2YoZGVwcmVjYXRlZCwgZm4pXG5cbiAgLy8gQHRzLWV4cGVjdC1lcnJvcjogaXTigJlzIHBlcmZlY3QsIHR5cGVzY3JpcHTigKZcbiAgcmV0dXJuIGRlcHJlY2F0ZWRcblxuICAvKipcbiAgICogQHRoaXMge3Vua25vd259XG4gICAqIEBwYXJhbSAgey4uLkFycmF5PHVua25vd24+fSBhcmdzXG4gICAqIEByZXR1cm5zIHt1bmtub3dufVxuICAgKi9cbiAgZnVuY3Rpb24gZGVwcmVjYXRlZCguLi5hcmdzKSB7XG4gICAgaWYgKCF3YXJuZWQpIHtcbiAgICAgIHdhcm5lZCA9IHRydWVcblxuICAgICAgaWYgKHR5cGVvZiBjb2RlID09PSAnc3RyaW5nJyAmJiBjb2Rlc1dhcm5lZC5oYXMoY29kZSkpIHtcbiAgICAgICAgLy8gRW1wdHkuXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmVycm9yKG5ldyBEZXByZWNhdGlvbkVycm9yKG1lc3NhZ2UsIGNvZGUgfHwgdW5kZWZpbmVkKSlcblxuICAgICAgICBpZiAodHlwZW9mIGNvZGUgPT09ICdzdHJpbmcnKSBjb2Rlc1dhcm5lZC5hZGQoY29kZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbmV3LnRhcmdldFxuICAgICAgPyBSZWZsZWN0LmNvbnN0cnVjdChmbiwgYXJncywgbmV3LnRhcmdldClcbiAgICAgIDogUmVmbGVjdC5hcHBseShmbiwgdGhpcywgYXJncylcbiAgfVxufVxuXG4vKipcbiAqIEFzc2VydCBkZWVwIHN0cmljdCBlcXVpdmFsZW5jZS5cbiAqXG4gKiA+IPCfkYkgKipJbXBvcnRhbnQqKjogb25seSBhc3NlcnRzIHdoZW4gdGhlIGBkZXZlbG9wbWVudGAgY29uZGl0aW9uIGlzIHVzZWQsXG4gKiA+IGRvZXMgbm90aGluZyBpbiBwcm9kdWN0aW9uLlxuICpcbiAqIEB0ZW1wbGF0ZSB7dW5rbm93bn0gVFxuICogICBFeHBlY3RlZCBraW5kLlxuICogQHBhcmFtIHt1bmtub3dufSBhY3R1YWxcbiAqICAgVmFsdWUuXG4gKiBAcGFyYW0ge1R9IGV4cGVjdGVkXG4gKiAgIEJhc2VsaW5lLlxuICogQHBhcmFtIHtFcnJvciB8IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWR9IFttZXNzYWdlXVxuICogICBNZXNzYWdlIGZvciBhc3NlcnRpb24gZXJyb3IgKGRlZmF1bHQ6IGAnRXhwZWN0ZWQgdmFsdWVzIHRvIGJlIGRlZXBseSBlcXVhbCdgKS5cbiAqIEByZXR1cm5zIHthc3NlcnRzIGFjdHVhbCBpcyBUfVxuICogICBOb3RoaW5nOyB0aHJvd3Mgd2hlbiBgYWN0dWFsYCBpcyBub3QgZGVlcCBzdHJpY3QgZXF1YWwgdG8gYGV4cGVjdGVkYC5cbiAqIEB0aHJvd3Mge0Fzc2VydGlvbkVycm9yfVxuICogICBUaHJvd3Mgd2hlbiBgYWN0dWFsYCBpcyBub3QgZGVlcCBzdHJpY3QgZXF1YWwgdG8gYGV4cGVjdGVkYC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVxdWFsKGFjdHVhbCwgZXhwZWN0ZWQsIG1lc3NhZ2UpIHtcbiAgYXNzZXJ0KFxuICAgIGRlcXVhbChhY3R1YWwsIGV4cGVjdGVkKSxcbiAgICBhY3R1YWwsXG4gICAgZXhwZWN0ZWQsXG4gICAgJ2VxdWFsJyxcbiAgICAnRXhwZWN0ZWQgdmFsdWVzIHRvIGJlIGRlZXBseSBlcXVhbCcsXG4gICAgbWVzc2FnZVxuICApXG59XG5cbi8qKlxuICogQXNzZXJ0IGlmIGB2YWx1ZWAgaXMgdHJ1dGh5LlxuICpcbiAqID4g8J+RiSAqKkltcG9ydGFudCoqOiBvbmx5IGFzc2VydHMgd2hlbiB0aGUgYGRldmVsb3BtZW50YCBjb25kaXRpb24gaXMgdXNlZCxcbiAqID4gZG9lcyBub3RoaW5nIGluIHByb2R1Y3Rpb24uXG4gKlxuICogQHBhcmFtIHt1bmtub3dufSB2YWx1ZVxuICogICBWYWx1ZSB0byBhc3NlcnQuXG4gKiBAcGFyYW0ge0Vycm9yIHwgc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gW21lc3NhZ2VdXG4gKiAgIE1lc3NhZ2UgZm9yIGFzc2VydGlvbiBlcnJvciAoZGVmYXVsdDogYCdFeHBlY3RlZCB2YWx1ZSB0byBiZSB0cnV0aHknYCkuXG4gKiBAcmV0dXJucyB7YXNzZXJ0cyB2YWx1ZX1cbiAqICAgTm90aGluZzsgdGhyb3dzIHdoZW4gYHZhbHVlYCBpcyBmYWxzZXkuXG4gKiBAdGhyb3dzIHtBc3NlcnRpb25FcnJvcn1cbiAqICAgVGhyb3dzIHdoZW4gYHZhbHVlYCBpcyBmYWxzZXkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBvayh2YWx1ZSwgbWVzc2FnZSkge1xuICBhc3NlcnQoXG4gICAgQm9vbGVhbih2YWx1ZSksXG4gICAgZmFsc2UsXG4gICAgdHJ1ZSxcbiAgICAnb2snLFxuICAgICdFeHBlY3RlZCB2YWx1ZSB0byBiZSB0cnV0aHknLFxuICAgIG1lc3NhZ2VcbiAgKVxufVxuXG4vKipcbiAqIEFzc2VydCB0aGF0IGEgY29kZSBwYXRoIG5ldmVyIGhhcHBlbnMuXG4gKlxuICogPiDwn5GJICoqSW1wb3J0YW50Kio6IG9ubHkgYXNzZXJ0cyB3aGVuIHRoZSBgZGV2ZWxvcG1lbnRgIGNvbmRpdGlvbiBpcyB1c2VkLFxuICogPiBkb2VzIG5vdGhpbmcgaW4gcHJvZHVjdGlvbi5cbiAqXG4gKiBAcGFyYW0ge0Vycm9yIHwgc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZH0gW21lc3NhZ2VdXG4gKiAgIE1lc3NhZ2UgZm9yIGFzc2VydGlvbiBlcnJvciAoZGVmYXVsdDogYCdVbnJlYWNoYWJsZSdgKS5cbiAqIEByZXR1cm5zIHtuZXZlcn1cbiAqICAgTm90aGluZzsgYWx3YXlzIHRocm93cy5cbiAqIEB0aHJvd3Mge0Fzc2VydGlvbkVycm9yfVxuICogICBUaHJvd3Mgd2hlbiBgdmFsdWVgIGlzIGZhbHNleS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVucmVhY2hhYmxlKG1lc3NhZ2UpIHtcbiAgYXNzZXJ0KGZhbHNlLCBmYWxzZSwgdHJ1ZSwgJ29rJywgJ1VucmVhY2hhYmxlJywgbWVzc2FnZSlcbn1cblxuLyoqXG4gKiBAcGFyYW0ge2Jvb2xlYW59IGJvb2xcbiAqICAgV2hldGhlciB0byBza2lwIHRoaXMgb3BlcmF0aW9uLlxuICogQHBhcmFtIHt1bmtub3dufSBhY3R1YWxcbiAqICAgQWN0dWFsIHZhbHVlLlxuICogQHBhcmFtIHt1bmtub3dufSBleHBlY3RlZFxuICogICBFeHBlY3RlZCB2YWx1ZS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBvcGVyYXRvclxuICogICBPcGVyYXRvci5cbiAqIEBwYXJhbSB7c3RyaW5nfSBkZWZhdWx0TWVzc2FnZVxuICogICBEZWZhdWx0IG1lc3NhZ2UgZm9yIG9wZXJhdGlvbi5cbiAqIEBwYXJhbSB7RXJyb3IgfCBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkfSB1c2VyTWVzc2FnZVxuICogICBVc2VyLXByb3ZpZGVkIG1lc3NhZ2UuXG4gKiBAcmV0dXJucyB7YXNzZXJ0cyBib29sfVxuICogICBOb3RoaW5nOyB0aHJvd3Mgd2hlbiBmYWxzZXkuXG4gKi9cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBtYXgtcGFyYW1zXG5mdW5jdGlvbiBhc3NlcnQoYm9vbCwgYWN0dWFsLCBleHBlY3RlZCwgb3BlcmF0b3IsIGRlZmF1bHRNZXNzYWdlLCB1c2VyTWVzc2FnZSkge1xuICBpZiAoIWJvb2wpIHtcbiAgICB0aHJvdyB1c2VyTWVzc2FnZSBpbnN0YW5jZW9mIEVycm9yXG4gICAgICA/IHVzZXJNZXNzYWdlXG4gICAgICA6IG5ldyBBc3NlcnRpb25FcnJvcihcbiAgICAgICAgICB1c2VyTWVzc2FnZSB8fCBkZWZhdWx0TWVzc2FnZSxcbiAgICAgICAgICBhY3R1YWwsXG4gICAgICAgICAgZXhwZWN0ZWQsXG4gICAgICAgICAgb3BlcmF0b3IsXG4gICAgICAgICAgIXVzZXJNZXNzYWdlXG4gICAgICAgIClcbiAgfVxufVxuIiwiLyoqXG4gKiBDaGFyYWN0ZXIgY29kZXMuXG4gKlxuICogVGhpcyBtb2R1bGUgaXMgY29tcGlsZWQgYXdheSFcbiAqXG4gKiBtaWNyb21hcmsgd29ya3MgYmFzZWQgb24gY2hhcmFjdGVyIGNvZGVzLlxuICogVGhpcyBtb2R1bGUgY29udGFpbnMgY29uc3RhbnRzIGZvciB0aGUgQVNDSUkgYmxvY2sgYW5kIHRoZSByZXBsYWNlbWVudFxuICogY2hhcmFjdGVyLlxuICogQSBjb3VwbGUgb2YgdGhlbSBhcmUgaGFuZGxlZCBpbiBhIHNwZWNpYWwgd2F5LCBzdWNoIGFzIHRoZSBsaW5lIGVuZGluZ3NcbiAqIChDUiwgTEYsIGFuZCBDUitMRiwgY29tbW9ubHkga25vd24gYXMgZW5kLW9mLWxpbmU6IEVPTHMpLCB0aGUgdGFiIChob3Jpem9udGFsXG4gKiB0YWIpIGFuZCBpdHMgZXhwYW5zaW9uIGJhc2VkIG9uIHdoYXQgY29sdW1uIGl04oCZcyBhdCAodmlydHVhbCBzcGFjZSksXG4gKiBhbmQgdGhlIGVuZC1vZi1maWxlIChlb2YpIGNoYXJhY3Rlci5cbiAqIEFzIHZhbHVlcyBhcmUgcHJlcHJvY2Vzc2VkIGJlZm9yZSBoYW5kbGluZyB0aGVtLCB0aGUgYWN0dWFsIGNoYXJhY3RlcnMgTEYsXG4gKiBDUiwgSFQsIGFuZCBOVUwgKHdoaWNoIGlzIHByZXNlbnQgYXMgdGhlIHJlcGxhY2VtZW50IGNoYXJhY3RlciksIGFyZVxuICogZ3VhcmFudGVlZCB0byBub3QgZXhpc3QuXG4gKlxuICogVW5pY29kZSBiYXNpYyBsYXRpbiBibG9jay5cbiAqL1xuZXhwb3J0IGNvbnN0IGNvZGVzID0gLyoqIEB0eXBlIHtjb25zdH0gKi8gKHtcbiAgY2FycmlhZ2VSZXR1cm46IC01LFxuICBsaW5lRmVlZDogLTQsXG4gIGNhcnJpYWdlUmV0dXJuTGluZUZlZWQ6IC0zLFxuICBob3Jpem9udGFsVGFiOiAtMixcbiAgdmlydHVhbFNwYWNlOiAtMSxcbiAgZW9mOiBudWxsLFxuICBudWw6IDAsXG4gIHNvaDogMSxcbiAgc3R4OiAyLFxuICBldHg6IDMsXG4gIGVvdDogNCxcbiAgZW5xOiA1LFxuICBhY2s6IDYsXG4gIGJlbDogNyxcbiAgYnM6IDgsXG4gIGh0OiA5LCAvLyBgXFx0YFxuICBsZjogMTAsIC8vIGBcXG5gXG4gIHZ0OiAxMSwgLy8gYFxcdmBcbiAgZmY6IDEyLCAvLyBgXFxmYFxuICBjcjogMTMsIC8vIGBcXHJgXG4gIHNvOiAxNCxcbiAgc2k6IDE1LFxuICBkbGU6IDE2LFxuICBkYzE6IDE3LFxuICBkYzI6IDE4LFxuICBkYzM6IDE5LFxuICBkYzQ6IDIwLFxuICBuYWs6IDIxLFxuICBzeW46IDIyLFxuICBldGI6IDIzLFxuICBjYW46IDI0LFxuICBlbTogMjUsXG4gIHN1YjogMjYsXG4gIGVzYzogMjcsXG4gIGZzOiAyOCxcbiAgZ3M6IDI5LFxuICByczogMzAsXG4gIHVzOiAzMSxcbiAgc3BhY2U6IDMyLFxuICBleGNsYW1hdGlvbk1hcms6IDMzLCAvLyBgIWBcbiAgcXVvdGF0aW9uTWFyazogMzQsIC8vIGBcImBcbiAgbnVtYmVyU2lnbjogMzUsIC8vIGAjYFxuICBkb2xsYXJTaWduOiAzNiwgLy8gYCRgXG4gIHBlcmNlbnRTaWduOiAzNywgLy8gYCVgXG4gIGFtcGVyc2FuZDogMzgsIC8vIGAmYFxuICBhcG9zdHJvcGhlOiAzOSwgLy8gYCdgXG4gIGxlZnRQYXJlbnRoZXNpczogNDAsIC8vIGAoYFxuICByaWdodFBhcmVudGhlc2lzOiA0MSwgLy8gYClgXG4gIGFzdGVyaXNrOiA0MiwgLy8gYCpgXG4gIHBsdXNTaWduOiA0MywgLy8gYCtgXG4gIGNvbW1hOiA0NCwgLy8gYCxgXG4gIGRhc2g6IDQ1LCAvLyBgLWBcbiAgZG90OiA0NiwgLy8gYC5gXG4gIHNsYXNoOiA0NywgLy8gYC9gXG4gIGRpZ2l0MDogNDgsIC8vIGAwYFxuICBkaWdpdDE6IDQ5LCAvLyBgMWBcbiAgZGlnaXQyOiA1MCwgLy8gYDJgXG4gIGRpZ2l0MzogNTEsIC8vIGAzYFxuICBkaWdpdDQ6IDUyLCAvLyBgNGBcbiAgZGlnaXQ1OiA1MywgLy8gYDVgXG4gIGRpZ2l0NjogNTQsIC8vIGA2YFxuICBkaWdpdDc6IDU1LCAvLyBgN2BcbiAgZGlnaXQ4OiA1NiwgLy8gYDhgXG4gIGRpZ2l0OTogNTcsIC8vIGA5YFxuICBjb2xvbjogNTgsIC8vIGA6YFxuICBzZW1pY29sb246IDU5LCAvLyBgO2BcbiAgbGVzc1RoYW46IDYwLCAvLyBgPGBcbiAgZXF1YWxzVG86IDYxLCAvLyBgPWBcbiAgZ3JlYXRlclRoYW46IDYyLCAvLyBgPmBcbiAgcXVlc3Rpb25NYXJrOiA2MywgLy8gYD9gXG4gIGF0U2lnbjogNjQsIC8vIGBAYFxuICB1cHBlcmNhc2VBOiA2NSwgLy8gYEFgXG4gIHVwcGVyY2FzZUI6IDY2LCAvLyBgQmBcbiAgdXBwZXJjYXNlQzogNjcsIC8vIGBDYFxuICB1cHBlcmNhc2VEOiA2OCwgLy8gYERgXG4gIHVwcGVyY2FzZUU6IDY5LCAvLyBgRWBcbiAgdXBwZXJjYXNlRjogNzAsIC8vIGBGYFxuICB1cHBlcmNhc2VHOiA3MSwgLy8gYEdgXG4gIHVwcGVyY2FzZUg6IDcyLCAvLyBgSGBcbiAgdXBwZXJjYXNlSTogNzMsIC8vIGBJYFxuICB1cHBlcmNhc2VKOiA3NCwgLy8gYEpgXG4gIHVwcGVyY2FzZUs6IDc1LCAvLyBgS2BcbiAgdXBwZXJjYXNlTDogNzYsIC8vIGBMYFxuICB1cHBlcmNhc2VNOiA3NywgLy8gYE1gXG4gIHVwcGVyY2FzZU46IDc4LCAvLyBgTmBcbiAgdXBwZXJjYXNlTzogNzksIC8vIGBPYFxuICB1cHBlcmNhc2VQOiA4MCwgLy8gYFBgXG4gIHVwcGVyY2FzZVE6IDgxLCAvLyBgUWBcbiAgdXBwZXJjYXNlUjogODIsIC8vIGBSYFxuICB1cHBlcmNhc2VTOiA4MywgLy8gYFNgXG4gIHVwcGVyY2FzZVQ6IDg0LCAvLyBgVGBcbiAgdXBwZXJjYXNlVTogODUsIC8vIGBVYFxuICB1cHBlcmNhc2VWOiA4NiwgLy8gYFZgXG4gIHVwcGVyY2FzZVc6IDg3LCAvLyBgV2BcbiAgdXBwZXJjYXNlWDogODgsIC8vIGBYYFxuICB1cHBlcmNhc2VZOiA4OSwgLy8gYFlgXG4gIHVwcGVyY2FzZVo6IDkwLCAvLyBgWmBcbiAgbGVmdFNxdWFyZUJyYWNrZXQ6IDkxLCAvLyBgW2BcbiAgYmFja3NsYXNoOiA5MiwgLy8gYFxcYFxuICByaWdodFNxdWFyZUJyYWNrZXQ6IDkzLCAvLyBgXWBcbiAgY2FyZXQ6IDk0LCAvLyBgXmBcbiAgdW5kZXJzY29yZTogOTUsIC8vIGBfYFxuICBncmF2ZUFjY2VudDogOTYsIC8vIGBgIGAgYGBcbiAgbG93ZXJjYXNlQTogOTcsIC8vIGBhYFxuICBsb3dlcmNhc2VCOiA5OCwgLy8gYGJgXG4gIGxvd2VyY2FzZUM6IDk5LCAvLyBgY2BcbiAgbG93ZXJjYXNlRDogMTAwLCAvLyBgZGBcbiAgbG93ZXJjYXNlRTogMTAxLCAvLyBgZWBcbiAgbG93ZXJjYXNlRjogMTAyLCAvLyBgZmBcbiAgbG93ZXJjYXNlRzogMTAzLCAvLyBgZ2BcbiAgbG93ZXJjYXNlSDogMTA0LCAvLyBgaGBcbiAgbG93ZXJjYXNlSTogMTA1LCAvLyBgaWBcbiAgbG93ZXJjYXNlSjogMTA2LCAvLyBgamBcbiAgbG93ZXJjYXNlSzogMTA3LCAvLyBga2BcbiAgbG93ZXJjYXNlTDogMTA4LCAvLyBgbGBcbiAgbG93ZXJjYXNlTTogMTA5LCAvLyBgbWBcbiAgbG93ZXJjYXNlTjogMTEwLCAvLyBgbmBcbiAgbG93ZXJjYXNlTzogMTExLCAvLyBgb2BcbiAgbG93ZXJjYXNlUDogMTEyLCAvLyBgcGBcbiAgbG93ZXJjYXNlUTogMTEzLCAvLyBgcWBcbiAgbG93ZXJjYXNlUjogMTE0LCAvLyBgcmBcbiAgbG93ZXJjYXNlUzogMTE1LCAvLyBgc2BcbiAgbG93ZXJjYXNlVDogMTE2LCAvLyBgdGBcbiAgbG93ZXJjYXNlVTogMTE3LCAvLyBgdWBcbiAgbG93ZXJjYXNlVjogMTE4LCAvLyBgdmBcbiAgbG93ZXJjYXNlVzogMTE5LCAvLyBgd2BcbiAgbG93ZXJjYXNlWDogMTIwLCAvLyBgeGBcbiAgbG93ZXJjYXNlWTogMTIxLCAvLyBgeWBcbiAgbG93ZXJjYXNlWjogMTIyLCAvLyBgemBcbiAgbGVmdEN1cmx5QnJhY2U6IDEyMywgLy8gYHtgXG4gIHZlcnRpY2FsQmFyOiAxMjQsIC8vIGB8YFxuICByaWdodEN1cmx5QnJhY2U6IDEyNSwgLy8gYH1gXG4gIHRpbGRlOiAxMjYsIC8vIGB+YFxuICBkZWw6IDEyNyxcbiAgLy8gVW5pY29kZSBTcGVjaWFscyBibG9jay5cbiAgYnl0ZU9yZGVyTWFya2VyOiA2NV8yNzksXG4gIC8vIFVuaWNvZGUgU3BlY2lhbHMgYmxvY2suXG4gIHJlcGxhY2VtZW50Q2hhcmFjdGVyOiA2NV81MzMgLy8gYO+/vWBcbn0pXG4iLCIvKipcbiAqIFRoaXMgbW9kdWxlIGlzIGNvbXBpbGVkIGF3YXkhXG4gKlxuICogUGFyc2luZyBtYXJrZG93biBjb21lcyB3aXRoIGEgY291cGxlIG9mIGNvbnN0YW50cywgc3VjaCBhcyBtaW5pbXVtIG9yIG1heGltdW1cbiAqIHNpemVzIG9mIGNlcnRhaW4gc2VxdWVuY2VzLlxuICogQWRkaXRpb25hbGx5LCB0aGVyZSBhcmUgYSBjb3VwbGUgc3ltYm9scyB1c2VkIGluc2lkZSBtaWNyb21hcmsuXG4gKiBUaGVzZSBhcmUgYWxsIGRlZmluZWQgaGVyZSwgYnV0IGNvbXBpbGVkIGF3YXkgYnkgc2NyaXB0cy5cbiAqL1xuZXhwb3J0IGNvbnN0IGNvbnN0YW50cyA9IC8qKiBAdHlwZSB7Y29uc3R9ICovICh7XG4gIGF0dGVudGlvblNpZGVBZnRlcjogMiwgLy8gU3ltYm9sIHRvIG1hcmsgYW4gYXR0ZW50aW9uIHNlcXVlbmNlIGFzIGFmdGVyIGNvbnRlbnQ6IGBhKmBcbiAgYXR0ZW50aW9uU2lkZUJlZm9yZTogMSwgLy8gU3ltYm9sIHRvIG1hcmsgYW4gYXR0ZW50aW9uIHNlcXVlbmNlIGFzIGJlZm9yZSBjb250ZW50OiBgKmFgXG4gIGF0eEhlYWRpbmdPcGVuaW5nRmVuY2VTaXplTWF4OiA2LCAvLyA2IG51bWJlciBzaWducyBpcyBmaW5lLCA3IGlzbuKAmXQuXG4gIGF1dG9saW5rRG9tYWluU2l6ZU1heDogNjMsIC8vIDYzIGNoYXJhY3RlcnMgaXMgZmluZSwgNjQgaXMgdG9vIG1hbnkuXG4gIGF1dG9saW5rU2NoZW1lU2l6ZU1heDogMzIsIC8vIDMyIGNoYXJhY3RlcnMgaXMgZmluZSwgMzMgaXMgdG9vIG1hbnkuXG4gIGNkYXRhT3BlbmluZ1N0cmluZzogJ0NEQVRBWycsIC8vIEFuZCBwcmVjZWRlZCBieSBgPCFbYC5cbiAgY2hhcmFjdGVyR3JvdXBQdW5jdHVhdGlvbjogMiwgLy8gU3ltYm9sIHVzZWQgdG8gaW5kaWNhdGUgYSBjaGFyYWN0ZXIgaXMgcHVuY3R1YXRpb25cbiAgY2hhcmFjdGVyR3JvdXBXaGl0ZXNwYWNlOiAxLCAvLyBTeW1ib2wgdXNlZCB0byBpbmRpY2F0ZSBhIGNoYXJhY3RlciBpcyB3aGl0ZXNwYWNlXG4gIGNoYXJhY3RlclJlZmVyZW5jZURlY2ltYWxTaXplTWF4OiA3LCAvLyBgJiM5OTk5OTk5O2AuXG4gIGNoYXJhY3RlclJlZmVyZW5jZUhleGFkZWNpbWFsU2l6ZU1heDogNiwgLy8gYCYjeGZmOTk5OTtgLlxuICBjaGFyYWN0ZXJSZWZlcmVuY2VOYW1lZFNpemVNYXg6IDMxLCAvLyBgJkNvdW50ZXJDbG9ja3dpc2VDb250b3VySW50ZWdyYWw7YC5cbiAgY29kZUZlbmNlZFNlcXVlbmNlU2l6ZU1pbjogMywgLy8gQXQgbGVhc3QgMyB0aWNrcyBvciB0aWxkZXMgYXJlIG5lZWRlZC5cbiAgY29udGVudFR5cGVDb250ZW50OiAnY29udGVudCcsXG4gIGNvbnRlbnRUeXBlRG9jdW1lbnQ6ICdkb2N1bWVudCcsXG4gIGNvbnRlbnRUeXBlRmxvdzogJ2Zsb3cnLFxuICBjb250ZW50VHlwZVN0cmluZzogJ3N0cmluZycsXG4gIGNvbnRlbnRUeXBlVGV4dDogJ3RleHQnLFxuICBoYXJkQnJlYWtQcmVmaXhTaXplTWluOiAyLCAvLyBBdCBsZWFzdCAyIHRyYWlsaW5nIHNwYWNlcyBhcmUgbmVlZGVkLlxuICBodG1sQmFzaWM6IDYsIC8vIFN5bWJvbCBmb3IgYDxkaXZgXG4gIGh0bWxDZGF0YTogNSwgLy8gU3ltYm9sIGZvciBgPCFbQ0RBVEFbXV0+YFxuICBodG1sQ29tbWVudDogMiwgLy8gU3ltYm9sIGZvciBgPCEtLS0tPmBcbiAgaHRtbENvbXBsZXRlOiA3LCAvLyBTeW1ib2wgZm9yIGA8eD5gXG4gIGh0bWxEZWNsYXJhdGlvbjogNCwgLy8gU3ltYm9sIGZvciBgPCFkb2N0eXBlPmBcbiAgaHRtbEluc3RydWN0aW9uOiAzLCAvLyBTeW1ib2wgZm9yIGA8P3BocD8+YFxuICBodG1sUmF3U2l6ZU1heDogOCwgLy8gTGVuZ3RoIG9mIGB0ZXh0YXJlYWAuXG4gIGh0bWxSYXc6IDEsIC8vIFN5bWJvbCBmb3IgYDxzY3JpcHQ+YFxuICBsaW5rUmVzb3VyY2VEZXN0aW5hdGlvbkJhbGFuY2VNYXg6IDMyLCAvLyBTZWU6IDxodHRwczovL3NwZWMuY29tbW9ubWFyay5vcmcvMC4zMC8jbGluay1kZXN0aW5hdGlvbj4sIDxodHRwczovL2dpdGh1Yi5jb20vcmVtYXJranMvcmVhY3QtbWFya2Rvd24vaXNzdWVzLzY1OCNpc3N1ZWNvbW1lbnQtOTg0MzQ1NTc3PlxuICBsaW5rUmVmZXJlbmNlU2l6ZU1heDogOTk5LCAvLyBTZWU6IDxodHRwczovL3NwZWMuY29tbW9ubWFyay5vcmcvMC4zMC8jbGluay1sYWJlbD5cbiAgbGlzdEl0ZW1WYWx1ZVNpemVNYXg6IDEwLCAvLyBTZWU6IDxodHRwczovL3NwZWMuY29tbW9ubWFyay5vcmcvMC4zMC8jb3JkZXJlZC1saXN0LW1hcmtlcj5cbiAgbnVtZXJpY0Jhc2VEZWNpbWFsOiAxMCxcbiAgbnVtZXJpY0Jhc2VIZXhhZGVjaW1hbDogMHgxMCxcbiAgdGFiU2l6ZTogNCwgLy8gVGFicyBoYXZlIGEgaGFyZC1jb2RlZCBzaXplIG9mIDQsIHBlciBDb21tb25NYXJrLlxuICB0aGVtYXRpY0JyZWFrTWFya2VyQ291bnRNaW46IDMsIC8vIEF0IGxlYXN0IDMgYXN0ZXJpc2tzLCBkYXNoZXMsIG9yIHVuZGVyc2NvcmVzIGFyZSBuZWVkZWQuXG4gIHY4TWF4U2FmZUNodW5rU2l6ZTogMTBfMDAwIC8vIFY4IChhbmQgcG90ZW50aWFsbHkgb3RoZXJzKSBoYXZlIHByb2JsZW1zIGluamVjdGluZyBnaWFudCBhcnJheXMgaW50byBvdGhlciBhcnJheXMsIGhlbmNlIHdlIG9wZXJhdGUgaW4gY2h1bmtzLlxufSlcbiIsIi8qKlxuICogVGhpcyBtb2R1bGUgaXMgY29tcGlsZWQgYXdheSFcbiAqXG4gKiBIZXJlIGlzIHRoZSBsaXN0IG9mIGFsbCB0eXBlcyBvZiB0b2tlbnMgZXhwb3NlZCBieSBtaWNyb21hcmssIHdpdGggYSBzaG9ydFxuICogZXhwbGFuYXRpb24gb2Ygd2hhdCB0aGV5IGluY2x1ZGUgYW5kIHdoZXJlIHRoZXkgYXJlIGZvdW5kLlxuICogSW4gcGlja2luZyBuYW1lcywgZ2VuZXJhbGx5LCB0aGUgcnVsZSBpcyB0byBiZSBhcyBleHBsaWNpdCBhcyBwb3NzaWJsZVxuICogaW5zdGVhZCBvZiByZXVzaW5nIG5hbWVzLlxuICogRm9yIGV4YW1wbGUsIHRoZXJlIGlzIGEgYGRlZmluaXRpb25EZXN0aW5hdGlvbmAgYW5kIGEgYHJlc291cmNlRGVzdGluYXRpb25gLFxuICogaW5zdGVhZCBvZiBvbmUgc2hhcmVkIG5hbWUuXG4gKi9cblxuLy8gTm90ZTogd2hlbiBjaGFuZ2luZyB0aGUgbmV4dCByZWNvcmQsIHlvdSBtdXN0IGFsc28gY2hhbmdlIGBUb2tlblR5cGVNYXBgXG4vLyBpbiBgbWljcm9tYXJrLXV0aWwtdHlwZXMvaW5kZXguZC50c2AuXG5leHBvcnQgY29uc3QgdHlwZXMgPSAvKiogQHR5cGUge2NvbnN0fSAqLyAoe1xuICAvLyBHZW5lcmljIHR5cGUgZm9yIGRhdGEsIHN1Y2ggYXMgaW4gYSB0aXRsZSwgYSBkZXN0aW5hdGlvbiwgZXRjLlxuICBkYXRhOiAnZGF0YScsXG5cbiAgLy8gR2VuZXJpYyB0eXBlIGZvciBzeW50YWN0aWMgd2hpdGVzcGFjZSAodGFicywgdmlydHVhbCBzcGFjZXMsIHNwYWNlcykuXG4gIC8vIFN1Y2ggYXMsIGJldHdlZW4gYSBmZW5jZWQgY29kZSBmZW5jZSBhbmQgYW4gaW5mbyBzdHJpbmcuXG4gIHdoaXRlc3BhY2U6ICd3aGl0ZXNwYWNlJyxcblxuICAvLyBHZW5lcmljIHR5cGUgZm9yIGxpbmUgZW5kaW5ncyAobGluZSBmZWVkLCBjYXJyaWFnZSByZXR1cm4sIGNhcnJpYWdlIHJldHVybiArXG4gIC8vIGxpbmUgZmVlZCkuXG4gIGxpbmVFbmRpbmc6ICdsaW5lRW5kaW5nJyxcblxuICAvLyBBIGxpbmUgZW5kaW5nLCBidXQgZW5kaW5nIGEgYmxhbmsgbGluZS5cbiAgbGluZUVuZGluZ0JsYW5rOiAnbGluZUVuZGluZ0JsYW5rJyxcblxuICAvLyBHZW5lcmljIHR5cGUgZm9yIHdoaXRlc3BhY2UgKHRhYnMsIHZpcnR1YWwgc3BhY2VzLCBzcGFjZXMpIGF0IHRoZSBzdGFydCBvZiBhXG4gIC8vIGxpbmUuXG4gIGxpbmVQcmVmaXg6ICdsaW5lUHJlZml4JyxcblxuICAvLyBHZW5lcmljIHR5cGUgZm9yIHdoaXRlc3BhY2UgKHRhYnMsIHZpcnR1YWwgc3BhY2VzLCBzcGFjZXMpIGF0IHRoZSBlbmQgb2YgYVxuICAvLyBsaW5lLlxuICBsaW5lU3VmZml4OiAnbGluZVN1ZmZpeCcsXG5cbiAgLy8gV2hvbGUgQVRYIGhlYWRpbmc6XG4gIC8vXG4gIC8vIGBgYG1hcmtkb3duXG4gIC8vICNcbiAgLy8gIyMgQWxwaGFcbiAgLy8gIyMjIEJyYXZvICMjI1xuICAvLyBgYGBcbiAgLy9cbiAgLy8gSW5jbHVkZXMgYGF0eEhlYWRpbmdTZXF1ZW5jZWAsIGB3aGl0ZXNwYWNlYCwgYGF0eEhlYWRpbmdUZXh0YC5cbiAgYXR4SGVhZGluZzogJ2F0eEhlYWRpbmcnLFxuXG4gIC8vIFNlcXVlbmNlIG9mIG51bWJlciBzaWducyBpbiBhbiBBVFggaGVhZGluZyAoYCMjI2ApLlxuICBhdHhIZWFkaW5nU2VxdWVuY2U6ICdhdHhIZWFkaW5nU2VxdWVuY2UnLFxuXG4gIC8vIENvbnRlbnQgaW4gYW4gQVRYIGhlYWRpbmcgKGBhbHBoYWApLlxuICAvLyBJbmNsdWRlcyB0ZXh0LlxuICBhdHhIZWFkaW5nVGV4dDogJ2F0eEhlYWRpbmdUZXh0JyxcblxuICAvLyBXaG9sZSBhdXRvbGluayAoYDxodHRwczovL2V4YW1wbGUuY29tPmAgb3IgYDxhZG1pbkBleGFtcGxlLmNvbT5gKVxuICAvLyBJbmNsdWRlcyBgYXV0b2xpbmtNYXJrZXJgIGFuZCBgYXV0b2xpbmtQcm90b2NvbGAgb3IgYGF1dG9saW5rRW1haWxgLlxuICBhdXRvbGluazogJ2F1dG9saW5rJyxcblxuICAvLyBFbWFpbCBhdXRvbGluayB3L28gbWFya2VycyAoYGFkbWluQGV4YW1wbGUuY29tYClcbiAgYXV0b2xpbmtFbWFpbDogJ2F1dG9saW5rRW1haWwnLFxuXG4gIC8vIE1hcmtlciBhcm91bmQgYW4gYGF1dG9saW5rUHJvdG9jb2xgIG9yIGBhdXRvbGlua0VtYWlsYCAoYDxgIG9yIGA+YCkuXG4gIGF1dG9saW5rTWFya2VyOiAnYXV0b2xpbmtNYXJrZXInLFxuXG4gIC8vIFByb3RvY29sIGF1dG9saW5rIHcvbyBtYXJrZXJzIChgaHR0cHM6Ly9leGFtcGxlLmNvbWApXG4gIGF1dG9saW5rUHJvdG9jb2w6ICdhdXRvbGlua1Byb3RvY29sJyxcblxuICAvLyBBIHdob2xlIGNoYXJhY3RlciBlc2NhcGUgKGBcXC1gKS5cbiAgLy8gSW5jbHVkZXMgYGVzY2FwZU1hcmtlcmAgYW5kIGBjaGFyYWN0ZXJFc2NhcGVWYWx1ZWAuXG4gIGNoYXJhY3RlckVzY2FwZTogJ2NoYXJhY3RlckVzY2FwZScsXG5cbiAgLy8gVGhlIGVzY2FwZWQgY2hhcmFjdGVyIChgLWApLlxuICBjaGFyYWN0ZXJFc2NhcGVWYWx1ZTogJ2NoYXJhY3RlckVzY2FwZVZhbHVlJyxcblxuICAvLyBBIHdob2xlIGNoYXJhY3RlciByZWZlcmVuY2UgKGAmYW1wO2AsIGAmIzg4MDA7YCwgb3IgYCYjeDFEMzA2O2ApLlxuICAvLyBJbmNsdWRlcyBgY2hhcmFjdGVyUmVmZXJlbmNlTWFya2VyYCwgYW4gb3B0aW9uYWxcbiAgLy8gYGNoYXJhY3RlclJlZmVyZW5jZU1hcmtlck51bWVyaWNgLCBpbiB3aGljaCBjYXNlIGFuIG9wdGlvbmFsXG4gIC8vIGBjaGFyYWN0ZXJSZWZlcmVuY2VNYXJrZXJIZXhhZGVjaW1hbGAsIGFuZCBhIGBjaGFyYWN0ZXJSZWZlcmVuY2VWYWx1ZWAuXG4gIGNoYXJhY3RlclJlZmVyZW5jZTogJ2NoYXJhY3RlclJlZmVyZW5jZScsXG5cbiAgLy8gVGhlIHN0YXJ0IG9yIGVuZCBtYXJrZXIgKGAmYCBvciBgO2ApLlxuICBjaGFyYWN0ZXJSZWZlcmVuY2VNYXJrZXI6ICdjaGFyYWN0ZXJSZWZlcmVuY2VNYXJrZXInLFxuXG4gIC8vIE1hcmsgcmVmZXJlbmNlIGFzIG51bWVyaWMgKGAjYCkuXG4gIGNoYXJhY3RlclJlZmVyZW5jZU1hcmtlck51bWVyaWM6ICdjaGFyYWN0ZXJSZWZlcmVuY2VNYXJrZXJOdW1lcmljJyxcblxuICAvLyBNYXJrIHJlZmVyZW5jZSBhcyBudW1lcmljIChgeGAgb3IgYFhgKS5cbiAgY2hhcmFjdGVyUmVmZXJlbmNlTWFya2VySGV4YWRlY2ltYWw6ICdjaGFyYWN0ZXJSZWZlcmVuY2VNYXJrZXJIZXhhZGVjaW1hbCcsXG5cbiAgLy8gVmFsdWUgb2YgY2hhcmFjdGVyIHJlZmVyZW5jZSB3L28gbWFya2VycyAoYGFtcGAsIGA4ODAwYCwgb3IgYDFEMzA2YCkuXG4gIGNoYXJhY3RlclJlZmVyZW5jZVZhbHVlOiAnY2hhcmFjdGVyUmVmZXJlbmNlVmFsdWUnLFxuXG4gIC8vIFdob2xlIGZlbmNlZCBjb2RlOlxuICAvL1xuICAvLyBgYGBgbWFya2Rvd25cbiAgLy8gYGBganNcbiAgLy8gYWxlcnQoMSlcbiAgLy8gYGBgXG4gIC8vIGBgYGBcbiAgY29kZUZlbmNlZDogJ2NvZGVGZW5jZWQnLFxuXG4gIC8vIEEgZmVuY2VkIGNvZGUgZmVuY2UsIGluY2x1ZGluZyB3aGl0ZXNwYWNlLCBzZXF1ZW5jZSwgaW5mbywgYW5kIG1ldGFcbiAgLy8gKGAgYGBganMgYCkuXG4gIGNvZGVGZW5jZWRGZW5jZTogJ2NvZGVGZW5jZWRGZW5jZScsXG5cbiAgLy8gU2VxdWVuY2Ugb2YgZ3JhdmUgYWNjZW50IG9yIHRpbGRlIGNoYXJhY3RlcnMgKGAgYGBgIGApIGluIGEgZmVuY2UuXG4gIGNvZGVGZW5jZWRGZW5jZVNlcXVlbmNlOiAnY29kZUZlbmNlZEZlbmNlU2VxdWVuY2UnLFxuXG4gIC8vIEluZm8gd29yZCAoYGpzYCkgaW4gYSBmZW5jZS5cbiAgLy8gSW5jbHVkZXMgc3RyaW5nLlxuICBjb2RlRmVuY2VkRmVuY2VJbmZvOiAnY29kZUZlbmNlZEZlbmNlSW5mbycsXG5cbiAgLy8gTWV0YSB3b3JkcyAoYGhpZ2hsaWdodD1cIjFcImApIGluIGEgZmVuY2UuXG4gIC8vIEluY2x1ZGVzIHN0cmluZy5cbiAgY29kZUZlbmNlZEZlbmNlTWV0YTogJ2NvZGVGZW5jZWRGZW5jZU1ldGEnLFxuXG4gIC8vIEEgbGluZSBvZiBjb2RlLlxuICBjb2RlRmxvd1ZhbHVlOiAnY29kZUZsb3dWYWx1ZScsXG5cbiAgLy8gV2hvbGUgaW5kZW50ZWQgY29kZTpcbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gICAgIGFsZXJ0KDEpXG4gIC8vIGBgYFxuICAvL1xuICAvLyBJbmNsdWRlcyBgbGluZUVuZGluZ2AsIGBsaW5lUHJlZml4YCwgYW5kIGBjb2RlRmxvd1ZhbHVlYC5cbiAgY29kZUluZGVudGVkOiAnY29kZUluZGVudGVkJyxcblxuICAvLyBBIHRleHQgY29kZSAoYGBgIGBhbHBoYWAgYGBgKS5cbiAgLy8gSW5jbHVkZXMgYGNvZGVUZXh0U2VxdWVuY2VgLCBgY29kZVRleHREYXRhYCwgYGxpbmVFbmRpbmdgLCBhbmQgY2FuIGluY2x1ZGVcbiAgLy8gYGNvZGVUZXh0UGFkZGluZ2AuXG4gIGNvZGVUZXh0OiAnY29kZVRleHQnLFxuXG4gIGNvZGVUZXh0RGF0YTogJ2NvZGVUZXh0RGF0YScsXG5cbiAgLy8gQSBzcGFjZSBvciBsaW5lIGVuZGluZyByaWdodCBhZnRlciBvciBiZWZvcmUgYSB0aWNrLlxuICBjb2RlVGV4dFBhZGRpbmc6ICdjb2RlVGV4dFBhZGRpbmcnLFxuXG4gIC8vIEEgdGV4dCBjb2RlIGZlbmNlIChgIGBgIGApLlxuICBjb2RlVGV4dFNlcXVlbmNlOiAnY29kZVRleHRTZXF1ZW5jZScsXG5cbiAgLy8gV2hvbGUgY29udGVudDpcbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gW2FdOiBiXG4gIC8vIGNcbiAgLy8gPVxuICAvLyBkXG4gIC8vIGBgYFxuICAvL1xuICAvLyBJbmNsdWRlcyBgcGFyYWdyYXBoYCBhbmQgYGRlZmluaXRpb25gLlxuICBjb250ZW50OiAnY29udGVudCcsXG4gIC8vIFdob2xlIGRlZmluaXRpb246XG4gIC8vXG4gIC8vIGBgYG1hcmtkb3duXG4gIC8vIFttaWNyb21hcmtdOiBodHRwczovL2dpdGh1Yi5jb20vbWljcm9tYXJrL21pY3JvbWFya1xuICAvLyBgYGBcbiAgLy9cbiAgLy8gSW5jbHVkZXMgYGRlZmluaXRpb25MYWJlbGAsIGBkZWZpbml0aW9uTWFya2VyYCwgYHdoaXRlc3BhY2VgLFxuICAvLyBgZGVmaW5pdGlvbkRlc3RpbmF0aW9uYCwgYW5kIG9wdGlvbmFsbHkgYGxpbmVFbmRpbmdgIGFuZCBgZGVmaW5pdGlvblRpdGxlYC5cbiAgZGVmaW5pdGlvbjogJ2RlZmluaXRpb24nLFxuXG4gIC8vIERlc3RpbmF0aW9uIG9mIGEgZGVmaW5pdGlvbiAoYGh0dHBzOi8vZ2l0aHViLmNvbS9taWNyb21hcmsvbWljcm9tYXJrYCBvclxuICAvLyBgPGh0dHBzOi8vZ2l0aHViLmNvbS9taWNyb21hcmsvbWljcm9tYXJrPmApLlxuICAvLyBJbmNsdWRlcyBgZGVmaW5pdGlvbkRlc3RpbmF0aW9uTGl0ZXJhbGAgb3IgYGRlZmluaXRpb25EZXN0aW5hdGlvblJhd2AuXG4gIGRlZmluaXRpb25EZXN0aW5hdGlvbjogJ2RlZmluaXRpb25EZXN0aW5hdGlvbicsXG5cbiAgLy8gRW5jbG9zZWQgZGVzdGluYXRpb24gb2YgYSBkZWZpbml0aW9uXG4gIC8vIChgPGh0dHBzOi8vZ2l0aHViLmNvbS9taWNyb21hcmsvbWljcm9tYXJrPmApLlxuICAvLyBJbmNsdWRlcyBgZGVmaW5pdGlvbkRlc3RpbmF0aW9uTGl0ZXJhbE1hcmtlcmAgYW5kIG9wdGlvbmFsbHlcbiAgLy8gYGRlZmluaXRpb25EZXN0aW5hdGlvblN0cmluZ2AuXG4gIGRlZmluaXRpb25EZXN0aW5hdGlvbkxpdGVyYWw6ICdkZWZpbml0aW9uRGVzdGluYXRpb25MaXRlcmFsJyxcblxuICAvLyBNYXJrZXJzIG9mIGFuIGVuY2xvc2VkIGRlZmluaXRpb24gZGVzdGluYXRpb24gKGA8YCBvciBgPmApLlxuICBkZWZpbml0aW9uRGVzdGluYXRpb25MaXRlcmFsTWFya2VyOiAnZGVmaW5pdGlvbkRlc3RpbmF0aW9uTGl0ZXJhbE1hcmtlcicsXG5cbiAgLy8gVW5lbmNsb3NlZCBkZXN0aW5hdGlvbiBvZiBhIGRlZmluaXRpb25cbiAgLy8gKGBodHRwczovL2dpdGh1Yi5jb20vbWljcm9tYXJrL21pY3JvbWFya2ApLlxuICAvLyBJbmNsdWRlcyBgZGVmaW5pdGlvbkRlc3RpbmF0aW9uU3RyaW5nYC5cbiAgZGVmaW5pdGlvbkRlc3RpbmF0aW9uUmF3OiAnZGVmaW5pdGlvbkRlc3RpbmF0aW9uUmF3JyxcblxuICAvLyBUZXh0IGluIGFuIGRlc3RpbmF0aW9uIChgaHR0cHM6Ly9naXRodWIuY29tL21pY3JvbWFyay9taWNyb21hcmtgKS5cbiAgLy8gSW5jbHVkZXMgc3RyaW5nLlxuICBkZWZpbml0aW9uRGVzdGluYXRpb25TdHJpbmc6ICdkZWZpbml0aW9uRGVzdGluYXRpb25TdHJpbmcnLFxuXG4gIC8vIExhYmVsIG9mIGEgZGVmaW5pdGlvbiAoYFttaWNyb21hcmtdYCkuXG4gIC8vIEluY2x1ZGVzIGBkZWZpbml0aW9uTGFiZWxNYXJrZXJgIGFuZCBgZGVmaW5pdGlvbkxhYmVsU3RyaW5nYC5cbiAgZGVmaW5pdGlvbkxhYmVsOiAnZGVmaW5pdGlvbkxhYmVsJyxcblxuICAvLyBNYXJrZXJzIG9mIGEgZGVmaW5pdGlvbiBsYWJlbCAoYFtgIG9yIGBdYCkuXG4gIGRlZmluaXRpb25MYWJlbE1hcmtlcjogJ2RlZmluaXRpb25MYWJlbE1hcmtlcicsXG5cbiAgLy8gVmFsdWUgb2YgYSBkZWZpbml0aW9uIGxhYmVsIChgbWljcm9tYXJrYCkuXG4gIC8vIEluY2x1ZGVzIHN0cmluZy5cbiAgZGVmaW5pdGlvbkxhYmVsU3RyaW5nOiAnZGVmaW5pdGlvbkxhYmVsU3RyaW5nJyxcblxuICAvLyBNYXJrZXIgYmV0d2VlbiBhIGxhYmVsIGFuZCBhIGRlc3RpbmF0aW9uIChgOmApLlxuICBkZWZpbml0aW9uTWFya2VyOiAnZGVmaW5pdGlvbk1hcmtlcicsXG5cbiAgLy8gVGl0bGUgb2YgYSBkZWZpbml0aW9uIChgXCJ4XCJgLCBgJ3knYCwgb3IgYCh6KWApLlxuICAvLyBJbmNsdWRlcyBgZGVmaW5pdGlvblRpdGxlTWFya2VyYCBhbmQgb3B0aW9uYWxseSBgZGVmaW5pdGlvblRpdGxlU3RyaW5nYC5cbiAgZGVmaW5pdGlvblRpdGxlOiAnZGVmaW5pdGlvblRpdGxlJyxcblxuICAvLyBNYXJrZXIgYXJvdW5kIGEgdGl0bGUgb2YgYSBkZWZpbml0aW9uIChgXCJgLCBgJ2AsIGAoYCwgb3IgYClgKS5cbiAgZGVmaW5pdGlvblRpdGxlTWFya2VyOiAnZGVmaW5pdGlvblRpdGxlTWFya2VyJyxcblxuICAvLyBEYXRhIHdpdGhvdXQgbWFya2VycyBpbiBhIHRpdGxlIChgemApLlxuICAvLyBJbmNsdWRlcyBzdHJpbmcuXG4gIGRlZmluaXRpb25UaXRsZVN0cmluZzogJ2RlZmluaXRpb25UaXRsZVN0cmluZycsXG5cbiAgLy8gRW1waGFzaXMgKGAqYWxwaGEqYCkuXG4gIC8vIEluY2x1ZGVzIGBlbXBoYXNpc1NlcXVlbmNlYCBhbmQgYGVtcGhhc2lzVGV4dGAuXG4gIGVtcGhhc2lzOiAnZW1waGFzaXMnLFxuXG4gIC8vIFNlcXVlbmNlIG9mIGVtcGhhc2lzIG1hcmtlcnMgKGAqYCBvciBgX2ApLlxuICBlbXBoYXNpc1NlcXVlbmNlOiAnZW1waGFzaXNTZXF1ZW5jZScsXG5cbiAgLy8gRW1waGFzaXMgdGV4dCAoYGFscGhhYCkuXG4gIC8vIEluY2x1ZGVzIHRleHQuXG4gIGVtcGhhc2lzVGV4dDogJ2VtcGhhc2lzVGV4dCcsXG5cbiAgLy8gVGhlIGNoYXJhY3RlciBlc2NhcGUgbWFya2VyIChgXFxgKS5cbiAgZXNjYXBlTWFya2VyOiAnZXNjYXBlTWFya2VyJyxcblxuICAvLyBBIGhhcmQgYnJlYWsgY3JlYXRlZCB3aXRoIGEgYmFja3NsYXNoIChgXFxcXG5gKS5cbiAgLy8gTm90ZTogZG9lcyBub3QgaW5jbHVkZSB0aGUgbGluZSBlbmRpbmcuXG4gIGhhcmRCcmVha0VzY2FwZTogJ2hhcmRCcmVha0VzY2FwZScsXG5cbiAgLy8gQSBoYXJkIGJyZWFrIGNyZWF0ZWQgd2l0aCB0cmFpbGluZyBzcGFjZXMgKGAgIFxcbmApLlxuICAvLyBEb2VzIG5vdCBpbmNsdWRlIHRoZSBsaW5lIGVuZGluZy5cbiAgaGFyZEJyZWFrVHJhaWxpbmc6ICdoYXJkQnJlYWtUcmFpbGluZycsXG5cbiAgLy8gRmxvdyBIVE1MOlxuICAvL1xuICAvLyBgYGBtYXJrZG93blxuICAvLyA8ZGl2XG4gIC8vIGBgYFxuICAvL1xuICAvLyBJbmxjdWRlcyBgbGluZUVuZGluZ2AsIGBodG1sRmxvd0RhdGFgLlxuICBodG1sRmxvdzogJ2h0bWxGbG93JyxcblxuICBodG1sRmxvd0RhdGE6ICdodG1sRmxvd0RhdGEnLFxuXG4gIC8vIEhUTUwgaW4gdGV4dCAodGhlIHRhZyBpbiBgYSA8aT4gYmApLlxuICAvLyBJbmNsdWRlcyBgbGluZUVuZGluZ2AsIGBodG1sVGV4dERhdGFgLlxuICBodG1sVGV4dDogJ2h0bWxUZXh0JyxcblxuICBodG1sVGV4dERhdGE6ICdodG1sVGV4dERhdGEnLFxuXG4gIC8vIFdob2xlIGltYWdlIChgIVthbHBoYV0oYnJhdm8pYCwgYCFbYWxwaGFdW2JyYXZvXWAsIGAhW2FscGhhXVtdYCwgb3JcbiAgLy8gYCFbYWxwaGFdYCkuXG4gIC8vIEluY2x1ZGVzIGBsYWJlbGAgYW5kIGFuIG9wdGlvbmFsIGByZXNvdXJjZWAgb3IgYHJlZmVyZW5jZWAuXG4gIGltYWdlOiAnaW1hZ2UnLFxuXG4gIC8vIFdob2xlIGxpbmsgbGFiZWwgKGBbKmFscGhhKl1gKS5cbiAgLy8gSW5jbHVkZXMgYGxhYmVsTGlua2Agb3IgYGxhYmVsSW1hZ2VgLCBgbGFiZWxUZXh0YCwgYW5kIGBsYWJlbEVuZGAuXG4gIGxhYmVsOiAnbGFiZWwnLFxuXG4gIC8vIFRleHQgaW4gYW4gbGFiZWwgKGAqYWxwaGEqYCkuXG4gIC8vIEluY2x1ZGVzIHRleHQuXG4gIGxhYmVsVGV4dDogJ2xhYmVsVGV4dCcsXG5cbiAgLy8gU3RhcnQgYSBsaW5rIGxhYmVsIChgW2ApLlxuICAvLyBJbmNsdWRlcyBhIGBsYWJlbE1hcmtlcmAuXG4gIGxhYmVsTGluazogJ2xhYmVsTGluaycsXG5cbiAgLy8gU3RhcnQgYW4gaW1hZ2UgbGFiZWwgKGAhW2ApLlxuICAvLyBJbmNsdWRlcyBgbGFiZWxJbWFnZU1hcmtlcmAgYW5kIGBsYWJlbE1hcmtlcmAuXG4gIGxhYmVsSW1hZ2U6ICdsYWJlbEltYWdlJyxcblxuICAvLyBNYXJrZXIgb2YgYSBsYWJlbCAoYFtgIG9yIGBdYCkuXG4gIGxhYmVsTWFya2VyOiAnbGFiZWxNYXJrZXInLFxuXG4gIC8vIE1hcmtlciB0byBzdGFydCBhbiBpbWFnZSAoYCFgKS5cbiAgbGFiZWxJbWFnZU1hcmtlcjogJ2xhYmVsSW1hZ2VNYXJrZXInLFxuXG4gIC8vIEVuZCBhIGxhYmVsIChgXWApLlxuICAvLyBJbmNsdWRlcyBgbGFiZWxNYXJrZXJgLlxuICBsYWJlbEVuZDogJ2xhYmVsRW5kJyxcblxuICAvLyBXaG9sZSBsaW5rIChgW2FscGhhXShicmF2bylgLCBgW2FscGhhXVticmF2b11gLCBgW2FscGhhXVtdYCwgb3IgYFthbHBoYV1gKS5cbiAgLy8gSW5jbHVkZXMgYGxhYmVsYCBhbmQgYW4gb3B0aW9uYWwgYHJlc291cmNlYCBvciBgcmVmZXJlbmNlYC5cbiAgbGluazogJ2xpbmsnLFxuXG4gIC8vIFdob2xlIHBhcmFncmFwaDpcbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gYWxwaGFcbiAgLy8gYnJhdm8uXG4gIC8vIGBgYFxuICAvL1xuICAvLyBJbmNsdWRlcyB0ZXh0LlxuICBwYXJhZ3JhcGg6ICdwYXJhZ3JhcGgnLFxuXG4gIC8vIEEgcmVmZXJlbmNlIChgW2FscGhhXWAgb3IgYFtdYCkuXG4gIC8vIEluY2x1ZGVzIGByZWZlcmVuY2VNYXJrZXJgIGFuZCBhbiBvcHRpb25hbCBgcmVmZXJlbmNlU3RyaW5nYC5cbiAgcmVmZXJlbmNlOiAncmVmZXJlbmNlJyxcblxuICAvLyBBIHJlZmVyZW5jZSBtYXJrZXIgKGBbYCBvciBgXWApLlxuICByZWZlcmVuY2VNYXJrZXI6ICdyZWZlcmVuY2VNYXJrZXInLFxuXG4gIC8vIFJlZmVyZW5jZSB0ZXh0IChgYWxwaGFgKS5cbiAgLy8gSW5jbHVkZXMgc3RyaW5nLlxuICByZWZlcmVuY2VTdHJpbmc6ICdyZWZlcmVuY2VTdHJpbmcnLFxuXG4gIC8vIEEgcmVzb3VyY2UgKGAoaHR0cHM6Ly9leGFtcGxlLmNvbSBcImFscGhhXCIpYCkuXG4gIC8vIEluY2x1ZGVzIGByZXNvdXJjZU1hcmtlcmAsIGFuIG9wdGlvbmFsIGByZXNvdXJjZURlc3RpbmF0aW9uYCB3aXRoIGFuIG9wdGlvbmFsXG4gIC8vIGB3aGl0ZXNwYWNlYCBhbmQgYHJlc291cmNlVGl0bGVgLlxuICByZXNvdXJjZTogJ3Jlc291cmNlJyxcblxuICAvLyBBIHJlc291cmNlIGRlc3RpbmF0aW9uIChgaHR0cHM6Ly9leGFtcGxlLmNvbWApLlxuICAvLyBJbmNsdWRlcyBgcmVzb3VyY2VEZXN0aW5hdGlvbkxpdGVyYWxgIG9yIGByZXNvdXJjZURlc3RpbmF0aW9uUmF3YC5cbiAgcmVzb3VyY2VEZXN0aW5hdGlvbjogJ3Jlc291cmNlRGVzdGluYXRpb24nLFxuXG4gIC8vIEEgbGl0ZXJhbCByZXNvdXJjZSBkZXN0aW5hdGlvbiAoYDxodHRwczovL2V4YW1wbGUuY29tPmApLlxuICAvLyBJbmNsdWRlcyBgcmVzb3VyY2VEZXN0aW5hdGlvbkxpdGVyYWxNYXJrZXJgIGFuZCBvcHRpb25hbGx5XG4gIC8vIGByZXNvdXJjZURlc3RpbmF0aW9uU3RyaW5nYC5cbiAgcmVzb3VyY2VEZXN0aW5hdGlvbkxpdGVyYWw6ICdyZXNvdXJjZURlc3RpbmF0aW9uTGl0ZXJhbCcsXG5cbiAgLy8gQSByZXNvdXJjZSBkZXN0aW5hdGlvbiBtYXJrZXIgKGA8YCBvciBgPmApLlxuICByZXNvdXJjZURlc3RpbmF0aW9uTGl0ZXJhbE1hcmtlcjogJ3Jlc291cmNlRGVzdGluYXRpb25MaXRlcmFsTWFya2VyJyxcblxuICAvLyBBIHJhdyByZXNvdXJjZSBkZXN0aW5hdGlvbiAoYGh0dHBzOi8vZXhhbXBsZS5jb21gKS5cbiAgLy8gSW5jbHVkZXMgYHJlc291cmNlRGVzdGluYXRpb25TdHJpbmdgLlxuICByZXNvdXJjZURlc3RpbmF0aW9uUmF3OiAncmVzb3VyY2VEZXN0aW5hdGlvblJhdycsXG5cbiAgLy8gUmVzb3VyY2UgZGVzdGluYXRpb24gdGV4dCAoYGh0dHBzOi8vZXhhbXBsZS5jb21gKS5cbiAgLy8gSW5jbHVkZXMgc3RyaW5nLlxuICByZXNvdXJjZURlc3RpbmF0aW9uU3RyaW5nOiAncmVzb3VyY2VEZXN0aW5hdGlvblN0cmluZycsXG5cbiAgLy8gQSByZXNvdXJjZSBtYXJrZXIgKGAoYCBvciBgKWApLlxuICByZXNvdXJjZU1hcmtlcjogJ3Jlc291cmNlTWFya2VyJyxcblxuICAvLyBBIHJlc291cmNlIHRpdGxlIChgXCJhbHBoYVwiYCwgYCdhbHBoYSdgLCBvciBgKGFscGhhKWApLlxuICAvLyBJbmNsdWRlcyBgcmVzb3VyY2VUaXRsZU1hcmtlcmAgYW5kIG9wdGlvbmFsbHkgYHJlc291cmNlVGl0bGVTdHJpbmdgLlxuICByZXNvdXJjZVRpdGxlOiAncmVzb3VyY2VUaXRsZScsXG5cbiAgLy8gQSByZXNvdXJjZSB0aXRsZSBtYXJrZXIgKGBcImAsIGAnYCwgYChgLCBvciBgKWApLlxuICByZXNvdXJjZVRpdGxlTWFya2VyOiAncmVzb3VyY2VUaXRsZU1hcmtlcicsXG5cbiAgLy8gUmVzb3VyY2UgZGVzdGluYXRpb24gdGl0bGUgKGBhbHBoYWApLlxuICAvLyBJbmNsdWRlcyBzdHJpbmcuXG4gIHJlc291cmNlVGl0bGVTdHJpbmc6ICdyZXNvdXJjZVRpdGxlU3RyaW5nJyxcblxuICAvLyBXaG9sZSBzZXRleHQgaGVhZGluZzpcbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gYWxwaGFcbiAgLy8gYnJhdm9cbiAgLy8gPT09PT1cbiAgLy8gYGBgXG4gIC8vXG4gIC8vIEluY2x1ZGVzIGBzZXRleHRIZWFkaW5nVGV4dGAsIGBsaW5lRW5kaW5nYCwgYGxpbmVQcmVmaXhgLCBhbmRcbiAgLy8gYHNldGV4dEhlYWRpbmdMaW5lYC5cbiAgc2V0ZXh0SGVhZGluZzogJ3NldGV4dEhlYWRpbmcnLFxuXG4gIC8vIENvbnRlbnQgaW4gYSBzZXRleHQgaGVhZGluZyAoYGFscGhhXFxuYnJhdm9gKS5cbiAgLy8gSW5jbHVkZXMgdGV4dC5cbiAgc2V0ZXh0SGVhZGluZ1RleHQ6ICdzZXRleHRIZWFkaW5nVGV4dCcsXG5cbiAgLy8gVW5kZXJsaW5lIGluIGEgc2V0ZXh0IGhlYWRpbmcsIGluY2x1ZGluZyB3aGl0ZXNwYWNlIHN1ZmZpeCAoYD09YCkuXG4gIC8vIEluY2x1ZGVzIGBzZXRleHRIZWFkaW5nTGluZVNlcXVlbmNlYC5cbiAgc2V0ZXh0SGVhZGluZ0xpbmU6ICdzZXRleHRIZWFkaW5nTGluZScsXG5cbiAgLy8gU2VxdWVuY2Ugb2YgZXF1YWxzIG9yIGRhc2ggY2hhcmFjdGVycyBpbiB1bmRlcmxpbmUgaW4gYSBzZXRleHQgaGVhZGluZyAoYC1gKS5cbiAgc2V0ZXh0SGVhZGluZ0xpbmVTZXF1ZW5jZTogJ3NldGV4dEhlYWRpbmdMaW5lU2VxdWVuY2UnLFxuXG4gIC8vIFN0cm9uZyAoYCoqYWxwaGEqKmApLlxuICAvLyBJbmNsdWRlcyBgc3Ryb25nU2VxdWVuY2VgIGFuZCBgc3Ryb25nVGV4dGAuXG4gIHN0cm9uZzogJ3N0cm9uZycsXG5cbiAgLy8gU2VxdWVuY2Ugb2Ygc3Ryb25nIG1hcmtlcnMgKGAqKmAgb3IgYF9fYCkuXG4gIHN0cm9uZ1NlcXVlbmNlOiAnc3Ryb25nU2VxdWVuY2UnLFxuXG4gIC8vIFN0cm9uZyB0ZXh0IChgYWxwaGFgKS5cbiAgLy8gSW5jbHVkZXMgdGV4dC5cbiAgc3Ryb25nVGV4dDogJ3N0cm9uZ1RleHQnLFxuXG4gIC8vIFdob2xlIHRoZW1hdGljIGJyZWFrOlxuICAvL1xuICAvLyBgYGBtYXJrZG93blxuICAvLyAqICogKlxuICAvLyBgYGBcbiAgLy9cbiAgLy8gSW5jbHVkZXMgYHRoZW1hdGljQnJlYWtTZXF1ZW5jZWAgYW5kIGB3aGl0ZXNwYWNlYC5cbiAgdGhlbWF0aWNCcmVhazogJ3RoZW1hdGljQnJlYWsnLFxuXG4gIC8vIEEgc2VxdWVuY2Ugb2Ygb25lIG9yIG1vcmUgdGhlbWF0aWMgYnJlYWsgbWFya2VycyAoYCoqKmApLlxuICB0aGVtYXRpY0JyZWFrU2VxdWVuY2U6ICd0aGVtYXRpY0JyZWFrU2VxdWVuY2UnLFxuXG4gIC8vIFdob2xlIGJsb2NrIHF1b3RlOlxuICAvL1xuICAvLyBgYGBtYXJrZG93blxuICAvLyA+IGFcbiAgLy8gPlxuICAvLyA+IGJcbiAgLy8gYGBgXG4gIC8vXG4gIC8vIEluY2x1ZGVzIGBibG9ja1F1b3RlUHJlZml4YCBhbmQgZmxvdy5cbiAgYmxvY2tRdW90ZTogJ2Jsb2NrUXVvdGUnLFxuICAvLyBUaGUgYD5gIG9yIGA+IGAgb2YgYSBibG9jayBxdW90ZS5cbiAgYmxvY2tRdW90ZVByZWZpeDogJ2Jsb2NrUXVvdGVQcmVmaXgnLFxuICAvLyBUaGUgYD5gIG9mIGEgYmxvY2sgcXVvdGUgcHJlZml4LlxuICBibG9ja1F1b3RlTWFya2VyOiAnYmxvY2tRdW90ZU1hcmtlcicsXG4gIC8vIFRoZSBvcHRpb25hbCBgIGAgb2YgYSBibG9jayBxdW90ZSBwcmVmaXguXG4gIGJsb2NrUXVvdGVQcmVmaXhXaGl0ZXNwYWNlOiAnYmxvY2tRdW90ZVByZWZpeFdoaXRlc3BhY2UnLFxuXG4gIC8vIFdob2xlIG9yZGVyZWQgbGlzdDpcbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gMS4gYVxuICAvLyAgICBiXG4gIC8vIGBgYFxuICAvL1xuICAvLyBJbmNsdWRlcyBgbGlzdEl0ZW1QcmVmaXhgLCBmbG93LCBhbmQgb3B0aW9uYWxseSAgYGxpc3RJdGVtSW5kZW50YCBvbiBmdXJ0aGVyXG4gIC8vIGxpbmVzLlxuICBsaXN0T3JkZXJlZDogJ2xpc3RPcmRlcmVkJyxcblxuICAvLyBXaG9sZSB1bm9yZGVyZWQgbGlzdDpcbiAgLy9cbiAgLy8gYGBgbWFya2Rvd25cbiAgLy8gLSBhXG4gIC8vICAgYlxuICAvLyBgYGBcbiAgLy9cbiAgLy8gSW5jbHVkZXMgYGxpc3RJdGVtUHJlZml4YCwgZmxvdywgYW5kIG9wdGlvbmFsbHkgIGBsaXN0SXRlbUluZGVudGAgb24gZnVydGhlclxuICAvLyBsaW5lcy5cbiAgbGlzdFVub3JkZXJlZDogJ2xpc3RVbm9yZGVyZWQnLFxuXG4gIC8vIFRoZSBpbmRlbnQgb2YgZnVydGhlciBsaXN0IGl0ZW0gbGluZXMuXG4gIGxpc3RJdGVtSW5kZW50OiAnbGlzdEl0ZW1JbmRlbnQnLFxuXG4gIC8vIEEgbWFya2VyLCBhcyBpbiwgYCpgLCBgK2AsIGAtYCwgYC5gLCBvciBgKWAuXG4gIGxpc3RJdGVtTWFya2VyOiAnbGlzdEl0ZW1NYXJrZXInLFxuXG4gIC8vIFRoZSB0aGluZyB0aGF0IHN0YXJ0cyBhIGxpc3QgaXRlbSwgc3VjaCBhcyBgMS4gYC5cbiAgLy8gSW5jbHVkZXMgYGxpc3RJdGVtVmFsdWVgIGlmIG9yZGVyZWQsIGBsaXN0SXRlbU1hcmtlcmAsIGFuZFxuICAvLyBgbGlzdEl0ZW1QcmVmaXhXaGl0ZXNwYWNlYCAodW5sZXNzIGZvbGxvd2VkIGJ5IGEgbGluZSBlbmRpbmcpLlxuICBsaXN0SXRlbVByZWZpeDogJ2xpc3RJdGVtUHJlZml4JyxcblxuICAvLyBUaGUgd2hpdGVzcGFjZSBhZnRlciBhIG1hcmtlci5cbiAgbGlzdEl0ZW1QcmVmaXhXaGl0ZXNwYWNlOiAnbGlzdEl0ZW1QcmVmaXhXaGl0ZXNwYWNlJyxcblxuICAvLyBUaGUgbnVtZXJpY2FsIHZhbHVlIG9mIGFuIG9yZGVyZWQgaXRlbS5cbiAgbGlzdEl0ZW1WYWx1ZTogJ2xpc3RJdGVtVmFsdWUnLFxuXG4gIC8vIEludGVybmFsIHR5cGVzIHVzZWQgZm9yIHN1YnRva2VuaXplcnMsIGNvbXBpbGVkIGF3YXlcbiAgY2h1bmtEb2N1bWVudDogJ2NodW5rRG9jdW1lbnQnLFxuICBjaHVua0NvbnRlbnQ6ICdjaHVua0NvbnRlbnQnLFxuICBjaHVua0Zsb3c6ICdjaHVua0Zsb3cnLFxuICBjaHVua1RleHQ6ICdjaHVua1RleHQnLFxuICBjaHVua1N0cmluZzogJ2NodW5rU3RyaW5nJ1xufSlcbiIsIi8qKlxuICogQGltcG9ydCB7Q29kZX0gZnJvbSAnbWljcm9tYXJrLXV0aWwtdHlwZXMnXG4gKi9cblxuaW1wb3J0IHtjb2Rlc30gZnJvbSAnbWljcm9tYXJrLXV0aWwtc3ltYm9sJ1xuXG4vKipcbiAqIENoZWNrIHdoZXRoZXIgdGhlIGNoYXJhY3RlciBjb2RlIHJlcHJlc2VudHMgYW4gQVNDSUkgYWxwaGEgKGBhYCB0aHJvdWdoIGB6YCxcbiAqIGNhc2UgaW5zZW5zaXRpdmUpLlxuICpcbiAqIEFuICoqQVNDSUkgYWxwaGEqKiBpcyBhbiBBU0NJSSB1cHBlciBhbHBoYSBvciBBU0NJSSBsb3dlciBhbHBoYS5cbiAqXG4gKiBBbiAqKkFTQ0lJIHVwcGVyIGFscGhhKiogaXMgYSBjaGFyYWN0ZXIgaW4gdGhlIGluY2x1c2l2ZSByYW5nZSBVKzAwNDEgKGBBYClcbiAqIHRvIFUrMDA1QSAoYFpgKS5cbiAqXG4gKiBBbiAqKkFTQ0lJIGxvd2VyIGFscGhhKiogaXMgYSBjaGFyYWN0ZXIgaW4gdGhlIGluY2x1c2l2ZSByYW5nZSBVKzAwNjEgKGBhYClcbiAqIHRvIFUrMDA3QSAoYHpgKS5cbiAqXG4gKiBAcGFyYW0gY29kZVxuICogICBDb2RlLlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKiAgIFdoZXRoZXIgaXQgbWF0Y2hlcy5cbiAqL1xuZXhwb3J0IGNvbnN0IGFzY2lpQWxwaGEgPSByZWdleENoZWNrKC9bQS1aYS16XS8pXG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0aGUgY2hhcmFjdGVyIGNvZGUgcmVwcmVzZW50cyBhbiBBU0NJSSBhbHBoYW51bWVyaWMgKGBhYFxuICogdGhyb3VnaCBgemAsIGNhc2UgaW5zZW5zaXRpdmUsIG9yIGAwYCB0aHJvdWdoIGA5YCkuXG4gKlxuICogQW4gKipBU0NJSSBhbHBoYW51bWVyaWMqKiBpcyBhbiBBU0NJSSBkaWdpdCAoc2VlIGBhc2NpaURpZ2l0YCkgb3IgQVNDSUkgYWxwaGFcbiAqIChzZWUgYGFzY2lpQWxwaGFgKS5cbiAqXG4gKiBAcGFyYW0gY29kZVxuICogICBDb2RlLlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKiAgIFdoZXRoZXIgaXQgbWF0Y2hlcy5cbiAqL1xuZXhwb3J0IGNvbnN0IGFzY2lpQWxwaGFudW1lcmljID0gcmVnZXhDaGVjaygvW1xcZEEtWmEtel0vKVxuXG4vKipcbiAqIENoZWNrIHdoZXRoZXIgdGhlIGNoYXJhY3RlciBjb2RlIHJlcHJlc2VudHMgYW4gQVNDSUkgYXRleHQuXG4gKlxuICogYXRleHQgaXMgYW4gQVNDSUkgYWxwaGFudW1lcmljIChzZWUgYGFzY2lpQWxwaGFudW1lcmljYCksIG9yIGEgY2hhcmFjdGVyIGluXG4gKiB0aGUgaW5jbHVzaXZlIHJhbmdlcyBVKzAwMjMgTlVNQkVSIFNJR04gKGAjYCkgdG8gVSswMDI3IEFQT1NUUk9QSEUgKGAnYCksXG4gKiBVKzAwMkEgQVNURVJJU0sgKGAqYCksIFUrMDAyQiBQTFVTIFNJR04gKGArYCksIFUrMDAyRCBEQVNIIChgLWApLCBVKzAwMkZcbiAqIFNMQVNIIChgL2ApLCBVKzAwM0QgRVFVQUxTIFRPIChgPWApLCBVKzAwM0YgUVVFU1RJT04gTUFSSyAoYD9gKSwgVSswMDVFXG4gKiBDQVJFVCAoYF5gKSB0byBVKzAwNjAgR1JBVkUgQUNDRU5UIChgYCBgIGBgKSwgb3IgVSswMDdCIExFRlQgQ1VSTFkgQlJBQ0VcbiAqIChge2ApIHRvIFUrMDA3RSBUSUxERSAoYH5gKS5cbiAqXG4gKiBTZWU6XG4gKiAqKlxcW1JGQzUzMjJdKio6XG4gKiBbSW50ZXJuZXQgTWVzc2FnZSBGb3JtYXRdKGh0dHBzOi8vdG9vbHMuaWV0Zi5vcmcvaHRtbC9yZmM1MzIyKS5cbiAqIFAuIFJlc25pY2suXG4gKiBJRVRGLlxuICpcbiAqIEBwYXJhbSBjb2RlXG4gKiAgIENvZGUuXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqICAgV2hldGhlciBpdCBtYXRjaGVzLlxuICovXG5leHBvcnQgY29uc3QgYXNjaWlBdGV4dCA9IHJlZ2V4Q2hlY2soL1sjLScqK1xcLS05PT9BLVpeLX5dLylcblxuLyoqXG4gKiBDaGVjayB3aGV0aGVyIGEgY2hhcmFjdGVyIGNvZGUgaXMgYW4gQVNDSUkgY29udHJvbCBjaGFyYWN0ZXIuXG4gKlxuICogQW4gKipBU0NJSSBjb250cm9sKiogaXMgYSBjaGFyYWN0ZXIgaW4gdGhlIGluY2x1c2l2ZSByYW5nZSBVKzAwMDAgTlVMTCAoTlVMKVxuICogdG8gVSswMDFGIChVUyksIG9yIFUrMDA3RiAoREVMKS5cbiAqXG4gKiBAcGFyYW0ge0NvZGV9IGNvZGVcbiAqICAgQ29kZS5cbiAqIEByZXR1cm5zIHtib29sZWFufVxuICogICBXaGV0aGVyIGl0IG1hdGNoZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc2NpaUNvbnRyb2woY29kZSkge1xuICByZXR1cm4gKFxuICAgIC8vIFNwZWNpYWwgd2hpdGVzcGFjZSBjb2RlcyAod2hpY2ggaGF2ZSBuZWdhdGl2ZSB2YWx1ZXMpLCBDMCBhbmQgQ29udHJvbFxuICAgIC8vIGNoYXJhY3RlciBERUxcbiAgICBjb2RlICE9PSBudWxsICYmIChjb2RlIDwgY29kZXMuc3BhY2UgfHwgY29kZSA9PT0gY29kZXMuZGVsKVxuICApXG59XG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0aGUgY2hhcmFjdGVyIGNvZGUgcmVwcmVzZW50cyBhbiBBU0NJSSBkaWdpdCAoYDBgIHRocm91Z2ggYDlgKS5cbiAqXG4gKiBBbiAqKkFTQ0lJIGRpZ2l0KiogaXMgYSBjaGFyYWN0ZXIgaW4gdGhlIGluY2x1c2l2ZSByYW5nZSBVKzAwMzAgKGAwYCkgdG9cbiAqIFUrMDAzOSAoYDlgKS5cbiAqXG4gKiBAcGFyYW0gY29kZVxuICogICBDb2RlLlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKiAgIFdoZXRoZXIgaXQgbWF0Y2hlcy5cbiAqL1xuZXhwb3J0IGNvbnN0IGFzY2lpRGlnaXQgPSByZWdleENoZWNrKC9cXGQvKVxuXG4vKipcbiAqIENoZWNrIHdoZXRoZXIgdGhlIGNoYXJhY3RlciBjb2RlIHJlcHJlc2VudHMgYW4gQVNDSUkgaGV4IGRpZ2l0IChgYWAgdGhyb3VnaFxuICogYGZgLCBjYXNlIGluc2Vuc2l0aXZlLCBvciBgMGAgdGhyb3VnaCBgOWApLlxuICpcbiAqIEFuICoqQVNDSUkgaGV4IGRpZ2l0KiogaXMgYW4gQVNDSUkgZGlnaXQgKHNlZSBgYXNjaWlEaWdpdGApLCBBU0NJSSB1cHBlciBoZXhcbiAqIGRpZ2l0LCBvciBhbiBBU0NJSSBsb3dlciBoZXggZGlnaXQuXG4gKlxuICogQW4gKipBU0NJSSB1cHBlciBoZXggZGlnaXQqKiBpcyBhIGNoYXJhY3RlciBpbiB0aGUgaW5jbHVzaXZlIHJhbmdlIFUrMDA0MVxuICogKGBBYCkgdG8gVSswMDQ2IChgRmApLlxuICpcbiAqIEFuICoqQVNDSUkgbG93ZXIgaGV4IGRpZ2l0KiogaXMgYSBjaGFyYWN0ZXIgaW4gdGhlIGluY2x1c2l2ZSByYW5nZSBVKzAwNjFcbiAqIChgYWApIHRvIFUrMDA2NiAoYGZgKS5cbiAqXG4gKiBAcGFyYW0gY29kZVxuICogICBDb2RlLlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKiAgIFdoZXRoZXIgaXQgbWF0Y2hlcy5cbiAqL1xuZXhwb3J0IGNvbnN0IGFzY2lpSGV4RGlnaXQgPSByZWdleENoZWNrKC9bXFxkQS1GYS1mXS8pXG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0aGUgY2hhcmFjdGVyIGNvZGUgcmVwcmVzZW50cyBBU0NJSSBwdW5jdHVhdGlvbi5cbiAqXG4gKiBBbiAqKkFTQ0lJIHB1bmN0dWF0aW9uKiogaXMgYSBjaGFyYWN0ZXIgaW4gdGhlIGluY2x1c2l2ZSByYW5nZXMgVSswMDIxXG4gKiBFWENMQU1BVElPTiBNQVJLIChgIWApIHRvIFUrMDAyRiBTTEFTSCAoYC9gKSwgVSswMDNBIENPTE9OIChgOmApIHRvIFUrMDA0MCBBVFxuICogU0lHTiAoYEBgKSwgVSswMDVCIExFRlQgU1FVQVJFIEJSQUNLRVQgKGBbYCkgdG8gVSswMDYwIEdSQVZFIEFDQ0VOVFxuICogKGBgIGAgYGApLCBvciBVKzAwN0IgTEVGVCBDVVJMWSBCUkFDRSAoYHtgKSB0byBVKzAwN0UgVElMREUgKGB+YCkuXG4gKlxuICogQHBhcmFtIGNvZGVcbiAqICAgQ29kZS5cbiAqIEByZXR1cm5zIHtib29sZWFufVxuICogICBXaGV0aGVyIGl0IG1hdGNoZXMuXG4gKi9cbmV4cG9ydCBjb25zdCBhc2NpaVB1bmN0dWF0aW9uID0gcmVnZXhDaGVjaygvWyEtLzotQFstYHstfl0vKVxuXG4vKipcbiAqIENoZWNrIHdoZXRoZXIgYSBjaGFyYWN0ZXIgY29kZSBpcyBhIG1hcmtkb3duIGxpbmUgZW5kaW5nLlxuICpcbiAqIEEgKiptYXJrZG93biBsaW5lIGVuZGluZyoqIGlzIHRoZSB2aXJ0dWFsIGNoYXJhY3RlcnMgTS0wMDAzIENBUlJJQUdFIFJFVFVSTlxuICogTElORSBGRUVEIChDUkxGKSwgTS0wMDA0IExJTkUgRkVFRCAoTEYpIGFuZCBNLTAwMDUgQ0FSUklBR0UgUkVUVVJOIChDUikuXG4gKlxuICogSW4gbWljcm9tYXJrLCB0aGUgYWN0dWFsIGNoYXJhY3RlciBVKzAwMEEgTElORSBGRUVEIChMRikgYW5kIFUrMDAwRCBDQVJSSUFHRVxuICogUkVUVVJOIChDUikgYXJlIHJlcGxhY2VkIGJ5IHRoZXNlIHZpcnR1YWwgY2hhcmFjdGVycyBkZXBlbmRpbmcgb24gd2hldGhlclxuICogdGhleSBvY2N1cnJlZCB0b2dldGhlci5cbiAqXG4gKiBAcGFyYW0ge0NvZGV9IGNvZGVcbiAqICAgQ29kZS5cbiAqIEByZXR1cm5zIHtib29sZWFufVxuICogICBXaGV0aGVyIGl0IG1hdGNoZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYXJrZG93bkxpbmVFbmRpbmcoY29kZSkge1xuICByZXR1cm4gY29kZSAhPT0gbnVsbCAmJiBjb2RlIDwgY29kZXMuaG9yaXpvbnRhbFRhYlxufVxuXG4vKipcbiAqIENoZWNrIHdoZXRoZXIgYSBjaGFyYWN0ZXIgY29kZSBpcyBhIG1hcmtkb3duIGxpbmUgZW5kaW5nIChzZWVcbiAqIGBtYXJrZG93bkxpbmVFbmRpbmdgKSBvciBtYXJrZG93biBzcGFjZSAoc2VlIGBtYXJrZG93blNwYWNlYCkuXG4gKlxuICogQHBhcmFtIHtDb2RlfSBjb2RlXG4gKiAgIENvZGUuXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqICAgV2hldGhlciBpdCBtYXRjaGVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZShjb2RlKSB7XG4gIHJldHVybiBjb2RlICE9PSBudWxsICYmIChjb2RlIDwgY29kZXMubnVsIHx8IGNvZGUgPT09IGNvZGVzLnNwYWNlKVxufVxuXG4vKipcbiAqIENoZWNrIHdoZXRoZXIgYSBjaGFyYWN0ZXIgY29kZSBpcyBhIG1hcmtkb3duIHNwYWNlLlxuICpcbiAqIEEgKiptYXJrZG93biBzcGFjZSoqIGlzIHRoZSBjb25jcmV0ZSBjaGFyYWN0ZXIgVSswMDIwIFNQQUNFIChTUCkgYW5kIHRoZVxuICogdmlydHVhbCBjaGFyYWN0ZXJzIE0tMDAwMSBWSVJUVUFMIFNQQUNFIChWUykgYW5kIE0tMDAwMiBIT1JJWk9OVEFMIFRBQiAoSFQpLlxuICpcbiAqIEluIG1pY3JvbWFyaywgdGhlIGFjdHVhbCBjaGFyYWN0ZXIgVSswMDA5IENIQVJBQ1RFUiBUQUJVTEFUSU9OIChIVCkgaXNcbiAqIHJlcGxhY2VkIGJ5IG9uZSBNLTAwMDIgSE9SSVpPTlRBTCBUQUIgKEhUKSBhbmQgYmV0d2VlbiAwIGFuZCAzIE0tMDAwMSBWSVJUVUFMXG4gKiBTUEFDRSAoVlMpIGNoYXJhY3RlcnMsIGRlcGVuZGluZyBvbiB0aGUgY29sdW1uIGF0IHdoaWNoIHRoZSB0YWIgb2NjdXJyZWQuXG4gKlxuICogQHBhcmFtIHtDb2RlfSBjb2RlXG4gKiAgIENvZGUuXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqICAgV2hldGhlciBpdCBtYXRjaGVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWFya2Rvd25TcGFjZShjb2RlKSB7XG4gIHJldHVybiAoXG4gICAgY29kZSA9PT0gY29kZXMuaG9yaXpvbnRhbFRhYiB8fFxuICAgIGNvZGUgPT09IGNvZGVzLnZpcnR1YWxTcGFjZSB8fFxuICAgIGNvZGUgPT09IGNvZGVzLnNwYWNlXG4gIClcbn1cblxuLy8gU2l6ZSBub3RlOiByZW1vdmluZyBBU0NJSSBmcm9tIHRoZSByZWdleCBhbmQgdXNpbmcgYGFzY2lpUHVuY3R1YXRpb25gIGhlcmVcbi8vIEluIGZhY3QgYWRkcyB0byB0aGUgYnVuZGxlIHNpemUuXG4vKipcbiAqIENoZWNrIHdoZXRoZXIgdGhlIGNoYXJhY3RlciBjb2RlIHJlcHJlc2VudHMgVW5pY29kZSBwdW5jdHVhdGlvbi5cbiAqXG4gKiBBICoqVW5pY29kZSBwdW5jdHVhdGlvbioqIGlzIGEgY2hhcmFjdGVyIGluIHRoZSBVbmljb2RlIGBQY2AgKFB1bmN0dWF0aW9uLFxuICogQ29ubmVjdG9yKSwgYFBkYCAoUHVuY3R1YXRpb24sIERhc2gpLCBgUGVgIChQdW5jdHVhdGlvbiwgQ2xvc2UpLCBgUGZgXG4gKiAoUHVuY3R1YXRpb24sIEZpbmFsIHF1b3RlKSwgYFBpYCAoUHVuY3R1YXRpb24sIEluaXRpYWwgcXVvdGUpLCBgUG9gXG4gKiAoUHVuY3R1YXRpb24sIE90aGVyKSwgb3IgYFBzYCAoUHVuY3R1YXRpb24sIE9wZW4pIGNhdGVnb3JpZXMsIG9yIGFuIEFTQ0lJXG4gKiBwdW5jdHVhdGlvbiAoc2VlIGBhc2NpaVB1bmN0dWF0aW9uYCkuXG4gKlxuICogU2VlOlxuICogKipcXFtVTklDT0RFXSoqOlxuICogW1RoZSBVbmljb2RlIFN0YW5kYXJkXShodHRwczovL3d3dy51bmljb2RlLm9yZy92ZXJzaW9ucy8pLlxuICogVW5pY29kZSBDb25zb3J0aXVtLlxuICpcbiAqIEBwYXJhbSBjb2RlXG4gKiAgIENvZGUuXG4gKiBAcmV0dXJuc1xuICogICBXaGV0aGVyIGl0IG1hdGNoZXMuXG4gKi9cbmV4cG9ydCBjb25zdCB1bmljb2RlUHVuY3R1YXRpb24gPSByZWdleENoZWNrKC9cXHB7UH18XFxwe1N9L3UpXG5cbi8qKlxuICogQ2hlY2sgd2hldGhlciB0aGUgY2hhcmFjdGVyIGNvZGUgcmVwcmVzZW50cyBVbmljb2RlIHdoaXRlc3BhY2UuXG4gKlxuICogTm90ZSB0aGF0IHRoaXMgZG9lcyBoYW5kbGUgbWljcm9tYXJrIHNwZWNpZmljIG1hcmtkb3duIHdoaXRlc3BhY2UgY2hhcmFjdGVycy5cbiAqIFNlZSBgbWFya2Rvd25MaW5lRW5kaW5nT3JTcGFjZWAgdG8gY2hlY2sgdGhhdC5cbiAqXG4gKiBBICoqVW5pY29kZSB3aGl0ZXNwYWNlKiogaXMgYSBjaGFyYWN0ZXIgaW4gdGhlIFVuaWNvZGUgYFpzYCAoU2VwYXJhdG9yLFxuICogU3BhY2UpIGNhdGVnb3J5LCBvciBVKzAwMDkgQ0hBUkFDVEVSIFRBQlVMQVRJT04gKEhUKSwgVSswMDBBIExJTkUgRkVFRCAoTEYpLFxuICogVSswMDBDIChGRiksIG9yIFUrMDAwRCBDQVJSSUFHRSBSRVRVUk4gKENSKSAoKipcXFtVTklDT0RFXSoqKS5cbiAqXG4gKiBTZWU6XG4gKiAqKlxcW1VOSUNPREVdKio6XG4gKiBbVGhlIFVuaWNvZGUgU3RhbmRhcmRdKGh0dHBzOi8vd3d3LnVuaWNvZGUub3JnL3ZlcnNpb25zLykuXG4gKiBVbmljb2RlIENvbnNvcnRpdW0uXG4gKlxuICogQHBhcmFtIGNvZGVcbiAqICAgQ29kZS5cbiAqIEByZXR1cm5zXG4gKiAgIFdoZXRoZXIgaXQgbWF0Y2hlcy5cbiAqL1xuZXhwb3J0IGNvbnN0IHVuaWNvZGVXaGl0ZXNwYWNlID0gcmVnZXhDaGVjaygvXFxzLylcblxuLyoqXG4gKiBDcmVhdGUgYSBjb2RlIGNoZWNrIGZyb20gYSByZWdleC5cbiAqXG4gKiBAcGFyYW0ge1JlZ0V4cH0gcmVnZXhcbiAqICAgRXhwcmVzc2lvbi5cbiAqIEByZXR1cm5zIHsoY29kZTogQ29kZSkgPT4gYm9vbGVhbn1cbiAqICAgQ2hlY2suXG4gKi9cbmZ1bmN0aW9uIHJlZ2V4Q2hlY2socmVnZXgpIHtcbiAgcmV0dXJuIGNoZWNrXG5cbiAgLyoqXG4gICAqIENoZWNrIHdoZXRoZXIgYSBjb2RlIG1hdGNoZXMgdGhlIGJvdW5kIHJlZ2V4LlxuICAgKlxuICAgKiBAcGFyYW0ge0NvZGV9IGNvZGVcbiAgICogICBDaGFyYWN0ZXIgY29kZS5cbiAgICogQHJldHVybnMge2Jvb2xlYW59XG4gICAqICAgV2hldGhlciB0aGUgY2hhcmFjdGVyIGNvZGUgbWF0Y2hlcyB0aGUgYm91bmQgcmVnZXguXG4gICAqL1xuICBmdW5jdGlvbiBjaGVjayhjb2RlKSB7XG4gICAgcmV0dXJuIGNvZGUgIT09IG51bGwgJiYgY29kZSA+IC0xICYmIHJlZ2V4LnRlc3QoU3RyaW5nLmZyb21DaGFyQ29kZShjb2RlKSlcbiAgfVxufVxuIiwiLyoqXG4gKiBAaW1wb3J0IHtFZmZlY3RzLCBTdGF0ZSwgVG9rZW5UeXBlfSBmcm9tICdtaWNyb21hcmstdXRpbC10eXBlcydcbiAqL1xuXG5pbXBvcnQge21hcmtkb3duU3BhY2V9IGZyb20gJ21pY3JvbWFyay11dGlsLWNoYXJhY3RlcidcblxuLy8gVG8gZG86IGltcGxlbWVudCBgc3BhY2VPclRhYmAsIGBzcGFjZU9yVGFiTWluTWF4YCwgYHNwYWNlT3JUYWJXaXRoT3B0aW9uc2AuXG5cbi8qKlxuICogUGFyc2Ugc3BhY2VzIGFuZCB0YWJzLlxuICpcbiAqIFRoZXJlIGlzIG5vIGBub2tgIHBhcmFtZXRlcjpcbiAqXG4gKiAqICAgc3BhY2VzIGluIG1hcmtkb3duIGFyZSBvZnRlbiBvcHRpb25hbCwgaW4gd2hpY2ggY2FzZSB0aGlzIGZhY3RvcnkgY2FuIGJlXG4gKiAgICAgdXNlZCBhbmQgYG9rYCB3aWxsIGJlIHN3aXRjaGVkIHRvIHdoZXRoZXIgc3BhY2VzIHdlcmUgZm91bmQgb3Igbm90XG4gKiAqICAgb25lIGxpbmUgZW5kaW5nIG9yIHNwYWNlIGNhbiBiZSBkZXRlY3RlZCB3aXRoIGBtYXJrZG93blNwYWNlKGNvZGUpYCByaWdodFxuICogICAgIGJlZm9yZSB1c2luZyBgZmFjdG9yeVNwYWNlYFxuICpcbiAqICMjIyMjIyBFeGFtcGxlc1xuICpcbiAqIFdoZXJlIGDikIlgIHJlcHJlc2VudHMgYSB0YWIgKHBsdXMgaG93IG11Y2ggaXQgZXhwYW5kcykgYW5kIGDikKBgIHJlcHJlc2VudHMgYVxuICogc2luZ2xlIHNwYWNlLlxuICpcbiAqIGBgYG1hcmtkb3duXG4gKiDikIlcbiAqIOKQoOKQoOKQoOKQoFxuICog4pCJ4pCgXG4gKiBgYGBcbiAqXG4gKiBAcGFyYW0ge0VmZmVjdHN9IGVmZmVjdHNcbiAqICAgQ29udGV4dC5cbiAqIEBwYXJhbSB7U3RhdGV9IG9rXG4gKiAgIFN0YXRlIHN3aXRjaGVkIHRvIHdoZW4gc3VjY2Vzc2Z1bC5cbiAqIEBwYXJhbSB7VG9rZW5UeXBlfSB0eXBlXG4gKiAgIFR5cGUgKGAnIFxcdCdgKS5cbiAqIEBwYXJhbSB7bnVtYmVyIHwgdW5kZWZpbmVkfSBbbWF4PUluZmluaXR5XVxuICogICBNYXggKGV4Y2x1c2l2ZSkuXG4gKiBAcmV0dXJucyB7U3RhdGV9XG4gKiAgIFN0YXJ0IHN0YXRlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmFjdG9yeVNwYWNlKGVmZmVjdHMsIG9rLCB0eXBlLCBtYXgpIHtcbiAgY29uc3QgbGltaXQgPSBtYXggPyBtYXggLSAxIDogTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZXG4gIGxldCBzaXplID0gMFxuXG4gIHJldHVybiBzdGFydFxuXG4gIC8qKiBAdHlwZSB7U3RhdGV9ICovXG4gIGZ1bmN0aW9uIHN0YXJ0KGNvZGUpIHtcbiAgICBpZiAobWFya2Rvd25TcGFjZShjb2RlKSkge1xuICAgICAgZWZmZWN0cy5lbnRlcih0eXBlKVxuICAgICAgcmV0dXJuIHByZWZpeChjb2RlKVxuICAgIH1cblxuICAgIHJldHVybiBvayhjb2RlKVxuICB9XG5cbiAgLyoqIEB0eXBlIHtTdGF0ZX0gKi9cbiAgZnVuY3Rpb24gcHJlZml4KGNvZGUpIHtcbiAgICBpZiAobWFya2Rvd25TcGFjZShjb2RlKSAmJiBzaXplKysgPCBsaW1pdCkge1xuICAgICAgZWZmZWN0cy5jb25zdW1lKGNvZGUpXG4gICAgICByZXR1cm4gcHJlZml4XG4gICAgfVxuXG4gICAgZWZmZWN0cy5leGl0KHR5cGUpXG4gICAgcmV0dXJuIG9rKGNvZGUpXG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6IjtBQU9BLElBQU0saUJBQU4sY0FBNkIsTUFBTTtDQUNqQyxPQUE2QjtDQUM3QixPQUE2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQjdCLFlBQVksU0FBUyxRQUFRLFVBQVUsVUFBVSxXQUFXO0VBQzFELE1BQU0sT0FBTztFQUViLElBQUksTUFBTSxtQkFDUixNQUFNLGtCQUFrQixNQUFNLEtBQUssV0FBVzs7OztFQU1oRCxLQUFLLFNBQVM7Ozs7RUFLZCxLQUFLLFdBQVc7Ozs7RUFLaEIsS0FBSyxZQUFZOzs7O0VBS2pCLEtBQUssV0FBVztDQUNsQjtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0FBNkhBLFNBQWdCLEdBQUcsT0FBTyxTQUFTO0NBQ2pDLE9BQ0UsUUFBUSxLQUFLLEdBQ2IsT0FDQSxNQUNBLE1BQ0EsK0JBQ0EsT0FDRjtBQUNGOzs7Ozs7Ozs7Ozs7OztBQWVBLFNBQWdCLFlBQVksU0FBUztDQUNuQyxPQUFPLE9BQU8sT0FBTyxNQUFNLE1BQU0sZUFBZSxPQUFPO0FBQ3pEOzs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxTQUFTLE9BQU8sTUFBTSxRQUFRLFVBQVUsVUFBVSxnQkFBZ0IsYUFBYTtDQUM3RSxJQUFJLENBQUMsTUFDSCxNQUFNLHVCQUF1QixRQUN6QixjQUNBLElBQUksZUFDRixlQUFlLGdCQUNmLFFBQ0EsVUFDQSxVQUNBLENBQUMsV0FDSDtBQUVSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzTkEsSUFBYSxRQUE4QjtDQUN6QyxnQkFBZ0I7Q0FDaEIsVUFBVTtDQUNWLHdCQUF3QjtDQUN4QixlQUFlO0NBQ2YsY0FBYztDQUNkLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsSUFBSTtDQUNKLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLE9BQU87Q0FDUCxpQkFBaUI7Q0FDakIsZUFBZTtDQUNmLFlBQVk7Q0FDWixZQUFZO0NBQ1osYUFBYTtDQUNiLFdBQVc7Q0FDWCxZQUFZO0NBQ1osaUJBQWlCO0NBQ2pCLGtCQUFrQjtDQUNsQixVQUFVO0NBQ1YsVUFBVTtDQUNWLE9BQU87Q0FDUCxNQUFNO0NBQ04sS0FBSztDQUNMLE9BQU87Q0FDUCxRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixRQUFRO0NBQ1IsUUFBUTtDQUNSLFFBQVE7Q0FDUixRQUFRO0NBQ1IsT0FBTztDQUNQLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsVUFBVTtDQUNWLGFBQWE7Q0FDYixjQUFjO0NBQ2QsUUFBUTtDQUNSLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osbUJBQW1CO0NBQ25CLFdBQVc7Q0FDWCxvQkFBb0I7Q0FDcEIsT0FBTztDQUNQLFlBQVk7Q0FDWixhQUFhO0NBQ2IsWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtDQUNaLFlBQVk7Q0FDWixnQkFBZ0I7Q0FDaEIsYUFBYTtDQUNiLGlCQUFpQjtDQUNqQixPQUFPO0NBQ1AsS0FBSztDQUVMLGlCQUFpQjtDQUVqQixzQkFBc0I7QUFDeEI7Ozs7Ozs7Ozs7O0FDckpBLElBQWEsWUFBa0M7Q0FDN0Msb0JBQW9CO0NBQ3BCLHFCQUFxQjtDQUNyQiwrQkFBK0I7Q0FDL0IsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2QixvQkFBb0I7Q0FDcEIsMkJBQTJCO0NBQzNCLDBCQUEwQjtDQUMxQixrQ0FBa0M7Q0FDbEMsc0NBQXNDO0NBQ3RDLGdDQUFnQztDQUNoQywyQkFBMkI7Q0FDM0Isb0JBQW9CO0NBQ3BCLHFCQUFxQjtDQUNyQixpQkFBaUI7Q0FDakIsbUJBQW1CO0NBQ25CLGlCQUFpQjtDQUNqQix3QkFBd0I7Q0FDeEIsV0FBVztDQUNYLFdBQVc7Q0FDWCxhQUFhO0NBQ2IsY0FBYztDQUNkLGlCQUFpQjtDQUNqQixpQkFBaUI7Q0FDakIsZ0JBQWdCO0NBQ2hCLFNBQVM7Q0FDVCxtQ0FBbUM7Q0FDbkMsc0JBQXNCO0NBQ3RCLHNCQUFzQjtDQUN0QixvQkFBb0I7Q0FDcEIsd0JBQXdCO0NBQ3hCLFNBQVM7Q0FDVCw2QkFBNkI7Q0FDN0Isb0JBQW9CO0FBQ3RCOzs7Ozs7Ozs7Ozs7O0FDOUJBLElBQWEsUUFBOEI7Q0FFekMsTUFBTTtDQUlOLFlBQVk7Q0FJWixZQUFZO0NBR1osaUJBQWlCO0NBSWpCLFlBQVk7Q0FJWixZQUFZO0NBV1osWUFBWTtDQUdaLG9CQUFvQjtDQUlwQixnQkFBZ0I7Q0FJaEIsVUFBVTtDQUdWLGVBQWU7Q0FHZixnQkFBZ0I7Q0FHaEIsa0JBQWtCO0NBSWxCLGlCQUFpQjtDQUdqQixzQkFBc0I7Q0FNdEIsb0JBQW9CO0NBR3BCLDBCQUEwQjtDQUcxQixpQ0FBaUM7Q0FHakMscUNBQXFDO0NBR3JDLHlCQUF5QjtDQVN6QixZQUFZO0NBSVosaUJBQWlCO0NBR2pCLHlCQUF5QjtDQUl6QixxQkFBcUI7Q0FJckIscUJBQXFCO0NBR3JCLGVBQWU7Q0FTZixjQUFjO0NBS2QsVUFBVTtDQUVWLGNBQWM7Q0FHZCxpQkFBaUI7Q0FHakIsa0JBQWtCO0NBWWxCLFNBQVM7Q0FTVCxZQUFZO0NBS1osdUJBQXVCO0NBTXZCLDhCQUE4QjtDQUc5QixvQ0FBb0M7Q0FLcEMsMEJBQTBCO0NBSTFCLDZCQUE2QjtDQUk3QixpQkFBaUI7Q0FHakIsdUJBQXVCO0NBSXZCLHVCQUF1QjtDQUd2QixrQkFBa0I7Q0FJbEIsaUJBQWlCO0NBR2pCLHVCQUF1QjtDQUl2Qix1QkFBdUI7Q0FJdkIsVUFBVTtDQUdWLGtCQUFrQjtDQUlsQixjQUFjO0NBR2QsY0FBYztDQUlkLGlCQUFpQjtDQUlqQixtQkFBbUI7Q0FTbkIsVUFBVTtDQUVWLGNBQWM7Q0FJZCxVQUFVO0NBRVYsY0FBYztDQUtkLE9BQU87Q0FJUCxPQUFPO0NBSVAsV0FBVztDQUlYLFdBQVc7Q0FJWCxZQUFZO0NBR1osYUFBYTtDQUdiLGtCQUFrQjtDQUlsQixVQUFVO0NBSVYsTUFBTTtDQVVOLFdBQVc7Q0FJWCxXQUFXO0NBR1gsaUJBQWlCO0NBSWpCLGlCQUFpQjtDQUtqQixVQUFVO0NBSVYscUJBQXFCO0NBS3JCLDRCQUE0QjtDQUc1QixrQ0FBa0M7Q0FJbEMsd0JBQXdCO0NBSXhCLDJCQUEyQjtDQUczQixnQkFBZ0I7Q0FJaEIsZUFBZTtDQUdmLHFCQUFxQjtDQUlyQixxQkFBcUI7Q0FZckIsZUFBZTtDQUlmLG1CQUFtQjtDQUluQixtQkFBbUI7Q0FHbkIsMkJBQTJCO0NBSTNCLFFBQVE7Q0FHUixnQkFBZ0I7Q0FJaEIsWUFBWTtDQVNaLGVBQWU7Q0FHZix1QkFBdUI7Q0FXdkIsWUFBWTtDQUVaLGtCQUFrQjtDQUVsQixrQkFBa0I7Q0FFbEIsNEJBQTRCO0NBVzVCLGFBQWE7Q0FXYixlQUFlO0NBR2YsZ0JBQWdCO0NBR2hCLGdCQUFnQjtDQUtoQixnQkFBZ0I7Q0FHaEIsMEJBQTBCO0NBRzFCLGVBQWU7Q0FHZixlQUFlO0NBQ2YsY0FBYztDQUNkLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsYUFBYTtBQUNmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdhQSxJQUFhLGFBQWEsV0FBVyxVQUFVOzs7Ozs7Ozs7Ozs7O0FBYy9DLElBQWEsb0JBQW9CLFdBQVcsWUFBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCeEQsSUFBYSxhQUFhLFdBQVcscUJBQXFCOzs7Ozs7Ozs7Ozs7QUFhMUQsU0FBZ0IsYUFBYSxNQUFNO0NBQ2pDLE9BR0UsU0FBUyxTQUFTLE9BQU8sTUFBTSxTQUFTLFNBQVMsTUFBTTtBQUUzRDs7Ozs7Ozs7Ozs7O0FBYUEsSUFBYSxhQUFhLFdBQVcsSUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9CekMsSUFBYSxnQkFBZ0IsV0FBVyxZQUFZOzs7Ozs7Ozs7Ozs7OztBQWVwRCxJQUFhLG1CQUFtQixXQUFXLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7OztBQWlCM0QsU0FBZ0IsbUJBQW1CLE1BQU07Q0FDdkMsT0FBTyxTQUFTLFFBQVEsT0FBTyxNQUFNO0FBQ3ZDOzs7Ozs7Ozs7O0FBV0EsU0FBZ0IsMEJBQTBCLE1BQU07Q0FDOUMsT0FBTyxTQUFTLFNBQVMsT0FBTyxNQUFNLE9BQU8sU0FBUyxNQUFNO0FBQzlEOzs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQWdCLGNBQWMsTUFBTTtDQUNsQyxPQUNFLFNBQVMsTUFBTSxpQkFDZixTQUFTLE1BQU0sZ0JBQ2YsU0FBUyxNQUFNO0FBRW5COzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCQSxJQUFhLHFCQUFxQixXQUFXLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNCM0QsSUFBYSxvQkFBb0IsV0FBVyxJQUFJOzs7Ozs7Ozs7QUFVaEQsU0FBUyxXQUFXLE9BQU87Q0FDekIsT0FBTzs7Ozs7Ozs7O0NBVVAsU0FBUyxNQUFNLE1BQU07RUFDbkIsT0FBTyxTQUFTLFFBQVEsT0FBTyxNQUFNLE1BQU0sS0FBSyxPQUFPLGFBQWEsSUFBSSxDQUFDO0NBQzNFO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbk5BLFNBQWdCLGFBQWEsU0FBUyxJQUFJLE1BQU0sS0FBSztDQUNuRCxNQUFNLFFBQVEsTUFBTSxNQUFNLElBQUksT0FBTztDQUNyQyxJQUFJLE9BQU87Q0FFWCxPQUFPOztDQUdQLFNBQVMsTUFBTSxNQUFNO0VBQ25CLElBQUksY0FBYyxJQUFJLEdBQUc7R0FDdkIsUUFBUSxNQUFNLElBQUk7R0FDbEIsT0FBTyxPQUFPLElBQUk7RUFDcEI7RUFFQSxPQUFPLEdBQUcsSUFBSTtDQUNoQjs7Q0FHQSxTQUFTLE9BQU8sTUFBTTtFQUNwQixJQUFJLGNBQWMsSUFBSSxLQUFLLFNBQVMsT0FBTztHQUN6QyxRQUFRLFFBQVEsSUFBSTtHQUNwQixPQUFPO0VBQ1Q7RUFFQSxRQUFRLEtBQUssSUFBSTtFQUNqQixPQUFPLEdBQUcsSUFBSTtDQUNoQjtBQUNGIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1XX0=