import { r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=076f3cfd";
//#endregion
//#region node_modules/dexie/import-wrapper.mjs
var import_dexie = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(global, factory) {
		typeof exports === "object" && typeof module !== "undefined" ? module.exports = factory() : typeof define === "function" && define.amd ? define(factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, global.Dexie = factory());
	})(exports, (function() {
		"use strict";
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		function __extends(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		}
		var __assign = function() {
			__assign = Object.assign || function __assign(t) {
				for (var s, i = 1, n = arguments.length; i < n; i++) {
					s = arguments[i];
					for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
				}
				return t;
			};
			return __assign.apply(this, arguments);
		};
		function __spreadArray(to, from, pack) {
			if (pack || arguments.length === 2) {
				for (var i = 0, l = from.length, ar; i < l; i++) if (ar || !(i in from)) {
					if (!ar) ar = Array.prototype.slice.call(from, 0, i);
					ar[i] = from[i];
				}
			}
			return to.concat(ar || Array.prototype.slice.call(from));
		}
		var _global = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
		var keys = Object.keys;
		var isArray = Array.isArray;
		if (typeof Promise !== "undefined" && !_global.Promise) _global.Promise = Promise;
		function extend(obj, extension) {
			if (typeof extension !== "object") return obj;
			keys(extension).forEach(function(key) {
				obj[key] = extension[key];
			});
			return obj;
		}
		var getProto = Object.getPrototypeOf;
		var _hasOwn = {}.hasOwnProperty;
		function hasOwn(obj, prop) {
			return _hasOwn.call(obj, prop);
		}
		function props(proto, extension) {
			if (typeof extension === "function") extension = extension(getProto(proto));
			(typeof Reflect === "undefined" ? keys : Reflect.ownKeys)(extension).forEach(function(key) {
				setProp(proto, key, extension[key]);
			});
		}
		var defineProperty = Object.defineProperty;
		function setProp(obj, prop, functionOrGetSet, options) {
			defineProperty(obj, prop, extend(functionOrGetSet && hasOwn(functionOrGetSet, "get") && typeof functionOrGetSet.get === "function" ? {
				get: functionOrGetSet.get,
				set: functionOrGetSet.set,
				configurable: true
			} : {
				value: functionOrGetSet,
				configurable: true,
				writable: true
			}, options));
		}
		function derive(Child) {
			return { from: function(Parent) {
				Child.prototype = Object.create(Parent.prototype);
				setProp(Child.prototype, "constructor", Child);
				return { extend: props.bind(null, Child.prototype) };
			} };
		}
		var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
		function getPropertyDescriptor(obj, prop) {
			var pd = getOwnPropertyDescriptor(obj, prop);
			var proto;
			return pd || (proto = getProto(obj)) && getPropertyDescriptor(proto, prop);
		}
		var _slice = [].slice;
		function slice(args, start, end) {
			return _slice.call(args, start, end);
		}
		function override(origFunc, overridedFactory) {
			return overridedFactory(origFunc);
		}
		function assert(b) {
			if (!b) throw new Error("Assertion Failed");
		}
		function asap$1(fn) {
			if (_global.setImmediate) setImmediate(fn);
			else setTimeout(fn, 0);
		}
		function arrayToObject(array, extractor) {
			return array.reduce(function(result, item, i) {
				var nameAndValue = extractor(item, i);
				if (nameAndValue) result[nameAndValue[0]] = nameAndValue[1];
				return result;
			}, {});
		}
		function getByKeyPath(obj, keyPath) {
			if (typeof keyPath === "string" && hasOwn(obj, keyPath)) return obj[keyPath];
			if (!keyPath) return obj;
			if (typeof keyPath !== "string") {
				var rv = [];
				for (var i = 0, l = keyPath.length; i < l; ++i) {
					var val = getByKeyPath(obj, keyPath[i]);
					rv.push(val);
				}
				return rv;
			}
			var period = keyPath.indexOf(".");
			if (period !== -1) {
				var innerObj = obj[keyPath.substr(0, period)];
				return innerObj == null ? void 0 : getByKeyPath(innerObj, keyPath.substr(period + 1));
			}
		}
		function setByKeyPath(obj, keyPath, value) {
			if (!obj || keyPath === void 0) return;
			if ("isFrozen" in Object && Object.isFrozen(obj)) return;
			if (typeof keyPath !== "string" && "length" in keyPath) {
				assert(typeof value !== "string" && "length" in value);
				for (var i = 0, l = keyPath.length; i < l; ++i) setByKeyPath(obj, keyPath[i], value[i]);
			} else {
				var period = keyPath.indexOf(".");
				if (period !== -1) {
					var currentKeyPath = keyPath.substr(0, period);
					var remainingKeyPath = keyPath.substr(period + 1);
					if (remainingKeyPath === "") if (value === void 0) {
						if (isArray(obj) && !isNaN(parseInt(currentKeyPath))) obj.splice(currentKeyPath, 1);
						else delete obj[currentKeyPath];
					} else obj[currentKeyPath] = value;
					else {
						var innerObj = obj[currentKeyPath];
						if (!innerObj || !hasOwn(obj, currentKeyPath)) {
							if (value === void 0) return;
							innerObj = obj[currentKeyPath] = {};
						}
						setByKeyPath(innerObj, remainingKeyPath, value);
					}
				} else if (value === void 0) {
					if (isArray(obj) && !isNaN(parseInt(keyPath))) obj.splice(keyPath, 1);
					else delete obj[keyPath];
				} else obj[keyPath] = value;
			}
		}
		function delByKeyPath(obj, keyPath) {
			if (typeof keyPath === "string") setByKeyPath(obj, keyPath, void 0);
			else if ("length" in keyPath) [].map.call(keyPath, function(kp) {
				setByKeyPath(obj, kp, void 0);
			});
		}
		function shallowClone(obj) {
			var rv = {};
			for (var m in obj) if (hasOwn(obj, m)) rv[m] = obj[m];
			return rv;
		}
		var concat = [].concat;
		function flatten(a) {
			return concat.apply([], a);
		}
		var intrinsicTypeNames = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(flatten([
			8,
			16,
			32,
			64
		].map(function(num) {
			return [
				"Int",
				"Uint",
				"Float"
			].map(function(t) {
				return t + num + "Array";
			});
		}))).filter(function(t) {
			return _global[t];
		});
		var intrinsicTypes = new Set(intrinsicTypeNames.map(function(t) {
			return _global[t];
		}));
		function cloneSimpleObjectTree(o) {
			var rv = {};
			for (var k in o) if (hasOwn(o, k)) {
				var v = o[k];
				rv[k] = !v || typeof v !== "object" || intrinsicTypes.has(v.constructor) ? v : cloneSimpleObjectTree(v);
			}
			return rv;
		}
		var circularRefs = null;
		function deepClone(any) {
			circularRefs = /* @__PURE__ */ new WeakMap();
			var rv = innerDeepClone(any);
			circularRefs = null;
			return rv;
		}
		function innerDeepClone(x) {
			if (!x || typeof x !== "object") return x;
			var rv = circularRefs.get(x);
			if (rv) return rv;
			if (isArray(x)) {
				rv = [];
				circularRefs.set(x, rv);
				for (var i = 0, l = x.length; i < l; ++i) rv.push(innerDeepClone(x[i]));
			} else if (intrinsicTypes.has(x.constructor)) rv = x;
			else {
				var proto = getProto(x);
				rv = proto === Object.prototype ? {} : Object.create(proto);
				circularRefs.set(x, rv);
				for (var prop in x) if (hasOwn(x, prop)) rv[prop] = innerDeepClone(x[prop]);
			}
			return rv;
		}
		var toString = {}.toString;
		function toStringTag(o) {
			return toString.call(o).slice(8, -1);
		}
		var iteratorSymbol = typeof Symbol !== "undefined" ? Symbol.iterator : "@@iterator";
		var getIteratorOf = typeof iteratorSymbol === "symbol" ? function(x) {
			var i;
			return x != null && (i = x[iteratorSymbol]) && i.apply(x);
		} : function() {
			return null;
		};
		function delArrayItem(a, x) {
			var i = a.indexOf(x);
			if (i >= 0) a.splice(i, 1);
			return i >= 0;
		}
		var NO_CHAR_ARRAY = {};
		function getArrayOf(arrayLike) {
			var i, a, x, it;
			if (arguments.length === 1) {
				if (isArray(arrayLike)) return arrayLike.slice();
				if (this === NO_CHAR_ARRAY && typeof arrayLike === "string") return [arrayLike];
				if (it = getIteratorOf(arrayLike)) {
					a = [];
					while (x = it.next(), !x.done) a.push(x.value);
					return a;
				}
				if (arrayLike == null) return [arrayLike];
				i = arrayLike.length;
				if (typeof i === "number") {
					a = new Array(i);
					while (i--) a[i] = arrayLike[i];
					return a;
				}
				return [arrayLike];
			}
			i = arguments.length;
			a = new Array(i);
			while (i--) a[i] = arguments[i];
			return a;
		}
		var isAsyncFunction = typeof Symbol !== "undefined" ? function(fn) {
			return fn[Symbol.toStringTag] === "AsyncFunction";
		} : function() {
			return false;
		};
		var dexieErrorNames = [
			"Modify",
			"Bulk",
			"OpenFailed",
			"VersionChange",
			"Schema",
			"Upgrade",
			"InvalidTable",
			"MissingAPI",
			"NoSuchDatabase",
			"InvalidArgument",
			"SubTransaction",
			"Unsupported",
			"Internal",
			"DatabaseClosed",
			"PrematureCommit",
			"ForeignAwait"
		];
		var idbDomErrorNames = [
			"Unknown",
			"Constraint",
			"Data",
			"TransactionInactive",
			"ReadOnly",
			"Version",
			"NotFound",
			"InvalidState",
			"InvalidAccess",
			"Abort",
			"Timeout",
			"QuotaExceeded",
			"Syntax",
			"DataClone"
		];
		var errorList = dexieErrorNames.concat(idbDomErrorNames);
		var defaultTexts = {
			VersionChanged: "Database version changed by other database connection",
			DatabaseClosed: "Database has been closed",
			Abort: "Transaction aborted",
			TransactionInactive: "Transaction has already completed or failed",
			MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
		};
		function DexieError(name, msg) {
			this.name = name;
			this.message = msg;
		}
		derive(DexieError).from(Error).extend({ toString: function() {
			return this.name + ": " + this.message;
		} });
		function getMultiErrorMessage(msg, failures) {
			return msg + ". Errors: " + Object.keys(failures).map(function(key) {
				return failures[key].toString();
			}).filter(function(v, i, s) {
				return s.indexOf(v) === i;
			}).join("\n");
		}
		function ModifyError(msg, failures, successCount, failedKeys) {
			this.failures = failures;
			this.failedKeys = failedKeys;
			this.successCount = successCount;
			this.message = getMultiErrorMessage(msg, failures);
		}
		derive(ModifyError).from(DexieError);
		function BulkError(msg, failures) {
			this.name = "BulkError";
			this.failures = Object.keys(failures).map(function(pos) {
				return failures[pos];
			});
			this.failuresByPos = failures;
			this.message = getMultiErrorMessage(msg, this.failures);
		}
		derive(BulkError).from(DexieError);
		var errnames = errorList.reduce(function(obj, name) {
			return obj[name] = name + "Error", obj;
		}, {});
		var BaseException = DexieError;
		var exceptions = errorList.reduce(function(obj, name) {
			var fullName = name + "Error";
			function DexieError(msgOrInner, inner) {
				this.name = fullName;
				if (!msgOrInner) {
					this.message = defaultTexts[name] || fullName;
					this.inner = null;
				} else if (typeof msgOrInner === "string") {
					this.message = "".concat(msgOrInner).concat(!inner ? "" : "\n " + inner);
					this.inner = inner || null;
				} else if (typeof msgOrInner === "object") {
					this.message = "".concat(msgOrInner.name, " ").concat(msgOrInner.message);
					this.inner = msgOrInner;
				}
			}
			derive(DexieError).from(BaseException);
			obj[name] = DexieError;
			return obj;
		}, {});
		exceptions.Syntax = SyntaxError;
		exceptions.Type = TypeError;
		exceptions.Range = RangeError;
		var exceptionMap = idbDomErrorNames.reduce(function(obj, name) {
			obj[name + "Error"] = exceptions[name];
			return obj;
		}, {});
		function mapError(domError, message) {
			if (!domError || domError instanceof DexieError || domError instanceof TypeError || domError instanceof SyntaxError || !domError.name || !exceptionMap[domError.name]) return domError;
			var rv = new exceptionMap[domError.name](message || domError.message, domError);
			if ("stack" in domError) setProp(rv, "stack", { get: function() {
				return this.inner.stack;
			} });
			return rv;
		}
		var fullNameExceptions = errorList.reduce(function(obj, name) {
			if ([
				"Syntax",
				"Type",
				"Range"
			].indexOf(name) === -1) obj[name + "Error"] = exceptions[name];
			return obj;
		}, {});
		fullNameExceptions.ModifyError = ModifyError;
		fullNameExceptions.DexieError = DexieError;
		fullNameExceptions.BulkError = BulkError;
		function nop() {}
		function mirror(val) {
			return val;
		}
		function pureFunctionChain(f1, f2) {
			if (f1 == null || f1 === mirror) return f2;
			return function(val) {
				return f2(f1(val));
			};
		}
		function callBoth(on1, on2) {
			return function() {
				on1.apply(this, arguments);
				on2.apply(this, arguments);
			};
		}
		function hookCreatingChain(f1, f2) {
			if (f1 === nop) return f2;
			return function() {
				var res = f1.apply(this, arguments);
				if (res !== void 0) arguments[0] = res;
				var onsuccess = this.onsuccess, onerror = this.onerror;
				this.onsuccess = null;
				this.onerror = null;
				var res2 = f2.apply(this, arguments);
				if (onsuccess) this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
				if (onerror) this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
				return res2 !== void 0 ? res2 : res;
			};
		}
		function hookDeletingChain(f1, f2) {
			if (f1 === nop) return f2;
			return function() {
				f1.apply(this, arguments);
				var onsuccess = this.onsuccess, onerror = this.onerror;
				this.onsuccess = this.onerror = null;
				f2.apply(this, arguments);
				if (onsuccess) this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
				if (onerror) this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
			};
		}
		function hookUpdatingChain(f1, f2) {
			if (f1 === nop) return f2;
			return function(modifications) {
				var res = f1.apply(this, arguments);
				extend(modifications, res);
				var onsuccess = this.onsuccess, onerror = this.onerror;
				this.onsuccess = null;
				this.onerror = null;
				var res2 = f2.apply(this, arguments);
				if (onsuccess) this.onsuccess = this.onsuccess ? callBoth(onsuccess, this.onsuccess) : onsuccess;
				if (onerror) this.onerror = this.onerror ? callBoth(onerror, this.onerror) : onerror;
				return res === void 0 ? res2 === void 0 ? void 0 : res2 : extend(res, res2);
			};
		}
		function reverseStoppableEventChain(f1, f2) {
			if (f1 === nop) return f2;
			return function() {
				if (f2.apply(this, arguments) === false) return false;
				return f1.apply(this, arguments);
			};
		}
		function promisableChain(f1, f2) {
			if (f1 === nop) return f2;
			return function() {
				var res = f1.apply(this, arguments);
				if (res && typeof res.then === "function") {
					var thiz = this, i = arguments.length, args = new Array(i);
					while (i--) args[i] = arguments[i];
					return res.then(function() {
						return f2.apply(thiz, args);
					});
				}
				return f2.apply(this, arguments);
			};
		}
		var debug = typeof location !== "undefined" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
		function setDebug(value, filter) {
			debug = value;
		}
		var INTERNAL = {};
		var ZONE_ECHO_LIMIT = 100, _a$1 = typeof Promise === "undefined" ? [] : (function() {
			var globalP = Promise.resolve();
			if (typeof crypto === "undefined" || !crypto.subtle) return [
				globalP,
				getProto(globalP),
				globalP
			];
			var nativeP = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
			return [
				nativeP,
				getProto(nativeP),
				globalP
			];
		})(), resolvedNativePromise = _a$1[0], nativePromiseProto = _a$1[1], resolvedGlobalPromise = _a$1[2], nativePromiseThen = nativePromiseProto && nativePromiseProto.then;
		var NativePromise = resolvedNativePromise && resolvedNativePromise.constructor;
		var patchGlobalPromise = !!resolvedGlobalPromise;
		function schedulePhysicalTick() {
			queueMicrotask(physicalTick);
		}
		var asap = function(callback, args) {
			microtickQueue.push([callback, args]);
			if (needsNewPhysicalTick) {
				schedulePhysicalTick();
				needsNewPhysicalTick = false;
			}
		};
		var isOutsideMicroTick = true, needsNewPhysicalTick = true, unhandledErrors = [], rejectingErrors = [], rejectionMapper = mirror;
		var globalPSD = {
			id: "global",
			global: true,
			ref: 0,
			unhandleds: [],
			onunhandled: nop,
			pgp: false,
			env: {},
			finalize: nop
		};
		var PSD = globalPSD;
		var microtickQueue = [];
		var numScheduledCalls = 0;
		var tickFinalizers = [];
		function DexiePromise(fn) {
			if (typeof this !== "object") throw new TypeError("Promises must be constructed via new");
			this._listeners = [];
			this._lib = false;
			var psd = this._PSD = PSD;
			if (typeof fn !== "function") {
				if (fn !== INTERNAL) throw new TypeError("Not a function");
				this._state = arguments[1];
				this._value = arguments[2];
				if (this._state === false) handleRejection(this, this._value);
				return;
			}
			this._state = null;
			this._value = null;
			++psd.ref;
			executePromiseTask(this, fn);
		}
		var thenProp = {
			get: function() {
				var psd = PSD, microTaskId = totalEchoes;
				function then(onFulfilled, onRejected) {
					var _this = this;
					var possibleAwait = !psd.global && (psd !== PSD || microTaskId !== totalEchoes);
					var cleanup = possibleAwait && !decrementExpectedAwaits();
					var rv = new DexiePromise(function(resolve, reject) {
						propagateToListener(_this, new Listener(nativeAwaitCompatibleWrap(onFulfilled, psd, possibleAwait, cleanup), nativeAwaitCompatibleWrap(onRejected, psd, possibleAwait, cleanup), resolve, reject, psd));
					});
					if (this._consoleTask) rv._consoleTask = this._consoleTask;
					return rv;
				}
				then.prototype = INTERNAL;
				return then;
			},
			set: function(value) {
				setProp(this, "then", value && value.prototype === INTERNAL ? thenProp : {
					get: function() {
						return value;
					},
					set: thenProp.set
				});
			}
		};
		props(DexiePromise.prototype, {
			then: thenProp,
			_then: function(onFulfilled, onRejected) {
				propagateToListener(this, new Listener(null, null, onFulfilled, onRejected, PSD));
			},
			catch: function(onRejected) {
				if (arguments.length === 1) return this.then(null, onRejected);
				var type = arguments[0], handler = arguments[1];
				return typeof type === "function" ? this.then(null, function(err) {
					return err instanceof type ? handler(err) : PromiseReject(err);
				}) : this.then(null, function(err) {
					return err && err.name === type ? handler(err) : PromiseReject(err);
				});
			},
			finally: function(onFinally) {
				return this.then(function(value) {
					return DexiePromise.resolve(onFinally()).then(function() {
						return value;
					});
				}, function(err) {
					return DexiePromise.resolve(onFinally()).then(function() {
						return PromiseReject(err);
					});
				});
			},
			timeout: function(ms, msg) {
				var _this = this;
				return ms < Infinity ? new DexiePromise(function(resolve, reject) {
					var handle = setTimeout(function() {
						return reject(new exceptions.Timeout(msg));
					}, ms);
					_this.then(resolve, reject).finally(clearTimeout.bind(null, handle));
				}) : this;
			}
		});
		if (typeof Symbol !== "undefined" && Symbol.toStringTag) setProp(DexiePromise.prototype, Symbol.toStringTag, "Dexie.Promise");
		globalPSD.env = snapShot();
		function Listener(onFulfilled, onRejected, resolve, reject, zone) {
			this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
			this.onRejected = typeof onRejected === "function" ? onRejected : null;
			this.resolve = resolve;
			this.reject = reject;
			this.psd = zone;
		}
		props(DexiePromise, {
			all: function() {
				var values = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
				return new DexiePromise(function(resolve, reject) {
					if (values.length === 0) resolve([]);
					var remaining = values.length;
					values.forEach(function(a, i) {
						return DexiePromise.resolve(a).then(function(x) {
							values[i] = x;
							if (!--remaining) resolve(values);
						}, reject);
					});
				});
			},
			resolve: function(value) {
				if (value instanceof DexiePromise) return value;
				if (value && typeof value.then === "function") return new DexiePromise(function(resolve, reject) {
					value.then(resolve, reject);
				});
				return new DexiePromise(INTERNAL, true, value);
			},
			reject: PromiseReject,
			race: function() {
				var values = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
				return new DexiePromise(function(resolve, reject) {
					values.map(function(value) {
						return DexiePromise.resolve(value).then(resolve, reject);
					});
				});
			},
			PSD: {
				get: function() {
					return PSD;
				},
				set: function(value) {
					return PSD = value;
				}
			},
			totalEchoes: { get: function() {
				return totalEchoes;
			} },
			newPSD: newScope,
			usePSD,
			scheduler: {
				get: function() {
					return asap;
				},
				set: function(value) {
					asap = value;
				}
			},
			rejectionMapper: {
				get: function() {
					return rejectionMapper;
				},
				set: function(value) {
					rejectionMapper = value;
				}
			},
			follow: function(fn, zoneProps) {
				return new DexiePromise(function(resolve, reject) {
					return newScope(function(resolve, reject) {
						var psd = PSD;
						psd.unhandleds = [];
						psd.onunhandled = reject;
						psd.finalize = callBoth(function() {
							var _this = this;
							run_at_end_of_this_or_next_physical_tick(function() {
								_this.unhandleds.length === 0 ? resolve() : reject(_this.unhandleds[0]);
							});
						}, psd.finalize);
						fn();
					}, zoneProps, resolve, reject);
				});
			}
		});
		if (NativePromise) {
			if (NativePromise.allSettled) setProp(DexiePromise, "allSettled", function() {
				var possiblePromises = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
				return new DexiePromise(function(resolve) {
					if (possiblePromises.length === 0) resolve([]);
					var remaining = possiblePromises.length;
					var results = new Array(remaining);
					possiblePromises.forEach(function(p, i) {
						return DexiePromise.resolve(p).then(function(value) {
							return results[i] = {
								status: "fulfilled",
								value
							};
						}, function(reason) {
							return results[i] = {
								status: "rejected",
								reason
							};
						}).then(function() {
							return --remaining || resolve(results);
						});
					});
				});
			});
			if (NativePromise.any && typeof AggregateError !== "undefined") setProp(DexiePromise, "any", function() {
				var possiblePromises = getArrayOf.apply(null, arguments).map(onPossibleParallellAsync);
				return new DexiePromise(function(resolve, reject) {
					if (possiblePromises.length === 0) reject(/* @__PURE__ */ new AggregateError([]));
					var remaining = possiblePromises.length;
					var failures = new Array(remaining);
					possiblePromises.forEach(function(p, i) {
						return DexiePromise.resolve(p).then(function(value) {
							return resolve(value);
						}, function(failure) {
							failures[i] = failure;
							if (!--remaining) reject(new AggregateError(failures));
						});
					});
				});
			});
			if (NativePromise.withResolvers) DexiePromise.withResolvers = NativePromise.withResolvers;
		}
		function executePromiseTask(promise, fn) {
			try {
				fn(function(value) {
					if (promise._state !== null) return;
					if (value === promise) throw new TypeError("A promise cannot be resolved with itself.");
					var shouldExecuteTick = promise._lib && beginMicroTickScope();
					if (value && typeof value.then === "function") executePromiseTask(promise, function(resolve, reject) {
						value instanceof DexiePromise ? value._then(resolve, reject) : value.then(resolve, reject);
					});
					else {
						promise._state = true;
						promise._value = value;
						propagateAllListeners(promise);
					}
					if (shouldExecuteTick) endMicroTickScope();
				}, handleRejection.bind(null, promise));
			} catch (ex) {
				handleRejection(promise, ex);
			}
		}
		function handleRejection(promise, reason) {
			rejectingErrors.push(reason);
			if (promise._state !== null) return;
			var shouldExecuteTick = promise._lib && beginMicroTickScope();
			reason = rejectionMapper(reason);
			promise._state = false;
			promise._value = reason;
			addPossiblyUnhandledError(promise);
			propagateAllListeners(promise);
			if (shouldExecuteTick) endMicroTickScope();
		}
		function propagateAllListeners(promise) {
			var listeners = promise._listeners;
			promise._listeners = [];
			for (var i = 0, len = listeners.length; i < len; ++i) propagateToListener(promise, listeners[i]);
			var psd = promise._PSD;
			--psd.ref || psd.finalize();
			if (numScheduledCalls === 0) {
				++numScheduledCalls;
				asap(function() {
					if (--numScheduledCalls === 0) finalizePhysicalTick();
				}, []);
			}
		}
		function propagateToListener(promise, listener) {
			if (promise._state === null) {
				promise._listeners.push(listener);
				return;
			}
			var cb = promise._state ? listener.onFulfilled : listener.onRejected;
			if (cb === null) return (promise._state ? listener.resolve : listener.reject)(promise._value);
			++listener.psd.ref;
			++numScheduledCalls;
			asap(callListener, [
				cb,
				promise,
				listener
			]);
		}
		function callListener(cb, promise, listener) {
			try {
				var ret, value = promise._value;
				if (!promise._state && rejectingErrors.length) rejectingErrors = [];
				ret = debug && promise._consoleTask ? promise._consoleTask.run(function() {
					return cb(value);
				}) : cb(value);
				if (!promise._state && rejectingErrors.indexOf(value) === -1) markErrorAsHandled(promise);
				listener.resolve(ret);
			} catch (e) {
				listener.reject(e);
			} finally {
				if (--numScheduledCalls === 0) finalizePhysicalTick();
				--listener.psd.ref || listener.psd.finalize();
			}
		}
		function physicalTick() {
			usePSD(globalPSD, function() {
				beginMicroTickScope() && endMicroTickScope();
			});
		}
		function beginMicroTickScope() {
			var wasRootExec = isOutsideMicroTick;
			isOutsideMicroTick = false;
			needsNewPhysicalTick = false;
			return wasRootExec;
		}
		function endMicroTickScope() {
			var callbacks, i, l;
			do
				while (microtickQueue.length > 0) {
					callbacks = microtickQueue;
					microtickQueue = [];
					l = callbacks.length;
					for (i = 0; i < l; ++i) {
						var item = callbacks[i];
						item[0].apply(null, item[1]);
					}
				}
			while (microtickQueue.length > 0);
			isOutsideMicroTick = true;
			needsNewPhysicalTick = true;
		}
		function finalizePhysicalTick() {
			var unhandledErrs = unhandledErrors;
			unhandledErrors = [];
			unhandledErrs.forEach(function(p) {
				p._PSD.onunhandled.call(null, p._value, p);
			});
			var finalizers = tickFinalizers.slice(0);
			var i = finalizers.length;
			while (i) finalizers[--i]();
		}
		function run_at_end_of_this_or_next_physical_tick(fn) {
			function finalizer() {
				fn();
				tickFinalizers.splice(tickFinalizers.indexOf(finalizer), 1);
			}
			tickFinalizers.push(finalizer);
			++numScheduledCalls;
			asap(function() {
				if (--numScheduledCalls === 0) finalizePhysicalTick();
			}, []);
		}
		function addPossiblyUnhandledError(promise) {
			if (!unhandledErrors.some(function(p) {
				return p._value === promise._value;
			})) unhandledErrors.push(promise);
		}
		function markErrorAsHandled(promise) {
			var i = unhandledErrors.length;
			while (i) if (unhandledErrors[--i]._value === promise._value) {
				unhandledErrors.splice(i, 1);
				return;
			}
		}
		function PromiseReject(reason) {
			return new DexiePromise(INTERNAL, false, reason);
		}
		function wrap(fn, errorCatcher) {
			var psd = PSD;
			return function() {
				var wasRootExec = beginMicroTickScope(), outerScope = PSD;
				try {
					switchToZone(psd, true);
					return fn.apply(this, arguments);
				} catch (e) {
					errorCatcher && errorCatcher(e);
				} finally {
					switchToZone(outerScope, false);
					if (wasRootExec) endMicroTickScope();
				}
			};
		}
		var task = {
			awaits: 0,
			echoes: 0,
			id: 0
		};
		var taskCounter = 0;
		var zoneStack = [];
		var zoneEchoes = 0;
		var totalEchoes = 0;
		var zone_id_counter = 0;
		function newScope(fn, props, a1, a2) {
			var parent = PSD, psd = Object.create(parent);
			psd.parent = parent;
			psd.ref = 0;
			psd.global = false;
			psd.id = ++zone_id_counter;
			globalPSD.env;
			psd.env = patchGlobalPromise ? {
				Promise: DexiePromise,
				PromiseProp: {
					value: DexiePromise,
					configurable: true,
					writable: true
				},
				all: DexiePromise.all,
				race: DexiePromise.race,
				allSettled: DexiePromise.allSettled,
				any: DexiePromise.any,
				resolve: DexiePromise.resolve,
				reject: DexiePromise.reject
			} : {};
			if (props) extend(psd, props);
			++parent.ref;
			psd.finalize = function() {
				--this.parent.ref || this.parent.finalize();
			};
			var rv = usePSD(psd, fn, a1, a2);
			if (psd.ref === 0) psd.finalize();
			return rv;
		}
		function incrementExpectedAwaits() {
			if (!task.id) task.id = ++taskCounter;
			++task.awaits;
			task.echoes += ZONE_ECHO_LIMIT;
			return task.id;
		}
		function decrementExpectedAwaits() {
			if (!task.awaits) return false;
			if (--task.awaits === 0) task.id = 0;
			task.echoes = task.awaits * ZONE_ECHO_LIMIT;
			return true;
		}
		if (("" + nativePromiseThen).indexOf("[native code]") === -1) incrementExpectedAwaits = decrementExpectedAwaits = nop;
		function onPossibleParallellAsync(possiblePromise) {
			if (task.echoes && possiblePromise && possiblePromise.constructor === NativePromise) {
				incrementExpectedAwaits();
				return possiblePromise.then(function(x) {
					decrementExpectedAwaits();
					return x;
				}, function(e) {
					decrementExpectedAwaits();
					return rejection(e);
				});
			}
			return possiblePromise;
		}
		function zoneEnterEcho(targetZone) {
			++totalEchoes;
			if (!task.echoes || --task.echoes === 0) task.echoes = task.awaits = task.id = 0;
			zoneStack.push(PSD);
			switchToZone(targetZone, true);
		}
		function zoneLeaveEcho() {
			var zone = zoneStack[zoneStack.length - 1];
			zoneStack.pop();
			switchToZone(zone, false);
		}
		function switchToZone(targetZone, bEnteringZone) {
			var currentZone = PSD;
			if (bEnteringZone ? task.echoes && (!zoneEchoes++ || targetZone !== PSD) : zoneEchoes && (!--zoneEchoes || targetZone !== PSD)) queueMicrotask(bEnteringZone ? zoneEnterEcho.bind(null, targetZone) : zoneLeaveEcho);
			if (targetZone === PSD) return;
			PSD = targetZone;
			if (currentZone === globalPSD) globalPSD.env = snapShot();
			if (patchGlobalPromise) {
				var GlobalPromise = globalPSD.env.Promise;
				var targetEnv = targetZone.env;
				if (currentZone.global || targetZone.global) {
					Object.defineProperty(_global, "Promise", targetEnv.PromiseProp);
					GlobalPromise.all = targetEnv.all;
					GlobalPromise.race = targetEnv.race;
					GlobalPromise.resolve = targetEnv.resolve;
					GlobalPromise.reject = targetEnv.reject;
					if (targetEnv.allSettled) GlobalPromise.allSettled = targetEnv.allSettled;
					if (targetEnv.any) GlobalPromise.any = targetEnv.any;
				}
			}
		}
		function snapShot() {
			var GlobalPromise = _global.Promise;
			return patchGlobalPromise ? {
				Promise: GlobalPromise,
				PromiseProp: Object.getOwnPropertyDescriptor(_global, "Promise"),
				all: GlobalPromise.all,
				race: GlobalPromise.race,
				allSettled: GlobalPromise.allSettled,
				any: GlobalPromise.any,
				resolve: GlobalPromise.resolve,
				reject: GlobalPromise.reject
			} : {};
		}
		function usePSD(psd, fn, a1, a2, a3) {
			var outerScope = PSD;
			try {
				switchToZone(psd, true);
				return fn(a1, a2, a3);
			} finally {
				switchToZone(outerScope, false);
			}
		}
		function nativeAwaitCompatibleWrap(fn, zone, possibleAwait, cleanup) {
			return typeof fn !== "function" ? fn : function() {
				var outerZone = PSD;
				if (possibleAwait) incrementExpectedAwaits();
				switchToZone(zone, true);
				try {
					return fn.apply(this, arguments);
				} finally {
					switchToZone(outerZone, false);
					if (cleanup) queueMicrotask(decrementExpectedAwaits);
				}
			};
		}
		function execInGlobalContext(cb) {
			if (Promise === NativePromise && task.echoes === 0) {
				if (zoneEchoes === 0) cb();
				else enqueueNativeMicroTask(cb);
			} else setTimeout(cb, 0);
		}
		var rejection = DexiePromise.reject;
		function tempTransaction(db, mode, storeNames, fn) {
			if (!db.idbdb || !db._state.openComplete && !PSD.letThrough && !db._vip) {
				if (db._state.openComplete) return rejection(new exceptions.DatabaseClosed(db._state.dbOpenError));
				if (!db._state.isBeingOpened) {
					if (!db._state.autoOpen) return rejection(new exceptions.DatabaseClosed());
					db.open().catch(nop);
				}
				return db._state.dbReadyPromise.then(function() {
					return tempTransaction(db, mode, storeNames, fn);
				});
			} else {
				var trans = db._createTransaction(mode, storeNames, db._dbSchema);
				try {
					trans.create();
					db._state.PR1398_maxLoop = 3;
				} catch (ex) {
					if (ex.name === errnames.InvalidState && db.isOpen() && --db._state.PR1398_maxLoop > 0) {
						console.warn("Dexie: Need to reopen db");
						db.close({ disableAutoOpen: false });
						return db.open().then(function() {
							return tempTransaction(db, mode, storeNames, fn);
						});
					}
					return rejection(ex);
				}
				return trans._promise(mode, function(resolve, reject) {
					return newScope(function() {
						PSD.trans = trans;
						return fn(resolve, reject, trans);
					});
				}).then(function(result) {
					if (mode === "readwrite") try {
						trans.idbtrans.commit();
					} catch (_a) {}
					return mode === "readonly" ? result : trans._completion.then(function() {
						return result;
					});
				});
			}
		}
		var DEXIE_VERSION = "4.4.5";
		var maxString = String.fromCharCode(65535);
		var minKey = -Infinity;
		var INVALID_KEY_ARGUMENT = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.";
		var STRING_EXPECTED = "String expected.";
		var DEFAULT_MAX_CONNECTIONS = 1e3;
		var DBNAMES_DB = "__dbnames";
		var READONLY = "readonly";
		var READWRITE = "readwrite";
		function combine(filter1, filter2) {
			return filter1 ? filter2 ? function() {
				return filter1.apply(this, arguments) && filter2.apply(this, arguments);
			} : filter1 : filter2;
		}
		var AnyRange = {
			type: 3,
			lower: -Infinity,
			lowerOpen: false,
			upper: [[]],
			upperOpen: false
		};
		function workaroundForUndefinedPrimKey(keyPath) {
			return typeof keyPath === "string" && !/\./.test(keyPath) ? function(obj) {
				if (obj[keyPath] === void 0 && keyPath in obj) {
					obj = deepClone(obj);
					delete obj[keyPath];
				}
				return obj;
			} : function(obj) {
				return obj;
			};
		}
		function Entity() {
			throw exceptions.Type("Entity instances must never be new:ed. Instances are generated by the framework bypassing the constructor.");
		}
		function cmp(a, b) {
			try {
				var ta = type(a);
				var tb = type(b);
				if (ta !== tb) {
					if (ta === "Array") return 1;
					if (tb === "Array") return -1;
					if (ta === "binary") return 1;
					if (tb === "binary") return -1;
					if (ta === "string") return 1;
					if (tb === "string") return -1;
					if (ta === "Date") return 1;
					if (tb !== "Date") return NaN;
					return -1;
				}
				switch (ta) {
					case "number":
					case "Date":
					case "string": return a > b ? 1 : a < b ? -1 : 0;
					case "binary": return compareUint8Arrays(getUint8Array(a), getUint8Array(b));
					case "Array": return compareArrays(a, b);
				}
			} catch (_a) {}
			return NaN;
		}
		function compareArrays(a, b) {
			var al = a.length;
			var bl = b.length;
			var l = al < bl ? al : bl;
			for (var i = 0; i < l; ++i) {
				var res = cmp(a[i], b[i]);
				if (res !== 0) return res;
			}
			return al === bl ? 0 : al < bl ? -1 : 1;
		}
		function compareUint8Arrays(a, b) {
			var al = a.length;
			var bl = b.length;
			var l = al < bl ? al : bl;
			for (var i = 0; i < l; ++i) if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
			return al === bl ? 0 : al < bl ? -1 : 1;
		}
		function type(x) {
			var t = typeof x;
			if (t !== "object") return t;
			if (ArrayBuffer.isView(x)) return "binary";
			var tsTag = toStringTag(x);
			return tsTag === "ArrayBuffer" ? "binary" : tsTag;
		}
		function getUint8Array(a) {
			if (a instanceof Uint8Array) return a;
			if (ArrayBuffer.isView(a)) return new Uint8Array(a.buffer, a.byteOffset, a.byteLength);
			return new Uint8Array(a);
		}
		function builtInDeletionTrigger(table, keys, res) {
			var yProps = table.schema.yProps;
			if (!yProps) return res;
			if (keys && res.numFailures > 0) keys = keys.filter(function(_, i) {
				return !res.failures[i];
			});
			return Promise.all(yProps.map(function(_a) {
				var updatesTable = _a.updatesTable;
				return keys ? table.db.table(updatesTable).where("k").anyOf(keys).delete() : table.db.table(updatesTable).clear();
			})).then(function() {
				return res;
			});
		}
		var PropModification = function() {
			function PropModification(spec) {
				this["@@propmod"] = spec;
			}
			PropModification.prototype.execute = function(value) {
				var _a;
				var spec = this["@@propmod"];
				if (spec.add !== void 0) {
					var term = spec.add;
					if (isArray(term)) return __spreadArray(__spreadArray([], isArray(value) ? value : [], true), term, true).sort();
					if (typeof term === "number") return (Number(value) || 0) + term;
					if (typeof term === "bigint") try {
						return BigInt(value) + term;
					} catch (_b) {
						return BigInt(0) + term;
					}
					throw new TypeError("Invalid term ".concat(term));
				}
				if (spec.remove !== void 0) {
					var subtrahend_1 = spec.remove;
					if (isArray(subtrahend_1)) return isArray(value) ? value.filter(function(item) {
						return !subtrahend_1.includes(item);
					}).sort() : [];
					if (typeof subtrahend_1 === "number") return Number(value) - subtrahend_1;
					if (typeof subtrahend_1 === "bigint") try {
						return BigInt(value) - subtrahend_1;
					} catch (_c) {
						return BigInt(0) - subtrahend_1;
					}
					throw new TypeError("Invalid subtrahend ".concat(subtrahend_1));
				}
				var prefixToReplace = (_a = spec.replacePrefix) === null || _a === void 0 ? void 0 : _a[0];
				if (prefixToReplace && typeof value === "string" && value.startsWith(prefixToReplace)) return spec.replacePrefix[1] + value.substring(prefixToReplace.length);
				return value;
			};
			return PropModification;
		}();
		function applyUpdateSpec(obj, changes) {
			var keyPaths = keys(changes);
			var numKeys = keyPaths.length;
			var anythingModified = false;
			for (var i = 0; i < numKeys; ++i) {
				var keyPath = keyPaths[i];
				var value = changes[keyPath];
				var origValue = getByKeyPath(obj, keyPath);
				if (value instanceof PropModification) {
					setByKeyPath(obj, keyPath, value.execute(origValue));
					anythingModified = true;
				} else if (origValue !== value) {
					setByKeyPath(obj, keyPath, value);
					anythingModified = true;
				}
			}
			return anythingModified;
		}
		var Table = function() {
			function Table() {}
			Table.prototype._trans = function(mode, fn, writeLocked) {
				var trans = this._tx || PSD.trans;
				var tableName = this.name;
				var task = debug && typeof console !== "undefined" && console.createTask && console.createTask("Dexie: ".concat(mode === "readonly" ? "read" : "write", " ").concat(this.name));
				function checkTableInTransaction(resolve, reject, trans) {
					if (!trans.schema[tableName]) throw new exceptions.NotFound("Table " + tableName + " not part of transaction");
					return fn(trans.idbtrans, trans);
				}
				var wasRootExec = beginMicroTickScope();
				try {
					var p = trans && trans.db._novip === this.db._novip ? trans === PSD.trans ? trans._promise(mode, checkTableInTransaction, writeLocked) : newScope(function() {
						return trans._promise(mode, checkTableInTransaction, writeLocked);
					}, {
						trans,
						transless: PSD.transless || PSD
					}) : tempTransaction(this.db, mode, [this.name], checkTableInTransaction);
					if (task) {
						p._consoleTask = task;
						p = p.catch(function(err) {
							console.trace(err);
							return rejection(err);
						});
					}
					return p;
				} finally {
					if (wasRootExec) endMicroTickScope();
				}
			};
			Table.prototype.get = function(keyOrCrit, cb) {
				var _this = this;
				if (keyOrCrit && keyOrCrit.constructor === Object) return this.where(keyOrCrit).first(cb);
				if (keyOrCrit == null) return rejection(new exceptions.Type("Invalid argument to Table.get()"));
				return this._trans("readonly", function(trans) {
					return _this.core.get({
						trans,
						key: keyOrCrit
					}).then(function(res) {
						return _this.hook.reading.fire(res);
					});
				}).then(cb);
			};
			Table.prototype.where = function(indexOrCrit) {
				if (typeof indexOrCrit === "string") return new this.db.WhereClause(this, indexOrCrit);
				if (isArray(indexOrCrit)) return new this.db.WhereClause(this, "[".concat(indexOrCrit.join("+"), "]"));
				var keyPaths = keys(indexOrCrit);
				if (keyPaths.length === 1) return this.where(keyPaths[0]).equals(indexOrCrit[keyPaths[0]]);
				var compoundIndex = this.schema.indexes.concat(this.schema.primKey).filter(function(ix) {
					if (ix.compound && keyPaths.every(function(keyPath) {
						return ix.keyPath.indexOf(keyPath) >= 0;
					})) {
						for (var i = 0; i < keyPaths.length; ++i) if (keyPaths.indexOf(ix.keyPath[i]) === -1) return false;
						return true;
					}
					return false;
				}).sort(function(a, b) {
					return a.keyPath.length - b.keyPath.length;
				})[0];
				if (compoundIndex && this.db._maxKey !== maxString) {
					var keyPathsInValidOrder = compoundIndex.keyPath.slice(0, keyPaths.length);
					return this.where(keyPathsInValidOrder).equals(keyPathsInValidOrder.map(function(kp) {
						return indexOrCrit[kp];
					}));
				}
				if (!compoundIndex && debug) console.warn("The query ".concat(JSON.stringify(indexOrCrit), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(keyPaths.join("+"), "]"));
				var idxByName = this.schema.idxByName;
				function equals(a, b) {
					return cmp(a, b) === 0;
				}
				var _a = keyPaths.reduce(function(_a, keyPath) {
					var prevIndex = _a[0], prevFilterFn = _a[1];
					var index = idxByName[keyPath];
					var value = indexOrCrit[keyPath];
					return [prevIndex || index, prevIndex || !index ? combine(prevFilterFn, index && index.multi ? function(x) {
						var prop = getByKeyPath(x, keyPath);
						return isArray(prop) && prop.some(function(item) {
							return equals(value, item);
						});
					} : function(x) {
						return equals(value, getByKeyPath(x, keyPath));
					}) : prevFilterFn];
				}, [null, null]), idx = _a[0], filterFunction = _a[1];
				return idx ? this.where(idx.name).equals(indexOrCrit[idx.keyPath]).filter(filterFunction) : compoundIndex ? this.filter(filterFunction) : this.where(keyPaths).equals("");
			};
			Table.prototype.filter = function(filterFunction) {
				return this.toCollection().and(filterFunction);
			};
			Table.prototype.count = function(thenShortcut) {
				return this.toCollection().count(thenShortcut);
			};
			Table.prototype.offset = function(offset) {
				return this.toCollection().offset(offset);
			};
			Table.prototype.limit = function(numRows) {
				return this.toCollection().limit(numRows);
			};
			Table.prototype.each = function(callback) {
				return this.toCollection().each(callback);
			};
			Table.prototype.toArray = function(thenShortcut) {
				return this.toCollection().toArray(thenShortcut);
			};
			Table.prototype.toCollection = function() {
				return new this.db.Collection(new this.db.WhereClause(this));
			};
			Table.prototype.orderBy = function(index) {
				return new this.db.Collection(new this.db.WhereClause(this, isArray(index) ? "[".concat(index.join("+"), "]") : index));
			};
			Table.prototype.reverse = function() {
				return this.toCollection().reverse();
			};
			Table.prototype.mapToClass = function(constructor) {
				var _a = this, db = _a.db, tableName = _a.name;
				this.schema.mappedClass = constructor;
				if (constructor.prototype instanceof Entity) constructor = function(_super) {
					__extends(class_1, _super);
					function class_1() {
						return _super !== null && _super.apply(this, arguments) || this;
					}
					Object.defineProperty(class_1.prototype, "db", {
						get: function() {
							return db;
						},
						enumerable: false,
						configurable: true
					});
					class_1.prototype.table = function() {
						return tableName;
					};
					return class_1;
				}(constructor);
				var inheritedProps = /* @__PURE__ */ new Set();
				for (var proto = constructor.prototype; proto; proto = getProto(proto)) Object.getOwnPropertyNames(proto).forEach(function(propName) {
					return inheritedProps.add(propName);
				});
				var readHook = function(obj) {
					if (!obj) return obj;
					var res = Object.create(constructor.prototype);
					for (var m in obj) if (!inheritedProps.has(m)) try {
						res[m] = obj[m];
					} catch (_) {}
					return res;
				};
				if (this.schema.readHook) this.hook.reading.unsubscribe(this.schema.readHook);
				this.schema.readHook = readHook;
				this.hook("reading", readHook);
				return constructor;
			};
			Table.prototype.defineClass = function() {
				function Class(content) {
					extend(this, content);
				}
				return this.mapToClass(Class);
			};
			Table.prototype.add = function(obj, key) {
				var _this = this;
				var _a = this.schema.primKey, auto = _a.auto, keyPath = _a.keyPath;
				var objToAdd = obj;
				if (keyPath && auto) objToAdd = workaroundForUndefinedPrimKey(keyPath)(obj);
				return this._trans("readwrite", function(trans) {
					return _this.core.mutate({
						trans,
						type: "add",
						keys: key != null ? [key] : null,
						values: [objToAdd]
					});
				}).then(function(res) {
					return res.numFailures ? DexiePromise.reject(res.failures[0]) : res.lastResult;
				}).then(function(lastResult) {
					if (keyPath) try {
						setByKeyPath(obj, keyPath, lastResult);
					} catch (_) {}
					return lastResult;
				});
			};
			Table.prototype.upsert = function(key, modifications) {
				var _this = this;
				var keyPath = this.schema.primKey.keyPath;
				return this._trans("readwrite", function(trans) {
					return _this.core.get({
						trans,
						key
					}).then(function(existing) {
						var obj = existing !== null && existing !== void 0 ? existing : {};
						applyUpdateSpec(obj, modifications);
						if (keyPath) setByKeyPath(obj, keyPath, key);
						return _this.core.mutate({
							trans,
							type: "put",
							values: [obj],
							keys: [key],
							upsert: true,
							updates: {
								keys: [key],
								changeSpecs: [modifications]
							}
						}).then(function(res) {
							return res.numFailures ? DexiePromise.reject(res.failures[0]) : !!existing;
						});
					});
				});
			};
			Table.prototype.update = function(keyOrObject, modifications) {
				if (typeof keyOrObject === "object" && !isArray(keyOrObject)) {
					var key = getByKeyPath(keyOrObject, this.schema.primKey.keyPath);
					if (key === void 0) return rejection(new exceptions.InvalidArgument("Given object does not contain its primary key"));
					return this.where(":id").equals(key).modify(modifications);
				} else return this.where(":id").equals(keyOrObject).modify(modifications);
			};
			Table.prototype.put = function(obj, key) {
				var _this = this;
				var _a = this.schema.primKey, auto = _a.auto, keyPath = _a.keyPath;
				var objToAdd = obj;
				if (keyPath && auto) objToAdd = workaroundForUndefinedPrimKey(keyPath)(obj);
				return this._trans("readwrite", function(trans) {
					return _this.core.mutate({
						trans,
						type: "put",
						values: [objToAdd],
						keys: key != null ? [key] : null
					});
				}).then(function(res) {
					return res.numFailures ? DexiePromise.reject(res.failures[0]) : res.lastResult;
				}).then(function(lastResult) {
					if (keyPath) try {
						setByKeyPath(obj, keyPath, lastResult);
					} catch (_) {}
					return lastResult;
				});
			};
			Table.prototype.delete = function(key) {
				var _this = this;
				return this._trans("readwrite", function(trans) {
					return _this.core.mutate({
						trans,
						type: "delete",
						keys: [key]
					}).then(function(res) {
						return builtInDeletionTrigger(_this, [key], res);
					}).then(function(res) {
						return res.numFailures ? DexiePromise.reject(res.failures[0]) : void 0;
					});
				});
			};
			Table.prototype.clear = function() {
				var _this = this;
				return this._trans("readwrite", function(trans) {
					return _this.core.mutate({
						trans,
						type: "deleteRange",
						range: AnyRange
					}).then(function(res) {
						return builtInDeletionTrigger(_this, null, res);
					});
				}).then(function(res) {
					return res.numFailures ? DexiePromise.reject(res.failures[0]) : void 0;
				});
			};
			Table.prototype.bulkGet = function(keys) {
				var _this = this;
				return this._trans("readonly", function(trans) {
					return _this.core.getMany({
						keys,
						trans
					}).then(function(result) {
						return result.map(function(res) {
							return _this.hook.reading.fire(res);
						});
					});
				});
			};
			Table.prototype.bulkAdd = function(objects, keysOrOptions, options) {
				var _this = this;
				var keys = Array.isArray(keysOrOptions) ? keysOrOptions : void 0;
				options = options || (keys ? void 0 : keysOrOptions);
				var wantResults = options ? options.allKeys : void 0;
				return this._trans("readwrite", function(trans) {
					var _a = _this.schema.primKey, auto = _a.auto, keyPath = _a.keyPath;
					if (keyPath && keys) throw new exceptions.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
					if (keys && keys.length !== objects.length) throw new exceptions.InvalidArgument("Arguments objects and keys must have the same length");
					var numObjects = objects.length;
					var objectsToAdd = keyPath && auto ? objects.map(workaroundForUndefinedPrimKey(keyPath)) : objects;
					return _this.core.mutate({
						trans,
						type: "add",
						keys,
						values: objectsToAdd,
						wantResults
					}).then(function(_a) {
						var numFailures = _a.numFailures, results = _a.results, lastResult = _a.lastResult, failures = _a.failures;
						var result = wantResults ? results : lastResult;
						if (numFailures === 0) return result;
						throw new BulkError("".concat(_this.name, ".bulkAdd(): ").concat(numFailures, " of ").concat(numObjects, " operations failed"), failures);
					});
				});
			};
			Table.prototype.bulkPut = function(objects, keysOrOptions, options) {
				var _this = this;
				var keys = Array.isArray(keysOrOptions) ? keysOrOptions : void 0;
				options = options || (keys ? void 0 : keysOrOptions);
				var wantResults = options ? options.allKeys : void 0;
				return this._trans("readwrite", function(trans) {
					var _a = _this.schema.primKey, auto = _a.auto, keyPath = _a.keyPath;
					if (keyPath && keys) throw new exceptions.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
					if (keys && keys.length !== objects.length) throw new exceptions.InvalidArgument("Arguments objects and keys must have the same length");
					var numObjects = objects.length;
					var objectsToPut = keyPath && auto ? objects.map(workaroundForUndefinedPrimKey(keyPath)) : objects;
					return _this.core.mutate({
						trans,
						type: "put",
						keys,
						values: objectsToPut,
						wantResults
					}).then(function(_a) {
						var numFailures = _a.numFailures, results = _a.results, lastResult = _a.lastResult, failures = _a.failures;
						var result = wantResults ? results : lastResult;
						if (numFailures === 0) return result;
						throw new BulkError("".concat(_this.name, ".bulkPut(): ").concat(numFailures, " of ").concat(numObjects, " operations failed"), failures);
					});
				});
			};
			Table.prototype.bulkUpdate = function(keysAndChanges) {
				var _this = this;
				var coreTable = this.core;
				var keys = keysAndChanges.map(function(entry) {
					return entry.key;
				});
				var changeSpecs = keysAndChanges.map(function(entry) {
					return entry.changes;
				});
				var offsetMap = [];
				return this._trans("readwrite", function(trans) {
					return coreTable.getMany({
						trans,
						keys,
						cache: "clone"
					}).then(function(objs) {
						var resultKeys = [];
						var resultObjs = [];
						keysAndChanges.forEach(function(_a, idx) {
							var key = _a.key, changes = _a.changes;
							var obj = objs[idx];
							if (obj) {
								for (var _i = 0, _b = Object.keys(changes); _i < _b.length; _i++) {
									var keyPath = _b[_i];
									var value = changes[keyPath];
									if (keyPath === _this.schema.primKey.keyPath) {
										if (cmp(value, key) !== 0) throw new exceptions.Constraint("Cannot update primary key in bulkUpdate()");
									} else setByKeyPath(obj, keyPath, value);
								}
								offsetMap.push(idx);
								resultKeys.push(key);
								resultObjs.push(obj);
							}
						});
						var numEntries = resultKeys.length;
						return coreTable.mutate({
							trans,
							type: "put",
							keys: resultKeys,
							values: resultObjs,
							updates: {
								keys,
								changeSpecs
							}
						}).then(function(_a) {
							var numFailures = _a.numFailures, failures = _a.failures;
							if (numFailures === 0) return numEntries;
							for (var _i = 0, _b = Object.keys(failures); _i < _b.length; _i++) {
								var offset = _b[_i];
								var mappedOffset = offsetMap[Number(offset)];
								if (mappedOffset != null) {
									var failure = failures[offset];
									delete failures[offset];
									failures[mappedOffset] = failure;
								}
							}
							throw new BulkError("".concat(_this.name, ".bulkUpdate(): ").concat(numFailures, " of ").concat(numEntries, " operations failed"), failures);
						});
					});
				});
			};
			Table.prototype.bulkDelete = function(keys) {
				var _this = this;
				var numKeys = keys.length;
				return this._trans("readwrite", function(trans) {
					return _this.core.mutate({
						trans,
						type: "delete",
						keys
					}).then(function(res) {
						return builtInDeletionTrigger(_this, keys, res);
					});
				}).then(function(_a) {
					var numFailures = _a.numFailures, lastResult = _a.lastResult, failures = _a.failures;
					if (numFailures === 0) return lastResult;
					throw new BulkError("".concat(_this.name, ".bulkDelete(): ").concat(numFailures, " of ").concat(numKeys, " operations failed"), failures);
				});
			};
			return Table;
		}();
		function Events(ctx) {
			var evs = {};
			var rv = function(eventName, subscriber) {
				if (subscriber) {
					var i = arguments.length, args = new Array(i - 1);
					while (--i) args[i - 1] = arguments[i];
					evs[eventName].subscribe.apply(null, args);
					return ctx;
				} else if (typeof eventName === "string") return evs[eventName];
			};
			rv.addEventType = add;
			for (var i = 1, l = arguments.length; i < l; ++i) add(arguments[i]);
			return rv;
			function add(eventName, chainFunction, defaultFunction) {
				if (typeof eventName === "object") return addConfiguredEvents(eventName);
				if (!chainFunction) chainFunction = reverseStoppableEventChain;
				if (!defaultFunction) defaultFunction = nop;
				var context = {
					subscribers: [],
					fire: defaultFunction,
					subscribe: function(cb) {
						if (context.subscribers.indexOf(cb) === -1) {
							context.subscribers.push(cb);
							context.fire = chainFunction(context.fire, cb);
						}
					},
					unsubscribe: function(cb) {
						context.subscribers = context.subscribers.filter(function(fn) {
							return fn !== cb;
						});
						context.fire = context.subscribers.reduce(chainFunction, defaultFunction);
					}
				};
				evs[eventName] = rv[eventName] = context;
				return context;
			}
			function addConfiguredEvents(cfg) {
				keys(cfg).forEach(function(eventName) {
					var args = cfg[eventName];
					if (isArray(args)) add(eventName, cfg[eventName][0], cfg[eventName][1]);
					else if (args === "asap") var context = add(eventName, mirror, function fire() {
						var i = arguments.length, args = new Array(i);
						while (i--) args[i] = arguments[i];
						context.subscribers.forEach(function(fn) {
							asap$1(function fireEvent() {
								fn.apply(null, args);
							});
						});
					});
					else throw new exceptions.InvalidArgument("Invalid event config");
				});
			}
		}
		function makeClassConstructor(prototype, constructor) {
			derive(constructor).from({ prototype });
			return constructor;
		}
		function createTableConstructor(db) {
			return makeClassConstructor(Table.prototype, function Table(name, tableSchema, trans) {
				this.db = db;
				this._tx = trans;
				this.name = name;
				this.schema = tableSchema;
				this.hook = db._allTables[name] ? db._allTables[name].hook : Events(null, {
					creating: [hookCreatingChain, nop],
					reading: [pureFunctionChain, mirror],
					updating: [hookUpdatingChain, nop],
					deleting: [hookDeletingChain, nop]
				});
			});
		}
		function isPlainKeyRange(ctx, ignoreLimitFilter) {
			return !(ctx.filter || ctx.algorithm || ctx.or) && (ignoreLimitFilter ? ctx.justLimit : !ctx.replayFilter);
		}
		function addFilter(ctx, fn) {
			ctx.filter = combine(ctx.filter, fn);
		}
		function addReplayFilter(ctx, factory, isLimitFilter) {
			var curr = ctx.replayFilter;
			ctx.replayFilter = curr ? function() {
				return combine(curr(), factory());
			} : factory;
			ctx.justLimit = isLimitFilter && !curr;
		}
		function addMatchFilter(ctx, fn) {
			ctx.isMatch = combine(ctx.isMatch, fn);
		}
		function getIndexOrStore(ctx, coreSchema) {
			if (ctx.isPrimKey) return coreSchema.primaryKey;
			var index = coreSchema.getIndexByKeyPath(ctx.index);
			if (!index) throw new exceptions.Schema("KeyPath " + ctx.index + " on object store " + coreSchema.name + " is not indexed");
			return index;
		}
		function openCursor(ctx, coreTable, trans) {
			var index = getIndexOrStore(ctx, coreTable.schema);
			return coreTable.openCursor({
				trans,
				values: !ctx.keysOnly,
				reverse: ctx.dir === "prev",
				unique: !!ctx.unique,
				query: {
					index,
					range: ctx.range
				}
			});
		}
		function iter(ctx, fn, coreTrans, coreTable) {
			var filter = ctx.replayFilter ? combine(ctx.filter, ctx.replayFilter()) : ctx.filter;
			if (!ctx.or) return iterate(openCursor(ctx, coreTable, coreTrans), combine(ctx.algorithm, filter), fn, !ctx.keysOnly && ctx.valueMapper);
			else {
				var set_1 = {};
				var union = function(item, cursor, advance) {
					if (!filter || filter(cursor, advance, function(result) {
						return cursor.stop(result);
					}, function(err) {
						return cursor.fail(err);
					})) {
						var primaryKey = cursor.primaryKey;
						var key = "" + primaryKey;
						if (key === "[object ArrayBuffer]") key = "" + new Uint8Array(primaryKey);
						if (!hasOwn(set_1, key)) {
							set_1[key] = true;
							fn(item, cursor, advance);
						}
					}
				};
				return Promise.all([ctx.or._iterate(union, coreTrans), iterate(openCursor(ctx, coreTable, coreTrans), ctx.algorithm, union, !ctx.keysOnly && ctx.valueMapper)]);
			}
		}
		function iterate(cursorPromise, filter, fn, valueMapper) {
			var wrappedFn = wrap(valueMapper ? function(x, c, a) {
				return fn(valueMapper(x), c, a);
			} : fn);
			return cursorPromise.then(function(cursor) {
				if (cursor) return cursor.start(function() {
					var c = function() {
						return cursor.continue();
					};
					if (!filter || filter(cursor, function(advancer) {
						return c = advancer;
					}, function(val) {
						cursor.stop(val);
						c = nop;
					}, function(e) {
						cursor.fail(e);
						c = nop;
					})) wrappedFn(cursor.value, cursor, function(advancer) {
						return c = advancer;
					});
					c();
				});
			});
		}
		var Collection = function() {
			function Collection() {}
			Collection.prototype._read = function(fn, cb) {
				var ctx = this._ctx;
				return ctx.error ? ctx.table._trans(null, rejection.bind(null, ctx.error)) : ctx.table._trans("readonly", fn).then(cb);
			};
			Collection.prototype._write = function(fn) {
				var ctx = this._ctx;
				return ctx.error ? ctx.table._trans(null, rejection.bind(null, ctx.error)) : ctx.table._trans("readwrite", fn, "locked");
			};
			Collection.prototype._addAlgorithm = function(fn) {
				var ctx = this._ctx;
				ctx.algorithm = combine(ctx.algorithm, fn);
			};
			Collection.prototype._iterate = function(fn, coreTrans) {
				return iter(this._ctx, fn, coreTrans, this._ctx.table.core);
			};
			Collection.prototype.clone = function(props) {
				var rv = Object.create(this.constructor.prototype), ctx = Object.create(this._ctx);
				if (props) extend(ctx, props);
				rv._ctx = ctx;
				return rv;
			};
			Collection.prototype.raw = function() {
				this._ctx.valueMapper = null;
				return this;
			};
			Collection.prototype.each = function(fn) {
				var ctx = this._ctx;
				return this._read(function(trans) {
					return iter(ctx, fn, trans, ctx.table.core);
				});
			};
			Collection.prototype.count = function(cb) {
				var _this = this;
				return this._read(function(trans) {
					var ctx = _this._ctx;
					var coreTable = ctx.table.core;
					if (isPlainKeyRange(ctx, true)) return coreTable.count({
						trans,
						query: {
							index: getIndexOrStore(ctx, coreTable.schema),
							range: ctx.range
						}
					}).then(function(count) {
						return Math.min(count, ctx.limit);
					});
					else {
						var count = 0;
						return iter(ctx, function() {
							++count;
							return false;
						}, trans, coreTable).then(function() {
							return count;
						});
					}
				}).then(cb);
			};
			Collection.prototype.sortBy = function(keyPath, cb) {
				var parts = keyPath.split(".").reverse(), lastPart = parts[0], lastIndex = parts.length - 1;
				function getval(obj, i) {
					if (i) return getval(obj[parts[i]], i - 1);
					return obj[lastPart];
				}
				var order = this._ctx.dir === "next" ? 1 : -1;
				function sorter(a, b) {
					return cmp(getval(a, lastIndex), getval(b, lastIndex)) * order;
				}
				return this.toArray(function(a) {
					return a.slice().sort(sorter);
				}).then(cb);
			};
			Collection.prototype.toArray = function(cb) {
				var _this = this;
				return this._read(function(trans) {
					var ctx = _this._ctx;
					if (isPlainKeyRange(ctx, true) && ctx.limit > 0) {
						var valueMapper_1 = ctx.valueMapper;
						var index = getIndexOrStore(ctx, ctx.table.core.schema);
						return ctx.table.core.query({
							trans,
							limit: ctx.limit,
							values: true,
							direction: ctx.dir === "prev" ? "prev" : void 0,
							query: {
								index,
								range: ctx.range
							}
						}).then(function(_a) {
							var result = _a.result;
							return valueMapper_1 ? result.map(valueMapper_1) : result;
						});
					} else {
						var a_1 = [];
						return iter(ctx, function(item) {
							return a_1.push(item);
						}, trans, ctx.table.core).then(function() {
							return a_1;
						});
					}
				}, cb);
			};
			Collection.prototype.offset = function(offset) {
				var ctx = this._ctx;
				if (offset <= 0) return this;
				ctx.offset += offset;
				if (isPlainKeyRange(ctx)) addReplayFilter(ctx, function() {
					var offsetLeft = offset;
					return function(cursor, advance) {
						if (offsetLeft === 0) return true;
						if (offsetLeft === 1) {
							--offsetLeft;
							return false;
						}
						advance(function() {
							cursor.advance(offsetLeft);
							offsetLeft = 0;
						});
						return false;
					};
				});
				else addReplayFilter(ctx, function() {
					var offsetLeft = offset;
					return function() {
						return --offsetLeft < 0;
					};
				});
				return this;
			};
			Collection.prototype.limit = function(numRows) {
				this._ctx.limit = Math.min(this._ctx.limit, numRows);
				addReplayFilter(this._ctx, function() {
					var rowsLeft = numRows;
					return function(cursor, advance, resolve) {
						if (--rowsLeft <= 0) advance(resolve);
						return rowsLeft >= 0;
					};
				}, true);
				return this;
			};
			Collection.prototype.until = function(filterFunction, bIncludeStopEntry) {
				addFilter(this._ctx, function(cursor, advance, resolve) {
					if (filterFunction(cursor.value)) {
						advance(resolve);
						return bIncludeStopEntry;
					} else return true;
				});
				return this;
			};
			Collection.prototype.first = function(cb) {
				return this.limit(1).toArray(function(a) {
					return a[0];
				}).then(cb);
			};
			Collection.prototype.last = function(cb) {
				return this.reverse().first(cb);
			};
			Collection.prototype.filter = function(filterFunction) {
				addFilter(this._ctx, function(cursor) {
					return filterFunction(cursor.value);
				});
				addMatchFilter(this._ctx, filterFunction);
				return this;
			};
			Collection.prototype.and = function(filter) {
				return this.filter(filter);
			};
			Collection.prototype.or = function(indexName) {
				return new this.db.WhereClause(this._ctx.table, indexName, this);
			};
			Collection.prototype.reverse = function() {
				this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev";
				if (this._ondirectionchange) this._ondirectionchange(this._ctx.dir);
				return this;
			};
			Collection.prototype.desc = function() {
				return this.reverse();
			};
			Collection.prototype.eachKey = function(cb) {
				var ctx = this._ctx;
				ctx.keysOnly = !ctx.isMatch;
				return this.each(function(val, cursor) {
					cb(cursor.key, cursor);
				});
			};
			Collection.prototype.eachUniqueKey = function(cb) {
				this._ctx.unique = "unique";
				return this.eachKey(cb);
			};
			Collection.prototype.eachPrimaryKey = function(cb) {
				var ctx = this._ctx;
				ctx.keysOnly = !ctx.isMatch;
				return this.each(function(val, cursor) {
					cb(cursor.primaryKey, cursor);
				});
			};
			Collection.prototype.keys = function(cb) {
				var ctx = this._ctx;
				ctx.keysOnly = !ctx.isMatch;
				var a = [];
				return this.each(function(item, cursor) {
					a.push(cursor.key);
				}).then(function() {
					return a;
				}).then(cb);
			};
			Collection.prototype.primaryKeys = function(cb) {
				var ctx = this._ctx;
				if (isPlainKeyRange(ctx, true) && ctx.limit > 0) return this._read(function(trans) {
					var index = getIndexOrStore(ctx, ctx.table.core.schema);
					return ctx.table.core.query({
						trans,
						values: false,
						limit: ctx.limit,
						direction: ctx.dir === "prev" ? "prev" : void 0,
						query: {
							index,
							range: ctx.range
						}
					});
				}).then(function(_a) {
					return _a.result;
				}).then(cb);
				ctx.keysOnly = !ctx.isMatch;
				var a = [];
				return this.each(function(item, cursor) {
					a.push(cursor.primaryKey);
				}).then(function() {
					return a;
				}).then(cb);
			};
			Collection.prototype.uniqueKeys = function(cb) {
				this._ctx.unique = "unique";
				return this.keys(cb);
			};
			Collection.prototype.firstKey = function(cb) {
				return this.limit(1).keys(function(a) {
					return a[0];
				}).then(cb);
			};
			Collection.prototype.lastKey = function(cb) {
				return this.reverse().firstKey(cb);
			};
			Collection.prototype.distinct = function() {
				var ctx = this._ctx, idx = ctx.index && ctx.table.schema.idxByName[ctx.index];
				if (!idx || !idx.multi) return this;
				var set = {};
				addFilter(this._ctx, function(cursor) {
					var strKey = cursor.primaryKey.toString();
					var found = hasOwn(set, strKey);
					set[strKey] = true;
					return !found;
				});
				return this;
			};
			Collection.prototype.modify = function(changes) {
				var _this = this;
				var ctx = this._ctx;
				return this._write(function(trans) {
					var modifyer;
					if (typeof changes === "function") modifyer = changes;
					else modifyer = function(item) {
						return applyUpdateSpec(item, changes);
					};
					var coreTable = ctx.table.core;
					var _a = coreTable.schema.primaryKey, outbound = _a.outbound, extractKey = _a.extractKey;
					var limit = 200;
					var modifyChunkSize = _this.db._options.modifyChunkSize;
					if (modifyChunkSize) {
						if (typeof modifyChunkSize == "object") limit = modifyChunkSize[coreTable.name] || modifyChunkSize["*"] || 200;
						else limit = modifyChunkSize;
					}
					var totalFailures = [];
					var successCount = 0;
					var failedKeys = [];
					var applyMutateResult = function(expectedCount, res) {
						var failures = res.failures, numFailures = res.numFailures;
						successCount += expectedCount - numFailures;
						for (var _i = 0, _a = keys(failures); _i < _a.length; _i++) {
							var pos = _a[_i];
							totalFailures.push(failures[pos]);
						}
					};
					var isUnconditionalDelete = changes === deleteCallback;
					return _this.clone().primaryKeys().then(function(keys) {
						var criteria = isPlainKeyRange(ctx) && ctx.limit === Infinity && (typeof changes !== "function" || isUnconditionalDelete) && {
							index: ctx.index,
							range: ctx.range
						};
						var nextChunk = function(offset) {
							var count = Math.min(limit, keys.length - offset);
							var keysInChunk = keys.slice(offset, offset + count);
							return (isUnconditionalDelete ? Promise.resolve([]) : coreTable.getMany({
								trans,
								keys: keysInChunk,
								cache: "immutable"
							})).then(function(values) {
								var addValues = [];
								var putValues = [];
								var putKeys = outbound ? [] : null;
								var deleteKeys = isUnconditionalDelete ? keysInChunk : [];
								if (!isUnconditionalDelete) for (var i = 0; i < count; ++i) {
									var origValue = values[i];
									var ctx_1 = {
										value: deepClone(origValue),
										primKey: keys[offset + i]
									};
									if (modifyer.call(ctx_1, ctx_1.value, ctx_1) !== false) {
										if (ctx_1.value == null) deleteKeys.push(keys[offset + i]);
										else if (!outbound && cmp(extractKey(origValue), extractKey(ctx_1.value)) !== 0) {
											deleteKeys.push(keys[offset + i]);
											addValues.push(ctx_1.value);
										} else {
											putValues.push(ctx_1.value);
											if (outbound) putKeys.push(keys[offset + i]);
										}
									}
								}
								return Promise.resolve(addValues.length > 0 && coreTable.mutate({
									trans,
									type: "add",
									values: addValues
								}).then(function(res) {
									for (var pos in res.failures) deleteKeys.splice(parseInt(pos), 1);
									applyMutateResult(addValues.length, res);
								})).then(function() {
									return (putValues.length > 0 || criteria && typeof changes === "object") && coreTable.mutate({
										trans,
										type: "put",
										keys: putKeys,
										values: putValues,
										criteria,
										changeSpec: typeof changes !== "function" && changes,
										isAdditionalChunk: offset > 0
									}).then(function(res) {
										return applyMutateResult(putValues.length, res);
									});
								}).then(function() {
									return (deleteKeys.length > 0 || criteria && isUnconditionalDelete) && coreTable.mutate({
										trans,
										type: "delete",
										keys: deleteKeys,
										criteria,
										isAdditionalChunk: offset > 0
									}).then(function(res) {
										return builtInDeletionTrigger(ctx.table, deleteKeys, res);
									}).then(function(res) {
										return applyMutateResult(deleteKeys.length, res);
									});
								}).then(function() {
									return keys.length > offset + count && nextChunk(offset + limit);
								});
							});
						};
						return nextChunk(0).then(function() {
							if (totalFailures.length > 0) throw new ModifyError("Error modifying one or more objects", totalFailures, successCount, failedKeys);
							return keys.length;
						});
					});
				});
			};
			Collection.prototype.delete = function() {
				var ctx = this._ctx, range = ctx.range;
				if (isPlainKeyRange(ctx) && !ctx.table.schema.yProps && (ctx.isPrimKey || range.type === 3)) return this._write(function(trans) {
					var primaryKey = ctx.table.core.schema.primaryKey;
					var coreRange = range;
					return ctx.table.core.count({
						trans,
						query: {
							index: primaryKey,
							range: coreRange
						}
					}).then(function(count) {
						return ctx.table.core.mutate({
							trans,
							type: "deleteRange",
							range: coreRange
						}).then(function(_a) {
							var failures = _a.failures, numFailures = _a.numFailures;
							if (numFailures) throw new ModifyError("Could not delete some values", Object.keys(failures).map(function(pos) {
								return failures[pos];
							}), count - numFailures);
							return count - numFailures;
						});
					});
				});
				return this.modify(deleteCallback);
			};
			return Collection;
		}();
		var deleteCallback = function(value, ctx) {
			return ctx.value = null;
		};
		function createCollectionConstructor(db) {
			return makeClassConstructor(Collection.prototype, function Collection(whereClause, keyRangeGenerator) {
				this.db = db;
				var keyRange = AnyRange, error = null;
				if (keyRangeGenerator) try {
					keyRange = keyRangeGenerator();
				} catch (ex) {
					error = ex;
				}
				var whereCtx = whereClause._ctx;
				var table = whereCtx.table;
				var readingHook = table.hook.reading.fire;
				this._ctx = {
					table,
					index: whereCtx.index,
					isPrimKey: !whereCtx.index || table.schema.primKey.keyPath && whereCtx.index === table.schema.primKey.name,
					range: keyRange,
					keysOnly: false,
					dir: "next",
					unique: "",
					algorithm: null,
					filter: null,
					replayFilter: null,
					justLimit: true,
					isMatch: null,
					offset: 0,
					limit: Infinity,
					error,
					or: whereCtx.or,
					valueMapper: readingHook !== mirror ? readingHook : null
				};
			});
		}
		function simpleCompare(a, b) {
			return a < b ? -1 : a === b ? 0 : 1;
		}
		function simpleCompareReverse(a, b) {
			return a > b ? -1 : a === b ? 0 : 1;
		}
		function fail(collectionOrWhereClause, err, T) {
			var collection = collectionOrWhereClause instanceof WhereClause ? new collectionOrWhereClause.Collection(collectionOrWhereClause) : collectionOrWhereClause;
			collection._ctx.error = T ? new T(err) : new TypeError(err);
			return collection;
		}
		function emptyCollection(whereClause) {
			return new whereClause.Collection(whereClause, function() {
				return rangeEqual("");
			}).limit(0);
		}
		function upperFactory(dir) {
			return dir === "next" ? function(s) {
				return s.toUpperCase();
			} : function(s) {
				return s.toLowerCase();
			};
		}
		function lowerFactory(dir) {
			return dir === "next" ? function(s) {
				return s.toLowerCase();
			} : function(s) {
				return s.toUpperCase();
			};
		}
		function nextCasing(key, lowerKey, upperNeedle, lowerNeedle, cmp, dir) {
			var length = Math.min(key.length, lowerNeedle.length);
			var llp = -1;
			for (var i = 0; i < length; ++i) {
				var lwrKeyChar = lowerKey[i];
				if (lwrKeyChar !== lowerNeedle[i]) {
					if (cmp(key[i], upperNeedle[i]) < 0) return key.substr(0, i) + upperNeedle[i] + upperNeedle.substr(i + 1);
					if (cmp(key[i], lowerNeedle[i]) < 0) return key.substr(0, i) + lowerNeedle[i] + upperNeedle.substr(i + 1);
					if (llp >= 0) return key.substr(0, llp) + lowerKey[llp] + upperNeedle.substr(llp + 1);
					return null;
				}
				if (cmp(key[i], lwrKeyChar) < 0) llp = i;
			}
			if (length < lowerNeedle.length && dir === "next") return key + upperNeedle.substr(key.length);
			if (length < key.length && dir === "prev") return key.substr(0, upperNeedle.length);
			return llp < 0 ? null : key.substr(0, llp) + lowerNeedle[llp] + upperNeedle.substr(llp + 1);
		}
		function addIgnoreCaseAlgorithm(whereClause, match, needles, suffix) {
			var upper, lower, compare, upperNeedles, lowerNeedles, direction, nextKeySuffix, needlesLen = needles.length;
			if (!needles.every(function(s) {
				return typeof s === "string";
			})) return fail(whereClause, STRING_EXPECTED);
			function initDirection(dir) {
				upper = upperFactory(dir);
				lower = lowerFactory(dir);
				compare = dir === "next" ? simpleCompare : simpleCompareReverse;
				var needleBounds = needles.map(function(needle) {
					return {
						lower: lower(needle),
						upper: upper(needle)
					};
				}).sort(function(a, b) {
					return compare(a.lower, b.lower);
				});
				upperNeedles = needleBounds.map(function(nb) {
					return nb.upper;
				});
				lowerNeedles = needleBounds.map(function(nb) {
					return nb.lower;
				});
				direction = dir;
				nextKeySuffix = dir === "next" ? "" : suffix;
			}
			initDirection("next");
			var c = new whereClause.Collection(whereClause, function() {
				return createRange(upperNeedles[0], lowerNeedles[needlesLen - 1] + suffix);
			});
			c._ondirectionchange = function(direction) {
				initDirection(direction);
			};
			var firstPossibleNeedle = 0;
			c._addAlgorithm(function(cursor, advance, resolve) {
				var key = cursor.key;
				if (typeof key !== "string") return false;
				var lowerKey = lower(key);
				if (match(lowerKey, lowerNeedles, firstPossibleNeedle)) return true;
				else {
					var lowestPossibleCasing = null;
					for (var i = firstPossibleNeedle; i < needlesLen; ++i) {
						var casing = nextCasing(key, lowerKey, upperNeedles[i], lowerNeedles[i], compare, direction);
						if (casing === null && lowestPossibleCasing === null) firstPossibleNeedle = i + 1;
						else if (lowestPossibleCasing === null || compare(lowestPossibleCasing, casing) > 0) lowestPossibleCasing = casing;
					}
					if (lowestPossibleCasing !== null) advance(function() {
						cursor.continue(lowestPossibleCasing + nextKeySuffix);
					});
					else advance(resolve);
					return false;
				}
			});
			return c;
		}
		function createRange(lower, upper, lowerOpen, upperOpen) {
			return {
				type: 2,
				lower,
				upper,
				lowerOpen,
				upperOpen
			};
		}
		function rangeEqual(value) {
			return {
				type: 1,
				lower: value,
				upper: value
			};
		}
		var WhereClause = function() {
			function WhereClause() {}
			Object.defineProperty(WhereClause.prototype, "Collection", {
				get: function() {
					return this._ctx.table.db.Collection;
				},
				enumerable: false,
				configurable: true
			});
			WhereClause.prototype.between = function(lower, upper, includeLower, includeUpper) {
				includeLower = includeLower !== false;
				includeUpper = includeUpper === true;
				try {
					if (this._cmp(lower, upper) > 0 || this._cmp(lower, upper) === 0 && (includeLower || includeUpper) && !(includeLower && includeUpper)) return emptyCollection(this);
					return new this.Collection(this, function() {
						return createRange(lower, upper, !includeLower, !includeUpper);
					});
				} catch (e) {
					return fail(this, INVALID_KEY_ARGUMENT);
				}
			};
			WhereClause.prototype.equals = function(value) {
				if (value == null) return fail(this, INVALID_KEY_ARGUMENT);
				return new this.Collection(this, function() {
					return rangeEqual(value);
				});
			};
			WhereClause.prototype.above = function(value) {
				if (value == null) return fail(this, INVALID_KEY_ARGUMENT);
				return new this.Collection(this, function() {
					return createRange(value, void 0, true);
				});
			};
			WhereClause.prototype.aboveOrEqual = function(value) {
				if (value == null) return fail(this, INVALID_KEY_ARGUMENT);
				return new this.Collection(this, function() {
					return createRange(value, void 0, false);
				});
			};
			WhereClause.prototype.below = function(value) {
				if (value == null) return fail(this, INVALID_KEY_ARGUMENT);
				return new this.Collection(this, function() {
					return createRange(void 0, value, false, true);
				});
			};
			WhereClause.prototype.belowOrEqual = function(value) {
				if (value == null) return fail(this, INVALID_KEY_ARGUMENT);
				return new this.Collection(this, function() {
					return createRange(void 0, value);
				});
			};
			WhereClause.prototype.startsWith = function(str) {
				if (typeof str !== "string") return fail(this, STRING_EXPECTED);
				return this.between(str, str + maxString, true, true);
			};
			WhereClause.prototype.startsWithIgnoreCase = function(str) {
				if (str === "") return this.startsWith(str);
				return addIgnoreCaseAlgorithm(this, function(x, a) {
					return x.indexOf(a[0]) === 0;
				}, [str], maxString);
			};
			WhereClause.prototype.equalsIgnoreCase = function(str) {
				return addIgnoreCaseAlgorithm(this, function(x, a) {
					return x === a[0];
				}, [str], "");
			};
			WhereClause.prototype.anyOfIgnoreCase = function() {
				var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
				if (set.length === 0) return emptyCollection(this);
				return addIgnoreCaseAlgorithm(this, function(x, a) {
					return a.indexOf(x) !== -1;
				}, set, "");
			};
			WhereClause.prototype.startsWithAnyOfIgnoreCase = function() {
				var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
				if (set.length === 0) return emptyCollection(this);
				return addIgnoreCaseAlgorithm(this, function(x, a) {
					return a.some(function(n) {
						return x.indexOf(n) === 0;
					});
				}, set, maxString);
			};
			WhereClause.prototype.anyOf = function() {
				var _this = this;
				var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
				var compare = this._cmp;
				try {
					set.sort(compare);
				} catch (e) {
					return fail(this, INVALID_KEY_ARGUMENT);
				}
				if (set.length === 0) return emptyCollection(this);
				var c = new this.Collection(this, function() {
					return createRange(set[0], set[set.length - 1]);
				});
				c._ondirectionchange = function(direction) {
					compare = direction === "next" ? _this._ascending : _this._descending;
					set.sort(compare);
				};
				var i = 0;
				c._addAlgorithm(function(cursor, advance, resolve) {
					var key = cursor.key;
					while (compare(key, set[i]) > 0) {
						++i;
						if (i === set.length) {
							advance(resolve);
							return false;
						}
					}
					if (compare(key, set[i]) === 0) return true;
					else {
						advance(function() {
							cursor.continue(set[i]);
						});
						return false;
					}
				});
				return c;
			};
			WhereClause.prototype.notEqual = function(value) {
				return this.inAnyRange([[minKey, value], [value, this.db._maxKey]], {
					includeLowers: false,
					includeUppers: false
				});
			};
			WhereClause.prototype.noneOf = function() {
				var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
				if (set.length === 0) return new this.Collection(this);
				try {
					set.sort(this._ascending);
				} catch (e) {
					return fail(this, INVALID_KEY_ARGUMENT);
				}
				var ranges = set.reduce(function(res, val) {
					return res ? res.concat([[res[res.length - 1][1], val]]) : [[minKey, val]];
				}, null);
				ranges.push([set[set.length - 1], this.db._maxKey]);
				return this.inAnyRange(ranges, {
					includeLowers: false,
					includeUppers: false
				});
			};
			WhereClause.prototype.inAnyRange = function(ranges, options) {
				var _this = this;
				var cmp = this._cmp, ascending = this._ascending, descending = this._descending, min = this._min, max = this._max;
				if (ranges.length === 0) return emptyCollection(this);
				if (!ranges.every(function(range) {
					return range[0] !== void 0 && range[1] !== void 0 && ascending(range[0], range[1]) <= 0;
				})) return fail(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", exceptions.InvalidArgument);
				var includeLowers = !options || options.includeLowers !== false;
				var includeUppers = options && options.includeUppers === true;
				function addRange(ranges, newRange) {
					var i = 0, l = ranges.length;
					for (; i < l; ++i) {
						var range = ranges[i];
						if (cmp(newRange[0], range[1]) < 0 && cmp(newRange[1], range[0]) > 0) {
							range[0] = min(range[0], newRange[0]);
							range[1] = max(range[1], newRange[1]);
							break;
						}
					}
					if (i === l) ranges.push(newRange);
					return ranges;
				}
				var sortDirection = ascending;
				function rangeSorter(a, b) {
					return sortDirection(a[0], b[0]);
				}
				var set;
				try {
					set = ranges.reduce(addRange, []);
					set.sort(rangeSorter);
				} catch (ex) {
					return fail(this, INVALID_KEY_ARGUMENT);
				}
				var rangePos = 0;
				var keyIsBeyondCurrentEntry = includeUppers ? function(key) {
					return ascending(key, set[rangePos][1]) > 0;
				} : function(key) {
					return ascending(key, set[rangePos][1]) >= 0;
				};
				var keyIsBeforeCurrentEntry = includeLowers ? function(key) {
					return descending(key, set[rangePos][0]) > 0;
				} : function(key) {
					return descending(key, set[rangePos][0]) >= 0;
				};
				function keyWithinCurrentRange(key) {
					return !keyIsBeyondCurrentEntry(key) && !keyIsBeforeCurrentEntry(key);
				}
				var checkKey = keyIsBeyondCurrentEntry;
				var c = new this.Collection(this, function() {
					return createRange(set[0][0], set[set.length - 1][1], !includeLowers, !includeUppers);
				});
				c._ondirectionchange = function(direction) {
					if (direction === "next") {
						checkKey = keyIsBeyondCurrentEntry;
						sortDirection = ascending;
					} else {
						checkKey = keyIsBeforeCurrentEntry;
						sortDirection = descending;
					}
					set.sort(rangeSorter);
				};
				c._addAlgorithm(function(cursor, advance, resolve) {
					var key = cursor.key;
					while (checkKey(key)) {
						++rangePos;
						if (rangePos === set.length) {
							advance(resolve);
							return false;
						}
					}
					if (keyWithinCurrentRange(key)) return true;
					else if (_this._cmp(key, set[rangePos][1]) === 0 || _this._cmp(key, set[rangePos][0]) === 0) return false;
					else {
						advance(function() {
							if (sortDirection === ascending) cursor.continue(set[rangePos][0]);
							else cursor.continue(set[rangePos][1]);
						});
						return false;
					}
				});
				return c;
			};
			WhereClause.prototype.startsWithAnyOf = function() {
				var set = getArrayOf.apply(NO_CHAR_ARRAY, arguments);
				if (!set.every(function(s) {
					return typeof s === "string";
				})) return fail(this, "startsWithAnyOf() only works with strings");
				if (set.length === 0) return emptyCollection(this);
				return this.inAnyRange(set.map(function(str) {
					return [str, str + maxString];
				}));
			};
			return WhereClause;
		}();
		function createWhereClauseConstructor(db) {
			return makeClassConstructor(WhereClause.prototype, function WhereClause(table, index, orCollection) {
				this.db = db;
				this._ctx = {
					table,
					index: index === ":id" ? null : index,
					or: orCollection
				};
				this._cmp = this._ascending = cmp;
				this._descending = function(a, b) {
					return cmp(b, a);
				};
				this._max = function(a, b) {
					return cmp(a, b) > 0 ? a : b;
				};
				this._min = function(a, b) {
					return cmp(a, b) < 0 ? a : b;
				};
				this._IDBKeyRange = db._deps.IDBKeyRange;
				if (!this._IDBKeyRange) throw new exceptions.MissingAPI();
			});
		}
		function eventRejectHandler(reject) {
			return wrap(function(event) {
				preventDefault(event);
				reject(event.target.error);
				return false;
			});
		}
		function preventDefault(event) {
			if (event.stopPropagation) event.stopPropagation();
			if (event.preventDefault) event.preventDefault();
		}
		var DEXIE_STORAGE_MUTATED_EVENT_NAME = "storagemutated";
		var STORAGE_MUTATED_DOM_EVENT_NAME = "x-storagemutated-1";
		var globalEvents = Events(null, DEXIE_STORAGE_MUTATED_EVENT_NAME);
		var Transaction = function() {
			function Transaction() {}
			Transaction.prototype._lock = function() {
				assert(!PSD.global);
				++this._reculock;
				if (this._reculock === 1 && !PSD.global) PSD.lockOwnerFor = this;
				return this;
			};
			Transaction.prototype._unlock = function() {
				assert(!PSD.global);
				if (--this._reculock === 0) {
					if (!PSD.global) PSD.lockOwnerFor = null;
					while (this._blockedFuncs.length > 0 && !this._locked()) {
						var fnAndPSD = this._blockedFuncs.shift();
						try {
							usePSD(fnAndPSD[1], fnAndPSD[0]);
						} catch (e) {}
					}
				}
				return this;
			};
			Transaction.prototype._locked = function() {
				return this._reculock && PSD.lockOwnerFor !== this;
			};
			Transaction.prototype.create = function(idbtrans) {
				var _this = this;
				if (!this.mode) return this;
				var idbdb = this.db.idbdb;
				var dbOpenError = this.db._state.dbOpenError;
				assert(!this.idbtrans);
				if (!idbtrans && !idbdb) switch (dbOpenError && dbOpenError.name) {
					case "DatabaseClosedError": throw new exceptions.DatabaseClosed(dbOpenError);
					case "MissingAPIError": throw new exceptions.MissingAPI(dbOpenError.message, dbOpenError);
					default: throw new exceptions.OpenFailed(dbOpenError);
				}
				if (!this.active) throw new exceptions.TransactionInactive();
				assert(this._completion._state === null);
				idbtrans = this.idbtrans = idbtrans || (this.db.core ? this.db.core.transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability }) : idbdb.transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability }));
				idbtrans.onerror = wrap(function(ev) {
					preventDefault(ev);
					_this._reject(idbtrans.error);
				});
				idbtrans.onabort = wrap(function(ev) {
					preventDefault(ev);
					_this.active && _this._reject(new exceptions.Abort(idbtrans.error));
					_this.active = false;
					_this.on("abort").fire(ev);
				});
				idbtrans.oncomplete = wrap(function() {
					_this.active = false;
					_this._resolve();
					if ("mutatedParts" in idbtrans) globalEvents.storagemutated.fire(idbtrans["mutatedParts"]);
				});
				return this;
			};
			Transaction.prototype._promise = function(mode, fn, bWriteLock) {
				var _this = this;
				if (mode === "readwrite" && this.mode !== "readwrite") return rejection(new exceptions.ReadOnly("Transaction is readonly"));
				if (!this.active) return rejection(new exceptions.TransactionInactive());
				if (this._locked()) return new DexiePromise(function(resolve, reject) {
					_this._blockedFuncs.push([function() {
						_this._promise(mode, fn, bWriteLock).then(resolve, reject);
					}, PSD]);
				});
				else if (bWriteLock) return newScope(function() {
					var p = new DexiePromise(function(resolve, reject) {
						_this._lock();
						var rv = fn(resolve, reject, _this);
						if (rv && rv.then) rv.then(resolve, reject);
					});
					p.finally(function() {
						return _this._unlock();
					});
					p._lib = true;
					return p;
				});
				else {
					var p = new DexiePromise(function(resolve, reject) {
						var rv = fn(resolve, reject, _this);
						if (rv && rv.then) rv.then(resolve, reject);
					});
					p._lib = true;
					return p;
				}
			};
			Transaction.prototype._root = function() {
				return this.parent ? this.parent._root() : this;
			};
			Transaction.prototype.waitFor = function(promiseLike) {
				var root = this._root();
				var promise = DexiePromise.resolve(promiseLike);
				if (root._waitingFor) root._waitingFor = root._waitingFor.then(function() {
					return promise;
				});
				else {
					root._waitingFor = promise;
					root._waitingQueue = [];
					var store = root.idbtrans.objectStore(root.storeNames[0]);
					(function spin() {
						++root._spinCount;
						while (root._waitingQueue.length) root._waitingQueue.shift()();
						if (root._waitingFor) store.get(-Infinity).onsuccess = spin;
					})();
				}
				var currentWaitPromise = root._waitingFor;
				return new DexiePromise(function(resolve, reject) {
					promise.then(function(res) {
						return root._waitingQueue.push(wrap(resolve.bind(null, res)));
					}, function(err) {
						return root._waitingQueue.push(wrap(reject.bind(null, err)));
					}).finally(function() {
						if (root._waitingFor === currentWaitPromise) root._waitingFor = null;
					});
				});
			};
			Transaction.prototype.abort = function() {
				if (this.active) {
					this.active = false;
					if (this.idbtrans) this.idbtrans.abort();
					this._reject(new exceptions.Abort());
				}
			};
			Transaction.prototype.table = function(tableName) {
				var memoizedTables = this._memoizedTables || (this._memoizedTables = {});
				if (hasOwn(memoizedTables, tableName)) return memoizedTables[tableName];
				var tableSchema = this.schema[tableName];
				if (!tableSchema) throw new exceptions.NotFound("Table " + tableName + " not part of transaction");
				var transactionBoundTable = new this.db.Table(tableName, tableSchema, this);
				transactionBoundTable.core = this.db.core.table(tableName);
				memoizedTables[tableName] = transactionBoundTable;
				return transactionBoundTable;
			};
			return Transaction;
		}();
		function createTransactionConstructor(db) {
			return makeClassConstructor(Transaction.prototype, function Transaction(mode, storeNames, dbschema, chromeTransactionDurability, parent) {
				var _this = this;
				if (mode !== "readonly") storeNames.forEach(function(storeName) {
					var _a;
					var yProps = (_a = dbschema[storeName]) === null || _a === void 0 ? void 0 : _a.yProps;
					if (yProps) storeNames = storeNames.concat(yProps.map(function(p) {
						return p.updatesTable;
					}));
				});
				this.db = db;
				this.mode = mode;
				this.storeNames = storeNames;
				this.schema = dbschema;
				this.chromeTransactionDurability = chromeTransactionDurability;
				this.idbtrans = null;
				this.on = Events(this, "complete", "error", "abort");
				this.parent = parent || null;
				this.active = true;
				this._reculock = 0;
				this._blockedFuncs = [];
				this._resolve = null;
				this._reject = null;
				this._waitingFor = null;
				this._waitingQueue = null;
				this._spinCount = 0;
				this._completion = new DexiePromise(function(resolve, reject) {
					_this._resolve = resolve;
					_this._reject = reject;
				});
				this._completion.then(function() {
					_this.active = false;
					_this.on.complete.fire();
				}, function(e) {
					var wasActive = _this.active;
					_this.active = false;
					_this.on.error.fire(e);
					_this.parent ? _this.parent._reject(e) : wasActive && _this.idbtrans && _this.idbtrans.abort();
					return rejection(e);
				});
			});
		}
		function createIndexSpec(name, keyPath, unique, multi, auto, compound, isPrimKey, type) {
			return {
				name,
				keyPath,
				unique,
				multi,
				auto,
				compound,
				src: (unique && !isPrimKey ? "&" : "") + (multi ? "*" : "") + (auto ? "++" : "") + nameFromKeyPath(keyPath),
				type
			};
		}
		function nameFromKeyPath(keyPath) {
			return typeof keyPath === "string" ? keyPath : keyPath ? "[" + [].join.call(keyPath, "+") + "]" : "";
		}
		function createTableSchema(name, primKey, indexes) {
			return {
				name,
				primKey,
				indexes,
				mappedClass: null,
				idxByName: arrayToObject(indexes, function(index) {
					return [index.name, index];
				})
			};
		}
		function safariMultiStoreFix(storeNames) {
			return storeNames.length === 1 ? storeNames[0] : storeNames;
		}
		var getMaxKey = function(IdbKeyRange) {
			try {
				IdbKeyRange.only([[]]);
				getMaxKey = function() {
					return [[]];
				};
				return [[]];
			} catch (e) {
				getMaxKey = function() {
					return maxString;
				};
				return maxString;
			}
		};
		function getKeyExtractor(keyPath) {
			if (keyPath == null) return function() {};
			else if (typeof keyPath === "string") return getSinglePathKeyExtractor(keyPath);
			else return function(obj) {
				return getByKeyPath(obj, keyPath);
			};
		}
		function getSinglePathKeyExtractor(keyPath) {
			if (keyPath.split(".").length === 1) return function(obj) {
				return obj[keyPath];
			};
			else return function(obj) {
				return getByKeyPath(obj, keyPath);
			};
		}
		function arrayify(arrayLike) {
			return [].slice.call(arrayLike);
		}
		var _id_counter = 0;
		function getKeyPathAlias(keyPath) {
			return keyPath == null ? ":id" : typeof keyPath === "string" ? keyPath : "[".concat(keyPath.join("+"), "]");
		}
		function createDBCore(db, IdbKeyRange, tmpTrans) {
			function extractSchema(db, trans) {
				var tables = arrayify(db.objectStoreNames);
				var tempStore = tables.length > 0 ? trans.objectStore(tables[0]) : {};
				return {
					schema: {
						name: db.name,
						tables: tables.map(function(table) {
							return trans.objectStore(table);
						}).map(function(store) {
							var keyPath = store.keyPath, autoIncrement = store.autoIncrement;
							var compound = isArray(keyPath);
							var outbound = keyPath == null;
							var indexByKeyPath = {};
							var result = {
								name: store.name,
								primaryKey: {
									name: null,
									isPrimaryKey: true,
									outbound,
									compound,
									keyPath,
									autoIncrement,
									unique: true,
									extractKey: getKeyExtractor(keyPath)
								},
								indexes: arrayify(store.indexNames).map(function(indexName) {
									return store.index(indexName);
								}).map(function(index) {
									var name = index.name, unique = index.unique, multiEntry = index.multiEntry, keyPath = index.keyPath;
									var result = {
										name,
										compound: isArray(keyPath),
										keyPath,
										unique,
										multiEntry,
										extractKey: getKeyExtractor(keyPath)
									};
									indexByKeyPath[getKeyPathAlias(keyPath)] = result;
									return result;
								}),
								getIndexByKeyPath: function(keyPath) {
									return indexByKeyPath[getKeyPathAlias(keyPath)];
								}
							};
							indexByKeyPath[":id"] = result.primaryKey;
							if (keyPath != null) indexByKeyPath[getKeyPathAlias(keyPath)] = result.primaryKey;
							return result;
						})
					},
					hasGetAll: tables.length > 0 && "getAll" in tempStore && !(typeof navigator !== "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604),
					hasIdb3Features: "getAllRecords" in tempStore
				};
			}
			function makeIDBKeyRange(range) {
				if (range.type === 3) return null;
				if (range.type === 4) throw new Error("Cannot convert never type to IDBKeyRange");
				var lower = range.lower, upper = range.upper, lowerOpen = range.lowerOpen, upperOpen = range.upperOpen;
				return lower === void 0 ? upper === void 0 ? null : IdbKeyRange.upperBound(upper, !!upperOpen) : upper === void 0 ? IdbKeyRange.lowerBound(lower, !!lowerOpen) : IdbKeyRange.bound(lower, upper, !!lowerOpen, !!upperOpen);
			}
			function createDbCoreTable(tableSchema) {
				var tableName = tableSchema.name;
				function mutate(_a) {
					var trans = _a.trans, type = _a.type, keys = _a.keys, values = _a.values, range = _a.range;
					return new Promise(function(resolve, reject) {
						resolve = wrap(resolve);
						var store = trans.objectStore(tableName);
						var outbound = store.keyPath == null;
						var isAddOrPut = type === "put" || type === "add";
						if (!isAddOrPut && type !== "delete" && type !== "deleteRange") throw new Error("Invalid operation type: " + type);
						var length = (keys || values || { length: 1 }).length;
						if (keys && values && keys.length !== values.length) throw new Error("Given keys array must have same length as given values array.");
						if (length === 0) return resolve({
							numFailures: 0,
							failures: {},
							results: [],
							lastResult: void 0
						});
						var req;
						var reqs = [];
						var failures = [];
						var numFailures = 0;
						var errorHandler = function(event) {
							++numFailures;
							preventDefault(event);
						};
						if (type === "deleteRange") {
							if (range.type === 4) return resolve({
								numFailures,
								failures,
								results: [],
								lastResult: void 0
							});
							if (range.type === 3) reqs.push(req = store.clear());
							else reqs.push(req = store.delete(makeIDBKeyRange(range)));
						} else {
							var _a = isAddOrPut ? outbound ? [values, keys] : [values, null] : [keys, null], args1 = _a[0], args2 = _a[1];
							if (isAddOrPut) for (var i = 0; i < length; ++i) {
								reqs.push(req = args2 && args2[i] !== void 0 ? store[type](args1[i], args2[i]) : store[type](args1[i]));
								req.onerror = errorHandler;
							}
							else for (var i = 0; i < length; ++i) {
								reqs.push(req = store[type](args1[i]));
								req.onerror = errorHandler;
							}
						}
						var done = function(event) {
							var lastResult = event.target.result;
							reqs.forEach(function(req, i) {
								return req.error != null && (failures[i] = req.error);
							});
							resolve({
								numFailures,
								failures,
								results: type === "delete" ? keys : reqs.map(function(req) {
									return req.result;
								}),
								lastResult
							});
						};
						req.onerror = function(event) {
							errorHandler(event);
							done(event);
						};
						req.onsuccess = done;
					});
				}
				function openCursor(_a) {
					var trans = _a.trans, values = _a.values, query = _a.query, reverse = _a.reverse, unique = _a.unique;
					return new Promise(function(resolve, reject) {
						resolve = wrap(resolve);
						var index = query.index, range = query.range;
						var store = trans.objectStore(tableName);
						var source = index.isPrimaryKey ? store : store.index(index.name);
						var direction = reverse ? unique ? "prevunique" : "prev" : unique ? "nextunique" : "next";
						var req = values || !("openKeyCursor" in source) ? source.openCursor(makeIDBKeyRange(range), direction) : source.openKeyCursor(makeIDBKeyRange(range), direction);
						req.onerror = eventRejectHandler(reject);
						req.onsuccess = wrap(function(ev) {
							var cursor = req.result;
							if (!cursor) {
								resolve(null);
								return;
							}
							cursor.___id = ++_id_counter;
							cursor.done = false;
							var _cursorContinue = cursor.continue.bind(cursor);
							var _cursorContinuePrimaryKey = cursor.continuePrimaryKey;
							if (_cursorContinuePrimaryKey) _cursorContinuePrimaryKey = _cursorContinuePrimaryKey.bind(cursor);
							var _cursorAdvance = cursor.advance.bind(cursor);
							var doThrowCursorIsNotStarted = function() {
								throw new Error("Cursor not started");
							};
							var doThrowCursorIsStopped = function() {
								throw new Error("Cursor not stopped");
							};
							cursor.trans = trans;
							cursor.stop = cursor.continue = cursor.continuePrimaryKey = cursor.advance = doThrowCursorIsNotStarted;
							cursor.fail = wrap(reject);
							cursor.next = function() {
								var _this = this;
								var gotOne = 1;
								return this.start(function() {
									return gotOne-- ? _this.continue() : _this.stop();
								}).then(function() {
									return _this;
								});
							};
							cursor.start = function(callback) {
								var iterationPromise = new Promise(function(resolveIteration, rejectIteration) {
									resolveIteration = wrap(resolveIteration);
									req.onerror = eventRejectHandler(rejectIteration);
									cursor.fail = rejectIteration;
									cursor.stop = function(value) {
										cursor.stop = cursor.continue = cursor.continuePrimaryKey = cursor.advance = doThrowCursorIsStopped;
										resolveIteration(value);
									};
								});
								var guardedCallback = function() {
									if (req.result) try {
										callback();
									} catch (err) {
										cursor.fail(err);
									}
									else {
										cursor.done = true;
										cursor.start = function() {
											throw new Error("Cursor behind last entry");
										};
										cursor.stop();
									}
								};
								req.onsuccess = wrap(function(ev) {
									req.onsuccess = guardedCallback;
									guardedCallback();
								});
								cursor.continue = _cursorContinue;
								cursor.continuePrimaryKey = _cursorContinuePrimaryKey;
								cursor.advance = _cursorAdvance;
								guardedCallback();
								return iterationPromise;
							};
							resolve(cursor);
						}, reject);
					});
				}
				function query(hasGetAll, hasIdb3Features) {
					return function(request) {
						return new Promise(function(resolve, reject) {
							var _a;
							resolve = wrap(resolve);
							var trans = request.trans, values = request.values, limit = request.limit, query = request.query;
							var direction = (_a = request.direction) !== null && _a !== void 0 ? _a : "next";
							var nonInfinitLimit = limit === Infinity ? void 0 : limit;
							var index = query.index, range = query.range;
							var store = trans.objectStore(tableName);
							var source = index.isPrimaryKey ? store : store.index(index.name);
							var idbKeyRange = makeIDBKeyRange(range);
							if (limit === 0) return resolve({ result: [] });
							if (hasIdb3Features) {
								var options = {
									query: idbKeyRange,
									count: nonInfinitLimit,
									direction
								};
								var req = values ? source.getAll(options) : source.getAllKeys(options);
								req.onsuccess = function(event) {
									return resolve({ result: event.target.result });
								};
								req.onerror = eventRejectHandler(reject);
							} else if (hasGetAll && direction === "next") {
								var req = values ? source.getAll(idbKeyRange, nonInfinitLimit) : source.getAllKeys(idbKeyRange, nonInfinitLimit);
								req.onsuccess = function(event) {
									return resolve({ result: event.target.result });
								};
								req.onerror = eventRejectHandler(reject);
							} else {
								var count_1 = 0;
								var req_1 = values || !("openKeyCursor" in source) ? source.openCursor(idbKeyRange, direction) : source.openKeyCursor(idbKeyRange, direction);
								var result_1 = [];
								req_1.onsuccess = function() {
									var cursor = req_1.result;
									if (!cursor) return resolve({ result: result_1 });
									result_1.push(values ? cursor.value : cursor.primaryKey);
									if (++count_1 === limit) return resolve({ result: result_1 });
									cursor.continue();
								};
								req_1.onerror = eventRejectHandler(reject);
							}
						});
					};
				}
				return {
					name: tableName,
					schema: tableSchema,
					mutate,
					getMany: function(_a) {
						var trans = _a.trans, keys = _a.keys;
						return new Promise(function(resolve, reject) {
							resolve = wrap(resolve);
							var store = trans.objectStore(tableName);
							var length = keys.length;
							var result = new Array(length);
							var keyCount = 0;
							var callbackCount = 0;
							var req;
							var successHandler = function(event) {
								var req = event.target;
								if ((result[req._pos] = req.result) != null);
								if (++callbackCount === keyCount) resolve(result);
							};
							var errorHandler = eventRejectHandler(reject);
							for (var i = 0; i < length; ++i) if (keys[i] != null) {
								req = store.get(keys[i]);
								req._pos = i;
								req.onsuccess = successHandler;
								req.onerror = errorHandler;
								++keyCount;
							}
							if (keyCount === 0) resolve(result);
						});
					},
					get: function(_a) {
						var trans = _a.trans, key = _a.key;
						return new Promise(function(resolve, reject) {
							resolve = wrap(resolve);
							var req = trans.objectStore(tableName).get(key);
							req.onsuccess = function(event) {
								return resolve(event.target.result);
							};
							req.onerror = eventRejectHandler(reject);
						});
					},
					query: query(hasGetAll, hasIdb3Features),
					openCursor,
					count: function(_a) {
						var query = _a.query, trans = _a.trans;
						var index = query.index, range = query.range;
						return new Promise(function(resolve, reject) {
							var store = trans.objectStore(tableName);
							var source = index.isPrimaryKey ? store : store.index(index.name);
							var idbKeyRange = makeIDBKeyRange(range);
							var req = idbKeyRange ? source.count(idbKeyRange) : source.count();
							req.onsuccess = wrap(function(ev) {
								return resolve(ev.target.result);
							});
							req.onerror = eventRejectHandler(reject);
						});
					}
				};
			}
			var _a = extractSchema(db, tmpTrans), schema = _a.schema, hasGetAll = _a.hasGetAll, hasIdb3Features = _a.hasIdb3Features;
			var tables = schema.tables.map(function(tableSchema) {
				return createDbCoreTable(tableSchema);
			});
			var tableMap = {};
			tables.forEach(function(table) {
				return tableMap[table.name] = table;
			});
			return {
				stack: "dbcore",
				transaction: db.transaction.bind(db),
				table: function(name) {
					if (!tableMap[name]) throw new Error("Table '".concat(name, "' not found"));
					return tableMap[name];
				},
				MIN_KEY: -Infinity,
				MAX_KEY: getMaxKey(IdbKeyRange),
				schema
			};
		}
		function createMiddlewareStack(stackImpl, middlewares) {
			return middlewares.reduce(function(down, _a) {
				var create = _a.create;
				return __assign(__assign({}, down), create(down));
			}, stackImpl);
		}
		function createMiddlewareStacks(middlewares, idbdb, _a, tmpTrans) {
			var IDBKeyRange = _a.IDBKeyRange;
			_a.indexedDB;
			return { dbcore: createMiddlewareStack(createDBCore(idbdb, IDBKeyRange, tmpTrans), middlewares.dbcore) };
		}
		function generateMiddlewareStacks(db, tmpTrans) {
			var idbdb = tmpTrans.db;
			db.core = createMiddlewareStacks(db._middlewares, idbdb, db._deps, tmpTrans).dbcore;
			db.tables.forEach(function(table) {
				var tableName = table.name;
				if (db.core.schema.tables.some(function(tbl) {
					return tbl.name === tableName;
				})) {
					table.core = db.core.table(tableName);
					if (db[tableName] instanceof db.Table) db[tableName].core = table.core;
				}
			});
		}
		function setApiOnPlace(db, objs, tableNames, dbschema) {
			tableNames.forEach(function(tableName) {
				var schema = dbschema[tableName];
				objs.forEach(function(obj) {
					var propDesc = getPropertyDescriptor(obj, tableName);
					if (!propDesc || "value" in propDesc && propDesc.value === void 0) {
						if (obj === db.Transaction.prototype || obj instanceof db.Transaction) setProp(obj, tableName, {
							get: function() {
								return this.table(tableName);
							},
							set: function(value) {
								defineProperty(this, tableName, {
									value,
									writable: true,
									configurable: true,
									enumerable: true
								});
							}
						});
						else obj[tableName] = new db.Table(tableName, schema);
					}
				});
			});
		}
		function removeTablesApi(db, objs) {
			objs.forEach(function(obj) {
				for (var key in obj) if (obj[key] instanceof db.Table) delete obj[key];
			});
		}
		function lowerVersionFirst(a, b) {
			return a._cfg.version - b._cfg.version;
		}
		function runUpgraders(db, oldVersion, idbUpgradeTrans, reject) {
			var globalSchema = db._dbSchema;
			if (idbUpgradeTrans.objectStoreNames.contains("$meta") && !globalSchema.$meta) {
				globalSchema.$meta = createTableSchema("$meta", parseIndexSyntax("")[0], []);
				db._storeNames.push("$meta");
			}
			var trans = db._createTransaction("readwrite", db._storeNames, globalSchema);
			trans.create(idbUpgradeTrans);
			trans._completion.catch(reject);
			var rejectTransaction = trans._reject.bind(trans);
			var transless = PSD.transless || PSD;
			newScope(function() {
				PSD.trans = trans;
				PSD.transless = transless;
				if (oldVersion === 0) {
					keys(globalSchema).forEach(function(tableName) {
						createTable(idbUpgradeTrans, tableName, globalSchema[tableName].primKey, globalSchema[tableName].indexes);
					});
					generateMiddlewareStacks(db, idbUpgradeTrans);
					DexiePromise.follow(function() {
						return db.on.populate.fire(trans);
					}).catch(rejectTransaction);
				} else {
					generateMiddlewareStacks(db, idbUpgradeTrans);
					return getExistingVersion(db, trans, oldVersion).then(function(oldVersion) {
						return updateTablesAndIndexes(db, oldVersion, trans, idbUpgradeTrans);
					}).catch(rejectTransaction);
				}
			});
		}
		function patchCurrentVersion(db, idbUpgradeTrans) {
			createMissingTables(db._dbSchema, idbUpgradeTrans);
			if (idbUpgradeTrans.db.version % 10 === 0 && !idbUpgradeTrans.objectStoreNames.contains("$meta")) idbUpgradeTrans.db.createObjectStore("$meta").add(Math.ceil(idbUpgradeTrans.db.version / 10 - 1), "version");
			var globalSchema = buildGlobalSchema(db, db.idbdb, idbUpgradeTrans);
			adjustToExistingIndexNames(db, db._dbSchema, idbUpgradeTrans);
			var diff = getSchemaDiff(globalSchema, db._dbSchema);
			var _loop_1 = function(tableChange) {
				if (tableChange.change.length || tableChange.recreate) {
					console.warn("Unable to patch indexes of table ".concat(tableChange.name, " because it has changes on the type of index or primary key."));
					return { value: void 0 };
				}
				var store = idbUpgradeTrans.objectStore(tableChange.name);
				tableChange.add.forEach(function(idx) {
					if (debug) console.debug("Dexie upgrade patch: Creating missing index ".concat(tableChange.name, ".").concat(idx.src));
					addIndex(store, idx);
				});
			};
			for (var _i = 0, _a = diff.change; _i < _a.length; _i++) {
				var tableChange = _a[_i];
				var state_1 = _loop_1(tableChange);
				if (typeof state_1 === "object") return state_1.value;
			}
		}
		function getExistingVersion(db, trans, oldVersion) {
			if (trans.storeNames.includes("$meta")) return trans.table("$meta").get("version").then(function(metaVersion) {
				return metaVersion != null ? metaVersion : oldVersion;
			});
			else return DexiePromise.resolve(oldVersion);
		}
		function updateTablesAndIndexes(db, oldVersion, trans, idbUpgradeTrans) {
			var queue = [];
			var versions = db._versions;
			var globalSchema = db._dbSchema = buildGlobalSchema(db, db.idbdb, idbUpgradeTrans);
			var versToRun = versions.filter(function(v) {
				return v._cfg.version >= oldVersion;
			});
			if (versToRun.length === 0) return DexiePromise.resolve();
			versToRun.forEach(function(version) {
				queue.push(function() {
					var oldSchema = globalSchema;
					var newSchema = version._cfg.dbschema;
					adjustToExistingIndexNames(db, oldSchema, idbUpgradeTrans);
					adjustToExistingIndexNames(db, newSchema, idbUpgradeTrans);
					globalSchema = db._dbSchema = newSchema;
					var diff = getSchemaDiff(oldSchema, newSchema);
					diff.add.forEach(function(tuple) {
						createTable(idbUpgradeTrans, tuple[0], tuple[1].primKey, tuple[1].indexes);
					});
					diff.change.forEach(function(change) {
						if (change.recreate) throw new exceptions.Upgrade("Not yet support for changing primary key");
						else {
							var store_1 = idbUpgradeTrans.objectStore(change.name);
							change.add.forEach(function(idx) {
								return addIndex(store_1, idx);
							});
							change.change.forEach(function(idx) {
								store_1.deleteIndex(idx.name);
								addIndex(store_1, idx);
							});
							change.del.forEach(function(idxName) {
								return store_1.deleteIndex(idxName);
							});
						}
					});
					var contentUpgrade = version._cfg.contentUpgrade;
					if (contentUpgrade && version._cfg.version > oldVersion) {
						generateMiddlewareStacks(db, idbUpgradeTrans);
						trans._memoizedTables = {};
						var upgradeSchema_1 = shallowClone(newSchema);
						diff.del.forEach(function(table) {
							upgradeSchema_1[table] = oldSchema[table];
						});
						removeTablesApi(db, [db.Transaction.prototype]);
						setApiOnPlace(db, [db.Transaction.prototype], keys(upgradeSchema_1), upgradeSchema_1);
						trans.schema = upgradeSchema_1;
						var contentUpgradeIsAsync_1 = isAsyncFunction(contentUpgrade);
						if (contentUpgradeIsAsync_1) incrementExpectedAwaits();
						var returnValue_1;
						var promiseFollowed = DexiePromise.follow(function() {
							returnValue_1 = contentUpgrade(trans);
							if (returnValue_1) {
								if (contentUpgradeIsAsync_1) {
									var decrementor = decrementExpectedAwaits.bind(null, null);
									returnValue_1.then(decrementor, decrementor);
								}
							}
						});
						return returnValue_1 && typeof returnValue_1.then === "function" ? DexiePromise.resolve(returnValue_1) : promiseFollowed.then(function() {
							return returnValue_1;
						});
					}
				});
				queue.push(function(idbtrans) {
					var newSchema = version._cfg.dbschema;
					deleteRemovedTables(newSchema, idbtrans);
					removeTablesApi(db, [db.Transaction.prototype]);
					setApiOnPlace(db, [db.Transaction.prototype], db._storeNames, db._dbSchema);
					trans.schema = db._dbSchema;
				});
				queue.push(function(idbtrans) {
					if (db.idbdb.objectStoreNames.contains("$meta")) {
						if (Math.ceil(db.idbdb.version / 10) === version._cfg.version) {
							db.idbdb.deleteObjectStore("$meta");
							delete db._dbSchema.$meta;
							db._storeNames = db._storeNames.filter(function(name) {
								return name !== "$meta";
							});
						} else idbtrans.objectStore("$meta").put(version._cfg.version, "version");
					}
				});
			});
			function runQueue() {
				return queue.length ? DexiePromise.resolve(queue.shift()(trans.idbtrans)).then(runQueue) : DexiePromise.resolve();
			}
			return runQueue().then(function() {
				createMissingTables(globalSchema, idbUpgradeTrans);
			});
		}
		function getSchemaDiff(oldSchema, newSchema) {
			var diff = {
				del: [],
				add: [],
				change: []
			};
			var table;
			for (table in oldSchema) if (!newSchema[table]) diff.del.push(table);
			for (table in newSchema) {
				var oldDef = oldSchema[table], newDef = newSchema[table];
				if (!oldDef) diff.add.push([table, newDef]);
				else {
					var change = {
						name: table,
						def: newDef,
						recreate: false,
						del: [],
						add: [],
						change: []
					};
					if ("" + (oldDef.primKey.keyPath || "") !== "" + (newDef.primKey.keyPath || "") || oldDef.primKey.auto !== newDef.primKey.auto) {
						change.recreate = true;
						diff.change.push(change);
					} else {
						var oldIndexes = oldDef.idxByName;
						var newIndexes = newDef.idxByName;
						var idxName = void 0;
						for (idxName in oldIndexes) if (!newIndexes[idxName]) change.del.push(idxName);
						for (idxName in newIndexes) {
							var oldIdx = oldIndexes[idxName], newIdx = newIndexes[idxName];
							if (!oldIdx) change.add.push(newIdx);
							else if (oldIdx.src !== newIdx.src) change.change.push(newIdx);
						}
						if (change.del.length > 0 || change.add.length > 0 || change.change.length > 0) diff.change.push(change);
					}
				}
			}
			return diff;
		}
		function createTable(idbtrans, tableName, primKey, indexes) {
			var store = idbtrans.db.createObjectStore(tableName, primKey.keyPath ? {
				keyPath: primKey.keyPath,
				autoIncrement: primKey.auto
			} : { autoIncrement: primKey.auto });
			indexes.forEach(function(idx) {
				return addIndex(store, idx);
			});
			return store;
		}
		function createMissingTables(newSchema, idbtrans) {
			keys(newSchema).forEach(function(tableName) {
				if (!idbtrans.db.objectStoreNames.contains(tableName)) {
					if (debug) console.debug("Dexie: Creating missing table", tableName);
					createTable(idbtrans, tableName, newSchema[tableName].primKey, newSchema[tableName].indexes);
				}
			});
		}
		function deleteRemovedTables(newSchema, idbtrans) {
			[].slice.call(idbtrans.db.objectStoreNames).forEach(function(storeName) {
				return newSchema[storeName] == null && idbtrans.db.deleteObjectStore(storeName);
			});
		}
		function addIndex(store, idx) {
			store.createIndex(idx.name, idx.keyPath, {
				unique: idx.unique,
				multiEntry: idx.multi
			});
		}
		function buildGlobalSchema(db, idbdb, tmpTrans) {
			var globalSchema = {};
			slice(idbdb.objectStoreNames, 0).forEach(function(storeName) {
				var store = tmpTrans.objectStore(storeName);
				var keyPath = store.keyPath;
				var primKey = createIndexSpec(nameFromKeyPath(keyPath), keyPath || "", true, false, !!store.autoIncrement, keyPath && typeof keyPath !== "string", true);
				var indexes = [];
				for (var j = 0; j < store.indexNames.length; ++j) {
					var idbindex = store.index(store.indexNames[j]);
					keyPath = idbindex.keyPath;
					var index = createIndexSpec(idbindex.name, keyPath, !!idbindex.unique, !!idbindex.multiEntry, false, keyPath && typeof keyPath !== "string", false);
					indexes.push(index);
				}
				globalSchema[storeName] = createTableSchema(storeName, primKey, indexes);
			});
			return globalSchema;
		}
		function readGlobalSchema(db, idbdb, tmpTrans) {
			db.verno = idbdb.version / 10;
			var globalSchema = db._dbSchema = buildGlobalSchema(db, idbdb, tmpTrans);
			db._storeNames = slice(idbdb.objectStoreNames, 0);
			setApiOnPlace(db, [db._allTables], keys(globalSchema), globalSchema);
		}
		function verifyInstalledSchema(db, tmpTrans) {
			var diff = getSchemaDiff(buildGlobalSchema(db, db.idbdb, tmpTrans), db._dbSchema);
			return !(diff.add.length || diff.change.some(function(ch) {
				return ch.add.length || ch.change.length;
			}));
		}
		function adjustToExistingIndexNames(db, schema, idbtrans) {
			var storeNames = idbtrans.db.objectStoreNames;
			for (var i = 0; i < storeNames.length; ++i) {
				var storeName = storeNames[i];
				var store = idbtrans.objectStore(storeName);
				db._hasGetAll = "getAll" in store;
				for (var j = 0; j < store.indexNames.length; ++j) {
					var indexName = store.indexNames[j];
					var keyPath = store.index(indexName).keyPath;
					var dexieName = typeof keyPath === "string" ? keyPath : "[" + slice(keyPath).join("+") + "]";
					if (schema[storeName]) {
						var indexSpec = schema[storeName].idxByName[dexieName];
						if (indexSpec) {
							indexSpec.name = indexName;
							delete schema[storeName].idxByName[dexieName];
							schema[storeName].idxByName[indexName] = indexSpec;
						}
					}
				}
			}
			if (typeof navigator !== "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && _global.WorkerGlobalScope && _global instanceof _global.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604) db._hasGetAll = false;
		}
		function parseIndexSyntax(primKeyAndIndexes) {
			return primKeyAndIndexes.split(",").map(function(index, indexNum) {
				var _a;
				var typeSplit = index.split(":");
				var type = (_a = typeSplit[1]) === null || _a === void 0 ? void 0 : _a.trim();
				index = typeSplit[0].trim();
				var name = index.replace(/([&*]|\+\+)/g, "");
				var keyPath = /^\[/.test(name) ? name.match(/^\[(.*)\]$/)[1].split("+") : name;
				return createIndexSpec(name, keyPath || null, /\&/.test(index), /\*/.test(index), /\+\+/.test(index), isArray(keyPath), indexNum === 0, type);
			});
		}
		var Version = function() {
			function Version() {}
			Version.prototype._createTableSchema = function(name, primKey, indexes) {
				return createTableSchema(name, primKey, indexes);
			};
			Version.prototype._parseIndexSyntax = function(primKeyAndIndexes) {
				return parseIndexSyntax(primKeyAndIndexes);
			};
			Version.prototype._parseStoresSpec = function(stores, outSchema) {
				var _this = this;
				keys(stores).forEach(function(tableName) {
					if (stores[tableName] !== null) {
						var indexes = _this._parseIndexSyntax(stores[tableName]);
						var primKey = indexes.shift();
						if (!primKey) throw new exceptions.Schema("Invalid schema for table " + tableName + ": " + stores[tableName]);
						primKey.unique = true;
						if (primKey.multi) throw new exceptions.Schema("Primary key cannot be multiEntry*");
						indexes.forEach(function(idx) {
							if (idx.auto) throw new exceptions.Schema("Only primary key can be marked as autoIncrement (++)");
							if (!idx.keyPath) throw new exceptions.Schema("Index must have a name and cannot be an empty string");
						});
						outSchema[tableName] = _this._createTableSchema(tableName, primKey, indexes);
					}
				});
			};
			Version.prototype.stores = function(stores) {
				var db = this.db;
				this._cfg.storesSource = this._cfg.storesSource ? extend(this._cfg.storesSource, stores) : stores;
				var versions = db._versions;
				var storesSpec = {};
				var dbschema = {};
				versions.forEach(function(version) {
					extend(storesSpec, version._cfg.storesSource);
					dbschema = version._cfg.dbschema = {};
					version._parseStoresSpec(storesSpec, dbschema);
				});
				db._dbSchema = dbschema;
				removeTablesApi(db, [
					db._allTables,
					db,
					db.Transaction.prototype
				]);
				setApiOnPlace(db, [
					db._allTables,
					db,
					db.Transaction.prototype,
					this._cfg.tables
				], keys(dbschema), dbschema);
				db._storeNames = keys(dbschema);
				return this;
			};
			Version.prototype.upgrade = function(upgradeFunction) {
				this._cfg.contentUpgrade = promisableChain(this._cfg.contentUpgrade || nop, upgradeFunction);
				return this;
			};
			return Version;
		}();
		function createVersionConstructor(db) {
			return makeClassConstructor(Version.prototype, function Version(versionNumber) {
				this.db = db;
				this._cfg = {
					version: versionNumber,
					storesSource: null,
					dbschema: {},
					tables: {},
					contentUpgrade: null
				};
			});
		}
		var connections = createConnectionsManager();
		function createConnectionsManager() {
			if (typeof FinalizationRegistry !== "undefined" && typeof WeakRef !== "undefined") {
				var _refs_1 = /* @__PURE__ */ new Set();
				var _registry_1 = new FinalizationRegistry(function(ref) {
					_refs_1.delete(ref);
				});
				var toArray = function() {
					return Array.from(_refs_1).map(function(ref) {
						return ref.deref();
					}).filter(function(db) {
						return db !== void 0;
					});
				};
				var add = function(db) {
					var ref = new WeakRef(db._novip);
					_refs_1.add(ref);
					_registry_1.register(db._novip, ref, ref);
					if (_refs_1.size > db._options.maxConnections) {
						var oldestRef = _refs_1.values().next().value;
						_refs_1.delete(oldestRef);
						_registry_1.unregister(oldestRef);
					}
				};
				var remove = function(db) {
					if (!db) return;
					var iterator = _refs_1.values();
					var result = iterator.next();
					while (!result.done) {
						var ref = result.value;
						if (ref.deref() === db._novip) {
							_refs_1.delete(ref);
							_registry_1.unregister(ref);
							return;
						}
						result = iterator.next();
					}
				};
				return {
					toArray,
					add,
					remove
				};
			} else {
				var connections_1 = [];
				var toArray = function() {
					return connections_1;
				};
				var add = function(db) {
					connections_1.push(db._novip);
				};
				var remove = function(db) {
					if (!db) return;
					var index = connections_1.indexOf(db._novip);
					if (index !== -1) connections_1.splice(index, 1);
				};
				return {
					toArray,
					add,
					remove
				};
			}
		}
		function getDbNamesTable(indexedDB, IDBKeyRange) {
			var dbNamesDB = indexedDB["_dbNamesDB"];
			if (!dbNamesDB) {
				dbNamesDB = indexedDB["_dbNamesDB"] = new Dexie$1(DBNAMES_DB, {
					addons: [],
					indexedDB,
					IDBKeyRange
				});
				dbNamesDB.version(1).stores({ dbnames: "name" });
			}
			return dbNamesDB.table("dbnames");
		}
		function hasDatabasesNative(indexedDB) {
			return indexedDB && typeof indexedDB.databases === "function";
		}
		function getDatabaseNames(_a) {
			var indexedDB = _a.indexedDB, IDBKeyRange = _a.IDBKeyRange;
			return hasDatabasesNative(indexedDB) ? Promise.resolve(indexedDB.databases()).then(function(infos) {
				return infos.map(function(info) {
					return info.name;
				}).filter(function(name) {
					return name !== DBNAMES_DB;
				});
			}) : getDbNamesTable(indexedDB, IDBKeyRange).toCollection().primaryKeys();
		}
		function _onDatabaseCreated(_a, name) {
			var indexedDB = _a.indexedDB, IDBKeyRange = _a.IDBKeyRange;
			!hasDatabasesNative(indexedDB) && name !== DBNAMES_DB && getDbNamesTable(indexedDB, IDBKeyRange).put({ name }).catch(nop);
		}
		function _onDatabaseDeleted(_a, name) {
			var indexedDB = _a.indexedDB, IDBKeyRange = _a.IDBKeyRange;
			!hasDatabasesNative(indexedDB) && name !== DBNAMES_DB && getDbNamesTable(indexedDB, IDBKeyRange).delete(name).catch(nop);
		}
		function vip(fn) {
			return newScope(function() {
				PSD.letThrough = true;
				return fn();
			});
		}
		function idbReady() {
			if (!(!navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent)) || !indexedDB.databases) return Promise.resolve();
			var intervalId;
			return new Promise(function(resolve) {
				var tryIdb = function() {
					return indexedDB.databases().finally(resolve);
				};
				intervalId = setInterval(tryIdb, 100);
				tryIdb();
			}).finally(function() {
				return clearInterval(intervalId);
			});
		}
		var _a;
		function isEmptyRange(node) {
			return !("from" in node);
		}
		var RangeSet = function(fromOrTree, to) {
			if (this) extend(this, arguments.length ? {
				d: 1,
				from: fromOrTree,
				to: arguments.length > 1 ? to : fromOrTree
			} : { d: 0 });
			else {
				var rv = new RangeSet();
				if (fromOrTree && "d" in fromOrTree) extend(rv, fromOrTree);
				return rv;
			}
		};
		props(RangeSet.prototype, (_a = {
			add: function(rangeSet) {
				mergeRanges(this, rangeSet);
				return this;
			},
			addKey: function(key) {
				addRange(this, key, key);
				return this;
			},
			addKeys: function(keys) {
				var _this = this;
				keys.forEach(function(key) {
					return addRange(_this, key, key);
				});
				return this;
			},
			hasKey: function(key) {
				var node = getRangeSetIterator(this).next(key).value;
				return node && cmp(node.from, key) <= 0 && cmp(node.to, key) >= 0;
			}
		}, _a[iteratorSymbol] = function() {
			return getRangeSetIterator(this);
		}, _a));
		function addRange(target, from, to) {
			var diff = cmp(from, to);
			if (isNaN(diff)) return;
			if (diff > 0) throw RangeError();
			if (isEmptyRange(target)) return extend(target, {
				from,
				to,
				d: 1
			});
			var left = target.l;
			var right = target.r;
			if (cmp(to, target.from) < 0) {
				left ? addRange(left, from, to) : target.l = {
					from,
					to,
					d: 1,
					l: null,
					r: null
				};
				return rebalance(target);
			}
			if (cmp(from, target.to) > 0) {
				right ? addRange(right, from, to) : target.r = {
					from,
					to,
					d: 1,
					l: null,
					r: null
				};
				return rebalance(target);
			}
			if (cmp(from, target.from) < 0) {
				target.from = from;
				target.l = null;
				target.d = right ? right.d + 1 : 1;
			}
			if (cmp(to, target.to) > 0) {
				target.to = to;
				target.r = null;
				target.d = target.l ? target.l.d + 1 : 1;
			}
			var rightWasCutOff = !target.r;
			if (left && !target.l) mergeRanges(target, left);
			if (right && rightWasCutOff) mergeRanges(target, right);
		}
		function mergeRanges(target, newSet) {
			function _addRangeSet(target, _a) {
				var from = _a.from, to = _a.to, l = _a.l, r = _a.r;
				addRange(target, from, to);
				if (l) _addRangeSet(target, l);
				if (r) _addRangeSet(target, r);
			}
			if (!isEmptyRange(newSet)) _addRangeSet(target, newSet);
		}
		function rangesOverlap(rangeSet1, rangeSet2) {
			var i1 = getRangeSetIterator(rangeSet2);
			var nextResult1 = i1.next();
			if (nextResult1.done) return false;
			var a = nextResult1.value;
			var i2 = getRangeSetIterator(rangeSet1);
			var nextResult2 = i2.next(a.from);
			var b = nextResult2.value;
			while (!nextResult1.done && !nextResult2.done) {
				if (cmp(b.from, a.to) <= 0 && cmp(b.to, a.from) >= 0) return true;
				cmp(a.from, b.from) < 0 ? a = (nextResult1 = i1.next(b.from)).value : b = (nextResult2 = i2.next(a.from)).value;
			}
			return false;
		}
		function getRangeSetIterator(node) {
			var state = isEmptyRange(node) ? null : {
				s: 0,
				n: node
			};
			return { next: function(key) {
				var keyProvided = arguments.length > 0;
				while (state) switch (state.s) {
					case 0:
						state.s = 1;
						if (keyProvided) while (state.n.l && cmp(key, state.n.from) < 0) state = {
							up: state,
							n: state.n.l,
							s: 1
						};
						else while (state.n.l) state = {
							up: state,
							n: state.n.l,
							s: 1
						};
					case 1:
						state.s = 2;
						if (!keyProvided || cmp(key, state.n.to) <= 0) return {
							value: state.n,
							done: false
						};
					case 2: if (state.n.r) {
						state.s = 3;
						state = {
							up: state,
							n: state.n.r,
							s: 0
						};
						continue;
					}
					case 3: state = state.up;
				}
				return { done: true };
			} };
		}
		function rebalance(target) {
			var _a, _b;
			var diff = (((_a = target.r) === null || _a === void 0 ? void 0 : _a.d) || 0) - (((_b = target.l) === null || _b === void 0 ? void 0 : _b.d) || 0);
			var r = diff > 1 ? "r" : diff < -1 ? "l" : "";
			if (r) {
				var l = r === "r" ? "l" : "r";
				var rootClone = __assign({}, target);
				var oldRootRight = target[r];
				target.from = oldRootRight.from;
				target.to = oldRootRight.to;
				target[r] = oldRootRight[r];
				rootClone[r] = oldRootRight[l];
				target[l] = rootClone;
				rootClone.d = computeDepth(rootClone);
			}
			target.d = computeDepth(target);
		}
		function computeDepth(_a) {
			var r = _a.r, l = _a.l;
			return (r ? l ? Math.max(r.d, l.d) : r.d : l ? l.d : 0) + 1;
		}
		function extendObservabilitySet(target, newSet) {
			keys(newSet).forEach(function(part) {
				if (target[part]) mergeRanges(target[part], newSet[part]);
				else target[part] = cloneSimpleObjectTree(newSet[part]);
			});
			return target;
		}
		function obsSetsOverlap(os1, os2) {
			return os1.all || os2.all || Object.keys(os1).some(function(key) {
				return os2[key] && rangesOverlap(os2[key], os1[key]);
			});
		}
		var cache = {};
		var unsignaledParts = {};
		var isTaskEnqueued = false;
		function signalSubscribersLazily(part, optimistic) {
			extendObservabilitySet(unsignaledParts, part);
			if (!isTaskEnqueued) {
				isTaskEnqueued = true;
				setTimeout(function() {
					isTaskEnqueued = false;
					var parts = unsignaledParts;
					unsignaledParts = {};
					signalSubscribersNow(parts, false);
				}, 0);
			}
		}
		function signalSubscribersNow(updatedParts, deleteAffectedCacheEntries) {
			if (deleteAffectedCacheEntries === void 0) deleteAffectedCacheEntries = false;
			var queriesToSignal = /* @__PURE__ */ new Set();
			if (updatedParts.all) for (var _i = 0, _a = Object.values(cache); _i < _a.length; _i++) {
				var tblCache = _a[_i];
				collectTableSubscribers(tblCache, updatedParts, queriesToSignal, deleteAffectedCacheEntries);
			}
			else for (var key in updatedParts) {
				var parts = /^idb\:\/\/(.*)\/(.*)\//.exec(key);
				if (parts) {
					var dbName = parts[1], tableName = parts[2];
					var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
					if (tblCache) collectTableSubscribers(tblCache, updatedParts, queriesToSignal, deleteAffectedCacheEntries);
				}
			}
			queriesToSignal.forEach(function(requery) {
				return requery();
			});
		}
		function collectTableSubscribers(tblCache, updatedParts, outQueriesToSignal, deleteAffectedCacheEntries) {
			var updatedEntryLists = [];
			for (var _i = 0, _a = Object.entries(tblCache.queries.query); _i < _a.length; _i++) {
				var _b = _a[_i], indexName = _b[0], entries = _b[1];
				var filteredEntries = [];
				for (var _c = 0, entries_1 = entries; _c < entries_1.length; _c++) {
					var entry = entries_1[_c];
					if (obsSetsOverlap(updatedParts, entry.obsSet)) entry.subscribers.forEach(function(requery) {
						return outQueriesToSignal.add(requery);
					});
					else if (deleteAffectedCacheEntries) filteredEntries.push(entry);
				}
				if (deleteAffectedCacheEntries) updatedEntryLists.push([indexName, filteredEntries]);
			}
			if (deleteAffectedCacheEntries) for (var _d = 0, updatedEntryLists_1 = updatedEntryLists; _d < updatedEntryLists_1.length; _d++) {
				var _e = updatedEntryLists_1[_d], indexName = _e[0], filteredEntries = _e[1];
				tblCache.queries.query[indexName] = filteredEntries;
			}
		}
		function dexieOpen(db) {
			var state = db._state;
			var indexedDB = db._deps.indexedDB;
			if (state.isBeingOpened || db.idbdb) return state.dbReadyPromise.then(function() {
				return state.dbOpenError ? rejection(state.dbOpenError) : db;
			});
			state.isBeingOpened = true;
			state.dbOpenError = null;
			state.openComplete = false;
			var openCanceller = state.openCanceller;
			var nativeVerToOpen = Math.round(db.verno * 10);
			var schemaPatchMode = false;
			function throwIfCancelled() {
				if (state.openCanceller !== openCanceller) throw new exceptions.DatabaseClosed("db.open() was cancelled");
			}
			var resolveDbReady = state.dbReadyResolve, upgradeTransaction = null, wasCreated = false;
			var tryOpenDB = function() {
				return new DexiePromise(function(resolve, reject) {
					throwIfCancelled();
					if (!indexedDB) throw new exceptions.MissingAPI();
					var dbName = db.name;
					var req = state.autoSchema || !nativeVerToOpen ? indexedDB.open(dbName) : indexedDB.open(dbName, nativeVerToOpen);
					if (!req) throw new exceptions.MissingAPI();
					req.onerror = eventRejectHandler(reject);
					req.onblocked = wrap(db._fireOnBlocked);
					req.onupgradeneeded = wrap(function(e) {
						upgradeTransaction = req.transaction;
						if (state.autoSchema && !db._options.allowEmptyDB) {
							req.onerror = preventDefault;
							upgradeTransaction.abort();
							req.result.close();
							var delreq = indexedDB.deleteDatabase(dbName);
							delreq.onsuccess = delreq.onerror = wrap(function() {
								reject(new exceptions.NoSuchDatabase("Database ".concat(dbName, " doesnt exist")));
							});
						} else {
							upgradeTransaction.onerror = eventRejectHandler(reject);
							var oldVer = e.oldVersion > Math.pow(2, 62) ? 0 : e.oldVersion;
							wasCreated = oldVer < 1;
							db.idbdb = req.result;
							if (schemaPatchMode) patchCurrentVersion(db, upgradeTransaction);
							runUpgraders(db, oldVer / 10, upgradeTransaction, reject);
						}
					}, reject);
					req.onsuccess = wrap(function() {
						upgradeTransaction = null;
						var idbdb = db.idbdb = req.result;
						var objectStoreNames = slice(idbdb.objectStoreNames);
						if (objectStoreNames.length > 0) try {
							var tmpTrans = idbdb.transaction(safariMultiStoreFix(objectStoreNames), "readonly");
							if (state.autoSchema) readGlobalSchema(db, idbdb, tmpTrans);
							else {
								adjustToExistingIndexNames(db, db._dbSchema, tmpTrans);
								if (!verifyInstalledSchema(db, tmpTrans) && !schemaPatchMode) {
									console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this.");
									idbdb.close();
									nativeVerToOpen = idbdb.version + 1;
									schemaPatchMode = true;
									return resolve(tryOpenDB());
								}
							}
							generateMiddlewareStacks(db, tmpTrans);
						} catch (e) {}
						connections.add(db);
						idbdb.onversionchange = wrap(function(ev) {
							state.vcFired = true;
							db.on("versionchange").fire(ev);
						});
						idbdb.onclose = wrap(function() {
							db.close({ disableAutoOpen: false });
						});
						if (wasCreated) _onDatabaseCreated(db._deps, dbName);
						resolve();
					}, reject);
				}).catch(function(err) {
					switch (err === null || err === void 0 ? void 0 : err.name) {
						case "UnknownError":
							if (state.PR1398_maxLoop > 0) {
								state.PR1398_maxLoop--;
								console.warn("Dexie: Workaround for Chrome UnknownError on open()");
								return tryOpenDB();
							}
							break;
						case "VersionError": if (nativeVerToOpen > 0) {
							nativeVerToOpen = 0;
							return tryOpenDB();
						}
					}
					return DexiePromise.reject(err);
				});
			};
			return DexiePromise.race([openCanceller, (typeof navigator === "undefined" ? DexiePromise.resolve() : idbReady()).then(tryOpenDB)]).then(function() {
				throwIfCancelled();
				state.onReadyBeingFired = [];
				return DexiePromise.resolve(vip(function() {
					return db.on.ready.fire(db.vip);
				})).then(function fireRemainders() {
					if (state.onReadyBeingFired.length > 0) {
						var remainders_1 = state.onReadyBeingFired.reduce(promisableChain, nop);
						state.onReadyBeingFired = [];
						return DexiePromise.resolve(vip(function() {
							return remainders_1(db.vip);
						})).then(fireRemainders);
					}
				});
			}).finally(function() {
				if (state.openCanceller === openCanceller) {
					state.onReadyBeingFired = null;
					state.isBeingOpened = false;
				}
			}).catch(function(err) {
				state.dbOpenError = err;
				try {
					upgradeTransaction && upgradeTransaction.abort();
				} catch (_a) {}
				if (openCanceller === state.openCanceller) db._close();
				return rejection(err);
			}).finally(function() {
				state.openComplete = true;
				resolveDbReady();
			}).then(function() {
				if (wasCreated) {
					var everything_1 = {};
					db.tables.forEach(function(table) {
						table.schema.indexes.forEach(function(idx) {
							if (idx.name) everything_1["idb://".concat(db.name, "/").concat(table.name, "/").concat(idx.name)] = new RangeSet(-Infinity, [[[]]]);
						});
						everything_1["idb://".concat(db.name, "/").concat(table.name, "/")] = everything_1["idb://".concat(db.name, "/").concat(table.name, "/:dels")] = new RangeSet(-Infinity, [[[]]]);
					});
					globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME).fire(everything_1);
					signalSubscribersNow(everything_1, true);
				}
				return db;
			});
		}
		function awaitIterator(iterator) {
			var callNext = function(result) {
				return iterator.next(result);
			}, doThrow = function(error) {
				return iterator.throw(error);
			}, onSuccess = step(callNext), onError = step(doThrow);
			function step(getNext) {
				return function(val) {
					var next = getNext(val), value = next.value;
					return next.done ? value : !value || typeof value.then !== "function" ? isArray(value) ? Promise.all(value).then(onSuccess, onError) : onSuccess(value) : value.then(onSuccess, onError);
				};
			}
			return step(callNext)();
		}
		function extractTransactionArgs(mode, _tableArgs_, scopeFunc) {
			var i = arguments.length;
			if (i < 2) throw new exceptions.InvalidArgument("Too few arguments");
			var args = new Array(i - 1);
			while (--i) args[i - 1] = arguments[i];
			scopeFunc = args.pop();
			return [
				mode,
				flatten(args),
				scopeFunc
			];
		}
		function enterTransactionScope(db, mode, storeNames, parentTransaction, scopeFunc) {
			return DexiePromise.resolve().then(function() {
				var transless = PSD.transless || PSD;
				var trans = db._createTransaction(mode, storeNames, db._dbSchema, parentTransaction);
				trans.explicit = true;
				var zoneProps = {
					trans,
					transless
				};
				if (parentTransaction) trans.idbtrans = parentTransaction.idbtrans;
				else try {
					trans.create();
					trans.idbtrans._explicit = true;
					db._state.PR1398_maxLoop = 3;
				} catch (ex) {
					if (ex.name === errnames.InvalidState && db.isOpen() && --db._state.PR1398_maxLoop > 0) {
						console.warn("Dexie: Need to reopen db");
						db.close({ disableAutoOpen: false });
						return db.open().then(function() {
							return enterTransactionScope(db, mode, storeNames, null, scopeFunc);
						});
					}
					return rejection(ex);
				}
				var scopeFuncIsAsync = isAsyncFunction(scopeFunc);
				if (scopeFuncIsAsync) incrementExpectedAwaits();
				var returnValue;
				var promiseFollowed = DexiePromise.follow(function() {
					returnValue = scopeFunc.call(trans, trans);
					if (returnValue) {
						if (scopeFuncIsAsync) {
							var decrementor = decrementExpectedAwaits.bind(null, null);
							returnValue.then(decrementor, decrementor);
						} else if (typeof returnValue.next === "function" && typeof returnValue.throw === "function") returnValue = awaitIterator(returnValue);
					}
				}, zoneProps);
				return (returnValue && typeof returnValue.then === "function" ? DexiePromise.resolve(returnValue).then(function(x) {
					return trans.active ? x : rejection(new exceptions.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
				}) : promiseFollowed.then(function() {
					return returnValue;
				})).then(function(x) {
					if (parentTransaction) trans._resolve();
					return trans._completion.then(function() {
						return x;
					});
				}).catch(function(e) {
					trans._reject(e);
					return rejection(e);
				});
			});
		}
		function pad(a, value, count) {
			var result = isArray(a) ? a.slice() : [a];
			for (var i = 0; i < count; ++i) result.push(value);
			return result;
		}
		function createVirtualIndexMiddleware(down) {
			return __assign(__assign({}, down), { table: function(tableName) {
				var table = down.table(tableName);
				var schema = table.schema;
				var indexLookup = Object.create(null);
				var allVirtualIndexes = [];
				function addVirtualIndexes(keyPath, keyTail, lowLevelIndex) {
					var keyPathAlias = getKeyPathAlias(keyPath);
					var indexList = indexLookup[keyPathAlias] = indexLookup[keyPathAlias] || [];
					var keyLength = keyPath == null ? 0 : typeof keyPath === "string" ? 1 : keyPath.length;
					var isVirtual = keyTail > 0;
					var virtualIndex = __assign(__assign({}, lowLevelIndex), {
						name: isVirtual ? "".concat(keyPathAlias, "(virtual-from:").concat(lowLevelIndex.name, ")") : lowLevelIndex.name,
						lowLevelIndex,
						isVirtual,
						keyTail,
						keyLength,
						extractKey: getKeyExtractor(keyPath),
						unique: !isVirtual && lowLevelIndex.unique
					});
					indexList.push(virtualIndex);
					if (!virtualIndex.isPrimaryKey) allVirtualIndexes.push(virtualIndex);
					if (keyLength > 1) addVirtualIndexes(keyLength === 2 ? keyPath[0] : keyPath.slice(0, keyLength - 1), keyTail + 1, lowLevelIndex);
					indexList.sort(function(a, b) {
						return a.keyTail - b.keyTail;
					});
					return virtualIndex;
				}
				var primaryKey = addVirtualIndexes(schema.primaryKey.keyPath, 0, schema.primaryKey);
				indexLookup[":id"] = [primaryKey];
				for (var _i = 0, _a = schema.indexes; _i < _a.length; _i++) {
					var index = _a[_i];
					addVirtualIndexes(index.keyPath, 0, index);
				}
				function findBestIndex(keyPath) {
					var result = indexLookup[getKeyPathAlias(keyPath)];
					return result && result[0];
				}
				function translateRange(range, keyTail) {
					return {
						type: range.type === 1 ? 2 : range.type,
						lower: pad(range.lower, range.lowerOpen ? down.MAX_KEY : down.MIN_KEY, keyTail),
						lowerOpen: true,
						upper: pad(range.upper, range.upperOpen ? down.MIN_KEY : down.MAX_KEY, keyTail),
						upperOpen: true
					};
				}
				function translateRequest(req) {
					var index = req.query.index;
					return index.isVirtual ? __assign(__assign({}, req), { query: {
						index: index.lowLevelIndex,
						range: translateRange(req.query.range, index.keyTail)
					} }) : req;
				}
				return __assign(__assign({}, table), {
					schema: __assign(__assign({}, schema), {
						primaryKey,
						indexes: allVirtualIndexes,
						getIndexByKeyPath: findBestIndex
					}),
					count: function(req) {
						return table.count(translateRequest(req));
					},
					query: function(req) {
						return table.query(translateRequest(req));
					},
					openCursor: function(req) {
						var _a = req.query.index, keyTail = _a.keyTail, isVirtual = _a.isVirtual, keyLength = _a.keyLength;
						if (!isVirtual) return table.openCursor(req);
						function createVirtualCursor(cursor) {
							function _continue(key) {
								key != null ? cursor.continue(pad(key, req.reverse ? down.MAX_KEY : down.MIN_KEY, keyTail)) : req.unique ? cursor.continue(cursor.key.slice(0, keyLength).concat(req.reverse ? down.MIN_KEY : down.MAX_KEY, keyTail)) : cursor.continue();
							}
							return Object.create(cursor, {
								continue: { value: _continue },
								continuePrimaryKey: { value: function(key, primaryKey) {
									cursor.continuePrimaryKey(pad(key, down.MAX_KEY, keyTail), primaryKey);
								} },
								primaryKey: { get: function() {
									return cursor.primaryKey;
								} },
								key: { get: function() {
									var key = cursor.key;
									return keyLength === 1 ? key[0] : key.slice(0, keyLength);
								} },
								value: { get: function() {
									return cursor.value;
								} }
							});
						}
						return table.openCursor(translateRequest(req)).then(function(cursor) {
							return cursor && createVirtualCursor(cursor);
						});
					}
				});
			} });
		}
		var virtualIndexMiddleware = {
			stack: "dbcore",
			name: "VirtualIndexMiddleware",
			level: 1,
			create: createVirtualIndexMiddleware
		};
		function getObjectDiff(a, b, rv, prfx) {
			rv = rv || {};
			prfx = prfx || "";
			keys(a).forEach(function(prop) {
				if (!hasOwn(b, prop)) rv[prfx + prop] = void 0;
				else {
					var ap = a[prop], bp = b[prop];
					if (typeof ap === "object" && typeof bp === "object" && ap && bp) {
						var apTypeName = toStringTag(ap);
						if (apTypeName !== toStringTag(bp)) rv[prfx + prop] = b[prop];
						else if (apTypeName === "Object") getObjectDiff(ap, bp, rv, prfx + prop + ".");
						else if (ap !== bp) rv[prfx + prop] = b[prop];
					} else if (ap !== bp) rv[prfx + prop] = b[prop];
				}
			});
			keys(b).forEach(function(prop) {
				if (!hasOwn(a, prop)) rv[prfx + prop] = b[prop];
			});
			return rv;
		}
		function getEffectiveKeys(primaryKey, req) {
			if (req.type === "delete") return req.keys;
			return req.keys || req.values.map(primaryKey.extractKey);
		}
		var hooksMiddleware = {
			stack: "dbcore",
			name: "HooksMiddleware",
			level: 2,
			create: function(downCore) {
				return __assign(__assign({}, downCore), { table: function(tableName) {
					var downTable = downCore.table(tableName);
					var primaryKey = downTable.schema.primaryKey;
					return __assign(__assign({}, downTable), { mutate: function(req) {
						var dxTrans = PSD.trans;
						var _a = dxTrans.table(tableName).hook, deleting = _a.deleting, creating = _a.creating, updating = _a.updating;
						switch (req.type) {
							case "add":
								if (creating.fire === nop) break;
								return dxTrans._promise("readwrite", function() {
									return addPutOrDelete(req);
								}, true);
							case "put":
								if (creating.fire === nop && updating.fire === nop) break;
								return dxTrans._promise("readwrite", function() {
									return addPutOrDelete(req);
								}, true);
							case "delete":
								if (deleting.fire === nop) break;
								return dxTrans._promise("readwrite", function() {
									return addPutOrDelete(req);
								}, true);
							case "deleteRange":
								if (deleting.fire === nop) break;
								return dxTrans._promise("readwrite", function() {
									return deleteRange(req);
								}, true);
						}
						return downTable.mutate(req);
						function addPutOrDelete(req) {
							var dxTrans = PSD.trans;
							var keys = req.keys || getEffectiveKeys(primaryKey, req);
							if (!keys) throw new Error("Keys missing");
							req = req.type === "add" || req.type === "put" ? __assign(__assign({}, req), { keys }) : __assign({}, req);
							if (req.type !== "delete") req.values = __spreadArray([], req.values, true);
							if (req.keys) req.keys = __spreadArray([], req.keys, true);
							return getExistingValues(downTable, req, keys).then(function(existingValues) {
								var contexts = keys.map(function(key, i) {
									var existingValue = existingValues[i];
									var ctx = {
										onerror: null,
										onsuccess: null
									};
									if (req.type === "delete") deleting.fire.call(ctx, key, existingValue, dxTrans);
									else if (req.type === "add" || existingValue === void 0) {
										var generatedPrimaryKey = creating.fire.call(ctx, key, req.values[i], dxTrans);
										if (key == null && generatedPrimaryKey != null) {
											key = generatedPrimaryKey;
											req.keys[i] = key;
											if (!primaryKey.outbound) setByKeyPath(req.values[i], primaryKey.keyPath, key);
										}
									} else {
										var objectDiff = getObjectDiff(existingValue, req.values[i]);
										var additionalChanges_1 = updating.fire.call(ctx, objectDiff, key, existingValue, dxTrans);
										if (additionalChanges_1) {
											var requestedValue_1 = req.values[i];
											Object.keys(additionalChanges_1).forEach(function(keyPath) {
												if (hasOwn(requestedValue_1, keyPath)) requestedValue_1[keyPath] = additionalChanges_1[keyPath];
												else setByKeyPath(requestedValue_1, keyPath, additionalChanges_1[keyPath]);
											});
										}
									}
									return ctx;
								});
								return downTable.mutate(req).then(function(_a) {
									var failures = _a.failures, results = _a.results, numFailures = _a.numFailures, lastResult = _a.lastResult;
									for (var i = 0; i < keys.length; ++i) {
										var primKey = results ? results[i] : keys[i];
										var ctx = contexts[i];
										if (primKey == null) ctx.onerror && ctx.onerror(failures[i]);
										else ctx.onsuccess && ctx.onsuccess(req.type === "put" && existingValues[i] ? req.values[i] : primKey);
									}
									return {
										failures,
										results,
										numFailures,
										lastResult
									};
								}).catch(function(error) {
									contexts.forEach(function(ctx) {
										return ctx.onerror && ctx.onerror(error);
									});
									return Promise.reject(error);
								});
							});
						}
						function deleteRange(req) {
							return deleteNextChunk(req.trans, req.range, 1e4);
						}
						function deleteNextChunk(trans, range, limit) {
							return downTable.query({
								trans,
								values: false,
								query: {
									index: primaryKey,
									range
								},
								limit
							}).then(function(_a) {
								var result = _a.result;
								return addPutOrDelete({
									type: "delete",
									keys: result,
									trans
								}).then(function(res) {
									if (res.numFailures > 0) return Promise.reject(res.failures[0]);
									if (result.length < limit) return {
										failures: [],
										numFailures: 0,
										lastResult: void 0
									};
									else return deleteNextChunk(trans, __assign(__assign({}, range), {
										lower: result[result.length - 1],
										lowerOpen: true
									}), limit);
								});
							});
						}
					} });
				} });
			}
		};
		function getExistingValues(table, req, effectiveKeys) {
			return req.type === "add" ? Promise.resolve([]) : table.getMany({
				trans: req.trans,
				keys: effectiveKeys,
				cache: "immutable"
			});
		}
		function getFromTransactionCache(keys, cache, clone) {
			try {
				if (!cache) return null;
				if (cache.keys.length < keys.length) return null;
				var result = [];
				for (var i = 0, j = 0; i < cache.keys.length && j < keys.length; ++i) {
					if (cmp(cache.keys[i], keys[j]) !== 0) continue;
					result.push(clone ? deepClone(cache.values[i]) : cache.values[i]);
					++j;
				}
				return result.length === keys.length ? result : null;
			} catch (_a) {
				return null;
			}
		}
		var cacheExistingValuesMiddleware = {
			stack: "dbcore",
			level: -1,
			create: function(core) {
				return { table: function(tableName) {
					var table = core.table(tableName);
					return __assign(__assign({}, table), {
						getMany: function(req) {
							if (!req.cache) return table.getMany(req);
							var cachedResult = getFromTransactionCache(req.keys, req.trans["_cache"], req.cache === "clone");
							if (cachedResult) return DexiePromise.resolve(cachedResult);
							return table.getMany(req).then(function(res) {
								req.trans["_cache"] = {
									keys: req.keys,
									values: req.cache === "clone" ? deepClone(res) : res
								};
								return res;
							});
						},
						mutate: function(req) {
							if (req.type !== "add") req.trans["_cache"] = null;
							return table.mutate(req);
						}
					});
				} };
			}
		};
		function isCachableContext(ctx, table) {
			return ctx.trans.mode === "readonly" && !!ctx.subscr && !ctx.trans.explicit && ctx.trans.db._options.cache !== "disabled" && !table.schema.primaryKey.outbound;
		}
		function isCachableRequest(type, req) {
			switch (type) {
				case "query": return req.values && !req.unique;
				case "get": return false;
				case "getMany": return false;
				case "count": return false;
				case "openCursor": return false;
			}
		}
		var observabilityMiddleware = {
			stack: "dbcore",
			level: 0,
			name: "Observability",
			create: function(core) {
				var dbName = core.schema.name;
				var FULL_RANGE = new RangeSet(core.MIN_KEY, core.MAX_KEY);
				return __assign(__assign({}, core), {
					transaction: function(stores, mode, options) {
						if (PSD.subscr && mode !== "readonly") throw new exceptions.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(PSD.querier));
						return core.transaction(stores, mode, options);
					},
					table: function(tableName) {
						var table = core.table(tableName);
						var schema = table.schema;
						var primaryKey = schema.primaryKey, indexes = schema.indexes;
						var extractKey = primaryKey.extractKey, outbound = primaryKey.outbound;
						var indexesWithAutoIncPK = primaryKey.autoIncrement && indexes.filter(function(index) {
							return index.compound && index.keyPath.includes(primaryKey.keyPath);
						});
						var tableClone = __assign(__assign({}, table), { mutate: function(req) {
							var _a, _b;
							var trans = req.trans;
							var mutatedParts = req.mutatedParts || (req.mutatedParts = {});
							var getRangeSet = function(indexName) {
								var part = "idb://".concat(dbName, "/").concat(tableName, "/").concat(indexName);
								return mutatedParts[part] || (mutatedParts[part] = new RangeSet());
							};
							var pkRangeSet = getRangeSet("");
							var delsRangeSet = getRangeSet(":dels");
							var type = req.type;
							var _c = req.type === "deleteRange" ? [req.range] : req.type === "delete" ? [req.keys] : req.values.length < 50 ? [getEffectiveKeys(primaryKey, req).filter(function(id) {
								return id;
							}), req.values] : [], keys = _c[0], newObjs = _c[1];
							var oldCache = req.trans["_cache"];
							if (isArray(keys)) {
								pkRangeSet.addKeys(keys);
								var oldObjs = type === "delete" || keys.length === newObjs.length ? getFromTransactionCache(keys, oldCache) : null;
								if (!oldObjs) delsRangeSet.addKeys(keys);
								if (oldObjs || newObjs) trackAffectedIndexes(getRangeSet, schema, oldObjs, newObjs);
							} else if (keys) {
								var range = {
									from: (_a = keys.lower) !== null && _a !== void 0 ? _a : core.MIN_KEY,
									to: (_b = keys.upper) !== null && _b !== void 0 ? _b : core.MAX_KEY
								};
								delsRangeSet.add(range);
								pkRangeSet.add(range);
							} else {
								pkRangeSet.add(FULL_RANGE);
								delsRangeSet.add(FULL_RANGE);
								schema.indexes.forEach(function(idx) {
									return getRangeSet(idx.name).add(FULL_RANGE);
								});
							}
							return table.mutate(req).then(function(res) {
								if (keys && (req.type === "add" || req.type === "put")) {
									pkRangeSet.addKeys(res.results);
									if (indexesWithAutoIncPK) indexesWithAutoIncPK.forEach(function(idx) {
										var idxVals = req.values.map(function(v) {
											return idx.extractKey(v);
										});
										var pkPos = idx.keyPath.findIndex(function(prop) {
											return prop === primaryKey.keyPath;
										});
										for (var i = 0, len = res.results.length; i < len; ++i) idxVals[i][pkPos] = res.results[i];
										getRangeSet(idx.name).addKeys(idxVals);
									});
								}
								trans.mutatedParts = extendObservabilitySet(trans.mutatedParts || {}, mutatedParts);
								return res;
							});
						} });
						var getRange = function(_a) {
							var _b, _c;
							var _d = _a.query, index = _d.index, range = _d.range;
							return [index, new RangeSet((_b = range.lower) !== null && _b !== void 0 ? _b : core.MIN_KEY, (_c = range.upper) !== null && _c !== void 0 ? _c : core.MAX_KEY)];
						};
						var readSubscribers = {
							get: function(req) {
								return [primaryKey, new RangeSet(req.key)];
							},
							getMany: function(req) {
								return [primaryKey, new RangeSet().addKeys(req.keys)];
							},
							count: getRange,
							query: getRange,
							openCursor: getRange
						};
						keys(readSubscribers).forEach(function(method) {
							tableClone[method] = function(req) {
								var subscr = PSD.subscr;
								var isLiveQuery = !!subscr;
								var obsSet = isCachableContext(PSD, table) && isCachableRequest(method, req) ? req.obsSet = {} : subscr;
								if (isLiveQuery) {
									var getRangeSet = function(indexName) {
										var part = "idb://".concat(dbName, "/").concat(tableName, "/").concat(indexName);
										return obsSet[part] || (obsSet[part] = new RangeSet());
									};
									var pkRangeSet_1 = getRangeSet("");
									var delsRangeSet_1 = getRangeSet(":dels");
									var _a = readSubscribers[method](req), queriedIndex = _a[0], queriedRanges = _a[1];
									if (method === "query" && queriedIndex.isPrimaryKey && !req.values) delsRangeSet_1.add(queriedRanges);
									else getRangeSet(queriedIndex.name || "").add(queriedRanges);
									if (!queriedIndex.isPrimaryKey) {
										if (method === "count") delsRangeSet_1.add(FULL_RANGE);
										else {
											var keysPromise_1 = method === "query" && outbound && req.values && table.query(__assign(__assign({}, req), { values: false }));
											return table[method].apply(this, arguments).then(function(res) {
												if (method === "query") {
													if (outbound && req.values) return keysPromise_1.then(function(_a) {
														var resultingKeys = _a.result;
														pkRangeSet_1.addKeys(resultingKeys);
														return res;
													});
													var pKeys = req.values ? res.result.map(extractKey) : res.result;
													if (req.values) pkRangeSet_1.addKeys(pKeys);
													else delsRangeSet_1.addKeys(pKeys);
												} else if (method === "openCursor") {
													var cursor_1 = res;
													var wantValues_1 = req.values;
													return cursor_1 && Object.create(cursor_1, {
														key: { get: function() {
															delsRangeSet_1.addKey(cursor_1.primaryKey);
															return cursor_1.key;
														} },
														primaryKey: { get: function() {
															var pkey = cursor_1.primaryKey;
															delsRangeSet_1.addKey(pkey);
															return pkey;
														} },
														value: { get: function() {
															wantValues_1 && pkRangeSet_1.addKey(cursor_1.primaryKey);
															return cursor_1.value;
														} }
													});
												}
												return res;
											});
										}
									}
								}
								return table[method].apply(this, arguments);
							};
						});
						return tableClone;
					}
				});
			}
		};
		function trackAffectedIndexes(getRangeSet, schema, oldObjs, newObjs) {
			function addAffectedIndex(ix) {
				var rangeSet = getRangeSet(ix.name || "");
				function extractKey(obj) {
					return obj != null ? ix.extractKey(obj) : null;
				}
				var addKeyOrKeys = function(key) {
					return ix.multiEntry && isArray(key) ? key.forEach(function(key) {
						return rangeSet.addKey(key);
					}) : rangeSet.addKey(key);
				};
				(oldObjs || newObjs).forEach(function(_, i) {
					var oldKey = oldObjs && extractKey(oldObjs[i]);
					var newKey = newObjs && extractKey(newObjs[i]);
					if (cmp(oldKey, newKey) !== 0) {
						if (oldKey != null) addKeyOrKeys(oldKey);
						if (newKey != null) addKeyOrKeys(newKey);
					}
				});
			}
			schema.indexes.forEach(addAffectedIndex);
		}
		function adjustOptimisticFromFailures(tblCache, req, res) {
			if (res.numFailures === 0) return req;
			if (req.type === "deleteRange") return null;
			var numBulkOps = req.keys ? req.keys.length : "values" in req && req.values ? req.values.length : 1;
			if (res.numFailures === numBulkOps) return null;
			var clone = __assign({}, req);
			if (isArray(clone.keys)) clone.keys = clone.keys.filter(function(_, i) {
				return !(i in res.failures);
			});
			if ("values" in clone && isArray(clone.values)) clone.values = clone.values.filter(function(_, i) {
				return !(i in res.failures);
			});
			return clone;
		}
		function isAboveLower(key, range) {
			return range.lower === void 0 ? true : range.lowerOpen ? cmp(key, range.lower) > 0 : cmp(key, range.lower) >= 0;
		}
		function isBelowUpper(key, range) {
			return range.upper === void 0 ? true : range.upperOpen ? cmp(key, range.upper) < 0 : cmp(key, range.upper) <= 0;
		}
		function isWithinRange(key, range) {
			return isAboveLower(key, range) && isBelowUpper(key, range);
		}
		function applyOptimisticOps(result, req, ops, table, cacheEntry, immutable) {
			if (!ops || ops.length === 0) return result;
			var index = req.query.index;
			var multiEntry = index.multiEntry;
			var queryRange = req.query.range;
			var extractPrimKey = table.schema.primaryKey.extractKey;
			var extractIndex = index.extractKey;
			var extractLowLevelIndex = (index.lowLevelIndex || index).extractKey;
			var finalResult = ops.reduce(function(result, op) {
				var modifedResult = result;
				var includedValues = [];
				if (op.type === "add" || op.type === "put") {
					var includedPKs = new RangeSet();
					for (var i = op.values.length - 1; i >= 0; --i) {
						var value = op.values[i];
						var pk = extractPrimKey(value);
						if (includedPKs.hasKey(pk)) continue;
						var key = extractIndex(value);
						if (multiEntry && isArray(key) ? key.some(function(k) {
							return isWithinRange(k, queryRange);
						}) : isWithinRange(key, queryRange)) {
							includedPKs.addKey(pk);
							includedValues.push(value);
						}
					}
				}
				switch (op.type) {
					case "add":
						var existingKeys_1 = new RangeSet().addKeys(req.values ? result.map(function(v) {
							return extractPrimKey(v);
						}) : result);
						modifedResult = result.concat(req.values ? includedValues.filter(function(v) {
							var key = extractPrimKey(v);
							if (existingKeys_1.hasKey(key)) return false;
							existingKeys_1.addKey(key);
							return true;
						}) : includedValues.map(function(v) {
							return extractPrimKey(v);
						}).filter(function(k) {
							if (existingKeys_1.hasKey(k)) return false;
							existingKeys_1.addKey(k);
							return true;
						}));
						break;
					case "put":
						var keySet_1 = new RangeSet().addKeys(op.values.map(function(v) {
							return extractPrimKey(v);
						}));
						modifedResult = result.filter(function(item) {
							return !keySet_1.hasKey(req.values ? extractPrimKey(item) : item);
						}).concat(req.values ? includedValues : includedValues.map(function(v) {
							return extractPrimKey(v);
						}));
						break;
					case "delete":
						var keysToDelete_1 = new RangeSet().addKeys(op.keys);
						modifedResult = result.filter(function(item) {
							return !keysToDelete_1.hasKey(req.values ? extractPrimKey(item) : item);
						});
						break;
					case "deleteRange":
						var range_1 = op.range;
						modifedResult = result.filter(function(item) {
							return !isWithinRange(extractPrimKey(item), range_1);
						});
				}
				return modifedResult;
			}, result);
			if (finalResult === result) return result;
			var sorter = function(a, b) {
				return cmp(extractLowLevelIndex(a), extractLowLevelIndex(b)) || cmp(extractPrimKey(a), extractPrimKey(b));
			};
			finalResult.sort(req.direction === "prev" || req.direction === "prevunique" ? function(a, b) {
				return sorter(b, a);
			} : sorter);
			if (req.limit && req.limit < Infinity) {
				if (finalResult.length > req.limit) finalResult.length = req.limit;
				else if (result.length === req.limit && finalResult.length < req.limit) cacheEntry.dirty = true;
			}
			return immutable ? Object.freeze(finalResult) : finalResult;
		}
		function areRangesEqual(r1, r2) {
			return cmp(r1.lower, r2.lower) === 0 && cmp(r1.upper, r2.upper) === 0 && !!r1.lowerOpen === !!r2.lowerOpen && !!r1.upperOpen === !!r2.upperOpen;
		}
		function compareLowers(lower1, lower2, lowerOpen1, lowerOpen2) {
			if (lower1 === void 0) return lower2 !== void 0 ? -1 : 0;
			if (lower2 === void 0) return 1;
			var c = cmp(lower1, lower2);
			if (c === 0) {
				if (lowerOpen1 && lowerOpen2) return 0;
				if (lowerOpen1) return 1;
				if (lowerOpen2) return -1;
			}
			return c;
		}
		function compareUppers(upper1, upper2, upperOpen1, upperOpen2) {
			if (upper1 === void 0) return upper2 !== void 0 ? 1 : 0;
			if (upper2 === void 0) return -1;
			var c = cmp(upper1, upper2);
			if (c === 0) {
				if (upperOpen1 && upperOpen2) return 0;
				if (upperOpen1) return -1;
				if (upperOpen2) return 1;
			}
			return c;
		}
		function isSuperRange(r1, r2) {
			return compareLowers(r1.lower, r2.lower, r1.lowerOpen, r2.lowerOpen) <= 0 && compareUppers(r1.upper, r2.upper, r1.upperOpen, r2.upperOpen) >= 0;
		}
		function findCompatibleQuery(dbName, tableName, type, req) {
			var _a;
			var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
			if (!tblCache) return [];
			var queries = tblCache.queries[type];
			if (!queries) return [
				null,
				false,
				tblCache,
				null
			];
			var entries = queries[(req.query ? req.query.index.name : null) || ""];
			if (!entries) return [
				null,
				false,
				tblCache,
				null
			];
			switch (type) {
				case "query":
					var reqDirection_1 = (_a = req.direction) !== null && _a !== void 0 ? _a : "next";
					var equalEntry = entries.find(function(entry) {
						var _a;
						return entry.req.limit === req.limit && entry.req.values === req.values && ((_a = entry.req.direction) !== null && _a !== void 0 ? _a : "next") === reqDirection_1 && areRangesEqual(entry.req.query.range, req.query.range);
					});
					if (equalEntry) return [
						equalEntry,
						true,
						tblCache,
						entries
					];
					return [
						entries.find(function(entry) {
							var _a;
							return ("limit" in entry.req ? entry.req.limit : Infinity) >= req.limit && ((_a = entry.req.direction) !== null && _a !== void 0 ? _a : "next") === reqDirection_1 && (req.values ? entry.req.values : true) && isSuperRange(entry.req.query.range, req.query.range);
						}),
						false,
						tblCache,
						entries
					];
				case "count":
					var countQuery = entries.find(function(entry) {
						return areRangesEqual(entry.req.query.range, req.query.range);
					});
					return [
						countQuery,
						!!countQuery,
						tblCache,
						entries
					];
			}
		}
		function subscribeToCacheEntry(cacheEntry, container, requery, signal) {
			cacheEntry.subscribers.add(requery);
			signal.addEventListener("abort", function() {
				cacheEntry.subscribers.delete(requery);
				if (cacheEntry.subscribers.size === 0) enqueForDeletion(cacheEntry, container);
			});
		}
		function enqueForDeletion(cacheEntry, container) {
			setTimeout(function() {
				if (cacheEntry.subscribers.size === 0) delArrayItem(container, cacheEntry);
			}, 3e3);
		}
		var cacheMiddleware = {
			stack: "dbcore",
			level: 0,
			name: "Cache",
			create: function(core) {
				var dbName = core.schema.name;
				return __assign(__assign({}, core), {
					transaction: function(stores, mode, options) {
						var idbtrans = core.transaction(stores, mode, options);
						if (mode === "readwrite") {
							var ac_1 = new AbortController();
							var signal = ac_1.signal;
							var endTransaction = function(wasCommitted) {
								return function() {
									ac_1.abort();
									if (mode === "readwrite") {
										var affectedSubscribers_1 = /* @__PURE__ */ new Set();
										for (var _i = 0, stores_1 = stores; _i < stores_1.length; _i++) {
											var storeName = stores_1[_i];
											var tblCache = cache["idb://".concat(dbName, "/").concat(storeName)];
											if (tblCache) {
												var table = core.table(storeName);
												var ops = tblCache.optimisticOps.filter(function(op) {
													return op.trans === idbtrans;
												});
												if (idbtrans._explicit && wasCommitted && idbtrans.mutatedParts) for (var _a = 0, _b = Object.values(tblCache.queries.query); _a < _b.length; _a++) {
													var entries = _b[_a];
													for (var _c = 0, _d = entries.slice(); _c < _d.length; _c++) {
														var entry = _d[_c];
														if (obsSetsOverlap(entry.obsSet, idbtrans.mutatedParts)) {
															delArrayItem(entries, entry);
															entry.subscribers.forEach(function(requery) {
																return affectedSubscribers_1.add(requery);
															});
														}
													}
												}
												else if (ops.length > 0) {
													tblCache.optimisticOps = tblCache.optimisticOps.filter(function(op) {
														return op.trans !== idbtrans;
													});
													for (var _e = 0, _f = Object.values(tblCache.queries.query); _e < _f.length; _e++) {
														var entries = _f[_e];
														for (var _g = 0, _h = entries.slice(); _g < _h.length; _g++) {
															var entry = _h[_g];
															if (entry.res != null && idbtrans.mutatedParts) {
																if (wasCommitted && !entry.dirty) {
																	var freezeResults = Object.isFrozen(entry.res);
																	var modRes = applyOptimisticOps(entry.res, entry.req, ops, table, entry, freezeResults);
																	if (entry.dirty) {
																		delArrayItem(entries, entry);
																		entry.subscribers.forEach(function(requery) {
																			return affectedSubscribers_1.add(requery);
																		});
																	} else if (modRes !== entry.res) {
																		entry.res = modRes;
																		entry.promise = DexiePromise.resolve({ result: modRes });
																	}
																} else {
																	if (entry.dirty) delArrayItem(entries, entry);
																	entry.subscribers.forEach(function(requery) {
																		return affectedSubscribers_1.add(requery);
																	});
																}
															}
														}
													}
												}
											}
										}
										affectedSubscribers_1.forEach(function(requery) {
											return requery();
										});
									}
								};
							};
							idbtrans.addEventListener("abort", endTransaction(false), { signal });
							idbtrans.addEventListener("error", endTransaction(false), { signal });
							idbtrans.addEventListener("complete", endTransaction(true), { signal });
						}
						return idbtrans;
					},
					table: function(tableName) {
						var downTable = core.table(tableName);
						var primKey = downTable.schema.primaryKey;
						return __assign(__assign({}, downTable), {
							mutate: function(req) {
								var trans = PSD.trans;
								if (primKey.outbound || trans.db._options.cache === "disabled" || trans.explicit || trans.idbtrans.mode !== "readwrite") return downTable.mutate(req);
								var tblCache = cache["idb://".concat(dbName, "/").concat(tableName)];
								if (!tblCache) return downTable.mutate(req);
								var promise = downTable.mutate(req);
								if ((req.type === "add" || req.type === "put") && (req.values.length >= 50 || getEffectiveKeys(primKey, req).some(function(key) {
									return key == null;
								}))) promise.then(function(res) {
									var adjustedReq = adjustOptimisticFromFailures(tblCache, __assign(__assign({}, req), { values: req.values.map(function(value, i) {
										var _a;
										if (res.failures[i]) return value;
										var valueWithKey = ((_a = primKey.keyPath) === null || _a === void 0 ? void 0 : _a.includes(".")) ? deepClone(value) : __assign({}, value);
										setByKeyPath(valueWithKey, primKey.keyPath, res.results[i]);
										return valueWithKey;
									}) }), res);
									tblCache.optimisticOps.push(adjustedReq);
									queueMicrotask(function() {
										return req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
									});
								});
								else {
									tblCache.optimisticOps.push(req);
									req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
									promise.then(function(res) {
										if (res.numFailures > 0) {
											delArrayItem(tblCache.optimisticOps, req);
											var adjustedReq = adjustOptimisticFromFailures(tblCache, req, res);
											if (adjustedReq) tblCache.optimisticOps.push(adjustedReq);
											req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
										}
									});
									promise.catch(function() {
										delArrayItem(tblCache.optimisticOps, req);
										req.mutatedParts && signalSubscribersLazily(req.mutatedParts);
									});
								}
								return promise;
							},
							query: function(req) {
								var _a;
								if (!isCachableContext(PSD, downTable) || !isCachableRequest("query", req)) return downTable.query(req);
								var freezeResults = ((_a = PSD.trans) === null || _a === void 0 ? void 0 : _a.db._options.cache) === "immutable";
								var _b = PSD, requery = _b.requery, signal = _b.signal;
								var _c = findCompatibleQuery(dbName, tableName, "query", req), cacheEntry = _c[0], exactMatch = _c[1], tblCache = _c[2], container = _c[3];
								if (cacheEntry && exactMatch) cacheEntry.obsSet = req.obsSet;
								else {
									var promise = downTable.query(req).then(function(res) {
										var result = res.result;
										if (cacheEntry) cacheEntry.res = result;
										if (freezeResults) {
											for (var i = 0, l = result.length; i < l; ++i) Object.freeze(result[i]);
											Object.freeze(result);
										}
										return res;
									}).catch(function(error) {
										if (container && cacheEntry) delArrayItem(container, cacheEntry);
										return Promise.reject(error);
									});
									cacheEntry = {
										obsSet: req.obsSet,
										promise,
										subscribers: /* @__PURE__ */ new Set(),
										type: "query",
										req,
										dirty: false
									};
									if (container) container.push(cacheEntry);
									else {
										container = [cacheEntry];
										if (!tblCache) tblCache = cache["idb://".concat(dbName, "/").concat(tableName)] = {
											queries: {
												query: {},
												count: {}
											},
											objs: /* @__PURE__ */ new Map(),
											optimisticOps: [],
											unsignaledParts: {}
										};
										tblCache.queries.query[req.query.index.name || ""] = container;
									}
								}
								subscribeToCacheEntry(cacheEntry, container, requery, signal);
								return cacheEntry.promise.then(function(res) {
									var result = applyOptimisticOps(res.result, req, tblCache === null || tblCache === void 0 ? void 0 : tblCache.optimisticOps, downTable, cacheEntry, freezeResults);
									return { result: freezeResults ? result : deepClone(result) };
								});
							}
						});
					}
				});
			}
		};
		function vipify(target, vipDb) {
			return new Proxy(target, { get: function(target, prop, receiver) {
				if (prop === "db") return vipDb;
				return Reflect.get(target, prop, receiver);
			} });
		}
		var Dexie$1 = function() {
			function Dexie(name, options) {
				var _this = this;
				this._middlewares = {};
				this.verno = 0;
				var deps = Dexie.dependencies;
				this._options = options = __assign({
					addons: Dexie.addons,
					autoOpen: true,
					indexedDB: deps.indexedDB,
					IDBKeyRange: deps.IDBKeyRange,
					cache: "cloned",
					maxConnections: DEFAULT_MAX_CONNECTIONS
				}, options);
				this._deps = {
					indexedDB: options.indexedDB,
					IDBKeyRange: options.IDBKeyRange
				};
				var addons = options.addons;
				this._dbSchema = {};
				this._versions = [];
				this._storeNames = [];
				this._allTables = {};
				this.idbdb = null;
				this._novip = this;
				var state = {
					dbOpenError: null,
					isBeingOpened: false,
					onReadyBeingFired: null,
					openComplete: false,
					dbReadyResolve: nop,
					dbReadyPromise: null,
					cancelOpen: nop,
					openCanceller: null,
					autoSchema: true,
					PR1398_maxLoop: 3,
					autoOpen: options.autoOpen
				};
				state.dbReadyPromise = new DexiePromise(function(resolve) {
					state.dbReadyResolve = resolve;
				});
				state.openCanceller = new DexiePromise(function(_, reject) {
					state.cancelOpen = reject;
				});
				this._state = state;
				this.name = name;
				this.on = Events(this, "populate", "blocked", "versionchange", "close", { ready: [promisableChain, nop] });
				this.once = function(event, callback) {
					var fn = function() {
						var args = [];
						for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
						_this.on(event).unsubscribe(fn);
						callback.apply(_this, args);
					};
					return _this.on(event, fn);
				};
				this.on.ready.subscribe = override(this.on.ready.subscribe, function(subscribe) {
					return function(subscriber, bSticky) {
						Dexie.vip(function() {
							var state = _this._state;
							if (state.openComplete) {
								if (!state.dbOpenError) DexiePromise.resolve().then(subscriber);
								if (bSticky) subscribe(subscriber);
							} else if (state.onReadyBeingFired) {
								state.onReadyBeingFired.push(subscriber);
								if (bSticky) subscribe(subscriber);
							} else {
								subscribe(subscriber);
								var db_1 = _this;
								if (!bSticky) subscribe(function unsubscribe() {
									db_1.on.ready.unsubscribe(subscriber);
									db_1.on.ready.unsubscribe(unsubscribe);
								});
							}
						});
					};
				});
				this.Collection = createCollectionConstructor(this);
				this.Table = createTableConstructor(this);
				this.Transaction = createTransactionConstructor(this);
				this.Version = createVersionConstructor(this);
				this.WhereClause = createWhereClauseConstructor(this);
				this.on("versionchange", function(ev) {
					if (ev.newVersion > 0) console.warn("Another connection wants to upgrade database '".concat(_this.name, "'. Closing db now to resume the upgrade."));
					else console.warn("Another connection wants to delete database '".concat(_this.name, "'. Closing db now to resume the delete request."));
					_this.close({ disableAutoOpen: false });
				});
				this.on("blocked", function(ev) {
					if (!ev.newVersion || ev.newVersion < ev.oldVersion) console.warn("Dexie.delete('".concat(_this.name, "') was blocked"));
					else console.warn("Upgrade '".concat(_this.name, "' blocked by other connection holding version ").concat(ev.oldVersion / 10));
				});
				this._maxKey = getMaxKey(options.IDBKeyRange);
				this._createTransaction = function(mode, storeNames, dbschema, parentTransaction) {
					return new _this.Transaction(mode, storeNames, dbschema, _this._options.chromeTransactionDurability, parentTransaction);
				};
				this._fireOnBlocked = function(ev) {
					_this.on("blocked").fire(ev);
					connections.toArray().filter(function(c) {
						return c.name === _this.name && c !== _this && !c._state.vcFired;
					}).map(function(c) {
						return c.on("versionchange").fire(ev);
					});
				};
				this.use(cacheExistingValuesMiddleware);
				this.use(cacheMiddleware);
				this.use(observabilityMiddleware);
				this.use(virtualIndexMiddleware);
				this.use(hooksMiddleware);
				var vipDB = new Proxy(this, { get: function(_, prop, receiver) {
					if (prop === "_vip") return true;
					if (prop === "table") return function(tableName) {
						return vipify(_this.table(tableName), vipDB);
					};
					var rv = Reflect.get(_, prop, receiver);
					if (rv instanceof Table) return vipify(rv, vipDB);
					if (prop === "tables") return rv.map(function(t) {
						return vipify(t, vipDB);
					});
					if (prop === "_createTransaction") return function() {
						return vipify(rv.apply(this, arguments), vipDB);
					};
					return rv;
				} });
				this.vip = vipDB;
				addons.forEach(function(addon) {
					return addon(_this);
				});
			}
			Dexie.prototype.version = function(versionNumber) {
				if (isNaN(versionNumber) || versionNumber < .1) throw new exceptions.Type("Given version is not a positive number");
				versionNumber = Math.round(versionNumber * 10) / 10;
				if (this.idbdb || this._state.isBeingOpened) throw new exceptions.Schema("Cannot add version when database is open");
				this.verno = Math.max(this.verno, versionNumber);
				var versions = this._versions;
				var versionInstance = versions.filter(function(v) {
					return v._cfg.version === versionNumber;
				})[0];
				if (versionInstance) return versionInstance;
				versionInstance = new this.Version(versionNumber);
				versions.push(versionInstance);
				versions.sort(lowerVersionFirst);
				versionInstance.stores({});
				this._state.autoSchema = false;
				return versionInstance;
			};
			Dexie.prototype._whenReady = function(fn) {
				var _this = this;
				return this.idbdb && (this._state.openComplete || PSD.letThrough || this._vip) ? fn() : new DexiePromise(function(resolve, reject) {
					if (_this._state.openComplete) return reject(new exceptions.DatabaseClosed(_this._state.dbOpenError));
					if (!_this._state.isBeingOpened) {
						if (!_this._state.autoOpen) {
							reject(new exceptions.DatabaseClosed());
							return;
						}
						_this.open().catch(nop);
					}
					_this._state.dbReadyPromise.then(resolve, reject);
				}).then(fn);
			};
			Dexie.prototype.use = function(_a) {
				var stack = _a.stack, create = _a.create, level = _a.level, name = _a.name;
				if (name) this.unuse({
					stack,
					name
				});
				var middlewares = this._middlewares[stack] || (this._middlewares[stack] = []);
				middlewares.push({
					stack,
					create,
					level: level == null ? 10 : level,
					name
				});
				middlewares.sort(function(a, b) {
					return a.level - b.level;
				});
				return this;
			};
			Dexie.prototype.unuse = function(_a) {
				var stack = _a.stack, name = _a.name, create = _a.create;
				if (stack && this._middlewares[stack]) this._middlewares[stack] = this._middlewares[stack].filter(function(mw) {
					return create ? mw.create !== create : name ? mw.name !== name : false;
				});
				return this;
			};
			Dexie.prototype.open = function() {
				var _this = this;
				return usePSD(globalPSD, function() {
					return dexieOpen(_this);
				});
			};
			Dexie.prototype._close = function() {
				this.on.close.fire(new CustomEvent("close"));
				var state = this._state;
				connections.remove(this);
				if (this.idbdb) {
					try {
						this.idbdb.close();
					} catch (e) {}
					this.idbdb = null;
				}
				if (!state.isBeingOpened) {
					state.dbReadyPromise = new DexiePromise(function(resolve) {
						state.dbReadyResolve = resolve;
					});
					state.openCanceller = new DexiePromise(function(_, reject) {
						state.cancelOpen = reject;
					});
				}
			};
			Dexie.prototype.close = function(_a) {
				var disableAutoOpen = (_a === void 0 ? { disableAutoOpen: true } : _a).disableAutoOpen;
				var state = this._state;
				if (disableAutoOpen) {
					if (state.isBeingOpened) state.cancelOpen(new exceptions.DatabaseClosed());
					this._close();
					state.autoOpen = false;
					state.dbOpenError = new exceptions.DatabaseClosed();
				} else {
					this._close();
					state.autoOpen = this._options.autoOpen || state.isBeingOpened;
					state.openComplete = false;
					state.dbOpenError = null;
				}
			};
			Dexie.prototype.delete = function(closeOptions) {
				var _this = this;
				if (closeOptions === void 0) closeOptions = { disableAutoOpen: true };
				var hasInvalidArguments = arguments.length > 0 && typeof arguments[0] !== "object";
				var state = this._state;
				return new DexiePromise(function(resolve, reject) {
					var doDelete = function() {
						_this.close(closeOptions);
						var req = _this._deps.indexedDB.deleteDatabase(_this.name);
						req.onsuccess = wrap(function() {
							_onDatabaseDeleted(_this._deps, _this.name);
							resolve();
						});
						req.onerror = eventRejectHandler(reject);
						req.onblocked = _this._fireOnBlocked;
					};
					if (hasInvalidArguments) throw new exceptions.InvalidArgument("Invalid closeOptions argument to db.delete()");
					if (state.isBeingOpened) state.dbReadyPromise.then(doDelete);
					else doDelete();
				});
			};
			Dexie.prototype.backendDB = function() {
				return this.idbdb;
			};
			Dexie.prototype.isOpen = function() {
				return this.idbdb !== null;
			};
			Dexie.prototype.hasBeenClosed = function() {
				var dbOpenError = this._state.dbOpenError;
				return dbOpenError && dbOpenError.name === "DatabaseClosed";
			};
			Dexie.prototype.hasFailed = function() {
				return this._state.dbOpenError !== null;
			};
			Dexie.prototype.dynamicallyOpened = function() {
				return this._state.autoSchema;
			};
			Object.defineProperty(Dexie.prototype, "tables", {
				get: function() {
					var _this = this;
					return keys(this._allTables).map(function(name) {
						return _this._allTables[name];
					});
				},
				enumerable: false,
				configurable: true
			});
			Dexie.prototype.transaction = function() {
				var args = extractTransactionArgs.apply(this, arguments);
				return this._transaction.apply(this, args);
			};
			Dexie.prototype._transaction = function(mode, tables, scopeFunc) {
				var _this = this;
				var parentTransaction = PSD.trans;
				if (!parentTransaction || parentTransaction.db !== this || mode.indexOf("!") !== -1) parentTransaction = null;
				var onlyIfCompatible = mode.indexOf("?") !== -1;
				mode = mode.replace("!", "").replace("?", "");
				var idbMode, storeNames;
				try {
					storeNames = tables.map(function(table) {
						var storeName = table instanceof _this.Table ? table.name : table;
						if (typeof storeName !== "string") throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
						return storeName;
					});
					if (mode == "r" || mode === READONLY) idbMode = READONLY;
					else if (mode == "rw" || mode == READWRITE) idbMode = READWRITE;
					else throw new exceptions.InvalidArgument("Invalid transaction mode: " + mode);
					if (parentTransaction) {
						if (parentTransaction.mode === READONLY && idbMode === READWRITE) {
							if (onlyIfCompatible) parentTransaction = null;
							else throw new exceptions.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
						}
						if (parentTransaction) storeNames.forEach(function(storeName) {
							if (parentTransaction && parentTransaction.storeNames.indexOf(storeName) === -1) {
								if (onlyIfCompatible) parentTransaction = null;
								else throw new exceptions.SubTransaction("Table " + storeName + " not included in parent transaction.");
							}
						});
						if (onlyIfCompatible && parentTransaction && !parentTransaction.active) parentTransaction = null;
					}
				} catch (e) {
					return parentTransaction ? parentTransaction._promise(null, function(_, reject) {
						reject(e);
					}) : rejection(e);
				}
				var enterTransaction = enterTransactionScope.bind(null, this, idbMode, storeNames, parentTransaction, scopeFunc);
				return parentTransaction ? parentTransaction._promise(idbMode, enterTransaction, "lock") : PSD.trans ? usePSD(PSD.transless, function() {
					return _this._whenReady(enterTransaction);
				}) : this._whenReady(enterTransaction);
			};
			Dexie.prototype.table = function(tableName) {
				if (!hasOwn(this._allTables, tableName)) throw new exceptions.InvalidTable("Table ".concat(tableName, " does not exist"));
				return this._allTables[tableName];
			};
			return Dexie;
		}();
		var symbolObservable = typeof Symbol !== "undefined" && "observable" in Symbol ? Symbol.observable : "@@observable";
		var Observable = function() {
			function Observable(subscribe) {
				this._subscribe = subscribe;
			}
			Observable.prototype.subscribe = function(x, error, complete) {
				return this._subscribe(!x || typeof x === "function" ? {
					next: x,
					error,
					complete
				} : x);
			};
			Observable.prototype[symbolObservable] = function() {
				return this;
			};
			return Observable;
		}();
		var domDeps;
		try {
			domDeps = {
				indexedDB: _global.indexedDB || _global.mozIndexedDB || _global.webkitIndexedDB || _global.msIndexedDB,
				IDBKeyRange: _global.IDBKeyRange || _global.webkitIDBKeyRange
			};
		} catch (e) {
			domDeps = {
				indexedDB: null,
				IDBKeyRange: null
			};
		}
		function liveQuery(querier) {
			var hasValue = false;
			var currentValue;
			var observable = new Observable(function(observer) {
				var scopeFuncIsAsync = isAsyncFunction(querier);
				function execute(ctx) {
					var wasRootExec = beginMicroTickScope();
					try {
						if (scopeFuncIsAsync) incrementExpectedAwaits();
						var rv = newScope(querier, ctx);
						if (scopeFuncIsAsync) rv = rv.finally(decrementExpectedAwaits);
						return rv;
					} finally {
						wasRootExec && endMicroTickScope();
					}
				}
				var closed = false;
				var abortController;
				var accumMuts = {};
				var currentObs = {};
				var subscription = {
					get closed() {
						return closed;
					},
					unsubscribe: function() {
						if (closed) return;
						closed = true;
						if (abortController) abortController.abort();
						if (startedListening) globalEvents.storagemutated.unsubscribe(mutationListener);
					}
				};
				observer.start && observer.start(subscription);
				var startedListening = false;
				var doQuery = function() {
					return execInGlobalContext(_doQuery);
				};
				function shouldNotify() {
					return obsSetsOverlap(currentObs, accumMuts);
				}
				var mutationListener = function(parts) {
					extendObservabilitySet(accumMuts, parts);
					if (shouldNotify()) doQuery();
				};
				var _doQuery = function() {
					if (closed || !domDeps.indexedDB) return;
					accumMuts = {};
					var subscr = {};
					if (abortController) abortController.abort();
					abortController = new AbortController();
					var ctx = {
						subscr,
						signal: abortController.signal,
						requery: doQuery,
						querier,
						trans: null
					};
					var ret = execute(ctx);
					if (!startedListening) {
						globalEvents.storagemutated.subscribe(mutationListener);
						startedListening = true;
					}
					Promise.resolve(ret).then(function(result) {
						hasValue = true;
						currentValue = result;
						if (closed || ctx.signal.aborted) return;
						if (shouldNotify()) doQuery();
						else {
							currentObs = subscr;
							if (shouldNotify()) doQuery();
							else {
								accumMuts = {};
								execInGlobalContext(function() {
									return !closed && observer.next && observer.next(result);
								});
							}
						}
					}, function(err) {
						hasValue = false;
						if (!["DatabaseClosedError", "AbortError"].includes(err === null || err === void 0 ? void 0 : err.name)) {
							if (!closed) execInGlobalContext(function() {
								if (closed) return;
								observer.error && observer.error(err);
							});
						}
					});
				};
				setTimeout(doQuery, 0);
				return subscription;
			});
			observable.hasValue = function() {
				return hasValue;
			};
			observable.getValue = function() {
				return currentValue;
			};
			return observable;
		}
		var Dexie = Dexie$1;
		props(Dexie, __assign(__assign({}, fullNameExceptions), {
			delete: function(databaseName) {
				return new Dexie(databaseName, { addons: [] }).delete();
			},
			exists: function(name) {
				return new Dexie(name, { addons: [] }).open().then(function(db) {
					db.close();
					return true;
				}).catch("NoSuchDatabaseError", function() {
					return false;
				});
			},
			getDatabaseNames: function(cb) {
				try {
					return getDatabaseNames(Dexie.dependencies).then(cb);
				} catch (_a) {
					return rejection(new exceptions.MissingAPI());
				}
			},
			defineClass: function() {
				function Class(content) {
					extend(this, content);
				}
				return Class;
			},
			ignoreTransaction: function(scopeFunc) {
				return PSD.trans ? usePSD(PSD.transless || globalPSD, scopeFunc) : scopeFunc();
			},
			vip,
			async: function(generatorFn) {
				return function() {
					try {
						var rv = awaitIterator(generatorFn.apply(this, arguments));
						if (!rv || typeof rv.then !== "function") return DexiePromise.resolve(rv);
						return rv;
					} catch (e) {
						return rejection(e);
					}
				};
			},
			spawn: function(generatorFn, args, thiz) {
				try {
					var rv = awaitIterator(generatorFn.apply(thiz, args || []));
					if (!rv || typeof rv.then !== "function") return DexiePromise.resolve(rv);
					return rv;
				} catch (e) {
					return rejection(e);
				}
			},
			currentTransaction: { get: function() {
				return PSD.trans || null;
			} },
			waitFor: function(promiseOrFunction, optionalTimeout) {
				var promise = DexiePromise.resolve(typeof promiseOrFunction === "function" ? Dexie.ignoreTransaction(promiseOrFunction) : promiseOrFunction).timeout(optionalTimeout || 6e4);
				return PSD.trans ? PSD.trans.waitFor(promise) : promise;
			},
			Promise: DexiePromise,
			debug: {
				get: function() {
					return debug;
				},
				set: function(value) {
					setDebug(value);
				}
			},
			derive,
			extend,
			props,
			override,
			Events,
			on: globalEvents,
			liveQuery,
			extendObservabilitySet,
			getByKeyPath,
			setByKeyPath,
			delByKeyPath,
			shallowClone,
			deepClone,
			getObjectDiff,
			cmp,
			asap: asap$1,
			minKey,
			addons: [],
			connections: { get: connections.toArray },
			errnames,
			dependencies: domDeps,
			cache,
			semVer: DEXIE_VERSION,
			version: DEXIE_VERSION.split(".").map(function(n) {
				return parseInt(n);
			}).reduce(function(p, c, i) {
				return p + c / Math.pow(10, i * 2);
			})
		}));
		Dexie.maxKey = getMaxKey(Dexie.dependencies.IDBKeyRange);
		if (typeof dispatchEvent !== "undefined" && typeof addEventListener !== "undefined") {
			globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME, function(updatedParts) {
				if (!propagatingLocally) {
					var event_1 = new CustomEvent(STORAGE_MUTATED_DOM_EVENT_NAME, { detail: updatedParts });
					propagatingLocally = true;
					dispatchEvent(event_1);
					propagatingLocally = false;
				}
			});
			addEventListener(STORAGE_MUTATED_DOM_EVENT_NAME, function(_a) {
				var detail = _a.detail;
				if (!propagatingLocally) propagateLocally(detail);
			});
		}
		function propagateLocally(updateParts) {
			var wasMe = propagatingLocally;
			try {
				propagatingLocally = true;
				globalEvents.storagemutated.fire(updateParts);
				signalSubscribersNow(updateParts, true);
			} finally {
				propagatingLocally = wasMe;
			}
		}
		var propagatingLocally = false;
		var bc;
		var createBC = function() {};
		if (typeof BroadcastChannel !== "undefined") {
			createBC = function() {
				bc = new BroadcastChannel(STORAGE_MUTATED_DOM_EVENT_NAME);
				bc.onmessage = function(ev) {
					return ev.data && propagateLocally(ev.data);
				};
			};
			createBC();
			if (typeof bc.unref === "function") bc.unref();
			globalEvents(DEXIE_STORAGE_MUTATED_EVENT_NAME, function(changedParts) {
				if (!propagatingLocally) bc.postMessage(changedParts);
			});
		}
		if (typeof addEventListener !== "undefined") {
			addEventListener("pagehide", function(event) {
				if (!Dexie$1.disableBfCache && event.persisted) {
					if (debug) console.debug("Dexie: handling persisted pagehide");
					bc === null || bc === void 0 || bc.close();
					for (var _i = 0, _a = connections.toArray(); _i < _a.length; _i++) _a[_i].close({ disableAutoOpen: false });
				}
			});
			addEventListener("pageshow", function(event) {
				if (!Dexie$1.disableBfCache && event.persisted) {
					if (debug) console.debug("Dexie: handling persisted pageshow");
					createBC();
					propagateLocally({ all: new RangeSet(-Infinity, [[]]) });
				}
			});
		}
		function add(value) {
			return new PropModification({ add: value });
		}
		function remove(value) {
			return new PropModification({ remove: value });
		}
		function replacePrefix(a, b) {
			return new PropModification({ replacePrefix: [a, b] });
		}
		DexiePromise.rejectionMapper = mapError;
		setDebug(debug);
		__assign(Dexie$1, /* @__PURE__ */ Object.freeze({
			__proto__: null,
			DEFAULT_MAX_CONNECTIONS,
			Dexie: Dexie$1,
			Entity,
			PropModification,
			RangeSet,
			add,
			cmp,
			default: Dexie$1,
			liveQuery,
			mergeRanges,
			rangesOverlap,
			remove,
			replacePrefix
		}), { default: Dexie$1 });
		return Dexie$1;
	}));
})))(), 1);
var DexieSymbol = Symbol.for("Dexie");
var Dexie = globalThis[DexieSymbol] || (globalThis[DexieSymbol] = import_dexie.default);
if (import_dexie.default.semVer !== Dexie.semVer) throw new Error(`Two different versions of Dexie loaded in the same app: ${import_dexie.default.semVer} and ${Dexie.semVer}`);
var { liveQuery, mergeRanges, rangesOverlap, RangeSet, cmp, Entity, PropModification, replacePrefix, add, remove, DexieYProvider } = Dexie;
//#endregion
export { Dexie, Dexie as default, DexieYProvider, Entity, PropModification, RangeSet, add, cmp, liveQuery, mergeRanges, rangesOverlap, remove, replacePrefix };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGV4aWUuanMiLCJuYW1lcyI6WyJfRGV4aWUiXSwic291cmNlcyI6WyIuLi8uLi9kZXhpZS9kaXN0L2RleGllLmpzIiwiLi4vLi4vZGV4aWUvaW1wb3J0LXdyYXBwZXIubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBEZXhpZS5qcyAtIGEgbWluaW1hbGlzdGljIHdyYXBwZXIgZm9yIEluZGV4ZWREQlxuICogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAqXG4gKiBCeSBEYXZpZCBGYWhsYW5kZXIsIGRhdmlkLmZhaGxhbmRlckBnbWFpbC5jb21cbiAqXG4gKiBWZXJzaW9uIDQuNC41LCBGcmkgQXVnIDE0IDIwMjZcbiAqXG4gKiBodHRwczovL2RleGllLm9yZ1xuICpcbiAqIEFwYWNoZSBMaWNlbnNlIFZlcnNpb24gMi4wLCBKYW51YXJ5IDIwMDQsIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9cbiAqL1xuIFxuKGZ1bmN0aW9uIChnbG9iYWwsIGZhY3RvcnkpIHtcbiAgdHlwZW9mIGV4cG9ydHMgPT09ICdvYmplY3QnICYmIHR5cGVvZiBtb2R1bGUgIT09ICd1bmRlZmluZWQnID8gbW9kdWxlLmV4cG9ydHMgPSBmYWN0b3J5KCkgOlxuICB0eXBlb2YgZGVmaW5lID09PSAnZnVuY3Rpb24nICYmIGRlZmluZS5hbWQgPyBkZWZpbmUoZmFjdG9yeSkgOlxuICAoZ2xvYmFsID0gdHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnID8gZ2xvYmFsVGhpcyA6IGdsb2JhbCB8fCBzZWxmLCBnbG9iYWwuRGV4aWUgPSBmYWN0b3J5KCkpO1xufSkodGhpcywgKGZ1bmN0aW9uICgpIHsgJ3VzZSBzdHJpY3QnO1xuXG4gIHZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24oZCwgYikge1xuICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcbiAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxuICAgICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xuICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xuICB9O1xuICBmdW5jdGlvbiBfX2V4dGVuZHMoZCwgYikge1xuICAgIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcbiAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xuICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxuICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcbiAgfVxuICB2YXIgX19hc3NpZ24gPSBmdW5jdGlvbigpIHtcbiAgICBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gX19hc3NpZ24odCkge1xuICAgICAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XG4gICAgICAgICAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkpIHRbcF0gPSBzW3BdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0O1xuICAgIH07XG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gIH07XG4gIGZ1bmN0aW9uIF9fc3ByZWFkQXJyYXkodG8sIGZyb20sIHBhY2spIHtcbiAgICBpZiAocGFjayB8fCBhcmd1bWVudHMubGVuZ3RoID09PSAyKSBmb3IgKHZhciBpID0gMCwgbCA9IGZyb20ubGVuZ3RoLCBhcjsgaSA8IGw7IGkrKykge1xuICAgICAgICBpZiAoYXIgfHwgIShpIGluIGZyb20pKSB7XG4gICAgICAgICAgICBpZiAoIWFyKSBhciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20sIDAsIGkpO1xuICAgICAgICAgICAgYXJbaV0gPSBmcm9tW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0by5jb25jYXQoYXIgfHwgQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoZnJvbSkpO1xuICB9XG4gIHR5cGVvZiBTdXBwcmVzc2VkRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IFN1cHByZXNzZWRFcnJvciA6IGZ1bmN0aW9uIChlcnJvciwgc3VwcHJlc3NlZCwgbWVzc2FnZSkge1xuICAgIHZhciBlID0gbmV3IEVycm9yKG1lc3NhZ2UpO1xuICAgIHJldHVybiBlLm5hbWUgPSBcIlN1cHByZXNzZWRFcnJvclwiLCBlLmVycm9yID0gZXJyb3IsIGUuc3VwcHJlc3NlZCA9IHN1cHByZXNzZWQsIGU7XG4gIH07XG5cbiAgdmFyIF9nbG9iYWwgPSB0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgID8gZ2xvYmFsVGhpc1xuICAgICAgOiB0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgICAgICA/IHNlbGZcbiAgICAgICAgICA6IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnXG4gICAgICAgICAgICAgID8gd2luZG93XG4gICAgICAgICAgICAgIDogZ2xvYmFsO1xuXG4gIHZhciBrZXlzID0gT2JqZWN0LmtleXM7XG4gIHZhciBpc0FycmF5ID0gQXJyYXkuaXNBcnJheTtcbiAgaWYgKHR5cGVvZiBQcm9taXNlICE9PSAndW5kZWZpbmVkJyAmJiAhX2dsb2JhbC5Qcm9taXNlKSB7XG4gICAgICBfZ2xvYmFsLlByb21pc2UgPSBQcm9taXNlO1xuICB9XG4gIGZ1bmN0aW9uIGV4dGVuZChvYmosIGV4dGVuc2lvbikge1xuICAgICAgaWYgKHR5cGVvZiBleHRlbnNpb24gIT09ICdvYmplY3QnKVxuICAgICAgICAgIHJldHVybiBvYmo7XG4gICAgICBrZXlzKGV4dGVuc2lvbikuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG4gICAgICAgICAgb2JqW2tleV0gPSBleHRlbnNpb25ba2V5XTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIG9iajtcbiAgfVxuICB2YXIgZ2V0UHJvdG8gPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG4gIHZhciBfaGFzT3duID0ge30uaGFzT3duUHJvcGVydHk7XG4gIGZ1bmN0aW9uIGhhc093bihvYmosIHByb3ApIHtcbiAgICAgIHJldHVybiBfaGFzT3duLmNhbGwob2JqLCBwcm9wKTtcbiAgfVxuICBmdW5jdGlvbiBwcm9wcyhwcm90bywgZXh0ZW5zaW9uKSB7XG4gICAgICBpZiAodHlwZW9mIGV4dGVuc2lvbiA9PT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgICBleHRlbnNpb24gPSBleHRlbnNpb24oZ2V0UHJvdG8ocHJvdG8pKTtcbiAgICAgICh0eXBlb2YgUmVmbGVjdCA9PT0gJ3VuZGVmaW5lZCcgPyBrZXlzIDogUmVmbGVjdC5vd25LZXlzKShleHRlbnNpb24pLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgICAgICAgIHNldFByb3AocHJvdG8sIGtleSwgZXh0ZW5zaW9uW2tleV0pO1xuICAgICAgfSk7XG4gIH1cbiAgdmFyIGRlZmluZVByb3BlcnR5ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xuICBmdW5jdGlvbiBzZXRQcm9wKG9iaiwgcHJvcCwgZnVuY3Rpb25PckdldFNldCwgb3B0aW9ucykge1xuICAgICAgZGVmaW5lUHJvcGVydHkob2JqLCBwcm9wLCBleHRlbmQoZnVuY3Rpb25PckdldFNldCAmJlxuICAgICAgICAgIGhhc093bihmdW5jdGlvbk9yR2V0U2V0LCAnZ2V0JykgJiZcbiAgICAgICAgICB0eXBlb2YgZnVuY3Rpb25PckdldFNldC5nZXQgPT09ICdmdW5jdGlvbidcbiAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbk9yR2V0U2V0LmdldCxcbiAgICAgICAgICAgICAgc2V0OiBmdW5jdGlvbk9yR2V0U2V0LnNldCxcbiAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgIH1cbiAgICAgICAgICA6IHsgdmFsdWU6IGZ1bmN0aW9uT3JHZXRTZXQsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSwgb3B0aW9ucykpO1xuICB9XG4gIGZ1bmN0aW9uIGRlcml2ZShDaGlsZCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBmcm9tOiBmdW5jdGlvbiAoUGFyZW50KSB7XG4gICAgICAgICAgICAgIENoaWxkLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoUGFyZW50LnByb3RvdHlwZSk7XG4gICAgICAgICAgICAgIHNldFByb3AoQ2hpbGQucHJvdG90eXBlLCAnY29uc3RydWN0b3InLCBDaGlsZCk7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICBleHRlbmQ6IHByb3BzLmJpbmQobnVsbCwgQ2hpbGQucHJvdG90eXBlKSxcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICB9LFxuICAgICAgfTtcbiAgfVxuICB2YXIgZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcbiAgZnVuY3Rpb24gZ2V0UHJvcGVydHlEZXNjcmlwdG9yKG9iaiwgcHJvcCkge1xuICAgICAgdmFyIHBkID0gZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iaiwgcHJvcCk7XG4gICAgICB2YXIgcHJvdG87XG4gICAgICByZXR1cm4gcGQgfHwgKChwcm90byA9IGdldFByb3RvKG9iaikpICYmIGdldFByb3BlcnR5RGVzY3JpcHRvcihwcm90bywgcHJvcCkpO1xuICB9XG4gIHZhciBfc2xpY2UgPSBbXS5zbGljZTtcbiAgZnVuY3Rpb24gc2xpY2UoYXJncywgc3RhcnQsIGVuZCkge1xuICAgICAgcmV0dXJuIF9zbGljZS5jYWxsKGFyZ3MsIHN0YXJ0LCBlbmQpO1xuICB9XG4gIGZ1bmN0aW9uIG92ZXJyaWRlKG9yaWdGdW5jLCBvdmVycmlkZWRGYWN0b3J5KSB7XG4gICAgICByZXR1cm4gb3ZlcnJpZGVkRmFjdG9yeShvcmlnRnVuYyk7XG4gIH1cbiAgZnVuY3Rpb24gYXNzZXJ0KGIpIHtcbiAgICAgIGlmICghYilcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Fzc2VydGlvbiBGYWlsZWQnKTtcbiAgfVxuICBmdW5jdGlvbiBhc2FwJDEoZm4pIHtcbiAgICAgIGlmIChfZ2xvYmFsLnNldEltbWVkaWF0ZSlcbiAgICAgICAgICBzZXRJbW1lZGlhdGUoZm4pO1xuICAgICAgZWxzZVxuICAgICAgICAgIHNldFRpbWVvdXQoZm4sIDApO1xuICB9XG4gIGZ1bmN0aW9uIGFycmF5VG9PYmplY3QoYXJyYXksIGV4dHJhY3Rvcikge1xuICAgICAgcmV0dXJuIGFycmF5LnJlZHVjZShmdW5jdGlvbiAocmVzdWx0LCBpdGVtLCBpKSB7XG4gICAgICAgICAgdmFyIG5hbWVBbmRWYWx1ZSA9IGV4dHJhY3RvcihpdGVtLCBpKTtcbiAgICAgICAgICBpZiAobmFtZUFuZFZhbHVlKVxuICAgICAgICAgICAgICByZXN1bHRbbmFtZUFuZFZhbHVlWzBdXSA9IG5hbWVBbmRWYWx1ZVsxXTtcbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSwge30pO1xuICB9XG4gIGZ1bmN0aW9uIGdldEJ5S2V5UGF0aChvYmosIGtleVBhdGgpIHtcbiAgICAgIGlmICh0eXBlb2Yga2V5UGF0aCA9PT0gJ3N0cmluZycgJiYgaGFzT3duKG9iaiwga2V5UGF0aCkpXG4gICAgICAgICAgcmV0dXJuIG9ialtrZXlQYXRoXTtcbiAgICAgIGlmICgha2V5UGF0aClcbiAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgaWYgKHR5cGVvZiBrZXlQYXRoICE9PSAnc3RyaW5nJykge1xuICAgICAgICAgIHZhciBydiA9IFtdO1xuICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsID0ga2V5UGF0aC5sZW5ndGg7IGkgPCBsOyArK2kpIHtcbiAgICAgICAgICAgICAgdmFyIHZhbCA9IGdldEJ5S2V5UGF0aChvYmosIGtleVBhdGhbaV0pO1xuICAgICAgICAgICAgICBydi5wdXNoKHZhbCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBydjtcbiAgICAgIH1cbiAgICAgIHZhciBwZXJpb2QgPSBrZXlQYXRoLmluZGV4T2YoJy4nKTtcbiAgICAgIGlmIChwZXJpb2QgIT09IC0xKSB7XG4gICAgICAgICAgdmFyIGlubmVyT2JqID0gb2JqW2tleVBhdGguc3Vic3RyKDAsIHBlcmlvZCldO1xuICAgICAgICAgIHJldHVybiBpbm5lck9iaiA9PSBudWxsXG4gICAgICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgICAgIDogZ2V0QnlLZXlQYXRoKGlubmVyT2JqLCBrZXlQYXRoLnN1YnN0cihwZXJpb2QgKyAxKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIGZ1bmN0aW9uIHNldEJ5S2V5UGF0aChvYmosIGtleVBhdGgsIHZhbHVlKSB7XG4gICAgICBpZiAoIW9iaiB8fCBrZXlQYXRoID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgaWYgKCdpc0Zyb3plbicgaW4gT2JqZWN0ICYmIE9iamVjdC5pc0Zyb3plbihvYmopKVxuICAgICAgICAgIHJldHVybjtcbiAgICAgIGlmICh0eXBlb2Yga2V5UGF0aCAhPT0gJ3N0cmluZycgJiYgJ2xlbmd0aCcgaW4ga2V5UGF0aCkge1xuICAgICAgICAgIGFzc2VydCh0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnICYmICdsZW5ndGgnIGluIHZhbHVlKTtcbiAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbCA9IGtleVBhdGgubGVuZ3RoOyBpIDwgbDsgKytpKSB7XG4gICAgICAgICAgICAgIHNldEJ5S2V5UGF0aChvYmosIGtleVBhdGhbaV0sIHZhbHVlW2ldKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgICB2YXIgcGVyaW9kID0ga2V5UGF0aC5pbmRleE9mKCcuJyk7XG4gICAgICAgICAgaWYgKHBlcmlvZCAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgdmFyIGN1cnJlbnRLZXlQYXRoID0ga2V5UGF0aC5zdWJzdHIoMCwgcGVyaW9kKTtcbiAgICAgICAgICAgICAgdmFyIHJlbWFpbmluZ0tleVBhdGggPSBrZXlQYXRoLnN1YnN0cihwZXJpb2QgKyAxKTtcbiAgICAgICAgICAgICAgaWYgKHJlbWFpbmluZ0tleVBhdGggPT09ICcnKVxuICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNBcnJheShvYmopICYmICFpc05hTihwYXJzZUludChjdXJyZW50S2V5UGF0aCkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvYmouc3BsaWNlKGN1cnJlbnRLZXlQYXRoLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBvYmpbY3VycmVudEtleVBhdGhdO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgIG9ialtjdXJyZW50S2V5UGF0aF0gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICB2YXIgaW5uZXJPYmogPSBvYmpbY3VycmVudEtleVBhdGhdO1xuICAgICAgICAgICAgICAgICAgaWYgKCFpbm5lck9iaiB8fCAhaGFzT3duKG9iaiwgY3VycmVudEtleVBhdGgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICBpbm5lck9iaiA9IG9ialtjdXJyZW50S2V5UGF0aF0gPSB7fTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHNldEJ5S2V5UGF0aChpbm5lck9iaiwgcmVtYWluaW5nS2V5UGF0aCwgdmFsdWUpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgaWYgKGlzQXJyYXkob2JqKSAmJiAhaXNOYU4ocGFyc2VJbnQoa2V5UGF0aCkpKVxuICAgICAgICAgICAgICAgICAgICAgIG9iai5zcGxpY2Uoa2V5UGF0aCwgMSk7XG4gICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG9ialtrZXlQYXRoXTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICBvYmpba2V5UGF0aF0gPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gIH1cbiAgZnVuY3Rpb24gZGVsQnlLZXlQYXRoKG9iaiwga2V5UGF0aCkge1xuICAgICAgaWYgKHR5cGVvZiBrZXlQYXRoID09PSAnc3RyaW5nJylcbiAgICAgICAgICBzZXRCeUtleVBhdGgob2JqLCBrZXlQYXRoLCB1bmRlZmluZWQpO1xuICAgICAgZWxzZSBpZiAoJ2xlbmd0aCcgaW4ga2V5UGF0aClcbiAgICAgICAgICBbXS5tYXAuY2FsbChrZXlQYXRoLCBmdW5jdGlvbiAoa3ApIHtcbiAgICAgICAgICAgICAgc2V0QnlLZXlQYXRoKG9iaiwga3AsIHVuZGVmaW5lZCk7XG4gICAgICAgICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gc2hhbGxvd0Nsb25lKG9iaikge1xuICAgICAgdmFyIHJ2ID0ge307XG4gICAgICBmb3IgKHZhciBtIGluIG9iaikge1xuICAgICAgICAgIGlmIChoYXNPd24ob2JqLCBtKSlcbiAgICAgICAgICAgICAgcnZbbV0gPSBvYmpbbV07XG4gICAgICB9XG4gICAgICByZXR1cm4gcnY7XG4gIH1cbiAgdmFyIGNvbmNhdCA9IFtdLmNvbmNhdDtcbiAgZnVuY3Rpb24gZmxhdHRlbihhKSB7XG4gICAgICByZXR1cm4gY29uY2F0LmFwcGx5KFtdLCBhKTtcbiAgfVxuICB2YXIgaW50cmluc2ljVHlwZU5hbWVzID0gJ0JpZ1VpbnQ2NEFycmF5LEJpZ0ludDY0QXJyYXksQXJyYXksQm9vbGVhbixTdHJpbmcsRGF0ZSxSZWdFeHAsQmxvYixGaWxlLEZpbGVMaXN0LEZpbGVTeXN0ZW1GaWxlSGFuZGxlLEZpbGVTeXN0ZW1EaXJlY3RvcnlIYW5kbGUsQXJyYXlCdWZmZXIsRGF0YVZpZXcsVWludDhDbGFtcGVkQXJyYXksSW1hZ2VCaXRtYXAsSW1hZ2VEYXRhLE1hcCxTZXQsQ3J5cHRvS2V5J1xuICAgICAgLnNwbGl0KCcsJylcbiAgICAgIC5jb25jYXQoZmxhdHRlbihbOCwgMTYsIDMyLCA2NF0ubWFwKGZ1bmN0aW9uIChudW0pIHtcbiAgICAgIHJldHVybiBbJ0ludCcsICdVaW50JywgJ0Zsb2F0J10ubWFwKGZ1bmN0aW9uICh0KSB7IHJldHVybiB0ICsgbnVtICsgJ0FycmF5JzsgfSk7XG4gIH0pKSlcbiAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKHQpIHsgcmV0dXJuIF9nbG9iYWxbdF07IH0pO1xuICB2YXIgaW50cmluc2ljVHlwZXMgPSBuZXcgU2V0KGludHJpbnNpY1R5cGVOYW1lcy5tYXAoZnVuY3Rpb24gKHQpIHsgcmV0dXJuIF9nbG9iYWxbdF07IH0pKTtcbiAgZnVuY3Rpb24gY2xvbmVTaW1wbGVPYmplY3RUcmVlKG8pIHtcbiAgICAgIHZhciBydiA9IHt9O1xuICAgICAgZm9yICh2YXIgayBpbiBvKVxuICAgICAgICAgIGlmIChoYXNPd24obywgaykpIHtcbiAgICAgICAgICAgICAgdmFyIHYgPSBvW2tdO1xuICAgICAgICAgICAgICBydltrXSA9XG4gICAgICAgICAgICAgICAgICAhdiB8fCB0eXBlb2YgdiAhPT0gJ29iamVjdCcgfHwgaW50cmluc2ljVHlwZXMuaGFzKHYuY29uc3RydWN0b3IpXG4gICAgICAgICAgICAgICAgICAgICAgPyB2XG4gICAgICAgICAgICAgICAgICAgICAgOiBjbG9uZVNpbXBsZU9iamVjdFRyZWUodik7XG4gICAgICAgICAgfVxuICAgICAgcmV0dXJuIHJ2O1xuICB9XG4gIHZhciBjaXJjdWxhclJlZnMgPSBudWxsO1xuICBmdW5jdGlvbiBkZWVwQ2xvbmUoYW55KSB7XG4gICAgICBjaXJjdWxhclJlZnMgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgdmFyIHJ2ID0gaW5uZXJEZWVwQ2xvbmUoYW55KTtcbiAgICAgIGNpcmN1bGFyUmVmcyA9IG51bGw7XG4gICAgICByZXR1cm4gcnY7XG4gIH1cbiAgZnVuY3Rpb24gaW5uZXJEZWVwQ2xvbmUoeCkge1xuICAgICAgaWYgKCF4IHx8IHR5cGVvZiB4ICE9PSAnb2JqZWN0JylcbiAgICAgICAgICByZXR1cm4geDtcbiAgICAgIHZhciBydiA9IGNpcmN1bGFyUmVmcy5nZXQoeCk7XG4gICAgICBpZiAocnYpXG4gICAgICAgICAgcmV0dXJuIHJ2O1xuICAgICAgaWYgKGlzQXJyYXkoeCkpIHtcbiAgICAgICAgICBydiA9IFtdO1xuICAgICAgICAgIGNpcmN1bGFyUmVmcy5zZXQoeCwgcnYpO1xuICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsID0geC5sZW5ndGg7IGkgPCBsOyArK2kpIHtcbiAgICAgICAgICAgICAgcnYucHVzaChpbm5lckRlZXBDbG9uZSh4W2ldKSk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgZWxzZSBpZiAoaW50cmluc2ljVHlwZXMuaGFzKHguY29uc3RydWN0b3IpKSB7XG4gICAgICAgICAgcnYgPSB4O1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgICAgdmFyIHByb3RvID0gZ2V0UHJvdG8oeCk7XG4gICAgICAgICAgcnYgPSBwcm90byA9PT0gT2JqZWN0LnByb3RvdHlwZSA/IHt9IDogT2JqZWN0LmNyZWF0ZShwcm90byk7XG4gICAgICAgICAgY2lyY3VsYXJSZWZzLnNldCh4LCBydik7XG4gICAgICAgICAgZm9yICh2YXIgcHJvcCBpbiB4KSB7XG4gICAgICAgICAgICAgIGlmIChoYXNPd24oeCwgcHJvcCkpIHtcbiAgICAgICAgICAgICAgICAgIHJ2W3Byb3BdID0gaW5uZXJEZWVwQ2xvbmUoeFtwcm9wXSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gcnY7XG4gIH1cbiAgdmFyIHRvU3RyaW5nID0ge30udG9TdHJpbmc7XG4gIGZ1bmN0aW9uIHRvU3RyaW5nVGFnKG8pIHtcbiAgICAgIHJldHVybiB0b1N0cmluZy5jYWxsKG8pLnNsaWNlKDgsIC0xKTtcbiAgfVxuICB2YXIgaXRlcmF0b3JTeW1ib2wgPSB0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyA/IFN5bWJvbC5pdGVyYXRvciA6ICdAQGl0ZXJhdG9yJztcbiAgdmFyIGdldEl0ZXJhdG9yT2YgPSB0eXBlb2YgaXRlcmF0b3JTeW1ib2wgPT09ICdzeW1ib2wnXG4gICAgICA/IGZ1bmN0aW9uICh4KSB7XG4gICAgICAgICAgdmFyIGk7XG4gICAgICAgICAgcmV0dXJuIHggIT0gbnVsbCAmJiAoaSA9IHhbaXRlcmF0b3JTeW1ib2xdKSAmJiBpLmFwcGx5KHgpO1xuICAgICAgfVxuICAgICAgOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9O1xuICBmdW5jdGlvbiBkZWxBcnJheUl0ZW0oYSwgeCkge1xuICAgICAgdmFyIGkgPSBhLmluZGV4T2YoeCk7XG4gICAgICBpZiAoaSA+PSAwKVxuICAgICAgICAgIGEuc3BsaWNlKGksIDEpO1xuICAgICAgcmV0dXJuIGkgPj0gMDtcbiAgfVxuICB2YXIgTk9fQ0hBUl9BUlJBWSA9IHt9O1xuICBmdW5jdGlvbiBnZXRBcnJheU9mKGFycmF5TGlrZSkge1xuICAgICAgdmFyIGksIGEsIHgsIGl0O1xuICAgICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICBpZiAoaXNBcnJheShhcnJheUxpa2UpKVxuICAgICAgICAgICAgICByZXR1cm4gYXJyYXlMaWtlLnNsaWNlKCk7XG4gICAgICAgICAgaWYgKHRoaXMgPT09IE5PX0NIQVJfQVJSQVkgJiYgdHlwZW9mIGFycmF5TGlrZSA9PT0gJ3N0cmluZycpXG4gICAgICAgICAgICAgIHJldHVybiBbYXJyYXlMaWtlXTtcbiAgICAgICAgICBpZiAoKGl0ID0gZ2V0SXRlcmF0b3JPZihhcnJheUxpa2UpKSkge1xuICAgICAgICAgICAgICBhID0gW107XG4gICAgICAgICAgICAgIHdoaWxlICgoKHggPSBpdC5uZXh0KCkpLCAheC5kb25lKSlcbiAgICAgICAgICAgICAgICAgIGEucHVzaCh4LnZhbHVlKTtcbiAgICAgICAgICAgICAgcmV0dXJuIGE7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChhcnJheUxpa2UgPT0gbnVsbClcbiAgICAgICAgICAgICAgcmV0dXJuIFthcnJheUxpa2VdO1xuICAgICAgICAgIGkgPSBhcnJheUxpa2UubGVuZ3RoO1xuICAgICAgICAgIGlmICh0eXBlb2YgaSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgICAgYSA9IG5ldyBBcnJheShpKTtcbiAgICAgICAgICAgICAgd2hpbGUgKGktLSlcbiAgICAgICAgICAgICAgICAgIGFbaV0gPSBhcnJheUxpa2VbaV07XG4gICAgICAgICAgICAgIHJldHVybiBhO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gW2FycmF5TGlrZV07XG4gICAgICB9XG4gICAgICBpID0gYXJndW1lbnRzLmxlbmd0aDtcbiAgICAgIGEgPSBuZXcgQXJyYXkoaSk7XG4gICAgICB3aGlsZSAoaS0tKVxuICAgICAgICAgIGFbaV0gPSBhcmd1bWVudHNbaV07XG4gICAgICByZXR1cm4gYTtcbiAgfVxuICB2YXIgaXNBc3luY0Z1bmN0aW9uID0gdHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgID8gZnVuY3Rpb24gKGZuKSB7IHJldHVybiBmbltTeW1ib2wudG9TdHJpbmdUYWddID09PSAnQXN5bmNGdW5jdGlvbic7IH1cbiAgICAgIDogZnVuY3Rpb24gKCkgeyByZXR1cm4gZmFsc2U7IH07XG5cbiAgdmFyIGRleGllRXJyb3JOYW1lcyA9IFtcbiAgICAgICdNb2RpZnknLFxuICAgICAgJ0J1bGsnLFxuICAgICAgJ09wZW5GYWlsZWQnLFxuICAgICAgJ1ZlcnNpb25DaGFuZ2UnLFxuICAgICAgJ1NjaGVtYScsXG4gICAgICAnVXBncmFkZScsXG4gICAgICAnSW52YWxpZFRhYmxlJyxcbiAgICAgICdNaXNzaW5nQVBJJyxcbiAgICAgICdOb1N1Y2hEYXRhYmFzZScsXG4gICAgICAnSW52YWxpZEFyZ3VtZW50JyxcbiAgICAgICdTdWJUcmFuc2FjdGlvbicsXG4gICAgICAnVW5zdXBwb3J0ZWQnLFxuICAgICAgJ0ludGVybmFsJyxcbiAgICAgICdEYXRhYmFzZUNsb3NlZCcsXG4gICAgICAnUHJlbWF0dXJlQ29tbWl0JyxcbiAgICAgICdGb3JlaWduQXdhaXQnLFxuICBdO1xuICB2YXIgaWRiRG9tRXJyb3JOYW1lcyA9IFtcbiAgICAgICdVbmtub3duJyxcbiAgICAgICdDb25zdHJhaW50JyxcbiAgICAgICdEYXRhJyxcbiAgICAgICdUcmFuc2FjdGlvbkluYWN0aXZlJyxcbiAgICAgICdSZWFkT25seScsXG4gICAgICAnVmVyc2lvbicsXG4gICAgICAnTm90Rm91bmQnLFxuICAgICAgJ0ludmFsaWRTdGF0ZScsXG4gICAgICAnSW52YWxpZEFjY2VzcycsXG4gICAgICAnQWJvcnQnLFxuICAgICAgJ1RpbWVvdXQnLFxuICAgICAgJ1F1b3RhRXhjZWVkZWQnLFxuICAgICAgJ1N5bnRheCcsXG4gICAgICAnRGF0YUNsb25lJyxcbiAgXTtcbiAgdmFyIGVycm9yTGlzdCA9IGRleGllRXJyb3JOYW1lcy5jb25jYXQoaWRiRG9tRXJyb3JOYW1lcyk7XG4gIHZhciBkZWZhdWx0VGV4dHMgPSB7XG4gICAgICBWZXJzaW9uQ2hhbmdlZDogJ0RhdGFiYXNlIHZlcnNpb24gY2hhbmdlZCBieSBvdGhlciBkYXRhYmFzZSBjb25uZWN0aW9uJyxcbiAgICAgIERhdGFiYXNlQ2xvc2VkOiAnRGF0YWJhc2UgaGFzIGJlZW4gY2xvc2VkJyxcbiAgICAgIEFib3J0OiAnVHJhbnNhY3Rpb24gYWJvcnRlZCcsXG4gICAgICBUcmFuc2FjdGlvbkluYWN0aXZlOiAnVHJhbnNhY3Rpb24gaGFzIGFscmVhZHkgY29tcGxldGVkIG9yIGZhaWxlZCcsXG4gICAgICBNaXNzaW5nQVBJOiAnSW5kZXhlZERCIEFQSSBtaXNzaW5nLiBQbGVhc2UgdmlzaXQgaHR0cHM6Ly90aW55dXJsLmNvbS95MnV1dnNrYicsXG4gIH07XG4gIGZ1bmN0aW9uIERleGllRXJyb3IobmFtZSwgbXNnKSB7XG4gICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgICAgdGhpcy5tZXNzYWdlID0gbXNnO1xuICB9XG4gIGRlcml2ZShEZXhpZUVycm9yKVxuICAgICAgLmZyb20oRXJyb3IpXG4gICAgICAuZXh0ZW5kKHtcbiAgICAgIHRvU3RyaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMubmFtZSArICc6ICcgKyB0aGlzLm1lc3NhZ2U7XG4gICAgICB9LFxuICB9KTtcbiAgZnVuY3Rpb24gZ2V0TXVsdGlFcnJvck1lc3NhZ2UobXNnLCBmYWlsdXJlcykge1xuICAgICAgcmV0dXJuIChtc2cgK1xuICAgICAgICAgICcuIEVycm9yczogJyArXG4gICAgICAgICAgT2JqZWN0LmtleXMoZmFpbHVyZXMpXG4gICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGtleSkgeyByZXR1cm4gZmFpbHVyZXNba2V5XS50b1N0cmluZygpOyB9KVxuICAgICAgICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uICh2LCBpLCBzKSB7IHJldHVybiBzLmluZGV4T2YodikgPT09IGk7IH0pXG4gICAgICAgICAgICAgIC5qb2luKCdcXG4nKSk7XG4gIH1cbiAgZnVuY3Rpb24gTW9kaWZ5RXJyb3IobXNnLCBmYWlsdXJlcywgc3VjY2Vzc0NvdW50LCBmYWlsZWRLZXlzKSB7XG4gICAgICB0aGlzLmZhaWx1cmVzID0gZmFpbHVyZXM7XG4gICAgICB0aGlzLmZhaWxlZEtleXMgPSBmYWlsZWRLZXlzO1xuICAgICAgdGhpcy5zdWNjZXNzQ291bnQgPSBzdWNjZXNzQ291bnQ7XG4gICAgICB0aGlzLm1lc3NhZ2UgPSBnZXRNdWx0aUVycm9yTWVzc2FnZShtc2csIGZhaWx1cmVzKTtcbiAgfVxuICBkZXJpdmUoTW9kaWZ5RXJyb3IpLmZyb20oRGV4aWVFcnJvcik7XG4gIGZ1bmN0aW9uIEJ1bGtFcnJvcihtc2csIGZhaWx1cmVzKSB7XG4gICAgICB0aGlzLm5hbWUgPSAnQnVsa0Vycm9yJztcbiAgICAgIHRoaXMuZmFpbHVyZXMgPSBPYmplY3Qua2V5cyhmYWlsdXJlcykubWFwKGZ1bmN0aW9uIChwb3MpIHsgcmV0dXJuIGZhaWx1cmVzW3Bvc107IH0pO1xuICAgICAgdGhpcy5mYWlsdXJlc0J5UG9zID0gZmFpbHVyZXM7XG4gICAgICB0aGlzLm1lc3NhZ2UgPSBnZXRNdWx0aUVycm9yTWVzc2FnZShtc2csIHRoaXMuZmFpbHVyZXMpO1xuICB9XG4gIGRlcml2ZShCdWxrRXJyb3IpLmZyb20oRGV4aWVFcnJvcik7XG4gIHZhciBlcnJuYW1lcyA9IGVycm9yTGlzdC5yZWR1Y2UoZnVuY3Rpb24gKG9iaiwgbmFtZSkgeyByZXR1cm4gKChvYmpbbmFtZV0gPSBuYW1lICsgJ0Vycm9yJyksIG9iaik7IH0sIHt9KTtcbiAgdmFyIEJhc2VFeGNlcHRpb24gPSBEZXhpZUVycm9yO1xuICB2YXIgZXhjZXB0aW9ucyA9IGVycm9yTGlzdC5yZWR1Y2UoZnVuY3Rpb24gKG9iaiwgbmFtZSkge1xuICAgICAgdmFyIGZ1bGxOYW1lID0gbmFtZSArICdFcnJvcic7XG4gICAgICBmdW5jdGlvbiBEZXhpZUVycm9yKG1zZ09ySW5uZXIsIGlubmVyKSB7XG4gICAgICAgICAgdGhpcy5uYW1lID0gZnVsbE5hbWU7XG4gICAgICAgICAgaWYgKCFtc2dPcklubmVyKSB7XG4gICAgICAgICAgICAgIHRoaXMubWVzc2FnZSA9IGRlZmF1bHRUZXh0c1tuYW1lXSB8fCBmdWxsTmFtZTtcbiAgICAgICAgICAgICAgdGhpcy5pbm5lciA9IG51bGw7XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBtc2dPcklubmVyID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICB0aGlzLm1lc3NhZ2UgPSBcIlwiLmNvbmNhdChtc2dPcklubmVyKS5jb25jYXQoIWlubmVyID8gJycgOiAnXFxuICcgKyBpbm5lcik7XG4gICAgICAgICAgICAgIHRoaXMuaW5uZXIgPSBpbm5lciB8fCBudWxsO1xuICAgICAgICAgIH1cbiAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgbXNnT3JJbm5lciA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgdGhpcy5tZXNzYWdlID0gXCJcIi5jb25jYXQobXNnT3JJbm5lci5uYW1lLCBcIiBcIikuY29uY2F0KG1zZ09ySW5uZXIubWVzc2FnZSk7XG4gICAgICAgICAgICAgIHRoaXMuaW5uZXIgPSBtc2dPcklubmVyO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGRlcml2ZShEZXhpZUVycm9yKS5mcm9tKEJhc2VFeGNlcHRpb24pO1xuICAgICAgb2JqW25hbWVdID0gRGV4aWVFcnJvcjtcbiAgICAgIHJldHVybiBvYmo7XG4gIH0sIHt9KTtcbiAgZXhjZXB0aW9ucy5TeW50YXggPSBTeW50YXhFcnJvcjtcbiAgZXhjZXB0aW9ucy5UeXBlID0gVHlwZUVycm9yO1xuICBleGNlcHRpb25zLlJhbmdlID0gUmFuZ2VFcnJvcjtcbiAgdmFyIGV4Y2VwdGlvbk1hcCA9IGlkYkRvbUVycm9yTmFtZXMucmVkdWNlKGZ1bmN0aW9uIChvYmosIG5hbWUpIHtcbiAgICAgIG9ialtuYW1lICsgJ0Vycm9yJ10gPSBleGNlcHRpb25zW25hbWVdO1xuICAgICAgcmV0dXJuIG9iajtcbiAgfSwge30pO1xuICBmdW5jdGlvbiBtYXBFcnJvcihkb21FcnJvciwgbWVzc2FnZSkge1xuICAgICAgaWYgKCFkb21FcnJvciB8fFxuICAgICAgICAgIGRvbUVycm9yIGluc3RhbmNlb2YgRGV4aWVFcnJvciB8fFxuICAgICAgICAgIGRvbUVycm9yIGluc3RhbmNlb2YgVHlwZUVycm9yIHx8XG4gICAgICAgICAgZG9tRXJyb3IgaW5zdGFuY2VvZiBTeW50YXhFcnJvciB8fFxuICAgICAgICAgICFkb21FcnJvci5uYW1lIHx8XG4gICAgICAgICAgIWV4Y2VwdGlvbk1hcFtkb21FcnJvci5uYW1lXSlcbiAgICAgICAgICByZXR1cm4gZG9tRXJyb3I7XG4gICAgICB2YXIgcnYgPSBuZXcgZXhjZXB0aW9uTWFwW2RvbUVycm9yLm5hbWVdKG1lc3NhZ2UgfHwgZG9tRXJyb3IubWVzc2FnZSwgZG9tRXJyb3IpO1xuICAgICAgaWYgKCdzdGFjaycgaW4gZG9tRXJyb3IpIHtcbiAgICAgICAgICBzZXRQcm9wKHJ2LCAnc3RhY2snLCB7XG4gICAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuaW5uZXIuc3RhY2s7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcnY7XG4gIH1cbiAgdmFyIGZ1bGxOYW1lRXhjZXB0aW9ucyA9IGVycm9yTGlzdC5yZWR1Y2UoZnVuY3Rpb24gKG9iaiwgbmFtZSkge1xuICAgICAgaWYgKFsnU3ludGF4JywgJ1R5cGUnLCAnUmFuZ2UnXS5pbmRleE9mKG5hbWUpID09PSAtMSlcbiAgICAgICAgICBvYmpbbmFtZSArICdFcnJvciddID0gZXhjZXB0aW9uc1tuYW1lXTtcbiAgICAgIHJldHVybiBvYmo7XG4gIH0sIHt9KTtcbiAgZnVsbE5hbWVFeGNlcHRpb25zLk1vZGlmeUVycm9yID0gTW9kaWZ5RXJyb3I7XG4gIGZ1bGxOYW1lRXhjZXB0aW9ucy5EZXhpZUVycm9yID0gRGV4aWVFcnJvcjtcbiAgZnVsbE5hbWVFeGNlcHRpb25zLkJ1bGtFcnJvciA9IEJ1bGtFcnJvcjtcblxuICBmdW5jdGlvbiBub3AoKSB7IH1cbiAgZnVuY3Rpb24gbWlycm9yKHZhbCkge1xuICAgICAgcmV0dXJuIHZhbDtcbiAgfVxuICBmdW5jdGlvbiBwdXJlRnVuY3Rpb25DaGFpbihmMSwgZjIpIHtcbiAgICAgIGlmIChmMSA9PSBudWxsIHx8IGYxID09PSBtaXJyb3IpXG4gICAgICAgICAgcmV0dXJuIGYyO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uICh2YWwpIHtcbiAgICAgICAgICByZXR1cm4gZjIoZjEodmFsKSk7XG4gICAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIGNhbGxCb3RoKG9uMSwgb24yKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIG9uMS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIG9uMi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgfTtcbiAgfVxuICBmdW5jdGlvbiBob29rQ3JlYXRpbmdDaGFpbihmMSwgZjIpIHtcbiAgICAgIGlmIChmMSA9PT0gbm9wKVxuICAgICAgICAgIHJldHVybiBmMjtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIHJlcyA9IGYxLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgaWYgKHJlcyAhPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgICBhcmd1bWVudHNbMF0gPSByZXM7XG4gICAgICAgICAgdmFyIG9uc3VjY2VzcyA9IHRoaXMub25zdWNjZXNzLFxuICAgICAgICAgIG9uZXJyb3IgPSB0aGlzLm9uZXJyb3I7XG4gICAgICAgICAgdGhpcy5vbnN1Y2Nlc3MgPSBudWxsO1xuICAgICAgICAgIHRoaXMub25lcnJvciA9IG51bGw7XG4gICAgICAgICAgdmFyIHJlczIgPSBmMi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIGlmIChvbnN1Y2Nlc3MpXG4gICAgICAgICAgICAgIHRoaXMub25zdWNjZXNzID0gdGhpcy5vbnN1Y2Nlc3NcbiAgICAgICAgICAgICAgICAgID8gY2FsbEJvdGgob25zdWNjZXNzLCB0aGlzLm9uc3VjY2VzcylcbiAgICAgICAgICAgICAgICAgIDogb25zdWNjZXNzO1xuICAgICAgICAgIGlmIChvbmVycm9yKVxuICAgICAgICAgICAgICB0aGlzLm9uZXJyb3IgPSB0aGlzLm9uZXJyb3IgPyBjYWxsQm90aChvbmVycm9yLCB0aGlzLm9uZXJyb3IpIDogb25lcnJvcjtcbiAgICAgICAgICByZXR1cm4gcmVzMiAhPT0gdW5kZWZpbmVkID8gcmVzMiA6IHJlcztcbiAgICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gaG9va0RlbGV0aW5nQ2hhaW4oZjEsIGYyKSB7XG4gICAgICBpZiAoZjEgPT09IG5vcClcbiAgICAgICAgICByZXR1cm4gZjI7XG4gICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGYxLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgdmFyIG9uc3VjY2VzcyA9IHRoaXMub25zdWNjZXNzLFxuICAgICAgICAgIG9uZXJyb3IgPSB0aGlzLm9uZXJyb3I7XG4gICAgICAgICAgdGhpcy5vbnN1Y2Nlc3MgPSB0aGlzLm9uZXJyb3IgPSBudWxsO1xuICAgICAgICAgIGYyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgaWYgKG9uc3VjY2VzcylcbiAgICAgICAgICAgICAgdGhpcy5vbnN1Y2Nlc3MgPSB0aGlzLm9uc3VjY2Vzc1xuICAgICAgICAgICAgICAgICAgPyBjYWxsQm90aChvbnN1Y2Nlc3MsIHRoaXMub25zdWNjZXNzKVxuICAgICAgICAgICAgICAgICAgOiBvbnN1Y2Nlc3M7XG4gICAgICAgICAgaWYgKG9uZXJyb3IpXG4gICAgICAgICAgICAgIHRoaXMub25lcnJvciA9IHRoaXMub25lcnJvciA/IGNhbGxCb3RoKG9uZXJyb3IsIHRoaXMub25lcnJvcikgOiBvbmVycm9yO1xuICAgICAgfTtcbiAgfVxuICBmdW5jdGlvbiBob29rVXBkYXRpbmdDaGFpbihmMSwgZjIpIHtcbiAgICAgIGlmIChmMSA9PT0gbm9wKVxuICAgICAgICAgIHJldHVybiBmMjtcbiAgICAgIHJldHVybiBmdW5jdGlvbiAobW9kaWZpY2F0aW9ucykge1xuICAgICAgICAgIHZhciByZXMgPSBmMS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIGV4dGVuZChtb2RpZmljYXRpb25zLCByZXMpO1xuICAgICAgICAgIHZhciBvbnN1Y2Nlc3MgPSB0aGlzLm9uc3VjY2VzcyxcbiAgICAgICAgICBvbmVycm9yID0gdGhpcy5vbmVycm9yO1xuICAgICAgICAgIHRoaXMub25zdWNjZXNzID0gbnVsbDtcbiAgICAgICAgICB0aGlzLm9uZXJyb3IgPSBudWxsO1xuICAgICAgICAgIHZhciByZXMyID0gZjIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICBpZiAob25zdWNjZXNzKVxuICAgICAgICAgICAgICB0aGlzLm9uc3VjY2VzcyA9IHRoaXMub25zdWNjZXNzXG4gICAgICAgICAgICAgICAgICA/IGNhbGxCb3RoKG9uc3VjY2VzcywgdGhpcy5vbnN1Y2Nlc3MpXG4gICAgICAgICAgICAgICAgICA6IG9uc3VjY2VzcztcbiAgICAgICAgICBpZiAob25lcnJvcilcbiAgICAgICAgICAgICAgdGhpcy5vbmVycm9yID0gdGhpcy5vbmVycm9yID8gY2FsbEJvdGgob25lcnJvciwgdGhpcy5vbmVycm9yKSA6IG9uZXJyb3I7XG4gICAgICAgICAgcmV0dXJuIHJlcyA9PT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgID8gcmVzMiA9PT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICA/IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgOiByZXMyXG4gICAgICAgICAgICAgIDogZXh0ZW5kKHJlcywgcmVzMik7XG4gICAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIHJldmVyc2VTdG9wcGFibGVFdmVudENoYWluKGYxLCBmMikge1xuICAgICAgaWYgKGYxID09PSBub3ApXG4gICAgICAgICAgcmV0dXJuIGYyO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAoZjIuYXBwbHkodGhpcywgYXJndW1lbnRzKSA9PT0gZmFsc2UpXG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICByZXR1cm4gZjEuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gcHJvbWlzYWJsZUNoYWluKGYxLCBmMikge1xuICAgICAgaWYgKGYxID09PSBub3ApXG4gICAgICAgICAgcmV0dXJuIGYyO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgcmVzID0gZjEuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICBpZiAocmVzICYmIHR5cGVvZiByZXMudGhlbiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICB2YXIgdGhpeiA9IHRoaXMsIGkgPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KGkpO1xuICAgICAgICAgICAgICB3aGlsZSAoaS0tKVxuICAgICAgICAgICAgICAgICAgYXJnc1tpXSA9IGFyZ3VtZW50c1tpXTtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlcy50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBmMi5hcHBseSh0aGl6LCBhcmdzKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBmMi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgfTtcbiAgfVxuXG4gIHZhciBkZWJ1ZyA9IHR5cGVvZiBsb2NhdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgIC9eKGh0dHB8aHR0cHMpOlxcL1xcLyhsb2NhbGhvc3R8MTI3XFwuMFxcLjBcXC4xKS8udGVzdChsb2NhdGlvbi5ocmVmKTtcbiAgZnVuY3Rpb24gc2V0RGVidWcodmFsdWUsIGZpbHRlcikge1xuICAgICAgZGVidWcgPSB2YWx1ZTtcbiAgfVxuXG4gIHZhciBJTlRFUk5BTCA9IHt9O1xuICB2YXIgWk9ORV9FQ0hPX0xJTUlUID0gMTAwLCBfYSQxID0gdHlwZW9mIFByb21pc2UgPT09ICd1bmRlZmluZWQnXG4gICAgICA/IFtdXG4gICAgICA6IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIGdsb2JhbFAgPSBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgICBpZiAodHlwZW9mIGNyeXB0byA9PT0gJ3VuZGVmaW5lZCcgfHwgIWNyeXB0by5zdWJ0bGUpXG4gICAgICAgICAgICAgIHJldHVybiBbZ2xvYmFsUCwgZ2V0UHJvdG8oZ2xvYmFsUCksIGdsb2JhbFBdO1xuICAgICAgICAgIHZhciBuYXRpdmVQID0gY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS01MTInLCBuZXcgVWludDhBcnJheShbMF0pKTtcbiAgICAgICAgICByZXR1cm4gW25hdGl2ZVAsIGdldFByb3RvKG5hdGl2ZVApLCBnbG9iYWxQXTtcbiAgICAgIH0pKCksIHJlc29sdmVkTmF0aXZlUHJvbWlzZSA9IF9hJDFbMF0sIG5hdGl2ZVByb21pc2VQcm90byA9IF9hJDFbMV0sIHJlc29sdmVkR2xvYmFsUHJvbWlzZSA9IF9hJDFbMl0sIG5hdGl2ZVByb21pc2VUaGVuID0gbmF0aXZlUHJvbWlzZVByb3RvICYmIG5hdGl2ZVByb21pc2VQcm90by50aGVuO1xuICB2YXIgTmF0aXZlUHJvbWlzZSA9IHJlc29sdmVkTmF0aXZlUHJvbWlzZSAmJiByZXNvbHZlZE5hdGl2ZVByb21pc2UuY29uc3RydWN0b3I7XG4gIHZhciBwYXRjaEdsb2JhbFByb21pc2UgPSAhIXJlc29sdmVkR2xvYmFsUHJvbWlzZTtcbiAgZnVuY3Rpb24gc2NoZWR1bGVQaHlzaWNhbFRpY2soKSB7XG4gICAgICBxdWV1ZU1pY3JvdGFzayhwaHlzaWNhbFRpY2spO1xuICB9XG4gIHZhciBhc2FwID0gZnVuY3Rpb24gKGNhbGxiYWNrLCBhcmdzKSB7XG4gICAgICBtaWNyb3RpY2tRdWV1ZS5wdXNoKFtjYWxsYmFjaywgYXJnc10pO1xuICAgICAgaWYgKG5lZWRzTmV3UGh5c2ljYWxUaWNrKSB7XG4gICAgICAgICAgc2NoZWR1bGVQaHlzaWNhbFRpY2soKTtcbiAgICAgICAgICBuZWVkc05ld1BoeXNpY2FsVGljayA9IGZhbHNlO1xuICAgICAgfVxuICB9O1xuICB2YXIgaXNPdXRzaWRlTWljcm9UaWNrID0gdHJ1ZSxcbiAgbmVlZHNOZXdQaHlzaWNhbFRpY2sgPSB0cnVlLFxuICB1bmhhbmRsZWRFcnJvcnMgPSBbXSxcbiAgcmVqZWN0aW5nRXJyb3JzID0gW10sXG4gIHJlamVjdGlvbk1hcHBlciA9IG1pcnJvcjtcbiAgdmFyIGdsb2JhbFBTRCA9IHtcbiAgICAgIGlkOiAnZ2xvYmFsJyxcbiAgICAgIGdsb2JhbDogdHJ1ZSxcbiAgICAgIHJlZjogMCxcbiAgICAgIHVuaGFuZGxlZHM6IFtdLFxuICAgICAgb251bmhhbmRsZWQ6IG5vcCxcbiAgICAgIHBncDogZmFsc2UsXG4gICAgICBlbnY6IHt9LFxuICAgICAgZmluYWxpemU6IG5vcCxcbiAgfTtcbiAgdmFyIFBTRCA9IGdsb2JhbFBTRDtcbiAgdmFyIG1pY3JvdGlja1F1ZXVlID0gW107XG4gIHZhciBudW1TY2hlZHVsZWRDYWxscyA9IDA7XG4gIHZhciB0aWNrRmluYWxpemVycyA9IFtdO1xuICBmdW5jdGlvbiBEZXhpZVByb21pc2UoZm4pIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcyAhPT0gJ29iamVjdCcpXG4gICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignUHJvbWlzZXMgbXVzdCBiZSBjb25zdHJ1Y3RlZCB2aWEgbmV3Jyk7XG4gICAgICB0aGlzLl9saXN0ZW5lcnMgPSBbXTtcbiAgICAgIHRoaXMuX2xpYiA9IGZhbHNlO1xuICAgICAgdmFyIHBzZCA9ICh0aGlzLl9QU0QgPSBQU0QpO1xuICAgICAgaWYgKHR5cGVvZiBmbiAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgIGlmIChmbiAhPT0gSU5URVJOQUwpXG4gICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ05vdCBhIGZ1bmN0aW9uJyk7XG4gICAgICAgICAgdGhpcy5fc3RhdGUgPSBhcmd1bWVudHNbMV07XG4gICAgICAgICAgdGhpcy5fdmFsdWUgPSBhcmd1bWVudHNbMl07XG4gICAgICAgICAgaWYgKHRoaXMuX3N0YXRlID09PSBmYWxzZSlcbiAgICAgICAgICAgICAgaGFuZGxlUmVqZWN0aW9uKHRoaXMsIHRoaXMuX3ZhbHVlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB0aGlzLl9zdGF0ZSA9IG51bGw7XG4gICAgICB0aGlzLl92YWx1ZSA9IG51bGw7XG4gICAgICArK3BzZC5yZWY7XG4gICAgICBleGVjdXRlUHJvbWlzZVRhc2sodGhpcywgZm4pO1xuICB9XG4gIHZhciB0aGVuUHJvcCA9IHtcbiAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBwc2QgPSBQU0QsIG1pY3JvVGFza0lkID0gdG90YWxFY2hvZXM7XG4gICAgICAgICAgZnVuY3Rpb24gdGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICB2YXIgcG9zc2libGVBd2FpdCA9ICFwc2QuZ2xvYmFsICYmIChwc2QgIT09IFBTRCB8fCBtaWNyb1Rhc2tJZCAhPT0gdG90YWxFY2hvZXMpO1xuICAgICAgICAgICAgICB2YXIgY2xlYW51cCA9IHBvc3NpYmxlQXdhaXQgJiYgIWRlY3JlbWVudEV4cGVjdGVkQXdhaXRzKCk7XG4gICAgICAgICAgICAgIHZhciBydiA9IG5ldyBEZXhpZVByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgcHJvcGFnYXRlVG9MaXN0ZW5lcihfdGhpcywgbmV3IExpc3RlbmVyKG5hdGl2ZUF3YWl0Q29tcGF0aWJsZVdyYXAob25GdWxmaWxsZWQsIHBzZCwgcG9zc2libGVBd2FpdCwgY2xlYW51cCksIG5hdGl2ZUF3YWl0Q29tcGF0aWJsZVdyYXAob25SZWplY3RlZCwgcHNkLCBwb3NzaWJsZUF3YWl0LCBjbGVhbnVwKSwgcmVzb2x2ZSwgcmVqZWN0LCBwc2QpKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIGlmICh0aGlzLl9jb25zb2xlVGFzaylcbiAgICAgICAgICAgICAgICAgIHJ2Ll9jb25zb2xlVGFzayA9IHRoaXMuX2NvbnNvbGVUYXNrO1xuICAgICAgICAgICAgICByZXR1cm4gcnY7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoZW4ucHJvdG90eXBlID0gSU5URVJOQUw7XG4gICAgICAgICAgcmV0dXJuIHRoZW47XG4gICAgICB9LFxuICAgICAgc2V0OiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICBzZXRQcm9wKHRoaXMsICd0aGVuJywgdmFsdWUgJiYgdmFsdWUucHJvdG90eXBlID09PSBJTlRFUk5BTFxuICAgICAgICAgICAgICA/IHRoZW5Qcm9wXG4gICAgICAgICAgICAgIDoge1xuICAgICAgICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIHNldDogdGhlblByb3Auc2V0LFxuICAgICAgICAgICAgICB9KTtcbiAgICAgIH0sXG4gIH07XG4gIHByb3BzKERleGllUHJvbWlzZS5wcm90b3R5cGUsIHtcbiAgICAgIHRoZW46IHRoZW5Qcm9wLFxuICAgICAgX3RoZW46IGZ1bmN0aW9uIChvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgICAgIHByb3BhZ2F0ZVRvTGlzdGVuZXIodGhpcywgbmV3IExpc3RlbmVyKG51bGwsIG51bGwsIG9uRnVsZmlsbGVkLCBvblJlamVjdGVkLCBQU0QpKTtcbiAgICAgIH0sXG4gICAgICBjYXRjaDogZnVuY3Rpb24gKG9uUmVqZWN0ZWQpIHtcbiAgICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMSlcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMudGhlbihudWxsLCBvblJlamVjdGVkKTtcbiAgICAgICAgICB2YXIgdHlwZSA9IGFyZ3VtZW50c1swXSwgaGFuZGxlciA9IGFyZ3VtZW50c1sxXTtcbiAgICAgICAgICByZXR1cm4gdHlwZW9mIHR5cGUgPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgICAgPyB0aGlzLnRoZW4obnVsbCwgZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGVyciBpbnN0YW5jZW9mIHR5cGUgPyBoYW5kbGVyKGVycikgOiBQcm9taXNlUmVqZWN0KGVycik7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIDogdGhpcy50aGVuKG51bGwsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBlcnIgJiYgZXJyLm5hbWUgPT09IHR5cGUgPyBoYW5kbGVyKGVycikgOiBQcm9taXNlUmVqZWN0KGVycik7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIGZpbmFsbHk6IGZ1bmN0aW9uIChvbkZpbmFsbHkpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy50aGVuKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICByZXR1cm4gRGV4aWVQcm9taXNlLnJlc29sdmUob25GaW5hbGx5KCkpLnRoZW4oZnVuY3Rpb24gKCkgeyByZXR1cm4gdmFsdWU7IH0pO1xuICAgICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIERleGllUHJvbWlzZS5yZXNvbHZlKG9uRmluYWxseSgpKS50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIFByb21pc2VSZWplY3QoZXJyKTsgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgdGltZW91dDogZnVuY3Rpb24gKG1zLCBtc2cpIHtcbiAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgIHJldHVybiBtcyA8IEluZmluaXR5XG4gICAgICAgICAgICAgID8gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICB2YXIgaGFuZGxlID0gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7IHJldHVybiByZWplY3QobmV3IGV4Y2VwdGlvbnMuVGltZW91dChtc2cpKTsgfSwgbXMpO1xuICAgICAgICAgICAgICAgICAgX3RoaXMudGhlbihyZXNvbHZlLCByZWplY3QpLmZpbmFsbHkoY2xlYXJUaW1lb3V0LmJpbmQobnVsbCwgaGFuZGxlKSk7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIDogdGhpcztcbiAgICAgIH0sXG4gIH0pO1xuICBpZiAodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKVxuICAgICAgc2V0UHJvcChEZXhpZVByb21pc2UucHJvdG90eXBlLCBTeW1ib2wudG9TdHJpbmdUYWcsICdEZXhpZS5Qcm9taXNlJyk7XG4gIGdsb2JhbFBTRC5lbnYgPSBzbmFwU2hvdCgpO1xuICBmdW5jdGlvbiBMaXN0ZW5lcihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCwgcmVzb2x2ZSwgcmVqZWN0LCB6b25lKSB7XG4gICAgICB0aGlzLm9uRnVsZmlsbGVkID0gdHlwZW9mIG9uRnVsZmlsbGVkID09PSAnZnVuY3Rpb24nID8gb25GdWxmaWxsZWQgOiBudWxsO1xuICAgICAgdGhpcy5vblJlamVjdGVkID0gdHlwZW9mIG9uUmVqZWN0ZWQgPT09ICdmdW5jdGlvbicgPyBvblJlamVjdGVkIDogbnVsbDtcbiAgICAgIHRoaXMucmVzb2x2ZSA9IHJlc29sdmU7XG4gICAgICB0aGlzLnJlamVjdCA9IHJlamVjdDtcbiAgICAgIHRoaXMucHNkID0gem9uZTtcbiAgfVxuICBwcm9wcyhEZXhpZVByb21pc2UsIHtcbiAgICAgIGFsbDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciB2YWx1ZXMgPSBnZXRBcnJheU9mXG4gICAgICAgICAgICAgIC5hcHBseShudWxsLCBhcmd1bWVudHMpXG4gICAgICAgICAgICAgIC5tYXAob25Qb3NzaWJsZVBhcmFsbGVsbEFzeW5jKTtcbiAgICAgICAgICByZXR1cm4gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgIGlmICh2YWx1ZXMubGVuZ3RoID09PSAwKVxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZShbXSk7XG4gICAgICAgICAgICAgIHZhciByZW1haW5pbmcgPSB2YWx1ZXMubGVuZ3RoO1xuICAgICAgICAgICAgICB2YWx1ZXMuZm9yRWFjaChmdW5jdGlvbiAoYSwgaSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIERleGllUHJvbWlzZS5yZXNvbHZlKGEpLnRoZW4oZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXNbaV0gPSB4O1xuICAgICAgICAgICAgICAgICAgICAgIGlmICghLS1yZW1haW5pbmcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUodmFsdWVzKTtcbiAgICAgICAgICAgICAgICAgIH0sIHJlamVjdCk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIHJlc29sdmU6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIERleGllUHJvbWlzZSlcbiAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgIGlmICh2YWx1ZSAmJiB0eXBlb2YgdmFsdWUudGhlbiA9PT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgICAgICAgcmV0dXJuIG5ldyBEZXhpZVByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgdmFsdWUudGhlbihyZXNvbHZlLCByZWplY3QpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB2YXIgcnYgPSBuZXcgRGV4aWVQcm9taXNlKElOVEVSTkFMLCB0cnVlLCB2YWx1ZSk7XG4gICAgICAgICAgcmV0dXJuIHJ2O1xuICAgICAgfSxcbiAgICAgIHJlamVjdDogUHJvbWlzZVJlamVjdCxcbiAgICAgIHJhY2U6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgdmFsdWVzID0gZ2V0QXJyYXlPZlxuICAgICAgICAgICAgICAuYXBwbHkobnVsbCwgYXJndW1lbnRzKVxuICAgICAgICAgICAgICAubWFwKG9uUG9zc2libGVQYXJhbGxlbGxBc3luYyk7XG4gICAgICAgICAgcmV0dXJuIG5ldyBEZXhpZVByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICB2YWx1ZXMubWFwKGZ1bmN0aW9uICh2YWx1ZSkgeyByZXR1cm4gRGV4aWVQcm9taXNlLnJlc29sdmUodmFsdWUpLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTsgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICB9LFxuICAgICAgUFNEOiB7XG4gICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBQU0Q7IH0sXG4gICAgICAgICAgc2V0OiBmdW5jdGlvbiAodmFsdWUpIHsgcmV0dXJuIChQU0QgPSB2YWx1ZSk7IH0sXG4gICAgICB9LFxuICAgICAgdG90YWxFY2hvZXM6IHsgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiB0b3RhbEVjaG9lczsgfSB9LFxuICAgICAgbmV3UFNEOiBuZXdTY29wZSxcbiAgICAgIHVzZVBTRDogdXNlUFNELFxuICAgICAgc2NoZWR1bGVyOiB7XG4gICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBhc2FwOyB9LFxuICAgICAgICAgIHNldDogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgIGFzYXAgPSB2YWx1ZTtcbiAgICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHJlamVjdGlvbk1hcHBlcjoge1xuICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gcmVqZWN0aW9uTWFwcGVyOyB9LFxuICAgICAgICAgIHNldDogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgIHJlamVjdGlvbk1hcHBlciA9IHZhbHVlO1xuICAgICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgZm9sbG93OiBmdW5jdGlvbiAoZm4sIHpvbmVQcm9wcykge1xuICAgICAgICAgIHJldHVybiBuZXcgRGV4aWVQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG5ld1Njb3BlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBwc2QgPSBQU0Q7XG4gICAgICAgICAgICAgICAgICBwc2QudW5oYW5kbGVkcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgcHNkLm9udW5oYW5kbGVkID0gcmVqZWN0O1xuICAgICAgICAgICAgICAgICAgcHNkLmZpbmFsaXplID0gY2FsbEJvdGgoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgcnVuX2F0X2VuZF9vZl90aGlzX29yX25leHRfcGh5c2ljYWxfdGljayhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnVuaGFuZGxlZHMubGVuZ3RoID09PSAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHJlc29sdmUoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiByZWplY3QoX3RoaXMudW5oYW5kbGVkc1swXSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9LCBwc2QuZmluYWxpemUpO1xuICAgICAgICAgICAgICAgICAgZm4oKTtcbiAgICAgICAgICAgICAgfSwgem9uZVByb3BzLCByZXNvbHZlLCByZWplY3QpO1xuICAgICAgICAgIH0pO1xuICAgICAgfSxcbiAgfSk7XG4gIGlmIChOYXRpdmVQcm9taXNlKSB7XG4gICAgICBpZiAoTmF0aXZlUHJvbWlzZS5hbGxTZXR0bGVkKVxuICAgICAgICAgIHNldFByb3AoRGV4aWVQcm9taXNlLCAnYWxsU2V0dGxlZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgdmFyIHBvc3NpYmxlUHJvbWlzZXMgPSBnZXRBcnJheU9mXG4gICAgICAgICAgICAgICAgICAuYXBwbHkobnVsbCwgYXJndW1lbnRzKVxuICAgICAgICAgICAgICAgICAgLm1hcChvblBvc3NpYmxlUGFyYWxsZWxsQXN5bmMpO1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSkge1xuICAgICAgICAgICAgICAgICAgaWYgKHBvc3NpYmxlUHJvbWlzZXMubGVuZ3RoID09PSAwKVxuICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoW10pO1xuICAgICAgICAgICAgICAgICAgdmFyIHJlbWFpbmluZyA9IHBvc3NpYmxlUHJvbWlzZXMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdHMgPSBuZXcgQXJyYXkocmVtYWluaW5nKTtcbiAgICAgICAgICAgICAgICAgIHBvc3NpYmxlUHJvbWlzZXMuZm9yRWFjaChmdW5jdGlvbiAocCwgaSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBEZXhpZVByb21pc2UucmVzb2x2ZShwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAodmFsdWUpIHsgcmV0dXJuIChyZXN1bHRzW2ldID0geyBzdGF0dXM6ICdmdWxmaWxsZWQnLCB2YWx1ZTogdmFsdWUgfSk7IH0sIGZ1bmN0aW9uIChyZWFzb24pIHsgcmV0dXJuIChyZXN1bHRzW2ldID0geyBzdGF0dXM6ICdyZWplY3RlZCcsIHJlYXNvbjogcmVhc29uIH0pOyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7IHJldHVybiAtLXJlbWFpbmluZyB8fCByZXNvbHZlKHJlc3VsdHMpOyB9KTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIGlmIChOYXRpdmVQcm9taXNlLmFueSAmJiB0eXBlb2YgQWdncmVnYXRlRXJyb3IgIT09ICd1bmRlZmluZWQnKVxuICAgICAgICAgIHNldFByb3AoRGV4aWVQcm9taXNlLCAnYW55JywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICB2YXIgcG9zc2libGVQcm9taXNlcyA9IGdldEFycmF5T2ZcbiAgICAgICAgICAgICAgICAgIC5hcHBseShudWxsLCBhcmd1bWVudHMpXG4gICAgICAgICAgICAgICAgICAubWFwKG9uUG9zc2libGVQYXJhbGxlbGxBc3luYyk7XG4gICAgICAgICAgICAgIHJldHVybiBuZXcgRGV4aWVQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChwb3NzaWJsZVByb21pc2VzLmxlbmd0aCA9PT0gMClcbiAgICAgICAgICAgICAgICAgICAgICByZWplY3QobmV3IEFnZ3JlZ2F0ZUVycm9yKFtdKSk7XG4gICAgICAgICAgICAgICAgICB2YXIgcmVtYWluaW5nID0gcG9zc2libGVQcm9taXNlcy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICB2YXIgZmFpbHVyZXMgPSBuZXcgQXJyYXkocmVtYWluaW5nKTtcbiAgICAgICAgICAgICAgICAgIHBvc3NpYmxlUHJvbWlzZXMuZm9yRWFjaChmdW5jdGlvbiAocCwgaSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBEZXhpZVByb21pc2UucmVzb2x2ZShwKS50aGVuKGZ1bmN0aW9uICh2YWx1ZSkgeyByZXR1cm4gcmVzb2x2ZSh2YWx1ZSk7IH0sIGZ1bmN0aW9uIChmYWlsdXJlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmVzW2ldID0gZmFpbHVyZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEtLXJlbWFpbmluZylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChuZXcgQWdncmVnYXRlRXJyb3IoZmFpbHVyZXMpKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIGlmIChOYXRpdmVQcm9taXNlLndpdGhSZXNvbHZlcnMpXG4gICAgICAgICAgRGV4aWVQcm9taXNlLndpdGhSZXNvbHZlcnMgPSBOYXRpdmVQcm9taXNlLndpdGhSZXNvbHZlcnM7XG4gIH1cbiAgZnVuY3Rpb24gZXhlY3V0ZVByb21pc2VUYXNrKHByb21pc2UsIGZuKSB7XG4gICAgICB0cnkge1xuICAgICAgICAgIGZuKGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICBpZiAocHJvbWlzZS5fc3RhdGUgIT09IG51bGwpXG4gICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIGlmICh2YWx1ZSA9PT0gcHJvbWlzZSlcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0EgcHJvbWlzZSBjYW5ub3QgYmUgcmVzb2x2ZWQgd2l0aCBpdHNlbGYuJyk7XG4gICAgICAgICAgICAgIHZhciBzaG91bGRFeGVjdXRlVGljayA9IHByb21pc2UuX2xpYiAmJiBiZWdpbk1pY3JvVGlja1Njb3BlKCk7XG4gICAgICAgICAgICAgIGlmICh2YWx1ZSAmJiB0eXBlb2YgdmFsdWUudGhlbiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgZXhlY3V0ZVByb21pc2VUYXNrKHByb21pc2UsIGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSBpbnN0YW5jZW9mIERleGllUHJvbWlzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IHZhbHVlLl90aGVuKHJlc29sdmUsIHJlamVjdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiB2YWx1ZS50aGVuKHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHByb21pc2UuX3N0YXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgIHByb21pc2UuX3ZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgICBwcm9wYWdhdGVBbGxMaXN0ZW5lcnMocHJvbWlzZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYgKHNob3VsZEV4ZWN1dGVUaWNrKVxuICAgICAgICAgICAgICAgICAgZW5kTWljcm9UaWNrU2NvcGUoKTtcbiAgICAgICAgICB9LCBoYW5kbGVSZWplY3Rpb24uYmluZChudWxsLCBwcm9taXNlKSk7XG4gICAgICB9XG4gICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICBoYW5kbGVSZWplY3Rpb24ocHJvbWlzZSwgZXgpO1xuICAgICAgfVxuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZVJlamVjdGlvbihwcm9taXNlLCByZWFzb24pIHtcbiAgICAgIHJlamVjdGluZ0Vycm9ycy5wdXNoKHJlYXNvbik7XG4gICAgICBpZiAocHJvbWlzZS5fc3RhdGUgIT09IG51bGwpXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgdmFyIHNob3VsZEV4ZWN1dGVUaWNrID0gcHJvbWlzZS5fbGliICYmIGJlZ2luTWljcm9UaWNrU2NvcGUoKTtcbiAgICAgIHJlYXNvbiA9IHJlamVjdGlvbk1hcHBlcihyZWFzb24pO1xuICAgICAgcHJvbWlzZS5fc3RhdGUgPSBmYWxzZTtcbiAgICAgIHByb21pc2UuX3ZhbHVlID0gcmVhc29uO1xuICAgICAgYWRkUG9zc2libHlVbmhhbmRsZWRFcnJvcihwcm9taXNlKTtcbiAgICAgIHByb3BhZ2F0ZUFsbExpc3RlbmVycyhwcm9taXNlKTtcbiAgICAgIGlmIChzaG91bGRFeGVjdXRlVGljaylcbiAgICAgICAgICBlbmRNaWNyb1RpY2tTY29wZSgpO1xuICB9XG4gIGZ1bmN0aW9uIHByb3BhZ2F0ZUFsbExpc3RlbmVycyhwcm9taXNlKSB7XG4gICAgICB2YXIgbGlzdGVuZXJzID0gcHJvbWlzZS5fbGlzdGVuZXJzO1xuICAgICAgcHJvbWlzZS5fbGlzdGVuZXJzID0gW107XG4gICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gbGlzdGVuZXJzLmxlbmd0aDsgaSA8IGxlbjsgKytpKSB7XG4gICAgICAgICAgcHJvcGFnYXRlVG9MaXN0ZW5lcihwcm9taXNlLCBsaXN0ZW5lcnNbaV0pO1xuICAgICAgfVxuICAgICAgdmFyIHBzZCA9IHByb21pc2UuX1BTRDtcbiAgICAgIC0tcHNkLnJlZiB8fCBwc2QuZmluYWxpemUoKTtcbiAgICAgIGlmIChudW1TY2hlZHVsZWRDYWxscyA9PT0gMCkge1xuICAgICAgICAgICsrbnVtU2NoZWR1bGVkQ2FsbHM7XG4gICAgICAgICAgYXNhcChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIGlmICgtLW51bVNjaGVkdWxlZENhbGxzID09PSAwKVxuICAgICAgICAgICAgICAgICAgZmluYWxpemVQaHlzaWNhbFRpY2soKTtcbiAgICAgICAgICB9LCBbXSk7XG4gICAgICB9XG4gIH1cbiAgZnVuY3Rpb24gcHJvcGFnYXRlVG9MaXN0ZW5lcihwcm9taXNlLCBsaXN0ZW5lcikge1xuICAgICAgaWYgKHByb21pc2UuX3N0YXRlID09PSBudWxsKSB7XG4gICAgICAgICAgcHJvbWlzZS5fbGlzdGVuZXJzLnB1c2gobGlzdGVuZXIpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHZhciBjYiA9IHByb21pc2UuX3N0YXRlID8gbGlzdGVuZXIub25GdWxmaWxsZWQgOiBsaXN0ZW5lci5vblJlamVjdGVkO1xuICAgICAgaWYgKGNiID09PSBudWxsKSB7XG4gICAgICAgICAgcmV0dXJuIChwcm9taXNlLl9zdGF0ZSA/IGxpc3RlbmVyLnJlc29sdmUgOiBsaXN0ZW5lci5yZWplY3QpKHByb21pc2UuX3ZhbHVlKTtcbiAgICAgIH1cbiAgICAgICsrbGlzdGVuZXIucHNkLnJlZjtcbiAgICAgICsrbnVtU2NoZWR1bGVkQ2FsbHM7XG4gICAgICBhc2FwKGNhbGxMaXN0ZW5lciwgW2NiLCBwcm9taXNlLCBsaXN0ZW5lcl0pO1xuICB9XG4gIGZ1bmN0aW9uIGNhbGxMaXN0ZW5lcihjYiwgcHJvbWlzZSwgbGlzdGVuZXIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgICAgdmFyIHJldCwgdmFsdWUgPSBwcm9taXNlLl92YWx1ZTtcbiAgICAgICAgICBpZiAoIXByb21pc2UuX3N0YXRlICYmIHJlamVjdGluZ0Vycm9ycy5sZW5ndGgpXG4gICAgICAgICAgICAgIHJlamVjdGluZ0Vycm9ycyA9IFtdO1xuICAgICAgICAgIHJldCA9XG4gICAgICAgICAgICAgIGRlYnVnICYmIHByb21pc2UuX2NvbnNvbGVUYXNrXG4gICAgICAgICAgICAgICAgICA/IHByb21pc2UuX2NvbnNvbGVUYXNrLnJ1bihmdW5jdGlvbiAoKSB7IHJldHVybiBjYih2YWx1ZSk7IH0pXG4gICAgICAgICAgICAgICAgICA6IGNiKHZhbHVlKTtcbiAgICAgICAgICBpZiAoIXByb21pc2UuX3N0YXRlICYmIHJlamVjdGluZ0Vycm9ycy5pbmRleE9mKHZhbHVlKSA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgbWFya0Vycm9yQXNIYW5kbGVkKHByb21pc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBsaXN0ZW5lci5yZXNvbHZlKHJldCk7XG4gICAgICB9XG4gICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgIGxpc3RlbmVyLnJlamVjdChlKTtcbiAgICAgIH1cbiAgICAgIGZpbmFsbHkge1xuICAgICAgICAgIGlmICgtLW51bVNjaGVkdWxlZENhbGxzID09PSAwKVxuICAgICAgICAgICAgICBmaW5hbGl6ZVBoeXNpY2FsVGljaygpO1xuICAgICAgICAgIC0tbGlzdGVuZXIucHNkLnJlZiB8fCBsaXN0ZW5lci5wc2QuZmluYWxpemUoKTtcbiAgICAgIH1cbiAgfVxuICBmdW5jdGlvbiBwaHlzaWNhbFRpY2soKSB7XG4gICAgICB1c2VQU0QoZ2xvYmFsUFNELCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgYmVnaW5NaWNyb1RpY2tTY29wZSgpICYmIGVuZE1pY3JvVGlja1Njb3BlKCk7XG4gICAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBiZWdpbk1pY3JvVGlja1Njb3BlKCkge1xuICAgICAgdmFyIHdhc1Jvb3RFeGVjID0gaXNPdXRzaWRlTWljcm9UaWNrO1xuICAgICAgaXNPdXRzaWRlTWljcm9UaWNrID0gZmFsc2U7XG4gICAgICBuZWVkc05ld1BoeXNpY2FsVGljayA9IGZhbHNlO1xuICAgICAgcmV0dXJuIHdhc1Jvb3RFeGVjO1xuICB9XG4gIGZ1bmN0aW9uIGVuZE1pY3JvVGlja1Njb3BlKCkge1xuICAgICAgdmFyIGNhbGxiYWNrcywgaSwgbDtcbiAgICAgIGRvIHtcbiAgICAgICAgICB3aGlsZSAobWljcm90aWNrUXVldWUubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICBjYWxsYmFja3MgPSBtaWNyb3RpY2tRdWV1ZTtcbiAgICAgICAgICAgICAgbWljcm90aWNrUXVldWUgPSBbXTtcbiAgICAgICAgICAgICAgbCA9IGNhbGxiYWNrcy5sZW5ndGg7XG4gICAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBsOyArK2kpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBpdGVtID0gY2FsbGJhY2tzW2ldO1xuICAgICAgICAgICAgICAgICAgaXRlbVswXS5hcHBseShudWxsLCBpdGVtWzFdKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH0gd2hpbGUgKG1pY3JvdGlja1F1ZXVlLmxlbmd0aCA+IDApO1xuICAgICAgaXNPdXRzaWRlTWljcm9UaWNrID0gdHJ1ZTtcbiAgICAgIG5lZWRzTmV3UGh5c2ljYWxUaWNrID0gdHJ1ZTtcbiAgfVxuICBmdW5jdGlvbiBmaW5hbGl6ZVBoeXNpY2FsVGljaygpIHtcbiAgICAgIHZhciB1bmhhbmRsZWRFcnJzID0gdW5oYW5kbGVkRXJyb3JzO1xuICAgICAgdW5oYW5kbGVkRXJyb3JzID0gW107XG4gICAgICB1bmhhbmRsZWRFcnJzLmZvckVhY2goZnVuY3Rpb24gKHApIHtcbiAgICAgICAgICBwLl9QU0Qub251bmhhbmRsZWQuY2FsbChudWxsLCBwLl92YWx1ZSwgcCk7XG4gICAgICB9KTtcbiAgICAgIHZhciBmaW5hbGl6ZXJzID0gdGlja0ZpbmFsaXplcnMuc2xpY2UoMCk7XG4gICAgICB2YXIgaSA9IGZpbmFsaXplcnMubGVuZ3RoO1xuICAgICAgd2hpbGUgKGkpXG4gICAgICAgICAgZmluYWxpemVyc1stLWldKCk7XG4gIH1cbiAgZnVuY3Rpb24gcnVuX2F0X2VuZF9vZl90aGlzX29yX25leHRfcGh5c2ljYWxfdGljayhmbikge1xuICAgICAgZnVuY3Rpb24gZmluYWxpemVyKCkge1xuICAgICAgICAgIGZuKCk7XG4gICAgICAgICAgdGlja0ZpbmFsaXplcnMuc3BsaWNlKHRpY2tGaW5hbGl6ZXJzLmluZGV4T2YoZmluYWxpemVyKSwgMSk7XG4gICAgICB9XG4gICAgICB0aWNrRmluYWxpemVycy5wdXNoKGZpbmFsaXplcik7XG4gICAgICArK251bVNjaGVkdWxlZENhbGxzO1xuICAgICAgYXNhcChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaWYgKC0tbnVtU2NoZWR1bGVkQ2FsbHMgPT09IDApXG4gICAgICAgICAgICAgIGZpbmFsaXplUGh5c2ljYWxUaWNrKCk7XG4gICAgICB9LCBbXSk7XG4gIH1cbiAgZnVuY3Rpb24gYWRkUG9zc2libHlVbmhhbmRsZWRFcnJvcihwcm9taXNlKSB7XG4gICAgICBpZiAoIXVuaGFuZGxlZEVycm9ycy5zb21lKGZ1bmN0aW9uIChwKSB7IHJldHVybiBwLl92YWx1ZSA9PT0gcHJvbWlzZS5fdmFsdWU7IH0pKVxuICAgICAgICAgIHVuaGFuZGxlZEVycm9ycy5wdXNoKHByb21pc2UpO1xuICB9XG4gIGZ1bmN0aW9uIG1hcmtFcnJvckFzSGFuZGxlZChwcm9taXNlKSB7XG4gICAgICB2YXIgaSA9IHVuaGFuZGxlZEVycm9ycy5sZW5ndGg7XG4gICAgICB3aGlsZSAoaSlcbiAgICAgICAgICBpZiAodW5oYW5kbGVkRXJyb3JzWy0taV0uX3ZhbHVlID09PSBwcm9taXNlLl92YWx1ZSkge1xuICAgICAgICAgICAgICB1bmhhbmRsZWRFcnJvcnMuc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICB9XG4gIGZ1bmN0aW9uIFByb21pc2VSZWplY3QocmVhc29uKSB7XG4gICAgICByZXR1cm4gbmV3IERleGllUHJvbWlzZShJTlRFUk5BTCwgZmFsc2UsIHJlYXNvbik7XG4gIH1cbiAgZnVuY3Rpb24gd3JhcChmbiwgZXJyb3JDYXRjaGVyKSB7XG4gICAgICB2YXIgcHNkID0gUFNEO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgd2FzUm9vdEV4ZWMgPSBiZWdpbk1pY3JvVGlja1Njb3BlKCksIG91dGVyU2NvcGUgPSBQU0Q7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgc3dpdGNoVG9ab25lKHBzZCwgdHJ1ZSk7XG4gICAgICAgICAgICAgIHJldHVybiBmbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICBlcnJvckNhdGNoZXIgJiYgZXJyb3JDYXRjaGVyKGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgc3dpdGNoVG9ab25lKG91dGVyU2NvcGUsIGZhbHNlKTtcbiAgICAgICAgICAgICAgaWYgKHdhc1Jvb3RFeGVjKVxuICAgICAgICAgICAgICAgICAgZW5kTWljcm9UaWNrU2NvcGUoKTtcbiAgICAgICAgICB9XG4gICAgICB9O1xuICB9XG4gIHZhciB0YXNrID0geyBhd2FpdHM6IDAsIGVjaG9lczogMCwgaWQ6IDAgfTtcbiAgdmFyIHRhc2tDb3VudGVyID0gMDtcbiAgdmFyIHpvbmVTdGFjayA9IFtdO1xuICB2YXIgem9uZUVjaG9lcyA9IDA7XG4gIHZhciB0b3RhbEVjaG9lcyA9IDA7XG4gIHZhciB6b25lX2lkX2NvdW50ZXIgPSAwO1xuICBmdW5jdGlvbiBuZXdTY29wZShmbiwgcHJvcHMsIGExLCBhMikge1xuICAgICAgdmFyIHBhcmVudCA9IFBTRCwgcHNkID0gT2JqZWN0LmNyZWF0ZShwYXJlbnQpO1xuICAgICAgcHNkLnBhcmVudCA9IHBhcmVudDtcbiAgICAgIHBzZC5yZWYgPSAwO1xuICAgICAgcHNkLmdsb2JhbCA9IGZhbHNlO1xuICAgICAgcHNkLmlkID0gKyt6b25lX2lkX2NvdW50ZXI7XG4gICAgICBnbG9iYWxQU0QuZW52O1xuICAgICAgcHNkLmVudiA9IHBhdGNoR2xvYmFsUHJvbWlzZVxuICAgICAgICAgID8ge1xuICAgICAgICAgICAgICBQcm9taXNlOiBEZXhpZVByb21pc2UsXG4gICAgICAgICAgICAgIFByb21pc2VQcm9wOiB7XG4gICAgICAgICAgICAgICAgICB2YWx1ZTogRGV4aWVQcm9taXNlLFxuICAgICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGFsbDogRGV4aWVQcm9taXNlLmFsbCxcbiAgICAgICAgICAgICAgcmFjZTogRGV4aWVQcm9taXNlLnJhY2UsXG4gICAgICAgICAgICAgIGFsbFNldHRsZWQ6IERleGllUHJvbWlzZS5hbGxTZXR0bGVkLFxuICAgICAgICAgICAgICBhbnk6IERleGllUHJvbWlzZS5hbnksXG4gICAgICAgICAgICAgIHJlc29sdmU6IERleGllUHJvbWlzZS5yZXNvbHZlLFxuICAgICAgICAgICAgICByZWplY3Q6IERleGllUHJvbWlzZS5yZWplY3QsXG4gICAgICAgICAgfVxuICAgICAgICAgIDoge307XG4gICAgICBpZiAocHJvcHMpXG4gICAgICAgICAgZXh0ZW5kKHBzZCwgcHJvcHMpO1xuICAgICAgKytwYXJlbnQucmVmO1xuICAgICAgcHNkLmZpbmFsaXplID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIC0tdGhpcy5wYXJlbnQucmVmIHx8IHRoaXMucGFyZW50LmZpbmFsaXplKCk7XG4gICAgICB9O1xuICAgICAgdmFyIHJ2ID0gdXNlUFNEKHBzZCwgZm4sIGExLCBhMik7XG4gICAgICBpZiAocHNkLnJlZiA9PT0gMClcbiAgICAgICAgICBwc2QuZmluYWxpemUoKTtcbiAgICAgIHJldHVybiBydjtcbiAgfVxuICBmdW5jdGlvbiBpbmNyZW1lbnRFeHBlY3RlZEF3YWl0cygpIHtcbiAgICAgIGlmICghdGFzay5pZClcbiAgICAgICAgICB0YXNrLmlkID0gKyt0YXNrQ291bnRlcjtcbiAgICAgICsrdGFzay5hd2FpdHM7XG4gICAgICB0YXNrLmVjaG9lcyArPSBaT05FX0VDSE9fTElNSVQ7XG4gICAgICByZXR1cm4gdGFzay5pZDtcbiAgfVxuICBmdW5jdGlvbiBkZWNyZW1lbnRFeHBlY3RlZEF3YWl0cygpIHtcbiAgICAgIGlmICghdGFzay5hd2FpdHMpXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKC0tdGFzay5hd2FpdHMgPT09IDApXG4gICAgICAgICAgdGFzay5pZCA9IDA7XG4gICAgICB0YXNrLmVjaG9lcyA9IHRhc2suYXdhaXRzICogWk9ORV9FQ0hPX0xJTUlUO1xuICAgICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKCgnJyArIG5hdGl2ZVByb21pc2VUaGVuKS5pbmRleE9mKCdbbmF0aXZlIGNvZGVdJykgPT09IC0xKSB7XG4gICAgICBpbmNyZW1lbnRFeHBlY3RlZEF3YWl0cyA9IGRlY3JlbWVudEV4cGVjdGVkQXdhaXRzID0gbm9wO1xuICB9XG4gIGZ1bmN0aW9uIG9uUG9zc2libGVQYXJhbGxlbGxBc3luYyhwb3NzaWJsZVByb21pc2UpIHtcbiAgICAgIGlmICh0YXNrLmVjaG9lcyAmJlxuICAgICAgICAgIHBvc3NpYmxlUHJvbWlzZSAmJlxuICAgICAgICAgIHBvc3NpYmxlUHJvbWlzZS5jb25zdHJ1Y3RvciA9PT0gTmF0aXZlUHJvbWlzZSkge1xuICAgICAgICAgIGluY3JlbWVudEV4cGVjdGVkQXdhaXRzKCk7XG4gICAgICAgICAgcmV0dXJuIHBvc3NpYmxlUHJvbWlzZS50aGVuKGZ1bmN0aW9uICh4KSB7XG4gICAgICAgICAgICAgIGRlY3JlbWVudEV4cGVjdGVkQXdhaXRzKCk7XG4gICAgICAgICAgICAgIHJldHVybiB4O1xuICAgICAgICAgIH0sIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgIGRlY3JlbWVudEV4cGVjdGVkQXdhaXRzKCk7XG4gICAgICAgICAgICAgIHJldHVybiByZWplY3Rpb24oZSk7XG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcG9zc2libGVQcm9taXNlO1xuICB9XG4gIGZ1bmN0aW9uIHpvbmVFbnRlckVjaG8odGFyZ2V0Wm9uZSkge1xuICAgICAgKyt0b3RhbEVjaG9lcztcbiAgICAgIGlmICghdGFzay5lY2hvZXMgfHwgLS10YXNrLmVjaG9lcyA9PT0gMCkge1xuICAgICAgICAgIHRhc2suZWNob2VzID0gdGFzay5hd2FpdHMgPSB0YXNrLmlkID0gMDtcbiAgICAgIH1cbiAgICAgIHpvbmVTdGFjay5wdXNoKFBTRCk7XG4gICAgICBzd2l0Y2hUb1pvbmUodGFyZ2V0Wm9uZSwgdHJ1ZSk7XG4gIH1cbiAgZnVuY3Rpb24gem9uZUxlYXZlRWNobygpIHtcbiAgICAgIHZhciB6b25lID0gem9uZVN0YWNrW3pvbmVTdGFjay5sZW5ndGggLSAxXTtcbiAgICAgIHpvbmVTdGFjay5wb3AoKTtcbiAgICAgIHN3aXRjaFRvWm9uZSh6b25lLCBmYWxzZSk7XG4gIH1cbiAgZnVuY3Rpb24gc3dpdGNoVG9ab25lKHRhcmdldFpvbmUsIGJFbnRlcmluZ1pvbmUpIHtcbiAgICAgIHZhciBjdXJyZW50Wm9uZSA9IFBTRDtcbiAgICAgIGlmIChiRW50ZXJpbmdab25lXG4gICAgICAgICAgPyB0YXNrLmVjaG9lcyAmJiAoIXpvbmVFY2hvZXMrKyB8fCB0YXJnZXRab25lICE9PSBQU0QpXG4gICAgICAgICAgOiB6b25lRWNob2VzICYmICghLS16b25lRWNob2VzIHx8IHRhcmdldFpvbmUgIT09IFBTRCkpIHtcbiAgICAgICAgICBxdWV1ZU1pY3JvdGFzayhiRW50ZXJpbmdab25lID8gem9uZUVudGVyRWNoby5iaW5kKG51bGwsIHRhcmdldFpvbmUpIDogem9uZUxlYXZlRWNobyk7XG4gICAgICB9XG4gICAgICBpZiAodGFyZ2V0Wm9uZSA9PT0gUFNEKVxuICAgICAgICAgIHJldHVybjtcbiAgICAgIFBTRCA9IHRhcmdldFpvbmU7XG4gICAgICBpZiAoY3VycmVudFpvbmUgPT09IGdsb2JhbFBTRClcbiAgICAgICAgICBnbG9iYWxQU0QuZW52ID0gc25hcFNob3QoKTtcbiAgICAgIGlmIChwYXRjaEdsb2JhbFByb21pc2UpIHtcbiAgICAgICAgICB2YXIgR2xvYmFsUHJvbWlzZSA9IGdsb2JhbFBTRC5lbnYuUHJvbWlzZTtcbiAgICAgICAgICB2YXIgdGFyZ2V0RW52ID0gdGFyZ2V0Wm9uZS5lbnY7XG4gICAgICAgICAgaWYgKGN1cnJlbnRab25lLmdsb2JhbCB8fCB0YXJnZXRab25lLmdsb2JhbCkge1xuICAgICAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoX2dsb2JhbCwgJ1Byb21pc2UnLCB0YXJnZXRFbnYuUHJvbWlzZVByb3ApO1xuICAgICAgICAgICAgICBHbG9iYWxQcm9taXNlLmFsbCA9IHRhcmdldEVudi5hbGw7XG4gICAgICAgICAgICAgIEdsb2JhbFByb21pc2UucmFjZSA9IHRhcmdldEVudi5yYWNlO1xuICAgICAgICAgICAgICBHbG9iYWxQcm9taXNlLnJlc29sdmUgPSB0YXJnZXRFbnYucmVzb2x2ZTtcbiAgICAgICAgICAgICAgR2xvYmFsUHJvbWlzZS5yZWplY3QgPSB0YXJnZXRFbnYucmVqZWN0O1xuICAgICAgICAgICAgICBpZiAodGFyZ2V0RW52LmFsbFNldHRsZWQpXG4gICAgICAgICAgICAgICAgICBHbG9iYWxQcm9taXNlLmFsbFNldHRsZWQgPSB0YXJnZXRFbnYuYWxsU2V0dGxlZDtcbiAgICAgICAgICAgICAgaWYgKHRhcmdldEVudi5hbnkpXG4gICAgICAgICAgICAgICAgICBHbG9iYWxQcm9taXNlLmFueSA9IHRhcmdldEVudi5hbnk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG4gIGZ1bmN0aW9uIHNuYXBTaG90KCkge1xuICAgICAgdmFyIEdsb2JhbFByb21pc2UgPSBfZ2xvYmFsLlByb21pc2U7XG4gICAgICByZXR1cm4gcGF0Y2hHbG9iYWxQcm9taXNlXG4gICAgICAgICAgPyB7XG4gICAgICAgICAgICAgIFByb21pc2U6IEdsb2JhbFByb21pc2UsXG4gICAgICAgICAgICAgIFByb21pc2VQcm9wOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKF9nbG9iYWwsICdQcm9taXNlJyksXG4gICAgICAgICAgICAgIGFsbDogR2xvYmFsUHJvbWlzZS5hbGwsXG4gICAgICAgICAgICAgIHJhY2U6IEdsb2JhbFByb21pc2UucmFjZSxcbiAgICAgICAgICAgICAgYWxsU2V0dGxlZDogR2xvYmFsUHJvbWlzZS5hbGxTZXR0bGVkLFxuICAgICAgICAgICAgICBhbnk6IEdsb2JhbFByb21pc2UuYW55LFxuICAgICAgICAgICAgICByZXNvbHZlOiBHbG9iYWxQcm9taXNlLnJlc29sdmUsXG4gICAgICAgICAgICAgIHJlamVjdDogR2xvYmFsUHJvbWlzZS5yZWplY3QsXG4gICAgICAgICAgfVxuICAgICAgICAgIDoge307XG4gIH1cbiAgZnVuY3Rpb24gdXNlUFNEKHBzZCwgZm4sIGExLCBhMiwgYTMpIHtcbiAgICAgIHZhciBvdXRlclNjb3BlID0gUFNEO1xuICAgICAgdHJ5IHtcbiAgICAgICAgICBzd2l0Y2hUb1pvbmUocHNkLCB0cnVlKTtcbiAgICAgICAgICByZXR1cm4gZm4oYTEsIGEyLCBhMyk7XG4gICAgICB9XG4gICAgICBmaW5hbGx5IHtcbiAgICAgICAgICBzd2l0Y2hUb1pvbmUob3V0ZXJTY29wZSwgZmFsc2UpO1xuICAgICAgfVxuICB9XG4gIGZ1bmN0aW9uIG5hdGl2ZUF3YWl0Q29tcGF0aWJsZVdyYXAoZm4sIHpvbmUsIHBvc3NpYmxlQXdhaXQsIGNsZWFudXApIHtcbiAgICAgIHJldHVybiB0eXBlb2YgZm4gIT09ICdmdW5jdGlvbidcbiAgICAgICAgICA/IGZuXG4gICAgICAgICAgOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHZhciBvdXRlclpvbmUgPSBQU0Q7XG4gICAgICAgICAgICAgIGlmIChwb3NzaWJsZUF3YWl0KVxuICAgICAgICAgICAgICAgICAgaW5jcmVtZW50RXhwZWN0ZWRBd2FpdHMoKTtcbiAgICAgICAgICAgICAgc3dpdGNoVG9ab25lKHpvbmUsIHRydWUpO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGZuLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICBzd2l0Y2hUb1pvbmUob3V0ZXJab25lLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgICBpZiAoY2xlYW51cClcbiAgICAgICAgICAgICAgICAgICAgICBxdWV1ZU1pY3JvdGFzayhkZWNyZW1lbnRFeHBlY3RlZEF3YWl0cyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIGV4ZWNJbkdsb2JhbENvbnRleHQoY2IpIHtcbiAgICAgIGlmIChQcm9taXNlID09PSBOYXRpdmVQcm9taXNlICYmIHRhc2suZWNob2VzID09PSAwKSB7XG4gICAgICAgICAgaWYgKHpvbmVFY2hvZXMgPT09IDApIHtcbiAgICAgICAgICAgICAgY2IoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgIGVucXVldWVOYXRpdmVNaWNyb1Rhc2soY2IpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAgIHNldFRpbWVvdXQoY2IsIDApO1xuICAgICAgfVxuICB9XG4gIHZhciByZWplY3Rpb24gPSBEZXhpZVByb21pc2UucmVqZWN0O1xuXG4gIGZ1bmN0aW9uIHRlbXBUcmFuc2FjdGlvbihkYiwgbW9kZSwgc3RvcmVOYW1lcywgZm4pIHtcbiAgICAgIGlmICghZGIuaWRiZGIgfHwgKCFkYi5fc3RhdGUub3BlbkNvbXBsZXRlICYmICFQU0QubGV0VGhyb3VnaCAmJiAhZGIuX3ZpcCkpIHtcbiAgICAgICAgICBpZiAoZGIuX3N0YXRlLm9wZW5Db21wbGV0ZSkge1xuICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0aW9uKG5ldyBleGNlcHRpb25zLkRhdGFiYXNlQ2xvc2VkKGRiLl9zdGF0ZS5kYk9wZW5FcnJvcikpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIWRiLl9zdGF0ZS5pc0JlaW5nT3BlbmVkKSB7XG4gICAgICAgICAgICAgIGlmICghZGIuX3N0YXRlLmF1dG9PcGVuKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdGlvbihuZXcgZXhjZXB0aW9ucy5EYXRhYmFzZUNsb3NlZCgpKTtcbiAgICAgICAgICAgICAgZGIub3BlbigpLmNhdGNoKG5vcCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBkYi5fc3RhdGUuZGJSZWFkeVByb21pc2UudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiB0ZW1wVHJhbnNhY3Rpb24oZGIsIG1vZGUsIHN0b3JlTmFtZXMsIGZuKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAgIHZhciB0cmFucyA9IGRiLl9jcmVhdGVUcmFuc2FjdGlvbihtb2RlLCBzdG9yZU5hbWVzLCBkYi5fZGJTY2hlbWEpO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHRyYW5zLmNyZWF0ZSgpO1xuICAgICAgICAgICAgICBkYi5fc3RhdGUuUFIxMzk4X21heExvb3AgPSAzO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgICAgaWYgKGV4Lm5hbWUgPT09IGVycm5hbWVzLkludmFsaWRTdGF0ZSAmJlxuICAgICAgICAgICAgICAgICAgZGIuaXNPcGVuKCkgJiZcbiAgICAgICAgICAgICAgICAgIC0tZGIuX3N0YXRlLlBSMTM5OF9tYXhMb29wID4gMCkge1xuICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdEZXhpZTogTmVlZCB0byByZW9wZW4gZGInKTtcbiAgICAgICAgICAgICAgICAgIGRiLmNsb3NlKHsgZGlzYWJsZUF1dG9PcGVuOiBmYWxzZSB9KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkYi5vcGVuKCkudGhlbihmdW5jdGlvbiAoKSB7IHJldHVybiB0ZW1wVHJhbnNhY3Rpb24oZGIsIG1vZGUsIHN0b3JlTmFtZXMsIGZuKTsgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdGlvbihleCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB0cmFuc1xuICAgICAgICAgICAgICAuX3Byb21pc2UobW9kZSwgZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3U2NvcGUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgUFNELnRyYW5zID0gdHJhbnM7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZm4ocmVzb2x2ZSwgcmVqZWN0LCB0cmFucyk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgaWYgKG1vZGUgPT09ICdyZWFkd3JpdGUnKVxuICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICB0cmFucy5pZGJ0cmFucy5jb21taXQoKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGNhdGNoIChfYSkgeyB9XG4gICAgICAgICAgICAgIHJldHVybiBtb2RlID09PSAncmVhZG9ubHknXG4gICAgICAgICAgICAgICAgICA/IHJlc3VsdFxuICAgICAgICAgICAgICAgICAgOiB0cmFucy5fY29tcGxldGlvbi50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHJlc3VsdDsgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gIH1cblxuICB2YXIgREVYSUVfVkVSU0lPTiA9ICc0LjQuNSc7XG4gIHZhciBtYXhTdHJpbmcgPSBTdHJpbmcuZnJvbUNoYXJDb2RlKDY1NTM1KTtcbiAgdmFyIG1pbktleSA9IC1JbmZpbml0eTtcbiAgdmFyIElOVkFMSURfS0VZX0FSR1VNRU5UID0gJ0ludmFsaWQga2V5IHByb3ZpZGVkLiBLZXlzIG11c3QgYmUgb2YgdHlwZSBzdHJpbmcsIG51bWJlciwgRGF0ZSBvciBBcnJheTxzdHJpbmcgfCBudW1iZXIgfCBEYXRlPi4nO1xuICB2YXIgU1RSSU5HX0VYUEVDVEVEID0gJ1N0cmluZyBleHBlY3RlZC4nO1xuICB2YXIgREVGQVVMVF9NQVhfQ09OTkVDVElPTlMgPSAxMDAwO1xuICB2YXIgREJOQU1FU19EQiA9ICdfX2RibmFtZXMnO1xuICB2YXIgUkVBRE9OTFkgPSAncmVhZG9ubHknO1xuICB2YXIgUkVBRFdSSVRFID0gJ3JlYWR3cml0ZSc7XG5cbiAgZnVuY3Rpb24gY29tYmluZShmaWx0ZXIxLCBmaWx0ZXIyKSB7XG4gICAgICByZXR1cm4gZmlsdGVyMVxuICAgICAgICAgID8gZmlsdGVyMlxuICAgICAgICAgICAgICA/IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoZmlsdGVyMS5hcHBseSh0aGlzLCBhcmd1bWVudHMpICYmIGZpbHRlcjIuYXBwbHkodGhpcywgYXJndW1lbnRzKSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgOiBmaWx0ZXIxXG4gICAgICAgICAgOiBmaWx0ZXIyO1xuICB9XG5cbiAgdmFyIEFueVJhbmdlID0ge1xuICAgICAgdHlwZTogMyAsXG4gICAgICBsb3dlcjogLUluZmluaXR5LFxuICAgICAgbG93ZXJPcGVuOiBmYWxzZSxcbiAgICAgIHVwcGVyOiBbW11dLFxuICAgICAgdXBwZXJPcGVuOiBmYWxzZSxcbiAgfTtcblxuICBmdW5jdGlvbiB3b3JrYXJvdW5kRm9yVW5kZWZpbmVkUHJpbUtleShrZXlQYXRoKSB7XG4gICAgICByZXR1cm4gdHlwZW9mIGtleVBhdGggPT09ICdzdHJpbmcnICYmICEvXFwuLy50ZXN0KGtleVBhdGgpXG4gICAgICAgICAgPyBmdW5jdGlvbiAob2JqKSB7XG4gICAgICAgICAgICAgIGlmIChvYmpba2V5UGF0aF0gPT09IHVuZGVmaW5lZCAmJiBrZXlQYXRoIGluIG9iaikge1xuICAgICAgICAgICAgICAgICAgb2JqID0gZGVlcENsb25lKG9iaik7XG4gICAgICAgICAgICAgICAgICBkZWxldGUgb2JqW2tleVBhdGhdO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBvYmo7XG4gICAgICAgICAgfVxuICAgICAgICAgIDogZnVuY3Rpb24gKG9iaikgeyByZXR1cm4gb2JqOyB9O1xuICB9XG5cbiAgZnVuY3Rpb24gRW50aXR5KCkge1xuICAgICAgdGhyb3cgZXhjZXB0aW9ucy5UeXBlKFwiRW50aXR5IGluc3RhbmNlcyBtdXN0IG5ldmVyIGJlIG5ldzplZC4gSW5zdGFuY2VzIGFyZSBnZW5lcmF0ZWQgYnkgdGhlIGZyYW1ld29yayBieXBhc3NpbmcgdGhlIGNvbnN0cnVjdG9yLlwiKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNtcChhLCBiKSB7XG4gICAgICB0cnkge1xuICAgICAgICAgIHZhciB0YSA9IHR5cGUoYSk7XG4gICAgICAgICAgdmFyIHRiID0gdHlwZShiKTtcbiAgICAgICAgICBpZiAodGEgIT09IHRiKSB7XG4gICAgICAgICAgICAgIGlmICh0YSA9PT0gJ0FycmF5JylcbiAgICAgICAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICAgICAgICBpZiAodGIgPT09ICdBcnJheScpXG4gICAgICAgICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgICAgICAgIGlmICh0YSA9PT0gJ2JpbmFyeScpXG4gICAgICAgICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgICAgICAgaWYgKHRiID09PSAnYmluYXJ5JylcbiAgICAgICAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgICAgICAgaWYgKHRhID09PSAnc3RyaW5nJylcbiAgICAgICAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICAgICAgICBpZiAodGIgPT09ICdzdHJpbmcnKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICAgICAgICBpZiAodGEgPT09ICdEYXRlJylcbiAgICAgICAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICAgICAgICBpZiAodGIgIT09ICdEYXRlJylcbiAgICAgICAgICAgICAgICAgIHJldHVybiBOYU47XG4gICAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgICB9XG4gICAgICAgICAgc3dpdGNoICh0YSkge1xuICAgICAgICAgICAgICBjYXNlICdudW1iZXInOlxuICAgICAgICAgICAgICBjYXNlICdEYXRlJzpcbiAgICAgICAgICAgICAgY2FzZSAnc3RyaW5nJzpcbiAgICAgICAgICAgICAgICAgIHJldHVybiBhID4gYiA/IDEgOiBhIDwgYiA/IC0xIDogMDtcbiAgICAgICAgICAgICAgY2FzZSAnYmluYXJ5Jzoge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbXBhcmVVaW50OEFycmF5cyhnZXRVaW50OEFycmF5KGEpLCBnZXRVaW50OEFycmF5KGIpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjYXNlICdBcnJheSc6XG4gICAgICAgICAgICAgICAgICByZXR1cm4gY29tcGFyZUFycmF5cyhhLCBiKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICBjYXRjaCAoX2EpIHsgfVxuICAgICAgcmV0dXJuIE5hTjtcbiAgfVxuICBmdW5jdGlvbiBjb21wYXJlQXJyYXlzKGEsIGIpIHtcbiAgICAgIHZhciBhbCA9IGEubGVuZ3RoO1xuICAgICAgdmFyIGJsID0gYi5sZW5ndGg7XG4gICAgICB2YXIgbCA9IGFsIDwgYmwgPyBhbCA6IGJsO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsOyArK2kpIHtcbiAgICAgICAgICB2YXIgcmVzID0gY21wKGFbaV0sIGJbaV0pO1xuICAgICAgICAgIGlmIChyZXMgIT09IDApXG4gICAgICAgICAgICAgIHJldHVybiByZXM7XG4gICAgICB9XG4gICAgICByZXR1cm4gYWwgPT09IGJsID8gMCA6IGFsIDwgYmwgPyAtMSA6IDE7XG4gIH1cbiAgZnVuY3Rpb24gY29tcGFyZVVpbnQ4QXJyYXlzKGEsIGIpIHtcbiAgICAgIHZhciBhbCA9IGEubGVuZ3RoO1xuICAgICAgdmFyIGJsID0gYi5sZW5ndGg7XG4gICAgICB2YXIgbCA9IGFsIDwgYmwgPyBhbCA6IGJsO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsOyArK2kpIHtcbiAgICAgICAgICBpZiAoYVtpXSAhPT0gYltpXSlcbiAgICAgICAgICAgICAgcmV0dXJuIGFbaV0gPCBiW2ldID8gLTEgOiAxO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGFsID09PSBibCA/IDAgOiBhbCA8IGJsID8gLTEgOiAxO1xuICB9XG4gIGZ1bmN0aW9uIHR5cGUoeCkge1xuICAgICAgdmFyIHQgPSB0eXBlb2YgeDtcbiAgICAgIGlmICh0ICE9PSAnb2JqZWN0JylcbiAgICAgICAgICByZXR1cm4gdDtcbiAgICAgIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcoeCkpXG4gICAgICAgICAgcmV0dXJuICdiaW5hcnknO1xuICAgICAgdmFyIHRzVGFnID0gdG9TdHJpbmdUYWcoeCk7XG4gICAgICByZXR1cm4gdHNUYWcgPT09ICdBcnJheUJ1ZmZlcicgPyAnYmluYXJ5JyA6IHRzVGFnO1xuICB9XG4gIGZ1bmN0aW9uIGdldFVpbnQ4QXJyYXkoYSkge1xuICAgICAgaWYgKGEgaW5zdGFuY2VvZiBVaW50OEFycmF5KVxuICAgICAgICAgIHJldHVybiBhO1xuICAgICAgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhhKSlcbiAgICAgICAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoYS5idWZmZXIsIGEuYnl0ZU9mZnNldCwgYS5ieXRlTGVuZ3RoKTtcbiAgICAgIHJldHVybiBuZXcgVWludDhBcnJheShhKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGJ1aWx0SW5EZWxldGlvblRyaWdnZXIodGFibGUsIGtleXMsIHJlcykge1xuICAgICAgdmFyIHlQcm9wcyA9IHRhYmxlLnNjaGVtYS55UHJvcHM7XG4gICAgICBpZiAoIXlQcm9wcylcbiAgICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgaWYgKGtleXMgJiYgcmVzLm51bUZhaWx1cmVzID4gMClcbiAgICAgICAgICBrZXlzID0ga2V5cy5maWx0ZXIoZnVuY3Rpb24gKF8sIGkpIHsgcmV0dXJuICFyZXMuZmFpbHVyZXNbaV07IH0pO1xuICAgICAgcmV0dXJuIFByb21pc2UuYWxsKHlQcm9wcy5tYXAoZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgdmFyIHVwZGF0ZXNUYWJsZSA9IF9hLnVwZGF0ZXNUYWJsZTtcbiAgICAgICAgICByZXR1cm4ga2V5c1xuICAgICAgICAgICAgICA/IHRhYmxlLmRiLnRhYmxlKHVwZGF0ZXNUYWJsZSkud2hlcmUoJ2snKS5hbnlPZihrZXlzKS5kZWxldGUoKVxuICAgICAgICAgICAgICA6IHRhYmxlLmRiLnRhYmxlKHVwZGF0ZXNUYWJsZSkuY2xlYXIoKTtcbiAgICAgIH0pKS50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHJlczsgfSk7XG4gIH1cblxuICB2YXIgUHJvcE1vZGlmaWNhdGlvbiA9ICAoZnVuY3Rpb24gKCkge1xuICAgICAgZnVuY3Rpb24gUHJvcE1vZGlmaWNhdGlvbihzcGVjKSB7XG4gICAgICAgICAgdGhpc1snQEBwcm9wbW9kJ10gPSBzcGVjO1xuICAgICAgfVxuICAgICAgUHJvcE1vZGlmaWNhdGlvbi5wcm90b3R5cGUuZXhlY3V0ZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICB2YXIgc3BlYyA9IHRoaXNbJ0BAcHJvcG1vZCddO1xuICAgICAgICAgIGlmIChzcGVjLmFkZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgIHZhciB0ZXJtID0gc3BlYy5hZGQ7XG4gICAgICAgICAgICAgIGlmIChpc0FycmF5KHRlcm0pKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX19zcHJlYWRBcnJheShfX3NwcmVhZEFycmF5KFtdLCAoaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZSA6IFtdKSwgdHJ1ZSksIHRlcm0sIHRydWUpLnNvcnQoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAodHlwZW9mIHRlcm0gPT09ICdudW1iZXInKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChOdW1iZXIodmFsdWUpIHx8IDApICsgdGVybTtcbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0ZXJtID09PSAnYmlnaW50Jykge1xuICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmlnSW50KHZhbHVlKSArIHRlcm07XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjYXRjaCAoX2IpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmlnSW50KDApICsgdGVybTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiSW52YWxpZCB0ZXJtIFwiLmNvbmNhdCh0ZXJtKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChzcGVjLnJlbW92ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgIHZhciBzdWJ0cmFoZW5kXzEgPSBzcGVjLnJlbW92ZTtcbiAgICAgICAgICAgICAgaWYgKGlzQXJyYXkoc3VidHJhaGVuZF8xKSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGlzQXJyYXkodmFsdWUpXG4gICAgICAgICAgICAgICAgICAgICAgPyB2YWx1ZS5maWx0ZXIoZnVuY3Rpb24gKGl0ZW0pIHsgcmV0dXJuICFzdWJ0cmFoZW5kXzEuaW5jbHVkZXMoaXRlbSk7IH0pLnNvcnQoKVxuICAgICAgICAgICAgICAgICAgICAgIDogW107XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiBzdWJ0cmFoZW5kXzEgPT09ICdudW1iZXInKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSkgLSBzdWJ0cmFoZW5kXzE7XG4gICAgICAgICAgICAgIGlmICh0eXBlb2Ygc3VidHJhaGVuZF8xID09PSAnYmlnaW50Jykge1xuICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmlnSW50KHZhbHVlKSAtIHN1YnRyYWhlbmRfMTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGNhdGNoIChfYykge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBCaWdJbnQoMCkgLSBzdWJ0cmFoZW5kXzE7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkludmFsaWQgc3VidHJhaGVuZCBcIi5jb25jYXQoc3VidHJhaGVuZF8xKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhciBwcmVmaXhUb1JlcGxhY2UgPSAoX2EgPSBzcGVjLnJlcGxhY2VQcmVmaXgpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYVswXTtcbiAgICAgICAgICBpZiAocHJlZml4VG9SZXBsYWNlICYmXG4gICAgICAgICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiZcbiAgICAgICAgICAgICAgdmFsdWUuc3RhcnRzV2l0aChwcmVmaXhUb1JlcGxhY2UpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBzcGVjLnJlcGxhY2VQcmVmaXhbMV0gKyB2YWx1ZS5zdWJzdHJpbmcocHJlZml4VG9SZXBsYWNlLmxlbmd0aCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH07XG4gICAgICByZXR1cm4gUHJvcE1vZGlmaWNhdGlvbjtcbiAgfSgpKTtcblxuICBmdW5jdGlvbiBhcHBseVVwZGF0ZVNwZWMob2JqLCBjaGFuZ2VzKSB7XG4gICAgICB2YXIga2V5UGF0aHMgPSBrZXlzKGNoYW5nZXMpO1xuICAgICAgdmFyIG51bUtleXMgPSBrZXlQYXRocy5sZW5ndGg7XG4gICAgICB2YXIgYW55dGhpbmdNb2RpZmllZCA9IGZhbHNlO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBudW1LZXlzOyArK2kpIHtcbiAgICAgICAgICB2YXIga2V5UGF0aCA9IGtleVBhdGhzW2ldO1xuICAgICAgICAgIHZhciB2YWx1ZSA9IGNoYW5nZXNba2V5UGF0aF07XG4gICAgICAgICAgdmFyIG9yaWdWYWx1ZSA9IGdldEJ5S2V5UGF0aChvYmosIGtleVBhdGgpO1xuICAgICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIFByb3BNb2RpZmljYXRpb24pIHtcbiAgICAgICAgICAgICAgc2V0QnlLZXlQYXRoKG9iaiwga2V5UGF0aCwgdmFsdWUuZXhlY3V0ZShvcmlnVmFsdWUpKTtcbiAgICAgICAgICAgICAgYW55dGhpbmdNb2RpZmllZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2UgaWYgKG9yaWdWYWx1ZSAhPT0gdmFsdWUpIHtcbiAgICAgICAgICAgICAgc2V0QnlLZXlQYXRoKG9iaiwga2V5UGF0aCwgdmFsdWUpO1xuICAgICAgICAgICAgICBhbnl0aGluZ01vZGlmaWVkID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gYW55dGhpbmdNb2RpZmllZDtcbiAgfVxuXG4gIHZhciBUYWJsZSA9ICAoZnVuY3Rpb24gKCkge1xuICAgICAgZnVuY3Rpb24gVGFibGUoKSB7XG4gICAgICB9XG4gICAgICBUYWJsZS5wcm90b3R5cGUuX3RyYW5zID0gZnVuY3Rpb24gKG1vZGUsIGZuLCB3cml0ZUxvY2tlZCkge1xuICAgICAgICAgIHZhciB0cmFucyA9IHRoaXMuX3R4IHx8IFBTRC50cmFucztcbiAgICAgICAgICB2YXIgdGFibGVOYW1lID0gdGhpcy5uYW1lO1xuICAgICAgICAgIHZhciB0YXNrID0gZGVidWcgJiZcbiAgICAgICAgICAgICAgdHlwZW9mIGNvbnNvbGUgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICAgICAgICAgIGNvbnNvbGUuY3JlYXRlVGFzayAmJlxuICAgICAgICAgICAgICBjb25zb2xlLmNyZWF0ZVRhc2soXCJEZXhpZTogXCIuY29uY2F0KG1vZGUgPT09ICdyZWFkb25seScgPyAncmVhZCcgOiAnd3JpdGUnLCBcIiBcIikuY29uY2F0KHRoaXMubmFtZSkpO1xuICAgICAgICAgIGZ1bmN0aW9uIGNoZWNrVGFibGVJblRyYW5zYWN0aW9uKHJlc29sdmUsIHJlamVjdCwgdHJhbnMpIHtcbiAgICAgICAgICAgICAgaWYgKCF0cmFucy5zY2hlbWFbdGFibGVOYW1lXSlcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLk5vdEZvdW5kKCdUYWJsZSAnICsgdGFibGVOYW1lICsgJyBub3QgcGFydCBvZiB0cmFuc2FjdGlvbicpO1xuICAgICAgICAgICAgICByZXR1cm4gZm4odHJhbnMuaWRidHJhbnMsIHRyYW5zKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIHdhc1Jvb3RFeGVjID0gYmVnaW5NaWNyb1RpY2tTY29wZSgpO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHZhciBwID0gdHJhbnMgJiYgdHJhbnMuZGIuX25vdmlwID09PSB0aGlzLmRiLl9ub3ZpcFxuICAgICAgICAgICAgICAgICAgPyB0cmFucyA9PT0gUFNELnRyYW5zXG4gICAgICAgICAgICAgICAgICAgICAgPyB0cmFucy5fcHJvbWlzZShtb2RlLCBjaGVja1RhYmxlSW5UcmFuc2FjdGlvbiwgd3JpdGVMb2NrZWQpXG4gICAgICAgICAgICAgICAgICAgICAgOiBuZXdTY29wZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0cmFucy5fcHJvbWlzZShtb2RlLCBjaGVja1RhYmxlSW5UcmFuc2FjdGlvbiwgd3JpdGVMb2NrZWQpO1xuICAgICAgICAgICAgICAgICAgICAgIH0sIHsgdHJhbnM6IHRyYW5zLCB0cmFuc2xlc3M6IFBTRC50cmFuc2xlc3MgfHwgUFNEIH0pXG4gICAgICAgICAgICAgICAgICA6IHRlbXBUcmFuc2FjdGlvbih0aGlzLmRiLCBtb2RlLCBbdGhpcy5uYW1lXSwgY2hlY2tUYWJsZUluVHJhbnNhY3Rpb24pO1xuICAgICAgICAgICAgICBpZiAodGFzaykge1xuICAgICAgICAgICAgICAgICAgcC5fY29uc29sZVRhc2sgPSB0YXNrO1xuICAgICAgICAgICAgICAgICAgcCA9IHAuY2F0Y2goZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUudHJhY2UoZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0aW9uKGVycik7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gcDtcbiAgICAgICAgICB9XG4gICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgIGlmICh3YXNSb290RXhlYylcbiAgICAgICAgICAgICAgICAgIGVuZE1pY3JvVGlja1Njb3BlKCk7XG4gICAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoa2V5T3JDcml0LCBjYikge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgaWYgKGtleU9yQ3JpdCAmJiBrZXlPckNyaXQuY29uc3RydWN0b3IgPT09IE9iamVjdClcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud2hlcmUoa2V5T3JDcml0KS5maXJzdChjYik7XG4gICAgICAgICAgaWYgKGtleU9yQ3JpdCA9PSBudWxsKVxuICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0aW9uKG5ldyBleGNlcHRpb25zLlR5cGUoXCJJbnZhbGlkIGFyZ3VtZW50IHRvIFRhYmxlLmdldCgpXCIpKTtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnMoJ3JlYWRvbmx5JywgZnVuY3Rpb24gKHRyYW5zKSB7XG4gICAgICAgICAgICAgIHJldHVybiBfdGhpcy5jb3JlXG4gICAgICAgICAgICAgICAgICAuZ2V0KHsgdHJhbnM6IHRyYW5zLCBrZXk6IGtleU9yQ3JpdCB9KVxuICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlcykgeyByZXR1cm4gX3RoaXMuaG9vay5yZWFkaW5nLmZpcmUocmVzKTsgfSk7XG4gICAgICAgICAgfSkudGhlbihjYik7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLndoZXJlID0gZnVuY3Rpb24gKGluZGV4T3JDcml0KSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBpbmRleE9yQ3JpdCA9PT0gJ3N0cmluZycpXG4gICAgICAgICAgICAgIHJldHVybiBuZXcgdGhpcy5kYi5XaGVyZUNsYXVzZSh0aGlzLCBpbmRleE9yQ3JpdCk7XG4gICAgICAgICAgaWYgKGlzQXJyYXkoaW5kZXhPckNyaXQpKVxuICAgICAgICAgICAgICByZXR1cm4gbmV3IHRoaXMuZGIuV2hlcmVDbGF1c2UodGhpcywgXCJbXCIuY29uY2F0KGluZGV4T3JDcml0LmpvaW4oJysnKSwgXCJdXCIpKTtcbiAgICAgICAgICB2YXIga2V5UGF0aHMgPSBrZXlzKGluZGV4T3JDcml0KTtcbiAgICAgICAgICBpZiAoa2V5UGF0aHMubGVuZ3RoID09PSAxKVxuICAgICAgICAgICAgICByZXR1cm4gdGhpcy53aGVyZShrZXlQYXRoc1swXSkuZXF1YWxzKGluZGV4T3JDcml0W2tleVBhdGhzWzBdXSk7XG4gICAgICAgICAgdmFyIGNvbXBvdW5kSW5kZXggPSB0aGlzLnNjaGVtYS5pbmRleGVzXG4gICAgICAgICAgICAgIC5jb25jYXQodGhpcy5zY2hlbWEucHJpbUtleSlcbiAgICAgICAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoaXgpIHtcbiAgICAgICAgICAgICAgaWYgKGl4LmNvbXBvdW5kICYmXG4gICAgICAgICAgICAgICAgICBrZXlQYXRocy5ldmVyeShmdW5jdGlvbiAoa2V5UGF0aCkgeyByZXR1cm4gaXgua2V5UGF0aC5pbmRleE9mKGtleVBhdGgpID49IDA7IH0pKSB7XG4gICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGtleVBhdGhzLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGtleVBhdGhzLmluZGV4T2YoaXgua2V5UGF0aFtpXSkgPT09IC0xKVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnNvcnQoZnVuY3Rpb24gKGEsIGIpIHsgcmV0dXJuIGEua2V5UGF0aC5sZW5ndGggLSBiLmtleVBhdGgubGVuZ3RoOyB9KVswXTtcbiAgICAgICAgICBpZiAoY29tcG91bmRJbmRleCAmJiB0aGlzLmRiLl9tYXhLZXkgIT09IG1heFN0cmluZykge1xuICAgICAgICAgICAgICB2YXIga2V5UGF0aHNJblZhbGlkT3JkZXIgPSBjb21wb3VuZEluZGV4LmtleVBhdGguc2xpY2UoMCwga2V5UGF0aHMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud2hlcmUoa2V5UGF0aHNJblZhbGlkT3JkZXIpLmVxdWFscyhrZXlQYXRoc0luVmFsaWRPcmRlci5tYXAoZnVuY3Rpb24gKGtwKSB7IHJldHVybiBpbmRleE9yQ3JpdFtrcF07IH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFjb21wb3VuZEluZGV4ICYmIGRlYnVnKVxuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJUaGUgcXVlcnkgXCIuY29uY2F0KEpTT04uc3RyaW5naWZ5KGluZGV4T3JDcml0KSwgXCIgb24gXCIpLmNvbmNhdCh0aGlzLm5hbWUsIFwiIHdvdWxkIGJlbmVmaXQgZnJvbSBhIFwiKSArXG4gICAgICAgICAgICAgICAgICBcImNvbXBvdW5kIGluZGV4IFtcIi5jb25jYXQoa2V5UGF0aHMuam9pbignKycpLCBcIl1cIikpO1xuICAgICAgICAgIHZhciBpZHhCeU5hbWUgPSB0aGlzLnNjaGVtYS5pZHhCeU5hbWU7XG4gICAgICAgICAgZnVuY3Rpb24gZXF1YWxzKGEsIGIpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNtcChhLCBiKSA9PT0gMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIF9hID0ga2V5UGF0aHMucmVkdWNlKGZ1bmN0aW9uIChfYSwga2V5UGF0aCkge1xuICAgICAgICAgICAgICB2YXIgcHJldkluZGV4ID0gX2FbMF0sIHByZXZGaWx0ZXJGbiA9IF9hWzFdO1xuICAgICAgICAgICAgICB2YXIgaW5kZXggPSBpZHhCeU5hbWVba2V5UGF0aF07XG4gICAgICAgICAgICAgIHZhciB2YWx1ZSA9IGluZGV4T3JDcml0W2tleVBhdGhdO1xuICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgICAgcHJldkluZGV4IHx8IGluZGV4LFxuICAgICAgICAgICAgICAgICAgcHJldkluZGV4IHx8ICFpbmRleFxuICAgICAgICAgICAgICAgICAgICAgID8gY29tYmluZShwcmV2RmlsdGVyRm4sIGluZGV4ICYmIGluZGV4Lm11bHRpXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwcm9wID0gZ2V0QnlLZXlQYXRoKHgsIGtleVBhdGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChpc0FycmF5KHByb3ApICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcC5zb21lKGZ1bmN0aW9uIChpdGVtKSB7IHJldHVybiBlcXVhbHModmFsdWUsIGl0ZW0pOyB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBmdW5jdGlvbiAoeCkgeyByZXR1cm4gZXF1YWxzKHZhbHVlLCBnZXRCeUtleVBhdGgoeCwga2V5UGF0aCkpOyB9KVxuICAgICAgICAgICAgICAgICAgICAgIDogcHJldkZpbHRlckZuLFxuICAgICAgICAgICAgICBdO1xuICAgICAgICAgIH0sIFtudWxsLCBudWxsXSksIGlkeCA9IF9hWzBdLCBmaWx0ZXJGdW5jdGlvbiA9IF9hWzFdO1xuICAgICAgICAgIHJldHVybiBpZHhcbiAgICAgICAgICAgICAgPyB0aGlzLndoZXJlKGlkeC5uYW1lKVxuICAgICAgICAgICAgICAgICAgLmVxdWFscyhpbmRleE9yQ3JpdFtpZHgua2V5UGF0aF0pXG4gICAgICAgICAgICAgICAgICAuZmlsdGVyKGZpbHRlckZ1bmN0aW9uKVxuICAgICAgICAgICAgICA6IGNvbXBvdW5kSW5kZXhcbiAgICAgICAgICAgICAgICAgID8gdGhpcy5maWx0ZXIoZmlsdGVyRnVuY3Rpb24pXG4gICAgICAgICAgICAgICAgICA6IHRoaXMud2hlcmUoa2V5UGF0aHMpLmVxdWFscygnJyk7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLmZpbHRlciA9IGZ1bmN0aW9uIChmaWx0ZXJGdW5jdGlvbikge1xuICAgICAgICAgIHJldHVybiB0aGlzLnRvQ29sbGVjdGlvbigpLmFuZChmaWx0ZXJGdW5jdGlvbik7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLmNvdW50ID0gZnVuY3Rpb24gKHRoZW5TaG9ydGN1dCkge1xuICAgICAgICAgIHJldHVybiB0aGlzLnRvQ29sbGVjdGlvbigpLmNvdW50KHRoZW5TaG9ydGN1dCk7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLm9mZnNldCA9IGZ1bmN0aW9uIChvZmZzZXQpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy50b0NvbGxlY3Rpb24oKS5vZmZzZXQob2Zmc2V0KTtcbiAgICAgIH07XG4gICAgICBUYWJsZS5wcm90b3R5cGUubGltaXQgPSBmdW5jdGlvbiAobnVtUm93cykge1xuICAgICAgICAgIHJldHVybiB0aGlzLnRvQ29sbGVjdGlvbigpLmxpbWl0KG51bVJvd3MpO1xuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS5lYWNoID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMudG9Db2xsZWN0aW9uKCkuZWFjaChjYWxsYmFjayk7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLnRvQXJyYXkgPSBmdW5jdGlvbiAodGhlblNob3J0Y3V0KSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMudG9Db2xsZWN0aW9uKCkudG9BcnJheSh0aGVuU2hvcnRjdXQpO1xuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS50b0NvbGxlY3Rpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyB0aGlzLmRiLkNvbGxlY3Rpb24obmV3IHRoaXMuZGIuV2hlcmVDbGF1c2UodGhpcykpO1xuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS5vcmRlckJ5ID0gZnVuY3Rpb24gKGluZGV4KSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyB0aGlzLmRiLkNvbGxlY3Rpb24obmV3IHRoaXMuZGIuV2hlcmVDbGF1c2UodGhpcywgaXNBcnJheShpbmRleCkgPyBcIltcIi5jb25jYXQoaW5kZXguam9pbignKycpLCBcIl1cIikgOiBpbmRleCkpO1xuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS5yZXZlcnNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiB0aGlzLnRvQ29sbGVjdGlvbigpLnJldmVyc2UoKTtcbiAgICAgIH07XG4gICAgICBUYWJsZS5wcm90b3R5cGUubWFwVG9DbGFzcyA9IGZ1bmN0aW9uIChjb25zdHJ1Y3Rvcikge1xuICAgICAgICAgIHZhciBfYSA9IHRoaXMsIGRiID0gX2EuZGIsIHRhYmxlTmFtZSA9IF9hLm5hbWU7XG4gICAgICAgICAgdGhpcy5zY2hlbWEubWFwcGVkQ2xhc3MgPSBjb25zdHJ1Y3RvcjtcbiAgICAgICAgICBpZiAoY29uc3RydWN0b3IucHJvdG90eXBlIGluc3RhbmNlb2YgRW50aXR5KSB7XG4gICAgICAgICAgICAgIGNvbnN0cnVjdG9yID0gIChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgICAgICAgICAgICAgICBfX2V4dGVuZHMoY2xhc3NfMSwgX3N1cGVyKTtcbiAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGNsYXNzXzEoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9zdXBlciAhPT0gbnVsbCAmJiBfc3VwZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKSB8fCB0aGlzO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNsYXNzXzEucHJvdG90eXBlLCBcImRiXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRiO1xuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIGNsYXNzXzEucHJvdG90eXBlLnRhYmxlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0YWJsZU5hbWU7XG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNsYXNzXzE7XG4gICAgICAgICAgICAgIH0oY29uc3RydWN0b3IpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIGluaGVyaXRlZFByb3BzID0gbmV3IFNldCgpO1xuICAgICAgICAgIGZvciAodmFyIHByb3RvID0gY29uc3RydWN0b3IucHJvdG90eXBlOyBwcm90bzsgcHJvdG8gPSBnZXRQcm90byhwcm90bykpIHtcbiAgICAgICAgICAgICAgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMocHJvdG8pLmZvckVhY2goZnVuY3Rpb24gKHByb3BOYW1lKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gaW5oZXJpdGVkUHJvcHMuYWRkKHByb3BOYW1lKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhciByZWFkSG9vayA9IGZ1bmN0aW9uIChvYmopIHtcbiAgICAgICAgICAgICAgaWYgKCFvYmopXG4gICAgICAgICAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgICAgICAgICB2YXIgcmVzID0gT2JqZWN0LmNyZWF0ZShjb25zdHJ1Y3Rvci5wcm90b3R5cGUpO1xuICAgICAgICAgICAgICBmb3IgKHZhciBtIGluIG9iailcbiAgICAgICAgICAgICAgICAgIGlmICghaW5oZXJpdGVkUHJvcHMuaGFzKG0pKVxuICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlc1ttXSA9IG9ialttXTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKF8pIHsgfVxuICAgICAgICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgICAgIH07XG4gICAgICAgICAgaWYgKHRoaXMuc2NoZW1hLnJlYWRIb29rKSB7XG4gICAgICAgICAgICAgIHRoaXMuaG9vay5yZWFkaW5nLnVuc3Vic2NyaWJlKHRoaXMuc2NoZW1hLnJlYWRIb29rKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5zY2hlbWEucmVhZEhvb2sgPSByZWFkSG9vaztcbiAgICAgICAgICB0aGlzLmhvb2soJ3JlYWRpbmcnLCByZWFkSG9vayk7XG4gICAgICAgICAgcmV0dXJuIGNvbnN0cnVjdG9yO1xuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS5kZWZpbmVDbGFzcyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBmdW5jdGlvbiBDbGFzcyhjb250ZW50KSB7XG4gICAgICAgICAgICAgIGV4dGVuZCh0aGlzLCBjb250ZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRoaXMubWFwVG9DbGFzcyhDbGFzcyk7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChvYmosIGtleSkge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgdmFyIF9hID0gdGhpcy5zY2hlbWEucHJpbUtleSwgYXV0byA9IF9hLmF1dG8sIGtleVBhdGggPSBfYS5rZXlQYXRoO1xuICAgICAgICAgIHZhciBvYmpUb0FkZCA9IG9iajtcbiAgICAgICAgICBpZiAoa2V5UGF0aCAmJiBhdXRvKSB7XG4gICAgICAgICAgICAgIG9ialRvQWRkID0gd29ya2Fyb3VuZEZvclVuZGVmaW5lZFByaW1LZXkoa2V5UGF0aCkob2JqKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zKCdyZWFkd3JpdGUnLCBmdW5jdGlvbiAodHJhbnMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmNvcmUubXV0YXRlKHtcbiAgICAgICAgICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdhZGQnLFxuICAgICAgICAgICAgICAgICAga2V5czoga2V5ICE9IG51bGwgPyBba2V5XSA6IG51bGwsXG4gICAgICAgICAgICAgICAgICB2YWx1ZXM6IFtvYmpUb0FkZF0sXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlcy5udW1GYWlsdXJlcyA/IERleGllUHJvbWlzZS5yZWplY3QocmVzLmZhaWx1cmVzWzBdKSA6IHJlcy5sYXN0UmVzdWx0O1xuICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChsYXN0UmVzdWx0KSB7XG4gICAgICAgICAgICAgIGlmIChrZXlQYXRoKSB7XG4gICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgIHNldEJ5S2V5UGF0aChvYmosIGtleVBhdGgsIGxhc3RSZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgY2F0Y2ggKF8pIHsgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiBsYXN0UmVzdWx0O1xuICAgICAgICAgIH0pO1xuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS51cHNlcnQgPSBmdW5jdGlvbiAoa2V5LCBtb2RpZmljYXRpb25zKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICB2YXIga2V5UGF0aCA9IHRoaXMuc2NoZW1hLnByaW1LZXkua2V5UGF0aDtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnMoJ3JlYWR3cml0ZScsIGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY29yZS5nZXQoeyB0cmFuczogdHJhbnMsIGtleToga2V5IH0pLnRoZW4oZnVuY3Rpb24gKGV4aXN0aW5nKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgb2JqID0gZXhpc3RpbmcgIT09IG51bGwgJiYgZXhpc3RpbmcgIT09IHZvaWQgMCA/IGV4aXN0aW5nIDoge307XG4gICAgICAgICAgICAgICAgICBhcHBseVVwZGF0ZVNwZWMob2JqLCBtb2RpZmljYXRpb25zKTtcbiAgICAgICAgICAgICAgICAgIGlmIChrZXlQYXRoKVxuICAgICAgICAgICAgICAgICAgICAgIHNldEJ5S2V5UGF0aChvYmosIGtleVBhdGgsIGtleSk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY29yZVxuICAgICAgICAgICAgICAgICAgICAgIC5tdXRhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAncHV0JyxcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXM6IFtvYmpdLFxuICAgICAgICAgICAgICAgICAgICAgIGtleXM6IFtrZXldLFxuICAgICAgICAgICAgICAgICAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVzOiB7IGtleXM6IFtrZXldLCBjaGFuZ2VTcGVjczogW21vZGlmaWNhdGlvbnNdIH0sXG4gICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzLm51bUZhaWx1cmVzID8gRGV4aWVQcm9taXNlLnJlamVjdChyZXMuZmFpbHVyZXNbMF0pIDogISFleGlzdGluZztcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBUYWJsZS5wcm90b3R5cGUudXBkYXRlID0gZnVuY3Rpb24gKGtleU9yT2JqZWN0LCBtb2RpZmljYXRpb25zKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBrZXlPck9iamVjdCA9PT0gJ29iamVjdCcgJiYgIWlzQXJyYXkoa2V5T3JPYmplY3QpKSB7XG4gICAgICAgICAgICAgIHZhciBrZXkgPSBnZXRCeUtleVBhdGgoa2V5T3JPYmplY3QsIHRoaXMuc2NoZW1hLnByaW1LZXkua2V5UGF0aCk7XG4gICAgICAgICAgICAgIGlmIChrZXkgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgICAgICAgIHJldHVybiByZWplY3Rpb24obmV3IGV4Y2VwdGlvbnMuSW52YWxpZEFyZ3VtZW50KCdHaXZlbiBvYmplY3QgZG9lcyBub3QgY29udGFpbiBpdHMgcHJpbWFyeSBrZXknKSk7XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLndoZXJlKCc6aWQnKS5lcXVhbHMoa2V5KS5tb2RpZnkobW9kaWZpY2F0aW9ucyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICByZXR1cm4gdGhpcy53aGVyZSgnOmlkJykuZXF1YWxzKGtleU9yT2JqZWN0KS5tb2RpZnkobW9kaWZpY2F0aW9ucyk7XG4gICAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS5wdXQgPSBmdW5jdGlvbiAob2JqLCBrZXkpIHtcbiAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgIHZhciBfYSA9IHRoaXMuc2NoZW1hLnByaW1LZXksIGF1dG8gPSBfYS5hdXRvLCBrZXlQYXRoID0gX2Eua2V5UGF0aDtcbiAgICAgICAgICB2YXIgb2JqVG9BZGQgPSBvYmo7XG4gICAgICAgICAgaWYgKGtleVBhdGggJiYgYXV0bykge1xuICAgICAgICAgICAgICBvYmpUb0FkZCA9IHdvcmthcm91bmRGb3JVbmRlZmluZWRQcmltS2V5KGtleVBhdGgpKG9iaik7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB0aGlzLl90cmFucygncmVhZHdyaXRlJywgZnVuY3Rpb24gKHRyYW5zKSB7XG4gICAgICAgICAgICAgIHJldHVybiBfdGhpcy5jb3JlLm11dGF0ZSh7XG4gICAgICAgICAgICAgICAgICB0cmFuczogdHJhbnMsXG4gICAgICAgICAgICAgICAgICB0eXBlOiAncHV0JyxcbiAgICAgICAgICAgICAgICAgIHZhbHVlczogW29ialRvQWRkXSxcbiAgICAgICAgICAgICAgICAgIGtleXM6IGtleSAhPSBudWxsID8gW2tleV0gOiBudWxsLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXMubnVtRmFpbHVyZXMgPyBEZXhpZVByb21pc2UucmVqZWN0KHJlcy5mYWlsdXJlc1swXSkgOiByZXMubGFzdFJlc3VsdDtcbiAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAobGFzdFJlc3VsdCkge1xuICAgICAgICAgICAgICBpZiAoa2V5UGF0aCkge1xuICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRCeUtleVBhdGgob2JqLCBrZXlQYXRoLCBsYXN0UmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGNhdGNoIChfKSB7IH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gbGFzdFJlc3VsdDtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBUYWJsZS5wcm90b3R5cGUuZGVsZXRlID0gZnVuY3Rpb24gKGtleSkge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zKCdyZWFkd3JpdGUnLCBmdW5jdGlvbiAodHJhbnMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmNvcmVcbiAgICAgICAgICAgICAgICAgIC5tdXRhdGUoeyB0cmFuczogdHJhbnMsIHR5cGU6ICdkZWxldGUnLCBrZXlzOiBba2V5XSB9KVxuICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlcykgeyByZXR1cm4gYnVpbHRJbkRlbGV0aW9uVHJpZ2dlcihfdGhpcywgW2tleV0sIHJlcyk7IH0pXG4gICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gcmVzLm51bUZhaWx1cmVzID8gRGV4aWVQcm9taXNlLnJlamVjdChyZXMuZmFpbHVyZXNbMF0pIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBUYWJsZS5wcm90b3R5cGUuY2xlYXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnMoJ3JlYWR3cml0ZScsIGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY29yZVxuICAgICAgICAgICAgICAgICAgLm11dGF0ZSh7IHRyYW5zOiB0cmFucywgdHlwZTogJ2RlbGV0ZVJhbmdlJywgcmFuZ2U6IEFueVJhbmdlIH0pXG4gICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzKSB7IHJldHVybiBidWlsdEluRGVsZXRpb25UcmlnZ2VyKF90aGlzLCBudWxsLCByZXMpOyB9KTtcbiAgICAgICAgICB9KS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlcy5udW1GYWlsdXJlcyA/IERleGllUHJvbWlzZS5yZWplY3QocmVzLmZhaWx1cmVzWzBdKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBUYWJsZS5wcm90b3R5cGUuYnVsa0dldCA9IGZ1bmN0aW9uIChrZXlzKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnMoJ3JlYWRvbmx5JywgZnVuY3Rpb24gKHRyYW5zKSB7XG4gICAgICAgICAgICAgIHJldHVybiBfdGhpcy5jb3JlXG4gICAgICAgICAgICAgICAgICAuZ2V0TWFueSh7XG4gICAgICAgICAgICAgICAgICBrZXlzOiBrZXlzLFxuICAgICAgICAgICAgICAgICAgdHJhbnM6IHRyYW5zLFxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkgeyByZXR1cm4gcmVzdWx0Lm1hcChmdW5jdGlvbiAocmVzKSB7IHJldHVybiBfdGhpcy5ob29rLnJlYWRpbmcuZmlyZShyZXMpOyB9KTsgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLmJ1bGtBZGQgPSBmdW5jdGlvbiAob2JqZWN0cywga2V5c09yT3B0aW9ucywgb3B0aW9ucykge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgdmFyIGtleXMgPSBBcnJheS5pc0FycmF5KGtleXNPck9wdGlvbnMpID8ga2V5c09yT3B0aW9ucyA6IHVuZGVmaW5lZDtcbiAgICAgICAgICBvcHRpb25zID1cbiAgICAgICAgICAgICAgb3B0aW9ucyB8fCAoa2V5cyA/IHVuZGVmaW5lZCA6IGtleXNPck9wdGlvbnMpO1xuICAgICAgICAgIHZhciB3YW50UmVzdWx0cyA9IG9wdGlvbnMgPyBvcHRpb25zLmFsbEtleXMgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zKCdyZWFkd3JpdGUnLCBmdW5jdGlvbiAodHJhbnMpIHtcbiAgICAgICAgICAgICAgdmFyIF9hID0gX3RoaXMuc2NoZW1hLnByaW1LZXksIGF1dG8gPSBfYS5hdXRvLCBrZXlQYXRoID0gX2Eua2V5UGF0aDtcbiAgICAgICAgICAgICAgaWYgKGtleVBhdGggJiYga2V5cylcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLkludmFsaWRBcmd1bWVudCgnYnVsa0FkZCgpOiBrZXlzIGFyZ3VtZW50IGludmFsaWQgb24gdGFibGVzIHdpdGggaW5ib3VuZCBrZXlzJyk7XG4gICAgICAgICAgICAgIGlmIChrZXlzICYmIGtleXMubGVuZ3RoICE9PSBvYmplY3RzLmxlbmd0aClcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLkludmFsaWRBcmd1bWVudCgnQXJndW1lbnRzIG9iamVjdHMgYW5kIGtleXMgbXVzdCBoYXZlIHRoZSBzYW1lIGxlbmd0aCcpO1xuICAgICAgICAgICAgICB2YXIgbnVtT2JqZWN0cyA9IG9iamVjdHMubGVuZ3RoO1xuICAgICAgICAgICAgICB2YXIgb2JqZWN0c1RvQWRkID0ga2V5UGF0aCAmJiBhdXRvXG4gICAgICAgICAgICAgICAgICA/IG9iamVjdHMubWFwKHdvcmthcm91bmRGb3JVbmRlZmluZWRQcmltS2V5KGtleVBhdGgpKVxuICAgICAgICAgICAgICAgICAgOiBvYmplY3RzO1xuICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY29yZVxuICAgICAgICAgICAgICAgICAgLm11dGF0ZSh7XG4gICAgICAgICAgICAgICAgICB0cmFuczogdHJhbnMsXG4gICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgIGtleXM6IGtleXMsXG4gICAgICAgICAgICAgICAgICB2YWx1ZXM6IG9iamVjdHNUb0FkZCxcbiAgICAgICAgICAgICAgICAgIHdhbnRSZXN1bHRzOiB3YW50UmVzdWx0cyxcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgICAgdmFyIG51bUZhaWx1cmVzID0gX2EubnVtRmFpbHVyZXMsIHJlc3VsdHMgPSBfYS5yZXN1bHRzLCBsYXN0UmVzdWx0ID0gX2EubGFzdFJlc3VsdCwgZmFpbHVyZXMgPSBfYS5mYWlsdXJlcztcbiAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSB3YW50UmVzdWx0cyA/IHJlc3VsdHMgOiBsYXN0UmVzdWx0O1xuICAgICAgICAgICAgICAgICAgaWYgKG51bUZhaWx1cmVzID09PSAwKVxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgQnVsa0Vycm9yKFwiXCIuY29uY2F0KF90aGlzLm5hbWUsIFwiLmJ1bGtBZGQoKTogXCIpLmNvbmNhdChudW1GYWlsdXJlcywgXCIgb2YgXCIpLmNvbmNhdChudW1PYmplY3RzLCBcIiBvcGVyYXRpb25zIGZhaWxlZFwiKSwgZmFpbHVyZXMpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBUYWJsZS5wcm90b3R5cGUuYnVsa1B1dCA9IGZ1bmN0aW9uIChvYmplY3RzLCBrZXlzT3JPcHRpb25zLCBvcHRpb25zKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICB2YXIga2V5cyA9IEFycmF5LmlzQXJyYXkoa2V5c09yT3B0aW9ucykgPyBrZXlzT3JPcHRpb25zIDogdW5kZWZpbmVkO1xuICAgICAgICAgIG9wdGlvbnMgPVxuICAgICAgICAgICAgICBvcHRpb25zIHx8IChrZXlzID8gdW5kZWZpbmVkIDoga2V5c09yT3B0aW9ucyk7XG4gICAgICAgICAgdmFyIHdhbnRSZXN1bHRzID0gb3B0aW9ucyA/IG9wdGlvbnMuYWxsS2V5cyA6IHVuZGVmaW5lZDtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnMoJ3JlYWR3cml0ZScsIGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICB2YXIgX2EgPSBfdGhpcy5zY2hlbWEucHJpbUtleSwgYXV0byA9IF9hLmF1dG8sIGtleVBhdGggPSBfYS5rZXlQYXRoO1xuICAgICAgICAgICAgICBpZiAoa2V5UGF0aCAmJiBrZXlzKVxuICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuSW52YWxpZEFyZ3VtZW50KCdidWxrUHV0KCk6IGtleXMgYXJndW1lbnQgaW52YWxpZCBvbiB0YWJsZXMgd2l0aCBpbmJvdW5kIGtleXMnKTtcbiAgICAgICAgICAgICAgaWYgKGtleXMgJiYga2V5cy5sZW5ndGggIT09IG9iamVjdHMubGVuZ3RoKVxuICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuSW52YWxpZEFyZ3VtZW50KCdBcmd1bWVudHMgb2JqZWN0cyBhbmQga2V5cyBtdXN0IGhhdmUgdGhlIHNhbWUgbGVuZ3RoJyk7XG4gICAgICAgICAgICAgIHZhciBudW1PYmplY3RzID0gb2JqZWN0cy5sZW5ndGg7XG4gICAgICAgICAgICAgIHZhciBvYmplY3RzVG9QdXQgPSBrZXlQYXRoICYmIGF1dG9cbiAgICAgICAgICAgICAgICAgID8gb2JqZWN0cy5tYXAod29ya2Fyb3VuZEZvclVuZGVmaW5lZFByaW1LZXkoa2V5UGF0aCkpXG4gICAgICAgICAgICAgICAgICA6IG9iamVjdHM7XG4gICAgICAgICAgICAgIHJldHVybiBfdGhpcy5jb3JlXG4gICAgICAgICAgICAgICAgICAubXV0YXRlKHtcbiAgICAgICAgICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdwdXQnLFxuICAgICAgICAgICAgICAgICAga2V5czoga2V5cyxcbiAgICAgICAgICAgICAgICAgIHZhbHVlczogb2JqZWN0c1RvUHV0LFxuICAgICAgICAgICAgICAgICAgd2FudFJlc3VsdHM6IHdhbnRSZXN1bHRzLFxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgbnVtRmFpbHVyZXMgPSBfYS5udW1GYWlsdXJlcywgcmVzdWx0cyA9IF9hLnJlc3VsdHMsIGxhc3RSZXN1bHQgPSBfYS5sYXN0UmVzdWx0LCBmYWlsdXJlcyA9IF9hLmZhaWx1cmVzO1xuICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IHdhbnRSZXN1bHRzID8gcmVzdWx0cyA6IGxhc3RSZXN1bHQ7XG4gICAgICAgICAgICAgICAgICBpZiAobnVtRmFpbHVyZXMgPT09IDApXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBCdWxrRXJyb3IoXCJcIi5jb25jYXQoX3RoaXMubmFtZSwgXCIuYnVsa1B1dCgpOiBcIikuY29uY2F0KG51bUZhaWx1cmVzLCBcIiBvZiBcIikuY29uY2F0KG51bU9iamVjdHMsIFwiIG9wZXJhdGlvbnMgZmFpbGVkXCIpLCBmYWlsdXJlcyk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgfTtcbiAgICAgIFRhYmxlLnByb3RvdHlwZS5idWxrVXBkYXRlID0gZnVuY3Rpb24gKGtleXNBbmRDaGFuZ2VzKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICB2YXIgY29yZVRhYmxlID0gdGhpcy5jb3JlO1xuICAgICAgICAgIHZhciBrZXlzID0ga2V5c0FuZENoYW5nZXMubWFwKGZ1bmN0aW9uIChlbnRyeSkgeyByZXR1cm4gZW50cnkua2V5OyB9KTtcbiAgICAgICAgICB2YXIgY2hhbmdlU3BlY3MgPSBrZXlzQW5kQ2hhbmdlcy5tYXAoZnVuY3Rpb24gKGVudHJ5KSB7IHJldHVybiBlbnRyeS5jaGFuZ2VzOyB9KTtcbiAgICAgICAgICB2YXIgb2Zmc2V0TWFwID0gW107XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3RyYW5zKCdyZWFkd3JpdGUnLCBmdW5jdGlvbiAodHJhbnMpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNvcmVUYWJsZS5nZXRNYW55KHsgdHJhbnM6IHRyYW5zLCBrZXlzOiBrZXlzLCBjYWNoZTogJ2Nsb25lJyB9KS50aGVuKGZ1bmN0aW9uIChvYmpzKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0S2V5cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdE9ianMgPSBbXTtcbiAgICAgICAgICAgICAgICAgIGtleXNBbmRDaGFuZ2VzLmZvckVhY2goZnVuY3Rpb24gKF9hLCBpZHgpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIga2V5ID0gX2Eua2V5LCBjaGFuZ2VzID0gX2EuY2hhbmdlcztcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgb2JqID0gb2Jqc1tpZHhdO1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChvYmopIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYiA9IE9iamVjdC5rZXlzKGNoYW5nZXMpOyBfaSA8IF9iLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGtleVBhdGggPSBfYltfaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSBjaGFuZ2VzW2tleVBhdGhdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGtleVBhdGggPT09IF90aGlzLnNjaGVtYS5wcmltS2V5LmtleVBhdGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY21wKHZhbHVlLCBrZXkpICE9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLkNvbnN0cmFpbnQoXCJDYW5ub3QgdXBkYXRlIHByaW1hcnkga2V5IGluIGJ1bGtVcGRhdGUoKVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRCeUtleVBhdGgob2JqLCBrZXlQYXRoLCB2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb2Zmc2V0TWFwLnB1c2goaWR4KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0S2V5cy5wdXNoKGtleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdE9ianMucHVzaChvYmopO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgdmFyIG51bUVudHJpZXMgPSByZXN1bHRLZXlzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb3JlVGFibGVcbiAgICAgICAgICAgICAgICAgICAgICAubXV0YXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICB0cmFuczogdHJhbnMsXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3B1dCcsXG4gICAgICAgICAgICAgICAgICAgICAga2V5czogcmVzdWx0S2V5cyxcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXM6IHJlc3VsdE9ianMsXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXlzOiBrZXlzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFuZ2VTcGVjczogY2hhbmdlU3BlY3MsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIG51bUZhaWx1cmVzID0gX2EubnVtRmFpbHVyZXMsIGZhaWx1cmVzID0gX2EuZmFpbHVyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKG51bUZhaWx1cmVzID09PSAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVtRW50cmllcztcbiAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBfaSA9IDAsIF9iID0gT2JqZWN0LmtleXMoZmFpbHVyZXMpOyBfaSA8IF9iLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgb2Zmc2V0ID0gX2JbX2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWFwcGVkT2Zmc2V0ID0gb2Zmc2V0TWFwW051bWJlcihvZmZzZXQpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1hcHBlZE9mZnNldCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmFpbHVyZSA9IGZhaWx1cmVzW29mZnNldF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgZmFpbHVyZXNbb2Zmc2V0XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmVzW21hcHBlZE9mZnNldF0gPSBmYWlsdXJlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBCdWxrRXJyb3IoXCJcIi5jb25jYXQoX3RoaXMubmFtZSwgXCIuYnVsa1VwZGF0ZSgpOiBcIikuY29uY2F0KG51bUZhaWx1cmVzLCBcIiBvZiBcIikuY29uY2F0KG51bUVudHJpZXMsIFwiIG9wZXJhdGlvbnMgZmFpbGVkXCIpLCBmYWlsdXJlcyk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgVGFibGUucHJvdG90eXBlLmJ1bGtEZWxldGUgPSBmdW5jdGlvbiAoa2V5cykge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgdmFyIG51bUtleXMgPSBrZXlzLmxlbmd0aDtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fdHJhbnMoJ3JlYWR3cml0ZScsIGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY29yZVxuICAgICAgICAgICAgICAgICAgLm11dGF0ZSh7IHRyYW5zOiB0cmFucywgdHlwZTogJ2RlbGV0ZScsIGtleXM6IGtleXMgfSlcbiAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXMpIHsgcmV0dXJuIGJ1aWx0SW5EZWxldGlvblRyaWdnZXIoX3RoaXMsIGtleXMsIHJlcyk7IH0pO1xuICAgICAgICAgIH0pLnRoZW4oZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgIHZhciBudW1GYWlsdXJlcyA9IF9hLm51bUZhaWx1cmVzLCBsYXN0UmVzdWx0ID0gX2EubGFzdFJlc3VsdCwgZmFpbHVyZXMgPSBfYS5mYWlsdXJlcztcbiAgICAgICAgICAgICAgaWYgKG51bUZhaWx1cmVzID09PSAwKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGxhc3RSZXN1bHQ7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBCdWxrRXJyb3IoXCJcIi5jb25jYXQoX3RoaXMubmFtZSwgXCIuYnVsa0RlbGV0ZSgpOiBcIikuY29uY2F0KG51bUZhaWx1cmVzLCBcIiBvZiBcIikuY29uY2F0KG51bUtleXMsIFwiIG9wZXJhdGlvbnMgZmFpbGVkXCIpLCBmYWlsdXJlcyk7XG4gICAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgcmV0dXJuIFRhYmxlO1xuICB9KCkpO1xuXG4gIGZ1bmN0aW9uIEV2ZW50cyhjdHgpIHtcbiAgICAgIHZhciBldnMgPSB7fTtcbiAgICAgIHZhciBydiA9IGZ1bmN0aW9uIChldmVudE5hbWUsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgICBpZiAoc3Vic2NyaWJlcikge1xuICAgICAgICAgICAgICB2YXIgaSA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoaSAtIDEpO1xuICAgICAgICAgICAgICB3aGlsZSAoLS1pKVxuICAgICAgICAgICAgICAgICAgYXJnc1tpIC0gMV0gPSBhcmd1bWVudHNbaV07XG4gICAgICAgICAgICAgIGV2c1tldmVudE5hbWVdLnN1YnNjcmliZS5hcHBseShudWxsLCBhcmdzKTtcbiAgICAgICAgICAgICAgcmV0dXJuIGN0eDtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGV2ZW50TmFtZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGV2c1tldmVudE5hbWVdO1xuICAgICAgICAgIH1cbiAgICAgIH07XG4gICAgICBydi5hZGRFdmVudFR5cGUgPSBhZGQ7XG4gICAgICBmb3IgKHZhciBpID0gMSwgbCA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBsOyArK2kpIHtcbiAgICAgICAgICBhZGQoYXJndW1lbnRzW2ldKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBydjtcbiAgICAgIGZ1bmN0aW9uIGFkZChldmVudE5hbWUsIGNoYWluRnVuY3Rpb24sIGRlZmF1bHRGdW5jdGlvbikge1xuICAgICAgICAgIGlmICh0eXBlb2YgZXZlbnROYW1lID09PSAnb2JqZWN0JylcbiAgICAgICAgICAgICAgcmV0dXJuIGFkZENvbmZpZ3VyZWRFdmVudHMoZXZlbnROYW1lKTtcbiAgICAgICAgICBpZiAoIWNoYWluRnVuY3Rpb24pXG4gICAgICAgICAgICAgIGNoYWluRnVuY3Rpb24gPSByZXZlcnNlU3RvcHBhYmxlRXZlbnRDaGFpbjtcbiAgICAgICAgICBpZiAoIWRlZmF1bHRGdW5jdGlvbilcbiAgICAgICAgICAgICAgZGVmYXVsdEZ1bmN0aW9uID0gbm9wO1xuICAgICAgICAgIHZhciBjb250ZXh0ID0ge1xuICAgICAgICAgICAgICBzdWJzY3JpYmVyczogW10sXG4gICAgICAgICAgICAgIGZpcmU6IGRlZmF1bHRGdW5jdGlvbixcbiAgICAgICAgICAgICAgc3Vic2NyaWJlOiBmdW5jdGlvbiAoY2IpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChjb250ZXh0LnN1YnNjcmliZXJzLmluZGV4T2YoY2IpID09PSAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQuc3Vic2NyaWJlcnMucHVzaChjYik7XG4gICAgICAgICAgICAgICAgICAgICAgY29udGV4dC5maXJlID0gY2hhaW5GdW5jdGlvbihjb250ZXh0LmZpcmUsIGNiKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdW5zdWJzY3JpYmU6IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgICAgICAgICAgY29udGV4dC5zdWJzY3JpYmVycyA9IGNvbnRleHQuc3Vic2NyaWJlcnMuZmlsdGVyKGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmbiAhPT0gY2I7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIGNvbnRleHQuZmlyZSA9IGNvbnRleHQuc3Vic2NyaWJlcnMucmVkdWNlKGNoYWluRnVuY3Rpb24sIGRlZmF1bHRGdW5jdGlvbik7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgfTtcbiAgICAgICAgICBldnNbZXZlbnROYW1lXSA9IHJ2W2V2ZW50TmFtZV0gPSBjb250ZXh0O1xuICAgICAgICAgIHJldHVybiBjb250ZXh0O1xuICAgICAgfVxuICAgICAgZnVuY3Rpb24gYWRkQ29uZmlndXJlZEV2ZW50cyhjZmcpIHtcbiAgICAgICAgICBrZXlzKGNmZykuZm9yRWFjaChmdW5jdGlvbiAoZXZlbnROYW1lKSB7XG4gICAgICAgICAgICAgIHZhciBhcmdzID0gY2ZnW2V2ZW50TmFtZV07XG4gICAgICAgICAgICAgIGlmIChpc0FycmF5KGFyZ3MpKSB7XG4gICAgICAgICAgICAgICAgICBhZGQoZXZlbnROYW1lLCBjZmdbZXZlbnROYW1lXVswXSwgY2ZnW2V2ZW50TmFtZV1bMV0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2UgaWYgKGFyZ3MgPT09ICdhc2FwJykge1xuICAgICAgICAgICAgICAgICAgdmFyIGNvbnRleHQgPSBhZGQoZXZlbnROYW1lLCBtaXJyb3IsIGZ1bmN0aW9uIGZpcmUoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGkgPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KGkpO1xuICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChpLS0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFyZ3NbaV0gPSBhcmd1bWVudHNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgY29udGV4dC5zdWJzY3JpYmVycy5mb3JFYWNoKGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhc2FwJDEoZnVuY3Rpb24gZmlyZUV2ZW50KCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm4uYXBwbHkobnVsbCwgYXJncyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuSW52YWxpZEFyZ3VtZW50KCdJbnZhbGlkIGV2ZW50IGNvbmZpZycpO1xuICAgICAgICAgIH0pO1xuICAgICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gbWFrZUNsYXNzQ29uc3RydWN0b3IocHJvdG90eXBlLCBjb25zdHJ1Y3Rvcikge1xuICAgICAgZGVyaXZlKGNvbnN0cnVjdG9yKS5mcm9tKHsgcHJvdG90eXBlOiBwcm90b3R5cGUgfSk7XG4gICAgICByZXR1cm4gY29uc3RydWN0b3I7XG4gIH1cblxuICBmdW5jdGlvbiBjcmVhdGVUYWJsZUNvbnN0cnVjdG9yKGRiKSB7XG4gICAgICByZXR1cm4gbWFrZUNsYXNzQ29uc3RydWN0b3IoVGFibGUucHJvdG90eXBlLCBmdW5jdGlvbiBUYWJsZShuYW1lLCB0YWJsZVNjaGVtYSwgdHJhbnMpIHtcbiAgICAgICAgICB0aGlzLmRiID0gZGI7XG4gICAgICAgICAgdGhpcy5fdHggPSB0cmFucztcbiAgICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgICAgICAgIHRoaXMuc2NoZW1hID0gdGFibGVTY2hlbWE7XG4gICAgICAgICAgdGhpcy5ob29rID0gZGIuX2FsbFRhYmxlc1tuYW1lXVxuICAgICAgICAgICAgICA/IGRiLl9hbGxUYWJsZXNbbmFtZV0uaG9va1xuICAgICAgICAgICAgICA6IEV2ZW50cyhudWxsLCB7XG4gICAgICAgICAgICAgICAgICBjcmVhdGluZzogW2hvb2tDcmVhdGluZ0NoYWluLCBub3BdLFxuICAgICAgICAgICAgICAgICAgcmVhZGluZzogW3B1cmVGdW5jdGlvbkNoYWluLCBtaXJyb3JdLFxuICAgICAgICAgICAgICAgICAgdXBkYXRpbmc6IFtob29rVXBkYXRpbmdDaGFpbiwgbm9wXSxcbiAgICAgICAgICAgICAgICAgIGRlbGV0aW5nOiBbaG9va0RlbGV0aW5nQ2hhaW4sIG5vcF0sXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBpc1BsYWluS2V5UmFuZ2UoY3R4LCBpZ25vcmVMaW1pdEZpbHRlcikge1xuICAgICAgcmV0dXJuICghKGN0eC5maWx0ZXIgfHwgY3R4LmFsZ29yaXRobSB8fCBjdHgub3IpICYmXG4gICAgICAgICAgKGlnbm9yZUxpbWl0RmlsdGVyID8gY3R4Lmp1c3RMaW1pdCA6ICFjdHgucmVwbGF5RmlsdGVyKSk7XG4gIH1cbiAgZnVuY3Rpb24gYWRkRmlsdGVyKGN0eCwgZm4pIHtcbiAgICAgIGN0eC5maWx0ZXIgPSBjb21iaW5lKGN0eC5maWx0ZXIsIGZuKTtcbiAgfVxuICBmdW5jdGlvbiBhZGRSZXBsYXlGaWx0ZXIoY3R4LCBmYWN0b3J5LCBpc0xpbWl0RmlsdGVyKSB7XG4gICAgICB2YXIgY3VyciA9IGN0eC5yZXBsYXlGaWx0ZXI7XG4gICAgICBjdHgucmVwbGF5RmlsdGVyID0gY3VyciA/IGZ1bmN0aW9uICgpIHsgcmV0dXJuIGNvbWJpbmUoY3VycigpLCBmYWN0b3J5KCkpOyB9IDogZmFjdG9yeTtcbiAgICAgIGN0eC5qdXN0TGltaXQgPSBpc0xpbWl0RmlsdGVyICYmICFjdXJyO1xuICB9XG4gIGZ1bmN0aW9uIGFkZE1hdGNoRmlsdGVyKGN0eCwgZm4pIHtcbiAgICAgIGN0eC5pc01hdGNoID0gY29tYmluZShjdHguaXNNYXRjaCwgZm4pO1xuICB9XG4gIGZ1bmN0aW9uIGdldEluZGV4T3JTdG9yZShjdHgsIGNvcmVTY2hlbWEpIHtcbiAgICAgIGlmIChjdHguaXNQcmltS2V5KVxuICAgICAgICAgIHJldHVybiBjb3JlU2NoZW1hLnByaW1hcnlLZXk7XG4gICAgICB2YXIgaW5kZXggPSBjb3JlU2NoZW1hLmdldEluZGV4QnlLZXlQYXRoKGN0eC5pbmRleCk7XG4gICAgICBpZiAoIWluZGV4KVxuICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLlNjaGVtYSgnS2V5UGF0aCAnICtcbiAgICAgICAgICAgICAgY3R4LmluZGV4ICtcbiAgICAgICAgICAgICAgJyBvbiBvYmplY3Qgc3RvcmUgJyArXG4gICAgICAgICAgICAgIGNvcmVTY2hlbWEubmFtZSArXG4gICAgICAgICAgICAgICcgaXMgbm90IGluZGV4ZWQnKTtcbiAgICAgIHJldHVybiBpbmRleDtcbiAgfVxuICBmdW5jdGlvbiBvcGVuQ3Vyc29yKGN0eCwgY29yZVRhYmxlLCB0cmFucykge1xuICAgICAgdmFyIGluZGV4ID0gZ2V0SW5kZXhPclN0b3JlKGN0eCwgY29yZVRhYmxlLnNjaGVtYSk7XG4gICAgICByZXR1cm4gY29yZVRhYmxlLm9wZW5DdXJzb3Ioe1xuICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICB2YWx1ZXM6ICFjdHgua2V5c09ubHksXG4gICAgICAgICAgcmV2ZXJzZTogY3R4LmRpciA9PT0gJ3ByZXYnLFxuICAgICAgICAgIHVuaXF1ZTogISFjdHgudW5pcXVlLFxuICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICAgICAgcmFuZ2U6IGN0eC5yYW5nZSxcbiAgICAgICAgICB9LFxuICAgICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gaXRlcihjdHgsIGZuLCBjb3JlVHJhbnMsIGNvcmVUYWJsZSkge1xuICAgICAgdmFyIGZpbHRlciA9IGN0eC5yZXBsYXlGaWx0ZXJcbiAgICAgICAgICA/IGNvbWJpbmUoY3R4LmZpbHRlciwgY3R4LnJlcGxheUZpbHRlcigpKVxuICAgICAgICAgIDogY3R4LmZpbHRlcjtcbiAgICAgIGlmICghY3R4Lm9yKSB7XG4gICAgICAgICAgcmV0dXJuIGl0ZXJhdGUob3BlbkN1cnNvcihjdHgsIGNvcmVUYWJsZSwgY29yZVRyYW5zKSwgY29tYmluZShjdHguYWxnb3JpdGhtLCBmaWx0ZXIpLCBmbiwgIWN0eC5rZXlzT25seSAmJiBjdHgudmFsdWVNYXBwZXIpO1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgICAgdmFyIHNldF8xID0ge307XG4gICAgICAgICAgdmFyIHVuaW9uID0gZnVuY3Rpb24gKGl0ZW0sIGN1cnNvciwgYWR2YW5jZSkge1xuICAgICAgICAgICAgICBpZiAoIWZpbHRlciB8fFxuICAgICAgICAgICAgICAgICAgZmlsdGVyKGN1cnNvciwgYWR2YW5jZSwgZnVuY3Rpb24gKHJlc3VsdCkgeyByZXR1cm4gY3Vyc29yLnN0b3AocmVzdWx0KTsgfSwgZnVuY3Rpb24gKGVycikgeyByZXR1cm4gY3Vyc29yLmZhaWwoZXJyKTsgfSkpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBwcmltYXJ5S2V5ID0gY3Vyc29yLnByaW1hcnlLZXk7XG4gICAgICAgICAgICAgICAgICB2YXIga2V5ID0gJycgKyBwcmltYXJ5S2V5O1xuICAgICAgICAgICAgICAgICAgaWYgKGtleSA9PT0gJ1tvYmplY3QgQXJyYXlCdWZmZXJdJylcbiAgICAgICAgICAgICAgICAgICAgICBrZXkgPSAnJyArIG5ldyBVaW50OEFycmF5KHByaW1hcnlLZXkpO1xuICAgICAgICAgICAgICAgICAgaWYgKCFoYXNPd24oc2V0XzEsIGtleSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRfMVtrZXldID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICBmbihpdGVtLCBjdXJzb3IsIGFkdmFuY2UpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgICByZXR1cm4gUHJvbWlzZS5hbGwoW1xuICAgICAgICAgICAgICBjdHgub3IuX2l0ZXJhdGUodW5pb24sIGNvcmVUcmFucyksXG4gICAgICAgICAgICAgIGl0ZXJhdGUob3BlbkN1cnNvcihjdHgsIGNvcmVUYWJsZSwgY29yZVRyYW5zKSwgY3R4LmFsZ29yaXRobSwgdW5pb24sICFjdHgua2V5c09ubHkgJiYgY3R4LnZhbHVlTWFwcGVyKSxcbiAgICAgICAgICBdKTtcbiAgICAgIH1cbiAgfVxuICBmdW5jdGlvbiBpdGVyYXRlKGN1cnNvclByb21pc2UsIGZpbHRlciwgZm4sIHZhbHVlTWFwcGVyKSB7XG4gICAgICB2YXIgbWFwcGVkRm4gPSB2YWx1ZU1hcHBlciA/IGZ1bmN0aW9uICh4LCBjLCBhKSB7IHJldHVybiBmbih2YWx1ZU1hcHBlcih4KSwgYywgYSk7IH0gOiBmbjtcbiAgICAgIHZhciB3cmFwcGVkRm4gPSB3cmFwKG1hcHBlZEZuKTtcbiAgICAgIHJldHVybiBjdXJzb3JQcm9taXNlLnRoZW4oZnVuY3Rpb24gKGN1cnNvcikge1xuICAgICAgICAgIGlmIChjdXJzb3IpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGN1cnNvci5zdGFydChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgYyA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIGN1cnNvci5jb250aW51ZSgpOyB9O1xuICAgICAgICAgICAgICAgICAgaWYgKCFmaWx0ZXIgfHxcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXIoY3Vyc29yLCBmdW5jdGlvbiAoYWR2YW5jZXIpIHsgcmV0dXJuIChjID0gYWR2YW5jZXIpOyB9LCBmdW5jdGlvbiAodmFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5zdG9wKHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBub3A7XG4gICAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmZhaWwoZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGMgPSBub3A7XG4gICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAgICAgICAgd3JhcHBlZEZuKGN1cnNvci52YWx1ZSwgY3Vyc29yLCBmdW5jdGlvbiAoYWR2YW5jZXIpIHsgcmV0dXJuIChjID0gYWR2YW5jZXIpOyB9KTtcbiAgICAgICAgICAgICAgICAgIGMoKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICB2YXIgQ29sbGVjdGlvbiA9ICAoZnVuY3Rpb24gKCkge1xuICAgICAgZnVuY3Rpb24gQ29sbGVjdGlvbigpIHtcbiAgICAgIH1cbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLl9yZWFkID0gZnVuY3Rpb24gKGZuLCBjYikge1xuICAgICAgICAgIHZhciBjdHggPSB0aGlzLl9jdHg7XG4gICAgICAgICAgcmV0dXJuIGN0eC5lcnJvclxuICAgICAgICAgICAgICA/IGN0eC50YWJsZS5fdHJhbnMobnVsbCwgcmVqZWN0aW9uLmJpbmQobnVsbCwgY3R4LmVycm9yKSlcbiAgICAgICAgICAgICAgOiBjdHgudGFibGUuX3RyYW5zKCdyZWFkb25seScsIGZuKS50aGVuKGNiKTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5fd3JpdGUgPSBmdW5jdGlvbiAoZm4pIHtcbiAgICAgICAgICB2YXIgY3R4ID0gdGhpcy5fY3R4O1xuICAgICAgICAgIHJldHVybiBjdHguZXJyb3JcbiAgICAgICAgICAgICAgPyBjdHgudGFibGUuX3RyYW5zKG51bGwsIHJlamVjdGlvbi5iaW5kKG51bGwsIGN0eC5lcnJvcikpXG4gICAgICAgICAgICAgIDogY3R4LnRhYmxlLl90cmFucygncmVhZHdyaXRlJywgZm4sICdsb2NrZWQnKTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5fYWRkQWxnb3JpdGhtID0gZnVuY3Rpb24gKGZuKSB7XG4gICAgICAgICAgdmFyIGN0eCA9IHRoaXMuX2N0eDtcbiAgICAgICAgICBjdHguYWxnb3JpdGhtID0gY29tYmluZShjdHguYWxnb3JpdGhtLCBmbik7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUuX2l0ZXJhdGUgPSBmdW5jdGlvbiAoZm4sIGNvcmVUcmFucykge1xuICAgICAgICAgIHJldHVybiBpdGVyKHRoaXMuX2N0eCwgZm4sIGNvcmVUcmFucywgdGhpcy5fY3R4LnRhYmxlLmNvcmUpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLmNsb25lID0gZnVuY3Rpb24gKHByb3BzKSB7XG4gICAgICAgICAgdmFyIHJ2ID0gT2JqZWN0LmNyZWF0ZSh0aGlzLmNvbnN0cnVjdG9yLnByb3RvdHlwZSksIGN0eCA9IE9iamVjdC5jcmVhdGUodGhpcy5fY3R4KTtcbiAgICAgICAgICBpZiAocHJvcHMpXG4gICAgICAgICAgICAgIGV4dGVuZChjdHgsIHByb3BzKTtcbiAgICAgICAgICBydi5fY3R4ID0gY3R4O1xuICAgICAgICAgIHJldHVybiBydjtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5yYXcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdGhpcy5fY3R4LnZhbHVlTWFwcGVyID0gbnVsbDtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5lYWNoID0gZnVuY3Rpb24gKGZuKSB7XG4gICAgICAgICAgdmFyIGN0eCA9IHRoaXMuX2N0eDtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fcmVhZChmdW5jdGlvbiAodHJhbnMpIHsgcmV0dXJuIGl0ZXIoY3R4LCBmbiwgdHJhbnMsIGN0eC50YWJsZS5jb3JlKTsgfSk7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUuY291bnQgPSBmdW5jdGlvbiAoY2IpIHtcbiAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZWFkKGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICB2YXIgY3R4ID0gX3RoaXMuX2N0eDtcbiAgICAgICAgICAgICAgdmFyIGNvcmVUYWJsZSA9IGN0eC50YWJsZS5jb3JlO1xuICAgICAgICAgICAgICBpZiAoaXNQbGFpbktleVJhbmdlKGN0eCwgdHJ1ZSkpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb3JlVGFibGVcbiAgICAgICAgICAgICAgICAgICAgICAuY291bnQoe1xuICAgICAgICAgICAgICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICAgICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleDogZ2V0SW5kZXhPclN0b3JlKGN0eCwgY29yZVRhYmxlLnNjaGVtYSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJhbmdlOiBjdHgucmFuZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKGNvdW50KSB7IHJldHVybiBNYXRoLm1pbihjb3VudCwgY3R4LmxpbWl0KTsgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICB2YXIgY291bnQgPSAwO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGl0ZXIoY3R4LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgKytjb3VudDtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgICB9LCB0cmFucywgY29yZVRhYmxlKS50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGNvdW50OyB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pLnRoZW4oY2IpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLnNvcnRCeSA9IGZ1bmN0aW9uIChrZXlQYXRoLCBjYikge1xuICAgICAgICAgIHZhciBwYXJ0cyA9IGtleVBhdGguc3BsaXQoJy4nKS5yZXZlcnNlKCksIGxhc3RQYXJ0ID0gcGFydHNbMF0sIGxhc3RJbmRleCA9IHBhcnRzLmxlbmd0aCAtIDE7XG4gICAgICAgICAgZnVuY3Rpb24gZ2V0dmFsKG9iaiwgaSkge1xuICAgICAgICAgICAgICBpZiAoaSlcbiAgICAgICAgICAgICAgICAgIHJldHVybiBnZXR2YWwob2JqW3BhcnRzW2ldXSwgaSAtIDEpO1xuICAgICAgICAgICAgICByZXR1cm4gb2JqW2xhc3RQYXJ0XTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIG9yZGVyID0gdGhpcy5fY3R4LmRpciA9PT0gJ25leHQnID8gMSA6IC0xO1xuICAgICAgICAgIGZ1bmN0aW9uIHNvcnRlcihhLCBiKSB7XG4gICAgICAgICAgICAgIHZhciBhVmFsID0gZ2V0dmFsKGEsIGxhc3RJbmRleCksIGJWYWwgPSBnZXR2YWwoYiwgbGFzdEluZGV4KTtcbiAgICAgICAgICAgICAgcmV0dXJuIGNtcChhVmFsLCBiVmFsKSAqIG9yZGVyO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdGhpcy50b0FycmF5KGZ1bmN0aW9uIChhKSB7XG4gICAgICAgICAgICAgIHJldHVybiBhLnNsaWNlKCkuc29ydChzb3J0ZXIpO1xuICAgICAgICAgIH0pLnRoZW4oY2IpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLnRvQXJyYXkgPSBmdW5jdGlvbiAoY2IpIHtcbiAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgIHJldHVybiB0aGlzLl9yZWFkKGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICB2YXIgY3R4ID0gX3RoaXMuX2N0eDtcbiAgICAgICAgICAgICAgaWYgKGlzUGxhaW5LZXlSYW5nZShjdHgsIHRydWUpICYmIGN0eC5saW1pdCA+IDApIHtcbiAgICAgICAgICAgICAgICAgIHZhciB2YWx1ZU1hcHBlcl8xID0gY3R4LnZhbHVlTWFwcGVyO1xuICAgICAgICAgICAgICAgICAgdmFyIGluZGV4ID0gZ2V0SW5kZXhPclN0b3JlKGN0eCwgY3R4LnRhYmxlLmNvcmUuc2NoZW1hKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjdHgudGFibGUuY29yZVxuICAgICAgICAgICAgICAgICAgICAgIC5xdWVyeSh7XG4gICAgICAgICAgICAgICAgICAgICAgdHJhbnM6IHRyYW5zLFxuICAgICAgICAgICAgICAgICAgICAgIGxpbWl0OiBjdHgubGltaXQsXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGlvbjogY3R4LmRpciA9PT0gJ3ByZXYnID8gJ3ByZXYnIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmFuZ2U6IGN0eC5yYW5nZSxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gX2EucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZU1hcHBlcl8xID8gcmVzdWx0Lm1hcCh2YWx1ZU1hcHBlcl8xKSA6IHJlc3VsdDtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgdmFyIGFfMSA9IFtdO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGl0ZXIoY3R4LCBmdW5jdGlvbiAoaXRlbSkgeyByZXR1cm4gYV8xLnB1c2goaXRlbSk7IH0sIHRyYW5zLCBjdHgudGFibGUuY29yZSkudGhlbihmdW5jdGlvbiAoKSB7IHJldHVybiBhXzE7IH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSwgY2IpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLm9mZnNldCA9IGZ1bmN0aW9uIChvZmZzZXQpIHtcbiAgICAgICAgICB2YXIgY3R4ID0gdGhpcy5fY3R4O1xuICAgICAgICAgIGlmIChvZmZzZXQgPD0gMClcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgY3R4Lm9mZnNldCArPSBvZmZzZXQ7XG4gICAgICAgICAgaWYgKGlzUGxhaW5LZXlSYW5nZShjdHgpKSB7XG4gICAgICAgICAgICAgIGFkZFJlcGxheUZpbHRlcihjdHgsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBvZmZzZXRMZWZ0ID0gb2Zmc2V0O1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChjdXJzb3IsIGFkdmFuY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAob2Zmc2V0TGVmdCA9PT0gMClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKG9mZnNldExlZnQgPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLS1vZmZzZXRMZWZ0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGFkdmFuY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3IuYWR2YW5jZShvZmZzZXRMZWZ0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb2Zmc2V0TGVmdCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICBhZGRSZXBsYXlGaWx0ZXIoY3R4LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgb2Zmc2V0TGVmdCA9IG9mZnNldDtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7IHJldHVybiAtLW9mZnNldExlZnQgPCAwOyB9O1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUubGltaXQgPSBmdW5jdGlvbiAobnVtUm93cykge1xuICAgICAgICAgIHRoaXMuX2N0eC5saW1pdCA9IE1hdGgubWluKHRoaXMuX2N0eC5saW1pdCwgbnVtUm93cyk7XG4gICAgICAgICAgYWRkUmVwbGF5RmlsdGVyKHRoaXMuX2N0eCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICB2YXIgcm93c0xlZnQgPSBudW1Sb3dzO1xuICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKGN1cnNvciwgYWR2YW5jZSwgcmVzb2x2ZSkge1xuICAgICAgICAgICAgICAgICAgaWYgKC0tcm93c0xlZnQgPD0gMClcbiAgICAgICAgICAgICAgICAgICAgICBhZHZhbmNlKHJlc29sdmUpO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHJvd3NMZWZ0ID49IDA7XG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgfSwgdHJ1ZSk7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUudW50aWwgPSBmdW5jdGlvbiAoZmlsdGVyRnVuY3Rpb24sIGJJbmNsdWRlU3RvcEVudHJ5KSB7XG4gICAgICAgICAgYWRkRmlsdGVyKHRoaXMuX2N0eCwgZnVuY3Rpb24gKGN1cnNvciwgYWR2YW5jZSwgcmVzb2x2ZSkge1xuICAgICAgICAgICAgICBpZiAoZmlsdGVyRnVuY3Rpb24oY3Vyc29yLnZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgYWR2YW5jZShyZXNvbHZlKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBiSW5jbHVkZVN0b3BFbnRyeTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUuZmlyc3QgPSBmdW5jdGlvbiAoY2IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5saW1pdCgxKVxuICAgICAgICAgICAgICAudG9BcnJheShmdW5jdGlvbiAoYSkge1xuICAgICAgICAgICAgICByZXR1cm4gYVswXTtcbiAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGhlbihjYik7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUubGFzdCA9IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgIHJldHVybiB0aGlzLnJldmVyc2UoKS5maXJzdChjYik7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUuZmlsdGVyID0gZnVuY3Rpb24gKGZpbHRlckZ1bmN0aW9uKSB7XG4gICAgICAgICAgYWRkRmlsdGVyKHRoaXMuX2N0eCwgZnVuY3Rpb24gKGN1cnNvcikge1xuICAgICAgICAgICAgICByZXR1cm4gZmlsdGVyRnVuY3Rpb24oY3Vyc29yLnZhbHVlKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBhZGRNYXRjaEZpbHRlcih0aGlzLl9jdHgsIGZpbHRlckZ1bmN0aW9uKTtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5hbmQgPSBmdW5jdGlvbiAoZmlsdGVyKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuZmlsdGVyKGZpbHRlcik7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUub3IgPSBmdW5jdGlvbiAoaW5kZXhOYW1lKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyB0aGlzLmRiLldoZXJlQ2xhdXNlKHRoaXMuX2N0eC50YWJsZSwgaW5kZXhOYW1lLCB0aGlzKTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5yZXZlcnNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHRoaXMuX2N0eC5kaXIgPSB0aGlzLl9jdHguZGlyID09PSAncHJldicgPyAnbmV4dCcgOiAncHJldic7XG4gICAgICAgICAgaWYgKHRoaXMuX29uZGlyZWN0aW9uY2hhbmdlKVxuICAgICAgICAgICAgICB0aGlzLl9vbmRpcmVjdGlvbmNoYW5nZSh0aGlzLl9jdHguZGlyKTtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5kZXNjID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiB0aGlzLnJldmVyc2UoKTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5lYWNoS2V5ID0gZnVuY3Rpb24gKGNiKSB7XG4gICAgICAgICAgdmFyIGN0eCA9IHRoaXMuX2N0eDtcbiAgICAgICAgICBjdHgua2V5c09ubHkgPSAhY3R4LmlzTWF0Y2g7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbiAodmFsLCBjdXJzb3IpIHtcbiAgICAgICAgICAgICAgY2IoY3Vyc29yLmtleSwgY3Vyc29yKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5lYWNoVW5pcXVlS2V5ID0gZnVuY3Rpb24gKGNiKSB7XG4gICAgICAgICAgdGhpcy5fY3R4LnVuaXF1ZSA9ICd1bmlxdWUnO1xuICAgICAgICAgIHJldHVybiB0aGlzLmVhY2hLZXkoY2IpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLmVhY2hQcmltYXJ5S2V5ID0gZnVuY3Rpb24gKGNiKSB7XG4gICAgICAgICAgdmFyIGN0eCA9IHRoaXMuX2N0eDtcbiAgICAgICAgICBjdHgua2V5c09ubHkgPSAhY3R4LmlzTWF0Y2g7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbiAodmFsLCBjdXJzb3IpIHtcbiAgICAgICAgICAgICAgY2IoY3Vyc29yLnByaW1hcnlLZXksIGN1cnNvcik7XG4gICAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUua2V5cyA9IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgIHZhciBjdHggPSB0aGlzLl9jdHg7XG4gICAgICAgICAgY3R4LmtleXNPbmx5ID0gIWN0eC5pc01hdGNoO1xuICAgICAgICAgIHZhciBhID0gW107XG4gICAgICAgICAgcmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbiAoaXRlbSwgY3Vyc29yKSB7XG4gICAgICAgICAgICAgIGEucHVzaChjdXJzb3Iua2V5KTtcbiAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBhO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50aGVuKGNiKTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5wcmltYXJ5S2V5cyA9IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgIHZhciBjdHggPSB0aGlzLl9jdHg7XG4gICAgICAgICAgaWYgKGlzUGxhaW5LZXlSYW5nZShjdHgsIHRydWUpICYmIGN0eC5saW1pdCA+IDApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3JlYWQoZnVuY3Rpb24gKHRyYW5zKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSBnZXRJbmRleE9yU3RvcmUoY3R4LCBjdHgudGFibGUuY29yZS5zY2hlbWEpO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGN0eC50YWJsZS5jb3JlLnF1ZXJ5KHtcbiAgICAgICAgICAgICAgICAgICAgICB0cmFuczogdHJhbnMsXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWVzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICBsaW1pdDogY3R4LmxpbWl0LFxuICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdGlvbjogY3R4LmRpciA9PT0gJ3ByZXYnID8gJ3ByZXYnIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4OiBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmFuZ2U6IGN0eC5yYW5nZSxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSBfYS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgLnRoZW4oY2IpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjdHgua2V5c09ubHkgPSAhY3R4LmlzTWF0Y2g7XG4gICAgICAgICAgdmFyIGEgPSBbXTtcbiAgICAgICAgICByZXR1cm4gdGhpcy5lYWNoKGZ1bmN0aW9uIChpdGVtLCBjdXJzb3IpIHtcbiAgICAgICAgICAgICAgYS5wdXNoKGN1cnNvci5wcmltYXJ5S2V5KTtcbiAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBhO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50aGVuKGNiKTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS51bmlxdWVLZXlzID0gZnVuY3Rpb24gKGNiKSB7XG4gICAgICAgICAgdGhpcy5fY3R4LnVuaXF1ZSA9ICd1bmlxdWUnO1xuICAgICAgICAgIHJldHVybiB0aGlzLmtleXMoY2IpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLmZpcnN0S2V5ID0gZnVuY3Rpb24gKGNiKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMubGltaXQoMSlcbiAgICAgICAgICAgICAgLmtleXMoZnVuY3Rpb24gKGEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGFbMF07XG4gICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnRoZW4oY2IpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLmxhc3RLZXkgPSBmdW5jdGlvbiAoY2IpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5yZXZlcnNlKCkuZmlyc3RLZXkoY2IpO1xuICAgICAgfTtcbiAgICAgIENvbGxlY3Rpb24ucHJvdG90eXBlLmRpc3RpbmN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBjdHggPSB0aGlzLl9jdHgsIGlkeCA9IGN0eC5pbmRleCAmJiBjdHgudGFibGUuc2NoZW1hLmlkeEJ5TmFtZVtjdHguaW5kZXhdO1xuICAgICAgICAgIGlmICghaWR4IHx8ICFpZHgubXVsdGkpXG4gICAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgIHZhciBzZXQgPSB7fTtcbiAgICAgICAgICBhZGRGaWx0ZXIodGhpcy5fY3R4LCBmdW5jdGlvbiAoY3Vyc29yKSB7XG4gICAgICAgICAgICAgIHZhciBzdHJLZXkgPSBjdXJzb3IucHJpbWFyeUtleS50b1N0cmluZygpO1xuICAgICAgICAgICAgICB2YXIgZm91bmQgPSBoYXNPd24oc2V0LCBzdHJLZXkpO1xuICAgICAgICAgICAgICBzZXRbc3RyS2V5XSA9IHRydWU7XG4gICAgICAgICAgICAgIHJldHVybiAhZm91bmQ7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgQ29sbGVjdGlvbi5wcm90b3R5cGUubW9kaWZ5ID0gZnVuY3Rpb24gKGNoYW5nZXMpIHtcbiAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgIHZhciBjdHggPSB0aGlzLl9jdHg7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3dyaXRlKGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICB2YXIgbW9kaWZ5ZXI7XG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgY2hhbmdlcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgbW9kaWZ5ZXIgPSBjaGFuZ2VzO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgbW9kaWZ5ZXIgPSBmdW5jdGlvbiAoaXRlbSkgeyByZXR1cm4gYXBwbHlVcGRhdGVTcGVjKGl0ZW0sIGNoYW5nZXMpOyB9O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHZhciBjb3JlVGFibGUgPSBjdHgudGFibGUuY29yZTtcbiAgICAgICAgICAgICAgdmFyIF9hID0gY29yZVRhYmxlLnNjaGVtYS5wcmltYXJ5S2V5LCBvdXRib3VuZCA9IF9hLm91dGJvdW5kLCBleHRyYWN0S2V5ID0gX2EuZXh0cmFjdEtleTtcbiAgICAgICAgICAgICAgdmFyIGxpbWl0ID0gMjAwO1xuICAgICAgICAgICAgICB2YXIgbW9kaWZ5Q2h1bmtTaXplID0gX3RoaXMuZGIuX29wdGlvbnMubW9kaWZ5Q2h1bmtTaXplO1xuICAgICAgICAgICAgICBpZiAobW9kaWZ5Q2h1bmtTaXplKSB7XG4gICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1vZGlmeUNodW5rU2l6ZSA9PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICAgIGxpbWl0ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kaWZ5Q2h1bmtTaXplW2NvcmVUYWJsZS5uYW1lXSB8fCBtb2RpZnlDaHVua1NpemVbJyonXSB8fCAyMDA7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICBsaW1pdCA9IG1vZGlmeUNodW5rU2l6ZTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB2YXIgdG90YWxGYWlsdXJlcyA9IFtdO1xuICAgICAgICAgICAgICB2YXIgc3VjY2Vzc0NvdW50ID0gMDtcbiAgICAgICAgICAgICAgdmFyIGZhaWxlZEtleXMgPSBbXTtcbiAgICAgICAgICAgICAgdmFyIGFwcGx5TXV0YXRlUmVzdWx0ID0gZnVuY3Rpb24gKGV4cGVjdGVkQ291bnQsIHJlcykge1xuICAgICAgICAgICAgICAgICAgdmFyIGZhaWx1cmVzID0gcmVzLmZhaWx1cmVzLCBudW1GYWlsdXJlcyA9IHJlcy5udW1GYWlsdXJlcztcbiAgICAgICAgICAgICAgICAgIHN1Y2Nlc3NDb3VudCArPSBleHBlY3RlZENvdW50IC0gbnVtRmFpbHVyZXM7XG4gICAgICAgICAgICAgICAgICBmb3IgKHZhciBfaSA9IDAsIF9hID0ga2V5cyhmYWlsdXJlcyk7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIHBvcyA9IF9hW19pXTtcbiAgICAgICAgICAgICAgICAgICAgICB0b3RhbEZhaWx1cmVzLnB1c2goZmFpbHVyZXNbcG9zXSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgIHZhciBpc1VuY29uZGl0aW9uYWxEZWxldGUgPSBjaGFuZ2VzID09PSBkZWxldGVDYWxsYmFjaztcbiAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmNsb25lKClcbiAgICAgICAgICAgICAgICAgIC5wcmltYXJ5S2V5cygpXG4gICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoa2V5cykge1xuICAgICAgICAgICAgICAgICAgdmFyIGNyaXRlcmlhID0gaXNQbGFpbktleVJhbmdlKGN0eCkgJiZcbiAgICAgICAgICAgICAgICAgICAgICBjdHgubGltaXQgPT09IEluZmluaXR5ICYmXG4gICAgICAgICAgICAgICAgICAgICAgKHR5cGVvZiBjaGFuZ2VzICE9PSAnZnVuY3Rpb24nIHx8IGlzVW5jb25kaXRpb25hbERlbGV0ZSkgJiYge1xuICAgICAgICAgICAgICAgICAgICAgIGluZGV4OiBjdHguaW5kZXgsXG4gICAgICAgICAgICAgICAgICAgICAgcmFuZ2U6IGN0eC5yYW5nZSxcbiAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICB2YXIgbmV4dENodW5rID0gZnVuY3Rpb24gKG9mZnNldCkge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBjb3VudCA9IE1hdGgubWluKGxpbWl0LCBrZXlzLmxlbmd0aCAtIG9mZnNldCk7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGtleXNJbkNodW5rID0ga2V5cy5zbGljZShvZmZzZXQsIG9mZnNldCArIGNvdW50KTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKGlzVW5jb25kaXRpb25hbERlbGV0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFByb21pc2UucmVzb2x2ZShbXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBjb3JlVGFibGUuZ2V0TWFueSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuczogdHJhbnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXlzOiBrZXlzSW5DaHVuayxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhY2hlOiAnaW1tdXRhYmxlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpLnRoZW4oZnVuY3Rpb24gKHZhbHVlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYWRkVmFsdWVzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwdXRWYWx1ZXMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHB1dEtleXMgPSBvdXRib3VuZCA/IFtdIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRlbGV0ZUtleXMgPSBpc1VuY29uZGl0aW9uYWxEZWxldGUgPyBrZXlzSW5DaHVuayA6IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzVW5jb25kaXRpb25hbERlbGV0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY291bnQ7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBvcmlnVmFsdWUgPSB2YWx1ZXNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGN0eF8xID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZGVlcENsb25lKG9yaWdWYWx1ZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW1LZXk6IGtleXNbb2Zmc2V0ICsgaV0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobW9kaWZ5ZXIuY2FsbChjdHhfMSwgY3R4XzEudmFsdWUsIGN0eF8xKSAhPT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGN0eF8xLnZhbHVlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZUtleXMucHVzaChrZXlzW29mZnNldCArIGldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICghb3V0Ym91bmQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNtcChleHRyYWN0S2V5KG9yaWdWYWx1ZSksIGV4dHJhY3RLZXkoY3R4XzEudmFsdWUpKSAhPT0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlS2V5cy5wdXNoKGtleXNbb2Zmc2V0ICsgaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkVmFsdWVzLnB1c2goY3R4XzEudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHV0VmFsdWVzLnB1c2goY3R4XzEudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG91dGJvdW5kKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB1dEtleXMucHVzaChrZXlzW29mZnNldCArIGldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShhZGRWYWx1ZXMubGVuZ3RoID4gMCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29yZVRhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLm11dGF0ZSh7IHRyYW5zOiB0cmFucywgdHlwZTogJ2FkZCcsIHZhbHVlczogYWRkVmFsdWVzIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIHBvcyBpbiByZXMuZmFpbHVyZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlS2V5cy5zcGxpY2UocGFyc2VJbnQocG9zKSwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcGx5TXV0YXRlUmVzdWx0KGFkZFZhbHVlcy5sZW5ndGgsIHJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAocHV0VmFsdWVzLmxlbmd0aCA+IDAgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY3JpdGVyaWEgJiYgdHlwZW9mIGNoYW5nZXMgPT09ICdvYmplY3QnKSkgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3JlVGFibGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLm11dGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3B1dCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleXM6IHB1dEtleXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogcHV0VmFsdWVzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjcml0ZXJpYTogY3JpdGVyaWEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoYW5nZVNwZWM6IHR5cGVvZiBjaGFuZ2VzICE9PSAnZnVuY3Rpb24nICYmIGNoYW5nZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWRkaXRpb25hbENodW5rOiBvZmZzZXQgPiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXMpIHsgcmV0dXJuIGFwcGx5TXV0YXRlUmVzdWx0KHB1dFZhbHVlcy5sZW5ndGgsIHJlcyk7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChkZWxldGVLZXlzLmxlbmd0aCA+IDAgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY3JpdGVyaWEgJiYgaXNVbmNvbmRpdGlvbmFsRGVsZXRlKSkgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3JlVGFibGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLm11dGF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2RlbGV0ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleXM6IGRlbGV0ZUtleXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNyaXRlcmlhOiBjcml0ZXJpYSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBZGRpdGlvbmFsQ2h1bms6IG9mZnNldCA+IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYnVpbHRJbkRlbGV0aW9uVHJpZ2dlcihjdHgudGFibGUsIGRlbGV0ZUtleXMsIHJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlcykgeyByZXR1cm4gYXBwbHlNdXRhdGVSZXN1bHQoZGVsZXRlS2V5cy5sZW5ndGgsIHJlcyk7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChrZXlzLmxlbmd0aCA+IG9mZnNldCArIGNvdW50ICYmIG5leHRDaHVuayhvZmZzZXQgKyBsaW1pdCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICByZXR1cm4gbmV4dENodW5rKDApLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIGlmICh0b3RhbEZhaWx1cmVzLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBNb2RpZnlFcnJvcignRXJyb3IgbW9kaWZ5aW5nIG9uZSBvciBtb3JlIG9iamVjdHMnLCB0b3RhbEZhaWx1cmVzLCBzdWNjZXNzQ291bnQsIGZhaWxlZEtleXMpO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBrZXlzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBDb2xsZWN0aW9uLnByb3RvdHlwZS5kZWxldGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIGN0eCA9IHRoaXMuX2N0eCwgcmFuZ2UgPSBjdHgucmFuZ2U7XG4gICAgICAgICAgaWYgKGlzUGxhaW5LZXlSYW5nZShjdHgpICYmXG4gICAgICAgICAgICAgICFjdHgudGFibGUuc2NoZW1hLnlQcm9wcyAmJlxuICAgICAgICAgICAgICAoY3R4LmlzUHJpbUtleSB8fCByYW5nZS50eXBlID09PSAzICkpXG4gICAgICAgICAgIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3dyaXRlKGZ1bmN0aW9uICh0cmFucykge1xuICAgICAgICAgICAgICAgICAgdmFyIHByaW1hcnlLZXkgPSBjdHgudGFibGUuY29yZS5zY2hlbWEucHJpbWFyeUtleTtcbiAgICAgICAgICAgICAgICAgIHZhciBjb3JlUmFuZ2UgPSByYW5nZTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjdHgudGFibGUuY29yZVxuICAgICAgICAgICAgICAgICAgICAgIC5jb3VudCh7IHRyYW5zOiB0cmFucywgcXVlcnk6IHsgaW5kZXg6IHByaW1hcnlLZXksIHJhbmdlOiBjb3JlUmFuZ2UgfSB9KVxuICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChjb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjdHgudGFibGUuY29yZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAubXV0YXRlKHsgdHJhbnM6IHRyYW5zLCB0eXBlOiAnZGVsZXRlUmFuZ2UnLCByYW5nZTogY29yZVJhbmdlIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmFpbHVyZXMgPSBfYS5mYWlsdXJlcywgbnVtRmFpbHVyZXMgPSBfYS5udW1GYWlsdXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG51bUZhaWx1cmVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1vZGlmeUVycm9yKCdDb3VsZCBub3QgZGVsZXRlIHNvbWUgdmFsdWVzJywgT2JqZWN0LmtleXMoZmFpbHVyZXMpLm1hcChmdW5jdGlvbiAocG9zKSB7IHJldHVybiBmYWlsdXJlc1twb3NdOyB9KSwgY291bnQgLSBudW1GYWlsdXJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjb3VudCAtIG51bUZhaWx1cmVzO1xuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdGhpcy5tb2RpZnkoZGVsZXRlQ2FsbGJhY2spO1xuICAgICAgfTtcbiAgICAgIHJldHVybiBDb2xsZWN0aW9uO1xuICB9KCkpO1xuICB2YXIgZGVsZXRlQ2FsbGJhY2sgPSBmdW5jdGlvbiAodmFsdWUsIGN0eCkgeyByZXR1cm4gKGN0eC52YWx1ZSA9IG51bGwpOyB9O1xuXG4gIGZ1bmN0aW9uIGNyZWF0ZUNvbGxlY3Rpb25Db25zdHJ1Y3RvcihkYikge1xuICAgICAgcmV0dXJuIG1ha2VDbGFzc0NvbnN0cnVjdG9yKENvbGxlY3Rpb24ucHJvdG90eXBlLCBmdW5jdGlvbiBDb2xsZWN0aW9uKHdoZXJlQ2xhdXNlLCBrZXlSYW5nZUdlbmVyYXRvcikge1xuICAgICAgICAgIHRoaXMuZGIgPSBkYjtcbiAgICAgICAgICB2YXIga2V5UmFuZ2UgPSBBbnlSYW5nZSwgZXJyb3IgPSBudWxsO1xuICAgICAgICAgIGlmIChrZXlSYW5nZUdlbmVyYXRvcilcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIGtleVJhbmdlID0ga2V5UmFuZ2VHZW5lcmF0b3IoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgICAgICAgIGVycm9yID0gZXg7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgd2hlcmVDdHggPSB3aGVyZUNsYXVzZS5fY3R4O1xuICAgICAgICAgIHZhciB0YWJsZSA9IHdoZXJlQ3R4LnRhYmxlO1xuICAgICAgICAgIHZhciByZWFkaW5nSG9vayA9IHRhYmxlLmhvb2sucmVhZGluZy5maXJlO1xuICAgICAgICAgIHRoaXMuX2N0eCA9IHtcbiAgICAgICAgICAgICAgdGFibGU6IHRhYmxlLFxuICAgICAgICAgICAgICBpbmRleDogd2hlcmVDdHguaW5kZXgsXG4gICAgICAgICAgICAgIGlzUHJpbUtleTogIXdoZXJlQ3R4LmluZGV4IHx8XG4gICAgICAgICAgICAgICAgICAodGFibGUuc2NoZW1hLnByaW1LZXkua2V5UGF0aCAmJlxuICAgICAgICAgICAgICAgICAgICAgIHdoZXJlQ3R4LmluZGV4ID09PSB0YWJsZS5zY2hlbWEucHJpbUtleS5uYW1lKSxcbiAgICAgICAgICAgICAgcmFuZ2U6IGtleVJhbmdlLFxuICAgICAgICAgICAgICBrZXlzT25seTogZmFsc2UsXG4gICAgICAgICAgICAgIGRpcjogJ25leHQnLFxuICAgICAgICAgICAgICB1bmlxdWU6ICcnLFxuICAgICAgICAgICAgICBhbGdvcml0aG06IG51bGwsXG4gICAgICAgICAgICAgIGZpbHRlcjogbnVsbCxcbiAgICAgICAgICAgICAgcmVwbGF5RmlsdGVyOiBudWxsLFxuICAgICAgICAgICAgICBqdXN0TGltaXQ6IHRydWUsXG4gICAgICAgICAgICAgIGlzTWF0Y2g6IG51bGwsXG4gICAgICAgICAgICAgIG9mZnNldDogMCxcbiAgICAgICAgICAgICAgbGltaXQ6IEluZmluaXR5LFxuICAgICAgICAgICAgICBlcnJvcjogZXJyb3IsXG4gICAgICAgICAgICAgIG9yOiB3aGVyZUN0eC5vcixcbiAgICAgICAgICAgICAgdmFsdWVNYXBwZXI6IHJlYWRpbmdIb29rICE9PSBtaXJyb3IgPyByZWFkaW5nSG9vayA6IG51bGwsXG4gICAgICAgICAgfTtcbiAgICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gc2ltcGxlQ29tcGFyZShhLCBiKSB7XG4gICAgICByZXR1cm4gYSA8IGIgPyAtMSA6IGEgPT09IGIgPyAwIDogMTtcbiAgfVxuICBmdW5jdGlvbiBzaW1wbGVDb21wYXJlUmV2ZXJzZShhLCBiKSB7XG4gICAgICByZXR1cm4gYSA+IGIgPyAtMSA6IGEgPT09IGIgPyAwIDogMTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGZhaWwoY29sbGVjdGlvbk9yV2hlcmVDbGF1c2UsIGVyciwgVCkge1xuICAgICAgdmFyIGNvbGxlY3Rpb24gPSBjb2xsZWN0aW9uT3JXaGVyZUNsYXVzZSBpbnN0YW5jZW9mIFdoZXJlQ2xhdXNlXG4gICAgICAgICAgPyBuZXcgY29sbGVjdGlvbk9yV2hlcmVDbGF1c2UuQ29sbGVjdGlvbihjb2xsZWN0aW9uT3JXaGVyZUNsYXVzZSlcbiAgICAgICAgICA6IGNvbGxlY3Rpb25PcldoZXJlQ2xhdXNlO1xuICAgICAgY29sbGVjdGlvbi5fY3R4LmVycm9yID0gVCA/IG5ldyBUKGVycikgOiBuZXcgVHlwZUVycm9yKGVycik7XG4gICAgICByZXR1cm4gY29sbGVjdGlvbjtcbiAgfVxuICBmdW5jdGlvbiBlbXB0eUNvbGxlY3Rpb24od2hlcmVDbGF1c2UpIHtcbiAgICAgIHJldHVybiBuZXcgd2hlcmVDbGF1c2UuQ29sbGVjdGlvbih3aGVyZUNsYXVzZSwgZnVuY3Rpb24gKCkgeyByZXR1cm4gcmFuZ2VFcXVhbCgnJyk7IH0pLmxpbWl0KDApO1xuICB9XG4gIGZ1bmN0aW9uIHVwcGVyRmFjdG9yeShkaXIpIHtcbiAgICAgIHJldHVybiBkaXIgPT09ICduZXh0J1xuICAgICAgICAgID8gZnVuY3Rpb24gKHMpIHsgcmV0dXJuIHMudG9VcHBlckNhc2UoKTsgfVxuICAgICAgICAgIDogZnVuY3Rpb24gKHMpIHsgcmV0dXJuIHMudG9Mb3dlckNhc2UoKTsgfTtcbiAgfVxuICBmdW5jdGlvbiBsb3dlckZhY3RvcnkoZGlyKSB7XG4gICAgICByZXR1cm4gZGlyID09PSAnbmV4dCdcbiAgICAgICAgICA/IGZ1bmN0aW9uIChzKSB7IHJldHVybiBzLnRvTG93ZXJDYXNlKCk7IH1cbiAgICAgICAgICA6IGZ1bmN0aW9uIChzKSB7IHJldHVybiBzLnRvVXBwZXJDYXNlKCk7IH07XG4gIH1cbiAgZnVuY3Rpb24gbmV4dENhc2luZyhrZXksIGxvd2VyS2V5LCB1cHBlck5lZWRsZSwgbG93ZXJOZWVkbGUsIGNtcCwgZGlyKSB7XG4gICAgICB2YXIgbGVuZ3RoID0gTWF0aC5taW4oa2V5Lmxlbmd0aCwgbG93ZXJOZWVkbGUubGVuZ3RoKTtcbiAgICAgIHZhciBsbHAgPSAtMTtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICB2YXIgbHdyS2V5Q2hhciA9IGxvd2VyS2V5W2ldO1xuICAgICAgICAgIGlmIChsd3JLZXlDaGFyICE9PSBsb3dlck5lZWRsZVtpXSkge1xuICAgICAgICAgICAgICBpZiAoY21wKGtleVtpXSwgdXBwZXJOZWVkbGVbaV0pIDwgMClcbiAgICAgICAgICAgICAgICAgIHJldHVybiBrZXkuc3Vic3RyKDAsIGkpICsgdXBwZXJOZWVkbGVbaV0gKyB1cHBlck5lZWRsZS5zdWJzdHIoaSArIDEpO1xuICAgICAgICAgICAgICBpZiAoY21wKGtleVtpXSwgbG93ZXJOZWVkbGVbaV0pIDwgMClcbiAgICAgICAgICAgICAgICAgIHJldHVybiBrZXkuc3Vic3RyKDAsIGkpICsgbG93ZXJOZWVkbGVbaV0gKyB1cHBlck5lZWRsZS5zdWJzdHIoaSArIDEpO1xuICAgICAgICAgICAgICBpZiAobGxwID49IDApXG4gICAgICAgICAgICAgICAgICByZXR1cm4ga2V5LnN1YnN0cigwLCBsbHApICsgbG93ZXJLZXlbbGxwXSArIHVwcGVyTmVlZGxlLnN1YnN0cihsbHAgKyAxKTtcbiAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChjbXAoa2V5W2ldLCBsd3JLZXlDaGFyKSA8IDApXG4gICAgICAgICAgICAgIGxscCA9IGk7XG4gICAgICB9XG4gICAgICBpZiAobGVuZ3RoIDwgbG93ZXJOZWVkbGUubGVuZ3RoICYmIGRpciA9PT0gJ25leHQnKVxuICAgICAgICAgIHJldHVybiBrZXkgKyB1cHBlck5lZWRsZS5zdWJzdHIoa2V5Lmxlbmd0aCk7XG4gICAgICBpZiAobGVuZ3RoIDwga2V5Lmxlbmd0aCAmJiBkaXIgPT09ICdwcmV2JylcbiAgICAgICAgICByZXR1cm4ga2V5LnN1YnN0cigwLCB1cHBlck5lZWRsZS5sZW5ndGgpO1xuICAgICAgcmV0dXJuIGxscCA8IDBcbiAgICAgICAgICA/IG51bGxcbiAgICAgICAgICA6IGtleS5zdWJzdHIoMCwgbGxwKSArIGxvd2VyTmVlZGxlW2xscF0gKyB1cHBlck5lZWRsZS5zdWJzdHIobGxwICsgMSk7XG4gIH1cbiAgZnVuY3Rpb24gYWRkSWdub3JlQ2FzZUFsZ29yaXRobSh3aGVyZUNsYXVzZSwgbWF0Y2gsIG5lZWRsZXMsIHN1ZmZpeCkge1xuICAgICAgdmFyIHVwcGVyLCBsb3dlciwgY29tcGFyZSwgdXBwZXJOZWVkbGVzLCBsb3dlck5lZWRsZXMsIGRpcmVjdGlvbiwgbmV4dEtleVN1ZmZpeCwgbmVlZGxlc0xlbiA9IG5lZWRsZXMubGVuZ3RoO1xuICAgICAgaWYgKCFuZWVkbGVzLmV2ZXJ5KGZ1bmN0aW9uIChzKSB7IHJldHVybiB0eXBlb2YgcyA9PT0gJ3N0cmluZyc7IH0pKSB7XG4gICAgICAgICAgcmV0dXJuIGZhaWwod2hlcmVDbGF1c2UsIFNUUklOR19FWFBFQ1RFRCk7XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiBpbml0RGlyZWN0aW9uKGRpcikge1xuICAgICAgICAgIHVwcGVyID0gdXBwZXJGYWN0b3J5KGRpcik7XG4gICAgICAgICAgbG93ZXIgPSBsb3dlckZhY3RvcnkoZGlyKTtcbiAgICAgICAgICBjb21wYXJlID0gZGlyID09PSAnbmV4dCcgPyBzaW1wbGVDb21wYXJlIDogc2ltcGxlQ29tcGFyZVJldmVyc2U7XG4gICAgICAgICAgdmFyIG5lZWRsZUJvdW5kcyA9IG5lZWRsZXNcbiAgICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAobmVlZGxlKSB7XG4gICAgICAgICAgICAgIHJldHVybiB7IGxvd2VyOiBsb3dlcihuZWVkbGUpLCB1cHBlcjogdXBwZXIobmVlZGxlKSB9O1xuICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICAgICAgICAgIHJldHVybiBjb21wYXJlKGEubG93ZXIsIGIubG93ZXIpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIHVwcGVyTmVlZGxlcyA9IG5lZWRsZUJvdW5kcy5tYXAoZnVuY3Rpb24gKG5iKSB7XG4gICAgICAgICAgICAgIHJldHVybiBuYi51cHBlcjtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBsb3dlck5lZWRsZXMgPSBuZWVkbGVCb3VuZHMubWFwKGZ1bmN0aW9uIChuYikge1xuICAgICAgICAgICAgICByZXR1cm4gbmIubG93ZXI7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgZGlyZWN0aW9uID0gZGlyO1xuICAgICAgICAgIG5leHRLZXlTdWZmaXggPSBkaXIgPT09ICduZXh0JyA/ICcnIDogc3VmZml4O1xuICAgICAgfVxuICAgICAgaW5pdERpcmVjdGlvbignbmV4dCcpO1xuICAgICAgdmFyIGMgPSBuZXcgd2hlcmVDbGF1c2UuQ29sbGVjdGlvbih3aGVyZUNsYXVzZSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiBjcmVhdGVSYW5nZSh1cHBlck5lZWRsZXNbMF0sIGxvd2VyTmVlZGxlc1tuZWVkbGVzTGVuIC0gMV0gKyBzdWZmaXgpO1xuICAgICAgfSk7XG4gICAgICBjLl9vbmRpcmVjdGlvbmNoYW5nZSA9IGZ1bmN0aW9uIChkaXJlY3Rpb24pIHtcbiAgICAgICAgICBpbml0RGlyZWN0aW9uKGRpcmVjdGlvbik7XG4gICAgICB9O1xuICAgICAgdmFyIGZpcnN0UG9zc2libGVOZWVkbGUgPSAwO1xuICAgICAgYy5fYWRkQWxnb3JpdGhtKGZ1bmN0aW9uIChjdXJzb3IsIGFkdmFuY2UsIHJlc29sdmUpIHtcbiAgICAgICAgICB2YXIga2V5ID0gY3Vyc29yLmtleTtcbiAgICAgICAgICBpZiAodHlwZW9mIGtleSAhPT0gJ3N0cmluZycpXG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB2YXIgbG93ZXJLZXkgPSBsb3dlcihrZXkpO1xuICAgICAgICAgIGlmIChtYXRjaChsb3dlcktleSwgbG93ZXJOZWVkbGVzLCBmaXJzdFBvc3NpYmxlTmVlZGxlKSkge1xuICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgIHZhciBsb3dlc3RQb3NzaWJsZUNhc2luZyA9IG51bGw7XG4gICAgICAgICAgICAgIGZvciAodmFyIGkgPSBmaXJzdFBvc3NpYmxlTmVlZGxlOyBpIDwgbmVlZGxlc0xlbjsgKytpKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgY2FzaW5nID0gbmV4dENhc2luZyhrZXksIGxvd2VyS2V5LCB1cHBlck5lZWRsZXNbaV0sIGxvd2VyTmVlZGxlc1tpXSwgY29tcGFyZSwgZGlyZWN0aW9uKTtcbiAgICAgICAgICAgICAgICAgIGlmIChjYXNpbmcgPT09IG51bGwgJiYgbG93ZXN0UG9zc2libGVDYXNpbmcgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgZmlyc3RQb3NzaWJsZU5lZWRsZSA9IGkgKyAxO1xuICAgICAgICAgICAgICAgICAgZWxzZSBpZiAobG93ZXN0UG9zc2libGVDYXNpbmcgPT09IG51bGwgfHxcbiAgICAgICAgICAgICAgICAgICAgICBjb21wYXJlKGxvd2VzdFBvc3NpYmxlQ2FzaW5nLCBjYXNpbmcpID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgIGxvd2VzdFBvc3NpYmxlQ2FzaW5nID0gY2FzaW5nO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmIChsb3dlc3RQb3NzaWJsZUNhc2luZyAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgYWR2YW5jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmNvbnRpbnVlKGxvd2VzdFBvc3NpYmxlQ2FzaW5nICsgbmV4dEtleVN1ZmZpeCk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGFkdmFuY2UocmVzb2x2ZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGM7XG4gIH1cbiAgZnVuY3Rpb24gY3JlYXRlUmFuZ2UobG93ZXIsIHVwcGVyLCBsb3dlck9wZW4sIHVwcGVyT3Blbikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0eXBlOiAyICxcbiAgICAgICAgICBsb3dlcjogbG93ZXIsXG4gICAgICAgICAgdXBwZXI6IHVwcGVyLFxuICAgICAgICAgIGxvd2VyT3BlbjogbG93ZXJPcGVuLFxuICAgICAgICAgIHVwcGVyT3BlbjogdXBwZXJPcGVuLFxuICAgICAgfTtcbiAgfVxuICBmdW5jdGlvbiByYW5nZUVxdWFsKHZhbHVlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAgIHR5cGU6IDEgLFxuICAgICAgICAgIGxvd2VyOiB2YWx1ZSxcbiAgICAgICAgICB1cHBlcjogdmFsdWUsXG4gICAgICB9O1xuICB9XG5cbiAgdmFyIFdoZXJlQ2xhdXNlID0gIChmdW5jdGlvbiAoKSB7XG4gICAgICBmdW5jdGlvbiBXaGVyZUNsYXVzZSgpIHtcbiAgICAgIH1cbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShXaGVyZUNsYXVzZS5wcm90b3R5cGUsIFwiQ29sbGVjdGlvblwiLCB7XG4gICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jdHgudGFibGUuZGIuQ29sbGVjdGlvbjtcbiAgICAgICAgICB9LFxuICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgICAgfSk7XG4gICAgICBXaGVyZUNsYXVzZS5wcm90b3R5cGUuYmV0d2VlbiA9IGZ1bmN0aW9uIChsb3dlciwgdXBwZXIsIGluY2x1ZGVMb3dlciwgaW5jbHVkZVVwcGVyKSB7XG4gICAgICAgICAgaW5jbHVkZUxvd2VyID0gaW5jbHVkZUxvd2VyICE9PSBmYWxzZTtcbiAgICAgICAgICBpbmNsdWRlVXBwZXIgPSBpbmNsdWRlVXBwZXIgPT09IHRydWU7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgaWYgKHRoaXMuX2NtcChsb3dlciwgdXBwZXIpID4gMCB8fFxuICAgICAgICAgICAgICAgICAgKHRoaXMuX2NtcChsb3dlciwgdXBwZXIpID09PSAwICYmXG4gICAgICAgICAgICAgICAgICAgICAgKGluY2x1ZGVMb3dlciB8fCBpbmNsdWRlVXBwZXIpICYmXG4gICAgICAgICAgICAgICAgICAgICAgIShpbmNsdWRlTG93ZXIgJiYgaW5jbHVkZVVwcGVyKSkpXG4gICAgICAgICAgICAgICAgICByZXR1cm4gZW1wdHlDb2xsZWN0aW9uKHRoaXMpO1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IHRoaXMuQ29sbGVjdGlvbih0aGlzLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gY3JlYXRlUmFuZ2UobG93ZXIsIHVwcGVyLCAhaW5jbHVkZUxvd2VyLCAhaW5jbHVkZVVwcGVyKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmYWlsKHRoaXMsIElOVkFMSURfS0VZX0FSR1VNRU5UKTtcbiAgICAgICAgICB9XG4gICAgICB9O1xuICAgICAgV2hlcmVDbGF1c2UucHJvdG90eXBlLmVxdWFscyA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgIGlmICh2YWx1ZSA9PSBudWxsKVxuICAgICAgICAgICAgICByZXR1cm4gZmFpbCh0aGlzLCBJTlZBTElEX0tFWV9BUkdVTUVOVCk7XG4gICAgICAgICAgcmV0dXJuIG5ldyB0aGlzLkNvbGxlY3Rpb24odGhpcywgZnVuY3Rpb24gKCkgeyByZXR1cm4gcmFuZ2VFcXVhbCh2YWx1ZSk7IH0pO1xuICAgICAgfTtcbiAgICAgIFdoZXJlQ2xhdXNlLnByb3RvdHlwZS5hYm92ZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgIGlmICh2YWx1ZSA9PSBudWxsKVxuICAgICAgICAgICAgICByZXR1cm4gZmFpbCh0aGlzLCBJTlZBTElEX0tFWV9BUkdVTUVOVCk7XG4gICAgICAgICAgcmV0dXJuIG5ldyB0aGlzLkNvbGxlY3Rpb24odGhpcywgZnVuY3Rpb24gKCkgeyByZXR1cm4gY3JlYXRlUmFuZ2UodmFsdWUsIHVuZGVmaW5lZCwgdHJ1ZSk7IH0pO1xuICAgICAgfTtcbiAgICAgIFdoZXJlQ2xhdXNlLnByb3RvdHlwZS5hYm92ZU9yRXF1YWwgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICBpZiAodmFsdWUgPT0gbnVsbClcbiAgICAgICAgICAgICAgcmV0dXJuIGZhaWwodGhpcywgSU5WQUxJRF9LRVlfQVJHVU1FTlQpO1xuICAgICAgICAgIHJldHVybiBuZXcgdGhpcy5Db2xsZWN0aW9uKHRoaXMsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNyZWF0ZVJhbmdlKHZhbHVlLCB1bmRlZmluZWQsIGZhbHNlKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBXaGVyZUNsYXVzZS5wcm90b3R5cGUuYmVsb3cgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICBpZiAodmFsdWUgPT0gbnVsbClcbiAgICAgICAgICAgICAgcmV0dXJuIGZhaWwodGhpcywgSU5WQUxJRF9LRVlfQVJHVU1FTlQpO1xuICAgICAgICAgIHJldHVybiBuZXcgdGhpcy5Db2xsZWN0aW9uKHRoaXMsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGNyZWF0ZVJhbmdlKHVuZGVmaW5lZCwgdmFsdWUsIGZhbHNlLCB0cnVlKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBXaGVyZUNsYXVzZS5wcm90b3R5cGUuYmVsb3dPckVxdWFsID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgaWYgKHZhbHVlID09IG51bGwpXG4gICAgICAgICAgICAgIHJldHVybiBmYWlsKHRoaXMsIElOVkFMSURfS0VZX0FSR1VNRU5UKTtcbiAgICAgICAgICByZXR1cm4gbmV3IHRoaXMuQ29sbGVjdGlvbih0aGlzLCBmdW5jdGlvbiAoKSB7IHJldHVybiBjcmVhdGVSYW5nZSh1bmRlZmluZWQsIHZhbHVlKTsgfSk7XG4gICAgICB9O1xuICAgICAgV2hlcmVDbGF1c2UucHJvdG90eXBlLnN0YXJ0c1dpdGggPSBmdW5jdGlvbiAoc3RyKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBzdHIgIT09ICdzdHJpbmcnKVxuICAgICAgICAgICAgICByZXR1cm4gZmFpbCh0aGlzLCBTVFJJTkdfRVhQRUNURUQpO1xuICAgICAgICAgIHJldHVybiB0aGlzLmJldHdlZW4oc3RyLCBzdHIgKyBtYXhTdHJpbmcsIHRydWUsIHRydWUpO1xuICAgICAgfTtcbiAgICAgIFdoZXJlQ2xhdXNlLnByb3RvdHlwZS5zdGFydHNXaXRoSWdub3JlQ2FzZSA9IGZ1bmN0aW9uIChzdHIpIHtcbiAgICAgICAgICBpZiAoc3RyID09PSAnJylcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuc3RhcnRzV2l0aChzdHIpO1xuICAgICAgICAgIHJldHVybiBhZGRJZ25vcmVDYXNlQWxnb3JpdGhtKHRoaXMsIGZ1bmN0aW9uICh4LCBhKSB7IHJldHVybiB4LmluZGV4T2YoYVswXSkgPT09IDA7IH0sIFtzdHJdLCBtYXhTdHJpbmcpO1xuICAgICAgfTtcbiAgICAgIFdoZXJlQ2xhdXNlLnByb3RvdHlwZS5lcXVhbHNJZ25vcmVDYXNlID0gZnVuY3Rpb24gKHN0cikge1xuICAgICAgICAgIHJldHVybiBhZGRJZ25vcmVDYXNlQWxnb3JpdGhtKHRoaXMsIGZ1bmN0aW9uICh4LCBhKSB7IHJldHVybiB4ID09PSBhWzBdOyB9LCBbc3RyXSwgJycpO1xuICAgICAgfTtcbiAgICAgIFdoZXJlQ2xhdXNlLnByb3RvdHlwZS5hbnlPZklnbm9yZUNhc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIHNldCA9IGdldEFycmF5T2YuYXBwbHkoTk9fQ0hBUl9BUlJBWSwgYXJndW1lbnRzKTtcbiAgICAgICAgICBpZiAoc2V0Lmxlbmd0aCA9PT0gMClcbiAgICAgICAgICAgICAgcmV0dXJuIGVtcHR5Q29sbGVjdGlvbih0aGlzKTtcbiAgICAgICAgICByZXR1cm4gYWRkSWdub3JlQ2FzZUFsZ29yaXRobSh0aGlzLCBmdW5jdGlvbiAoeCwgYSkgeyByZXR1cm4gYS5pbmRleE9mKHgpICE9PSAtMTsgfSwgc2V0LCAnJyk7XG4gICAgICB9O1xuICAgICAgV2hlcmVDbGF1c2UucHJvdG90eXBlLnN0YXJ0c1dpdGhBbnlPZklnbm9yZUNhc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIHNldCA9IGdldEFycmF5T2YuYXBwbHkoTk9fQ0hBUl9BUlJBWSwgYXJndW1lbnRzKTtcbiAgICAgICAgICBpZiAoc2V0Lmxlbmd0aCA9PT0gMClcbiAgICAgICAgICAgICAgcmV0dXJuIGVtcHR5Q29sbGVjdGlvbih0aGlzKTtcbiAgICAgICAgICByZXR1cm4gYWRkSWdub3JlQ2FzZUFsZ29yaXRobSh0aGlzLCBmdW5jdGlvbiAoeCwgYSkgeyByZXR1cm4gYS5zb21lKGZ1bmN0aW9uIChuKSB7IHJldHVybiB4LmluZGV4T2YobikgPT09IDA7IH0pOyB9LCBzZXQsIG1heFN0cmluZyk7XG4gICAgICB9O1xuICAgICAgV2hlcmVDbGF1c2UucHJvdG90eXBlLmFueU9mID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgdmFyIHNldCA9IGdldEFycmF5T2YuYXBwbHkoTk9fQ0hBUl9BUlJBWSwgYXJndW1lbnRzKTtcbiAgICAgICAgICB2YXIgY29tcGFyZSA9IHRoaXMuX2NtcDtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBzZXQuc29ydChjb21wYXJlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZhaWwodGhpcywgSU5WQUxJRF9LRVlfQVJHVU1FTlQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoc2V0Lmxlbmd0aCA9PT0gMClcbiAgICAgICAgICAgICAgcmV0dXJuIGVtcHR5Q29sbGVjdGlvbih0aGlzKTtcbiAgICAgICAgICB2YXIgYyA9IG5ldyB0aGlzLkNvbGxlY3Rpb24odGhpcywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICByZXR1cm4gY3JlYXRlUmFuZ2Uoc2V0WzBdLCBzZXRbc2V0Lmxlbmd0aCAtIDFdKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBjLl9vbmRpcmVjdGlvbmNoYW5nZSA9IGZ1bmN0aW9uIChkaXJlY3Rpb24pIHtcbiAgICAgICAgICAgICAgY29tcGFyZSA9IGRpcmVjdGlvbiA9PT0gJ25leHQnID8gX3RoaXMuX2FzY2VuZGluZyA6IF90aGlzLl9kZXNjZW5kaW5nO1xuICAgICAgICAgICAgICBzZXQuc29ydChjb21wYXJlKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgICBjLl9hZGRBbGdvcml0aG0oZnVuY3Rpb24gKGN1cnNvciwgYWR2YW5jZSwgcmVzb2x2ZSkge1xuICAgICAgICAgICAgICB2YXIga2V5ID0gY3Vyc29yLmtleTtcbiAgICAgICAgICAgICAgd2hpbGUgKGNvbXBhcmUoa2V5LCBzZXRbaV0pID4gMCkge1xuICAgICAgICAgICAgICAgICAgKytpO1xuICAgICAgICAgICAgICAgICAgaWYgKGkgPT09IHNldC5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICBhZHZhbmNlKHJlc29sdmUpO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAoY29tcGFyZShrZXksIHNldFtpXSkgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgYWR2YW5jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmNvbnRpbnVlKHNldFtpXSk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiBjO1xuICAgICAgfTtcbiAgICAgIFdoZXJlQ2xhdXNlLnByb3RvdHlwZS5ub3RFcXVhbCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLmluQW55UmFuZ2UoW1xuICAgICAgICAgICAgICBbbWluS2V5LCB2YWx1ZV0sXG4gICAgICAgICAgICAgIFt2YWx1ZSwgdGhpcy5kYi5fbWF4S2V5XSxcbiAgICAgICAgICBdLCB7IGluY2x1ZGVMb3dlcnM6IGZhbHNlLCBpbmNsdWRlVXBwZXJzOiBmYWxzZSB9KTtcbiAgICAgIH07XG4gICAgICBXaGVyZUNsYXVzZS5wcm90b3R5cGUubm9uZU9mID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBzZXQgPSBnZXRBcnJheU9mLmFwcGx5KE5PX0NIQVJfQVJSQVksIGFyZ3VtZW50cyk7XG4gICAgICAgICAgaWYgKHNldC5sZW5ndGggPT09IDApXG4gICAgICAgICAgICAgIHJldHVybiBuZXcgdGhpcy5Db2xsZWN0aW9uKHRoaXMpO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHNldC5zb3J0KHRoaXMuX2FzY2VuZGluZyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmYWlsKHRoaXMsIElOVkFMSURfS0VZX0FSR1VNRU5UKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIHJhbmdlcyA9IHNldC5yZWR1Y2UoZnVuY3Rpb24gKHJlcywgdmFsKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXMgPyByZXMuY29uY2F0KFtbcmVzW3Jlcy5sZW5ndGggLSAxXVsxXSwgdmFsXV0pIDogW1ttaW5LZXksIHZhbF1dO1xuICAgICAgICAgIH0sIG51bGwpO1xuICAgICAgICAgIHJhbmdlcy5wdXNoKFtzZXRbc2V0Lmxlbmd0aCAtIDFdLCB0aGlzLmRiLl9tYXhLZXldKTtcbiAgICAgICAgICByZXR1cm4gdGhpcy5pbkFueVJhbmdlKHJhbmdlcywge1xuICAgICAgICAgICAgICBpbmNsdWRlTG93ZXJzOiBmYWxzZSxcbiAgICAgICAgICAgICAgaW5jbHVkZVVwcGVyczogZmFsc2UsXG4gICAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgV2hlcmVDbGF1c2UucHJvdG90eXBlLmluQW55UmFuZ2UgPSBmdW5jdGlvbiAocmFuZ2VzLCBvcHRpb25zKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICB2YXIgY21wID0gdGhpcy5fY21wLCBhc2NlbmRpbmcgPSB0aGlzLl9hc2NlbmRpbmcsIGRlc2NlbmRpbmcgPSB0aGlzLl9kZXNjZW5kaW5nLCBtaW4gPSB0aGlzLl9taW4sIG1heCA9IHRoaXMuX21heDtcbiAgICAgICAgICBpZiAocmFuZ2VzLmxlbmd0aCA9PT0gMClcbiAgICAgICAgICAgICAgcmV0dXJuIGVtcHR5Q29sbGVjdGlvbih0aGlzKTtcbiAgICAgICAgICBpZiAoIXJhbmdlcy5ldmVyeShmdW5jdGlvbiAocmFuZ2UpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJhbmdlWzBdICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAgICAgICAgIHJhbmdlWzFdICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAgICAgICAgIGFzY2VuZGluZyhyYW5nZVswXSwgcmFuZ2VbMV0pIDw9IDA7XG4gICAgICAgICAgfSkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZhaWwodGhpcywgJ0ZpcnN0IGFyZ3VtZW50IHRvIGluQW55UmFuZ2UoKSBtdXN0IGJlIGFuIEFycmF5IG9mIHR3by12YWx1ZSBBcnJheXMgW2xvd2VyLHVwcGVyXSB3aGVyZSB1cHBlciBtdXN0IG5vdCBiZSBsb3dlciB0aGFuIGxvd2VyJywgZXhjZXB0aW9ucy5JbnZhbGlkQXJndW1lbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgaW5jbHVkZUxvd2VycyA9ICFvcHRpb25zIHx8IG9wdGlvbnMuaW5jbHVkZUxvd2VycyAhPT0gZmFsc2U7XG4gICAgICAgICAgdmFyIGluY2x1ZGVVcHBlcnMgPSBvcHRpb25zICYmIG9wdGlvbnMuaW5jbHVkZVVwcGVycyA9PT0gdHJ1ZTtcbiAgICAgICAgICBmdW5jdGlvbiBhZGRSYW5nZShyYW5nZXMsIG5ld1JhbmdlKSB7XG4gICAgICAgICAgICAgIHZhciBpID0gMCwgbCA9IHJhbmdlcy5sZW5ndGg7XG4gICAgICAgICAgICAgIGZvciAoOyBpIDwgbDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgcmFuZ2UgPSByYW5nZXNbaV07XG4gICAgICAgICAgICAgICAgICBpZiAoY21wKG5ld1JhbmdlWzBdLCByYW5nZVsxXSkgPCAwICYmIGNtcChuZXdSYW5nZVsxXSwgcmFuZ2VbMF0pID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgIHJhbmdlWzBdID0gbWluKHJhbmdlWzBdLCBuZXdSYW5nZVswXSk7XG4gICAgICAgICAgICAgICAgICAgICAgcmFuZ2VbMV0gPSBtYXgocmFuZ2VbMV0sIG5ld1JhbmdlWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAoaSA9PT0gbClcbiAgICAgICAgICAgICAgICAgIHJhbmdlcy5wdXNoKG5ld1JhbmdlKTtcbiAgICAgICAgICAgICAgcmV0dXJuIHJhbmdlcztcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIHNvcnREaXJlY3Rpb24gPSBhc2NlbmRpbmc7XG4gICAgICAgICAgZnVuY3Rpb24gcmFuZ2VTb3J0ZXIoYSwgYikge1xuICAgICAgICAgICAgICByZXR1cm4gc29ydERpcmVjdGlvbihhWzBdLCBiWzBdKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIHNldDtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBzZXQgPSByYW5nZXMucmVkdWNlKGFkZFJhbmdlLCBbXSk7XG4gICAgICAgICAgICAgIHNldC5zb3J0KHJhbmdlU29ydGVyKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICAgIHJldHVybiBmYWlsKHRoaXMsIElOVkFMSURfS0VZX0FSR1VNRU5UKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIHJhbmdlUG9zID0gMDtcbiAgICAgICAgICB2YXIga2V5SXNCZXlvbmRDdXJyZW50RW50cnkgPSBpbmNsdWRlVXBwZXJzXG4gICAgICAgICAgICAgID8gZnVuY3Rpb24gKGtleSkgeyByZXR1cm4gYXNjZW5kaW5nKGtleSwgc2V0W3JhbmdlUG9zXVsxXSkgPiAwOyB9XG4gICAgICAgICAgICAgIDogZnVuY3Rpb24gKGtleSkgeyByZXR1cm4gYXNjZW5kaW5nKGtleSwgc2V0W3JhbmdlUG9zXVsxXSkgPj0gMDsgfTtcbiAgICAgICAgICB2YXIga2V5SXNCZWZvcmVDdXJyZW50RW50cnkgPSBpbmNsdWRlTG93ZXJzXG4gICAgICAgICAgICAgID8gZnVuY3Rpb24gKGtleSkgeyByZXR1cm4gZGVzY2VuZGluZyhrZXksIHNldFtyYW5nZVBvc11bMF0pID4gMDsgfVxuICAgICAgICAgICAgICA6IGZ1bmN0aW9uIChrZXkpIHsgcmV0dXJuIGRlc2NlbmRpbmcoa2V5LCBzZXRbcmFuZ2VQb3NdWzBdKSA+PSAwOyB9O1xuICAgICAgICAgIGZ1bmN0aW9uIGtleVdpdGhpbkN1cnJlbnRSYW5nZShrZXkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuICFrZXlJc0JleW9uZEN1cnJlbnRFbnRyeShrZXkpICYmICFrZXlJc0JlZm9yZUN1cnJlbnRFbnRyeShrZXkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgY2hlY2tLZXkgPSBrZXlJc0JleW9uZEN1cnJlbnRFbnRyeTtcbiAgICAgICAgICB2YXIgYyA9IG5ldyB0aGlzLkNvbGxlY3Rpb24odGhpcywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICByZXR1cm4gY3JlYXRlUmFuZ2Uoc2V0WzBdWzBdLCBzZXRbc2V0Lmxlbmd0aCAtIDFdWzFdLCAhaW5jbHVkZUxvd2VycywgIWluY2x1ZGVVcHBlcnMpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGMuX29uZGlyZWN0aW9uY2hhbmdlID0gZnVuY3Rpb24gKGRpcmVjdGlvbikge1xuICAgICAgICAgICAgICBpZiAoZGlyZWN0aW9uID09PSAnbmV4dCcpIHtcbiAgICAgICAgICAgICAgICAgIGNoZWNrS2V5ID0ga2V5SXNCZXlvbmRDdXJyZW50RW50cnk7XG4gICAgICAgICAgICAgICAgICBzb3J0RGlyZWN0aW9uID0gYXNjZW5kaW5nO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgY2hlY2tLZXkgPSBrZXlJc0JlZm9yZUN1cnJlbnRFbnRyeTtcbiAgICAgICAgICAgICAgICAgIHNvcnREaXJlY3Rpb24gPSBkZXNjZW5kaW5nO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHNldC5zb3J0KHJhbmdlU29ydGVyKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIGMuX2FkZEFsZ29yaXRobShmdW5jdGlvbiAoY3Vyc29yLCBhZHZhbmNlLCByZXNvbHZlKSB7XG4gICAgICAgICAgICAgIHZhciBrZXkgPSBjdXJzb3Iua2V5O1xuICAgICAgICAgICAgICB3aGlsZSAoY2hlY2tLZXkoa2V5KSkge1xuICAgICAgICAgICAgICAgICAgKytyYW5nZVBvcztcbiAgICAgICAgICAgICAgICAgIGlmIChyYW5nZVBvcyA9PT0gc2V0Lmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgIGFkdmFuY2UocmVzb2x2ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmIChrZXlXaXRoaW5DdXJyZW50UmFuZ2Uoa2V5KSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZWxzZSBpZiAoX3RoaXMuX2NtcChrZXksIHNldFtyYW5nZVBvc11bMV0pID09PSAwIHx8XG4gICAgICAgICAgICAgICAgICBfdGhpcy5fY21wKGtleSwgc2V0W3JhbmdlUG9zXVswXSkgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGFkdmFuY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChzb3J0RGlyZWN0aW9uID09PSBhc2NlbmRpbmcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5jb250aW51ZShzZXRbcmFuZ2VQb3NdWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5jb250aW51ZShzZXRbcmFuZ2VQb3NdWzFdKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIGM7XG4gICAgICB9O1xuICAgICAgV2hlcmVDbGF1c2UucHJvdG90eXBlLnN0YXJ0c1dpdGhBbnlPZiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgc2V0ID0gZ2V0QXJyYXlPZi5hcHBseShOT19DSEFSX0FSUkFZLCBhcmd1bWVudHMpO1xuICAgICAgICAgIGlmICghc2V0LmV2ZXJ5KGZ1bmN0aW9uIChzKSB7IHJldHVybiB0eXBlb2YgcyA9PT0gJ3N0cmluZyc7IH0pKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmYWlsKHRoaXMsICdzdGFydHNXaXRoQW55T2YoKSBvbmx5IHdvcmtzIHdpdGggc3RyaW5ncycpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoc2V0Lmxlbmd0aCA9PT0gMClcbiAgICAgICAgICAgICAgcmV0dXJuIGVtcHR5Q29sbGVjdGlvbih0aGlzKTtcbiAgICAgICAgICByZXR1cm4gdGhpcy5pbkFueVJhbmdlKHNldC5tYXAoZnVuY3Rpb24gKHN0cikgeyByZXR1cm4gW3N0ciwgc3RyICsgbWF4U3RyaW5nXTsgfSkpO1xuICAgICAgfTtcbiAgICAgIHJldHVybiBXaGVyZUNsYXVzZTtcbiAgfSgpKTtcblxuICBmdW5jdGlvbiBjcmVhdGVXaGVyZUNsYXVzZUNvbnN0cnVjdG9yKGRiKSB7XG4gICAgICByZXR1cm4gbWFrZUNsYXNzQ29uc3RydWN0b3IoV2hlcmVDbGF1c2UucHJvdG90eXBlLCBmdW5jdGlvbiBXaGVyZUNsYXVzZSh0YWJsZSwgaW5kZXgsIG9yQ29sbGVjdGlvbikge1xuICAgICAgICAgIHRoaXMuZGIgPSBkYjtcbiAgICAgICAgICB0aGlzLl9jdHggPSB7XG4gICAgICAgICAgICAgIHRhYmxlOiB0YWJsZSxcbiAgICAgICAgICAgICAgaW5kZXg6IGluZGV4ID09PSAnOmlkJyA/IG51bGwgOiBpbmRleCxcbiAgICAgICAgICAgICAgb3I6IG9yQ29sbGVjdGlvbixcbiAgICAgICAgICB9O1xuICAgICAgICAgIHRoaXMuX2NtcCA9IHRoaXMuX2FzY2VuZGluZyA9IGNtcDtcbiAgICAgICAgICB0aGlzLl9kZXNjZW5kaW5nID0gZnVuY3Rpb24gKGEsIGIpIHsgcmV0dXJuIGNtcChiLCBhKTsgfTtcbiAgICAgICAgICB0aGlzLl9tYXggPSBmdW5jdGlvbiAoYSwgYikgeyByZXR1cm4gKGNtcChhLCBiKSA+IDAgPyBhIDogYik7IH07XG4gICAgICAgICAgdGhpcy5fbWluID0gZnVuY3Rpb24gKGEsIGIpIHsgcmV0dXJuIChjbXAoYSwgYikgPCAwID8gYSA6IGIpOyB9O1xuICAgICAgICAgIHRoaXMuX0lEQktleVJhbmdlID0gZGIuX2RlcHMuSURCS2V5UmFuZ2U7XG4gICAgICAgICAgaWYgKCF0aGlzLl9JREJLZXlSYW5nZSlcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuTWlzc2luZ0FQSSgpO1xuICAgICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBldmVudFJlamVjdEhhbmRsZXIocmVqZWN0KSB7XG4gICAgICByZXR1cm4gd3JhcChmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICBwcmV2ZW50RGVmYXVsdChldmVudCk7XG4gICAgICAgICAgcmVqZWN0KGV2ZW50LnRhcmdldC5lcnJvcik7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gcHJldmVudERlZmF1bHQoZXZlbnQpIHtcbiAgICAgIGlmIChldmVudC5zdG9wUHJvcGFnYXRpb24pXG4gICAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICBpZiAoZXZlbnQucHJldmVudERlZmF1bHQpXG4gICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgfVxuXG4gIHZhciBERVhJRV9TVE9SQUdFX01VVEFURURfRVZFTlRfTkFNRSA9ICdzdG9yYWdlbXV0YXRlZCc7XG4gIHZhciBTVE9SQUdFX01VVEFURURfRE9NX0VWRU5UX05BTUUgPSAneC1zdG9yYWdlbXV0YXRlZC0xJztcbiAgdmFyIGdsb2JhbEV2ZW50cyA9IEV2ZW50cyhudWxsLCBERVhJRV9TVE9SQUdFX01VVEFURURfRVZFTlRfTkFNRSk7XG5cbiAgdmFyIFRyYW5zYWN0aW9uID0gIChmdW5jdGlvbiAoKSB7XG4gICAgICBmdW5jdGlvbiBUcmFuc2FjdGlvbigpIHtcbiAgICAgIH1cbiAgICAgIFRyYW5zYWN0aW9uLnByb3RvdHlwZS5fbG9jayA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBhc3NlcnQoIVBTRC5nbG9iYWwpO1xuICAgICAgICAgICsrdGhpcy5fcmVjdWxvY2s7XG4gICAgICAgICAgaWYgKHRoaXMuX3JlY3Vsb2NrID09PSAxICYmICFQU0QuZ2xvYmFsKVxuICAgICAgICAgICAgICBQU0QubG9ja093bmVyRm9yID0gdGhpcztcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH07XG4gICAgICBUcmFuc2FjdGlvbi5wcm90b3R5cGUuX3VubG9jayA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBhc3NlcnQoIVBTRC5nbG9iYWwpO1xuICAgICAgICAgIGlmICgtLXRoaXMuX3JlY3Vsb2NrID09PSAwKSB7XG4gICAgICAgICAgICAgIGlmICghUFNELmdsb2JhbClcbiAgICAgICAgICAgICAgICAgIFBTRC5sb2NrT3duZXJGb3IgPSBudWxsO1xuICAgICAgICAgICAgICB3aGlsZSAodGhpcy5fYmxvY2tlZEZ1bmNzLmxlbmd0aCA+IDAgJiYgIXRoaXMuX2xvY2tlZCgpKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgZm5BbmRQU0QgPSB0aGlzLl9ibG9ja2VkRnVuY3Muc2hpZnQoKTtcbiAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgdXNlUFNEKGZuQW5kUFNEWzFdLCBmbkFuZFBTRFswXSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjYXRjaCAoZSkgeyB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgVHJhbnNhY3Rpb24ucHJvdG90eXBlLl9sb2NrZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3JlY3Vsb2NrICYmIFBTRC5sb2NrT3duZXJGb3IgIT09IHRoaXM7XG4gICAgICB9O1xuICAgICAgVHJhbnNhY3Rpb24ucHJvdG90eXBlLmNyZWF0ZSA9IGZ1bmN0aW9uIChpZGJ0cmFucykge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgaWYgKCF0aGlzLm1vZGUpXG4gICAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgIHZhciBpZGJkYiA9IHRoaXMuZGIuaWRiZGI7XG4gICAgICAgICAgdmFyIGRiT3BlbkVycm9yID0gdGhpcy5kYi5fc3RhdGUuZGJPcGVuRXJyb3I7XG4gICAgICAgICAgYXNzZXJ0KCF0aGlzLmlkYnRyYW5zKTtcbiAgICAgICAgICBpZiAoIWlkYnRyYW5zICYmICFpZGJkYikge1xuICAgICAgICAgICAgICBzd2l0Y2ggKGRiT3BlbkVycm9yICYmIGRiT3BlbkVycm9yLm5hbWUpIHtcbiAgICAgICAgICAgICAgICAgIGNhc2UgJ0RhdGFiYXNlQ2xvc2VkRXJyb3InOlxuICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLkRhdGFiYXNlQ2xvc2VkKGRiT3BlbkVycm9yKTtcbiAgICAgICAgICAgICAgICAgIGNhc2UgJ01pc3NpbmdBUElFcnJvcic6XG4gICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuTWlzc2luZ0FQSShkYk9wZW5FcnJvci5tZXNzYWdlLCBkYk9wZW5FcnJvcik7XG4gICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLk9wZW5GYWlsZWQoZGJPcGVuRXJyb3IpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghdGhpcy5hY3RpdmUpXG4gICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLlRyYW5zYWN0aW9uSW5hY3RpdmUoKTtcbiAgICAgICAgICBhc3NlcnQodGhpcy5fY29tcGxldGlvbi5fc3RhdGUgPT09IG51bGwpO1xuICAgICAgICAgIGlkYnRyYW5zID0gdGhpcy5pZGJ0cmFucyA9XG4gICAgICAgICAgICAgIGlkYnRyYW5zIHx8XG4gICAgICAgICAgICAgICAgICAodGhpcy5kYi5jb3JlXG4gICAgICAgICAgICAgICAgICAgICAgPyB0aGlzLmRiLmNvcmUudHJhbnNhY3Rpb24odGhpcy5zdG9yZU5hbWVzLCB0aGlzLm1vZGUsIHsgZHVyYWJpbGl0eTogdGhpcy5jaHJvbWVUcmFuc2FjdGlvbkR1cmFiaWxpdHkgfSlcbiAgICAgICAgICAgICAgICAgICAgICA6IGlkYmRiLnRyYW5zYWN0aW9uKHRoaXMuc3RvcmVOYW1lcywgdGhpcy5tb2RlLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGR1cmFiaWxpdHk6IHRoaXMuY2hyb21lVHJhbnNhY3Rpb25EdXJhYmlsaXR5LFxuICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICBpZGJ0cmFucy5vbmVycm9yID0gd3JhcChmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgICAgcHJldmVudERlZmF1bHQoZXYpO1xuICAgICAgICAgICAgICBfdGhpcy5fcmVqZWN0KGlkYnRyYW5zLmVycm9yKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZGJ0cmFucy5vbmFib3J0ID0gd3JhcChmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgICAgcHJldmVudERlZmF1bHQoZXYpO1xuICAgICAgICAgICAgICBfdGhpcy5hY3RpdmUgJiYgX3RoaXMuX3JlamVjdChuZXcgZXhjZXB0aW9ucy5BYm9ydChpZGJ0cmFucy5lcnJvcikpO1xuICAgICAgICAgICAgICBfdGhpcy5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgX3RoaXMub24oJ2Fib3J0JykuZmlyZShldik7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWRidHJhbnMub25jb21wbGV0ZSA9IHdyYXAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBfdGhpcy5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgX3RoaXMuX3Jlc29sdmUoKTtcbiAgICAgICAgICAgICAgaWYgKCdtdXRhdGVkUGFydHMnIGluIGlkYnRyYW5zKSB7XG4gICAgICAgICAgICAgICAgICBnbG9iYWxFdmVudHMuc3RvcmFnZW11dGF0ZWQuZmlyZShpZGJ0cmFuc1snbXV0YXRlZFBhcnRzJ10pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgVHJhbnNhY3Rpb24ucHJvdG90eXBlLl9wcm9taXNlID0gZnVuY3Rpb24gKG1vZGUsIGZuLCBiV3JpdGVMb2NrKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICBpZiAobW9kZSA9PT0gJ3JlYWR3cml0ZScgJiYgdGhpcy5tb2RlICE9PSAncmVhZHdyaXRlJylcbiAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdGlvbihuZXcgZXhjZXB0aW9ucy5SZWFkT25seSgnVHJhbnNhY3Rpb24gaXMgcmVhZG9ubHknKSk7XG4gICAgICAgICAgaWYgKCF0aGlzLmFjdGl2ZSlcbiAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdGlvbihuZXcgZXhjZXB0aW9ucy5UcmFuc2FjdGlvbkluYWN0aXZlKCkpO1xuICAgICAgICAgIGlmICh0aGlzLl9sb2NrZWQoKSkge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICBfdGhpcy5fYmxvY2tlZEZ1bmNzLnB1c2goW1xuICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuX3Byb21pc2UobW9kZSwgZm4sIGJXcml0ZUxvY2spLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIFBTRCxcbiAgICAgICAgICAgICAgICAgIF0pO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZSBpZiAoYldyaXRlTG9jaykge1xuICAgICAgICAgICAgICByZXR1cm4gbmV3U2NvcGUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgdmFyIHAgPSBuZXcgRGV4aWVQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5fbG9jaygpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBydiA9IGZuKHJlc29sdmUsIHJlamVjdCwgX3RoaXMpO1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChydiAmJiBydi50aGVuKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBydi50aGVuKHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIHAuZmluYWxseShmdW5jdGlvbiAoKSB7IHJldHVybiBfdGhpcy5fdW5sb2NrKCk7IH0pO1xuICAgICAgICAgICAgICAgICAgcC5fbGliID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBwO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgIHZhciBwID0gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICB2YXIgcnYgPSBmbihyZXNvbHZlLCByZWplY3QsIF90aGlzKTtcbiAgICAgICAgICAgICAgICAgIGlmIChydiAmJiBydi50aGVuKVxuICAgICAgICAgICAgICAgICAgICAgIHJ2LnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHAuX2xpYiA9IHRydWU7XG4gICAgICAgICAgICAgIHJldHVybiBwO1xuICAgICAgICAgIH1cbiAgICAgIH07XG4gICAgICBUcmFuc2FjdGlvbi5wcm90b3R5cGUuX3Jvb3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGFyZW50ID8gdGhpcy5wYXJlbnQuX3Jvb3QoKSA6IHRoaXM7XG4gICAgICB9O1xuICAgICAgVHJhbnNhY3Rpb24ucHJvdG90eXBlLndhaXRGb3IgPSBmdW5jdGlvbiAocHJvbWlzZUxpa2UpIHtcbiAgICAgICAgICB2YXIgcm9vdCA9IHRoaXMuX3Jvb3QoKTtcbiAgICAgICAgICB2YXIgcHJvbWlzZSA9IERleGllUHJvbWlzZS5yZXNvbHZlKHByb21pc2VMaWtlKTtcbiAgICAgICAgICBpZiAocm9vdC5fd2FpdGluZ0Zvcikge1xuICAgICAgICAgICAgICByb290Ll93YWl0aW5nRm9yID0gcm9vdC5fd2FpdGluZ0Zvci50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHByb21pc2U7IH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgcm9vdC5fd2FpdGluZ0ZvciA9IHByb21pc2U7XG4gICAgICAgICAgICAgIHJvb3QuX3dhaXRpbmdRdWV1ZSA9IFtdO1xuICAgICAgICAgICAgICB2YXIgc3RvcmUgPSByb290LmlkYnRyYW5zLm9iamVjdFN0b3JlKHJvb3Quc3RvcmVOYW1lc1swXSk7XG4gICAgICAgICAgICAgIChmdW5jdGlvbiBzcGluKCkge1xuICAgICAgICAgICAgICAgICAgKytyb290Ll9zcGluQ291bnQ7XG4gICAgICAgICAgICAgICAgICB3aGlsZSAocm9vdC5fd2FpdGluZ1F1ZXVlLmxlbmd0aClcbiAgICAgICAgICAgICAgICAgICAgICByb290Ll93YWl0aW5nUXVldWUuc2hpZnQoKSgpO1xuICAgICAgICAgICAgICAgICAgaWYgKHJvb3QuX3dhaXRpbmdGb3IpXG4gICAgICAgICAgICAgICAgICAgICAgc3RvcmUuZ2V0KC1JbmZpbml0eSkub25zdWNjZXNzID0gc3BpbjtcbiAgICAgICAgICAgICAgfSkoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIGN1cnJlbnRXYWl0UHJvbWlzZSA9IHJvb3QuX3dhaXRpbmdGb3I7XG4gICAgICAgICAgcmV0dXJuIG5ldyBEZXhpZVByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICBwcm9taXNlXG4gICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzKSB7IHJldHVybiByb290Ll93YWl0aW5nUXVldWUucHVzaCh3cmFwKHJlc29sdmUuYmluZChudWxsLCByZXMpKSk7IH0sIGZ1bmN0aW9uIChlcnIpIHsgcmV0dXJuIHJvb3QuX3dhaXRpbmdRdWV1ZS5wdXNoKHdyYXAocmVqZWN0LmJpbmQobnVsbCwgZXJyKSkpOyB9KVxuICAgICAgICAgICAgICAgICAgLmZpbmFsbHkoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgaWYgKHJvb3QuX3dhaXRpbmdGb3IgPT09IGN1cnJlbnRXYWl0UHJvbWlzZSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJvb3QuX3dhaXRpbmdGb3IgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBUcmFuc2FjdGlvbi5wcm90b3R5cGUuYWJvcnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaWYgKHRoaXMuYWN0aXZlKSB7XG4gICAgICAgICAgICAgIHRoaXMuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICAgIGlmICh0aGlzLmlkYnRyYW5zKVxuICAgICAgICAgICAgICAgICAgdGhpcy5pZGJ0cmFucy5hYm9ydCgpO1xuICAgICAgICAgICAgICB0aGlzLl9yZWplY3QobmV3IGV4Y2VwdGlvbnMuQWJvcnQoKSk7XG4gICAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIFRyYW5zYWN0aW9uLnByb3RvdHlwZS50YWJsZSA9IGZ1bmN0aW9uICh0YWJsZU5hbWUpIHtcbiAgICAgICAgICB2YXIgbWVtb2l6ZWRUYWJsZXMgPSB0aGlzLl9tZW1vaXplZFRhYmxlcyB8fCAodGhpcy5fbWVtb2l6ZWRUYWJsZXMgPSB7fSk7XG4gICAgICAgICAgaWYgKGhhc093bihtZW1vaXplZFRhYmxlcywgdGFibGVOYW1lKSlcbiAgICAgICAgICAgICAgcmV0dXJuIG1lbW9pemVkVGFibGVzW3RhYmxlTmFtZV07XG4gICAgICAgICAgdmFyIHRhYmxlU2NoZW1hID0gdGhpcy5zY2hlbWFbdGFibGVOYW1lXTtcbiAgICAgICAgICBpZiAoIXRhYmxlU2NoZW1hKSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLk5vdEZvdW5kKCdUYWJsZSAnICsgdGFibGVOYW1lICsgJyBub3QgcGFydCBvZiB0cmFuc2FjdGlvbicpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgdHJhbnNhY3Rpb25Cb3VuZFRhYmxlID0gbmV3IHRoaXMuZGIuVGFibGUodGFibGVOYW1lLCB0YWJsZVNjaGVtYSwgdGhpcyk7XG4gICAgICAgICAgdHJhbnNhY3Rpb25Cb3VuZFRhYmxlLmNvcmUgPSB0aGlzLmRiLmNvcmUudGFibGUodGFibGVOYW1lKTtcbiAgICAgICAgICBtZW1vaXplZFRhYmxlc1t0YWJsZU5hbWVdID0gdHJhbnNhY3Rpb25Cb3VuZFRhYmxlO1xuICAgICAgICAgIHJldHVybiB0cmFuc2FjdGlvbkJvdW5kVGFibGU7XG4gICAgICB9O1xuICAgICAgcmV0dXJuIFRyYW5zYWN0aW9uO1xuICB9KCkpO1xuXG4gIGZ1bmN0aW9uIGNyZWF0ZVRyYW5zYWN0aW9uQ29uc3RydWN0b3IoZGIpIHtcbiAgICAgIHJldHVybiBtYWtlQ2xhc3NDb25zdHJ1Y3RvcihUcmFuc2FjdGlvbi5wcm90b3R5cGUsIGZ1bmN0aW9uIFRyYW5zYWN0aW9uKG1vZGUsIHN0b3JlTmFtZXMsIGRic2NoZW1hLCBjaHJvbWVUcmFuc2FjdGlvbkR1cmFiaWxpdHksIHBhcmVudCkge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgaWYgKG1vZGUgIT09ICdyZWFkb25seScpXG4gICAgICAgICAgICAgIHN0b3JlTmFtZXMuZm9yRWFjaChmdW5jdGlvbiAoc3RvcmVOYW1lKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgICAgICAgICB2YXIgeVByb3BzID0gKF9hID0gZGJzY2hlbWFbc3RvcmVOYW1lXSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnlQcm9wcztcbiAgICAgICAgICAgICAgICAgIGlmICh5UHJvcHMpXG4gICAgICAgICAgICAgICAgICAgICAgc3RvcmVOYW1lcyA9IHN0b3JlTmFtZXMuY29uY2F0KHlQcm9wcy5tYXAoZnVuY3Rpb24gKHApIHsgcmV0dXJuIHAudXBkYXRlc1RhYmxlOyB9KSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIHRoaXMuZGIgPSBkYjtcbiAgICAgICAgICB0aGlzLm1vZGUgPSBtb2RlO1xuICAgICAgICAgIHRoaXMuc3RvcmVOYW1lcyA9IHN0b3JlTmFtZXM7XG4gICAgICAgICAgdGhpcy5zY2hlbWEgPSBkYnNjaGVtYTtcbiAgICAgICAgICB0aGlzLmNocm9tZVRyYW5zYWN0aW9uRHVyYWJpbGl0eSA9IGNocm9tZVRyYW5zYWN0aW9uRHVyYWJpbGl0eTtcbiAgICAgICAgICB0aGlzLmlkYnRyYW5zID0gbnVsbDtcbiAgICAgICAgICB0aGlzLm9uID0gRXZlbnRzKHRoaXMsICdjb21wbGV0ZScsICdlcnJvcicsICdhYm9ydCcpO1xuICAgICAgICAgIHRoaXMucGFyZW50ID0gcGFyZW50IHx8IG51bGw7XG4gICAgICAgICAgdGhpcy5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgIHRoaXMuX3JlY3Vsb2NrID0gMDtcbiAgICAgICAgICB0aGlzLl9ibG9ja2VkRnVuY3MgPSBbXTtcbiAgICAgICAgICB0aGlzLl9yZXNvbHZlID0gbnVsbDtcbiAgICAgICAgICB0aGlzLl9yZWplY3QgPSBudWxsO1xuICAgICAgICAgIHRoaXMuX3dhaXRpbmdGb3IgPSBudWxsO1xuICAgICAgICAgIHRoaXMuX3dhaXRpbmdRdWV1ZSA9IG51bGw7XG4gICAgICAgICAgdGhpcy5fc3BpbkNvdW50ID0gMDtcbiAgICAgICAgICB0aGlzLl9jb21wbGV0aW9uID0gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgIF90aGlzLl9yZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgICAgICAgICAgX3RoaXMuX3JlamVjdCA9IHJlamVjdDtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLl9jb21wbGV0aW9uLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBfdGhpcy5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgX3RoaXMub24uY29tcGxldGUuZmlyZSgpO1xuICAgICAgICAgIH0sIGZ1bmN0aW9uIChlKSB7XG4gICAgICAgICAgICAgIHZhciB3YXNBY3RpdmUgPSBfdGhpcy5hY3RpdmU7XG4gICAgICAgICAgICAgIF90aGlzLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICBfdGhpcy5vbi5lcnJvci5maXJlKGUpO1xuICAgICAgICAgICAgICBfdGhpcy5wYXJlbnRcbiAgICAgICAgICAgICAgICAgID8gX3RoaXMucGFyZW50Ll9yZWplY3QoZSlcbiAgICAgICAgICAgICAgICAgIDogd2FzQWN0aXZlICYmIF90aGlzLmlkYnRyYW5zICYmIF90aGlzLmlkYnRyYW5zLmFib3J0KCk7XG4gICAgICAgICAgICAgIHJldHVybiByZWplY3Rpb24oZSk7XG4gICAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZUluZGV4U3BlYyhuYW1lLCBrZXlQYXRoLCB1bmlxdWUsIG11bHRpLCBhdXRvLCBjb21wb3VuZCwgaXNQcmltS2V5LCB0eXBlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAgIG5hbWU6IG5hbWUsXG4gICAgICAgICAga2V5UGF0aDoga2V5UGF0aCxcbiAgICAgICAgICB1bmlxdWU6IHVuaXF1ZSxcbiAgICAgICAgICBtdWx0aTogbXVsdGksXG4gICAgICAgICAgYXV0bzogYXV0byxcbiAgICAgICAgICBjb21wb3VuZDogY29tcG91bmQsXG4gICAgICAgICAgc3JjOiAodW5pcXVlICYmICFpc1ByaW1LZXkgPyAnJicgOiAnJykgK1xuICAgICAgICAgICAgICAobXVsdGkgPyAnKicgOiAnJykgK1xuICAgICAgICAgICAgICAoYXV0byA/ICcrKycgOiAnJykgK1xuICAgICAgICAgICAgICBuYW1lRnJvbUtleVBhdGgoa2V5UGF0aCksXG4gICAgICAgICAgdHlwZTogdHlwZSxcbiAgICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gbmFtZUZyb21LZXlQYXRoKGtleVBhdGgpIHtcbiAgICAgIHJldHVybiB0eXBlb2Yga2V5UGF0aCA9PT0gJ3N0cmluZydcbiAgICAgICAgICA/IGtleVBhdGhcbiAgICAgICAgICA6IGtleVBhdGhcbiAgICAgICAgICAgICAgPyAnWycgKyBbXS5qb2luLmNhbGwoa2V5UGF0aCwgJysnKSArICddJ1xuICAgICAgICAgICAgICA6ICcnO1xuICB9XG5cbiAgZnVuY3Rpb24gY3JlYXRlVGFibGVTY2hlbWEobmFtZSwgcHJpbUtleSwgaW5kZXhlcykge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgIHByaW1LZXk6IHByaW1LZXksXG4gICAgICAgICAgaW5kZXhlczogaW5kZXhlcyxcbiAgICAgICAgICBtYXBwZWRDbGFzczogbnVsbCxcbiAgICAgICAgICBpZHhCeU5hbWU6IGFycmF5VG9PYmplY3QoaW5kZXhlcywgZnVuY3Rpb24gKGluZGV4KSB7IHJldHVybiBbaW5kZXgubmFtZSwgaW5kZXhdOyB9KSxcbiAgICAgIH07XG4gIH1cblxuICBmdW5jdGlvbiBzYWZhcmlNdWx0aVN0b3JlRml4KHN0b3JlTmFtZXMpIHtcbiAgICAgIHJldHVybiBzdG9yZU5hbWVzLmxlbmd0aCA9PT0gMSA/IHN0b3JlTmFtZXNbMF0gOiBzdG9yZU5hbWVzO1xuICB9XG4gIHZhciBnZXRNYXhLZXkgPSBmdW5jdGlvbiAoSWRiS2V5UmFuZ2UpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgICAgSWRiS2V5UmFuZ2Uub25seShbW11dKTtcbiAgICAgICAgICBnZXRNYXhLZXkgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBbW11dOyB9O1xuICAgICAgICAgIHJldHVybiBbW11dO1xuICAgICAgfVxuICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICBnZXRNYXhLZXkgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBtYXhTdHJpbmc7IH07XG4gICAgICAgICAgcmV0dXJuIG1heFN0cmluZztcbiAgICAgIH1cbiAgfTtcblxuICBmdW5jdGlvbiBnZXRLZXlFeHRyYWN0b3Ioa2V5UGF0aCkge1xuICAgICAgaWYgKGtleVBhdGggPT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7IHJldHVybiB1bmRlZmluZWQ7IH07XG4gICAgICB9XG4gICAgICBlbHNlIGlmICh0eXBlb2Yga2V5UGF0aCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICByZXR1cm4gZ2V0U2luZ2xlUGF0aEtleUV4dHJhY3RvcihrZXlQYXRoKTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAob2JqKSB7IHJldHVybiBnZXRCeUtleVBhdGgob2JqLCBrZXlQYXRoKTsgfTtcbiAgICAgIH1cbiAgfVxuICBmdW5jdGlvbiBnZXRTaW5nbGVQYXRoS2V5RXh0cmFjdG9yKGtleVBhdGgpIHtcbiAgICAgIHZhciBzcGxpdCA9IGtleVBhdGguc3BsaXQoJy4nKTtcbiAgICAgIGlmIChzcGxpdC5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKG9iaikgeyByZXR1cm4gb2JqW2tleVBhdGhdOyB9O1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChvYmopIHsgcmV0dXJuIGdldEJ5S2V5UGF0aChvYmosIGtleVBhdGgpOyB9O1xuICAgICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gYXJyYXlpZnkoYXJyYXlMaWtlKSB7XG4gICAgICByZXR1cm4gW10uc2xpY2UuY2FsbChhcnJheUxpa2UpO1xuICB9XG4gIHZhciBfaWRfY291bnRlciA9IDA7XG4gIGZ1bmN0aW9uIGdldEtleVBhdGhBbGlhcyhrZXlQYXRoKSB7XG4gICAgICByZXR1cm4ga2V5UGF0aCA9PSBudWxsXG4gICAgICAgICAgPyAnOmlkJ1xuICAgICAgICAgIDogdHlwZW9mIGtleVBhdGggPT09ICdzdHJpbmcnXG4gICAgICAgICAgICAgID8ga2V5UGF0aFxuICAgICAgICAgICAgICA6IFwiW1wiLmNvbmNhdChrZXlQYXRoLmpvaW4oJysnKSwgXCJdXCIpO1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZURCQ29yZShkYiwgSWRiS2V5UmFuZ2UsIHRtcFRyYW5zKSB7XG4gICAgICBmdW5jdGlvbiBleHRyYWN0U2NoZW1hKGRiLCB0cmFucykge1xuICAgICAgICAgIHZhciB0YWJsZXMgPSBhcnJheWlmeShkYi5vYmplY3RTdG9yZU5hbWVzKTtcbiAgICAgICAgICB2YXIgdGVtcFN0b3JlID0gdGFibGVzLmxlbmd0aCA+IDAgPyB0cmFucy5vYmplY3RTdG9yZSh0YWJsZXNbMF0pIDoge307XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgc2NoZW1hOiB7XG4gICAgICAgICAgICAgICAgICBuYW1lOiBkYi5uYW1lLFxuICAgICAgICAgICAgICAgICAgdGFibGVzOiB0YWJsZXNcbiAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uICh0YWJsZSkgeyByZXR1cm4gdHJhbnMub2JqZWN0U3RvcmUodGFibGUpOyB9KVxuICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKHN0b3JlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGtleVBhdGggPSBzdG9yZS5rZXlQYXRoLCBhdXRvSW5jcmVtZW50ID0gc3RvcmUuYXV0b0luY3JlbWVudDtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgY29tcG91bmQgPSBpc0FycmF5KGtleVBhdGgpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBvdXRib3VuZCA9IGtleVBhdGggPT0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgaW5kZXhCeUtleVBhdGggPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBzdG9yZS5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5S2V5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQcmltYXJ5S2V5OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3V0Ym91bmQ6IG91dGJvdW5kLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG91bmQ6IGNvbXBvdW5kLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5UGF0aDoga2V5UGF0aCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dG9JbmNyZW1lbnQ6IGF1dG9JbmNyZW1lbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bmlxdWU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHRyYWN0S2V5OiBnZXRLZXlFeHRyYWN0b3Ioa2V5UGF0aCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4ZXM6IGFycmF5aWZ5KHN0b3JlLmluZGV4TmFtZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChpbmRleE5hbWUpIHsgcmV0dXJuIHN0b3JlLmluZGV4KGluZGV4TmFtZSk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChpbmRleCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG5hbWUgPSBpbmRleC5uYW1lLCB1bmlxdWUgPSBpbmRleC51bmlxdWUsIG11bHRpRW50cnkgPSBpbmRleC5tdWx0aUVudHJ5LCBrZXlQYXRoID0gaW5kZXgua2V5UGF0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb21wb3VuZCA9IGlzQXJyYXkoa2V5UGF0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IG5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG91bmQ6IGNvbXBvdW5kLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleVBhdGg6IGtleVBhdGgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5pcXVlOiB1bmlxdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXVsdGlFbnRyeTogbXVsdGlFbnRyeSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHRyYWN0S2V5OiBnZXRLZXlFeHRyYWN0b3Ioa2V5UGF0aCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXhCeUtleVBhdGhbZ2V0S2V5UGF0aEFsaWFzKGtleVBhdGgpXSA9IHJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBnZXRJbmRleEJ5S2V5UGF0aDogZnVuY3Rpb24gKGtleVBhdGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpbmRleEJ5S2V5UGF0aFtnZXRLZXlQYXRoQWxpYXMoa2V5UGF0aCldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgaW5kZXhCeUtleVBhdGhbJzppZCddID0gcmVzdWx0LnByaW1hcnlLZXk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGtleVBhdGggIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleEJ5S2V5UGF0aFtnZXRLZXlQYXRoQWxpYXMoa2V5UGF0aCldID0gcmVzdWx0LnByaW1hcnlLZXk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgaGFzR2V0QWxsOiB0YWJsZXMubGVuZ3RoID4gMCAmJlxuICAgICAgICAgICAgICAgICAgJ2dldEFsbCcgaW4gdGVtcFN0b3JlICYmXG4gICAgICAgICAgICAgICAgICAhKHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICAgICAgICAgICAgICAgICAgL1NhZmFyaS8udGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSAmJlxuICAgICAgICAgICAgICAgICAgICAgICEvKENocm9tZVxcL3xFZGdlXFwvKS8udGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSAmJlxuICAgICAgICAgICAgICAgICAgICAgIFtdLmNvbmNhdChuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9TYWZhcmlcXC8oXFxkKikvKSlbMV0gPCA2MDQpLFxuICAgICAgICAgICAgICBoYXNJZGIzRmVhdHVyZXM6ICdnZXRBbGxSZWNvcmRzJyBpbiB0ZW1wU3RvcmUsXG4gICAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIG1ha2VJREJLZXlSYW5nZShyYW5nZSkge1xuICAgICAgICAgIGlmIChyYW5nZS50eXBlID09PSAzIClcbiAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgaWYgKHJhbmdlLnR5cGUgPT09IDQgKVxuICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBjb252ZXJ0IG5ldmVyIHR5cGUgdG8gSURCS2V5UmFuZ2UnKTtcbiAgICAgICAgICB2YXIgbG93ZXIgPSByYW5nZS5sb3dlciwgdXBwZXIgPSByYW5nZS51cHBlciwgbG93ZXJPcGVuID0gcmFuZ2UubG93ZXJPcGVuLCB1cHBlck9wZW4gPSByYW5nZS51cHBlck9wZW47XG4gICAgICAgICAgdmFyIGlkYlJhbmdlID0gbG93ZXIgPT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICA/IHVwcGVyID09PSB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgID8gbnVsbFxuICAgICAgICAgICAgICAgICAgOiBJZGJLZXlSYW5nZS51cHBlckJvdW5kKHVwcGVyLCAhIXVwcGVyT3BlbilcbiAgICAgICAgICAgICAgOiB1cHBlciA9PT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICA/IElkYktleVJhbmdlLmxvd2VyQm91bmQobG93ZXIsICEhbG93ZXJPcGVuKVxuICAgICAgICAgICAgICAgICAgOiBJZGJLZXlSYW5nZS5ib3VuZChsb3dlciwgdXBwZXIsICEhbG93ZXJPcGVuLCAhIXVwcGVyT3Blbik7XG4gICAgICAgICAgcmV0dXJuIGlkYlJhbmdlO1xuICAgICAgfVxuICAgICAgZnVuY3Rpb24gY3JlYXRlRGJDb3JlVGFibGUodGFibGVTY2hlbWEpIHtcbiAgICAgICAgICB2YXIgdGFibGVOYW1lID0gdGFibGVTY2hlbWEubmFtZTtcbiAgICAgICAgICBmdW5jdGlvbiBtdXRhdGUoX2EpIHtcbiAgICAgICAgICAgICAgdmFyIHRyYW5zID0gX2EudHJhbnMsIHR5cGUgPSBfYS50eXBlLCBrZXlzID0gX2Eua2V5cywgdmFsdWVzID0gX2EudmFsdWVzLCByYW5nZSA9IF9hLnJhbmdlO1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSA9IHdyYXAocmVzb2x2ZSk7XG4gICAgICAgICAgICAgICAgICB2YXIgc3RvcmUgPSB0cmFucy5vYmplY3RTdG9yZSh0YWJsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgdmFyIG91dGJvdW5kID0gc3RvcmUua2V5UGF0aCA9PSBudWxsO1xuICAgICAgICAgICAgICAgICAgdmFyIGlzQWRkT3JQdXQgPSB0eXBlID09PSAncHV0JyB8fCB0eXBlID09PSAnYWRkJztcbiAgICAgICAgICAgICAgICAgIGlmICghaXNBZGRPclB1dCAmJiB0eXBlICE9PSAnZGVsZXRlJyAmJiB0eXBlICE9PSAnZGVsZXRlUmFuZ2UnKVxuICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBvcGVyYXRpb24gdHlwZTogJyArIHR5cGUpO1xuICAgICAgICAgICAgICAgICAgdmFyIGxlbmd0aCA9IChrZXlzIHx8IHZhbHVlcyB8fCB7IGxlbmd0aDogMSB9KS5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICBpZiAoa2V5cyAmJiB2YWx1ZXMgJiYga2V5cy5sZW5ndGggIT09IHZhbHVlcy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0dpdmVuIGtleXMgYXJyYXkgbXVzdCBoYXZlIHNhbWUgbGVuZ3RoIGFzIGdpdmVuIHZhbHVlcyBhcnJheS4nKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChsZW5ndGggPT09IDApXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICBudW1GYWlsdXJlczogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmFpbHVyZXM6IHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRzOiBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFzdFJlc3VsdDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgdmFyIHJlcTtcbiAgICAgICAgICAgICAgICAgIHZhciByZXFzID0gW107XG4gICAgICAgICAgICAgICAgICB2YXIgZmFpbHVyZXMgPSBbXTtcbiAgICAgICAgICAgICAgICAgIHZhciBudW1GYWlsdXJlcyA9IDA7XG4gICAgICAgICAgICAgICAgICB2YXIgZXJyb3JIYW5kbGVyID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgKytudW1GYWlsdXJlcztcbiAgICAgICAgICAgICAgICAgICAgICBwcmV2ZW50RGVmYXVsdChldmVudCk7XG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgaWYgKHR5cGUgPT09ICdkZWxldGVSYW5nZScpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAocmFuZ2UudHlwZSA9PT0gNCApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNvbHZlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bUZhaWx1cmVzOiBudW1GYWlsdXJlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmVzOiBmYWlsdXJlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdHM6IFtdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFzdFJlc3VsdDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAocmFuZ2UudHlwZSA9PT0gMyApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXMucHVzaCgocmVxID0gc3RvcmUuY2xlYXIoKSkpO1xuICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxcy5wdXNoKChyZXEgPSBzdG9yZS5kZWxldGUobWFrZUlEQktleVJhbmdlKHJhbmdlKSkpKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBfYSA9IGlzQWRkT3JQdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBvdXRib3VuZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBbdmFsdWVzLCBrZXlzXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBbdmFsdWVzLCBudWxsXVxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFtrZXlzLCBudWxsXSwgYXJnczEgPSBfYVswXSwgYXJnczIgPSBfYVsxXTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNBZGRPclB1dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXFzLnB1c2goKHJlcSA9IChhcmdzMiAmJiBhcmdzMltpXSAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzdG9yZVt0eXBlXShhcmdzMVtpXSwgYXJnczJbaV0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzdG9yZVt0eXBlXShhcmdzMVtpXSkpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IGVycm9ySGFuZGxlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxcy5wdXNoKChyZXEgPSBzdG9yZVt0eXBlXShhcmdzMVtpXSkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcS5vbmVycm9yID0gZXJyb3JIYW5kbGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgdmFyIGRvbmUgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgbGFzdFJlc3VsdCA9IGV2ZW50LnRhcmdldC5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgcmVxcy5mb3JFYWNoKGZ1bmN0aW9uIChyZXEsIGkpIHsgcmV0dXJuIHJlcS5lcnJvciAhPSBudWxsICYmIChmYWlsdXJlc1tpXSA9IHJlcS5lcnJvcik7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICBudW1GYWlsdXJlczogbnVtRmFpbHVyZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmVzOiBmYWlsdXJlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0czogdHlwZSA9PT0gJ2RlbGV0ZScgPyBrZXlzIDogcmVxcy5tYXAoZnVuY3Rpb24gKHJlcSkgeyByZXR1cm4gcmVxLnJlc3VsdDsgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhc3RSZXN1bHQ6IGxhc3RSZXN1bHQsXG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBlcnJvckhhbmRsZXIoZXZlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgIGRvbmUoZXZlbnQpO1xuICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgIHJlcS5vbnN1Y2Nlc3MgPSBkb25lO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZnVuY3Rpb24gb3BlbkN1cnNvcihfYSkge1xuICAgICAgICAgICAgICB2YXIgdHJhbnMgPSBfYS50cmFucywgdmFsdWVzID0gX2EudmFsdWVzLCBxdWVyeSA9IF9hLnF1ZXJ5LCByZXZlcnNlID0gX2EucmV2ZXJzZSwgdW5pcXVlID0gX2EudW5pcXVlO1xuICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSA9IHdyYXAocmVzb2x2ZSk7XG4gICAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSBxdWVyeS5pbmRleCwgcmFuZ2UgPSBxdWVyeS5yYW5nZTtcbiAgICAgICAgICAgICAgICAgIHZhciBzdG9yZSA9IHRyYW5zLm9iamVjdFN0b3JlKHRhYmxlTmFtZSk7XG4gICAgICAgICAgICAgICAgICB2YXIgc291cmNlID0gaW5kZXguaXNQcmltYXJ5S2V5ID8gc3RvcmUgOiBzdG9yZS5pbmRleChpbmRleC5uYW1lKTtcbiAgICAgICAgICAgICAgICAgIHZhciBkaXJlY3Rpb24gPSByZXZlcnNlXG4gICAgICAgICAgICAgICAgICAgICAgPyB1bmlxdWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAncHJldnVuaXF1ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAncHJldidcbiAgICAgICAgICAgICAgICAgICAgICA6IHVuaXF1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICduZXh0dW5pcXVlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICduZXh0JztcbiAgICAgICAgICAgICAgICAgIHZhciByZXEgPSB2YWx1ZXMgfHwgISgnb3BlbktleUN1cnNvcicgaW4gc291cmNlKVxuICAgICAgICAgICAgICAgICAgICAgID8gc291cmNlLm9wZW5DdXJzb3IobWFrZUlEQktleVJhbmdlKHJhbmdlKSwgZGlyZWN0aW9uKVxuICAgICAgICAgICAgICAgICAgICAgIDogc291cmNlLm9wZW5LZXlDdXJzb3IobWFrZUlEQktleVJhbmdlKHJhbmdlKSwgZGlyZWN0aW9uKTtcbiAgICAgICAgICAgICAgICAgIHJlcS5vbmVycm9yID0gZXZlbnRSZWplY3RIYW5kbGVyKHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICByZXEub25zdWNjZXNzID0gd3JhcChmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgY3Vyc29yID0gcmVxLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoIWN1cnNvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5fX19pZCA9ICsrX2lkX2NvdW50ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmRvbmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgX2N1cnNvckNvbnRpbnVlID0gY3Vyc29yLmNvbnRpbnVlLmJpbmQoY3Vyc29yKTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgX2N1cnNvckNvbnRpbnVlUHJpbWFyeUtleSA9IGN1cnNvci5jb250aW51ZVByaW1hcnlLZXk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKF9jdXJzb3JDb250aW51ZVByaW1hcnlLZXkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIF9jdXJzb3JDb250aW51ZVByaW1hcnlLZXkgPSBfY3Vyc29yQ29udGludWVQcmltYXJ5S2V5LmJpbmQoY3Vyc29yKTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgX2N1cnNvckFkdmFuY2UgPSBjdXJzb3IuYWR2YW5jZS5iaW5kKGN1cnNvcik7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGRvVGhyb3dDdXJzb3JJc05vdFN0YXJ0ZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ3Vyc29yIG5vdCBzdGFydGVkJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgZG9UaHJvd0N1cnNvcklzU3RvcHBlZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDdXJzb3Igbm90IHN0b3BwZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci50cmFucyA9IHRyYW5zO1xuICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5zdG9wID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmNvbnRpbnVlID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5jb250aW51ZVByaW1hcnlLZXkgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5hZHZhbmNlID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9UaHJvd0N1cnNvcklzTm90U3RhcnRlZDtcbiAgICAgICAgICAgICAgICAgICAgICBjdXJzb3IuZmFpbCA9IHdyYXAocmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgICBjdXJzb3IubmV4dCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGdvdE9uZSA9IDE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnN0YXJ0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBnb3RPbmUtLSA/IF90aGlzLmNvbnRpbnVlKCkgOiBfdGhpcy5zdG9wKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pLnRoZW4oZnVuY3Rpb24gKCkgeyByZXR1cm4gX3RoaXM7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLnN0YXJ0ID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpdGVyYXRpb25Qcm9taXNlID0gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmVJdGVyYXRpb24sIHJlamVjdEl0ZXJhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZUl0ZXJhdGlvbiA9IHdyYXAocmVzb2x2ZUl0ZXJhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IGV2ZW50UmVqZWN0SGFuZGxlcihyZWplY3RJdGVyYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmZhaWwgPSByZWplY3RJdGVyYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3Iuc3RvcCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5zdG9wID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmNvbnRpbnVlID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5jb250aW51ZVByaW1hcnlLZXkgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5hZHZhbmNlID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9UaHJvd0N1cnNvcklzU3RvcHBlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlSXRlcmF0aW9uKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZ3VhcmRlZENhbGxiYWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcS5yZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5mYWlsKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmRvbmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5zdGFydCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDdXJzb3IgYmVoaW5kIGxhc3QgZW50cnknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvci5zdG9wKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcS5vbnN1Y2Nlc3MgPSB3cmFwKGZ1bmN0aW9uIChldikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLm9uc3VjY2VzcyA9IGd1YXJkZWRDYWxsYmFjaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGd1YXJkZWRDYWxsYmFjaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmNvbnRpbnVlID0gX2N1cnNvckNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3IuY29udGludWVQcmltYXJ5S2V5ID0gX2N1cnNvckNvbnRpbnVlUHJpbWFyeUtleTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmFkdmFuY2UgPSBfY3Vyc29yQWR2YW5jZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ3VhcmRlZENhbGxiYWNrKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpdGVyYXRpb25Qcm9taXNlO1xuICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShjdXJzb3IpO1xuICAgICAgICAgICAgICAgICAgfSwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGZ1bmN0aW9uIHF1ZXJ5KGhhc0dldEFsbCwgaGFzSWRiM0ZlYXR1cmVzKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAocmVxdWVzdCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSA9IHdyYXAocmVzb2x2ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIHRyYW5zID0gcmVxdWVzdC50cmFucywgdmFsdWVzID0gcmVxdWVzdC52YWx1ZXMsIGxpbWl0ID0gcmVxdWVzdC5saW1pdCwgcXVlcnkgPSByZXF1ZXN0LnF1ZXJ5O1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBkaXJlY3Rpb24gPSAoX2EgPSByZXF1ZXN0LmRpcmVjdGlvbikgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogJ25leHQnO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBub25JbmZpbml0TGltaXQgPSBsaW1pdCA9PT0gSW5maW5pdHkgPyB1bmRlZmluZWQgOiBsaW1pdDtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSBxdWVyeS5pbmRleCwgcmFuZ2UgPSBxdWVyeS5yYW5nZTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmUgPSB0cmFucy5vYmplY3RTdG9yZSh0YWJsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBzb3VyY2UgPSBpbmRleC5pc1ByaW1hcnlLZXkgPyBzdG9yZSA6IHN0b3JlLmluZGV4KGluZGV4Lm5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBpZGJLZXlSYW5nZSA9IG1ha2VJREJLZXlSYW5nZShyYW5nZSk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGxpbWl0ID09PSAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzb2x2ZSh7IHJlc3VsdDogW10gfSk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGhhc0lkYjNGZWF0dXJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgb3B0aW9ucyA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBpZGJLZXlSYW5nZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBub25JbmZpbml0TGltaXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3Rpb246IGRpcmVjdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcSA9IHZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzb3VyY2UuZ2V0QWxsKG9wdGlvbnMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNvdXJjZS5nZXRBbGxLZXlzKG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXEub25zdWNjZXNzID0gZnVuY3Rpb24gKGV2ZW50KSB7IHJldHVybiByZXNvbHZlKHsgcmVzdWx0OiBldmVudC50YXJnZXQucmVzdWx0IH0pOyB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IGV2ZW50UmVqZWN0SGFuZGxlcihyZWplY3QpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChoYXNHZXRBbGwgJiYgZGlyZWN0aW9uID09PSAnbmV4dCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcSA9IHZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzb3VyY2UuZ2V0QWxsKGlkYktleVJhbmdlLCBub25JbmZpbml0TGltaXQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNvdXJjZS5nZXRBbGxLZXlzKGlkYktleVJhbmdlLCBub25JbmZpbml0TGltaXQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXEub25zdWNjZXNzID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzb2x2ZSh7IHJlc3VsdDogZXZlbnQudGFyZ2V0LnJlc3VsdCB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBldmVudFJlamVjdEhhbmRsZXIocmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb3VudF8xID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcV8xID0gdmFsdWVzIHx8ICEoJ29wZW5LZXlDdXJzb3InIGluIHNvdXJjZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gc291cmNlLm9wZW5DdXJzb3IoaWRiS2V5UmFuZ2UsIGRpcmVjdGlvbilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc291cmNlLm9wZW5LZXlDdXJzb3IoaWRiS2V5UmFuZ2UsIGRpcmVjdGlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHRfMSA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXFfMS5vbnN1Y2Nlc3MgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY3Vyc29yID0gcmVxXzEucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFjdXJzb3IpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoeyByZXN1bHQ6IHJlc3VsdF8xIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0XzEucHVzaCh2YWx1ZXMgPyBjdXJzb3IudmFsdWUgOiBjdXJzb3IucHJpbWFyeUtleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKytjb3VudF8xID09PSBsaW1pdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzb2x2ZSh7IHJlc3VsdDogcmVzdWx0XzEgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3IuY29udGludWUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxXzEub25lcnJvciA9IGV2ZW50UmVqZWN0SGFuZGxlcihyZWplY3QpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBuYW1lOiB0YWJsZU5hbWUsXG4gICAgICAgICAgICAgIHNjaGVtYTogdGFibGVTY2hlbWEsXG4gICAgICAgICAgICAgIG11dGF0ZTogbXV0YXRlLFxuICAgICAgICAgICAgICBnZXRNYW55OiBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICAgICAgICAgIHZhciB0cmFucyA9IF9hLnRyYW5zLCBrZXlzID0gX2Eua2V5cztcbiAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSA9IHdyYXAocmVzb2x2ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIHN0b3JlID0gdHJhbnMub2JqZWN0U3RvcmUodGFibGVOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgbGVuZ3RoID0ga2V5cy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IG5ldyBBcnJheShsZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBrZXlDb3VudCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGNhbGxiYWNrQ291bnQgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciByZXE7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIHN1Y2Nlc3NIYW5kbGVyID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXEgPSBldmVudC50YXJnZXQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgocmVzdWx0W3JlcS5fcG9zXSA9IHJlcS5yZXN1bHQpICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgrK2NhbGxiYWNrQ291bnQgPT09IGtleUNvdW50KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGVycm9ySGFuZGxlciA9IGV2ZW50UmVqZWN0SGFuZGxlcihyZWplY3QpO1xuICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGtleSA9IGtleXNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChrZXkgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxID0gc3RvcmUuZ2V0KGtleXNbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLl9wb3MgPSBpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLm9uc3VjY2VzcyA9IHN1Y2Nlc3NIYW5kbGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBlcnJvckhhbmRsZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICArK2tleUNvdW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGlmIChrZXlDb3VudCA9PT0gMClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgdHJhbnMgPSBfYS50cmFucywga2V5ID0gX2Eua2V5O1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlID0gd3JhcChyZXNvbHZlKTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmUgPSB0cmFucy5vYmplY3RTdG9yZSh0YWJsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciByZXEgPSBzdG9yZS5nZXQoa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICByZXEub25zdWNjZXNzID0gZnVuY3Rpb24gKGV2ZW50KSB7IHJldHVybiByZXNvbHZlKGV2ZW50LnRhcmdldC5yZXN1bHQpOyB9O1xuICAgICAgICAgICAgICAgICAgICAgIHJlcS5vbmVycm9yID0gZXZlbnRSZWplY3RIYW5kbGVyKHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcXVlcnk6IHF1ZXJ5KGhhc0dldEFsbCwgaGFzSWRiM0ZlYXR1cmVzKSxcbiAgICAgICAgICAgICAgb3BlbkN1cnNvcjogb3BlbkN1cnNvcixcbiAgICAgICAgICAgICAgY291bnQ6IGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgICAgdmFyIHF1ZXJ5ID0gX2EucXVlcnksIHRyYW5zID0gX2EudHJhbnM7XG4gICAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSBxdWVyeS5pbmRleCwgcmFuZ2UgPSBxdWVyeS5yYW5nZTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIHN0b3JlID0gdHJhbnMub2JqZWN0U3RvcmUodGFibGVOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgc291cmNlID0gaW5kZXguaXNQcmltYXJ5S2V5ID8gc3RvcmUgOiBzdG9yZS5pbmRleChpbmRleC5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgaWRiS2V5UmFuZ2UgPSBtYWtlSURCS2V5UmFuZ2UocmFuZ2UpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciByZXEgPSBpZGJLZXlSYW5nZSA/IHNvdXJjZS5jb3VudChpZGJLZXlSYW5nZSkgOiBzb3VyY2UuY291bnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICByZXEub25zdWNjZXNzID0gd3JhcChmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoZXYudGFyZ2V0LnJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgcmVxLm9uZXJyb3IgPSBldmVudFJlamVjdEhhbmRsZXIocmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9LFxuICAgICAgICAgIH07XG4gICAgICB9XG4gICAgICB2YXIgX2EgPSBleHRyYWN0U2NoZW1hKGRiLCB0bXBUcmFucyksIHNjaGVtYSA9IF9hLnNjaGVtYSwgaGFzR2V0QWxsID0gX2EuaGFzR2V0QWxsLCBoYXNJZGIzRmVhdHVyZXMgPSBfYS5oYXNJZGIzRmVhdHVyZXM7XG4gICAgICB2YXIgdGFibGVzID0gc2NoZW1hLnRhYmxlcy5tYXAoZnVuY3Rpb24gKHRhYmxlU2NoZW1hKSB7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZURiQ29yZVRhYmxlKHRhYmxlU2NoZW1hKTtcbiAgICAgIH0pO1xuICAgICAgdmFyIHRhYmxlTWFwID0ge307XG4gICAgICB0YWJsZXMuZm9yRWFjaChmdW5jdGlvbiAodGFibGUpIHsgcmV0dXJuICh0YWJsZU1hcFt0YWJsZS5uYW1lXSA9IHRhYmxlKTsgfSk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAgIHN0YWNrOiAnZGJjb3JlJyxcbiAgICAgICAgICB0cmFuc2FjdGlvbjogZGIudHJhbnNhY3Rpb24uYmluZChkYiksXG4gICAgICAgICAgdGFibGU6IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgICAgICAgICAgIHZhciByZXN1bHQgPSB0YWJsZU1hcFtuYW1lXTtcbiAgICAgICAgICAgICAgaWYgKCFyZXN1bHQpXG4gICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUYWJsZSAnXCIuY29uY2F0KG5hbWUsIFwiJyBub3QgZm91bmRcIikpO1xuICAgICAgICAgICAgICByZXR1cm4gdGFibGVNYXBbbmFtZV07XG4gICAgICAgICAgfSxcbiAgICAgICAgICBNSU5fS0VZOiAtSW5maW5pdHksXG4gICAgICAgICAgTUFYX0tFWTogZ2V0TWF4S2V5KElkYktleVJhbmdlKSxcbiAgICAgICAgICBzY2hlbWE6IHNjaGVtYSxcbiAgICAgIH07XG4gIH1cblxuICBmdW5jdGlvbiBjcmVhdGVNaWRkbGV3YXJlU3RhY2soc3RhY2tJbXBsLCBtaWRkbGV3YXJlcykge1xuICAgICAgcmV0dXJuIG1pZGRsZXdhcmVzLnJlZHVjZShmdW5jdGlvbiAoZG93biwgX2EpIHtcbiAgICAgICAgICB2YXIgY3JlYXRlID0gX2EuY3JlYXRlO1xuICAgICAgICAgIHJldHVybiAoX19hc3NpZ24oX19hc3NpZ24oe30sIGRvd24pLCBjcmVhdGUoZG93bikpKTtcbiAgICAgIH0sIHN0YWNrSW1wbCk7XG4gIH1cbiAgZnVuY3Rpb24gY3JlYXRlTWlkZGxld2FyZVN0YWNrcyhtaWRkbGV3YXJlcywgaWRiZGIsIF9hLCB0bXBUcmFucykge1xuICAgICAgdmFyIElEQktleVJhbmdlID0gX2EuSURCS2V5UmFuZ2U7IF9hLmluZGV4ZWREQjtcbiAgICAgIHZhciBkYmNvcmUgPSBjcmVhdGVNaWRkbGV3YXJlU3RhY2soY3JlYXRlREJDb3JlKGlkYmRiLCBJREJLZXlSYW5nZSwgdG1wVHJhbnMpLCBtaWRkbGV3YXJlcy5kYmNvcmUpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBkYmNvcmU6IGRiY29yZSxcbiAgICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gZ2VuZXJhdGVNaWRkbGV3YXJlU3RhY2tzKGRiLCB0bXBUcmFucykge1xuICAgICAgdmFyIGlkYmRiID0gdG1wVHJhbnMuZGI7XG4gICAgICB2YXIgc3RhY2tzID0gY3JlYXRlTWlkZGxld2FyZVN0YWNrcyhkYi5fbWlkZGxld2FyZXMsIGlkYmRiLCBkYi5fZGVwcywgdG1wVHJhbnMpO1xuICAgICAgZGIuY29yZSA9IHN0YWNrcy5kYmNvcmU7XG4gICAgICBkYi50YWJsZXMuZm9yRWFjaChmdW5jdGlvbiAodGFibGUpIHtcbiAgICAgICAgICB2YXIgdGFibGVOYW1lID0gdGFibGUubmFtZTtcbiAgICAgICAgICBpZiAoZGIuY29yZS5zY2hlbWEudGFibGVzLnNvbWUoZnVuY3Rpb24gKHRibCkgeyByZXR1cm4gdGJsLm5hbWUgPT09IHRhYmxlTmFtZTsgfSkpIHtcbiAgICAgICAgICAgICAgdGFibGUuY29yZSA9IGRiLmNvcmUudGFibGUodGFibGVOYW1lKTtcbiAgICAgICAgICAgICAgaWYgKGRiW3RhYmxlTmFtZV0gaW5zdGFuY2VvZiBkYi5UYWJsZSkge1xuICAgICAgICAgICAgICAgICAgZGJbdGFibGVOYW1lXS5jb3JlID0gdGFibGUuY29yZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gc2V0QXBpT25QbGFjZShkYiwgb2JqcywgdGFibGVOYW1lcywgZGJzY2hlbWEpIHtcbiAgICAgIHRhYmxlTmFtZXMuZm9yRWFjaChmdW5jdGlvbiAodGFibGVOYW1lKSB7XG4gICAgICAgICAgdmFyIHNjaGVtYSA9IGRic2NoZW1hW3RhYmxlTmFtZV07XG4gICAgICAgICAgb2Jqcy5mb3JFYWNoKGZ1bmN0aW9uIChvYmopIHtcbiAgICAgICAgICAgICAgdmFyIHByb3BEZXNjID0gZ2V0UHJvcGVydHlEZXNjcmlwdG9yKG9iaiwgdGFibGVOYW1lKTtcbiAgICAgICAgICAgICAgaWYgKCFwcm9wRGVzYyB8fCAoJ3ZhbHVlJyBpbiBwcm9wRGVzYyAmJiBwcm9wRGVzYy52YWx1ZSA9PT0gdW5kZWZpbmVkKSkge1xuICAgICAgICAgICAgICAgICAgaWYgKG9iaiA9PT0gZGIuVHJhbnNhY3Rpb24ucHJvdG90eXBlIHx8IG9iaiBpbnN0YW5jZW9mIGRiLlRyYW5zYWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0UHJvcChvYmosIHRhYmxlTmFtZSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnRhYmxlKHRhYmxlTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldDogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZpbmVQcm9wZXJ0eSh0aGlzLCB0YWJsZU5hbWUsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgIG9ialt0YWJsZU5hbWVdID0gbmV3IGRiLlRhYmxlKHRhYmxlTmFtZSwgc2NoZW1hKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gcmVtb3ZlVGFibGVzQXBpKGRiLCBvYmpzKSB7XG4gICAgICBvYmpzLmZvckVhY2goZnVuY3Rpb24gKG9iaikge1xuICAgICAgICAgIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICAgICAgICAgICAgaWYgKG9ialtrZXldIGluc3RhbmNlb2YgZGIuVGFibGUpXG4gICAgICAgICAgICAgICAgICBkZWxldGUgb2JqW2tleV07XG4gICAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gbG93ZXJWZXJzaW9uRmlyc3QoYSwgYikge1xuICAgICAgcmV0dXJuIGEuX2NmZy52ZXJzaW9uIC0gYi5fY2ZnLnZlcnNpb247XG4gIH1cbiAgZnVuY3Rpb24gcnVuVXBncmFkZXJzKGRiLCBvbGRWZXJzaW9uLCBpZGJVcGdyYWRlVHJhbnMsIHJlamVjdCkge1xuICAgICAgdmFyIGdsb2JhbFNjaGVtYSA9IGRiLl9kYlNjaGVtYTtcbiAgICAgIGlmIChpZGJVcGdyYWRlVHJhbnMub2JqZWN0U3RvcmVOYW1lcy5jb250YWlucygnJG1ldGEnKSAmJlxuICAgICAgICAgICFnbG9iYWxTY2hlbWEuJG1ldGEpIHtcbiAgICAgICAgICBnbG9iYWxTY2hlbWEuJG1ldGEgPSBjcmVhdGVUYWJsZVNjaGVtYSgnJG1ldGEnLCBwYXJzZUluZGV4U3ludGF4KCcnKVswXSwgW10pO1xuICAgICAgICAgIGRiLl9zdG9yZU5hbWVzLnB1c2goJyRtZXRhJyk7XG4gICAgICB9XG4gICAgICB2YXIgdHJhbnMgPSBkYi5fY3JlYXRlVHJhbnNhY3Rpb24oJ3JlYWR3cml0ZScsIGRiLl9zdG9yZU5hbWVzLCBnbG9iYWxTY2hlbWEpO1xuICAgICAgdHJhbnMuY3JlYXRlKGlkYlVwZ3JhZGVUcmFucyk7XG4gICAgICB0cmFucy5fY29tcGxldGlvbi5jYXRjaChyZWplY3QpO1xuICAgICAgdmFyIHJlamVjdFRyYW5zYWN0aW9uID0gdHJhbnMuX3JlamVjdC5iaW5kKHRyYW5zKTtcbiAgICAgIHZhciB0cmFuc2xlc3MgPSBQU0QudHJhbnNsZXNzIHx8IFBTRDtcbiAgICAgIG5ld1Njb3BlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBQU0QudHJhbnMgPSB0cmFucztcbiAgICAgICAgICBQU0QudHJhbnNsZXNzID0gdHJhbnNsZXNzO1xuICAgICAgICAgIGlmIChvbGRWZXJzaW9uID09PSAwKSB7XG4gICAgICAgICAgICAgIGtleXMoZ2xvYmFsU2NoZW1hKS5mb3JFYWNoKGZ1bmN0aW9uICh0YWJsZU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZVRhYmxlKGlkYlVwZ3JhZGVUcmFucywgdGFibGVOYW1lLCBnbG9iYWxTY2hlbWFbdGFibGVOYW1lXS5wcmltS2V5LCBnbG9iYWxTY2hlbWFbdGFibGVOYW1lXS5pbmRleGVzKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIGdlbmVyYXRlTWlkZGxld2FyZVN0YWNrcyhkYiwgaWRiVXBncmFkZVRyYW5zKTtcbiAgICAgICAgICAgICAgRGV4aWVQcm9taXNlLmZvbGxvdyhmdW5jdGlvbiAoKSB7IHJldHVybiBkYi5vbi5wb3B1bGF0ZS5maXJlKHRyYW5zKTsgfSkuY2F0Y2gocmVqZWN0VHJhbnNhY3Rpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgZ2VuZXJhdGVNaWRkbGV3YXJlU3RhY2tzKGRiLCBpZGJVcGdyYWRlVHJhbnMpO1xuICAgICAgICAgICAgICByZXR1cm4gZ2V0RXhpc3RpbmdWZXJzaW9uKGRiLCB0cmFucywgb2xkVmVyc2lvbilcbiAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChvbGRWZXJzaW9uKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdXBkYXRlVGFibGVzQW5kSW5kZXhlcyhkYiwgb2xkVmVyc2lvbiwgdHJhbnMsIGlkYlVwZ3JhZGVUcmFucyk7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAuY2F0Y2gocmVqZWN0VHJhbnNhY3Rpb24pO1xuICAgICAgICAgIH1cbiAgICAgIH0pO1xuICB9XG4gIGZ1bmN0aW9uIHBhdGNoQ3VycmVudFZlcnNpb24oZGIsIGlkYlVwZ3JhZGVUcmFucykge1xuICAgICAgY3JlYXRlTWlzc2luZ1RhYmxlcyhkYi5fZGJTY2hlbWEsIGlkYlVwZ3JhZGVUcmFucyk7XG4gICAgICBpZiAoaWRiVXBncmFkZVRyYW5zLmRiLnZlcnNpb24gJSAxMCA9PT0gMCAmJlxuICAgICAgICAgICFpZGJVcGdyYWRlVHJhbnMub2JqZWN0U3RvcmVOYW1lcy5jb250YWlucygnJG1ldGEnKSkge1xuICAgICAgICAgIGlkYlVwZ3JhZGVUcmFucy5kYlxuICAgICAgICAgICAgICAuY3JlYXRlT2JqZWN0U3RvcmUoJyRtZXRhJylcbiAgICAgICAgICAgICAgLmFkZChNYXRoLmNlaWwoaWRiVXBncmFkZVRyYW5zLmRiLnZlcnNpb24gLyAxMCAtIDEpLCAndmVyc2lvbicpO1xuICAgICAgfVxuICAgICAgdmFyIGdsb2JhbFNjaGVtYSA9IGJ1aWxkR2xvYmFsU2NoZW1hKGRiLCBkYi5pZGJkYiwgaWRiVXBncmFkZVRyYW5zKTtcbiAgICAgIGFkanVzdFRvRXhpc3RpbmdJbmRleE5hbWVzKGRiLCBkYi5fZGJTY2hlbWEsIGlkYlVwZ3JhZGVUcmFucyk7XG4gICAgICB2YXIgZGlmZiA9IGdldFNjaGVtYURpZmYoZ2xvYmFsU2NoZW1hLCBkYi5fZGJTY2hlbWEpO1xuICAgICAgdmFyIF9sb29wXzEgPSBmdW5jdGlvbiAodGFibGVDaGFuZ2UpIHtcbiAgICAgICAgICBpZiAodGFibGVDaGFuZ2UuY2hhbmdlLmxlbmd0aCB8fCB0YWJsZUNoYW5nZS5yZWNyZWF0ZSkge1xuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJVbmFibGUgdG8gcGF0Y2ggaW5kZXhlcyBvZiB0YWJsZSBcIi5jb25jYXQodGFibGVDaGFuZ2UubmFtZSwgXCIgYmVjYXVzZSBpdCBoYXMgY2hhbmdlcyBvbiB0aGUgdHlwZSBvZiBpbmRleCBvciBwcmltYXJ5IGtleS5cIikpO1xuICAgICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogdm9pZCAwIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhciBzdG9yZSA9IGlkYlVwZ3JhZGVUcmFucy5vYmplY3RTdG9yZSh0YWJsZUNoYW5nZS5uYW1lKTtcbiAgICAgICAgICB0YWJsZUNoYW5nZS5hZGQuZm9yRWFjaChmdW5jdGlvbiAoaWR4KSB7XG4gICAgICAgICAgICAgIGlmIChkZWJ1ZylcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZGVidWcoXCJEZXhpZSB1cGdyYWRlIHBhdGNoOiBDcmVhdGluZyBtaXNzaW5nIGluZGV4IFwiLmNvbmNhdCh0YWJsZUNoYW5nZS5uYW1lLCBcIi5cIikuY29uY2F0KGlkeC5zcmMpKTtcbiAgICAgICAgICAgICAgYWRkSW5kZXgoc3RvcmUsIGlkeCk7XG4gICAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IGRpZmYuY2hhbmdlOyBfaSA8IF9hLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgIHZhciB0YWJsZUNoYW5nZSA9IF9hW19pXTtcbiAgICAgICAgICB2YXIgc3RhdGVfMSA9IF9sb29wXzEodGFibGVDaGFuZ2UpO1xuICAgICAgICAgIGlmICh0eXBlb2Ygc3RhdGVfMSA9PT0gXCJvYmplY3RcIilcbiAgICAgICAgICAgICAgcmV0dXJuIHN0YXRlXzEudmFsdWU7XG4gICAgICB9XG4gIH1cbiAgZnVuY3Rpb24gZ2V0RXhpc3RpbmdWZXJzaW9uKGRiLCB0cmFucywgb2xkVmVyc2lvbikge1xuICAgICAgaWYgKHRyYW5zLnN0b3JlTmFtZXMuaW5jbHVkZXMoJyRtZXRhJykpIHtcbiAgICAgICAgICByZXR1cm4gdHJhbnNcbiAgICAgICAgICAgICAgLnRhYmxlKCckbWV0YScpXG4gICAgICAgICAgICAgIC5nZXQoJ3ZlcnNpb24nKVxuICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAobWV0YVZlcnNpb24pIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG1ldGFWZXJzaW9uICE9IG51bGwgPyBtZXRhVmVyc2lvbiA6IG9sZFZlcnNpb247XG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gRGV4aWVQcm9taXNlLnJlc29sdmUob2xkVmVyc2lvbik7XG4gICAgICB9XG4gIH1cbiAgZnVuY3Rpb24gdXBkYXRlVGFibGVzQW5kSW5kZXhlcyhkYiwgb2xkVmVyc2lvbiwgdHJhbnMsIGlkYlVwZ3JhZGVUcmFucykge1xuICAgICAgdmFyIHF1ZXVlID0gW107XG4gICAgICB2YXIgdmVyc2lvbnMgPSBkYi5fdmVyc2lvbnM7XG4gICAgICB2YXIgZ2xvYmFsU2NoZW1hID0gKGRiLl9kYlNjaGVtYSA9IGJ1aWxkR2xvYmFsU2NoZW1hKGRiLCBkYi5pZGJkYiwgaWRiVXBncmFkZVRyYW5zKSk7XG4gICAgICB2YXIgdmVyc1RvUnVuID0gdmVyc2lvbnMuZmlsdGVyKGZ1bmN0aW9uICh2KSB7IHJldHVybiB2Ll9jZmcudmVyc2lvbiA+PSBvbGRWZXJzaW9uOyB9KTtcbiAgICAgIGlmICh2ZXJzVG9SdW4ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIERleGllUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICB9XG4gICAgICB2ZXJzVG9SdW4uZm9yRWFjaChmdW5jdGlvbiAodmVyc2lvbikge1xuICAgICAgICAgIHF1ZXVlLnB1c2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICB2YXIgb2xkU2NoZW1hID0gZ2xvYmFsU2NoZW1hO1xuICAgICAgICAgICAgICB2YXIgbmV3U2NoZW1hID0gdmVyc2lvbi5fY2ZnLmRic2NoZW1hO1xuICAgICAgICAgICAgICBhZGp1c3RUb0V4aXN0aW5nSW5kZXhOYW1lcyhkYiwgb2xkU2NoZW1hLCBpZGJVcGdyYWRlVHJhbnMpO1xuICAgICAgICAgICAgICBhZGp1c3RUb0V4aXN0aW5nSW5kZXhOYW1lcyhkYiwgbmV3U2NoZW1hLCBpZGJVcGdyYWRlVHJhbnMpO1xuICAgICAgICAgICAgICBnbG9iYWxTY2hlbWEgPSBkYi5fZGJTY2hlbWEgPSBuZXdTY2hlbWE7XG4gICAgICAgICAgICAgIHZhciBkaWZmID0gZ2V0U2NoZW1hRGlmZihvbGRTY2hlbWEsIG5ld1NjaGVtYSk7XG4gICAgICAgICAgICAgIGRpZmYuYWRkLmZvckVhY2goZnVuY3Rpb24gKHR1cGxlKSB7XG4gICAgICAgICAgICAgICAgICBjcmVhdGVUYWJsZShpZGJVcGdyYWRlVHJhbnMsIHR1cGxlWzBdLCB0dXBsZVsxXS5wcmltS2V5LCB0dXBsZVsxXS5pbmRleGVzKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIGRpZmYuY2hhbmdlLmZvckVhY2goZnVuY3Rpb24gKGNoYW5nZSkge1xuICAgICAgICAgICAgICAgICAgaWYgKGNoYW5nZS5yZWNyZWF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLlVwZ3JhZGUoJ05vdCB5ZXQgc3VwcG9ydCBmb3IgY2hhbmdpbmcgcHJpbWFyeSBrZXknKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBzdG9yZV8xID0gaWRiVXBncmFkZVRyYW5zLm9iamVjdFN0b3JlKGNoYW5nZS5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICBjaGFuZ2UuYWRkLmZvckVhY2goZnVuY3Rpb24gKGlkeCkgeyByZXR1cm4gYWRkSW5kZXgoc3RvcmVfMSwgaWR4KTsgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgY2hhbmdlLmNoYW5nZS5mb3JFYWNoKGZ1bmN0aW9uIChpZHgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RvcmVfMS5kZWxldGVJbmRleChpZHgubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkZEluZGV4KHN0b3JlXzEsIGlkeCk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgY2hhbmdlLmRlbC5mb3JFYWNoKGZ1bmN0aW9uIChpZHhOYW1lKSB7IHJldHVybiBzdG9yZV8xLmRlbGV0ZUluZGV4KGlkeE5hbWUpOyB9KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHZhciBjb250ZW50VXBncmFkZSA9IHZlcnNpb24uX2NmZy5jb250ZW50VXBncmFkZTtcbiAgICAgICAgICAgICAgaWYgKGNvbnRlbnRVcGdyYWRlICYmIHZlcnNpb24uX2NmZy52ZXJzaW9uID4gb2xkVmVyc2lvbikge1xuICAgICAgICAgICAgICAgICAgZ2VuZXJhdGVNaWRkbGV3YXJlU3RhY2tzKGRiLCBpZGJVcGdyYWRlVHJhbnMpO1xuICAgICAgICAgICAgICAgICAgdHJhbnMuX21lbW9pemVkVGFibGVzID0ge307XG4gICAgICAgICAgICAgICAgICB2YXIgdXBncmFkZVNjaGVtYV8xID0gc2hhbGxvd0Nsb25lKG5ld1NjaGVtYSk7XG4gICAgICAgICAgICAgICAgICBkaWZmLmRlbC5mb3JFYWNoKGZ1bmN0aW9uICh0YWJsZSkge1xuICAgICAgICAgICAgICAgICAgICAgIHVwZ3JhZGVTY2hlbWFfMVt0YWJsZV0gPSBvbGRTY2hlbWFbdGFibGVdO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICByZW1vdmVUYWJsZXNBcGkoZGIsIFtkYi5UcmFuc2FjdGlvbi5wcm90b3R5cGVdKTtcbiAgICAgICAgICAgICAgICAgIHNldEFwaU9uUGxhY2UoZGIsIFtkYi5UcmFuc2FjdGlvbi5wcm90b3R5cGVdLCBrZXlzKHVwZ3JhZGVTY2hlbWFfMSksIHVwZ3JhZGVTY2hlbWFfMSk7XG4gICAgICAgICAgICAgICAgICB0cmFucy5zY2hlbWEgPSB1cGdyYWRlU2NoZW1hXzE7XG4gICAgICAgICAgICAgICAgICB2YXIgY29udGVudFVwZ3JhZGVJc0FzeW5jXzEgPSBpc0FzeW5jRnVuY3Rpb24oY29udGVudFVwZ3JhZGUpO1xuICAgICAgICAgICAgICAgICAgaWYgKGNvbnRlbnRVcGdyYWRlSXNBc3luY18xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaW5jcmVtZW50RXhwZWN0ZWRBd2FpdHMoKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHZhciByZXR1cm5WYWx1ZV8xO1xuICAgICAgICAgICAgICAgICAgdmFyIHByb21pc2VGb2xsb3dlZCA9IERleGllUHJvbWlzZS5mb2xsb3coZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVyblZhbHVlXzEgPSBjb250ZW50VXBncmFkZSh0cmFucyk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHJldHVyblZhbHVlXzEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbnRlbnRVcGdyYWRlSXNBc3luY18xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGVjcmVtZW50b3IgPSBkZWNyZW1lbnRFeHBlY3RlZEF3YWl0cy5iaW5kKG51bGwsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuVmFsdWVfMS50aGVuKGRlY3JlbWVudG9yLCBkZWNyZW1lbnRvcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiByZXR1cm5WYWx1ZV8xICYmIHR5cGVvZiByZXR1cm5WYWx1ZV8xLnRoZW4gPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgICAgICAgICAgICA/IERleGllUHJvbWlzZS5yZXNvbHZlKHJldHVyblZhbHVlXzEpXG4gICAgICAgICAgICAgICAgICAgICAgOiBwcm9taXNlRm9sbG93ZWQudGhlbihmdW5jdGlvbiAoKSB7IHJldHVybiByZXR1cm5WYWx1ZV8xOyB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHF1ZXVlLnB1c2goZnVuY3Rpb24gKGlkYnRyYW5zKSB7XG4gICAgICAgICAgICAgIHZhciBuZXdTY2hlbWEgPSB2ZXJzaW9uLl9jZmcuZGJzY2hlbWE7XG4gICAgICAgICAgICAgIGRlbGV0ZVJlbW92ZWRUYWJsZXMobmV3U2NoZW1hLCBpZGJ0cmFucyk7XG4gICAgICAgICAgICAgIHJlbW92ZVRhYmxlc0FwaShkYiwgW2RiLlRyYW5zYWN0aW9uLnByb3RvdHlwZV0pO1xuICAgICAgICAgICAgICBzZXRBcGlPblBsYWNlKGRiLCBbZGIuVHJhbnNhY3Rpb24ucHJvdG90eXBlXSwgZGIuX3N0b3JlTmFtZXMsIGRiLl9kYlNjaGVtYSk7XG4gICAgICAgICAgICAgIHRyYW5zLnNjaGVtYSA9IGRiLl9kYlNjaGVtYTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBxdWV1ZS5wdXNoKGZ1bmN0aW9uIChpZGJ0cmFucykge1xuICAgICAgICAgICAgICBpZiAoZGIuaWRiZGIub2JqZWN0U3RvcmVOYW1lcy5jb250YWlucygnJG1ldGEnKSkge1xuICAgICAgICAgICAgICAgICAgaWYgKE1hdGguY2VpbChkYi5pZGJkYi52ZXJzaW9uIC8gMTApID09PSB2ZXJzaW9uLl9jZmcudmVyc2lvbikge1xuICAgICAgICAgICAgICAgICAgICAgIGRiLmlkYmRiLmRlbGV0ZU9iamVjdFN0b3JlKCckbWV0YScpO1xuICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBkYi5fZGJTY2hlbWEuJG1ldGE7XG4gICAgICAgICAgICAgICAgICAgICAgZGIuX3N0b3JlTmFtZXMgPSBkYi5fc3RvcmVOYW1lcy5maWx0ZXIoZnVuY3Rpb24gKG5hbWUpIHsgcmV0dXJuIG5hbWUgIT09ICckbWV0YSc7IH0pO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWRidHJhbnMub2JqZWN0U3RvcmUoJyRtZXRhJykucHV0KHZlcnNpb24uX2NmZy52ZXJzaW9uLCAndmVyc2lvbicpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIGZ1bmN0aW9uIHJ1blF1ZXVlKCkge1xuICAgICAgICAgIHJldHVybiBxdWV1ZS5sZW5ndGhcbiAgICAgICAgICAgICAgPyBEZXhpZVByb21pc2UucmVzb2x2ZShxdWV1ZS5zaGlmdCgpKHRyYW5zLmlkYnRyYW5zKSkudGhlbihydW5RdWV1ZSlcbiAgICAgICAgICAgICAgOiBEZXhpZVByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJ1blF1ZXVlKCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgY3JlYXRlTWlzc2luZ1RhYmxlcyhnbG9iYWxTY2hlbWEsIGlkYlVwZ3JhZGVUcmFucyk7XG4gICAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBnZXRTY2hlbWFEaWZmKG9sZFNjaGVtYSwgbmV3U2NoZW1hKSB7XG4gICAgICB2YXIgZGlmZiA9IHtcbiAgICAgICAgICBkZWw6IFtdLFxuICAgICAgICAgIGFkZDogW10sXG4gICAgICAgICAgY2hhbmdlOiBbXSxcbiAgICAgIH07XG4gICAgICB2YXIgdGFibGU7XG4gICAgICBmb3IgKHRhYmxlIGluIG9sZFNjaGVtYSkge1xuICAgICAgICAgIGlmICghbmV3U2NoZW1hW3RhYmxlXSlcbiAgICAgICAgICAgICAgZGlmZi5kZWwucHVzaCh0YWJsZSk7XG4gICAgICB9XG4gICAgICBmb3IgKHRhYmxlIGluIG5ld1NjaGVtYSkge1xuICAgICAgICAgIHZhciBvbGREZWYgPSBvbGRTY2hlbWFbdGFibGVdLCBuZXdEZWYgPSBuZXdTY2hlbWFbdGFibGVdO1xuICAgICAgICAgIGlmICghb2xkRGVmKSB7XG4gICAgICAgICAgICAgIGRpZmYuYWRkLnB1c2goW3RhYmxlLCBuZXdEZWZdKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgIHZhciBjaGFuZ2UgPSB7XG4gICAgICAgICAgICAgICAgICBuYW1lOiB0YWJsZSxcbiAgICAgICAgICAgICAgICAgIGRlZjogbmV3RGVmLFxuICAgICAgICAgICAgICAgICAgcmVjcmVhdGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgZGVsOiBbXSxcbiAgICAgICAgICAgICAgICAgIGFkZDogW10sXG4gICAgICAgICAgICAgICAgICBjaGFuZ2U6IFtdLFxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICcnICsgKG9sZERlZi5wcmltS2V5LmtleVBhdGggfHwgJycpICE9PVxuICAgICAgICAgICAgICAgICAgJycgKyAobmV3RGVmLnByaW1LZXkua2V5UGF0aCB8fCAnJykgfHxcbiAgICAgICAgICAgICAgICAgIG9sZERlZi5wcmltS2V5LmF1dG8gIT09IG5ld0RlZi5wcmltS2V5LmF1dG8pIHtcbiAgICAgICAgICAgICAgICAgIGNoYW5nZS5yZWNyZWF0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICBkaWZmLmNoYW5nZS5wdXNoKGNoYW5nZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICB2YXIgb2xkSW5kZXhlcyA9IG9sZERlZi5pZHhCeU5hbWU7XG4gICAgICAgICAgICAgICAgICB2YXIgbmV3SW5kZXhlcyA9IG5ld0RlZi5pZHhCeU5hbWU7XG4gICAgICAgICAgICAgICAgICB2YXIgaWR4TmFtZSA9IHZvaWQgMDtcbiAgICAgICAgICAgICAgICAgIGZvciAoaWR4TmFtZSBpbiBvbGRJbmRleGVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKCFuZXdJbmRleGVzW2lkeE5hbWVdKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFuZ2UuZGVsLnB1c2goaWR4TmFtZSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBmb3IgKGlkeE5hbWUgaW4gbmV3SW5kZXhlcykge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBvbGRJZHggPSBvbGRJbmRleGVzW2lkeE5hbWVdLCBuZXdJZHggPSBuZXdJbmRleGVzW2lkeE5hbWVdO1xuICAgICAgICAgICAgICAgICAgICAgIGlmICghb2xkSWR4KVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFuZ2UuYWRkLnB1c2gobmV3SWR4KTtcbiAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChvbGRJZHguc3JjICE9PSBuZXdJZHguc3JjKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFuZ2UuY2hhbmdlLnB1c2gobmV3SWR4KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChjaGFuZ2UuZGVsLmxlbmd0aCA+IDAgfHxcbiAgICAgICAgICAgICAgICAgICAgICBjaGFuZ2UuYWRkLmxlbmd0aCA+IDAgfHxcbiAgICAgICAgICAgICAgICAgICAgICBjaGFuZ2UuY2hhbmdlLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICBkaWZmLmNoYW5nZS5wdXNoKGNoYW5nZSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gZGlmZjtcbiAgfVxuICBmdW5jdGlvbiBjcmVhdGVUYWJsZShpZGJ0cmFucywgdGFibGVOYW1lLCBwcmltS2V5LCBpbmRleGVzKSB7XG4gICAgICB2YXIgc3RvcmUgPSBpZGJ0cmFucy5kYi5jcmVhdGVPYmplY3RTdG9yZSh0YWJsZU5hbWUsIHByaW1LZXkua2V5UGF0aFxuICAgICAgICAgID8geyBrZXlQYXRoOiBwcmltS2V5LmtleVBhdGgsIGF1dG9JbmNyZW1lbnQ6IHByaW1LZXkuYXV0byB9XG4gICAgICAgICAgOiB7IGF1dG9JbmNyZW1lbnQ6IHByaW1LZXkuYXV0byB9KTtcbiAgICAgIGluZGV4ZXMuZm9yRWFjaChmdW5jdGlvbiAoaWR4KSB7IHJldHVybiBhZGRJbmRleChzdG9yZSwgaWR4KTsgfSk7XG4gICAgICByZXR1cm4gc3RvcmU7XG4gIH1cbiAgZnVuY3Rpb24gY3JlYXRlTWlzc2luZ1RhYmxlcyhuZXdTY2hlbWEsIGlkYnRyYW5zKSB7XG4gICAgICBrZXlzKG5ld1NjaGVtYSkuZm9yRWFjaChmdW5jdGlvbiAodGFibGVOYW1lKSB7XG4gICAgICAgICAgaWYgKCFpZGJ0cmFucy5kYi5vYmplY3RTdG9yZU5hbWVzLmNvbnRhaW5zKHRhYmxlTmFtZSkpIHtcbiAgICAgICAgICAgICAgaWYgKGRlYnVnKVxuICAgICAgICAgICAgICAgICAgY29uc29sZS5kZWJ1ZygnRGV4aWU6IENyZWF0aW5nIG1pc3NpbmcgdGFibGUnLCB0YWJsZU5hbWUpO1xuICAgICAgICAgICAgICBjcmVhdGVUYWJsZShpZGJ0cmFucywgdGFibGVOYW1lLCBuZXdTY2hlbWFbdGFibGVOYW1lXS5wcmltS2V5LCBuZXdTY2hlbWFbdGFibGVOYW1lXS5pbmRleGVzKTtcbiAgICAgICAgICB9XG4gICAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBkZWxldGVSZW1vdmVkVGFibGVzKG5ld1NjaGVtYSwgaWRidHJhbnMpIHtcbiAgICAgIFtdLnNsaWNlXG4gICAgICAgICAgLmNhbGwoaWRidHJhbnMuZGIub2JqZWN0U3RvcmVOYW1lcylcbiAgICAgICAgICAuZm9yRWFjaChmdW5jdGlvbiAoc3RvcmVOYW1lKSB7XG4gICAgICAgICAgcmV0dXJuIG5ld1NjaGVtYVtzdG9yZU5hbWVdID09IG51bGwgJiYgaWRidHJhbnMuZGIuZGVsZXRlT2JqZWN0U3RvcmUoc3RvcmVOYW1lKTtcbiAgICAgIH0pO1xuICB9XG4gIGZ1bmN0aW9uIGFkZEluZGV4KHN0b3JlLCBpZHgpIHtcbiAgICAgIHN0b3JlLmNyZWF0ZUluZGV4KGlkeC5uYW1lLCBpZHgua2V5UGF0aCwge1xuICAgICAgICAgIHVuaXF1ZTogaWR4LnVuaXF1ZSxcbiAgICAgICAgICBtdWx0aUVudHJ5OiBpZHgubXVsdGksXG4gICAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBidWlsZEdsb2JhbFNjaGVtYShkYiwgaWRiZGIsIHRtcFRyYW5zKSB7XG4gICAgICB2YXIgZ2xvYmFsU2NoZW1hID0ge307XG4gICAgICB2YXIgZGJTdG9yZU5hbWVzID0gc2xpY2UoaWRiZGIub2JqZWN0U3RvcmVOYW1lcywgMCk7XG4gICAgICBkYlN0b3JlTmFtZXMuZm9yRWFjaChmdW5jdGlvbiAoc3RvcmVOYW1lKSB7XG4gICAgICAgICAgdmFyIHN0b3JlID0gdG1wVHJhbnMub2JqZWN0U3RvcmUoc3RvcmVOYW1lKTtcbiAgICAgICAgICB2YXIga2V5UGF0aCA9IHN0b3JlLmtleVBhdGg7XG4gICAgICAgICAgdmFyIHByaW1LZXkgPSBjcmVhdGVJbmRleFNwZWMobmFtZUZyb21LZXlQYXRoKGtleVBhdGgpLCBrZXlQYXRoIHx8ICcnLCB0cnVlLCBmYWxzZSwgISFzdG9yZS5hdXRvSW5jcmVtZW50LCBrZXlQYXRoICYmIHR5cGVvZiBrZXlQYXRoICE9PSAnc3RyaW5nJywgdHJ1ZSk7XG4gICAgICAgICAgdmFyIGluZGV4ZXMgPSBbXTtcbiAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHN0b3JlLmluZGV4TmFtZXMubGVuZ3RoOyArK2opIHtcbiAgICAgICAgICAgICAgdmFyIGlkYmluZGV4ID0gc3RvcmUuaW5kZXgoc3RvcmUuaW5kZXhOYW1lc1tqXSk7XG4gICAgICAgICAgICAgIGtleVBhdGggPSBpZGJpbmRleC5rZXlQYXRoO1xuICAgICAgICAgICAgICB2YXIgaW5kZXggPSBjcmVhdGVJbmRleFNwZWMoaWRiaW5kZXgubmFtZSwga2V5UGF0aCwgISFpZGJpbmRleC51bmlxdWUsICEhaWRiaW5kZXgubXVsdGlFbnRyeSwgZmFsc2UsIGtleVBhdGggJiYgdHlwZW9mIGtleVBhdGggIT09ICdzdHJpbmcnLCBmYWxzZSk7XG4gICAgICAgICAgICAgIGluZGV4ZXMucHVzaChpbmRleCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGdsb2JhbFNjaGVtYVtzdG9yZU5hbWVdID0gY3JlYXRlVGFibGVTY2hlbWEoc3RvcmVOYW1lLCBwcmltS2V5LCBpbmRleGVzKTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGdsb2JhbFNjaGVtYTtcbiAgfVxuICBmdW5jdGlvbiByZWFkR2xvYmFsU2NoZW1hKGRiLCBpZGJkYiwgdG1wVHJhbnMpIHtcbiAgICAgIGRiLnZlcm5vID0gaWRiZGIudmVyc2lvbiAvIDEwO1xuICAgICAgdmFyIGdsb2JhbFNjaGVtYSA9IChkYi5fZGJTY2hlbWEgPSBidWlsZEdsb2JhbFNjaGVtYShkYiwgaWRiZGIsIHRtcFRyYW5zKSk7XG4gICAgICBkYi5fc3RvcmVOYW1lcyA9IHNsaWNlKGlkYmRiLm9iamVjdFN0b3JlTmFtZXMsIDApO1xuICAgICAgc2V0QXBpT25QbGFjZShkYiwgW2RiLl9hbGxUYWJsZXNdLCBrZXlzKGdsb2JhbFNjaGVtYSksIGdsb2JhbFNjaGVtYSk7XG4gIH1cbiAgZnVuY3Rpb24gdmVyaWZ5SW5zdGFsbGVkU2NoZW1hKGRiLCB0bXBUcmFucykge1xuICAgICAgdmFyIGluc3RhbGxlZFNjaGVtYSA9IGJ1aWxkR2xvYmFsU2NoZW1hKGRiLCBkYi5pZGJkYiwgdG1wVHJhbnMpO1xuICAgICAgdmFyIGRpZmYgPSBnZXRTY2hlbWFEaWZmKGluc3RhbGxlZFNjaGVtYSwgZGIuX2RiU2NoZW1hKTtcbiAgICAgIHJldHVybiAhKGRpZmYuYWRkLmxlbmd0aCB8fFxuICAgICAgICAgIGRpZmYuY2hhbmdlLnNvbWUoZnVuY3Rpb24gKGNoKSB7IHJldHVybiBjaC5hZGQubGVuZ3RoIHx8IGNoLmNoYW5nZS5sZW5ndGg7IH0pKTtcbiAgfVxuICBmdW5jdGlvbiBhZGp1c3RUb0V4aXN0aW5nSW5kZXhOYW1lcyhkYiwgc2NoZW1hLCBpZGJ0cmFucykge1xuICAgICAgdmFyIHN0b3JlTmFtZXMgPSBpZGJ0cmFucy5kYi5vYmplY3RTdG9yZU5hbWVzO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzdG9yZU5hbWVzLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgdmFyIHN0b3JlTmFtZSA9IHN0b3JlTmFtZXNbaV07XG4gICAgICAgICAgdmFyIHN0b3JlID0gaWRidHJhbnMub2JqZWN0U3RvcmUoc3RvcmVOYW1lKTtcbiAgICAgICAgICBkYi5faGFzR2V0QWxsID0gJ2dldEFsbCcgaW4gc3RvcmU7XG4gICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBzdG9yZS5pbmRleE5hbWVzLmxlbmd0aDsgKytqKSB7XG4gICAgICAgICAgICAgIHZhciBpbmRleE5hbWUgPSBzdG9yZS5pbmRleE5hbWVzW2pdO1xuICAgICAgICAgICAgICB2YXIga2V5UGF0aCA9IHN0b3JlLmluZGV4KGluZGV4TmFtZSkua2V5UGF0aDtcbiAgICAgICAgICAgICAgdmFyIGRleGllTmFtZSA9IHR5cGVvZiBrZXlQYXRoID09PSAnc3RyaW5nJ1xuICAgICAgICAgICAgICAgICAgPyBrZXlQYXRoXG4gICAgICAgICAgICAgICAgICA6ICdbJyArIHNsaWNlKGtleVBhdGgpLmpvaW4oJysnKSArICddJztcbiAgICAgICAgICAgICAgaWYgKHNjaGVtYVtzdG9yZU5hbWVdKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgaW5kZXhTcGVjID0gc2NoZW1hW3N0b3JlTmFtZV0uaWR4QnlOYW1lW2RleGllTmFtZV07XG4gICAgICAgICAgICAgICAgICBpZiAoaW5kZXhTcGVjKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaW5kZXhTcGVjLm5hbWUgPSBpbmRleE5hbWU7XG4gICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHNjaGVtYVtzdG9yZU5hbWVdLmlkeEJ5TmFtZVtkZXhpZU5hbWVdO1xuICAgICAgICAgICAgICAgICAgICAgIHNjaGVtYVtzdG9yZU5hbWVdLmlkeEJ5TmFtZVtpbmRleE5hbWVdID0gaW5kZXhTcGVjO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICAgICAgL1NhZmFyaS8udGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSAmJlxuICAgICAgICAgICEvKENocm9tZVxcL3xFZGdlXFwvKS8udGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSAmJlxuICAgICAgICAgIF9nbG9iYWwuV29ya2VyR2xvYmFsU2NvcGUgJiZcbiAgICAgICAgICBfZ2xvYmFsIGluc3RhbmNlb2YgX2dsb2JhbC5Xb3JrZXJHbG9iYWxTY29wZSAmJlxuICAgICAgICAgIFtdLmNvbmNhdChuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9TYWZhcmlcXC8oXFxkKikvKSlbMV0gPCA2MDQpIHtcbiAgICAgICAgICBkYi5faGFzR2V0QWxsID0gZmFsc2U7XG4gICAgICB9XG4gIH1cbiAgZnVuY3Rpb24gcGFyc2VJbmRleFN5bnRheChwcmltS2V5QW5kSW5kZXhlcykge1xuICAgICAgcmV0dXJuIHByaW1LZXlBbmRJbmRleGVzLnNwbGl0KCcsJykubWFwKGZ1bmN0aW9uIChpbmRleCwgaW5kZXhOdW0pIHtcbiAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgdmFyIHR5cGVTcGxpdCA9IGluZGV4LnNwbGl0KCc6Jyk7XG4gICAgICAgICAgdmFyIHR5cGUgPSAoX2EgPSB0eXBlU3BsaXRbMV0pID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS50cmltKCk7XG4gICAgICAgICAgaW5kZXggPSB0eXBlU3BsaXRbMF0udHJpbSgpO1xuICAgICAgICAgIHZhciBuYW1lID0gaW5kZXgucmVwbGFjZSgvKFsmKl18XFwrXFwrKS9nLCAnJyk7XG4gICAgICAgICAgdmFyIGtleVBhdGggPSAvXlxcWy8udGVzdChuYW1lKVxuICAgICAgICAgICAgICA/IG5hbWUubWF0Y2goL15cXFsoLiopXFxdJC8pWzFdLnNwbGl0KCcrJylcbiAgICAgICAgICAgICAgOiBuYW1lO1xuICAgICAgICAgIHJldHVybiBjcmVhdGVJbmRleFNwZWMobmFtZSwga2V5UGF0aCB8fCBudWxsLCAvXFwmLy50ZXN0KGluZGV4KSwgL1xcKi8udGVzdChpbmRleCksIC9cXCtcXCsvLnRlc3QoaW5kZXgpLCBpc0FycmF5KGtleVBhdGgpLCBpbmRleE51bSA9PT0gMCwgdHlwZSk7XG4gICAgICB9KTtcbiAgfVxuXG4gIHZhciBWZXJzaW9uID0gIChmdW5jdGlvbiAoKSB7XG4gICAgICBmdW5jdGlvbiBWZXJzaW9uKCkge1xuICAgICAgfVxuICAgICAgVmVyc2lvbi5wcm90b3R5cGUuX2NyZWF0ZVRhYmxlU2NoZW1hID0gZnVuY3Rpb24gKG5hbWUsIHByaW1LZXksIGluZGV4ZXMpIHtcbiAgICAgICAgICByZXR1cm4gY3JlYXRlVGFibGVTY2hlbWEobmFtZSwgcHJpbUtleSwgaW5kZXhlcyk7XG4gICAgICB9O1xuICAgICAgVmVyc2lvbi5wcm90b3R5cGUuX3BhcnNlSW5kZXhTeW50YXggPSBmdW5jdGlvbiAocHJpbUtleUFuZEluZGV4ZXMpIHtcbiAgICAgICAgICByZXR1cm4gcGFyc2VJbmRleFN5bnRheChwcmltS2V5QW5kSW5kZXhlcyk7XG4gICAgICB9O1xuICAgICAgVmVyc2lvbi5wcm90b3R5cGUuX3BhcnNlU3RvcmVzU3BlYyA9IGZ1bmN0aW9uIChzdG9yZXMsIG91dFNjaGVtYSkge1xuICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAga2V5cyhzdG9yZXMpLmZvckVhY2goZnVuY3Rpb24gKHRhYmxlTmFtZSkge1xuICAgICAgICAgICAgICBpZiAoc3RvcmVzW3RhYmxlTmFtZV0gIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBpbmRleGVzID0gX3RoaXMuX3BhcnNlSW5kZXhTeW50YXgoc3RvcmVzW3RhYmxlTmFtZV0pO1xuICAgICAgICAgICAgICAgICAgdmFyIHByaW1LZXkgPSBpbmRleGVzLnNoaWZ0KCk7XG4gICAgICAgICAgICAgICAgICBpZiAoIXByaW1LZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgZXhjZXB0aW9ucy5TY2hlbWEoJ0ludmFsaWQgc2NoZW1hIGZvciB0YWJsZSAnICsgdGFibGVOYW1lICsgJzogJyArIHN0b3Jlc1t0YWJsZU5hbWVdKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHByaW1LZXkudW5pcXVlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgIGlmIChwcmltS2V5Lm11bHRpKVxuICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLlNjaGVtYSgnUHJpbWFyeSBrZXkgY2Fubm90IGJlIG11bHRpRW50cnkqJyk7XG4gICAgICAgICAgICAgICAgICBpbmRleGVzLmZvckVhY2goZnVuY3Rpb24gKGlkeCkge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChpZHguYXV0bylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuU2NoZW1hKCdPbmx5IHByaW1hcnkga2V5IGNhbiBiZSBtYXJrZWQgYXMgYXV0b0luY3JlbWVudCAoKyspJyk7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKCFpZHgua2V5UGF0aClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuU2NoZW1hKCdJbmRleCBtdXN0IGhhdmUgYSBuYW1lIGFuZCBjYW5ub3QgYmUgYW4gZW1wdHkgc3RyaW5nJyk7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIHZhciB0YmxTY2hlbWEgPSBfdGhpcy5fY3JlYXRlVGFibGVTY2hlbWEodGFibGVOYW1lLCBwcmltS2V5LCBpbmRleGVzKTtcbiAgICAgICAgICAgICAgICAgIG91dFNjaGVtYVt0YWJsZU5hbWVdID0gdGJsU2NoZW1hO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICB9O1xuICAgICAgVmVyc2lvbi5wcm90b3R5cGUuc3RvcmVzID0gZnVuY3Rpb24gKHN0b3Jlcykge1xuICAgICAgICAgIHZhciBkYiA9IHRoaXMuZGI7XG4gICAgICAgICAgdGhpcy5fY2ZnLnN0b3Jlc1NvdXJjZSA9IHRoaXMuX2NmZy5zdG9yZXNTb3VyY2VcbiAgICAgICAgICAgICAgPyBleHRlbmQodGhpcy5fY2ZnLnN0b3Jlc1NvdXJjZSwgc3RvcmVzKVxuICAgICAgICAgICAgICA6IHN0b3JlcztcbiAgICAgICAgICB2YXIgdmVyc2lvbnMgPSBkYi5fdmVyc2lvbnM7XG4gICAgICAgICAgdmFyIHN0b3Jlc1NwZWMgPSB7fTtcbiAgICAgICAgICB2YXIgZGJzY2hlbWEgPSB7fTtcbiAgICAgICAgICB2ZXJzaW9ucy5mb3JFYWNoKGZ1bmN0aW9uICh2ZXJzaW9uKSB7XG4gICAgICAgICAgICAgIGV4dGVuZChzdG9yZXNTcGVjLCB2ZXJzaW9uLl9jZmcuc3RvcmVzU291cmNlKTtcbiAgICAgICAgICAgICAgZGJzY2hlbWEgPSB2ZXJzaW9uLl9jZmcuZGJzY2hlbWEgPSB7fTtcbiAgICAgICAgICAgICAgdmVyc2lvbi5fcGFyc2VTdG9yZXNTcGVjKHN0b3Jlc1NwZWMsIGRic2NoZW1hKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBkYi5fZGJTY2hlbWEgPSBkYnNjaGVtYTtcbiAgICAgICAgICByZW1vdmVUYWJsZXNBcGkoZGIsIFtkYi5fYWxsVGFibGVzLCBkYiwgZGIuVHJhbnNhY3Rpb24ucHJvdG90eXBlXSk7XG4gICAgICAgICAgc2V0QXBpT25QbGFjZShkYiwgW2RiLl9hbGxUYWJsZXMsIGRiLCBkYi5UcmFuc2FjdGlvbi5wcm90b3R5cGUsIHRoaXMuX2NmZy50YWJsZXNdLCBrZXlzKGRic2NoZW1hKSwgZGJzY2hlbWEpO1xuICAgICAgICAgIGRiLl9zdG9yZU5hbWVzID0ga2V5cyhkYnNjaGVtYSk7XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgVmVyc2lvbi5wcm90b3R5cGUudXBncmFkZSA9IGZ1bmN0aW9uICh1cGdyYWRlRnVuY3Rpb24pIHtcbiAgICAgICAgICB0aGlzLl9jZmcuY29udGVudFVwZ3JhZGUgPSBwcm9taXNhYmxlQ2hhaW4odGhpcy5fY2ZnLmNvbnRlbnRVcGdyYWRlIHx8IG5vcCwgdXBncmFkZUZ1bmN0aW9uKTtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH07XG4gICAgICByZXR1cm4gVmVyc2lvbjtcbiAgfSgpKTtcblxuICBmdW5jdGlvbiBjcmVhdGVWZXJzaW9uQ29uc3RydWN0b3IoZGIpIHtcbiAgICAgIHJldHVybiBtYWtlQ2xhc3NDb25zdHJ1Y3RvcihWZXJzaW9uLnByb3RvdHlwZSwgZnVuY3Rpb24gVmVyc2lvbih2ZXJzaW9uTnVtYmVyKSB7XG4gICAgICAgICAgdGhpcy5kYiA9IGRiO1xuICAgICAgICAgIHRoaXMuX2NmZyA9IHtcbiAgICAgICAgICAgICAgdmVyc2lvbjogdmVyc2lvbk51bWJlcixcbiAgICAgICAgICAgICAgc3RvcmVzU291cmNlOiBudWxsLFxuICAgICAgICAgICAgICBkYnNjaGVtYToge30sXG4gICAgICAgICAgICAgIHRhYmxlczoge30sXG4gICAgICAgICAgICAgIGNvbnRlbnRVcGdyYWRlOiBudWxsLFxuICAgICAgICAgIH07XG4gICAgICB9KTtcbiAgfVxuXG4gIHZhciBjb25uZWN0aW9ucyA9IGNyZWF0ZUNvbm5lY3Rpb25zTWFuYWdlcigpO1xuICBmdW5jdGlvbiBjcmVhdGVDb25uZWN0aW9uc01hbmFnZXIoKSB7XG4gICAgICBpZiAodHlwZW9mIEZpbmFsaXphdGlvblJlZ2lzdHJ5ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgICAgICAgIHR5cGVvZiBXZWFrUmVmICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgIHZhciBfcmVmc18xID0gbmV3IFNldCgpO1xuICAgICAgICAgIHZhciBfcmVnaXN0cnlfMSA9IG5ldyBGaW5hbGl6YXRpb25SZWdpc3RyeShmdW5jdGlvbiAocmVmKSB7XG4gICAgICAgICAgICAgIF9yZWZzXzEuZGVsZXRlKHJlZik7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdmFyIHRvQXJyYXkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBBcnJheS5mcm9tKF9yZWZzXzEpXG4gICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChyZWYpIHsgcmV0dXJuIHJlZi5kZXJlZigpOyB9KVxuICAgICAgICAgICAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoZGIpIHsgcmV0dXJuIGRiICE9PSB1bmRlZmluZWQ7IH0pO1xuICAgICAgICAgIH07XG4gICAgICAgICAgdmFyIGFkZCA9IGZ1bmN0aW9uIChkYikge1xuICAgICAgICAgICAgICB2YXIgcmVmID0gbmV3IFdlYWtSZWYoZGIuX25vdmlwKTtcbiAgICAgICAgICAgICAgX3JlZnNfMS5hZGQocmVmKTtcbiAgICAgICAgICAgICAgX3JlZ2lzdHJ5XzEucmVnaXN0ZXIoZGIuX25vdmlwLCByZWYsIHJlZik7XG4gICAgICAgICAgICAgIGlmIChfcmVmc18xLnNpemUgPiBkYi5fb3B0aW9ucy5tYXhDb25uZWN0aW9ucykge1xuICAgICAgICAgICAgICAgICAgdmFyIG9sZGVzdFJlZiA9IF9yZWZzXzEudmFsdWVzKCkubmV4dCgpLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgX3JlZnNfMS5kZWxldGUob2xkZXN0UmVmKTtcbiAgICAgICAgICAgICAgICAgIF9yZWdpc3RyeV8xLnVucmVnaXN0ZXIob2xkZXN0UmVmKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgICAgdmFyIHJlbW92ZSA9IGZ1bmN0aW9uIChkYikge1xuICAgICAgICAgICAgICBpZiAoIWRiKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB2YXIgaXRlcmF0b3IgPSBfcmVmc18xLnZhbHVlcygpO1xuICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpO1xuICAgICAgICAgICAgICB3aGlsZSAoIXJlc3VsdC5kb25lKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgcmVmID0gcmVzdWx0LnZhbHVlO1xuICAgICAgICAgICAgICAgICAgaWYgKHJlZi5kZXJlZigpID09PSBkYi5fbm92aXApIHtcbiAgICAgICAgICAgICAgICAgICAgICBfcmVmc18xLmRlbGV0ZShyZWYpO1xuICAgICAgICAgICAgICAgICAgICAgIF9yZWdpc3RyeV8xLnVucmVnaXN0ZXIocmVmKTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICAgIHJldHVybiB7IHRvQXJyYXk6IHRvQXJyYXksIGFkZDogYWRkLCByZW1vdmU6IHJlbW92ZSB9O1xuICAgICAgfVxuICAgICAgZWxzZSB7XG4gICAgICAgICAgdmFyIGNvbm5lY3Rpb25zXzEgPSBbXTtcbiAgICAgICAgICB2YXIgdG9BcnJheSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIGNvbm5lY3Rpb25zXzE7IH07XG4gICAgICAgICAgdmFyIGFkZCA9IGZ1bmN0aW9uIChkYikge1xuICAgICAgICAgICAgICBjb25uZWN0aW9uc18xLnB1c2goZGIuX25vdmlwKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHZhciByZW1vdmUgPSBmdW5jdGlvbiAoZGIpIHtcbiAgICAgICAgICAgICAgaWYgKCFkYilcbiAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgdmFyIGluZGV4ID0gY29ubmVjdGlvbnNfMS5pbmRleE9mKGRiLl9ub3ZpcCk7XG4gICAgICAgICAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgICAgIGNvbm5lY3Rpb25zXzEuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgICAgcmV0dXJuIHsgdG9BcnJheTogdG9BcnJheSwgYWRkOiBhZGQsIHJlbW92ZTogcmVtb3ZlIH07XG4gICAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBnZXREYk5hbWVzVGFibGUoaW5kZXhlZERCLCBJREJLZXlSYW5nZSkge1xuICAgICAgdmFyIGRiTmFtZXNEQiA9IGluZGV4ZWREQlsnX2RiTmFtZXNEQiddO1xuICAgICAgaWYgKCFkYk5hbWVzREIpIHtcbiAgICAgICAgICBkYk5hbWVzREIgPSBpbmRleGVkREJbJ19kYk5hbWVzREInXSA9IG5ldyBEZXhpZSQxKERCTkFNRVNfREIsIHtcbiAgICAgICAgICAgICAgYWRkb25zOiBbXSxcbiAgICAgICAgICAgICAgaW5kZXhlZERCOiBpbmRleGVkREIsXG4gICAgICAgICAgICAgIElEQktleVJhbmdlOiBJREJLZXlSYW5nZSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBkYk5hbWVzREIudmVyc2lvbigxKS5zdG9yZXMoeyBkYm5hbWVzOiAnbmFtZScgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGJOYW1lc0RCLnRhYmxlKCdkYm5hbWVzJyk7XG4gIH1cbiAgZnVuY3Rpb24gaGFzRGF0YWJhc2VzTmF0aXZlKGluZGV4ZWREQikge1xuICAgICAgcmV0dXJuIGluZGV4ZWREQiAmJiB0eXBlb2YgaW5kZXhlZERCLmRhdGFiYXNlcyA9PT0gJ2Z1bmN0aW9uJztcbiAgfVxuICBmdW5jdGlvbiBnZXREYXRhYmFzZU5hbWVzKF9hKSB7XG4gICAgICB2YXIgaW5kZXhlZERCID0gX2EuaW5kZXhlZERCLCBJREJLZXlSYW5nZSA9IF9hLklEQktleVJhbmdlO1xuICAgICAgcmV0dXJuIGhhc0RhdGFiYXNlc05hdGl2ZShpbmRleGVkREIpXG4gICAgICAgICAgPyBQcm9taXNlLnJlc29sdmUoaW5kZXhlZERCLmRhdGFiYXNlcygpKS50aGVuKGZ1bmN0aW9uIChpbmZvcykge1xuICAgICAgICAgICAgICByZXR1cm4gaW5mb3NcbiAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGluZm8pIHsgcmV0dXJuIGluZm8ubmFtZTsgfSlcbiAgICAgICAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKG5hbWUpIHsgcmV0dXJuIG5hbWUgIT09IERCTkFNRVNfREI7IH0pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgOiBnZXREYk5hbWVzVGFibGUoaW5kZXhlZERCLCBJREJLZXlSYW5nZSkudG9Db2xsZWN0aW9uKCkucHJpbWFyeUtleXMoKTtcbiAgfVxuICBmdW5jdGlvbiBfb25EYXRhYmFzZUNyZWF0ZWQoX2EsIG5hbWUpIHtcbiAgICAgIHZhciBpbmRleGVkREIgPSBfYS5pbmRleGVkREIsIElEQktleVJhbmdlID0gX2EuSURCS2V5UmFuZ2U7XG4gICAgICAhaGFzRGF0YWJhc2VzTmF0aXZlKGluZGV4ZWREQikgJiZcbiAgICAgICAgICBuYW1lICE9PSBEQk5BTUVTX0RCICYmXG4gICAgICAgICAgZ2V0RGJOYW1lc1RhYmxlKGluZGV4ZWREQiwgSURCS2V5UmFuZ2UpLnB1dCh7IG5hbWU6IG5hbWUgfSkuY2F0Y2gobm9wKTtcbiAgfVxuICBmdW5jdGlvbiBfb25EYXRhYmFzZURlbGV0ZWQoX2EsIG5hbWUpIHtcbiAgICAgIHZhciBpbmRleGVkREIgPSBfYS5pbmRleGVkREIsIElEQktleVJhbmdlID0gX2EuSURCS2V5UmFuZ2U7XG4gICAgICAhaGFzRGF0YWJhc2VzTmF0aXZlKGluZGV4ZWREQikgJiZcbiAgICAgICAgICBuYW1lICE9PSBEQk5BTUVTX0RCICYmXG4gICAgICAgICAgZ2V0RGJOYW1lc1RhYmxlKGluZGV4ZWREQiwgSURCS2V5UmFuZ2UpLmRlbGV0ZShuYW1lKS5jYXRjaChub3ApO1xuICB9XG5cbiAgZnVuY3Rpb24gdmlwKGZuKSB7XG4gICAgICByZXR1cm4gbmV3U2NvcGUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgIFBTRC5sZXRUaHJvdWdoID0gdHJ1ZTtcbiAgICAgICAgICByZXR1cm4gZm4oKTtcbiAgICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gaWRiUmVhZHkoKSB7XG4gICAgICB2YXIgaXNTYWZhcmkgPSAhbmF2aWdhdG9yLnVzZXJBZ2VudERhdGEgJiZcbiAgICAgICAgICAvU2FmYXJpXFwvLy50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpICYmXG4gICAgICAgICAgIS9DaHJvbShlfGl1bSlcXC8vLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCk7XG4gICAgICBpZiAoIWlzU2FmYXJpIHx8ICFpbmRleGVkREIuZGF0YWJhc2VzKVxuICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgIHZhciBpbnRlcnZhbElkO1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlKSB7XG4gICAgICAgICAgdmFyIHRyeUlkYiA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIGluZGV4ZWREQi5kYXRhYmFzZXMoKS5maW5hbGx5KHJlc29sdmUpOyB9O1xuICAgICAgICAgIGludGVydmFsSWQgPSBzZXRJbnRlcnZhbCh0cnlJZGIsIDEwMCk7XG4gICAgICAgICAgdHJ5SWRiKCk7XG4gICAgICB9KS5maW5hbGx5KGZ1bmN0aW9uICgpIHsgcmV0dXJuIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZCk7IH0pO1xuICB9XG5cbiAgdmFyIF9hO1xuICBmdW5jdGlvbiBpc0VtcHR5UmFuZ2Uobm9kZSkge1xuICAgICAgcmV0dXJuICEoJ2Zyb20nIGluIG5vZGUpO1xuICB9XG4gIHZhciBSYW5nZVNldCA9IGZ1bmN0aW9uIChmcm9tT3JUcmVlLCB0bykge1xuICAgICAgaWYgKHRoaXMpIHtcbiAgICAgICAgICBleHRlbmQodGhpcywgYXJndW1lbnRzLmxlbmd0aFxuICAgICAgICAgICAgICA/IHsgZDogMSwgZnJvbTogZnJvbU9yVHJlZSwgdG86IGFyZ3VtZW50cy5sZW5ndGggPiAxID8gdG8gOiBmcm9tT3JUcmVlIH1cbiAgICAgICAgICAgICAgOiB7IGQ6IDAgfSk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgICB2YXIgcnYgPSBuZXcgUmFuZ2VTZXQoKTtcbiAgICAgICAgICBpZiAoZnJvbU9yVHJlZSAmJiAnZCcgaW4gZnJvbU9yVHJlZSkge1xuICAgICAgICAgICAgICBleHRlbmQocnYsIGZyb21PclRyZWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcnY7XG4gICAgICB9XG4gIH07XG4gIHByb3BzKFJhbmdlU2V0LnByb3RvdHlwZSwgKF9hID0ge1xuICAgICAgICAgIGFkZDogZnVuY3Rpb24gKHJhbmdlU2V0KSB7XG4gICAgICAgICAgICAgIG1lcmdlUmFuZ2VzKHRoaXMsIHJhbmdlU2V0KTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBhZGRLZXk6IGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgICAgICAgICAgYWRkUmFuZ2UodGhpcywga2V5LCBrZXkpO1xuICAgICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICB9LFxuICAgICAgICAgIGFkZEtleXM6IGZ1bmN0aW9uIChrZXlzKSB7XG4gICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgIGtleXMuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7IHJldHVybiBhZGRSYW5nZShfdGhpcywga2V5LCBrZXkpOyB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBoYXNLZXk6IGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgICAgICAgICAgdmFyIG5vZGUgPSBnZXRSYW5nZVNldEl0ZXJhdG9yKHRoaXMpLm5leHQoa2V5KS52YWx1ZTtcbiAgICAgICAgICAgICAgcmV0dXJuIG5vZGUgJiYgY21wKG5vZGUuZnJvbSwga2V5KSA8PSAwICYmIGNtcChub2RlLnRvLCBrZXkpID49IDA7XG4gICAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIF9hW2l0ZXJhdG9yU3ltYm9sXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gZ2V0UmFuZ2VTZXRJdGVyYXRvcih0aGlzKTtcbiAgICAgIH0sXG4gICAgICBfYSkpO1xuICBmdW5jdGlvbiBhZGRSYW5nZSh0YXJnZXQsIGZyb20sIHRvKSB7XG4gICAgICB2YXIgZGlmZiA9IGNtcChmcm9tLCB0byk7XG4gICAgICBpZiAoaXNOYU4oZGlmZikpXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgaWYgKGRpZmYgPiAwKVxuICAgICAgICAgIHRocm93IFJhbmdlRXJyb3IoKTtcbiAgICAgIGlmIChpc0VtcHR5UmFuZ2UodGFyZ2V0KSlcbiAgICAgICAgICByZXR1cm4gZXh0ZW5kKHRhcmdldCwgeyBmcm9tOiBmcm9tLCB0bzogdG8sIGQ6IDEgfSk7XG4gICAgICB2YXIgbGVmdCA9IHRhcmdldC5sO1xuICAgICAgdmFyIHJpZ2h0ID0gdGFyZ2V0LnI7XG4gICAgICBpZiAoY21wKHRvLCB0YXJnZXQuZnJvbSkgPCAwKSB7XG4gICAgICAgICAgbGVmdFxuICAgICAgICAgICAgICA/IGFkZFJhbmdlKGxlZnQsIGZyb20sIHRvKVxuICAgICAgICAgICAgICA6ICh0YXJnZXQubCA9IHsgZnJvbTogZnJvbSwgdG86IHRvLCBkOiAxLCBsOiBudWxsLCByOiBudWxsIH0pO1xuICAgICAgICAgIHJldHVybiByZWJhbGFuY2UodGFyZ2V0KTtcbiAgICAgIH1cbiAgICAgIGlmIChjbXAoZnJvbSwgdGFyZ2V0LnRvKSA+IDApIHtcbiAgICAgICAgICByaWdodFxuICAgICAgICAgICAgICA/IGFkZFJhbmdlKHJpZ2h0LCBmcm9tLCB0bylcbiAgICAgICAgICAgICAgOiAodGFyZ2V0LnIgPSB7IGZyb206IGZyb20sIHRvOiB0bywgZDogMSwgbDogbnVsbCwgcjogbnVsbCB9KTtcbiAgICAgICAgICByZXR1cm4gcmViYWxhbmNlKHRhcmdldCk7XG4gICAgICB9XG4gICAgICBpZiAoY21wKGZyb20sIHRhcmdldC5mcm9tKSA8IDApIHtcbiAgICAgICAgICB0YXJnZXQuZnJvbSA9IGZyb207XG4gICAgICAgICAgdGFyZ2V0LmwgPSBudWxsO1xuICAgICAgICAgIHRhcmdldC5kID0gcmlnaHQgPyByaWdodC5kICsgMSA6IDE7XG4gICAgICB9XG4gICAgICBpZiAoY21wKHRvLCB0YXJnZXQudG8pID4gMCkge1xuICAgICAgICAgIHRhcmdldC50byA9IHRvO1xuICAgICAgICAgIHRhcmdldC5yID0gbnVsbDtcbiAgICAgICAgICB0YXJnZXQuZCA9IHRhcmdldC5sID8gdGFyZ2V0LmwuZCArIDEgOiAxO1xuICAgICAgfVxuICAgICAgdmFyIHJpZ2h0V2FzQ3V0T2ZmID0gIXRhcmdldC5yO1xuICAgICAgaWYgKGxlZnQgJiYgIXRhcmdldC5sKSB7XG4gICAgICAgICAgbWVyZ2VSYW5nZXModGFyZ2V0LCBsZWZ0KTtcbiAgICAgIH1cbiAgICAgIGlmIChyaWdodCAmJiByaWdodFdhc0N1dE9mZikge1xuICAgICAgICAgIG1lcmdlUmFuZ2VzKHRhcmdldCwgcmlnaHQpO1xuICAgICAgfVxuICB9XG4gIGZ1bmN0aW9uIG1lcmdlUmFuZ2VzKHRhcmdldCwgbmV3U2V0KSB7XG4gICAgICBmdW5jdGlvbiBfYWRkUmFuZ2VTZXQodGFyZ2V0LCBfYSkge1xuICAgICAgICAgIHZhciBmcm9tID0gX2EuZnJvbSwgdG8gPSBfYS50bywgbCA9IF9hLmwsIHIgPSBfYS5yO1xuICAgICAgICAgIGFkZFJhbmdlKHRhcmdldCwgZnJvbSwgdG8pO1xuICAgICAgICAgIGlmIChsKVxuICAgICAgICAgICAgICBfYWRkUmFuZ2VTZXQodGFyZ2V0LCBsKTtcbiAgICAgICAgICBpZiAocilcbiAgICAgICAgICAgICAgX2FkZFJhbmdlU2V0KHRhcmdldCwgcik7XG4gICAgICB9XG4gICAgICBpZiAoIWlzRW1wdHlSYW5nZShuZXdTZXQpKVxuICAgICAgICAgIF9hZGRSYW5nZVNldCh0YXJnZXQsIG5ld1NldCk7XG4gIH1cbiAgZnVuY3Rpb24gcmFuZ2VzT3ZlcmxhcChyYW5nZVNldDEsIHJhbmdlU2V0Mikge1xuICAgICAgdmFyIGkxID0gZ2V0UmFuZ2VTZXRJdGVyYXRvcihyYW5nZVNldDIpO1xuICAgICAgdmFyIG5leHRSZXN1bHQxID0gaTEubmV4dCgpO1xuICAgICAgaWYgKG5leHRSZXN1bHQxLmRvbmUpXG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgdmFyIGEgPSBuZXh0UmVzdWx0MS52YWx1ZTtcbiAgICAgIHZhciBpMiA9IGdldFJhbmdlU2V0SXRlcmF0b3IocmFuZ2VTZXQxKTtcbiAgICAgIHZhciBuZXh0UmVzdWx0MiA9IGkyLm5leHQoYS5mcm9tKTtcbiAgICAgIHZhciBiID0gbmV4dFJlc3VsdDIudmFsdWU7XG4gICAgICB3aGlsZSAoIW5leHRSZXN1bHQxLmRvbmUgJiYgIW5leHRSZXN1bHQyLmRvbmUpIHtcbiAgICAgICAgICBpZiAoY21wKGIuZnJvbSwgYS50bykgPD0gMCAmJiBjbXAoYi50bywgYS5mcm9tKSA+PSAwKVxuICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICBjbXAoYS5mcm9tLCBiLmZyb20pIDwgMFxuICAgICAgICAgICAgICA/IChhID0gKG5leHRSZXN1bHQxID0gaTEubmV4dChiLmZyb20pKS52YWx1ZSlcbiAgICAgICAgICAgICAgOiAoYiA9IChuZXh0UmVzdWx0MiA9IGkyLm5leHQoYS5mcm9tKSkudmFsdWUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZ1bmN0aW9uIGdldFJhbmdlU2V0SXRlcmF0b3Iobm9kZSkge1xuICAgICAgdmFyIHN0YXRlID0gaXNFbXB0eVJhbmdlKG5vZGUpXG4gICAgICAgICAgPyBudWxsXG4gICAgICAgICAgOiB7IHM6IDAsIG46IG5vZGUgfTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgICAgbmV4dDogZnVuY3Rpb24gKGtleSkge1xuICAgICAgICAgICAgICB2YXIga2V5UHJvdmlkZWQgPSBhcmd1bWVudHMubGVuZ3RoID4gMDtcbiAgICAgICAgICAgICAgd2hpbGUgKHN0YXRlKSB7XG4gICAgICAgICAgICAgICAgICBzd2l0Y2ggKHN0YXRlLnMpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlLnMgPSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoa2V5UHJvdmlkZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChzdGF0ZS5uLmwgJiYgY21wKGtleSwgc3RhdGUubi5mcm9tKSA8IDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGUgPSB7IHVwOiBzdGF0ZSwgbjogc3RhdGUubi5sLCBzOiAxIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aGlsZSAoc3RhdGUubi5sKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlID0geyB1cDogc3RhdGUsIG46IHN0YXRlLm4ubCwgczogMSB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5zID0gMjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFrZXlQcm92aWRlZCB8fCBjbXAoa2V5LCBzdGF0ZS5uLnRvKSA8PSAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHN0YXRlLm4sIGRvbmU6IGZhbHNlIH07XG4gICAgICAgICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RhdGUubi5yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5zID0gMztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlID0geyB1cDogc3RhdGUsIG46IHN0YXRlLm4uciwgczogMCB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlID0gc3RhdGUudXA7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIHsgZG9uZTogdHJ1ZSB9O1xuICAgICAgICAgIH0sXG4gICAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIHJlYmFsYW5jZSh0YXJnZXQpIHtcbiAgICAgIHZhciBfYSwgX2I7XG4gICAgICB2YXIgZGlmZiA9ICgoKF9hID0gdGFyZ2V0LnIpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5kKSB8fCAwKSAtICgoKF9iID0gdGFyZ2V0LmwpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5kKSB8fCAwKTtcbiAgICAgIHZhciByID0gZGlmZiA+IDEgPyAncicgOiBkaWZmIDwgLTEgPyAnbCcgOiAnJztcbiAgICAgIGlmIChyKSB7XG4gICAgICAgICAgdmFyIGwgPSByID09PSAncicgPyAnbCcgOiAncic7XG4gICAgICAgICAgdmFyIHJvb3RDbG9uZSA9IF9fYXNzaWduKHt9LCB0YXJnZXQpO1xuICAgICAgICAgIHZhciBvbGRSb290UmlnaHQgPSB0YXJnZXRbcl07XG4gICAgICAgICAgdGFyZ2V0LmZyb20gPSBvbGRSb290UmlnaHQuZnJvbTtcbiAgICAgICAgICB0YXJnZXQudG8gPSBvbGRSb290UmlnaHQudG87XG4gICAgICAgICAgdGFyZ2V0W3JdID0gb2xkUm9vdFJpZ2h0W3JdO1xuICAgICAgICAgIHJvb3RDbG9uZVtyXSA9IG9sZFJvb3RSaWdodFtsXTtcbiAgICAgICAgICB0YXJnZXRbbF0gPSByb290Q2xvbmU7XG4gICAgICAgICAgcm9vdENsb25lLmQgPSBjb21wdXRlRGVwdGgocm9vdENsb25lKTtcbiAgICAgIH1cbiAgICAgIHRhcmdldC5kID0gY29tcHV0ZURlcHRoKHRhcmdldCk7XG4gIH1cbiAgZnVuY3Rpb24gY29tcHV0ZURlcHRoKF9hKSB7XG4gICAgICB2YXIgciA9IF9hLnIsIGwgPSBfYS5sO1xuICAgICAgcmV0dXJuIChyID8gKGwgPyBNYXRoLm1heChyLmQsIGwuZCkgOiByLmQpIDogbCA/IGwuZCA6IDApICsgMTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGV4dGVuZE9ic2VydmFiaWxpdHlTZXQodGFyZ2V0LCBuZXdTZXQpIHtcbiAgICAgIGtleXMobmV3U2V0KS5mb3JFYWNoKGZ1bmN0aW9uIChwYXJ0KSB7XG4gICAgICAgICAgaWYgKHRhcmdldFtwYXJ0XSlcbiAgICAgICAgICAgICAgbWVyZ2VSYW5nZXModGFyZ2V0W3BhcnRdLCBuZXdTZXRbcGFydF0pO1xuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgdGFyZ2V0W3BhcnRdID0gY2xvbmVTaW1wbGVPYmplY3RUcmVlKG5ld1NldFtwYXJ0XSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB0YXJnZXQ7XG4gIH1cblxuICBmdW5jdGlvbiBvYnNTZXRzT3ZlcmxhcChvczEsIG9zMikge1xuICAgICAgcmV0dXJuIChvczEuYWxsIHx8XG4gICAgICAgICAgb3MyLmFsbCB8fFxuICAgICAgICAgIE9iamVjdC5rZXlzKG9zMSkuc29tZShmdW5jdGlvbiAoa2V5KSB7IHJldHVybiBvczJba2V5XSAmJiByYW5nZXNPdmVybGFwKG9zMltrZXldLCBvczFba2V5XSk7IH0pKTtcbiAgfVxuXG4gIHZhciBjYWNoZSA9IHt9O1xuXG4gIHZhciB1bnNpZ25hbGVkUGFydHMgPSB7fTtcbiAgdmFyIGlzVGFza0VucXVldWVkID0gZmFsc2U7XG4gIGZ1bmN0aW9uIHNpZ25hbFN1YnNjcmliZXJzTGF6aWx5KHBhcnQsIG9wdGltaXN0aWMpIHtcbiAgICAgIGV4dGVuZE9ic2VydmFiaWxpdHlTZXQodW5zaWduYWxlZFBhcnRzLCBwYXJ0KTtcbiAgICAgIGlmICghaXNUYXNrRW5xdWV1ZWQpIHtcbiAgICAgICAgICBpc1Rhc2tFbnF1ZXVlZCA9IHRydWU7XG4gICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIGlzVGFza0VucXVldWVkID0gZmFsc2U7XG4gICAgICAgICAgICAgIHZhciBwYXJ0cyA9IHVuc2lnbmFsZWRQYXJ0cztcbiAgICAgICAgICAgICAgdW5zaWduYWxlZFBhcnRzID0ge307XG4gICAgICAgICAgICAgIHNpZ25hbFN1YnNjcmliZXJzTm93KHBhcnRzLCBmYWxzZSk7XG4gICAgICAgICAgfSwgMCk7XG4gICAgICB9XG4gIH1cbiAgZnVuY3Rpb24gc2lnbmFsU3Vic2NyaWJlcnNOb3codXBkYXRlZFBhcnRzLCBkZWxldGVBZmZlY3RlZENhY2hlRW50cmllcykge1xuICAgICAgaWYgKGRlbGV0ZUFmZmVjdGVkQ2FjaGVFbnRyaWVzID09PSB2b2lkIDApIHsgZGVsZXRlQWZmZWN0ZWRDYWNoZUVudHJpZXMgPSBmYWxzZTsgfVxuICAgICAgdmFyIHF1ZXJpZXNUb1NpZ25hbCA9IG5ldyBTZXQoKTtcbiAgICAgIGlmICh1cGRhdGVkUGFydHMuYWxsKSB7XG4gICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IE9iamVjdC52YWx1ZXMoY2FjaGUpOyBfaSA8IF9hLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgICB2YXIgdGJsQ2FjaGUgPSBfYVtfaV07XG4gICAgICAgICAgICAgIGNvbGxlY3RUYWJsZVN1YnNjcmliZXJzKHRibENhY2hlLCB1cGRhdGVkUGFydHMsIHF1ZXJpZXNUb1NpZ25hbCwgZGVsZXRlQWZmZWN0ZWRDYWNoZUVudHJpZXMpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICAgIGZvciAodmFyIGtleSBpbiB1cGRhdGVkUGFydHMpIHtcbiAgICAgICAgICAgICAgdmFyIHBhcnRzID0gL15pZGJcXDpcXC9cXC8oLiopXFwvKC4qKVxcLy8uZXhlYyhrZXkpO1xuICAgICAgICAgICAgICBpZiAocGFydHMpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBkYk5hbWUgPSBwYXJ0c1sxXSwgdGFibGVOYW1lID0gcGFydHNbMl07XG4gICAgICAgICAgICAgICAgICB2YXIgdGJsQ2FjaGUgPSBjYWNoZVtcImlkYjovL1wiLmNvbmNhdChkYk5hbWUsIFwiL1wiKS5jb25jYXQodGFibGVOYW1lKV07XG4gICAgICAgICAgICAgICAgICBpZiAodGJsQ2FjaGUpXG4gICAgICAgICAgICAgICAgICAgICAgY29sbGVjdFRhYmxlU3Vic2NyaWJlcnModGJsQ2FjaGUsIHVwZGF0ZWRQYXJ0cywgcXVlcmllc1RvU2lnbmFsLCBkZWxldGVBZmZlY3RlZENhY2hlRW50cmllcyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICBxdWVyaWVzVG9TaWduYWwuZm9yRWFjaChmdW5jdGlvbiAocmVxdWVyeSkgeyByZXR1cm4gcmVxdWVyeSgpOyB9KTtcbiAgfVxuICBmdW5jdGlvbiBjb2xsZWN0VGFibGVTdWJzY3JpYmVycyh0YmxDYWNoZSwgdXBkYXRlZFBhcnRzLCBvdXRRdWVyaWVzVG9TaWduYWwsIGRlbGV0ZUFmZmVjdGVkQ2FjaGVFbnRyaWVzKSB7XG4gICAgICB2YXIgdXBkYXRlZEVudHJ5TGlzdHMgPSBbXTtcbiAgICAgIGZvciAodmFyIF9pID0gMCwgX2EgPSBPYmplY3QuZW50cmllcyh0YmxDYWNoZS5xdWVyaWVzLnF1ZXJ5KTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICB2YXIgX2IgPSBfYVtfaV0sIGluZGV4TmFtZSA9IF9iWzBdLCBlbnRyaWVzID0gX2JbMV07XG4gICAgICAgICAgdmFyIGZpbHRlcmVkRW50cmllcyA9IFtdO1xuICAgICAgICAgIGZvciAodmFyIF9jID0gMCwgZW50cmllc18xID0gZW50cmllczsgX2MgPCBlbnRyaWVzXzEubGVuZ3RoOyBfYysrKSB7XG4gICAgICAgICAgICAgIHZhciBlbnRyeSA9IGVudHJpZXNfMVtfY107XG4gICAgICAgICAgICAgIGlmIChvYnNTZXRzT3ZlcmxhcCh1cGRhdGVkUGFydHMsIGVudHJ5Lm9ic1NldCkpIHtcbiAgICAgICAgICAgICAgICAgIGVudHJ5LnN1YnNjcmliZXJzLmZvckVhY2goZnVuY3Rpb24gKHJlcXVlcnkpIHsgcmV0dXJuIG91dFF1ZXJpZXNUb1NpZ25hbC5hZGQocmVxdWVyeSk7IH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2UgaWYgKGRlbGV0ZUFmZmVjdGVkQ2FjaGVFbnRyaWVzKSB7XG4gICAgICAgICAgICAgICAgICBmaWx0ZXJlZEVudHJpZXMucHVzaChlbnRyeSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGRlbGV0ZUFmZmVjdGVkQ2FjaGVFbnRyaWVzKVxuICAgICAgICAgICAgICB1cGRhdGVkRW50cnlMaXN0cy5wdXNoKFtpbmRleE5hbWUsIGZpbHRlcmVkRW50cmllc10pO1xuICAgICAgfVxuICAgICAgaWYgKGRlbGV0ZUFmZmVjdGVkQ2FjaGVFbnRyaWVzKSB7XG4gICAgICAgICAgZm9yICh2YXIgX2QgPSAwLCB1cGRhdGVkRW50cnlMaXN0c18xID0gdXBkYXRlZEVudHJ5TGlzdHM7IF9kIDwgdXBkYXRlZEVudHJ5TGlzdHNfMS5sZW5ndGg7IF9kKyspIHtcbiAgICAgICAgICAgICAgdmFyIF9lID0gdXBkYXRlZEVudHJ5TGlzdHNfMVtfZF0sIGluZGV4TmFtZSA9IF9lWzBdLCBmaWx0ZXJlZEVudHJpZXMgPSBfZVsxXTtcbiAgICAgICAgICAgICAgdGJsQ2FjaGUucXVlcmllcy5xdWVyeVtpbmRleE5hbWVdID0gZmlsdGVyZWRFbnRyaWVzO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIGRleGllT3BlbihkYikge1xuICAgICAgdmFyIHN0YXRlID0gZGIuX3N0YXRlO1xuICAgICAgdmFyIGluZGV4ZWREQiA9IGRiLl9kZXBzLmluZGV4ZWREQjtcbiAgICAgIGlmIChzdGF0ZS5pc0JlaW5nT3BlbmVkIHx8IGRiLmlkYmRiKVxuICAgICAgICAgIHJldHVybiBzdGF0ZS5kYlJlYWR5UHJvbWlzZS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHN0YXRlLmRiT3BlbkVycm9yID8gcmVqZWN0aW9uKHN0YXRlLmRiT3BlbkVycm9yKSA6IGRiO1xuICAgICAgICAgIH0pO1xuICAgICAgc3RhdGUuaXNCZWluZ09wZW5lZCA9IHRydWU7XG4gICAgICBzdGF0ZS5kYk9wZW5FcnJvciA9IG51bGw7XG4gICAgICBzdGF0ZS5vcGVuQ29tcGxldGUgPSBmYWxzZTtcbiAgICAgIHZhciBvcGVuQ2FuY2VsbGVyID0gc3RhdGUub3BlbkNhbmNlbGxlcjtcbiAgICAgIHZhciBuYXRpdmVWZXJUb09wZW4gPSBNYXRoLnJvdW5kKGRiLnZlcm5vICogMTApO1xuICAgICAgdmFyIHNjaGVtYVBhdGNoTW9kZSA9IGZhbHNlO1xuICAgICAgZnVuY3Rpb24gdGhyb3dJZkNhbmNlbGxlZCgpIHtcbiAgICAgICAgICBpZiAoc3RhdGUub3BlbkNhbmNlbGxlciAhPT0gb3BlbkNhbmNlbGxlcilcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuRGF0YWJhc2VDbG9zZWQoJ2RiLm9wZW4oKSB3YXMgY2FuY2VsbGVkJyk7XG4gICAgICB9XG4gICAgICB2YXIgcmVzb2x2ZURiUmVhZHkgPSBzdGF0ZS5kYlJlYWR5UmVzb2x2ZSxcbiAgICAgIHVwZ3JhZGVUcmFuc2FjdGlvbiA9IG51bGwsIHdhc0NyZWF0ZWQgPSBmYWxzZTtcbiAgICAgIHZhciB0cnlPcGVuREIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBEZXhpZVByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICB0aHJvd0lmQ2FuY2VsbGVkKCk7XG4gICAgICAgICAgICAgIGlmICghaW5kZXhlZERCKVxuICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuTWlzc2luZ0FQSSgpO1xuICAgICAgICAgICAgICB2YXIgZGJOYW1lID0gZGIubmFtZTtcbiAgICAgICAgICAgICAgdmFyIHJlcSA9IHN0YXRlLmF1dG9TY2hlbWEgfHwgIW5hdGl2ZVZlclRvT3BlblxuICAgICAgICAgICAgICAgICAgPyBpbmRleGVkREIub3BlbihkYk5hbWUpXG4gICAgICAgICAgICAgICAgICA6IGluZGV4ZWREQi5vcGVuKGRiTmFtZSwgbmF0aXZlVmVyVG9PcGVuKTtcbiAgICAgICAgICAgICAgaWYgKCFyZXEpXG4gICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgZXhjZXB0aW9ucy5NaXNzaW5nQVBJKCk7XG4gICAgICAgICAgICAgIHJlcS5vbmVycm9yID0gZXZlbnRSZWplY3RIYW5kbGVyKHJlamVjdCk7XG4gICAgICAgICAgICAgIHJlcS5vbmJsb2NrZWQgPSB3cmFwKGRiLl9maXJlT25CbG9ja2VkKTtcbiAgICAgICAgICAgICAgcmVxLm9udXBncmFkZW5lZWRlZCA9IHdyYXAoZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgICAgICAgIHVwZ3JhZGVUcmFuc2FjdGlvbiA9IHJlcS50cmFuc2FjdGlvbjtcbiAgICAgICAgICAgICAgICAgIGlmIChzdGF0ZS5hdXRvU2NoZW1hICYmICFkYi5fb3B0aW9ucy5hbGxvd0VtcHR5REIpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IHByZXZlbnREZWZhdWx0O1xuICAgICAgICAgICAgICAgICAgICAgIHVwZ3JhZGVUcmFuc2FjdGlvbi5hYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgICAgIHJlcS5yZXN1bHQuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgZGVscmVxID0gaW5kZXhlZERCLmRlbGV0ZURhdGFiYXNlKGRiTmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgZGVscmVxLm9uc3VjY2VzcyA9IGRlbHJlcS5vbmVycm9yID0gd3JhcChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChuZXcgZXhjZXB0aW9ucy5Ob1N1Y2hEYXRhYmFzZShcIkRhdGFiYXNlIFwiLmNvbmNhdChkYk5hbWUsIFwiIGRvZXNudCBleGlzdFwiKSkpO1xuICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgdXBncmFkZVRyYW5zYWN0aW9uLm9uZXJyb3IgPSBldmVudFJlamVjdEhhbmRsZXIocmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgb2xkVmVyID0gZS5vbGRWZXJzaW9uID4gTWF0aC5wb3coMiwgNjIpID8gMCA6IGUub2xkVmVyc2lvbjtcbiAgICAgICAgICAgICAgICAgICAgICB3YXNDcmVhdGVkID0gb2xkVmVyIDwgMTtcbiAgICAgICAgICAgICAgICAgICAgICBkYi5pZGJkYiA9IHJlcS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHNjaGVtYVBhdGNoTW9kZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRjaEN1cnJlbnRWZXJzaW9uKGRiLCB1cGdyYWRlVHJhbnNhY3Rpb24pO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBydW5VcGdyYWRlcnMoZGIsIG9sZFZlciAvIDEwLCB1cGdyYWRlVHJhbnNhY3Rpb24sIHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0sIHJlamVjdCk7XG4gICAgICAgICAgICAgIHJlcS5vbnN1Y2Nlc3MgPSB3cmFwKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIHVwZ3JhZGVUcmFuc2FjdGlvbiA9IG51bGw7XG4gICAgICAgICAgICAgICAgICB2YXIgaWRiZGIgPSAoZGIuaWRiZGIgPSByZXEucmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgIHZhciBvYmplY3RTdG9yZU5hbWVzID0gc2xpY2UoaWRiZGIub2JqZWN0U3RvcmVOYW1lcyk7XG4gICAgICAgICAgICAgICAgICBpZiAob2JqZWN0U3RvcmVOYW1lcy5sZW5ndGggPiAwKVxuICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0bXBUcmFucyA9IGlkYmRiLnRyYW5zYWN0aW9uKHNhZmFyaU11bHRpU3RvcmVGaXgob2JqZWN0U3RvcmVOYW1lcyksICdyZWFkb25seScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RhdGUuYXV0b1NjaGVtYSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRHbG9iYWxTY2hlbWEoZGIsIGlkYmRiLCB0bXBUcmFucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRqdXN0VG9FeGlzdGluZ0luZGV4TmFtZXMoZGIsIGRiLl9kYlNjaGVtYSwgdG1wVHJhbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF2ZXJpZnlJbnN0YWxsZWRTY2hlbWEoZGIsIHRtcFRyYW5zKSAmJiAhc2NoZW1hUGF0Y2hNb2RlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKFwiRGV4aWUgU2NoZW1hRGlmZjogU2NoZW1hIHdhcyBleHRlbmRlZCB3aXRob3V0IGluY3JlYXNpbmcgdGhlIG51bWJlciBwYXNzZWQgdG8gZGIudmVyc2lvbigpLiBEZXhpZSB3aWxsIGFkZCBtaXNzaW5nIHBhcnRzIGFuZCBpbmNyZW1lbnQgbmF0aXZlIHZlcnNpb24gbnVtYmVyIHRvIHdvcmthcm91bmQgdGhpcy5cIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWRiZGIuY2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYXRpdmVWZXJUb09wZW4gPSBpZGJkYi52ZXJzaW9uICsgMTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzY2hlbWFQYXRjaE1vZGUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNvbHZlKHRyeU9wZW5EQigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBnZW5lcmF0ZU1pZGRsZXdhcmVTdGFja3MoZGIsIHRtcFRyYW5zKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjb25uZWN0aW9ucy5hZGQoZGIpO1xuICAgICAgICAgICAgICAgICAgaWRiZGIub252ZXJzaW9uY2hhbmdlID0gd3JhcChmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS52Y0ZpcmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICBkYi5vbigndmVyc2lvbmNoYW5nZScpLmZpcmUoZXYpO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICBpZGJkYi5vbmNsb3NlID0gd3JhcChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgZGIuY2xvc2UoeyBkaXNhYmxlQXV0b09wZW46IGZhbHNlIH0pO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICBpZiAod2FzQ3JlYXRlZClcbiAgICAgICAgICAgICAgICAgICAgICBfb25EYXRhYmFzZUNyZWF0ZWQoZGIuX2RlcHMsIGRiTmFtZSk7XG4gICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgIH0sIHJlamVjdCk7XG4gICAgICAgICAgfSkuY2F0Y2goZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgICAgICBzd2l0Y2ggKGVyciA9PT0gbnVsbCB8fCBlcnIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGVyci5uYW1lKSB7XG4gICAgICAgICAgICAgICAgICBjYXNlICdVbmtub3duRXJyb3InOlxuICAgICAgICAgICAgICAgICAgICAgIGlmIChzdGF0ZS5QUjEzOThfbWF4TG9vcCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGUuUFIxMzk4X21heExvb3AtLTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdEZXhpZTogV29ya2Fyb3VuZCBmb3IgQ2hyb21lIFVua25vd25FcnJvciBvbiBvcGVuKCknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRyeU9wZW5EQigpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgIGNhc2UgJ1ZlcnNpb25FcnJvcic6XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKG5hdGl2ZVZlclRvT3BlbiA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmF0aXZlVmVyVG9PcGVuID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRyeU9wZW5EQigpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gRGV4aWVQcm9taXNlLnJlamVjdChlcnIpO1xuICAgICAgICAgIH0pO1xuICAgICAgfTtcbiAgICAgIHJldHVybiBEZXhpZVByb21pc2UucmFjZShbXG4gICAgICAgICAgb3BlbkNhbmNlbGxlcixcbiAgICAgICAgICAodHlwZW9mIG5hdmlnYXRvciA9PT0gJ3VuZGVmaW5lZCdcbiAgICAgICAgICAgICAgPyBEZXhpZVByb21pc2UucmVzb2x2ZSgpXG4gICAgICAgICAgICAgIDogaWRiUmVhZHkoKSkudGhlbih0cnlPcGVuREIpLFxuICAgICAgXSlcbiAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdGhyb3dJZkNhbmNlbGxlZCgpO1xuICAgICAgICAgIHN0YXRlLm9uUmVhZHlCZWluZ0ZpcmVkID0gW107XG4gICAgICAgICAgcmV0dXJuIERleGllUHJvbWlzZS5yZXNvbHZlKHZpcChmdW5jdGlvbiAoKSB7IHJldHVybiBkYi5vbi5yZWFkeS5maXJlKGRiLnZpcCk7IH0pKS50aGVuKGZ1bmN0aW9uIGZpcmVSZW1haW5kZXJzKCkge1xuICAgICAgICAgICAgICBpZiAoc3RhdGUub25SZWFkeUJlaW5nRmlyZWQubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgdmFyIHJlbWFpbmRlcnNfMSA9IHN0YXRlLm9uUmVhZHlCZWluZ0ZpcmVkLnJlZHVjZShwcm9taXNhYmxlQ2hhaW4sIG5vcCk7XG4gICAgICAgICAgICAgICAgICBzdGF0ZS5vblJlYWR5QmVpbmdGaXJlZCA9IFtdO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIERleGllUHJvbWlzZS5yZXNvbHZlKHZpcChmdW5jdGlvbiAoKSB7IHJldHVybiByZW1haW5kZXJzXzEoZGIudmlwKTsgfSkpLnRoZW4oZmlyZVJlbWFpbmRlcnMpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICB9KVxuICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAoc3RhdGUub3BlbkNhbmNlbGxlciA9PT0gb3BlbkNhbmNlbGxlcikge1xuICAgICAgICAgICAgICBzdGF0ZS5vblJlYWR5QmVpbmdGaXJlZCA9IG51bGw7XG4gICAgICAgICAgICAgIHN0YXRlLmlzQmVpbmdPcGVuZWQgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICB9KVxuICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgc3RhdGUuZGJPcGVuRXJyb3IgPSBlcnI7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdXBncmFkZVRyYW5zYWN0aW9uICYmIHVwZ3JhZGVUcmFuc2FjdGlvbi5hYm9ydCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjYXRjaCAoX2EpIHsgfVxuICAgICAgICAgIGlmIChvcGVuQ2FuY2VsbGVyID09PSBzdGF0ZS5vcGVuQ2FuY2VsbGVyKSB7XG4gICAgICAgICAgICAgIGRiLl9jbG9zZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVqZWN0aW9uKGVycik7XG4gICAgICB9KVxuICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBzdGF0ZS5vcGVuQ29tcGxldGUgPSB0cnVlO1xuICAgICAgICAgIHJlc29sdmVEYlJlYWR5KCk7XG4gICAgICB9KVxuICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAod2FzQ3JlYXRlZCkge1xuICAgICAgICAgICAgICB2YXIgZXZlcnl0aGluZ18xID0ge307XG4gICAgICAgICAgICAgIGRiLnRhYmxlcy5mb3JFYWNoKGZ1bmN0aW9uICh0YWJsZSkge1xuICAgICAgICAgICAgICAgICAgdGFibGUuc2NoZW1hLmluZGV4ZXMuZm9yRWFjaChmdW5jdGlvbiAoaWR4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGlkeC5uYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICBldmVyeXRoaW5nXzFbXCJpZGI6Ly9cIi5jb25jYXQoZGIubmFtZSwgXCIvXCIpLmNvbmNhdCh0YWJsZS5uYW1lLCBcIi9cIikuY29uY2F0KGlkeC5uYW1lKV0gPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFJhbmdlU2V0KC1JbmZpbml0eSwgW1tbXV1dKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgZXZlcnl0aGluZ18xW1wiaWRiOi8vXCIuY29uY2F0KGRiLm5hbWUsIFwiL1wiKS5jb25jYXQodGFibGUubmFtZSwgXCIvXCIpXSA9IGV2ZXJ5dGhpbmdfMVtcImlkYjovL1wiLmNvbmNhdChkYi5uYW1lLCBcIi9cIikuY29uY2F0KHRhYmxlLm5hbWUsIFwiLzpkZWxzXCIpXSA9IG5ldyBSYW5nZVNldCgtSW5maW5pdHksIFtbW11dXSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBnbG9iYWxFdmVudHMoREVYSUVfU1RPUkFHRV9NVVRBVEVEX0VWRU5UX05BTUUpLmZpcmUoZXZlcnl0aGluZ18xKTtcbiAgICAgICAgICAgICAgc2lnbmFsU3Vic2NyaWJlcnNOb3coZXZlcnl0aGluZ18xLCB0cnVlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGRiO1xuICAgICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBhd2FpdEl0ZXJhdG9yKGl0ZXJhdG9yKSB7XG4gICAgICB2YXIgY2FsbE5leHQgPSBmdW5jdGlvbiAocmVzdWx0KSB7IHJldHVybiBpdGVyYXRvci5uZXh0KHJlc3VsdCk7IH0sIGRvVGhyb3cgPSBmdW5jdGlvbiAoZXJyb3IpIHsgcmV0dXJuIGl0ZXJhdG9yLnRocm93KGVycm9yKTsgfSwgb25TdWNjZXNzID0gc3RlcChjYWxsTmV4dCksIG9uRXJyb3IgPSBzdGVwKGRvVGhyb3cpO1xuICAgICAgZnVuY3Rpb24gc3RlcChnZXROZXh0KSB7XG4gICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICh2YWwpIHtcbiAgICAgICAgICAgICAgdmFyIG5leHQgPSBnZXROZXh0KHZhbCksIHZhbHVlID0gbmV4dC52YWx1ZTtcbiAgICAgICAgICAgICAgcmV0dXJuIG5leHQuZG9uZVxuICAgICAgICAgICAgICAgICAgPyB2YWx1ZVxuICAgICAgICAgICAgICAgICAgOiAhdmFsdWUgfHwgdHlwZW9mIHZhbHVlLnRoZW4gIT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgICAgICAgICAgICA/IGlzQXJyYXkodmFsdWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gUHJvbWlzZS5hbGwodmFsdWUpLnRoZW4ob25TdWNjZXNzLCBvbkVycm9yKVxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IG9uU3VjY2Vzcyh2YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICA6IHZhbHVlLnRoZW4ob25TdWNjZXNzLCBvbkVycm9yKTtcbiAgICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0ZXAoY2FsbE5leHQpKCk7XG4gIH1cblxuICBmdW5jdGlvbiBleHRyYWN0VHJhbnNhY3Rpb25BcmdzKG1vZGUsIF90YWJsZUFyZ3NfLCBzY29wZUZ1bmMpIHtcbiAgICAgIHZhciBpID0gYXJndW1lbnRzLmxlbmd0aDtcbiAgICAgIGlmIChpIDwgMilcbiAgICAgICAgICB0aHJvdyBuZXcgZXhjZXB0aW9ucy5JbnZhbGlkQXJndW1lbnQoJ1RvbyBmZXcgYXJndW1lbnRzJyk7XG4gICAgICB2YXIgYXJncyA9IG5ldyBBcnJheShpIC0gMSk7XG4gICAgICB3aGlsZSAoLS1pKVxuICAgICAgICAgIGFyZ3NbaSAtIDFdID0gYXJndW1lbnRzW2ldO1xuICAgICAgc2NvcGVGdW5jID0gYXJncy5wb3AoKTtcbiAgICAgIHZhciB0YWJsZXMgPSBmbGF0dGVuKGFyZ3MpO1xuICAgICAgcmV0dXJuIFttb2RlLCB0YWJsZXMsIHNjb3BlRnVuY107XG4gIH1cbiAgZnVuY3Rpb24gZW50ZXJUcmFuc2FjdGlvblNjb3BlKGRiLCBtb2RlLCBzdG9yZU5hbWVzLCBwYXJlbnRUcmFuc2FjdGlvbiwgc2NvcGVGdW5jKSB7XG4gICAgICByZXR1cm4gRGV4aWVQcm9taXNlLnJlc29sdmUoKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgdHJhbnNsZXNzID0gUFNELnRyYW5zbGVzcyB8fCBQU0Q7XG4gICAgICAgICAgdmFyIHRyYW5zID0gZGIuX2NyZWF0ZVRyYW5zYWN0aW9uKG1vZGUsIHN0b3JlTmFtZXMsIGRiLl9kYlNjaGVtYSwgcGFyZW50VHJhbnNhY3Rpb24pO1xuICAgICAgICAgIHRyYW5zLmV4cGxpY2l0ID0gdHJ1ZTtcbiAgICAgICAgICB2YXIgem9uZVByb3BzID0ge1xuICAgICAgICAgICAgICB0cmFuczogdHJhbnMsXG4gICAgICAgICAgICAgIHRyYW5zbGVzczogdHJhbnNsZXNzLFxuICAgICAgICAgIH07XG4gICAgICAgICAgaWYgKHBhcmVudFRyYW5zYWN0aW9uKSB7XG4gICAgICAgICAgICAgIHRyYW5zLmlkYnRyYW5zID0gcGFyZW50VHJhbnNhY3Rpb24uaWRidHJhbnM7XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgdHJhbnMuY3JlYXRlKCk7XG4gICAgICAgICAgICAgICAgICB0cmFucy5pZGJ0cmFucy5fZXhwbGljaXQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgZGIuX3N0YXRlLlBSMTM5OF9tYXhMb29wID0gMztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChleC5uYW1lID09PSBlcnJuYW1lcy5JbnZhbGlkU3RhdGUgJiZcbiAgICAgICAgICAgICAgICAgICAgICBkYi5pc09wZW4oKSAmJlxuICAgICAgICAgICAgICAgICAgICAgIC0tZGIuX3N0YXRlLlBSMTM5OF9tYXhMb29wID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignRGV4aWU6IE5lZWQgdG8gcmVvcGVuIGRiJyk7XG4gICAgICAgICAgICAgICAgICAgICAgZGIuY2xvc2UoeyBkaXNhYmxlQXV0b09wZW46IGZhbHNlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkYlxuICAgICAgICAgICAgICAgICAgICAgICAgICAub3BlbigpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVudGVyVHJhbnNhY3Rpb25TY29wZShkYiwgbW9kZSwgc3RvcmVOYW1lcywgbnVsbCwgc2NvcGVGdW5jKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiByZWplY3Rpb24oZXgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhciBzY29wZUZ1bmNJc0FzeW5jID0gaXNBc3luY0Z1bmN0aW9uKHNjb3BlRnVuYyk7XG4gICAgICAgICAgaWYgKHNjb3BlRnVuY0lzQXN5bmMpIHtcbiAgICAgICAgICAgICAgaW5jcmVtZW50RXhwZWN0ZWRBd2FpdHMoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIHJldHVyblZhbHVlO1xuICAgICAgICAgIHZhciBwcm9taXNlRm9sbG93ZWQgPSBEZXhpZVByb21pc2UuZm9sbG93KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgcmV0dXJuVmFsdWUgPSBzY29wZUZ1bmMuY2FsbCh0cmFucywgdHJhbnMpO1xuICAgICAgICAgICAgICBpZiAocmV0dXJuVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChzY29wZUZ1bmNJc0FzeW5jKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIGRlY3JlbWVudG9yID0gZGVjcmVtZW50RXhwZWN0ZWRBd2FpdHMuYmluZChudWxsLCBudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm5WYWx1ZS50aGVuKGRlY3JlbWVudG9yLCBkZWNyZW1lbnRvcik7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgcmV0dXJuVmFsdWUubmV4dCA9PT0gJ2Z1bmN0aW9uJyAmJlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGVvZiByZXR1cm5WYWx1ZS50aHJvdyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVyblZhbHVlID0gYXdhaXRJdGVyYXRvcihyZXR1cm5WYWx1ZSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9LCB6b25lUHJvcHMpO1xuICAgICAgICAgIHJldHVybiAocmV0dXJuVmFsdWUgJiYgdHlwZW9mIHJldHVyblZhbHVlLnRoZW4gPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgICAgP1xuICAgICAgICAgICAgICAgICAgRGV4aWVQcm9taXNlLnJlc29sdmUocmV0dXJuVmFsdWUpLnRoZW4oZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJhbnMuYWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8geFxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IHJlamVjdGlvbihuZXcgZXhjZXB0aW9ucy5QcmVtYXR1cmVDb21taXQoJ1RyYW5zYWN0aW9uIGNvbW1pdHRlZCB0b28gZWFybHkuIFNlZSBodHRwOi8vYml0Lmx5LzJrZGNrTW4nKSk7XG4gICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICA6XG4gICAgICAgICAgICAgICAgICBwcm9taXNlRm9sbG93ZWQudGhlbihmdW5jdGlvbiAoKSB7IHJldHVybiByZXR1cm5WYWx1ZTsgfSkpXG4gICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICh4KSB7XG4gICAgICAgICAgICAgIGlmIChwYXJlbnRUcmFuc2FjdGlvbilcbiAgICAgICAgICAgICAgICAgIHRyYW5zLl9yZXNvbHZlKCk7XG4gICAgICAgICAgICAgIHJldHVybiB0cmFucy5fY29tcGxldGlvbi50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHg7IH0pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoZSkge1xuICAgICAgICAgICAgICB0cmFucy5fcmVqZWN0KGUpO1xuICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0aW9uKGUpO1xuICAgICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBwYWQoYSwgdmFsdWUsIGNvdW50KSB7XG4gICAgICB2YXIgcmVzdWx0ID0gaXNBcnJheShhKSA/IGEuc2xpY2UoKSA6IFthXTtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY291bnQ7ICsraSlcbiAgICAgICAgICByZXN1bHQucHVzaCh2YWx1ZSk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZVZpcnR1YWxJbmRleE1pZGRsZXdhcmUoZG93bikge1xuICAgICAgcmV0dXJuIF9fYXNzaWduKF9fYXNzaWduKHt9LCBkb3duKSwgeyB0YWJsZTogZnVuY3Rpb24gKHRhYmxlTmFtZSkge1xuICAgICAgICAgICAgICB2YXIgdGFibGUgPSBkb3duLnRhYmxlKHRhYmxlTmFtZSk7XG4gICAgICAgICAgICAgIHZhciBzY2hlbWEgPSB0YWJsZS5zY2hlbWE7XG4gICAgICAgICAgICAgIHZhciBpbmRleExvb2t1cCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgICAgICAgIHZhciBhbGxWaXJ0dWFsSW5kZXhlcyA9IFtdO1xuICAgICAgICAgICAgICBmdW5jdGlvbiBhZGRWaXJ0dWFsSW5kZXhlcyhrZXlQYXRoLCBrZXlUYWlsLCBsb3dMZXZlbEluZGV4KSB7XG4gICAgICAgICAgICAgICAgICB2YXIga2V5UGF0aEFsaWFzID0gZ2V0S2V5UGF0aEFsaWFzKGtleVBhdGgpO1xuICAgICAgICAgICAgICAgICAgdmFyIGluZGV4TGlzdCA9IChpbmRleExvb2t1cFtrZXlQYXRoQWxpYXNdID1cbiAgICAgICAgICAgICAgICAgICAgICBpbmRleExvb2t1cFtrZXlQYXRoQWxpYXNdIHx8IFtdKTtcbiAgICAgICAgICAgICAgICAgIHZhciBrZXlMZW5ndGggPSBrZXlQYXRoID09IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICA/IDBcbiAgICAgICAgICAgICAgICAgICAgICA6IHR5cGVvZiBrZXlQYXRoID09PSAnc3RyaW5nJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/IDFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBrZXlQYXRoLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgIHZhciBpc1ZpcnR1YWwgPSBrZXlUYWlsID4gMDtcbiAgICAgICAgICAgICAgICAgIHZhciB2aXJ0dWFsSW5kZXggPSBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgbG93TGV2ZWxJbmRleCksIHsgbmFtZTogaXNWaXJ0dWFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJcIi5jb25jYXQoa2V5UGF0aEFsaWFzLCBcIih2aXJ0dWFsLWZyb206XCIpLmNvbmNhdChsb3dMZXZlbEluZGV4Lm5hbWUsIFwiKVwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IGxvd0xldmVsSW5kZXgubmFtZSwgbG93TGV2ZWxJbmRleDogbG93TGV2ZWxJbmRleCwgaXNWaXJ0dWFsOiBpc1ZpcnR1YWwsIGtleVRhaWw6IGtleVRhaWwsIGtleUxlbmd0aDoga2V5TGVuZ3RoLCBleHRyYWN0S2V5OiBnZXRLZXlFeHRyYWN0b3Ioa2V5UGF0aCksIHVuaXF1ZTogIWlzVmlydHVhbCAmJiBsb3dMZXZlbEluZGV4LnVuaXF1ZSB9KTtcbiAgICAgICAgICAgICAgICAgIGluZGV4TGlzdC5wdXNoKHZpcnR1YWxJbmRleCk7XG4gICAgICAgICAgICAgICAgICBpZiAoIXZpcnR1YWxJbmRleC5pc1ByaW1hcnlLZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBhbGxWaXJ0dWFsSW5kZXhlcy5wdXNoKHZpcnR1YWxJbmRleCk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoa2V5TGVuZ3RoID4gMSkge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciB2aXJ0dWFsS2V5UGF0aCA9IGtleUxlbmd0aCA9PT0gMlxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IGtleVBhdGhbMF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBrZXlQYXRoLnNsaWNlKDAsIGtleUxlbmd0aCAtIDEpO1xuICAgICAgICAgICAgICAgICAgICAgIGFkZFZpcnR1YWxJbmRleGVzKHZpcnR1YWxLZXlQYXRoLCBrZXlUYWlsICsgMSwgbG93TGV2ZWxJbmRleCk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpbmRleExpc3Quc29ydChmdW5jdGlvbiAoYSwgYikgeyByZXR1cm4gYS5rZXlUYWlsIC0gYi5rZXlUYWlsOyB9KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB2aXJ0dWFsSW5kZXg7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgdmFyIHByaW1hcnlLZXkgPSBhZGRWaXJ0dWFsSW5kZXhlcyhzY2hlbWEucHJpbWFyeUtleS5rZXlQYXRoLCAwLCBzY2hlbWEucHJpbWFyeUtleSk7XG4gICAgICAgICAgICAgIGluZGV4TG9va3VwWyc6aWQnXSA9IFtwcmltYXJ5S2V5XTtcbiAgICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHNjaGVtYS5pbmRleGVzOyBfaSA8IF9hLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgICAgICAgdmFyIGluZGV4ID0gX2FbX2ldO1xuICAgICAgICAgICAgICAgICAgYWRkVmlydHVhbEluZGV4ZXMoaW5kZXgua2V5UGF0aCwgMCwgaW5kZXgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGZ1bmN0aW9uIGZpbmRCZXN0SW5kZXgoa2V5UGF0aCkge1xuICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IGluZGV4TG9va3VwW2dldEtleVBhdGhBbGlhcyhrZXlQYXRoKV07XG4gICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0ICYmIHJlc3VsdFswXTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBmdW5jdGlvbiB0cmFuc2xhdGVSYW5nZShyYW5nZSwga2V5VGFpbCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlOiByYW5nZS50eXBlID09PSAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gMlxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IHJhbmdlLnR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgbG93ZXI6IHBhZChyYW5nZS5sb3dlciwgcmFuZ2UubG93ZXJPcGVuID8gZG93bi5NQVhfS0VZIDogZG93bi5NSU5fS0VZLCBrZXlUYWlsKSxcbiAgICAgICAgICAgICAgICAgICAgICBsb3dlck9wZW46IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgdXBwZXI6IHBhZChyYW5nZS51cHBlciwgcmFuZ2UudXBwZXJPcGVuID8gZG93bi5NSU5fS0VZIDogZG93bi5NQVhfS0VZLCBrZXlUYWlsKSxcbiAgICAgICAgICAgICAgICAgICAgICB1cHBlck9wZW46IHRydWUsXG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGZ1bmN0aW9uIHRyYW5zbGF0ZVJlcXVlc3QocmVxKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSByZXEucXVlcnkuaW5kZXg7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gaW5kZXguaXNWaXJ0dWFsXG4gICAgICAgICAgICAgICAgICAgICAgPyBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgcmVxKSwgeyBxdWVyeToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXg6IGluZGV4Lmxvd0xldmVsSW5kZXgsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByYW5nZTogdHJhbnNsYXRlUmFuZ2UocmVxLnF1ZXJ5LnJhbmdlLCBpbmRleC5rZXlUYWlsKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSB9KSA6IHJlcTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gX19hc3NpZ24oX19hc3NpZ24oe30sIHRhYmxlKSwgeyBzY2hlbWE6IF9fYXNzaWduKF9fYXNzaWduKHt9LCBzY2hlbWEpLCB7IHByaW1hcnlLZXk6IHByaW1hcnlLZXksIGluZGV4ZXM6IGFsbFZpcnR1YWxJbmRleGVzLCBnZXRJbmRleEJ5S2V5UGF0aDogZmluZEJlc3RJbmRleCB9KSwgY291bnQ6IGZ1bmN0aW9uIChyZXEpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGFibGUuY291bnQodHJhbnNsYXRlUmVxdWVzdChyZXEpKTtcbiAgICAgICAgICAgICAgICAgIH0sIHF1ZXJ5OiBmdW5jdGlvbiAocmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhYmxlLnF1ZXJ5KHRyYW5zbGF0ZVJlcXVlc3QocmVxKSk7XG4gICAgICAgICAgICAgICAgICB9LCBvcGVuQ3Vyc29yOiBmdW5jdGlvbiAocmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIF9hID0gcmVxLnF1ZXJ5XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmRleCwga2V5VGFpbCA9IF9hLmtleVRhaWwsIGlzVmlydHVhbCA9IF9hLmlzVmlydHVhbCwga2V5TGVuZ3RoID0gX2Eua2V5TGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICAgIGlmICghaXNWaXJ0dWFsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGFibGUub3BlbkN1cnNvcihyZXEpO1xuICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGNyZWF0ZVZpcnR1YWxDdXJzb3IoY3Vyc29yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIF9jb250aW51ZShrZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleSAhPSBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBjdXJzb3IuY29udGludWUocGFkKGtleSwgcmVxLnJldmVyc2UgPyBkb3duLk1BWF9LRVkgOiBkb3duLk1JTl9LRVksIGtleVRhaWwpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVxLnVuaXF1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGN1cnNvci5jb250aW51ZShjdXJzb3Iua2V5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc2xpY2UoMCwga2V5TGVuZ3RoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNvbmNhdChyZXEucmV2ZXJzZSA/IGRvd24uTUlOX0tFWSA6IGRvd24uTUFYX0tFWSwga2V5VGFpbCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogY3Vyc29yLmNvbnRpbnVlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHZpcnR1YWxDdXJzb3IgPSBPYmplY3QuY3JlYXRlKGN1cnNvciwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU6IHsgdmFsdWU6IF9jb250aW51ZSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWVQcmltYXJ5S2V5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIChrZXksIHByaW1hcnlLZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3Vyc29yLmNvbnRpbnVlUHJpbWFyeUtleShwYWQoa2V5LCBkb3duLk1BWF9LRVksIGtleVRhaWwpLCBwcmltYXJ5S2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW1hcnlLZXk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGN1cnNvci5wcmltYXJ5S2V5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBrZXkgPSBjdXJzb3Iua2V5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ga2V5TGVuZ3RoID09PSAxXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGtleVswXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBrZXkuc2xpY2UoMCwga2V5TGVuZ3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjdXJzb3IudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmlydHVhbEN1cnNvcjtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5vcGVuQ3Vyc29yKHRyYW5zbGF0ZVJlcXVlc3QocmVxKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKGN1cnNvcikgeyByZXR1cm4gY3Vyc29yICYmIGNyZWF0ZVZpcnR1YWxDdXJzb3IoY3Vyc29yKTsgfSk7XG4gICAgICAgICAgICAgICAgICB9IH0pO1xuICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgIH0gfSk7XG4gIH1cbiAgdmFyIHZpcnR1YWxJbmRleE1pZGRsZXdhcmUgPSB7XG4gICAgICBzdGFjazogJ2RiY29yZScsXG4gICAgICBuYW1lOiAnVmlydHVhbEluZGV4TWlkZGxld2FyZScsXG4gICAgICBsZXZlbDogMSxcbiAgICAgIGNyZWF0ZTogY3JlYXRlVmlydHVhbEluZGV4TWlkZGxld2FyZSxcbiAgfTtcblxuICBmdW5jdGlvbiBnZXRPYmplY3REaWZmKGEsIGIsIHJ2LCBwcmZ4KSB7XG4gICAgICBydiA9IHJ2IHx8IHt9O1xuICAgICAgcHJmeCA9IHByZnggfHwgJyc7XG4gICAgICBrZXlzKGEpLmZvckVhY2goZnVuY3Rpb24gKHByb3ApIHtcbiAgICAgICAgICBpZiAoIWhhc093bihiLCBwcm9wKSkge1xuICAgICAgICAgICAgICBydltwcmZ4ICsgcHJvcF0gPSB1bmRlZmluZWQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICB2YXIgYXAgPSBhW3Byb3BdLCBicCA9IGJbcHJvcF07XG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgYXAgPT09ICdvYmplY3QnICYmIHR5cGVvZiBicCA9PT0gJ29iamVjdCcgJiYgYXAgJiYgYnApIHtcbiAgICAgICAgICAgICAgICAgIHZhciBhcFR5cGVOYW1lID0gdG9TdHJpbmdUYWcoYXApO1xuICAgICAgICAgICAgICAgICAgdmFyIGJwVHlwZU5hbWUgPSB0b1N0cmluZ1RhZyhicCk7XG4gICAgICAgICAgICAgICAgICBpZiAoYXBUeXBlTmFtZSAhPT0gYnBUeXBlTmFtZSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJ2W3ByZnggKyBwcm9wXSA9IGJbcHJvcF07XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBlbHNlIGlmIChhcFR5cGVOYW1lID09PSAnT2JqZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICAgIGdldE9iamVjdERpZmYoYXAsIGJwLCBydiwgcHJmeCArIHByb3AgKyAnLicpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoYXAgIT09IGJwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcnZbcHJmeCArIHByb3BdID0gYltwcm9wXTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBlbHNlIGlmIChhcCAhPT0gYnApXG4gICAgICAgICAgICAgICAgICBydltwcmZ4ICsgcHJvcF0gPSBiW3Byb3BdO1xuICAgICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAga2V5cyhiKS5mb3JFYWNoKGZ1bmN0aW9uIChwcm9wKSB7XG4gICAgICAgICAgaWYgKCFoYXNPd24oYSwgcHJvcCkpIHtcbiAgICAgICAgICAgICAgcnZbcHJmeCArIHByb3BdID0gYltwcm9wXTtcbiAgICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBydjtcbiAgfVxuXG4gIGZ1bmN0aW9uIGdldEVmZmVjdGl2ZUtleXMocHJpbWFyeUtleSwgcmVxKSB7XG4gICAgICBpZiAocmVxLnR5cGUgPT09ICdkZWxldGUnKVxuICAgICAgICAgIHJldHVybiByZXEua2V5cztcbiAgICAgIHJldHVybiByZXEua2V5cyB8fCByZXEudmFsdWVzLm1hcChwcmltYXJ5S2V5LmV4dHJhY3RLZXkpO1xuICB9XG5cbiAgdmFyIGhvb2tzTWlkZGxld2FyZSA9IHtcbiAgICAgIHN0YWNrOiAnZGJjb3JlJyxcbiAgICAgIG5hbWU6ICdIb29rc01pZGRsZXdhcmUnLFxuICAgICAgbGV2ZWw6IDIsXG4gICAgICBjcmVhdGU6IGZ1bmN0aW9uIChkb3duQ29yZSkge1xuICAgICAgICAgIHJldHVybiAoX19hc3NpZ24oX19hc3NpZ24oe30sIGRvd25Db3JlKSwgeyB0YWJsZTogZnVuY3Rpb24gKHRhYmxlTmFtZSkge1xuICAgICAgICAgICAgICAgICAgdmFyIGRvd25UYWJsZSA9IGRvd25Db3JlLnRhYmxlKHRhYmxlTmFtZSk7XG4gICAgICAgICAgICAgICAgICB2YXIgcHJpbWFyeUtleSA9IGRvd25UYWJsZS5zY2hlbWEucHJpbWFyeUtleTtcbiAgICAgICAgICAgICAgICAgIHZhciB0YWJsZU1pZGRsZXdhcmUgPSBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgZG93blRhYmxlKSwgeyBtdXRhdGU6IGZ1bmN0aW9uIChyZXEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGR4VHJhbnMgPSBQU0QudHJhbnM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfYSA9IGR4VHJhbnMudGFibGUodGFibGVOYW1lKS5ob29rLCBkZWxldGluZyA9IF9hLmRlbGV0aW5nLCBjcmVhdGluZyA9IF9hLmNyZWF0aW5nLCB1cGRhdGluZyA9IF9hLnVwZGF0aW5nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHJlcS50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdhZGQnOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjcmVhdGluZy5maXJlID09PSBub3ApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkeFRyYW5zLl9wcm9taXNlKCdyZWFkd3JpdGUnLCBmdW5jdGlvbiAoKSB7IHJldHVybiBhZGRQdXRPckRlbGV0ZShyZXEpOyB9LCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ3B1dCc6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNyZWF0aW5nLmZpcmUgPT09IG5vcCAmJiB1cGRhdGluZy5maXJlID09PSBub3ApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkeFRyYW5zLl9wcm9taXNlKCdyZWFkd3JpdGUnLCBmdW5jdGlvbiAoKSB7IHJldHVybiBhZGRQdXRPckRlbGV0ZShyZXEpOyB9LCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ2RlbGV0ZSc6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRlbGV0aW5nLmZpcmUgPT09IG5vcClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGR4VHJhbnMuX3Byb21pc2UoJ3JlYWR3cml0ZScsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGFkZFB1dE9yRGVsZXRlKHJlcSk7IH0sIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnZGVsZXRlUmFuZ2UnOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkZWxldGluZy5maXJlID09PSBub3ApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkeFRyYW5zLl9wcm9taXNlKCdyZWFkd3JpdGUnLCBmdW5jdGlvbiAoKSB7IHJldHVybiBkZWxldGVSYW5nZShyZXEpOyB9LCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZG93blRhYmxlLm11dGF0ZShyZXEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBhZGRQdXRPckRlbGV0ZShyZXEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkeFRyYW5zID0gUFNELnRyYW5zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGtleXMgPSByZXEua2V5cyB8fCBnZXRFZmZlY3RpdmVLZXlzKHByaW1hcnlLZXksIHJlcSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWtleXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdLZXlzIG1pc3NpbmcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcSA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLnR5cGUgPT09ICdhZGQnIHx8IHJlcS50eXBlID09PSAncHV0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IF9fYXNzaWduKF9fYXNzaWduKHt9LCByZXEpLCB7IGtleXM6IGtleXMgfSkgOiBfX2Fzc2lnbih7fSwgcmVxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXEudHlwZSAhPT0gJ2RlbGV0ZScpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLnZhbHVlcyA9IF9fc3ByZWFkQXJyYXkoW10sIHJlcS52YWx1ZXMsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlcS5rZXlzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcS5rZXlzID0gX19zcHJlYWRBcnJheShbXSwgcmVxLmtleXMsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGdldEV4aXN0aW5nVmFsdWVzKGRvd25UYWJsZSwgcmVxLCBrZXlzKS50aGVuKGZ1bmN0aW9uIChleGlzdGluZ1ZhbHVlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb250ZXh0cyA9IGtleXMubWFwKGZ1bmN0aW9uIChrZXksIGkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGV4aXN0aW5nVmFsdWUgPSBleGlzdGluZ1ZhbHVlc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGN0eCA9IHsgb25lcnJvcjogbnVsbCwgb25zdWNjZXNzOiBudWxsIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXEudHlwZSA9PT0gJ2RlbGV0ZScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0aW5nLmZpcmUuY2FsbChjdHgsIGtleSwgZXhpc3RpbmdWYWx1ZSwgZHhUcmFucyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAocmVxLnR5cGUgPT09ICdhZGQnIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1ZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBnZW5lcmF0ZWRQcmltYXJ5S2V5ID0gY3JlYXRpbmcuZmlyZS5jYWxsKGN0eCwga2V5LCByZXEudmFsdWVzW2ldLCBkeFRyYW5zKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChrZXkgPT0gbnVsbCAmJiBnZW5lcmF0ZWRQcmltYXJ5S2V5ICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXkgPSBnZW5lcmF0ZWRQcmltYXJ5S2V5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcS5rZXlzW2ldID0ga2V5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcHJpbWFyeUtleS5vdXRib3VuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRCeUtleVBhdGgocmVxLnZhbHVlc1tpXSwgcHJpbWFyeUtleS5rZXlQYXRoLCBrZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBvYmplY3REaWZmID0gZ2V0T2JqZWN0RGlmZihleGlzdGluZ1ZhbHVlLCByZXEudmFsdWVzW2ldKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhZGRpdGlvbmFsQ2hhbmdlc18xID0gdXBkYXRpbmcuZmlyZS5jYWxsKGN0eCwgb2JqZWN0RGlmZiwga2V5LCBleGlzdGluZ1ZhbHVlLCBkeFRyYW5zKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhZGRpdGlvbmFsQ2hhbmdlc18xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3RlZFZhbHVlXzEgPSByZXEudmFsdWVzW2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKGFkZGl0aW9uYWxDaGFuZ2VzXzEpLmZvckVhY2goZnVuY3Rpb24gKGtleVBhdGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhhc093bihyZXF1ZXN0ZWRWYWx1ZV8xLCBrZXlQYXRoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWVzdGVkVmFsdWVfMVtrZXlQYXRoXSA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkaXRpb25hbENoYW5nZXNfMVtrZXlQYXRoXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEJ5S2V5UGF0aChyZXF1ZXN0ZWRWYWx1ZV8xLCBrZXlQYXRoLCBhZGRpdGlvbmFsQ2hhbmdlc18xW2tleVBhdGhdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjdHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRvd25UYWJsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAubXV0YXRlKHJlcSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBmYWlsdXJlcyA9IF9hLmZhaWx1cmVzLCByZXN1bHRzID0gX2EucmVzdWx0cywgbnVtRmFpbHVyZXMgPSBfYS5udW1GYWlsdXJlcywgbGFzdFJlc3VsdCA9IF9hLmxhc3RSZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHByaW1LZXkgPSByZXN1bHRzID8gcmVzdWx0c1tpXSA6IGtleXNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY3R4ID0gY29udGV4dHNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJpbUtleSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3R4Lm9uZXJyb3IgJiYgY3R4Lm9uZXJyb3IoZmFpbHVyZXNbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3R4Lm9uc3VjY2VzcyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdHgub25zdWNjZXNzKHJlcS50eXBlID09PSAncHV0JyAmJiBleGlzdGluZ1ZhbHVlc1tpXVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyByZXEudmFsdWVzW2ldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHByaW1LZXlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyBmYWlsdXJlczogZmFpbHVyZXMsIHJlc3VsdHM6IHJlc3VsdHMsIG51bUZhaWx1cmVzOiBudW1GYWlsdXJlcywgbGFzdFJlc3VsdDogbGFzdFJlc3VsdCB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dHMuZm9yRWFjaChmdW5jdGlvbiAoY3R4KSB7IHJldHVybiBjdHgub25lcnJvciAmJiBjdHgub25lcnJvcihlcnJvcik7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZGVsZXRlUmFuZ2UocmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGVsZXRlTmV4dENodW5rKHJlcS50cmFucywgcmVxLnJhbmdlLCAxMDAwMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZGVsZXRlTmV4dENodW5rKHRyYW5zLCByYW5nZSwgbGltaXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkb3duVGFibGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucXVlcnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zOiB0cmFucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXM6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiB7IGluZGV4OiBwcmltYXJ5S2V5LCByYW5nZTogcmFuZ2UgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsaW1pdDogbGltaXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSBfYS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFkZFB1dE9yRGVsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2RlbGV0ZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleXM6IHJlc3VsdCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnM6IHRyYW5zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLm51bUZhaWx1cmVzID4gMClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChyZXMuZmFpbHVyZXNbMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0Lmxlbmd0aCA8IGxpbWl0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmVzOiBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1GYWlsdXJlczogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXN0UmVzdWx0OiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRlbGV0ZU5leHRDaHVuayh0cmFucywgX19hc3NpZ24oX19hc3NpZ24oe30sIHJhbmdlKSwgeyBsb3dlcjogcmVzdWx0W3Jlc3VsdC5sZW5ndGggLSAxXSwgbG93ZXJPcGVuOiB0cnVlIH0pLCBsaW1pdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfSB9KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0YWJsZU1pZGRsZXdhcmU7XG4gICAgICAgICAgICAgIH0gfSkpO1xuICAgICAgfSxcbiAgfTtcbiAgZnVuY3Rpb24gZ2V0RXhpc3RpbmdWYWx1ZXModGFibGUsIHJlcSwgZWZmZWN0aXZlS2V5cykge1xuICAgICAgcmV0dXJuIHJlcS50eXBlID09PSAnYWRkJ1xuICAgICAgICAgID8gUHJvbWlzZS5yZXNvbHZlKFtdKVxuICAgICAgICAgIDogdGFibGUuZ2V0TWFueSh7XG4gICAgICAgICAgICAgIHRyYW5zOiByZXEudHJhbnMsXG4gICAgICAgICAgICAgIGtleXM6IGVmZmVjdGl2ZUtleXMsXG4gICAgICAgICAgICAgIGNhY2hlOiAnaW1tdXRhYmxlJyxcbiAgICAgICAgICB9KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGdldEZyb21UcmFuc2FjdGlvbkNhY2hlKGtleXMsIGNhY2hlLCBjbG9uZSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoIWNhY2hlKVxuICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICBpZiAoY2FjaGUua2V5cy5sZW5ndGggPCBrZXlzLmxlbmd0aClcbiAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBqID0gMDsgaSA8IGNhY2hlLmtleXMubGVuZ3RoICYmIGogPCBrZXlzLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgIGlmIChjbXAoY2FjaGUua2V5c1tpXSwga2V5c1tqXSkgIT09IDApXG4gICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgcmVzdWx0LnB1c2goY2xvbmUgPyBkZWVwQ2xvbmUoY2FjaGUudmFsdWVzW2ldKSA6IGNhY2hlLnZhbHVlc1tpXSk7XG4gICAgICAgICAgICAgICsrajtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdC5sZW5ndGggPT09IGtleXMubGVuZ3RoID8gcmVzdWx0IDogbnVsbDtcbiAgICAgIH1cbiAgICAgIGNhdGNoIChfYSkge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICB9XG4gIHZhciBjYWNoZUV4aXN0aW5nVmFsdWVzTWlkZGxld2FyZSA9IHtcbiAgICAgIHN0YWNrOiAnZGJjb3JlJyxcbiAgICAgIGxldmVsOiAtMSxcbiAgICAgIGNyZWF0ZTogZnVuY3Rpb24gKGNvcmUpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB0YWJsZTogZnVuY3Rpb24gKHRhYmxlTmFtZSkge1xuICAgICAgICAgICAgICAgICAgdmFyIHRhYmxlID0gY29yZS50YWJsZSh0YWJsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9fYXNzaWduKF9fYXNzaWduKHt9LCB0YWJsZSksIHsgZ2V0TWFueTogZnVuY3Rpb24gKHJlcSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXJlcS5jYWNoZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhYmxlLmdldE1hbnkocmVxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY2FjaGVkUmVzdWx0ID0gZ2V0RnJvbVRyYW5zYWN0aW9uQ2FjaGUocmVxLmtleXMsIHJlcS50cmFuc1snX2NhY2hlJ10sIHJlcS5jYWNoZSA9PT0gJ2Nsb25lJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjYWNoZWRSZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBEZXhpZVByb21pc2UucmVzb2x2ZShjYWNoZWRSZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0YWJsZS5nZXRNYW55KHJlcSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXEudHJhbnNbJ19jYWNoZSddID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleXM6IHJlcS5rZXlzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogcmVxLmNhY2hlID09PSAnY2xvbmUnID8gZGVlcENsb25lKHJlcykgOiByZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSwgbXV0YXRlOiBmdW5jdGlvbiAocmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXEudHlwZSAhPT0gJ2FkZCcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXEudHJhbnNbJ19jYWNoZSddID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhYmxlLm11dGF0ZShyZXEpO1xuICAgICAgICAgICAgICAgICAgICAgIH0gfSk7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgfTtcbiAgICAgIH0sXG4gIH07XG5cbiAgZnVuY3Rpb24gaXNDYWNoYWJsZUNvbnRleHQoY3R4LCB0YWJsZSkge1xuICAgICAgcmV0dXJuIChjdHgudHJhbnMubW9kZSA9PT0gJ3JlYWRvbmx5JyAmJlxuICAgICAgICAgICEhY3R4LnN1YnNjciAmJlxuICAgICAgICAgICFjdHgudHJhbnMuZXhwbGljaXQgJiZcbiAgICAgICAgICBjdHgudHJhbnMuZGIuX29wdGlvbnMuY2FjaGUgIT09ICdkaXNhYmxlZCcgJiZcbiAgICAgICAgICAhdGFibGUuc2NoZW1hLnByaW1hcnlLZXkub3V0Ym91bmQpO1xuICB9XG5cbiAgZnVuY3Rpb24gaXNDYWNoYWJsZVJlcXVlc3QodHlwZSwgcmVxKSB7XG4gICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICBjYXNlICdxdWVyeSc6XG4gICAgICAgICAgICAgIHJldHVybiByZXEudmFsdWVzICYmICFyZXEudW5pcXVlO1xuICAgICAgICAgIGNhc2UgJ2dldCc6XG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICBjYXNlICdnZXRNYW55JzpcbiAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIGNhc2UgJ2NvdW50JzpcbiAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIGNhc2UgJ29wZW5DdXJzb3InOlxuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gIH1cblxuICB2YXIgb2JzZXJ2YWJpbGl0eU1pZGRsZXdhcmUgPSB7XG4gICAgICBzdGFjazogJ2RiY29yZScsXG4gICAgICBsZXZlbDogMCxcbiAgICAgIG5hbWU6ICdPYnNlcnZhYmlsaXR5JyxcbiAgICAgIGNyZWF0ZTogZnVuY3Rpb24gKGNvcmUpIHtcbiAgICAgICAgICB2YXIgZGJOYW1lID0gY29yZS5zY2hlbWEubmFtZTtcbiAgICAgICAgICB2YXIgRlVMTF9SQU5HRSA9IG5ldyBSYW5nZVNldChjb3JlLk1JTl9LRVksIGNvcmUuTUFYX0tFWSk7XG4gICAgICAgICAgcmV0dXJuIF9fYXNzaWduKF9fYXNzaWduKHt9LCBjb3JlKSwgeyB0cmFuc2FjdGlvbjogZnVuY3Rpb24gKHN0b3JlcywgbW9kZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgICAgICAgaWYgKFBTRC5zdWJzY3IgJiYgbW9kZSAhPT0gJ3JlYWRvbmx5Jykge1xuICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLlJlYWRPbmx5KFwiUmVhZHdyaXRlIHRyYW5zYWN0aW9uIGluIGxpdmVRdWVyeSBjb250ZXh0LiBRdWVyaWVyIHNvdXJjZTogXCIuY29uY2F0KFBTRC5xdWVyaWVyKSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXR1cm4gY29yZS50cmFuc2FjdGlvbihzdG9yZXMsIG1vZGUsIG9wdGlvbnMpO1xuICAgICAgICAgICAgICB9LCB0YWJsZTogZnVuY3Rpb24gKHRhYmxlTmFtZSkge1xuICAgICAgICAgICAgICAgICAgdmFyIHRhYmxlID0gY29yZS50YWJsZSh0YWJsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgdmFyIHNjaGVtYSA9IHRhYmxlLnNjaGVtYTtcbiAgICAgICAgICAgICAgICAgIHZhciBwcmltYXJ5S2V5ID0gc2NoZW1hLnByaW1hcnlLZXksIGluZGV4ZXMgPSBzY2hlbWEuaW5kZXhlcztcbiAgICAgICAgICAgICAgICAgIHZhciBleHRyYWN0S2V5ID0gcHJpbWFyeUtleS5leHRyYWN0S2V5LCBvdXRib3VuZCA9IHByaW1hcnlLZXkub3V0Ym91bmQ7XG4gICAgICAgICAgICAgICAgICB2YXIgaW5kZXhlc1dpdGhBdXRvSW5jUEsgPSBwcmltYXJ5S2V5LmF1dG9JbmNyZW1lbnQgJiZcbiAgICAgICAgICAgICAgICAgICAgICBpbmRleGVzLmZpbHRlcihmdW5jdGlvbiAoaW5kZXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGluZGV4LmNvbXBvdW5kICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleC5rZXlQYXRoLmluY2x1ZGVzKHByaW1hcnlLZXkua2V5UGF0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB2YXIgdGFibGVDbG9uZSA9IF9fYXNzaWduKF9fYXNzaWduKHt9LCB0YWJsZSksIHsgbXV0YXRlOiBmdW5jdGlvbiAocmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfYSwgX2I7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0cmFucyA9IHJlcS50cmFucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG11dGF0ZWRQYXJ0cyA9IHJlcS5tdXRhdGVkUGFydHMgfHwgKHJlcS5tdXRhdGVkUGFydHMgPSB7fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBnZXRSYW5nZVNldCA9IGZ1bmN0aW9uIChpbmRleE5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwYXJ0ID0gXCJpZGI6Ly9cIi5jb25jYXQoZGJOYW1lLCBcIi9cIikuY29uY2F0KHRhYmxlTmFtZSwgXCIvXCIpLmNvbmNhdChpbmRleE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChtdXRhdGVkUGFydHNbcGFydF0gfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAobXV0YXRlZFBhcnRzW3BhcnRdID0gbmV3IFJhbmdlU2V0KCkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHBrUmFuZ2VTZXQgPSBnZXRSYW5nZVNldCgnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkZWxzUmFuZ2VTZXQgPSBnZXRSYW5nZVNldCgnOmRlbHMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHR5cGUgPSByZXEudHlwZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF9jID0gcmVxLnR5cGUgPT09ICdkZWxldGVSYW5nZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gW3JlcS5yYW5nZV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVxLnR5cGUgPT09ICdkZWxldGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBbcmVxLmtleXNdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiByZXEudmFsdWVzLmxlbmd0aCA8IDUwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0RWZmZWN0aXZlS2V5cyhwcmltYXJ5S2V5LCByZXEpLmZpbHRlcihmdW5jdGlvbiAoaWQpIHsgcmV0dXJuIGlkOyB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcS52YWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBbXSwga2V5cyA9IF9jWzBdLCBuZXdPYmpzID0gX2NbMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBvbGRDYWNoZSA9IHJlcS50cmFuc1snX2NhY2hlJ107XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0FycmF5KGtleXMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwa1JhbmdlU2V0LmFkZEtleXMoa2V5cyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgb2xkT2JqcyA9IHR5cGUgPT09ICdkZWxldGUnIHx8IGtleXMubGVuZ3RoID09PSBuZXdPYmpzLmxlbmd0aFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZ2V0RnJvbVRyYW5zYWN0aW9uQ2FjaGUoa2V5cywgb2xkQ2FjaGUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFvbGRPYmpzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsc1JhbmdlU2V0LmFkZEtleXMoa2V5cyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAob2xkT2JqcyB8fCBuZXdPYmpzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhY2tBZmZlY3RlZEluZGV4ZXMoZ2V0UmFuZ2VTZXQsIHNjaGVtYSwgb2xkT2JqcywgbmV3T2Jqcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoa2V5cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJhbmdlID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZyb206IChfYSA9IGtleXMubG93ZXIpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IGNvcmUuTUlOX0tFWSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bzogKF9iID0ga2V5cy51cHBlcikgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogY29yZS5NQVhfS0VZLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbHNSYW5nZVNldC5hZGQocmFuZ2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGtSYW5nZVNldC5hZGQocmFuZ2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGtSYW5nZVNldC5hZGQoRlVMTF9SQU5HRSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxzUmFuZ2VTZXQuYWRkKEZVTExfUkFOR0UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NoZW1hLmluZGV4ZXMuZm9yRWFjaChmdW5jdGlvbiAoaWR4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGdldFJhbmdlU2V0KGlkeC5uYW1lKS5hZGQoRlVMTF9SQU5HRSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGFibGUubXV0YXRlKHJlcSkudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoa2V5cyAmJiAocmVxLnR5cGUgPT09ICdhZGQnIHx8IHJlcS50eXBlID09PSAncHV0JykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwa1JhbmdlU2V0LmFkZEtleXMocmVzLnJlc3VsdHMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbmRleGVzV2l0aEF1dG9JbmNQSykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleGVzV2l0aEF1dG9JbmNQSy5mb3JFYWNoKGZ1bmN0aW9uIChpZHgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpZHhWYWxzID0gcmVxLnZhbHVlcy5tYXAoZnVuY3Rpb24gKHYpIHsgcmV0dXJuIGlkeC5leHRyYWN0S2V5KHYpOyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwa1BvcyA9IGlkeC5rZXlQYXRoLmZpbmRJbmRleChmdW5jdGlvbiAocHJvcCkgeyByZXR1cm4gcHJvcCA9PT0gcHJpbWFyeUtleS5rZXlQYXRoOyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSByZXMucmVzdWx0cy5sZW5ndGg7IGkgPCBsZW47ICsraSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkeFZhbHNbaV1bcGtQb3NdID0gcmVzLnJlc3VsdHNbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZXRSYW5nZVNldChpZHgubmFtZSkuYWRkS2V5cyhpZHhWYWxzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnMubXV0YXRlZFBhcnRzID0gZXh0ZW5kT2JzZXJ2YWJpbGl0eVNldCh0cmFucy5tdXRhdGVkUGFydHMgfHwge30sIG11dGF0ZWRQYXJ0cyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9IH0pO1xuICAgICAgICAgICAgICAgICAgdmFyIGdldFJhbmdlID0gZnVuY3Rpb24gKF9hKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdmFyIF9iLCBfYztcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgX2QgPSBfYS5xdWVyeSwgaW5kZXggPSBfZC5pbmRleCwgcmFuZ2UgPSBfZC5yYW5nZTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmV3IFJhbmdlU2V0KChfYiA9IHJhbmdlLmxvd2VyKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiBjb3JlLk1JTl9LRVksIChfYyA9IHJhbmdlLnVwcGVyKSAhPT0gbnVsbCAmJiBfYyAhPT0gdm9pZCAwID8gX2MgOiBjb3JlLk1BWF9LRVkpLFxuICAgICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgdmFyIHJlYWRTdWJzY3JpYmVycyA9IHtcbiAgICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uIChyZXEpIHsgcmV0dXJuIFtwcmltYXJ5S2V5LCBuZXcgUmFuZ2VTZXQocmVxLmtleSldOyB9LFxuICAgICAgICAgICAgICAgICAgICAgIGdldE1hbnk6IGZ1bmN0aW9uIChyZXEpIHsgcmV0dXJuIFtwcmltYXJ5S2V5LCBuZXcgUmFuZ2VTZXQoKS5hZGRLZXlzKHJlcS5rZXlzKV07IH0sXG4gICAgICAgICAgICAgICAgICAgICAgY291bnQ6IGdldFJhbmdlLFxuICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiBnZXRSYW5nZSxcbiAgICAgICAgICAgICAgICAgICAgICBvcGVuQ3Vyc29yOiBnZXRSYW5nZSxcbiAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICBrZXlzKHJlYWRTdWJzY3JpYmVycykuZm9yRWFjaChmdW5jdGlvbiAobWV0aG9kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdGFibGVDbG9uZVttZXRob2RdID0gZnVuY3Rpb24gKHJlcSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3Vic2NyID0gUFNELnN1YnNjcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlzTGl2ZVF1ZXJ5ID0gISFzdWJzY3I7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjYWNoYWJsZSA9IGlzQ2FjaGFibGVDb250ZXh0KFBTRCwgdGFibGUpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NhY2hhYmxlUmVxdWVzdChtZXRob2QsIHJlcSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBvYnNTZXQgPSBjYWNoYWJsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAocmVxLm9ic1NldCA9IHt9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzdWJzY3I7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0xpdmVRdWVyeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGdldFJhbmdlU2V0ID0gZnVuY3Rpb24gKGluZGV4TmFtZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwYXJ0ID0gXCJpZGI6Ly9cIi5jb25jYXQoZGJOYW1lLCBcIi9cIikuY29uY2F0KHRhYmxlTmFtZSwgXCIvXCIpLmNvbmNhdChpbmRleE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAob2JzU2V0W3BhcnRdIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvYnNTZXRbcGFydF0gPSBuZXcgUmFuZ2VTZXQoKSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwa1JhbmdlU2V0XzEgPSBnZXRSYW5nZVNldCgnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGVsc1JhbmdlU2V0XzEgPSBnZXRSYW5nZVNldCgnOmRlbHMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfYSA9IHJlYWRTdWJzY3JpYmVyc1ttZXRob2RdKHJlcSksIHF1ZXJpZWRJbmRleCA9IF9hWzBdLCBxdWVyaWVkUmFuZ2VzID0gX2FbMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobWV0aG9kID09PSAncXVlcnknICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlcmllZEluZGV4LmlzUHJpbWFyeUtleSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFyZXEudmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsc1JhbmdlU2V0XzEuYWRkKHF1ZXJpZWRSYW5nZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0UmFuZ2VTZXQocXVlcmllZEluZGV4Lm5hbWUgfHwgJycpLmFkZChxdWVyaWVkUmFuZ2VzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcXVlcmllZEluZGV4LmlzUHJpbWFyeUtleSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtZXRob2QgPT09ICdjb3VudCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsc1JhbmdlU2V0XzEuYWRkKEZVTExfUkFOR0UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGtleXNQcm9taXNlXzEgPSBtZXRob2QgPT09ICdxdWVyeScgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG91dGJvdW5kICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXEudmFsdWVzICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZS5xdWVyeShfX2Fzc2lnbihfX2Fzc2lnbih7fSwgcmVxKSwgeyB2YWx1ZXM6IGZhbHNlIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhYmxlW21ldGhvZF0uYXBwbHkodGhpcywgYXJndW1lbnRzKS50aGVuKGZ1bmN0aW9uIChyZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtZXRob2QgPT09ICdxdWVyeScpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAob3V0Ym91bmQgJiYgcmVxLnZhbHVlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ga2V5c1Byb21pc2VfMS50aGVuKGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdGluZ0tleXMgPSBfYS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwa1JhbmdlU2V0XzEuYWRkS2V5cyhyZXN1bHRpbmdLZXlzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcEtleXMgPSByZXEudmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gcmVzLnJlc3VsdC5tYXAoZXh0cmFjdEtleSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiByZXMucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXEudmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBrUmFuZ2VTZXRfMS5hZGRLZXlzKHBLZXlzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbHNSYW5nZVNldF8xLmFkZEtleXMocEtleXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKG1ldGhvZCA9PT0gJ29wZW5DdXJzb3InKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGN1cnNvcl8xID0gcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB3YW50VmFsdWVzXzEgPSByZXFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnZhbHVlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKGN1cnNvcl8xICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5jcmVhdGUoY3Vyc29yXzEsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxzUmFuZ2VTZXRfMS5hZGRLZXkoY3Vyc29yXzEucHJpbWFyeUtleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjdXJzb3JfMS5rZXk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5S2V5OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwa2V5ID0gY3Vyc29yXzEucHJpbWFyeUtleTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsc1JhbmdlU2V0XzEuYWRkS2V5KHBrZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcGtleTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdhbnRWYWx1ZXNfMSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGtSYW5nZVNldF8xLmFkZEtleShjdXJzb3JfMS5wcmltYXJ5S2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGN1cnNvcl8xLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhYmxlW21ldGhvZF0uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdGFibGVDbG9uZTtcbiAgICAgICAgICAgICAgfSB9KTtcbiAgICAgIH0sXG4gIH07XG4gIGZ1bmN0aW9uIHRyYWNrQWZmZWN0ZWRJbmRleGVzKGdldFJhbmdlU2V0LCBzY2hlbWEsIG9sZE9ianMsIG5ld09ianMpIHtcbiAgICAgIGZ1bmN0aW9uIGFkZEFmZmVjdGVkSW5kZXgoaXgpIHtcbiAgICAgICAgICB2YXIgcmFuZ2VTZXQgPSBnZXRSYW5nZVNldChpeC5uYW1lIHx8ICcnKTtcbiAgICAgICAgICBmdW5jdGlvbiBleHRyYWN0S2V5KG9iaikge1xuICAgICAgICAgICAgICByZXR1cm4gb2JqICE9IG51bGwgPyBpeC5leHRyYWN0S2V5KG9iaikgOiBudWxsO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgYWRkS2V5T3JLZXlzID0gZnVuY3Rpb24gKGtleSkge1xuICAgICAgICAgICAgICByZXR1cm4gaXgubXVsdGlFbnRyeSAmJiBpc0FycmF5KGtleSlcbiAgICAgICAgICAgICAgICAgID9cbiAgICAgICAgICAgICAgICAgICAgICBrZXkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7IHJldHVybiByYW5nZVNldC5hZGRLZXkoa2V5KTsgfSlcbiAgICAgICAgICAgICAgICAgIDpcbiAgICAgICAgICAgICAgICAgICAgICByYW5nZVNldC5hZGRLZXkoa2V5KTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIChvbGRPYmpzIHx8IG5ld09ianMpLmZvckVhY2goZnVuY3Rpb24gKF8sIGkpIHtcbiAgICAgICAgICAgICAgdmFyIG9sZEtleSA9IG9sZE9ianMgJiYgZXh0cmFjdEtleShvbGRPYmpzW2ldKTtcbiAgICAgICAgICAgICAgdmFyIG5ld0tleSA9IG5ld09ianMgJiYgZXh0cmFjdEtleShuZXdPYmpzW2ldKTtcbiAgICAgICAgICAgICAgaWYgKGNtcChvbGRLZXksIG5ld0tleSkgIT09IDApIHtcbiAgICAgICAgICAgICAgICAgIGlmIChvbGRLZXkgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICBhZGRLZXlPcktleXMob2xkS2V5KTtcbiAgICAgICAgICAgICAgICAgIGlmIChuZXdLZXkgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICBhZGRLZXlPcktleXMobmV3S2V5KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgc2NoZW1hLmluZGV4ZXMuZm9yRWFjaChhZGRBZmZlY3RlZEluZGV4KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGFkanVzdE9wdGltaXN0aWNGcm9tRmFpbHVyZXModGJsQ2FjaGUsIHJlcSwgcmVzKSB7XG4gICAgICBpZiAocmVzLm51bUZhaWx1cmVzID09PSAwKVxuICAgICAgICAgIHJldHVybiByZXE7XG4gICAgICBpZiAocmVxLnR5cGUgPT09ICdkZWxldGVSYW5nZScpIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIHZhciBudW1CdWxrT3BzID0gcmVxLmtleXNcbiAgICAgICAgICA/IHJlcS5rZXlzLmxlbmd0aFxuICAgICAgICAgIDogJ3ZhbHVlcycgaW4gcmVxICYmIHJlcS52YWx1ZXNcbiAgICAgICAgICAgICAgPyByZXEudmFsdWVzLmxlbmd0aFxuICAgICAgICAgICAgICA6IDE7XG4gICAgICBpZiAocmVzLm51bUZhaWx1cmVzID09PSBudW1CdWxrT3BzKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICB2YXIgY2xvbmUgPSBfX2Fzc2lnbih7fSwgcmVxKTtcbiAgICAgIGlmIChpc0FycmF5KGNsb25lLmtleXMpKSB7XG4gICAgICAgICAgY2xvbmUua2V5cyA9IGNsb25lLmtleXMuZmlsdGVyKGZ1bmN0aW9uIChfLCBpKSB7IHJldHVybiAhKGkgaW4gcmVzLmZhaWx1cmVzKTsgfSk7XG4gICAgICB9XG4gICAgICBpZiAoJ3ZhbHVlcycgaW4gY2xvbmUgJiYgaXNBcnJheShjbG9uZS52YWx1ZXMpKSB7XG4gICAgICAgICAgY2xvbmUudmFsdWVzID0gY2xvbmUudmFsdWVzLmZpbHRlcihmdW5jdGlvbiAoXywgaSkgeyByZXR1cm4gIShpIGluIHJlcy5mYWlsdXJlcyk7IH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGNsb25lO1xuICB9XG5cbiAgZnVuY3Rpb24gaXNBYm92ZUxvd2VyKGtleSwgcmFuZ2UpIHtcbiAgICAgIHJldHVybiByYW5nZS5sb3dlciA9PT0gdW5kZWZpbmVkXG4gICAgICAgICAgPyB0cnVlXG4gICAgICAgICAgOiByYW5nZS5sb3dlck9wZW5cbiAgICAgICAgICAgICAgPyBjbXAoa2V5LCByYW5nZS5sb3dlcikgPiAwXG4gICAgICAgICAgICAgIDogY21wKGtleSwgcmFuZ2UubG93ZXIpID49IDA7XG4gIH1cbiAgZnVuY3Rpb24gaXNCZWxvd1VwcGVyKGtleSwgcmFuZ2UpIHtcbiAgICAgIHJldHVybiByYW5nZS51cHBlciA9PT0gdW5kZWZpbmVkXG4gICAgICAgICAgPyB0cnVlXG4gICAgICAgICAgOiByYW5nZS51cHBlck9wZW5cbiAgICAgICAgICAgICAgPyBjbXAoa2V5LCByYW5nZS51cHBlcikgPCAwXG4gICAgICAgICAgICAgIDogY21wKGtleSwgcmFuZ2UudXBwZXIpIDw9IDA7XG4gIH1cbiAgZnVuY3Rpb24gaXNXaXRoaW5SYW5nZShrZXksIHJhbmdlKSB7XG4gICAgICByZXR1cm4gaXNBYm92ZUxvd2VyKGtleSwgcmFuZ2UpICYmIGlzQmVsb3dVcHBlcihrZXksIHJhbmdlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGFwcGx5T3B0aW1pc3RpY09wcyhyZXN1bHQsIHJlcSwgb3BzLCB0YWJsZSwgY2FjaGVFbnRyeSwgaW1tdXRhYmxlKSB7XG4gICAgICBpZiAoIW9wcyB8fCBvcHMubGVuZ3RoID09PSAwKVxuICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB2YXIgaW5kZXggPSByZXEucXVlcnkuaW5kZXg7XG4gICAgICB2YXIgbXVsdGlFbnRyeSA9IGluZGV4Lm11bHRpRW50cnk7XG4gICAgICB2YXIgcXVlcnlSYW5nZSA9IHJlcS5xdWVyeS5yYW5nZTtcbiAgICAgIHZhciBwcmltYXJ5S2V5ID0gdGFibGUuc2NoZW1hLnByaW1hcnlLZXk7XG4gICAgICB2YXIgZXh0cmFjdFByaW1LZXkgPSBwcmltYXJ5S2V5LmV4dHJhY3RLZXk7XG4gICAgICB2YXIgZXh0cmFjdEluZGV4ID0gaW5kZXguZXh0cmFjdEtleTtcbiAgICAgIHZhciBleHRyYWN0TG93TGV2ZWxJbmRleCA9IChpbmRleC5sb3dMZXZlbEluZGV4IHx8IGluZGV4KS5leHRyYWN0S2V5O1xuICAgICAgdmFyIGZpbmFsUmVzdWx0ID0gb3BzLnJlZHVjZShmdW5jdGlvbiAocmVzdWx0LCBvcCkge1xuICAgICAgICAgIHZhciBtb2RpZmVkUmVzdWx0ID0gcmVzdWx0O1xuICAgICAgICAgIHZhciBpbmNsdWRlZFZhbHVlcyA9IFtdO1xuICAgICAgICAgIGlmIChvcC50eXBlID09PSAnYWRkJyB8fCBvcC50eXBlID09PSAncHV0Jykge1xuICAgICAgICAgICAgICB2YXIgaW5jbHVkZWRQS3MgPSBuZXcgUmFuZ2VTZXQoKTtcbiAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IG9wLnZhbHVlcy5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgICAgICAgICAgICAgdmFyIHZhbHVlID0gb3AudmFsdWVzW2ldO1xuICAgICAgICAgICAgICAgICAgdmFyIHBrID0gZXh0cmFjdFByaW1LZXkodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgaWYgKGluY2x1ZGVkUEtzLmhhc0tleShwaykpXG4gICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICB2YXIga2V5ID0gZXh0cmFjdEluZGV4KHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgIGlmIChtdWx0aUVudHJ5ICYmIGlzQXJyYXkoa2V5KVxuICAgICAgICAgICAgICAgICAgICAgID8ga2V5LnNvbWUoZnVuY3Rpb24gKGspIHsgcmV0dXJuIGlzV2l0aGluUmFuZ2UoaywgcXVlcnlSYW5nZSk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgOiBpc1dpdGhpblJhbmdlKGtleSwgcXVlcnlSYW5nZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpbmNsdWRlZFBLcy5hZGRLZXkocGspO1xuICAgICAgICAgICAgICAgICAgICAgIGluY2x1ZGVkVmFsdWVzLnB1c2godmFsdWUpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHN3aXRjaCAob3AudHlwZSkge1xuICAgICAgICAgICAgICBjYXNlICdhZGQnOiB7XG4gICAgICAgICAgICAgICAgICB2YXIgZXhpc3RpbmdLZXlzXzEgPSBuZXcgUmFuZ2VTZXQoKS5hZGRLZXlzKHJlcS52YWx1ZXMgPyByZXN1bHQubWFwKGZ1bmN0aW9uICh2KSB7IHJldHVybiBleHRyYWN0UHJpbUtleSh2KTsgfSkgOiByZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgbW9kaWZlZFJlc3VsdCA9IHJlc3VsdC5jb25jYXQocmVxLnZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgID8gaW5jbHVkZWRWYWx1ZXMuZmlsdGVyKGZ1bmN0aW9uICh2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBrZXkgPSBleHRyYWN0UHJpbUtleSh2KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV4aXN0aW5nS2V5c18xLmhhc0tleShrZXkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ0tleXNfMS5hZGRLZXkoa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICA6IGluY2x1ZGVkVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKHYpIHsgcmV0dXJuIGV4dHJhY3RQcmltS2V5KHYpOyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChleGlzdGluZ0tleXNfMS5oYXNLZXkoaykpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nS2V5c18xLmFkZEtleShrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgY2FzZSAncHV0Jzoge1xuICAgICAgICAgICAgICAgICAgdmFyIGtleVNldF8xID0gbmV3IFJhbmdlU2V0KCkuYWRkS2V5cyhvcC52YWx1ZXMubWFwKGZ1bmN0aW9uICh2KSB7IHJldHVybiBleHRyYWN0UHJpbUtleSh2KTsgfSkpO1xuICAgICAgICAgICAgICAgICAgbW9kaWZlZFJlc3VsdCA9IHJlc3VsdFxuICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICBmdW5jdGlvbiAoaXRlbSkgeyByZXR1cm4gIWtleVNldF8xLmhhc0tleShyZXEudmFsdWVzID8gZXh0cmFjdFByaW1LZXkoaXRlbSkgOiBpdGVtKTsgfSlcbiAgICAgICAgICAgICAgICAgICAgICAuY29uY2F0KFxuICAgICAgICAgICAgICAgICAgcmVxLnZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgID8gaW5jbHVkZWRWYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICA6IGluY2x1ZGVkVmFsdWVzLm1hcChmdW5jdGlvbiAodikgeyByZXR1cm4gZXh0cmFjdFByaW1LZXkodik7IH0pKTtcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNhc2UgJ2RlbGV0ZSc6XG4gICAgICAgICAgICAgICAgICB2YXIga2V5c1RvRGVsZXRlXzEgPSBuZXcgUmFuZ2VTZXQoKS5hZGRLZXlzKG9wLmtleXMpO1xuICAgICAgICAgICAgICAgICAgbW9kaWZlZFJlc3VsdCA9IHJlc3VsdC5maWx0ZXIoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gIWtleXNUb0RlbGV0ZV8xLmhhc0tleShyZXEudmFsdWVzID8gZXh0cmFjdFByaW1LZXkoaXRlbSkgOiBpdGVtKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIGNhc2UgJ2RlbGV0ZVJhbmdlJzpcbiAgICAgICAgICAgICAgICAgIHZhciByYW5nZV8xID0gb3AucmFuZ2U7XG4gICAgICAgICAgICAgICAgICBtb2RpZmVkUmVzdWx0ID0gcmVzdWx0LmZpbHRlcihmdW5jdGlvbiAoaXRlbSkgeyByZXR1cm4gIWlzV2l0aGluUmFuZ2UoZXh0cmFjdFByaW1LZXkoaXRlbSksIHJhbmdlXzEpOyB9KTtcbiAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gbW9kaWZlZFJlc3VsdDtcbiAgICAgIH0sIHJlc3VsdCk7XG4gICAgICBpZiAoZmluYWxSZXN1bHQgPT09IHJlc3VsdClcbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgdmFyIHNvcnRlciA9IGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICAgICAgcmV0dXJuIGNtcChleHRyYWN0TG93TGV2ZWxJbmRleChhKSwgZXh0cmFjdExvd0xldmVsSW5kZXgoYikpIHx8XG4gICAgICAgICAgICAgIGNtcChleHRyYWN0UHJpbUtleShhKSwgZXh0cmFjdFByaW1LZXkoYikpO1xuICAgICAgfTtcbiAgICAgIGZpbmFsUmVzdWx0LnNvcnQocmVxLmRpcmVjdGlvbiA9PT0gJ3ByZXYnIHx8IHJlcS5kaXJlY3Rpb24gPT09ICdwcmV2dW5pcXVlJ1xuICAgICAgICAgID8gZnVuY3Rpb24gKGEsIGIpIHsgcmV0dXJuIHNvcnRlcihiLCBhKTsgfVxuICAgICAgICAgIDogc29ydGVyKTtcbiAgICAgIGlmIChyZXEubGltaXQgJiYgcmVxLmxpbWl0IDwgSW5maW5pdHkpIHtcbiAgICAgICAgICBpZiAoZmluYWxSZXN1bHQubGVuZ3RoID4gcmVxLmxpbWl0KSB7XG4gICAgICAgICAgICAgIGZpbmFsUmVzdWx0Lmxlbmd0aCA9IHJlcS5saW1pdDtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZSBpZiAocmVzdWx0Lmxlbmd0aCA9PT0gcmVxLmxpbWl0ICYmIGZpbmFsUmVzdWx0Lmxlbmd0aCA8IHJlcS5saW1pdCkge1xuICAgICAgICAgICAgICBjYWNoZUVudHJ5LmRpcnR5ID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gaW1tdXRhYmxlID8gT2JqZWN0LmZyZWV6ZShmaW5hbFJlc3VsdCkgOiBmaW5hbFJlc3VsdDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGFyZVJhbmdlc0VxdWFsKHIxLCByMikge1xuICAgICAgcmV0dXJuIChjbXAocjEubG93ZXIsIHIyLmxvd2VyKSA9PT0gMCAmJlxuICAgICAgICAgIGNtcChyMS51cHBlciwgcjIudXBwZXIpID09PSAwICYmXG4gICAgICAgICAgISFyMS5sb3dlck9wZW4gPT09ICEhcjIubG93ZXJPcGVuICYmXG4gICAgICAgICAgISFyMS51cHBlck9wZW4gPT09ICEhcjIudXBwZXJPcGVuKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNvbXBhcmVMb3dlcnMobG93ZXIxLCBsb3dlcjIsIGxvd2VyT3BlbjEsIGxvd2VyT3BlbjIpIHtcbiAgICAgIGlmIChsb3dlcjEgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICByZXR1cm4gbG93ZXIyICE9PSB1bmRlZmluZWQgPyAtMSA6IDA7XG4gICAgICBpZiAobG93ZXIyID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgcmV0dXJuIDE7XG4gICAgICB2YXIgYyA9IGNtcChsb3dlcjEsIGxvd2VyMik7XG4gICAgICBpZiAoYyA9PT0gMCkge1xuICAgICAgICAgIGlmIChsb3dlck9wZW4xICYmIGxvd2VyT3BlbjIpXG4gICAgICAgICAgICAgIHJldHVybiAwO1xuICAgICAgICAgIGlmIChsb3dlck9wZW4xKVxuICAgICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgICBpZiAobG93ZXJPcGVuMilcbiAgICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGM7XG4gIH1cbiAgZnVuY3Rpb24gY29tcGFyZVVwcGVycyh1cHBlcjEsIHVwcGVyMiwgdXBwZXJPcGVuMSwgdXBwZXJPcGVuMikge1xuICAgICAgaWYgKHVwcGVyMSA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgIHJldHVybiB1cHBlcjIgIT09IHVuZGVmaW5lZCA/IDEgOiAwO1xuICAgICAgaWYgKHVwcGVyMiA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgIHZhciBjID0gY21wKHVwcGVyMSwgdXBwZXIyKTtcbiAgICAgIGlmIChjID09PSAwKSB7XG4gICAgICAgICAgaWYgKHVwcGVyT3BlbjEgJiYgdXBwZXJPcGVuMilcbiAgICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgICAgaWYgKHVwcGVyT3BlbjEpXG4gICAgICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgICBpZiAodXBwZXJPcGVuMilcbiAgICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICB9XG4gICAgICByZXR1cm4gYztcbiAgfVxuICBmdW5jdGlvbiBpc1N1cGVyUmFuZ2UocjEsIHIyKSB7XG4gICAgICByZXR1cm4gKGNvbXBhcmVMb3dlcnMocjEubG93ZXIsIHIyLmxvd2VyLCByMS5sb3dlck9wZW4sIHIyLmxvd2VyT3BlbikgPD0gMCAmJlxuICAgICAgICAgIGNvbXBhcmVVcHBlcnMocjEudXBwZXIsIHIyLnVwcGVyLCByMS51cHBlck9wZW4sIHIyLnVwcGVyT3BlbikgPj0gMCk7XG4gIH1cblxuICBmdW5jdGlvbiBmaW5kQ29tcGF0aWJsZVF1ZXJ5KGRiTmFtZSwgdGFibGVOYW1lLCB0eXBlLCByZXEpIHtcbiAgICAgIHZhciBfYTtcbiAgICAgIHZhciB0YmxDYWNoZSA9IGNhY2hlW1wiaWRiOi8vXCIuY29uY2F0KGRiTmFtZSwgXCIvXCIpLmNvbmNhdCh0YWJsZU5hbWUpXTtcbiAgICAgIGlmICghdGJsQ2FjaGUpXG4gICAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgdmFyIHF1ZXJpZXMgPSB0YmxDYWNoZS5xdWVyaWVzW3R5cGVdO1xuICAgICAgaWYgKCFxdWVyaWVzKVxuICAgICAgICAgIHJldHVybiBbbnVsbCwgZmFsc2UsIHRibENhY2hlLCBudWxsXTtcbiAgICAgIHZhciBpbmRleE5hbWUgPSByZXEucXVlcnkgPyByZXEucXVlcnkuaW5kZXgubmFtZSA6IG51bGw7XG4gICAgICB2YXIgZW50cmllcyA9IHF1ZXJpZXNbaW5kZXhOYW1lIHx8ICcnXTtcbiAgICAgIGlmICghZW50cmllcylcbiAgICAgICAgICByZXR1cm4gW251bGwsIGZhbHNlLCB0YmxDYWNoZSwgbnVsbF07XG4gICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICBjYXNlICdxdWVyeSc6XG4gICAgICAgICAgICAgIHZhciByZXFEaXJlY3Rpb25fMSA9IChfYSA9IHJlcS5kaXJlY3Rpb24pICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6ICduZXh0JztcbiAgICAgICAgICAgICAgdmFyIGVxdWFsRW50cnkgPSBlbnRyaWVzLmZpbmQoZnVuY3Rpb24gKGVudHJ5KSB7XG4gICAgICAgICAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZW50cnkucmVxLmxpbWl0ID09PSByZXEubGltaXQgJiZcbiAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5yZXEudmFsdWVzID09PSByZXEudmFsdWVzICYmXG4gICAgICAgICAgICAgICAgICAgICAgKChfYSA9IGVudHJ5LnJlcS5kaXJlY3Rpb24pICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6ICduZXh0JykgPT09XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcURpcmVjdGlvbl8xICYmXG4gICAgICAgICAgICAgICAgICAgICAgYXJlUmFuZ2VzRXF1YWwoZW50cnkucmVxLnF1ZXJ5LnJhbmdlLCByZXEucXVlcnkucmFuZ2UpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgaWYgKGVxdWFsRW50cnkpXG4gICAgICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgICAgICAgIGVxdWFsRW50cnksXG4gICAgICAgICAgICAgICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICB0YmxDYWNoZSxcbiAgICAgICAgICAgICAgICAgICAgICBlbnRyaWVzLFxuICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgdmFyIHN1cGVyRW50cnkgPSBlbnRyaWVzLmZpbmQoZnVuY3Rpb24gKGVudHJ5KSB7XG4gICAgICAgICAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgICAgICAgICB2YXIgbGltaXQgPSAnbGltaXQnIGluIGVudHJ5LnJlcSA/IGVudHJ5LnJlcS5saW1pdCA6IEluZmluaXR5O1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChsaW1pdCA+PSByZXEubGltaXQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAoKF9hID0gZW50cnkucmVxLmRpcmVjdGlvbikgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogJ25leHQnKSA9PT1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxRGlyZWN0aW9uXzEgJiZcbiAgICAgICAgICAgICAgICAgICAgICAocmVxLnZhbHVlcyA/IGVudHJ5LnJlcS52YWx1ZXMgOiB0cnVlKSAmJlxuICAgICAgICAgICAgICAgICAgICAgIGlzU3VwZXJSYW5nZShlbnRyeS5yZXEucXVlcnkucmFuZ2UsIHJlcS5xdWVyeS5yYW5nZSkpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuIFtzdXBlckVudHJ5LCBmYWxzZSwgdGJsQ2FjaGUsIGVudHJpZXNdO1xuICAgICAgICAgIGNhc2UgJ2NvdW50JzpcbiAgICAgICAgICAgICAgdmFyIGNvdW50UXVlcnkgPSBlbnRyaWVzLmZpbmQoZnVuY3Rpb24gKGVudHJ5KSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gYXJlUmFuZ2VzRXF1YWwoZW50cnkucmVxLnF1ZXJ5LnJhbmdlLCByZXEucXVlcnkucmFuZ2UpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuIFtjb3VudFF1ZXJ5LCAhIWNvdW50UXVlcnksIHRibENhY2hlLCBlbnRyaWVzXTtcbiAgICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHN1YnNjcmliZVRvQ2FjaGVFbnRyeShjYWNoZUVudHJ5LCBjb250YWluZXIsIHJlcXVlcnksIHNpZ25hbCkge1xuICAgICAgY2FjaGVFbnRyeS5zdWJzY3JpYmVycy5hZGQocmVxdWVyeSk7XG4gICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgY2FjaGVFbnRyeS5zdWJzY3JpYmVycy5kZWxldGUocmVxdWVyeSk7XG4gICAgICAgICAgaWYgKGNhY2hlRW50cnkuc3Vic2NyaWJlcnMuc2l6ZSA9PT0gMCkge1xuICAgICAgICAgICAgICBlbnF1ZUZvckRlbGV0aW9uKGNhY2hlRW50cnksIGNvbnRhaW5lcik7XG4gICAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gZW5xdWVGb3JEZWxldGlvbihjYWNoZUVudHJ5LCBjb250YWluZXIpIHtcbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmIChjYWNoZUVudHJ5LnN1YnNjcmliZXJzLnNpemUgPT09IDApIHtcbiAgICAgICAgICAgICAgZGVsQXJyYXlJdGVtKGNvbnRhaW5lciwgY2FjaGVFbnRyeSk7XG4gICAgICAgICAgfVxuICAgICAgfSwgMzAwMCk7XG4gIH1cblxuICB2YXIgY2FjaGVNaWRkbGV3YXJlID0ge1xuICAgICAgc3RhY2s6ICdkYmNvcmUnLFxuICAgICAgbGV2ZWw6IDAsXG4gICAgICBuYW1lOiAnQ2FjaGUnLFxuICAgICAgY3JlYXRlOiBmdW5jdGlvbiAoY29yZSkge1xuICAgICAgICAgIHZhciBkYk5hbWUgPSBjb3JlLnNjaGVtYS5uYW1lO1xuICAgICAgICAgIHZhciBjb3JlTVcgPSBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgY29yZSksIHsgdHJhbnNhY3Rpb246IGZ1bmN0aW9uIChzdG9yZXMsIG1vZGUsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBpZGJ0cmFucyA9IGNvcmUudHJhbnNhY3Rpb24oc3RvcmVzLCBtb2RlLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgICAgIGlmIChtb2RlID09PSAncmVhZHdyaXRlJykge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBhY18xID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBzaWduYWwgPSBhY18xLnNpZ25hbDtcbiAgICAgICAgICAgICAgICAgICAgICB2YXIgZW5kVHJhbnNhY3Rpb24gPSBmdW5jdGlvbiAod2FzQ29tbWl0dGVkKSB7IHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFjXzEuYWJvcnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1vZGUgPT09ICdyZWFkd3JpdGUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYWZmZWN0ZWRTdWJzY3JpYmVyc18xID0gbmV3IFNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBzdG9yZXNfMSA9IHN0b3JlczsgX2kgPCBzdG9yZXNfMS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmVOYW1lID0gc3RvcmVzXzFbX2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0YmxDYWNoZSA9IGNhY2hlW1wiaWRiOi8vXCIuY29uY2F0KGRiTmFtZSwgXCIvXCIpLmNvbmNhdChzdG9yZU5hbWUpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGJsQ2FjaGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRhYmxlID0gY29yZS50YWJsZShzdG9yZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgb3BzID0gdGJsQ2FjaGUub3B0aW1pc3RpY09wcy5maWx0ZXIoZnVuY3Rpb24gKG9wKSB7IHJldHVybiBvcC50cmFucyA9PT0gaWRidHJhbnM7IH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaWRidHJhbnMuX2V4cGxpY2l0ICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3YXNDb21taXR0ZWQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkYnRyYW5zLm11dGF0ZWRQYXJ0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2EgPSAwLCBfYiA9IE9iamVjdC52YWx1ZXModGJsQ2FjaGUucXVlcmllcy5xdWVyeSk7IF9hIDwgX2IubGVuZ3RoOyBfYSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVudHJpZXMgPSBfYltfYV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2MgPSAwLCBfZCA9IGVudHJpZXMuc2xpY2UoKTsgX2MgPCBfZC5sZW5ndGg7IF9jKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVudHJ5ID0gX2RbX2NdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAob2JzU2V0c092ZXJsYXAoZW50cnkub2JzU2V0LCBpZGJ0cmFucy5tdXRhdGVkUGFydHMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxBcnJheUl0ZW0oZW50cmllcywgZW50cnkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnkuc3Vic2NyaWJlcnMuZm9yRWFjaChmdW5jdGlvbiAocmVxdWVyeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBhZmZlY3RlZFN1YnNjcmliZXJzXzEuYWRkKHJlcXVlcnkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAob3BzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRibENhY2hlLm9wdGltaXN0aWNPcHMgPSB0YmxDYWNoZS5vcHRpbWlzdGljT3BzLmZpbHRlcihmdW5jdGlvbiAob3ApIHsgcmV0dXJuIG9wLnRyYW5zICE9PSBpZGJ0cmFuczsgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBfZSA9IDAsIF9mID0gT2JqZWN0LnZhbHVlcyh0YmxDYWNoZS5xdWVyaWVzLnF1ZXJ5KTsgX2UgPCBfZi5sZW5ndGg7IF9lKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZW50cmllcyA9IF9mW19lXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBfZyA9IDAsIF9oID0gZW50cmllcy5zbGljZSgpOyBfZyA8IF9oLmxlbmd0aDsgX2crKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZW50cnkgPSBfaFtfZ107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlbnRyeS5yZXMgIT0gbnVsbCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWRidHJhbnMubXV0YXRlZFBhcnRzXG4gICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHdhc0NvbW1pdHRlZCAmJiAhZW50cnkuZGlydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZnJlZXplUmVzdWx0cyA9IE9iamVjdC5pc0Zyb3plbihlbnRyeS5yZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtb2RSZXMgPSBhcHBseU9wdGltaXN0aWNPcHMoZW50cnkucmVzLCBlbnRyeS5yZXEsIG9wcywgdGFibGUsIGVudHJ5LCBmcmVlemVSZXN1bHRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZW50cnkuZGlydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsQXJyYXlJdGVtKGVudHJpZXMsIGVudHJ5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnkuc3Vic2NyaWJlcnMuZm9yRWFjaChmdW5jdGlvbiAocmVxdWVyeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFmZmVjdGVkU3Vic2NyaWJlcnNfMS5hZGQocmVxdWVyeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChtb2RSZXMgIT09IGVudHJ5LnJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5yZXMgPSBtb2RSZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LnByb21pc2UgPSBEZXhpZVByb21pc2UucmVzb2x2ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQ6IG1vZFJlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVudHJ5LmRpcnR5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbEFycmF5SXRlbShlbnRyaWVzLCBlbnRyeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5LnN1YnNjcmliZXJzLmZvckVhY2goZnVuY3Rpb24gKHJlcXVlcnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFmZmVjdGVkU3Vic2NyaWJlcnNfMS5hZGQocmVxdWVyeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZmZlY3RlZFN1YnNjcmliZXJzXzEuZm9yRWFjaChmdW5jdGlvbiAocmVxdWVyeSkgeyByZXR1cm4gcmVxdWVyeSgpOyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH07IH07XG4gICAgICAgICAgICAgICAgICAgICAgaWRidHJhbnMuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBlbmRUcmFuc2FjdGlvbihmYWxzZSksIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2lnbmFsOiBzaWduYWwsXG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgaWRidHJhbnMuYWRkRXZlbnRMaXN0ZW5lcignZXJyb3InLCBlbmRUcmFuc2FjdGlvbihmYWxzZSksIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2lnbmFsOiBzaWduYWwsXG4gICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgaWRidHJhbnMuYWRkRXZlbnRMaXN0ZW5lcignY29tcGxldGUnLCBlbmRUcmFuc2FjdGlvbih0cnVlKSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzaWduYWw6IHNpZ25hbCxcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiBpZGJ0cmFucztcbiAgICAgICAgICAgICAgfSwgdGFibGU6IGZ1bmN0aW9uICh0YWJsZU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgIHZhciBkb3duVGFibGUgPSBjb3JlLnRhYmxlKHRhYmxlTmFtZSk7XG4gICAgICAgICAgICAgICAgICB2YXIgcHJpbUtleSA9IGRvd25UYWJsZS5zY2hlbWEucHJpbWFyeUtleTtcbiAgICAgICAgICAgICAgICAgIHZhciB0YWJsZU1XID0gX19hc3NpZ24oX19hc3NpZ24oe30sIGRvd25UYWJsZSksIHsgbXV0YXRlOiBmdW5jdGlvbiAocmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0cmFucyA9IFBTRC50cmFucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByaW1LZXkub3V0Ym91bmQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zLmRiLl9vcHRpb25zLmNhY2hlID09PSAnZGlzYWJsZWQnIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFucy5leHBsaWNpdCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnMuaWRidHJhbnMubW9kZSAhPT0gJ3JlYWR3cml0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZG93blRhYmxlLm11dGF0ZShyZXEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0YmxDYWNoZSA9IGNhY2hlW1wiaWRiOi8vXCIuY29uY2F0KGRiTmFtZSwgXCIvXCIpLmNvbmNhdCh0YWJsZU5hbWUpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF0YmxDYWNoZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkb3duVGFibGUubXV0YXRlKHJlcSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwcm9taXNlID0gZG93blRhYmxlLm11dGF0ZShyZXEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKHJlcS50eXBlID09PSAnYWRkJyB8fCByZXEudHlwZSA9PT0gJ3B1dCcpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocmVxLnZhbHVlcy5sZW5ndGggPj0gNTAgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZXRFZmZlY3RpdmVLZXlzKHByaW1LZXksIHJlcSkuc29tZShmdW5jdGlvbiAoa2V5KSB7IHJldHVybiBrZXkgPT0gbnVsbDsgfSkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9taXNlLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXFXaXRoUmVzb2x2ZWRLZXlzID0gX19hc3NpZ24oX19hc3NpZ24oe30sIHJlcSksIHsgdmFsdWVzOiByZXEudmFsdWVzLm1hcChmdW5jdGlvbiAodmFsdWUsIGkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMuZmFpbHVyZXNbaV0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHZhbHVlV2l0aEtleSA9ICgoX2EgPSBwcmltS2V5LmtleVBhdGgpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5pbmNsdWRlcygnLicpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gZGVlcENsb25lKHZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogX19hc3NpZ24oe30sIHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEJ5S2V5UGF0aCh2YWx1ZVdpdGhLZXksIHByaW1LZXkua2V5UGF0aCwgcmVzLnJlc3VsdHNbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlV2l0aEtleTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkanVzdGVkUmVxID0gYWRqdXN0T3B0aW1pc3RpY0Zyb21GYWlsdXJlcyh0YmxDYWNoZSwgcmVxV2l0aFJlc29sdmVkS2V5cywgcmVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YmxDYWNoZS5vcHRpbWlzdGljT3BzLnB1c2goYWRqdXN0ZWRSZXEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXVlTWljcm90YXNrKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlcS5tdXRhdGVkUGFydHMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpZ25hbFN1YnNjcmliZXJzTGF6aWx5KHJlcS5tdXRhdGVkUGFydHMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YmxDYWNoZS5vcHRpbWlzdGljT3BzLnB1c2gocmVxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcS5tdXRhdGVkUGFydHMgJiYgc2lnbmFsU3Vic2NyaWJlcnNMYXppbHkocmVxLm11dGF0ZWRQYXJ0cyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9taXNlLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXMubnVtRmFpbHVyZXMgPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbEFycmF5SXRlbSh0YmxDYWNoZS5vcHRpbWlzdGljT3BzLCByZXEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYWRqdXN0ZWRSZXEgPSBhZGp1c3RPcHRpbWlzdGljRnJvbUZhaWx1cmVzKHRibENhY2hlLCByZXEsIHJlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhZGp1c3RlZFJlcSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGJsQ2FjaGUub3B0aW1pc3RpY09wcy5wdXNoKGFkanVzdGVkUmVxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXEubXV0YXRlZFBhcnRzICYmIHNpZ25hbFN1YnNjcmliZXJzTGF6aWx5KHJlcS5tdXRhdGVkUGFydHMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvbWlzZS5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsQXJyYXlJdGVtKHRibENhY2hlLm9wdGltaXN0aWNPcHMsIHJlcSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLm11dGF0ZWRQYXJ0cyAmJiBzaWduYWxTdWJzY3JpYmVyc0xhemlseShyZXEubXV0YXRlZFBhcnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBwcm9taXNlO1xuICAgICAgICAgICAgICAgICAgICAgIH0sIHF1ZXJ5OiBmdW5jdGlvbiAocmVxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0NhY2hhYmxlQ29udGV4dChQU0QsIGRvd25UYWJsZSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFpc0NhY2hhYmxlUmVxdWVzdCgncXVlcnknLCByZXEpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRvd25UYWJsZS5xdWVyeShyZXEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZnJlZXplUmVzdWx0cyA9ICgoX2EgPSBQU0QudHJhbnMpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5kYi5fb3B0aW9ucy5jYWNoZSkgPT09XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaW1tdXRhYmxlJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF9iID0gUFNELCByZXF1ZXJ5ID0gX2IucmVxdWVyeSwgc2lnbmFsID0gX2Iuc2lnbmFsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgX2MgPSBmaW5kQ29tcGF0aWJsZVF1ZXJ5KGRiTmFtZSwgdGFibGVOYW1lLCAncXVlcnknLCByZXEpLCBjYWNoZUVudHJ5ID0gX2NbMF0sIGV4YWN0TWF0Y2ggPSBfY1sxXSwgdGJsQ2FjaGUgPSBfY1syXSwgY29udGFpbmVyID0gX2NbM107XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjYWNoZUVudHJ5ICYmIGV4YWN0TWF0Y2gpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhY2hlRW50cnkub2JzU2V0ID0gcmVxLm9ic1NldDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwcm9taXNlID0gZG93blRhYmxlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnF1ZXJ5KHJlcSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IHJlcy5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNhY2hlRW50cnkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhY2hlRW50cnkucmVzID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChmcmVlemVSZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsID0gcmVzdWx0Lmxlbmd0aDsgaSA8IGw7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmZyZWV6ZShyZXN1bHRbaV0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5mcmVlemUocmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb250YWluZXIgJiYgY2FjaGVFbnRyeSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsQXJyYXlJdGVtKGNvbnRhaW5lciwgY2FjaGVFbnRyeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FjaGVFbnRyeSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYnNTZXQ6IHJlcS5vYnNTZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvbWlzZTogcHJvbWlzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyczogbmV3IFNldCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdxdWVyeScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxOiByZXEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlydHk6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb250YWluZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250YWluZXIucHVzaChjYWNoZUVudHJ5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRhaW5lciA9IFtjYWNoZUVudHJ5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXRibENhY2hlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRibENhY2hlID0gY2FjaGVbXCJpZGI6Ly9cIi5jb25jYXQoZGJOYW1lLCBcIi9cIikuY29uY2F0KHRhYmxlTmFtZSldID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcXVlcmllczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3VudDoge30sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqczogbmV3IE1hcCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW1pc3RpY09wczogW10sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bnNpZ25hbGVkUGFydHM6IHt9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YmxDYWNoZS5xdWVyaWVzLnF1ZXJ5W3JlcS5xdWVyeS5pbmRleC5uYW1lIHx8ICcnXSA9IGNvbnRhaW5lcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVUb0NhY2hlRW50cnkoY2FjaGVFbnRyeSwgY29udGFpbmVyLCByZXF1ZXJ5LCBzaWduYWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FjaGVFbnRyeS5wcm9taXNlLnRoZW4oZnVuY3Rpb24gKHJlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IGFwcGx5T3B0aW1pc3RpY09wcyhyZXMucmVzdWx0LCByZXEsIHRibENhY2hlID09PSBudWxsIHx8IHRibENhY2hlID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0YmxDYWNoZS5vcHRpbWlzdGljT3BzLCBkb3duVGFibGUsIGNhY2hlRW50cnksIGZyZWV6ZVJlc3VsdHMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQ6IGZyZWV6ZVJlc3VsdHMgPyByZXN1bHQgOiBkZWVwQ2xvbmUocmVzdWx0KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH0gfSk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdGFibGVNVztcbiAgICAgICAgICAgICAgfSB9KTtcbiAgICAgICAgICByZXR1cm4gY29yZU1XO1xuICAgICAgfSxcbiAgfTtcblxuICBmdW5jdGlvbiB2aXBpZnkodGFyZ2V0LCB2aXBEYikge1xuICAgICAgcmV0dXJuIG5ldyBQcm94eSh0YXJnZXQsIHtcbiAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgICAgIGlmIChwcm9wID09PSAnZGInKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHZpcERiO1xuICAgICAgICAgICAgICByZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG4gICAgICAgICAgfSxcbiAgICAgIH0pO1xuICB9XG5cbiAgdmFyIERleGllJDEgPSAgKGZ1bmN0aW9uICgpIHtcbiAgICAgIGZ1bmN0aW9uIERleGllKG5hbWUsIG9wdGlvbnMpIHtcbiAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgIHRoaXMuX21pZGRsZXdhcmVzID0ge307XG4gICAgICAgICAgdGhpcy52ZXJubyA9IDA7XG4gICAgICAgICAgdmFyIGRlcHMgPSBEZXhpZS5kZXBlbmRlbmNpZXM7XG4gICAgICAgICAgdGhpcy5fb3B0aW9ucyA9IG9wdGlvbnMgPSBfX2Fzc2lnbih7XG4gICAgICAgICAgICAgIGFkZG9uczogRGV4aWUuYWRkb25zLCBhdXRvT3BlbjogdHJ1ZSxcbiAgICAgICAgICAgICAgaW5kZXhlZERCOiBkZXBzLmluZGV4ZWREQiwgSURCS2V5UmFuZ2U6IGRlcHMuSURCS2V5UmFuZ2UsIGNhY2hlOiAnY2xvbmVkJywgbWF4Q29ubmVjdGlvbnM6IERFRkFVTFRfTUFYX0NPTk5FQ1RJT05TIH0sIG9wdGlvbnMpO1xuICAgICAgICAgIHRoaXMuX2RlcHMgPSB7XG4gICAgICAgICAgICAgIGluZGV4ZWREQjogb3B0aW9ucy5pbmRleGVkREIsXG4gICAgICAgICAgICAgIElEQktleVJhbmdlOiBvcHRpb25zLklEQktleVJhbmdlLFxuICAgICAgICAgIH07XG4gICAgICAgICAgdmFyIGFkZG9ucyA9IG9wdGlvbnMuYWRkb25zO1xuICAgICAgICAgIHRoaXMuX2RiU2NoZW1hID0ge307XG4gICAgICAgICAgdGhpcy5fdmVyc2lvbnMgPSBbXTtcbiAgICAgICAgICB0aGlzLl9zdG9yZU5hbWVzID0gW107XG4gICAgICAgICAgdGhpcy5fYWxsVGFibGVzID0ge307XG4gICAgICAgICAgdGhpcy5pZGJkYiA9IG51bGw7XG4gICAgICAgICAgdGhpcy5fbm92aXAgPSB0aGlzO1xuICAgICAgICAgIHZhciBzdGF0ZSA9IHtcbiAgICAgICAgICAgICAgZGJPcGVuRXJyb3I6IG51bGwsXG4gICAgICAgICAgICAgIGlzQmVpbmdPcGVuZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvblJlYWR5QmVpbmdGaXJlZDogbnVsbCxcbiAgICAgICAgICAgICAgb3BlbkNvbXBsZXRlOiBmYWxzZSxcbiAgICAgICAgICAgICAgZGJSZWFkeVJlc29sdmU6IG5vcCxcbiAgICAgICAgICAgICAgZGJSZWFkeVByb21pc2U6IG51bGwsXG4gICAgICAgICAgICAgIGNhbmNlbE9wZW46IG5vcCxcbiAgICAgICAgICAgICAgb3BlbkNhbmNlbGxlcjogbnVsbCxcbiAgICAgICAgICAgICAgYXV0b1NjaGVtYTogdHJ1ZSxcbiAgICAgICAgICAgICAgUFIxMzk4X21heExvb3A6IDMsXG4gICAgICAgICAgICAgIGF1dG9PcGVuOiBvcHRpb25zLmF1dG9PcGVuLFxuICAgICAgICAgIH07XG4gICAgICAgICAgc3RhdGUuZGJSZWFkeVByb21pc2UgPSBuZXcgRGV4aWVQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlKSB7XG4gICAgICAgICAgICAgIHN0YXRlLmRiUmVhZHlSZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBzdGF0ZS5vcGVuQ2FuY2VsbGVyID0gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAoXywgcmVqZWN0KSB7XG4gICAgICAgICAgICAgIHN0YXRlLmNhbmNlbE9wZW4gPSByZWplY3Q7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdGhpcy5fc3RhdGUgPSBzdGF0ZTtcbiAgICAgICAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgICAgICAgIHRoaXMub24gPSBFdmVudHModGhpcywgJ3BvcHVsYXRlJywgJ2Jsb2NrZWQnLCAndmVyc2lvbmNoYW5nZScsICdjbG9zZScsIHtcbiAgICAgICAgICAgICAgcmVhZHk6IFtwcm9taXNhYmxlQ2hhaW4sIG5vcF0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdGhpcy5vbmNlID0gZnVuY3Rpb24gKGV2ZW50LCBjYWxsYmFjaykge1xuICAgICAgICAgICAgICB2YXIgZm4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgYXJncyA9IFtdO1xuICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICBhcmdzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBfdGhpcy5vbihldmVudCkudW5zdWJzY3JpYmUoZm4pO1xuICAgICAgICAgICAgICAgICAgY2FsbGJhY2suYXBwbHkoX3RoaXMsIGFyZ3MpO1xuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICByZXR1cm4gX3RoaXMub24oZXZlbnQsIGZuKTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHRoaXMub24ucmVhZHkuc3Vic2NyaWJlID0gb3ZlcnJpZGUodGhpcy5vbi5yZWFkeS5zdWJzY3JpYmUsIGZ1bmN0aW9uIChzdWJzY3JpYmUpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChzdWJzY3JpYmVyLCBiU3RpY2t5KSB7XG4gICAgICAgICAgICAgICAgICBEZXhpZS52aXAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciBzdGF0ZSA9IF90aGlzLl9zdGF0ZTtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RhdGUub3BlbkNvbXBsZXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghc3RhdGUuZGJPcGVuRXJyb3IpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZXhpZVByb21pc2UucmVzb2x2ZSgpLnRoZW4oc3Vic2NyaWJlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChiU3RpY2t5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlKHN1YnNjcmliZXIpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzdGF0ZS5vblJlYWR5QmVpbmdGaXJlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5vblJlYWR5QmVpbmdGaXJlZC5wdXNoKHN1YnNjcmliZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYlN0aWNreSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRiXzEgPSBfdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFiU3RpY2t5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlKGZ1bmN0aW9uIHVuc3Vic2NyaWJlKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRiXzEub24ucmVhZHkudW5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGJfMS5vbi5yZWFkeS51bnN1YnNjcmliZSh1bnN1YnNjcmliZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLkNvbGxlY3Rpb24gPSBjcmVhdGVDb2xsZWN0aW9uQ29uc3RydWN0b3IodGhpcyk7XG4gICAgICAgICAgdGhpcy5UYWJsZSA9IGNyZWF0ZVRhYmxlQ29uc3RydWN0b3IodGhpcyk7XG4gICAgICAgICAgdGhpcy5UcmFuc2FjdGlvbiA9IGNyZWF0ZVRyYW5zYWN0aW9uQ29uc3RydWN0b3IodGhpcyk7XG4gICAgICAgICAgdGhpcy5WZXJzaW9uID0gY3JlYXRlVmVyc2lvbkNvbnN0cnVjdG9yKHRoaXMpO1xuICAgICAgICAgIHRoaXMuV2hlcmVDbGF1c2UgPSBjcmVhdGVXaGVyZUNsYXVzZUNvbnN0cnVjdG9yKHRoaXMpO1xuICAgICAgICAgIHRoaXMub24oJ3ZlcnNpb25jaGFuZ2UnLCBmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgICAgaWYgKGV2Lm5ld1ZlcnNpb24gPiAwKVxuICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKFwiQW5vdGhlciBjb25uZWN0aW9uIHdhbnRzIHRvIHVwZ3JhZGUgZGF0YWJhc2UgJ1wiLmNvbmNhdChfdGhpcy5uYW1lLCBcIicuIENsb3NpbmcgZGIgbm93IHRvIHJlc3VtZSB0aGUgdXBncmFkZS5cIikpO1xuICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJBbm90aGVyIGNvbm5lY3Rpb24gd2FudHMgdG8gZGVsZXRlIGRhdGFiYXNlICdcIi5jb25jYXQoX3RoaXMubmFtZSwgXCInLiBDbG9zaW5nIGRiIG5vdyB0byByZXN1bWUgdGhlIGRlbGV0ZSByZXF1ZXN0LlwiKSk7XG4gICAgICAgICAgICAgIF90aGlzLmNsb3NlKHsgZGlzYWJsZUF1dG9PcGVuOiBmYWxzZSB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLm9uKCdibG9ja2VkJywgZnVuY3Rpb24gKGV2KSB7XG4gICAgICAgICAgICAgIGlmICghZXYubmV3VmVyc2lvbiB8fCBldi5uZXdWZXJzaW9uIDwgZXYub2xkVmVyc2lvbilcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcIkRleGllLmRlbGV0ZSgnXCIuY29uY2F0KF90aGlzLm5hbWUsIFwiJykgd2FzIGJsb2NrZWRcIikpO1xuICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJVcGdyYWRlICdcIi5jb25jYXQoX3RoaXMubmFtZSwgXCInIGJsb2NrZWQgYnkgb3RoZXIgY29ubmVjdGlvbiBob2xkaW5nIHZlcnNpb24gXCIpLmNvbmNhdChldi5vbGRWZXJzaW9uIC8gMTApKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLl9tYXhLZXkgPSBnZXRNYXhLZXkob3B0aW9ucy5JREJLZXlSYW5nZSk7XG4gICAgICAgICAgdGhpcy5fY3JlYXRlVHJhbnNhY3Rpb24gPSBmdW5jdGlvbiAobW9kZSwgc3RvcmVOYW1lcywgZGJzY2hlbWEsIHBhcmVudFRyYW5zYWN0aW9uKSB7XG4gICAgICAgICAgICAgIHJldHVybiBuZXcgX3RoaXMuVHJhbnNhY3Rpb24obW9kZSwgc3RvcmVOYW1lcywgZGJzY2hlbWEsIF90aGlzLl9vcHRpb25zLmNocm9tZVRyYW5zYWN0aW9uRHVyYWJpbGl0eSwgcGFyZW50VHJhbnNhY3Rpb24pO1xuICAgICAgICAgIH07XG4gICAgICAgICAgdGhpcy5fZmlyZU9uQmxvY2tlZCA9IGZ1bmN0aW9uIChldikge1xuICAgICAgICAgICAgICBfdGhpcy5vbignYmxvY2tlZCcpLmZpcmUoZXYpO1xuICAgICAgICAgICAgICBjb25uZWN0aW9uc1xuICAgICAgICAgICAgICAgICAgLnRvQXJyYXkoKVxuICAgICAgICAgICAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoYykgeyByZXR1cm4gYy5uYW1lID09PSBfdGhpcy5uYW1lICYmIGMgIT09IF90aGlzICYmICFjLl9zdGF0ZS52Y0ZpcmVkOyB9KVxuICAgICAgICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAoYykgeyByZXR1cm4gYy5vbigndmVyc2lvbmNoYW5nZScpLmZpcmUoZXYpOyB9KTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHRoaXMudXNlKGNhY2hlRXhpc3RpbmdWYWx1ZXNNaWRkbGV3YXJlKTtcbiAgICAgICAgICB0aGlzLnVzZShjYWNoZU1pZGRsZXdhcmUpO1xuICAgICAgICAgIHRoaXMudXNlKG9ic2VydmFiaWxpdHlNaWRkbGV3YXJlKTtcbiAgICAgICAgICB0aGlzLnVzZSh2aXJ0dWFsSW5kZXhNaWRkbGV3YXJlKTtcbiAgICAgICAgICB0aGlzLnVzZShob29rc01pZGRsZXdhcmUpO1xuICAgICAgICAgIHZhciB2aXBEQiA9IG5ldyBQcm94eSh0aGlzLCB7XG4gICAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKF8sIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgICAgICAgICBpZiAocHJvcCA9PT0gJ192aXAnKVxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgICAgaWYgKHByb3AgPT09ICd0YWJsZScpXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICh0YWJsZU5hbWUpIHsgcmV0dXJuIHZpcGlmeShfdGhpcy50YWJsZSh0YWJsZU5hbWUpLCB2aXBEQik7IH07XG4gICAgICAgICAgICAgICAgICB2YXIgcnYgPSBSZWZsZWN0LmdldChfLCBwcm9wLCByZWNlaXZlcik7XG4gICAgICAgICAgICAgICAgICBpZiAocnYgaW5zdGFuY2VvZiBUYWJsZSlcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmlwaWZ5KHJ2LCB2aXBEQik7XG4gICAgICAgICAgICAgICAgICBpZiAocHJvcCA9PT0gJ3RhYmxlcycpXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJ2Lm1hcChmdW5jdGlvbiAodCkgeyByZXR1cm4gdmlwaWZ5KHQsIHZpcERCKTsgfSk7XG4gICAgICAgICAgICAgICAgICBpZiAocHJvcCA9PT0gJ19jcmVhdGVUcmFuc2FjdGlvbicpXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHR4ID0gcnYuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZpcGlmeSh0eCwgdmlwREIpO1xuICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICByZXR1cm4gcnY7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdGhpcy52aXAgPSB2aXBEQjtcbiAgICAgICAgICBhZGRvbnMuZm9yRWFjaChmdW5jdGlvbiAoYWRkb24pIHsgcmV0dXJuIGFkZG9uKF90aGlzKTsgfSk7XG4gICAgICB9XG4gICAgICBEZXhpZS5wcm90b3R5cGUudmVyc2lvbiA9IGZ1bmN0aW9uICh2ZXJzaW9uTnVtYmVyKSB7XG4gICAgICAgICAgaWYgKGlzTmFOKHZlcnNpb25OdW1iZXIpIHx8IHZlcnNpb25OdW1iZXIgPCAwLjEpXG4gICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLlR5cGUoXCJHaXZlbiB2ZXJzaW9uIGlzIG5vdCBhIHBvc2l0aXZlIG51bWJlclwiKTtcbiAgICAgICAgICB2ZXJzaW9uTnVtYmVyID0gTWF0aC5yb3VuZCh2ZXJzaW9uTnVtYmVyICogMTApIC8gMTA7XG4gICAgICAgICAgaWYgKHRoaXMuaWRiZGIgfHwgdGhpcy5fc3RhdGUuaXNCZWluZ09wZW5lZClcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuU2NoZW1hKCdDYW5ub3QgYWRkIHZlcnNpb24gd2hlbiBkYXRhYmFzZSBpcyBvcGVuJyk7XG4gICAgICAgICAgdGhpcy52ZXJubyA9IE1hdGgubWF4KHRoaXMudmVybm8sIHZlcnNpb25OdW1iZXIpO1xuICAgICAgICAgIHZhciB2ZXJzaW9ucyA9IHRoaXMuX3ZlcnNpb25zO1xuICAgICAgICAgIHZhciB2ZXJzaW9uSW5zdGFuY2UgPSB2ZXJzaW9ucy5maWx0ZXIoZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHYuX2NmZy52ZXJzaW9uID09PSB2ZXJzaW9uTnVtYmVyOyB9KVswXTtcbiAgICAgICAgICBpZiAodmVyc2lvbkluc3RhbmNlKVxuICAgICAgICAgICAgICByZXR1cm4gdmVyc2lvbkluc3RhbmNlO1xuICAgICAgICAgIHZlcnNpb25JbnN0YW5jZSA9IG5ldyB0aGlzLlZlcnNpb24odmVyc2lvbk51bWJlcik7XG4gICAgICAgICAgdmVyc2lvbnMucHVzaCh2ZXJzaW9uSW5zdGFuY2UpO1xuICAgICAgICAgIHZlcnNpb25zLnNvcnQobG93ZXJWZXJzaW9uRmlyc3QpO1xuICAgICAgICAgIHZlcnNpb25JbnN0YW5jZS5zdG9yZXMoe30pO1xuICAgICAgICAgIHRoaXMuX3N0YXRlLmF1dG9TY2hlbWEgPSBmYWxzZTtcbiAgICAgICAgICByZXR1cm4gdmVyc2lvbkluc3RhbmNlO1xuICAgICAgfTtcbiAgICAgIERleGllLnByb3RvdHlwZS5fd2hlblJlYWR5ID0gZnVuY3Rpb24gKGZuKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICByZXR1cm4gdGhpcy5pZGJkYiAmJlxuICAgICAgICAgICAgICAodGhpcy5fc3RhdGUub3BlbkNvbXBsZXRlIHx8IFBTRC5sZXRUaHJvdWdoIHx8IHRoaXMuX3ZpcClcbiAgICAgICAgICAgICAgPyBmbigpXG4gICAgICAgICAgICAgIDogbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICBpZiAoX3RoaXMuX3N0YXRlLm9wZW5Db21wbGV0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZWplY3QobmV3IGV4Y2VwdGlvbnMuRGF0YWJhc2VDbG9zZWQoX3RoaXMuX3N0YXRlLmRiT3BlbkVycm9yKSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoIV90aGlzLl9zdGF0ZS5pc0JlaW5nT3BlbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKCFfdGhpcy5fc3RhdGUuYXV0b09wZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KG5ldyBleGNlcHRpb25zLkRhdGFiYXNlQ2xvc2VkKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIF90aGlzLm9wZW4oKS5jYXRjaChub3ApO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgX3RoaXMuX3N0YXRlLmRiUmVhZHlQcm9taXNlLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgfSkudGhlbihmbik7XG4gICAgICB9O1xuICAgICAgRGV4aWUucHJvdG90eXBlLnVzZSA9IGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgIHZhciBzdGFjayA9IF9hLnN0YWNrLCBjcmVhdGUgPSBfYS5jcmVhdGUsIGxldmVsID0gX2EubGV2ZWwsIG5hbWUgPSBfYS5uYW1lO1xuICAgICAgICAgIGlmIChuYW1lKVxuICAgICAgICAgICAgICB0aGlzLnVudXNlKHsgc3RhY2s6IHN0YWNrLCBuYW1lOiBuYW1lIH0pO1xuICAgICAgICAgIHZhciBtaWRkbGV3YXJlcyA9IHRoaXMuX21pZGRsZXdhcmVzW3N0YWNrXSB8fCAodGhpcy5fbWlkZGxld2FyZXNbc3RhY2tdID0gW10pO1xuICAgICAgICAgIG1pZGRsZXdhcmVzLnB1c2goe1xuICAgICAgICAgICAgICBzdGFjazogc3RhY2ssXG4gICAgICAgICAgICAgIGNyZWF0ZTogY3JlYXRlLFxuICAgICAgICAgICAgICBsZXZlbDogbGV2ZWwgPT0gbnVsbCA/IDEwIDogbGV2ZWwsXG4gICAgICAgICAgICAgIG5hbWU6IG5hbWUsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbWlkZGxld2FyZXMuc29ydChmdW5jdGlvbiAoYSwgYikgeyByZXR1cm4gYS5sZXZlbCAtIGIubGV2ZWw7IH0pO1xuICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgfTtcbiAgICAgIERleGllLnByb3RvdHlwZS51bnVzZSA9IGZ1bmN0aW9uIChfYSkge1xuICAgICAgICAgIHZhciBzdGFjayA9IF9hLnN0YWNrLCBuYW1lID0gX2EubmFtZSwgY3JlYXRlID0gX2EuY3JlYXRlO1xuICAgICAgICAgIGlmIChzdGFjayAmJiB0aGlzLl9taWRkbGV3YXJlc1tzdGFja10pIHtcbiAgICAgICAgICAgICAgdGhpcy5fbWlkZGxld2FyZXNbc3RhY2tdID0gdGhpcy5fbWlkZGxld2FyZXNbc3RhY2tdLmZpbHRlcihmdW5jdGlvbiAobXcpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjcmVhdGVcbiAgICAgICAgICAgICAgICAgICAgICA/IG13LmNyZWF0ZSAhPT0gY3JlYXRlXG4gICAgICAgICAgICAgICAgICAgICAgOiBuYW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gbXcubmFtZSAhPT0gbmFtZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IGZhbHNlO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgICAgRGV4aWUucHJvdG90eXBlLm9wZW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICByZXR1cm4gdXNlUFNEKGdsb2JhbFBTRCxcbiAgICAgICAgICBmdW5jdGlvbiAoKSB7IHJldHVybiBkZXhpZU9wZW4oX3RoaXMpOyB9KTtcbiAgICAgIH07XG4gICAgICBEZXhpZS5wcm90b3R5cGUuX2Nsb3NlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHRoaXMub24uY2xvc2UuZmlyZShuZXcgQ3VzdG9tRXZlbnQoJ2Nsb3NlJykpO1xuICAgICAgICAgIHZhciBzdGF0ZSA9IHRoaXMuX3N0YXRlO1xuICAgICAgICAgIGNvbm5lY3Rpb25zLnJlbW92ZSh0aGlzKTtcbiAgICAgICAgICBpZiAodGhpcy5pZGJkYikge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgdGhpcy5pZGJkYi5jbG9zZSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNhdGNoIChlKSB7IH1cbiAgICAgICAgICAgICAgdGhpcy5pZGJkYiA9IG51bGw7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghc3RhdGUuaXNCZWluZ09wZW5lZCkge1xuICAgICAgICAgICAgICBzdGF0ZS5kYlJlYWR5UHJvbWlzZSA9IG5ldyBEZXhpZVByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICAgICAgICAgICAgICAgIHN0YXRlLmRiUmVhZHlSZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHN0YXRlLm9wZW5DYW5jZWxsZXIgPSBuZXcgRGV4aWVQcm9taXNlKGZ1bmN0aW9uIChfLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgIHN0YXRlLmNhbmNlbE9wZW4gPSByZWplY3Q7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgIH07XG4gICAgICBEZXhpZS5wcm90b3R5cGUuY2xvc2UgPSBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICB2YXIgX2IgPSBfYSA9PT0gdm9pZCAwID8geyBkaXNhYmxlQXV0b09wZW46IHRydWUgfSA6IF9hLCBkaXNhYmxlQXV0b09wZW4gPSBfYi5kaXNhYmxlQXV0b09wZW47XG4gICAgICAgICAgdmFyIHN0YXRlID0gdGhpcy5fc3RhdGU7XG4gICAgICAgICAgaWYgKGRpc2FibGVBdXRvT3Blbikge1xuICAgICAgICAgICAgICBpZiAoc3RhdGUuaXNCZWluZ09wZW5lZCkge1xuICAgICAgICAgICAgICAgICAgc3RhdGUuY2FuY2VsT3BlbihuZXcgZXhjZXB0aW9ucy5EYXRhYmFzZUNsb3NlZCgpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB0aGlzLl9jbG9zZSgpO1xuICAgICAgICAgICAgICBzdGF0ZS5hdXRvT3BlbiA9IGZhbHNlO1xuICAgICAgICAgICAgICBzdGF0ZS5kYk9wZW5FcnJvciA9IG5ldyBleGNlcHRpb25zLkRhdGFiYXNlQ2xvc2VkKCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICB0aGlzLl9jbG9zZSgpO1xuICAgICAgICAgICAgICBzdGF0ZS5hdXRvT3BlbiA9IHRoaXMuX29wdGlvbnMuYXV0b09wZW4gfHwgc3RhdGUuaXNCZWluZ09wZW5lZDtcbiAgICAgICAgICAgICAgc3RhdGUub3BlbkNvbXBsZXRlID0gZmFsc2U7XG4gICAgICAgICAgICAgIHN0YXRlLmRiT3BlbkVycm9yID0gbnVsbDtcbiAgICAgICAgICB9XG4gICAgICB9O1xuICAgICAgRGV4aWUucHJvdG90eXBlLmRlbGV0ZSA9IGZ1bmN0aW9uIChjbG9zZU9wdGlvbnMpIHtcbiAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgIGlmIChjbG9zZU9wdGlvbnMgPT09IHZvaWQgMCkgeyBjbG9zZU9wdGlvbnMgPSB7IGRpc2FibGVBdXRvT3BlbjogdHJ1ZSB9OyB9XG4gICAgICAgICAgdmFyIGhhc0ludmFsaWRBcmd1bWVudHMgPSBhcmd1bWVudHMubGVuZ3RoID4gMCAmJiB0eXBlb2YgYXJndW1lbnRzWzBdICE9PSAnb2JqZWN0JztcbiAgICAgICAgICB2YXIgc3RhdGUgPSB0aGlzLl9zdGF0ZTtcbiAgICAgICAgICByZXR1cm4gbmV3IERleGllUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgIHZhciBkb0RlbGV0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIF90aGlzLmNsb3NlKGNsb3NlT3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICB2YXIgcmVxID0gX3RoaXMuX2RlcHMuaW5kZXhlZERCLmRlbGV0ZURhdGFiYXNlKF90aGlzLm5hbWUpO1xuICAgICAgICAgICAgICAgICAgcmVxLm9uc3VjY2VzcyA9IHdyYXAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgIF9vbkRhdGFiYXNlRGVsZXRlZChfdGhpcy5fZGVwcywgX3RoaXMubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICByZXEub25lcnJvciA9IGV2ZW50UmVqZWN0SGFuZGxlcihyZWplY3QpO1xuICAgICAgICAgICAgICAgICAgcmVxLm9uYmxvY2tlZCA9IF90aGlzLl9maXJlT25CbG9ja2VkO1xuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBpZiAoaGFzSW52YWxpZEFyZ3VtZW50cylcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBleGNlcHRpb25zLkludmFsaWRBcmd1bWVudCgnSW52YWxpZCBjbG9zZU9wdGlvbnMgYXJndW1lbnQgdG8gZGIuZGVsZXRlKCknKTtcbiAgICAgICAgICAgICAgaWYgKHN0YXRlLmlzQmVpbmdPcGVuZWQpIHtcbiAgICAgICAgICAgICAgICAgIHN0YXRlLmRiUmVhZHlQcm9taXNlLnRoZW4oZG9EZWxldGUpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgZG9EZWxldGUoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgfTtcbiAgICAgIERleGllLnByb3RvdHlwZS5iYWNrZW5kREIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuaWRiZGI7XG4gICAgICB9O1xuICAgICAgRGV4aWUucHJvdG90eXBlLmlzT3BlbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5pZGJkYiAhPT0gbnVsbDtcbiAgICAgIH07XG4gICAgICBEZXhpZS5wcm90b3R5cGUuaGFzQmVlbkNsb3NlZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICB2YXIgZGJPcGVuRXJyb3IgPSB0aGlzLl9zdGF0ZS5kYk9wZW5FcnJvcjtcbiAgICAgICAgICByZXR1cm4gZGJPcGVuRXJyb3IgJiYgZGJPcGVuRXJyb3IubmFtZSA9PT0gJ0RhdGFiYXNlQ2xvc2VkJztcbiAgICAgIH07XG4gICAgICBEZXhpZS5wcm90b3R5cGUuaGFzRmFpbGVkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9zdGF0ZS5kYk9wZW5FcnJvciAhPT0gbnVsbDtcbiAgICAgIH07XG4gICAgICBEZXhpZS5wcm90b3R5cGUuZHluYW1pY2FsbHlPcGVuZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3N0YXRlLmF1dG9TY2hlbWE7XG4gICAgICB9O1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KERleGllLnByb3RvdHlwZSwgXCJ0YWJsZXNcIiwge1xuICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICByZXR1cm4ga2V5cyh0aGlzLl9hbGxUYWJsZXMpLm1hcChmdW5jdGlvbiAobmFtZSkgeyByZXR1cm4gX3RoaXMuX2FsbFRhYmxlc1tuYW1lXTsgfSk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgIH0pO1xuICAgICAgRGV4aWUucHJvdG90eXBlLnRyYW5zYWN0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBhcmdzID0gZXh0cmFjdFRyYW5zYWN0aW9uQXJncy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICAgIHJldHVybiB0aGlzLl90cmFuc2FjdGlvbi5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgIH07XG4gICAgICBEZXhpZS5wcm90b3R5cGUuX3RyYW5zYWN0aW9uID0gZnVuY3Rpb24gKG1vZGUsIHRhYmxlcywgc2NvcGVGdW5jKSB7XG4gICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICB2YXIgcGFyZW50VHJhbnNhY3Rpb24gPSBQU0QudHJhbnM7XG4gICAgICAgICAgaWYgKCFwYXJlbnRUcmFuc2FjdGlvbiB8fFxuICAgICAgICAgICAgICBwYXJlbnRUcmFuc2FjdGlvbi5kYiAhPT0gdGhpcyB8fFxuICAgICAgICAgICAgICBtb2RlLmluZGV4T2YoJyEnKSAhPT0gLTEpXG4gICAgICAgICAgICAgIHBhcmVudFRyYW5zYWN0aW9uID0gbnVsbDtcbiAgICAgICAgICB2YXIgb25seUlmQ29tcGF0aWJsZSA9IG1vZGUuaW5kZXhPZignPycpICE9PSAtMTtcbiAgICAgICAgICBtb2RlID0gbW9kZS5yZXBsYWNlKCchJywgJycpLnJlcGxhY2UoJz8nLCAnJyk7XG4gICAgICAgICAgdmFyIGlkYk1vZGUsIHN0b3JlTmFtZXM7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgc3RvcmVOYW1lcyA9IHRhYmxlcy5tYXAoZnVuY3Rpb24gKHRhYmxlKSB7XG4gICAgICAgICAgICAgICAgICB2YXIgc3RvcmVOYW1lID0gdGFibGUgaW5zdGFuY2VvZiBfdGhpcy5UYWJsZSA/IHRhYmxlLm5hbWUgOiB0YWJsZTtcbiAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygc3RvcmVOYW1lICE9PSAnc3RyaW5nJylcbiAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbnZhbGlkIHRhYmxlIGFyZ3VtZW50IHRvIERleGllLnRyYW5zYWN0aW9uKCkuIE9ubHkgVGFibGUgb3IgU3RyaW5nIGFyZSBhbGxvd2VkJyk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gc3RvcmVOYW1lO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgaWYgKG1vZGUgPT0gJ3InIHx8IG1vZGUgPT09IFJFQURPTkxZKVxuICAgICAgICAgICAgICAgICAgaWRiTW9kZSA9IFJFQURPTkxZO1xuICAgICAgICAgICAgICBlbHNlIGlmIChtb2RlID09ICdydycgfHwgbW9kZSA9PSBSRUFEV1JJVEUpXG4gICAgICAgICAgICAgICAgICBpZGJNb2RlID0gUkVBRFdSSVRFO1xuICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgZXhjZXB0aW9ucy5JbnZhbGlkQXJndW1lbnQoJ0ludmFsaWQgdHJhbnNhY3Rpb24gbW9kZTogJyArIG1vZGUpO1xuICAgICAgICAgICAgICBpZiAocGFyZW50VHJhbnNhY3Rpb24pIHtcbiAgICAgICAgICAgICAgICAgIGlmIChwYXJlbnRUcmFuc2FjdGlvbi5tb2RlID09PSBSRUFET05MWSAmJiBpZGJNb2RlID09PSBSRUFEV1JJVEUpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAob25seUlmQ29tcGF0aWJsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnRUcmFuc2FjdGlvbiA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuU3ViVHJhbnNhY3Rpb24oJ0Nhbm5vdCBlbnRlciBhIHN1Yi10cmFuc2FjdGlvbiB3aXRoIFJFQURXUklURSBtb2RlIHdoZW4gcGFyZW50IHRyYW5zYWN0aW9uIGlzIFJFQURPTkxZJyk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAocGFyZW50VHJhbnNhY3Rpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICBzdG9yZU5hbWVzLmZvckVhY2goZnVuY3Rpb24gKHN0b3JlTmFtZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocGFyZW50VHJhbnNhY3Rpb24gJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmVudFRyYW5zYWN0aW9uLnN0b3JlTmFtZXMuaW5kZXhPZihzdG9yZU5hbWUpID09PSAtMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9ubHlJZkNvbXBhdGlibGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnRUcmFuc2FjdGlvbiA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuU3ViVHJhbnNhY3Rpb24oJ1RhYmxlICcgKyBzdG9yZU5hbWUgKyAnIG5vdCBpbmNsdWRlZCBpbiBwYXJlbnQgdHJhbnNhY3Rpb24uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChvbmx5SWZDb21wYXRpYmxlICYmXG4gICAgICAgICAgICAgICAgICAgICAgcGFyZW50VHJhbnNhY3Rpb24gJiZcbiAgICAgICAgICAgICAgICAgICAgICAhcGFyZW50VHJhbnNhY3Rpb24uYWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcGFyZW50VHJhbnNhY3Rpb24gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIHJldHVybiBwYXJlbnRUcmFuc2FjdGlvblxuICAgICAgICAgICAgICAgICAgPyBwYXJlbnRUcmFuc2FjdGlvbi5fcHJvbWlzZShudWxsLCBmdW5jdGlvbiAoXywgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgIDogcmVqZWN0aW9uKGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgZW50ZXJUcmFuc2FjdGlvbiA9IGVudGVyVHJhbnNhY3Rpb25TY29wZS5iaW5kKG51bGwsIHRoaXMsIGlkYk1vZGUsIHN0b3JlTmFtZXMsIHBhcmVudFRyYW5zYWN0aW9uLCBzY29wZUZ1bmMpO1xuICAgICAgICAgIHJldHVybiBwYXJlbnRUcmFuc2FjdGlvblxuICAgICAgICAgICAgICA/IHBhcmVudFRyYW5zYWN0aW9uLl9wcm9taXNlKGlkYk1vZGUsIGVudGVyVHJhbnNhY3Rpb24sICdsb2NrJylcbiAgICAgICAgICAgICAgOiBQU0QudHJhbnNcbiAgICAgICAgICAgICAgICAgID9cbiAgICAgICAgICAgICAgICAgICAgICB1c2VQU0QoUFNELnRyYW5zbGVzcywgZnVuY3Rpb24gKCkgeyByZXR1cm4gX3RoaXMuX3doZW5SZWFkeShlbnRlclRyYW5zYWN0aW9uKTsgfSlcbiAgICAgICAgICAgICAgICAgIDogdGhpcy5fd2hlblJlYWR5KGVudGVyVHJhbnNhY3Rpb24pO1xuICAgICAgfTtcbiAgICAgIERleGllLnByb3RvdHlwZS50YWJsZSA9IGZ1bmN0aW9uICh0YWJsZU5hbWUpIHtcbiAgICAgICAgICBpZiAoIWhhc093bih0aGlzLl9hbGxUYWJsZXMsIHRhYmxlTmFtZSkpIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IGV4Y2VwdGlvbnMuSW52YWxpZFRhYmxlKFwiVGFibGUgXCIuY29uY2F0KHRhYmxlTmFtZSwgXCIgZG9lcyBub3QgZXhpc3RcIikpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdGhpcy5fYWxsVGFibGVzW3RhYmxlTmFtZV07XG4gICAgICB9O1xuICAgICAgcmV0dXJuIERleGllO1xuICB9KCkpO1xuXG4gIHZhciBzeW1ib2xPYnNlcnZhYmxlID0gdHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgJ29ic2VydmFibGUnIGluIFN5bWJvbFxuICAgICAgPyBTeW1ib2wub2JzZXJ2YWJsZVxuICAgICAgOiAnQEBvYnNlcnZhYmxlJztcbiAgdmFyIE9ic2VydmFibGUgPSAgKGZ1bmN0aW9uICgpIHtcbiAgICAgIGZ1bmN0aW9uIE9ic2VydmFibGUoc3Vic2NyaWJlKSB7XG4gICAgICAgICAgdGhpcy5fc3Vic2NyaWJlID0gc3Vic2NyaWJlO1xuICAgICAgfVxuICAgICAgT2JzZXJ2YWJsZS5wcm90b3R5cGUuc3Vic2NyaWJlID0gZnVuY3Rpb24gKHgsIGVycm9yLCBjb21wbGV0ZSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9zdWJzY3JpYmUoIXggfHwgdHlwZW9mIHggPT09ICdmdW5jdGlvbicgPyB7IG5leHQ6IHgsIGVycm9yOiBlcnJvciwgY29tcGxldGU6IGNvbXBsZXRlIH0gOiB4KTtcbiAgICAgIH07XG4gICAgICBPYnNlcnZhYmxlLnByb3RvdHlwZVtzeW1ib2xPYnNlcnZhYmxlXSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH07XG4gICAgICByZXR1cm4gT2JzZXJ2YWJsZTtcbiAgfSgpKTtcblxuICB2YXIgZG9tRGVwcztcbiAgdHJ5IHtcbiAgICAgIGRvbURlcHMgPSB7XG4gICAgICAgICAgaW5kZXhlZERCOiBfZ2xvYmFsLmluZGV4ZWREQiB8fFxuICAgICAgICAgICAgICBfZ2xvYmFsLm1vekluZGV4ZWREQiB8fFxuICAgICAgICAgICAgICBfZ2xvYmFsLndlYmtpdEluZGV4ZWREQiB8fFxuICAgICAgICAgICAgICBfZ2xvYmFsLm1zSW5kZXhlZERCLFxuICAgICAgICAgIElEQktleVJhbmdlOiBfZ2xvYmFsLklEQktleVJhbmdlIHx8IF9nbG9iYWwud2Via2l0SURCS2V5UmFuZ2UsXG4gICAgICB9O1xuICB9XG4gIGNhdGNoIChlKSB7XG4gICAgICBkb21EZXBzID0geyBpbmRleGVkREI6IG51bGwsIElEQktleVJhbmdlOiBudWxsIH07XG4gIH1cblxuICBmdW5jdGlvbiBsaXZlUXVlcnkocXVlcmllcikge1xuICAgICAgdmFyIGhhc1ZhbHVlID0gZmFsc2U7XG4gICAgICB2YXIgY3VycmVudFZhbHVlO1xuICAgICAgdmFyIG9ic2VydmFibGUgPSBuZXcgT2JzZXJ2YWJsZShmdW5jdGlvbiAob2JzZXJ2ZXIpIHtcbiAgICAgICAgICB2YXIgc2NvcGVGdW5jSXNBc3luYyA9IGlzQXN5bmNGdW5jdGlvbihxdWVyaWVyKTtcbiAgICAgICAgICBmdW5jdGlvbiBleGVjdXRlKGN0eCkge1xuICAgICAgICAgICAgICB2YXIgd2FzUm9vdEV4ZWMgPSBiZWdpbk1pY3JvVGlja1Njb3BlKCk7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICBpZiAoc2NvcGVGdW5jSXNBc3luYykge1xuICAgICAgICAgICAgICAgICAgICAgIGluY3JlbWVudEV4cGVjdGVkQXdhaXRzKCk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB2YXIgcnYgPSBuZXdTY29wZShxdWVyaWVyLCBjdHgpO1xuICAgICAgICAgICAgICAgICAgaWYgKHNjb3BlRnVuY0lzQXN5bmMpIHtcbiAgICAgICAgICAgICAgICAgICAgICBydiA9IHJ2LmZpbmFsbHkoZGVjcmVtZW50RXhwZWN0ZWRBd2FpdHMpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHJ2O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgd2FzUm9vdEV4ZWMgJiYgZW5kTWljcm9UaWNrU2NvcGUoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgY2xvc2VkID0gZmFsc2U7XG4gICAgICAgICAgdmFyIGFib3J0Q29udHJvbGxlcjtcbiAgICAgICAgICB2YXIgYWNjdW1NdXRzID0ge307XG4gICAgICAgICAgdmFyIGN1cnJlbnRPYnMgPSB7fTtcbiAgICAgICAgICB2YXIgc3Vic2NyaXB0aW9uID0ge1xuICAgICAgICAgICAgICBnZXQgY2xvc2VkKCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNsb3NlZDtcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdW5zdWJzY3JpYmU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChjbG9zZWQpXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgY2xvc2VkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgIGlmIChhYm9ydENvbnRyb2xsZXIpXG4gICAgICAgICAgICAgICAgICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XG4gICAgICAgICAgICAgICAgICBpZiAoc3RhcnRlZExpc3RlbmluZylcbiAgICAgICAgICAgICAgICAgICAgICBnbG9iYWxFdmVudHMuc3RvcmFnZW11dGF0ZWQudW5zdWJzY3JpYmUobXV0YXRpb25MaXN0ZW5lcik7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgfTtcbiAgICAgICAgICBvYnNlcnZlci5zdGFydCAmJiBvYnNlcnZlci5zdGFydChzdWJzY3JpcHRpb24pO1xuICAgICAgICAgIHZhciBzdGFydGVkTGlzdGVuaW5nID0gZmFsc2U7XG4gICAgICAgICAgdmFyIGRvUXVlcnkgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBleGVjSW5HbG9iYWxDb250ZXh0KF9kb1F1ZXJ5KTsgfTtcbiAgICAgICAgICBmdW5jdGlvbiBzaG91bGROb3RpZnkoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBvYnNTZXRzT3ZlcmxhcChjdXJyZW50T2JzLCBhY2N1bU11dHMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgbXV0YXRpb25MaXN0ZW5lciA9IGZ1bmN0aW9uIChwYXJ0cykge1xuICAgICAgICAgICAgICBleHRlbmRPYnNlcnZhYmlsaXR5U2V0KGFjY3VtTXV0cywgcGFydHMpO1xuICAgICAgICAgICAgICBpZiAoc2hvdWxkTm90aWZ5KCkpIHtcbiAgICAgICAgICAgICAgICAgIGRvUXVlcnkoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgICAgdmFyIF9kb1F1ZXJ5ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICBpZiAoY2xvc2VkIHx8XG4gICAgICAgICAgICAgICAgICAhZG9tRGVwcy5pbmRleGVkREIpXG4gICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgYWNjdW1NdXRzID0ge307XG4gICAgICAgICAgICAgIHZhciBzdWJzY3IgPSB7fTtcbiAgICAgICAgICAgICAgaWYgKGFib3J0Q29udHJvbGxlcilcbiAgICAgICAgICAgICAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgICAgICAgICBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICAgICAgICAgIHZhciBjdHggPSB7XG4gICAgICAgICAgICAgICAgICBzdWJzY3I6IHN1YnNjcixcbiAgICAgICAgICAgICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgICAgICAgICAgIHJlcXVlcnk6IGRvUXVlcnksXG4gICAgICAgICAgICAgICAgICBxdWVyaWVyOiBxdWVyaWVyLFxuICAgICAgICAgICAgICAgICAgdHJhbnM6IG51bGwsXG4gICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgIHZhciByZXQgPSBleGVjdXRlKGN0eCk7XG4gICAgICAgICAgICAgIGlmICghc3RhcnRlZExpc3RlbmluZykge1xuICAgICAgICAgICAgICAgICAgZ2xvYmFsRXZlbnRzLnN0b3JhZ2VtdXRhdGVkLnN1YnNjcmliZShtdXRhdGlvbkxpc3RlbmVyKTtcbiAgICAgICAgICAgICAgICAgIHN0YXJ0ZWRMaXN0ZW5pbmcgPSB0cnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIFByb21pc2UucmVzb2x2ZShyZXQpLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgaGFzVmFsdWUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgY3VycmVudFZhbHVlID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgICAgaWYgKGNsb3NlZCB8fCBjdHguc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoc2hvdWxkTm90aWZ5KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBkb1F1ZXJ5KCk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50T2JzID0gc3Vic2NyO1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChzaG91bGROb3RpZnkoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBkb1F1ZXJ5KCk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBhY2N1bU11dHMgPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXhlY0luR2xvYmFsQ29udGV4dChmdW5jdGlvbiAoKSB7IHJldHVybiAhY2xvc2VkICYmIG9ic2VydmVyLm5leHQgJiYgb2JzZXJ2ZXIubmV4dChyZXN1bHQpOyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgIGhhc1ZhbHVlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICBpZiAoIVsnRGF0YWJhc2VDbG9zZWRFcnJvcicsICdBYm9ydEVycm9yJ10uaW5jbHVkZXMoZXJyID09PSBudWxsIHx8IGVyciA9PT0gdm9pZCAwID8gdm9pZCAwIDogZXJyLm5hbWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKCFjbG9zZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4ZWNJbkdsb2JhbENvbnRleHQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNsb3NlZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYnNlcnZlci5lcnJvciAmJiBvYnNlcnZlci5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfTtcbiAgICAgICAgICBzZXRUaW1lb3V0KGRvUXVlcnksIDApO1xuICAgICAgICAgIHJldHVybiBzdWJzY3JpcHRpb247XG4gICAgICB9KTtcbiAgICAgIG9ic2VydmFibGUuaGFzVmFsdWUgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBoYXNWYWx1ZTsgfTtcbiAgICAgIG9ic2VydmFibGUuZ2V0VmFsdWUgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBjdXJyZW50VmFsdWU7IH07XG4gICAgICByZXR1cm4gb2JzZXJ2YWJsZTtcbiAgfVxuXG4gIHZhciBEZXhpZSA9IERleGllJDE7XG4gIHByb3BzKERleGllLCBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgZnVsbE5hbWVFeGNlcHRpb25zKSwge1xuICAgICAgZGVsZXRlOiBmdW5jdGlvbiAoZGF0YWJhc2VOYW1lKSB7XG4gICAgICAgICAgdmFyIGRiID0gbmV3IERleGllKGRhdGFiYXNlTmFtZSwgeyBhZGRvbnM6IFtdIH0pO1xuICAgICAgICAgIHJldHVybiBkYi5kZWxldGUoKTtcbiAgICAgIH0sXG4gICAgICBleGlzdHM6IGZ1bmN0aW9uIChuYW1lKSB7XG4gICAgICAgICAgcmV0dXJuIG5ldyBEZXhpZShuYW1lLCB7IGFkZG9uczogW10gfSlcbiAgICAgICAgICAgICAgLm9wZW4oKVxuICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoZGIpIHtcbiAgICAgICAgICAgICAgZGIuY2xvc2UoKTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLmNhdGNoKCdOb1N1Y2hEYXRhYmFzZUVycm9yJywgZnVuY3Rpb24gKCkgeyByZXR1cm4gZmFsc2U7IH0pO1xuICAgICAgfSxcbiAgICAgIGdldERhdGFiYXNlTmFtZXM6IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHJldHVybiBnZXREYXRhYmFzZU5hbWVzKERleGllLmRlcGVuZGVuY2llcykudGhlbihjYik7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhdGNoIChfYSkge1xuICAgICAgICAgICAgICByZXR1cm4gcmVqZWN0aW9uKG5ldyBleGNlcHRpb25zLk1pc3NpbmdBUEkoKSk7XG4gICAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIGRlZmluZUNsYXNzOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZnVuY3Rpb24gQ2xhc3MoY29udGVudCkge1xuICAgICAgICAgICAgICBleHRlbmQodGhpcywgY29udGVudCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBDbGFzcztcbiAgICAgIH0sIGlnbm9yZVRyYW5zYWN0aW9uOiBmdW5jdGlvbiAoc2NvcGVGdW5jKSB7XG4gICAgICAgICAgcmV0dXJuIFBTRC50cmFuc1xuICAgICAgICAgICAgICA/IHVzZVBTRChQU0QudHJhbnNsZXNzIHx8IGdsb2JhbFBTRCwgc2NvcGVGdW5jKVxuICAgICAgICAgICAgICA6IHNjb3BlRnVuYygpO1xuICAgICAgfSwgdmlwOiB2aXAsIGFzeW5jOiBmdW5jdGlvbiAoZ2VuZXJhdG9yRm4pIHtcbiAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgdmFyIHJ2ID0gYXdhaXRJdGVyYXRvcihnZW5lcmF0b3JGbi5hcHBseSh0aGlzLCBhcmd1bWVudHMpKTtcbiAgICAgICAgICAgICAgICAgIGlmICghcnYgfHwgdHlwZW9mIHJ2LnRoZW4gIT09ICdmdW5jdGlvbicpXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIERleGllUHJvbWlzZS5yZXNvbHZlKHJ2KTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBydjtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdGlvbihlKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICB9LCBzcGF3bjogZnVuY3Rpb24gKGdlbmVyYXRvckZuLCBhcmdzLCB0aGl6KSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdmFyIHJ2ID0gYXdhaXRJdGVyYXRvcihnZW5lcmF0b3JGbi5hcHBseSh0aGl6LCBhcmdzIHx8IFtdKSk7XG4gICAgICAgICAgICAgIGlmICghcnYgfHwgdHlwZW9mIHJ2LnRoZW4gIT09ICdmdW5jdGlvbicpXG4gICAgICAgICAgICAgICAgICByZXR1cm4gRGV4aWVQcm9taXNlLnJlc29sdmUocnYpO1xuICAgICAgICAgICAgICByZXR1cm4gcnY7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZWplY3Rpb24oZSk7XG4gICAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIGN1cnJlbnRUcmFuc2FjdGlvbjoge1xuICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gUFNELnRyYW5zIHx8IG51bGw7IH0sXG4gICAgICB9LCB3YWl0Rm9yOiBmdW5jdGlvbiAocHJvbWlzZU9yRnVuY3Rpb24sIG9wdGlvbmFsVGltZW91dCkge1xuICAgICAgICAgIHZhciBwcm9taXNlID0gRGV4aWVQcm9taXNlLnJlc29sdmUodHlwZW9mIHByb21pc2VPckZ1bmN0aW9uID09PSAnZnVuY3Rpb24nXG4gICAgICAgICAgICAgID8gRGV4aWUuaWdub3JlVHJhbnNhY3Rpb24ocHJvbWlzZU9yRnVuY3Rpb24pXG4gICAgICAgICAgICAgIDogcHJvbWlzZU9yRnVuY3Rpb24pLnRpbWVvdXQob3B0aW9uYWxUaW1lb3V0IHx8IDYwMDAwKTtcbiAgICAgICAgICByZXR1cm4gUFNELnRyYW5zID8gUFNELnRyYW5zLndhaXRGb3IocHJvbWlzZSkgOiBwcm9taXNlO1xuICAgICAgfSxcbiAgICAgIFByb21pc2U6IERleGllUHJvbWlzZSxcbiAgICAgIGRlYnVnOiB7XG4gICAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBkZWJ1ZzsgfSxcbiAgICAgICAgICBzZXQ6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICBzZXREZWJ1Zyh2YWx1ZSk7XG4gICAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBkZXJpdmU6IGRlcml2ZSwgZXh0ZW5kOiBleHRlbmQsIHByb3BzOiBwcm9wcywgb3ZlcnJpZGU6IG92ZXJyaWRlLFxuICAgICAgRXZlbnRzOiBFdmVudHMsIG9uOiBnbG9iYWxFdmVudHMsIGxpdmVRdWVyeTogbGl2ZVF1ZXJ5LCBleHRlbmRPYnNlcnZhYmlsaXR5U2V0OiBleHRlbmRPYnNlcnZhYmlsaXR5U2V0LFxuICAgICAgZ2V0QnlLZXlQYXRoOiBnZXRCeUtleVBhdGgsIHNldEJ5S2V5UGF0aDogc2V0QnlLZXlQYXRoLCBkZWxCeUtleVBhdGg6IGRlbEJ5S2V5UGF0aCwgc2hhbGxvd0Nsb25lOiBzaGFsbG93Q2xvbmUsIGRlZXBDbG9uZTogZGVlcENsb25lLCBnZXRPYmplY3REaWZmOiBnZXRPYmplY3REaWZmLCBjbXA6IGNtcCwgYXNhcDogYXNhcCQxLFxuICAgICAgbWluS2V5OiBtaW5LZXksXG4gICAgICBhZGRvbnM6IFtdLFxuICAgICAgY29ubmVjdGlvbnM6IHtcbiAgICAgICAgICBnZXQ6IGNvbm5lY3Rpb25zLnRvQXJyYXksXG4gICAgICB9LFxuICAgICAgZXJybmFtZXM6IGVycm5hbWVzLFxuICAgICAgZGVwZW5kZW5jaWVzOiBkb21EZXBzLCBjYWNoZTogY2FjaGUsXG4gICAgICBzZW1WZXI6IERFWElFX1ZFUlNJT04sIHZlcnNpb246IERFWElFX1ZFUlNJT04uc3BsaXQoJy4nKVxuICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKG4pIHsgcmV0dXJuIHBhcnNlSW50KG4pOyB9KVxuICAgICAgICAgIC5yZWR1Y2UoZnVuY3Rpb24gKHAsIGMsIGkpIHsgcmV0dXJuIHAgKyBjIC8gTWF0aC5wb3coMTAsIGkgKiAyKTsgfSkgfSkpO1xuICBEZXhpZS5tYXhLZXkgPSBnZXRNYXhLZXkoRGV4aWUuZGVwZW5kZW5jaWVzLklEQktleVJhbmdlKTtcblxuICBpZiAodHlwZW9mIGRpc3BhdGNoRXZlbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgICB0eXBlb2YgYWRkRXZlbnRMaXN0ZW5lciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIGdsb2JhbEV2ZW50cyhERVhJRV9TVE9SQUdFX01VVEFURURfRVZFTlRfTkFNRSwgZnVuY3Rpb24gKHVwZGF0ZWRQYXJ0cykge1xuICAgICAgICAgIGlmICghcHJvcGFnYXRpbmdMb2NhbGx5KSB7XG4gICAgICAgICAgICAgIHZhciBldmVudF8xO1xuICAgICAgICAgICAgICBldmVudF8xID0gbmV3IEN1c3RvbUV2ZW50KFNUT1JBR0VfTVVUQVRFRF9ET01fRVZFTlRfTkFNRSwge1xuICAgICAgICAgICAgICAgICAgZGV0YWlsOiB1cGRhdGVkUGFydHMsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBwcm9wYWdhdGluZ0xvY2FsbHkgPSB0cnVlO1xuICAgICAgICAgICAgICBkaXNwYXRjaEV2ZW50KGV2ZW50XzEpO1xuICAgICAgICAgICAgICBwcm9wYWdhdGluZ0xvY2FsbHkgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGFkZEV2ZW50TGlzdGVuZXIoU1RPUkFHRV9NVVRBVEVEX0RPTV9FVkVOVF9OQU1FLCBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICB2YXIgZGV0YWlsID0gX2EuZGV0YWlsO1xuICAgICAgICAgIGlmICghcHJvcGFnYXRpbmdMb2NhbGx5KSB7XG4gICAgICAgICAgICAgIHByb3BhZ2F0ZUxvY2FsbHkoZGV0YWlsKTtcbiAgICAgICAgICB9XG4gICAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBwcm9wYWdhdGVMb2NhbGx5KHVwZGF0ZVBhcnRzKSB7XG4gICAgICB2YXIgd2FzTWUgPSBwcm9wYWdhdGluZ0xvY2FsbHk7XG4gICAgICB0cnkge1xuICAgICAgICAgIHByb3BhZ2F0aW5nTG9jYWxseSA9IHRydWU7XG4gICAgICAgICAgZ2xvYmFsRXZlbnRzLnN0b3JhZ2VtdXRhdGVkLmZpcmUodXBkYXRlUGFydHMpO1xuICAgICAgICAgIHNpZ25hbFN1YnNjcmliZXJzTm93KHVwZGF0ZVBhcnRzLCB0cnVlKTtcbiAgICAgIH1cbiAgICAgIGZpbmFsbHkge1xuICAgICAgICAgIHByb3BhZ2F0aW5nTG9jYWxseSA9IHdhc01lO1xuICAgICAgfVxuICB9XG4gIHZhciBwcm9wYWdhdGluZ0xvY2FsbHkgPSBmYWxzZTtcblxuICB2YXIgYmM7XG4gIHZhciBjcmVhdGVCQyA9IGZ1bmN0aW9uICgpIHsgfTtcbiAgaWYgKHR5cGVvZiBCcm9hZGNhc3RDaGFubmVsICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgY3JlYXRlQkMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgYmMgPSBuZXcgQnJvYWRjYXN0Q2hhbm5lbChTVE9SQUdFX01VVEFURURfRE9NX0VWRU5UX05BTUUpO1xuICAgICAgICAgIGJjLm9ubWVzc2FnZSA9IGZ1bmN0aW9uIChldikgeyByZXR1cm4gZXYuZGF0YSAmJiBwcm9wYWdhdGVMb2NhbGx5KGV2LmRhdGEpOyB9O1xuICAgICAgfTtcbiAgICAgIGNyZWF0ZUJDKCk7XG4gICAgICBpZiAodHlwZW9mIGJjLnVucmVmID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgYmMudW5yZWYoKTtcbiAgICAgIH1cbiAgICAgIGdsb2JhbEV2ZW50cyhERVhJRV9TVE9SQUdFX01VVEFURURfRVZFTlRfTkFNRSwgZnVuY3Rpb24gKGNoYW5nZWRQYXJ0cykge1xuICAgICAgICAgIGlmICghcHJvcGFnYXRpbmdMb2NhbGx5KSB7XG4gICAgICAgICAgICAgIGJjLnBvc3RNZXNzYWdlKGNoYW5nZWRQYXJ0cyk7XG4gICAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICBpZiAodHlwZW9mIGFkZEV2ZW50TGlzdGVuZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBhZGRFdmVudExpc3RlbmVyKCdwYWdlaGlkZScsIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgIGlmICghRGV4aWUkMS5kaXNhYmxlQmZDYWNoZSAmJiBldmVudC5wZXJzaXN0ZWQpIHtcbiAgICAgICAgICAgICAgaWYgKGRlYnVnKVxuICAgICAgICAgICAgICAgICAgY29uc29sZS5kZWJ1ZygnRGV4aWU6IGhhbmRsaW5nIHBlcnNpc3RlZCBwYWdlaGlkZScpO1xuICAgICAgICAgICAgICBiYyA9PT0gbnVsbCB8fCBiYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogYmMuY2xvc2UoKTtcbiAgICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IGNvbm5lY3Rpb25zLnRvQXJyYXkoKTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICAgIHZhciBkYiA9IF9hW19pXTtcbiAgICAgICAgICAgICAgICAgIGRiLmNsb3NlKHsgZGlzYWJsZUF1dG9PcGVuOiBmYWxzZSB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgYWRkRXZlbnRMaXN0ZW5lcigncGFnZXNob3cnLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICBpZiAoIURleGllJDEuZGlzYWJsZUJmQ2FjaGUgJiYgZXZlbnQucGVyc2lzdGVkKSB7XG4gICAgICAgICAgICAgIGlmIChkZWJ1ZylcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZGVidWcoJ0RleGllOiBoYW5kbGluZyBwZXJzaXN0ZWQgcGFnZXNob3cnKTtcbiAgICAgICAgICAgICAgY3JlYXRlQkMoKTtcbiAgICAgICAgICAgICAgcHJvcGFnYXRlTG9jYWxseSh7IGFsbDogbmV3IFJhbmdlU2V0KC1JbmZpbml0eSwgW1tdXSkgfSk7XG4gICAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBhZGQodmFsdWUpIHtcbiAgICAgIHJldHVybiBuZXcgUHJvcE1vZGlmaWNhdGlvbih7IGFkZDogdmFsdWUgfSk7XG4gIH1cblxuICBmdW5jdGlvbiByZW1vdmUodmFsdWUpIHtcbiAgICAgIHJldHVybiBuZXcgUHJvcE1vZGlmaWNhdGlvbih7IHJlbW92ZTogdmFsdWUgfSk7XG4gIH1cblxuICBmdW5jdGlvbiByZXBsYWNlUHJlZml4KGEsIGIpIHtcbiAgICAgIHJldHVybiBuZXcgUHJvcE1vZGlmaWNhdGlvbih7IHJlcGxhY2VQcmVmaXg6IFthLCBiXSB9KTtcbiAgfVxuXG4gIERleGllUHJvbWlzZS5yZWplY3Rpb25NYXBwZXIgPSBtYXBFcnJvcjtcbiAgc2V0RGVidWcoZGVidWcpO1xuXG4gIHZhciBuYW1lZEV4cG9ydHMgPSAvKiNfX1BVUkVfXyovT2JqZWN0LmZyZWV6ZSh7XG4gICAgX19wcm90b19fOiBudWxsLFxuICAgIERFRkFVTFRfTUFYX0NPTk5FQ1RJT05TOiBERUZBVUxUX01BWF9DT05ORUNUSU9OUyxcbiAgICBEZXhpZTogRGV4aWUkMSxcbiAgICBFbnRpdHk6IEVudGl0eSxcbiAgICBQcm9wTW9kaWZpY2F0aW9uOiBQcm9wTW9kaWZpY2F0aW9uLFxuICAgIFJhbmdlU2V0OiBSYW5nZVNldCxcbiAgICBhZGQ6IGFkZCxcbiAgICBjbXA6IGNtcCxcbiAgICBkZWZhdWx0OiBEZXhpZSQxLFxuICAgIGxpdmVRdWVyeTogbGl2ZVF1ZXJ5LFxuICAgIG1lcmdlUmFuZ2VzOiBtZXJnZVJhbmdlcyxcbiAgICByYW5nZXNPdmVybGFwOiByYW5nZXNPdmVybGFwLFxuICAgIHJlbW92ZTogcmVtb3ZlLFxuICAgIHJlcGxhY2VQcmVmaXg6IHJlcGxhY2VQcmVmaXhcbiAgfSk7XG5cbiAgX19hc3NpZ24oRGV4aWUkMSwgbmFtZWRFeHBvcnRzLCB7IGRlZmF1bHQ6IERleGllJDEgfSk7XG5cbiAgcmV0dXJuIERleGllJDE7XG5cbn0pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRleGllLmpzLm1hcFxuIiwiLy8gTWFraW5nIHRoZSBtb2R1bGUgdmVyc2lvbiBjb25zdW1hYmxlIHZpYSByZXF1aXJlIC0gdG8gcHJvaGliaXRcbi8vIG11bHRpcGxlIG9jY3VycmFuY2llcyBvZiB0aGUgc2FtZSBtb2R1bGUgaW4gdGhlIHNhbWUgYXBwXG4vLyAoZHVhbCBwYWNrYWdlIGhhemFyZCwgaHR0cHM6Ly9ub2RlanMub3JnL2FwaS9wYWNrYWdlcy5odG1sI2R1YWwtcGFja2FnZS1oYXphcmQpXG5pbXBvcnQgX0RleGllIGZyb20gXCIuL2Rpc3QvZGV4aWUuanNcIjtcbmNvbnN0IERleGllU3ltYm9sID0gU3ltYm9sLmZvcihcIkRleGllXCIpO1xuY29uc3QgRGV4aWUgPSBnbG9iYWxUaGlzW0RleGllU3ltYm9sXSB8fCAoZ2xvYmFsVGhpc1tEZXhpZVN5bWJvbF0gPSBfRGV4aWUpO1xuaWYgKF9EZXhpZS5zZW1WZXIgIT09IERleGllLnNlbVZlcikge1xuICAgIHRocm93IG5ldyBFcnJvcihgVHdvIGRpZmZlcmVudCB2ZXJzaW9ucyBvZiBEZXhpZSBsb2FkZWQgaW4gdGhlIHNhbWUgYXBwOiAke19EZXhpZS5zZW1WZXJ9IGFuZCAke0RleGllLnNlbVZlcn1gKTtcbn1cbmNvbnN0IHsgbGl2ZVF1ZXJ5LCBtZXJnZVJhbmdlcywgcmFuZ2VzT3ZlcmxhcCwgUmFuZ2VTZXQsIGNtcCwgRW50aXR5LFxuICAgIFByb3BNb2RpZmljYXRpb24sIHJlcGxhY2VQcmVmaXgsIGFkZCwgcmVtb3ZlLFxuICAgIERleGllWVByb3ZpZGVyIH0gPSBEZXhpZTtcbmV4cG9ydCB7IGxpdmVRdWVyeSwgbWVyZ2VSYW5nZXMsIHJhbmdlc092ZXJsYXAsIFJhbmdlU2V0LCBjbXAsIERleGllLCBFbnRpdHksXG4gICAgUHJvcE1vZGlmaWNhdGlvbiwgcmVwbGFjZVByZWZpeCwgYWRkLCByZW1vdmUsXG4gICAgRGV4aWVZUHJvdmlkZXJ9O1xuICAgIFxuZXhwb3J0IGRlZmF1bHQgRGV4aWU7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Q0FhQSxDQUFDLFNBQVUsUUFBUSxTQUFTO0VBQzFCLE9BQU8sWUFBWSxZQUFZLE9BQU8sV0FBVyxjQUFjLE9BQU8sVUFBVSxRQUFRLElBQ3hGLE9BQU8sV0FBVyxjQUFjLE9BQU8sTUFBTSxPQUFPLE9BQU8sS0FDMUQsU0FBUyxPQUFPLGVBQWUsY0FBYyxhQUFhLFVBQVUsTUFBTSxPQUFPLFFBQVEsUUFBUTtDQUNwRyxFQUFBLENBQUMsVUFBUyxXQUFZO0VBQUU7RUFFdEIsSUFBSSxnQkFBZ0IsU0FBUyxHQUFHLEdBQUc7R0FDakMsZ0JBQWdCLE9BQU8sa0JBQ2xCLEVBQUUsV0FBVyxDQUFDLEVBQUUsYUFBYSxTQUFTLFNBQVUsR0FBRyxHQUFHO0lBQUUsRUFBRSxZQUFZO0dBQUcsS0FDMUUsU0FBVSxHQUFHLEdBQUc7SUFBRSxLQUFLLElBQUksS0FBSyxHQUFHLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRTtHQUFJO0dBQ3BHLE9BQU8sY0FBYyxHQUFHLENBQUM7RUFDM0I7RUFDQSxTQUFTLFVBQVUsR0FBRyxHQUFHO0dBQ3ZCLElBQUksT0FBTyxNQUFNLGNBQWMsTUFBTSxNQUNqQyxNQUFNLElBQUksVUFBVSx5QkFBeUIsT0FBTyxDQUFDLElBQUksK0JBQStCO0dBQzVGLGNBQWMsR0FBRyxDQUFDO0dBQ2xCLFNBQVMsS0FBSztJQUFFLEtBQUssY0FBYztHQUFHO0dBQ3RDLEVBQUUsWUFBWSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUMsS0FBSyxHQUFHLFlBQVksRUFBRSxXQUFXLElBQUksR0FBRztFQUNwRjtFQUNBLElBQUksV0FBVyxXQUFXO0dBQ3hCLFdBQVcsT0FBTyxVQUFVLFNBQVMsU0FBUyxHQUFHO0lBQzdDLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxJQUFJLEdBQUcsS0FBSztLQUNqRCxJQUFJLFVBQVU7S0FDZCxLQUFLLElBQUksS0FBSyxHQUFHLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRTtJQUM5RTtJQUNBLE9BQU87R0FDWDtHQUNBLE9BQU8sU0FBUyxNQUFNLE1BQU0sU0FBUztFQUN2QztFQUNBLFNBQVMsY0FBYyxJQUFJLE1BQU0sTUFBTTtHQUNyQyxJQUFJLFFBQVEsVUFBVSxXQUFXLEdBQVE7U0FBQSxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLElBQUksR0FBRyxLQUM1RSxJQUFJLE1BQU0sRUFBRSxLQUFLLE9BQU87S0FDcEIsSUFBSSxDQUFDLElBQUksS0FBSyxNQUFNLFVBQVUsTUFBTSxLQUFLLE1BQU0sR0FBRyxDQUFDO0tBQ25ELEdBQUcsS0FBSyxLQUFLO0lBQ2pCOztHQUVKLE9BQU8sR0FBRyxPQUFPLE1BQU0sTUFBTSxVQUFVLE1BQU0sS0FBSyxJQUFJLENBQUM7RUFDekQ7RUFNQSxJQUFJLFVBQVUsT0FBTyxlQUFlLGNBQzlCLGFBQ0EsT0FBTyxTQUFTLGNBQ1osT0FDQSxPQUFPLFdBQVcsY0FDZCxTQUNBO0VBRWQsSUFBSSxPQUFPLE9BQU87RUFDbEIsSUFBSSxVQUFVLE1BQU07RUFDcEIsSUFBSSxPQUFPLFlBQVksZUFBZSxDQUFDLFFBQVEsU0FDM0MsUUFBUSxVQUFVO0VBRXRCLFNBQVMsT0FBTyxLQUFLLFdBQVc7R0FDNUIsSUFBSSxPQUFPLGNBQWMsVUFDckIsT0FBTztHQUNYLEtBQUssU0FBUyxDQUFDLENBQUMsUUFBUSxTQUFVLEtBQUs7SUFDbkMsSUFBSSxPQUFPLFVBQVU7R0FDekIsQ0FBQztHQUNELE9BQU87RUFDWDtFQUNBLElBQUksV0FBVyxPQUFPO0VBQ3RCLElBQUksVUFBVSxDQUFDLEVBQUU7RUFDakIsU0FBUyxPQUFPLEtBQUssTUFBTTtHQUN2QixPQUFPLFFBQVEsS0FBSyxLQUFLLElBQUk7RUFDakM7RUFDQSxTQUFTLE1BQU0sT0FBTyxXQUFXO0dBQzdCLElBQUksT0FBTyxjQUFjLFlBQ3JCLFlBQVksVUFBVSxTQUFTLEtBQUssQ0FBQztHQUN6QyxDQUFDLE9BQU8sWUFBWSxjQUFjLE9BQU8sUUFBUSxRQUFBLENBQVMsU0FBUyxDQUFDLENBQUMsUUFBUSxTQUFVLEtBQUs7SUFDeEYsUUFBUSxPQUFPLEtBQUssVUFBVSxJQUFJO0dBQ3RDLENBQUM7RUFDTDtFQUNBLElBQUksaUJBQWlCLE9BQU87RUFDNUIsU0FBUyxRQUFRLEtBQUssTUFBTSxrQkFBa0IsU0FBUztHQUNuRCxlQUFlLEtBQUssTUFBTSxPQUFPLG9CQUM3QixPQUFPLGtCQUFrQixLQUFLLEtBQzlCLE9BQU8saUJBQWlCLFFBQVEsYUFDOUI7SUFDRSxLQUFLLGlCQUFpQjtJQUN0QixLQUFLLGlCQUFpQjtJQUN0QixjQUFjO0dBQ2xCLElBQ0U7SUFBRSxPQUFPO0lBQWtCLGNBQWM7SUFBTSxVQUFVO0dBQUssR0FBRyxPQUFPLENBQUM7RUFDbkY7RUFDQSxTQUFTLE9BQU8sT0FBTztHQUNuQixPQUFPLEVBQ0gsTUFBTSxTQUFVLFFBQVE7SUFDcEIsTUFBTSxZQUFZLE9BQU8sT0FBTyxPQUFPLFNBQVM7SUFDaEQsUUFBUSxNQUFNLFdBQVcsZUFBZSxLQUFLO0lBQzdDLE9BQU8sRUFDSCxRQUFRLE1BQU0sS0FBSyxNQUFNLE1BQU0sU0FBUyxFQUM1QztHQUNKLEVBQ0o7RUFDSjtFQUNBLElBQUksMkJBQTJCLE9BQU87RUFDdEMsU0FBUyxzQkFBc0IsS0FBSyxNQUFNO0dBQ3RDLElBQUksS0FBSyx5QkFBeUIsS0FBSyxJQUFJO0dBQzNDLElBQUk7R0FDSixPQUFPLE9BQVEsUUFBUSxTQUFTLEdBQUcsTUFBTSxzQkFBc0IsT0FBTyxJQUFJO0VBQzlFO0VBQ0EsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDO0VBQ2hCLFNBQVMsTUFBTSxNQUFNLE9BQU8sS0FBSztHQUM3QixPQUFPLE9BQU8sS0FBSyxNQUFNLE9BQU8sR0FBRztFQUN2QztFQUNBLFNBQVMsU0FBUyxVQUFVLGtCQUFrQjtHQUMxQyxPQUFPLGlCQUFpQixRQUFRO0VBQ3BDO0VBQ0EsU0FBUyxPQUFPLEdBQUc7R0FDZixJQUFJLENBQUMsR0FDRCxNQUFNLElBQUksTUFBTSxrQkFBa0I7RUFDMUM7RUFDQSxTQUFTLE9BQU8sSUFBSTtHQUNoQixJQUFJLFFBQVEsY0FDUixhQUFhLEVBQUU7UUFFZixXQUFXLElBQUksQ0FBQztFQUN4QjtFQUNBLFNBQVMsY0FBYyxPQUFPLFdBQVc7R0FDckMsT0FBTyxNQUFNLE9BQU8sU0FBVSxRQUFRLE1BQU0sR0FBRztJQUMzQyxJQUFJLGVBQWUsVUFBVSxNQUFNLENBQUM7SUFDcEMsSUFBSSxjQUNBLE9BQU8sYUFBYSxNQUFNLGFBQWE7SUFDM0MsT0FBTztHQUNYLEdBQUcsQ0FBQyxDQUFDO0VBQ1Q7RUFDQSxTQUFTLGFBQWEsS0FBSyxTQUFTO0dBQ2hDLElBQUksT0FBTyxZQUFZLFlBQVksT0FBTyxLQUFLLE9BQU8sR0FDbEQsT0FBTyxJQUFJO0dBQ2YsSUFBSSxDQUFDLFNBQ0QsT0FBTztHQUNYLElBQUksT0FBTyxZQUFZLFVBQVU7SUFDN0IsSUFBSSxLQUFLLENBQUM7SUFDVixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLElBQUksR0FBRyxFQUFFLEdBQUc7S0FDNUMsSUFBSSxNQUFNLGFBQWEsS0FBSyxRQUFRLEVBQUU7S0FDdEMsR0FBRyxLQUFLLEdBQUc7SUFDZjtJQUNBLE9BQU87R0FDWDtHQUNBLElBQUksU0FBUyxRQUFRLFFBQVEsR0FBRztHQUNoQyxJQUFJLFdBQVcsSUFBSTtJQUNmLElBQUksV0FBVyxJQUFJLFFBQVEsT0FBTyxHQUFHLE1BQU07SUFDM0MsT0FBTyxZQUFZLE9BQ2IsS0FBQSxJQUNBLGFBQWEsVUFBVSxRQUFRLE9BQU8sU0FBUyxDQUFDLENBQUM7R0FDM0Q7RUFFSjtFQUNBLFNBQVMsYUFBYSxLQUFLLFNBQVMsT0FBTztHQUN2QyxJQUFJLENBQUMsT0FBTyxZQUFZLEtBQUEsR0FDcEI7R0FDSixJQUFJLGNBQWMsVUFBVSxPQUFPLFNBQVMsR0FBRyxHQUMzQztHQUNKLElBQUksT0FBTyxZQUFZLFlBQVksWUFBWSxTQUFTO0lBQ3BELE9BQU8sT0FBTyxVQUFVLFlBQVksWUFBWSxLQUFLO0lBQ3JELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsSUFBSSxHQUFHLEVBQUUsR0FDekMsYUFBYSxLQUFLLFFBQVEsSUFBSSxNQUFNLEVBQUU7R0FFOUMsT0FDSztJQUNELElBQUksU0FBUyxRQUFRLFFBQVEsR0FBRztJQUNoQyxJQUFJLFdBQVcsSUFBSTtLQUNmLElBQUksaUJBQWlCLFFBQVEsT0FBTyxHQUFHLE1BQU07S0FDN0MsSUFBSSxtQkFBbUIsUUFBUSxPQUFPLFNBQVMsQ0FBQztLQUNoRCxJQUFJLHFCQUFxQixJQUNyQixJQUFJLFVBQVUsS0FBQSxHQUFXO01BQ3JCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLFNBQVMsY0FBYyxDQUFDLEdBQy9DLElBQUksT0FBTyxnQkFBZ0IsQ0FBQztXQUU1QixPQUFPLElBQUk7S0FDbkIsT0FFSSxJQUFJLGtCQUFrQjtVQUN6QjtNQUNELElBQUksV0FBVyxJQUFJO01BQ25CLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxLQUFLLGNBQWMsR0FBRztPQUMzQyxJQUFJLFVBQVUsS0FBQSxHQUNWO09BQ0osV0FBVyxJQUFJLGtCQUFrQixDQUFDO01BQ3RDO01BQ0EsYUFBYSxVQUFVLGtCQUFrQixLQUFLO0tBQ2xEO0lBQ0osT0FFSSxJQUFJLFVBQVUsS0FBQSxHQUFXO0tBQ3JCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLFNBQVMsT0FBTyxDQUFDLEdBQ3hDLElBQUksT0FBTyxTQUFTLENBQUM7VUFFckIsT0FBTyxJQUFJO0lBQ25CLE9BRUksSUFBSSxXQUFXO0dBRTNCO0VBQ0o7RUFDQSxTQUFTLGFBQWEsS0FBSyxTQUFTO0dBQ2hDLElBQUksT0FBTyxZQUFZLFVBQ25CLGFBQWEsS0FBSyxTQUFTLEtBQUEsQ0FBUztRQUNuQyxJQUFJLFlBQVksU0FDakIsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLFNBQVMsU0FBVSxJQUFJO0lBQy9CLGFBQWEsS0FBSyxJQUFJLEtBQUEsQ0FBUztHQUNuQyxDQUFDO0VBQ1Q7RUFDQSxTQUFTLGFBQWEsS0FBSztHQUN2QixJQUFJLEtBQUssQ0FBQztHQUNWLEtBQUssSUFBSSxLQUFLLEtBQ1YsSUFBSSxPQUFPLEtBQUssQ0FBQyxHQUNiLEdBQUcsS0FBSyxJQUFJO0dBRXBCLE9BQU87RUFDWDtFQUNBLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQztFQUNoQixTQUFTLFFBQVEsR0FBRztHQUNoQixPQUFPLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQztFQUM3QjtFQUNBLElBQUkscUJBQXFCLGlOQUNwQixNQUFNLEdBQUcsQ0FBQyxDQUNWLE9BQU8sUUFBUTtHQUFDO0dBQUc7R0FBSTtHQUFJO0VBQUUsQ0FBQyxDQUFDLElBQUksU0FBVSxLQUFLO0dBQ25ELE9BQU87SUFBQztJQUFPO0lBQVE7R0FBTyxDQUFDLENBQUMsSUFBSSxTQUFVLEdBQUc7SUFBRSxPQUFPLElBQUksTUFBTTtHQUFTLENBQUM7RUFDbEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUNDLE9BQU8sU0FBVSxHQUFHO0dBQUUsT0FBTyxRQUFRO0VBQUksQ0FBQztFQUMvQyxJQUFJLGlCQUFpQixJQUFJLElBQUksbUJBQW1CLElBQUksU0FBVSxHQUFHO0dBQUUsT0FBTyxRQUFRO0VBQUksQ0FBQyxDQUFDO0VBQ3hGLFNBQVMsc0JBQXNCLEdBQUc7R0FDOUIsSUFBSSxLQUFLLENBQUM7R0FDVixLQUFLLElBQUksS0FBSyxHQUNWLElBQUksT0FBTyxHQUFHLENBQUMsR0FBRztJQUNkLElBQUksSUFBSSxFQUFFO0lBQ1YsR0FBRyxLQUNDLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxlQUFlLElBQUksRUFBRSxXQUFXLElBQ3pELElBQ0Esc0JBQXNCLENBQUM7R0FDckM7R0FDSixPQUFPO0VBQ1g7RUFDQSxJQUFJLGVBQWU7RUFDbkIsU0FBUyxVQUFVLEtBQUs7R0FDcEIsK0JBQWUsSUFBSSxRQUFRO0dBQzNCLElBQUksS0FBSyxlQUFlLEdBQUc7R0FDM0IsZUFBZTtHQUNmLE9BQU87RUFDWDtFQUNBLFNBQVMsZUFBZSxHQUFHO0dBQ3ZCLElBQUksQ0FBQyxLQUFLLE9BQU8sTUFBTSxVQUNuQixPQUFPO0dBQ1gsSUFBSSxLQUFLLGFBQWEsSUFBSSxDQUFDO0dBQzNCLElBQUksSUFDQSxPQUFPO0dBQ1gsSUFBSSxRQUFRLENBQUMsR0FBRztJQUNaLEtBQUssQ0FBQztJQUNOLGFBQWEsSUFBSSxHQUFHLEVBQUU7SUFDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsRUFBRSxHQUNuQyxHQUFHLEtBQUssZUFBZSxFQUFFLEVBQUUsQ0FBQztHQUVwQyxPQUNLLElBQUksZUFBZSxJQUFJLEVBQUUsV0FBVyxHQUNyQyxLQUFLO1FBRUo7SUFDRCxJQUFJLFFBQVEsU0FBUyxDQUFDO0lBQ3RCLEtBQUssVUFBVSxPQUFPLFlBQVksQ0FBQyxJQUFJLE9BQU8sT0FBTyxLQUFLO0lBQzFELGFBQWEsSUFBSSxHQUFHLEVBQUU7SUFDdEIsS0FBSyxJQUFJLFFBQVEsR0FDYixJQUFJLE9BQU8sR0FBRyxJQUFJLEdBQ2QsR0FBRyxRQUFRLGVBQWUsRUFBRSxLQUFLO0dBRzdDO0dBQ0EsT0FBTztFQUNYO0VBQ0EsSUFBSSxXQUFXLENBQUMsRUFBRTtFQUNsQixTQUFTLFlBQVksR0FBRztHQUNwQixPQUFPLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRTtFQUN2QztFQUNBLElBQUksaUJBQWlCLE9BQU8sV0FBVyxjQUFjLE9BQU8sV0FBVztFQUN2RSxJQUFJLGdCQUFnQixPQUFPLG1CQUFtQixXQUN4QyxTQUFVLEdBQUc7R0FDWCxJQUFJO0dBQ0osT0FBTyxLQUFLLFNBQVMsSUFBSSxFQUFFLG9CQUFvQixFQUFFLE1BQU0sQ0FBQztFQUM1RCxJQUNFLFdBQVk7R0FDVixPQUFPO0VBQ1g7RUFDSixTQUFTLGFBQWEsR0FBRyxHQUFHO0dBQ3hCLElBQUksSUFBSSxFQUFFLFFBQVEsQ0FBQztHQUNuQixJQUFJLEtBQUssR0FDTCxFQUFFLE9BQU8sR0FBRyxDQUFDO0dBQ2pCLE9BQU8sS0FBSztFQUNoQjtFQUNBLElBQUksZ0JBQWdCLENBQUM7RUFDckIsU0FBUyxXQUFXLFdBQVc7R0FDM0IsSUFBSSxHQUFHLEdBQUcsR0FBRztHQUNiLElBQUksVUFBVSxXQUFXLEdBQUc7SUFDeEIsSUFBSSxRQUFRLFNBQVMsR0FDakIsT0FBTyxVQUFVLE1BQU07SUFDM0IsSUFBSSxTQUFTLGlCQUFpQixPQUFPLGNBQWMsVUFDL0MsT0FBTyxDQUFDLFNBQVM7SUFDckIsSUFBSyxLQUFLLGNBQWMsU0FBUyxHQUFJO0tBQ2pDLElBQUksQ0FBQztLQUNMLE9BQVMsSUFBSSxHQUFHLEtBQUssR0FBSSxDQUFDLEVBQUUsTUFDeEIsRUFBRSxLQUFLLEVBQUUsS0FBSztLQUNsQixPQUFPO0lBQ1g7SUFDQSxJQUFJLGFBQWEsTUFDYixPQUFPLENBQUMsU0FBUztJQUNyQixJQUFJLFVBQVU7SUFDZCxJQUFJLE9BQU8sTUFBTSxVQUFVO0tBQ3ZCLElBQUksSUFBSSxNQUFNLENBQUM7S0FDZixPQUFPLEtBQ0gsRUFBRSxLQUFLLFVBQVU7S0FDckIsT0FBTztJQUNYO0lBQ0EsT0FBTyxDQUFDLFNBQVM7R0FDckI7R0FDQSxJQUFJLFVBQVU7R0FDZCxJQUFJLElBQUksTUFBTSxDQUFDO0dBQ2YsT0FBTyxLQUNILEVBQUUsS0FBSyxVQUFVO0dBQ3JCLE9BQU87RUFDWDtFQUNBLElBQUksa0JBQWtCLE9BQU8sV0FBVyxjQUNsQyxTQUFVLElBQUk7R0FBRSxPQUFPLEdBQUcsT0FBTyxpQkFBaUI7RUFBaUIsSUFDbkUsV0FBWTtHQUFFLE9BQU87RUFBTztFQUVsQyxJQUFJLGtCQUFrQjtHQUNsQjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNKO0VBQ0EsSUFBSSxtQkFBbUI7R0FDbkI7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNKO0VBQ0EsSUFBSSxZQUFZLGdCQUFnQixPQUFPLGdCQUFnQjtFQUN2RCxJQUFJLGVBQWU7R0FDZixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLE9BQU87R0FDUCxxQkFBcUI7R0FDckIsWUFBWTtFQUNoQjtFQUNBLFNBQVMsV0FBVyxNQUFNLEtBQUs7R0FDM0IsS0FBSyxPQUFPO0dBQ1osS0FBSyxVQUFVO0VBQ25CO0VBQ0EsT0FBTyxVQUFVLENBQUMsQ0FDYixLQUFLLEtBQUssQ0FBQyxDQUNYLE9BQU8sRUFDUixVQUFVLFdBQVk7R0FDbEIsT0FBTyxLQUFLLE9BQU8sT0FBTyxLQUFLO0VBQ25DLEVBQ0osQ0FBQztFQUNELFNBQVMscUJBQXFCLEtBQUssVUFBVTtHQUN6QyxPQUFRLE1BQ0osZUFDQSxPQUFPLEtBQUssUUFBUSxDQUFDLENBQ2hCLElBQUksU0FBVSxLQUFLO0lBQUUsT0FBTyxTQUFTLElBQUksQ0FBQyxTQUFTO0dBQUcsQ0FBQyxDQUFDLENBQ3hELE9BQU8sU0FBVSxHQUFHLEdBQUcsR0FBRztJQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtHQUFHLENBQUMsQ0FBQyxDQUN6RCxLQUFLLElBQUk7RUFDdEI7RUFDQSxTQUFTLFlBQVksS0FBSyxVQUFVLGNBQWMsWUFBWTtHQUMxRCxLQUFLLFdBQVc7R0FDaEIsS0FBSyxhQUFhO0dBQ2xCLEtBQUssZUFBZTtHQUNwQixLQUFLLFVBQVUscUJBQXFCLEtBQUssUUFBUTtFQUNyRDtFQUNBLE9BQU8sV0FBVyxDQUFDLENBQUMsS0FBSyxVQUFVO0VBQ25DLFNBQVMsVUFBVSxLQUFLLFVBQVU7R0FDOUIsS0FBSyxPQUFPO0dBQ1osS0FBSyxXQUFXLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxJQUFJLFNBQVUsS0FBSztJQUFFLE9BQU8sU0FBUztHQUFNLENBQUM7R0FDbEYsS0FBSyxnQkFBZ0I7R0FDckIsS0FBSyxVQUFVLHFCQUFxQixLQUFLLEtBQUssUUFBUTtFQUMxRDtFQUNBLE9BQU8sU0FBUyxDQUFDLENBQUMsS0FBSyxVQUFVO0VBQ2pDLElBQUksV0FBVyxVQUFVLE9BQU8sU0FBVSxLQUFLLE1BQU07R0FBRSxPQUFTLElBQUksUUFBUSxPQUFPLFNBQVU7RUFBTSxHQUFHLENBQUMsQ0FBQztFQUN4RyxJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGFBQWEsVUFBVSxPQUFPLFNBQVUsS0FBSyxNQUFNO0dBQ25ELElBQUksV0FBVyxPQUFPO0dBQ3RCLFNBQVMsV0FBVyxZQUFZLE9BQU87SUFDbkMsS0FBSyxPQUFPO0lBQ1osSUFBSSxDQUFDLFlBQVk7S0FDYixLQUFLLFVBQVUsYUFBYSxTQUFTO0tBQ3JDLEtBQUssUUFBUTtJQUNqQixPQUNLLElBQUksT0FBTyxlQUFlLFVBQVU7S0FDckMsS0FBSyxVQUFVLEdBQUcsT0FBTyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxLQUFLLFFBQVEsS0FBSztLQUN2RSxLQUFLLFFBQVEsU0FBUztJQUMxQixPQUNLLElBQUksT0FBTyxlQUFlLFVBQVU7S0FDckMsS0FBSyxVQUFVLEdBQUcsT0FBTyxXQUFXLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBTyxXQUFXLE9BQU87S0FDeEUsS0FBSyxRQUFRO0lBQ2pCO0dBQ0o7R0FDQSxPQUFPLFVBQVUsQ0FBQyxDQUFDLEtBQUssYUFBYTtHQUNyQyxJQUFJLFFBQVE7R0FDWixPQUFPO0VBQ1gsR0FBRyxDQUFDLENBQUM7RUFDTCxXQUFXLFNBQVM7RUFDcEIsV0FBVyxPQUFPO0VBQ2xCLFdBQVcsUUFBUTtFQUNuQixJQUFJLGVBQWUsaUJBQWlCLE9BQU8sU0FBVSxLQUFLLE1BQU07R0FDNUQsSUFBSSxPQUFPLFdBQVcsV0FBVztHQUNqQyxPQUFPO0VBQ1gsR0FBRyxDQUFDLENBQUM7RUFDTCxTQUFTLFNBQVMsVUFBVSxTQUFTO0dBQ2pDLElBQUksQ0FBQyxZQUNELG9CQUFvQixjQUNwQixvQkFBb0IsYUFDcEIsb0JBQW9CLGVBQ3BCLENBQUMsU0FBUyxRQUNWLENBQUMsYUFBYSxTQUFTLE9BQ3ZCLE9BQU87R0FDWCxJQUFJLEtBQUssSUFBSSxhQUFhLFNBQVMsTUFBTSxXQUFXLFNBQVMsU0FBUyxRQUFRO0dBQzlFLElBQUksV0FBVyxVQUNYLFFBQVEsSUFBSSxTQUFTLEVBQ2pCLEtBQUssV0FBWTtJQUNiLE9BQU8sS0FBSyxNQUFNO0dBQ3RCLEVBQ0osQ0FBQztHQUVMLE9BQU87RUFDWDtFQUNBLElBQUkscUJBQXFCLFVBQVUsT0FBTyxTQUFVLEtBQUssTUFBTTtHQUMzRCxJQUFJO0lBQUM7SUFBVTtJQUFRO0dBQU8sQ0FBQyxDQUFDLFFBQVEsSUFBSSxNQUFNLElBQzlDLElBQUksT0FBTyxXQUFXLFdBQVc7R0FDckMsT0FBTztFQUNYLEdBQUcsQ0FBQyxDQUFDO0VBQ0wsbUJBQW1CLGNBQWM7RUFDakMsbUJBQW1CLGFBQWE7RUFDaEMsbUJBQW1CLFlBQVk7RUFFL0IsU0FBUyxNQUFNLENBQUU7RUFDakIsU0FBUyxPQUFPLEtBQUs7R0FDakIsT0FBTztFQUNYO0VBQ0EsU0FBUyxrQkFBa0IsSUFBSSxJQUFJO0dBQy9CLElBQUksTUFBTSxRQUFRLE9BQU8sUUFDckIsT0FBTztHQUNYLE9BQU8sU0FBVSxLQUFLO0lBQ2xCLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUNyQjtFQUNKO0VBQ0EsU0FBUyxTQUFTLEtBQUssS0FBSztHQUN4QixPQUFPLFdBQVk7SUFDZixJQUFJLE1BQU0sTUFBTSxTQUFTO0lBQ3pCLElBQUksTUFBTSxNQUFNLFNBQVM7R0FDN0I7RUFDSjtFQUNBLFNBQVMsa0JBQWtCLElBQUksSUFBSTtHQUMvQixJQUFJLE9BQU8sS0FDUCxPQUFPO0dBQ1gsT0FBTyxXQUFZO0lBQ2YsSUFBSSxNQUFNLEdBQUcsTUFBTSxNQUFNLFNBQVM7SUFDbEMsSUFBSSxRQUFRLEtBQUEsR0FDUixVQUFVLEtBQUs7SUFDbkIsSUFBSSxZQUFZLEtBQUssV0FDckIsVUFBVSxLQUFLO0lBQ2YsS0FBSyxZQUFZO0lBQ2pCLEtBQUssVUFBVTtJQUNmLElBQUksT0FBTyxHQUFHLE1BQU0sTUFBTSxTQUFTO0lBQ25DLElBQUksV0FDQSxLQUFLLFlBQVksS0FBSyxZQUNoQixTQUFTLFdBQVcsS0FBSyxTQUFTLElBQ2xDO0lBQ1YsSUFBSSxTQUNBLEtBQUssVUFBVSxLQUFLLFVBQVUsU0FBUyxTQUFTLEtBQUssT0FBTyxJQUFJO0lBQ3BFLE9BQU8sU0FBUyxLQUFBLElBQVksT0FBTztHQUN2QztFQUNKO0VBQ0EsU0FBUyxrQkFBa0IsSUFBSSxJQUFJO0dBQy9CLElBQUksT0FBTyxLQUNQLE9BQU87R0FDWCxPQUFPLFdBQVk7SUFDZixHQUFHLE1BQU0sTUFBTSxTQUFTO0lBQ3hCLElBQUksWUFBWSxLQUFLLFdBQ3JCLFVBQVUsS0FBSztJQUNmLEtBQUssWUFBWSxLQUFLLFVBQVU7SUFDaEMsR0FBRyxNQUFNLE1BQU0sU0FBUztJQUN4QixJQUFJLFdBQ0EsS0FBSyxZQUFZLEtBQUssWUFDaEIsU0FBUyxXQUFXLEtBQUssU0FBUyxJQUNsQztJQUNWLElBQUksU0FDQSxLQUFLLFVBQVUsS0FBSyxVQUFVLFNBQVMsU0FBUyxLQUFLLE9BQU8sSUFBSTtHQUN4RTtFQUNKO0VBQ0EsU0FBUyxrQkFBa0IsSUFBSSxJQUFJO0dBQy9CLElBQUksT0FBTyxLQUNQLE9BQU87R0FDWCxPQUFPLFNBQVUsZUFBZTtJQUM1QixJQUFJLE1BQU0sR0FBRyxNQUFNLE1BQU0sU0FBUztJQUNsQyxPQUFPLGVBQWUsR0FBRztJQUN6QixJQUFJLFlBQVksS0FBSyxXQUNyQixVQUFVLEtBQUs7SUFDZixLQUFLLFlBQVk7SUFDakIsS0FBSyxVQUFVO0lBQ2YsSUFBSSxPQUFPLEdBQUcsTUFBTSxNQUFNLFNBQVM7SUFDbkMsSUFBSSxXQUNBLEtBQUssWUFBWSxLQUFLLFlBQ2hCLFNBQVMsV0FBVyxLQUFLLFNBQVMsSUFDbEM7SUFDVixJQUFJLFNBQ0EsS0FBSyxVQUFVLEtBQUssVUFBVSxTQUFTLFNBQVMsS0FBSyxPQUFPLElBQUk7SUFDcEUsT0FBTyxRQUFRLEtBQUEsSUFDVCxTQUFTLEtBQUEsSUFDTCxLQUFBLElBQ0EsT0FDSixPQUFPLEtBQUssSUFBSTtHQUMxQjtFQUNKO0VBQ0EsU0FBUywyQkFBMkIsSUFBSSxJQUFJO0dBQ3hDLElBQUksT0FBTyxLQUNQLE9BQU87R0FDWCxPQUFPLFdBQVk7SUFDZixJQUFJLEdBQUcsTUFBTSxNQUFNLFNBQVMsTUFBTSxPQUM5QixPQUFPO0lBQ1gsT0FBTyxHQUFHLE1BQU0sTUFBTSxTQUFTO0dBQ25DO0VBQ0o7RUFDQSxTQUFTLGdCQUFnQixJQUFJLElBQUk7R0FDN0IsSUFBSSxPQUFPLEtBQ1AsT0FBTztHQUNYLE9BQU8sV0FBWTtJQUNmLElBQUksTUFBTSxHQUFHLE1BQU0sTUFBTSxTQUFTO0lBQ2xDLElBQUksT0FBTyxPQUFPLElBQUksU0FBUyxZQUFZO0tBQ3ZDLElBQUksT0FBTyxNQUFNLElBQUksVUFBVSxRQUFRLE9BQU8sSUFBSSxNQUFNLENBQUM7S0FDekQsT0FBTyxLQUNILEtBQUssS0FBSyxVQUFVO0tBQ3hCLE9BQU8sSUFBSSxLQUFLLFdBQVk7TUFDeEIsT0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJO0tBQzlCLENBQUM7SUFDTDtJQUNBLE9BQU8sR0FBRyxNQUFNLE1BQU0sU0FBUztHQUNuQztFQUNKO0VBRUEsSUFBSSxRQUFRLE9BQU8sYUFBYSxlQUM1Qiw2Q0FBNkMsS0FBSyxTQUFTLElBQUk7RUFDbkUsU0FBUyxTQUFTLE9BQU8sUUFBUTtHQUM3QixRQUFRO0VBQ1o7RUFFQSxJQUFJLFdBQVcsQ0FBQztFQUNoQixJQUFJLGtCQUFrQixLQUFLLE9BQU8sT0FBTyxZQUFZLGNBQy9DLENBQUMsS0FDQSxXQUFZO0dBQ1gsSUFBSSxVQUFVLFFBQVEsUUFBUTtHQUM5QixJQUFJLE9BQU8sV0FBVyxlQUFlLENBQUMsT0FBTyxRQUN6QyxPQUFPO0lBQUM7SUFBUyxTQUFTLE9BQU87SUFBRztHQUFPO0dBQy9DLElBQUksVUFBVSxPQUFPLE9BQU8sT0FBTyxXQUFXLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0dBQ2pFLE9BQU87SUFBQztJQUFTLFNBQVMsT0FBTztJQUFHO0dBQU87RUFDL0MsRUFBQSxDQUFHLEdBQUcsd0JBQXdCLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxJQUFJLHdCQUF3QixLQUFLLElBQUksb0JBQW9CLHNCQUFzQixtQkFBbUI7RUFDdkssSUFBSSxnQkFBZ0IseUJBQXlCLHNCQUFzQjtFQUNuRSxJQUFJLHFCQUFxQixDQUFDLENBQUM7RUFDM0IsU0FBUyx1QkFBdUI7R0FDNUIsZUFBZSxZQUFZO0VBQy9CO0VBQ0EsSUFBSSxPQUFPLFNBQVUsVUFBVSxNQUFNO0dBQ2pDLGVBQWUsS0FBSyxDQUFDLFVBQVUsSUFBSSxDQUFDO0dBQ3BDLElBQUksc0JBQXNCO0lBQ3RCLHFCQUFxQjtJQUNyQix1QkFBdUI7R0FDM0I7RUFDSjtFQUNBLElBQUkscUJBQXFCLE1BQ3pCLHVCQUF1QixNQUN2QixrQkFBa0IsQ0FBQyxHQUNuQixrQkFBa0IsQ0FBQyxHQUNuQixrQkFBa0I7RUFDbEIsSUFBSSxZQUFZO0dBQ1osSUFBSTtHQUNKLFFBQVE7R0FDUixLQUFLO0dBQ0wsWUFBWSxDQUFDO0dBQ2IsYUFBYTtHQUNiLEtBQUs7R0FDTCxLQUFLLENBQUM7R0FDTixVQUFVO0VBQ2Q7RUFDQSxJQUFJLE1BQU07RUFDVixJQUFJLGlCQUFpQixDQUFDO0VBQ3RCLElBQUksb0JBQW9CO0VBQ3hCLElBQUksaUJBQWlCLENBQUM7RUFDdEIsU0FBUyxhQUFhLElBQUk7R0FDdEIsSUFBSSxPQUFPLFNBQVMsVUFDaEIsTUFBTSxJQUFJLFVBQVUsc0NBQXNDO0dBQzlELEtBQUssYUFBYSxDQUFDO0dBQ25CLEtBQUssT0FBTztHQUNaLElBQUksTUFBTyxLQUFLLE9BQU87R0FDdkIsSUFBSSxPQUFPLE9BQU8sWUFBWTtJQUMxQixJQUFJLE9BQU8sVUFDUCxNQUFNLElBQUksVUFBVSxnQkFBZ0I7SUFDeEMsS0FBSyxTQUFTLFVBQVU7SUFDeEIsS0FBSyxTQUFTLFVBQVU7SUFDeEIsSUFBSSxLQUFLLFdBQVcsT0FDaEIsZ0JBQWdCLE1BQU0sS0FBSyxNQUFNO0lBQ3JDO0dBQ0o7R0FDQSxLQUFLLFNBQVM7R0FDZCxLQUFLLFNBQVM7R0FDZCxFQUFFLElBQUk7R0FDTixtQkFBbUIsTUFBTSxFQUFFO0VBQy9CO0VBQ0EsSUFBSSxXQUFXO0dBQ1gsS0FBSyxXQUFZO0lBQ2IsSUFBSSxNQUFNLEtBQUssY0FBYztJQUM3QixTQUFTLEtBQUssYUFBYSxZQUFZO0tBQ25DLElBQUksUUFBUTtLQUNaLElBQUksZ0JBQWdCLENBQUMsSUFBSSxXQUFXLFFBQVEsT0FBTyxnQkFBZ0I7S0FDbkUsSUFBSSxVQUFVLGlCQUFpQixDQUFDLHdCQUF3QjtLQUN4RCxJQUFJLEtBQUssSUFBSSxhQUFhLFNBQVUsU0FBUyxRQUFRO01BQ2pELG9CQUFvQixPQUFPLElBQUksU0FBUywwQkFBMEIsYUFBYSxLQUFLLGVBQWUsT0FBTyxHQUFHLDBCQUEwQixZQUFZLEtBQUssZUFBZSxPQUFPLEdBQUcsU0FBUyxRQUFRLEdBQUcsQ0FBQztLQUMxTSxDQUFDO0tBQ0QsSUFBSSxLQUFLLGNBQ0wsR0FBRyxlQUFlLEtBQUs7S0FDM0IsT0FBTztJQUNYO0lBQ0EsS0FBSyxZQUFZO0lBQ2pCLE9BQU87R0FDWDtHQUNBLEtBQUssU0FBVSxPQUFPO0lBQ2xCLFFBQVEsTUFBTSxRQUFRLFNBQVMsTUFBTSxjQUFjLFdBQzdDLFdBQ0E7S0FDRSxLQUFLLFdBQVk7TUFDYixPQUFPO0tBQ1g7S0FDQSxLQUFLLFNBQVM7SUFDbEIsQ0FBQztHQUNUO0VBQ0o7RUFDQSxNQUFNLGFBQWEsV0FBVztHQUMxQixNQUFNO0dBQ04sT0FBTyxTQUFVLGFBQWEsWUFBWTtJQUN0QyxvQkFBb0IsTUFBTSxJQUFJLFNBQVMsTUFBTSxNQUFNLGFBQWEsWUFBWSxHQUFHLENBQUM7R0FDcEY7R0FDQSxPQUFPLFNBQVUsWUFBWTtJQUN6QixJQUFJLFVBQVUsV0FBVyxHQUNyQixPQUFPLEtBQUssS0FBSyxNQUFNLFVBQVU7SUFDckMsSUFBSSxPQUFPLFVBQVUsSUFBSSxVQUFVLFVBQVU7SUFDN0MsT0FBTyxPQUFPLFNBQVMsYUFDakIsS0FBSyxLQUFLLE1BQU0sU0FBVSxLQUFLO0tBQzdCLE9BQU8sZUFBZSxPQUFPLFFBQVEsR0FBRyxJQUFJLGNBQWMsR0FBRztJQUNqRSxDQUFDLElBQ0MsS0FBSyxLQUFLLE1BQU0sU0FBVSxLQUFLO0tBQzdCLE9BQU8sT0FBTyxJQUFJLFNBQVMsT0FBTyxRQUFRLEdBQUcsSUFBSSxjQUFjLEdBQUc7SUFDdEUsQ0FBQztHQUNUO0dBQ0EsU0FBUyxTQUFVLFdBQVc7SUFDMUIsT0FBTyxLQUFLLEtBQUssU0FBVSxPQUFPO0tBQzlCLE9BQU8sYUFBYSxRQUFRLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFZO01BQUUsT0FBTztLQUFPLENBQUM7SUFDL0UsR0FBRyxTQUFVLEtBQUs7S0FDZCxPQUFPLGFBQWEsUUFBUSxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBWTtNQUFFLE9BQU8sY0FBYyxHQUFHO0tBQUcsQ0FBQztJQUM1RixDQUFDO0dBQ0w7R0FDQSxTQUFTLFNBQVUsSUFBSSxLQUFLO0lBQ3hCLElBQUksUUFBUTtJQUNaLE9BQU8sS0FBSyxXQUNOLElBQUksYUFBYSxTQUFVLFNBQVMsUUFBUTtLQUMxQyxJQUFJLFNBQVMsV0FBVyxXQUFZO01BQUUsT0FBTyxPQUFPLElBQUksV0FBVyxRQUFRLEdBQUcsQ0FBQztLQUFHLEdBQUcsRUFBRTtLQUN2RixNQUFNLEtBQUssU0FBUyxNQUFNLENBQUMsQ0FBQyxRQUFRLGFBQWEsS0FBSyxNQUFNLE1BQU0sQ0FBQztJQUN2RSxDQUFDLElBQ0M7R0FDVjtFQUNKLENBQUM7RUFDRCxJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sYUFDeEMsUUFBUSxhQUFhLFdBQVcsT0FBTyxhQUFhLGVBQWU7RUFDdkUsVUFBVSxNQUFNLFNBQVM7RUFDekIsU0FBUyxTQUFTLGFBQWEsWUFBWSxTQUFTLFFBQVEsTUFBTTtHQUM5RCxLQUFLLGNBQWMsT0FBTyxnQkFBZ0IsYUFBYSxjQUFjO0dBQ3JFLEtBQUssYUFBYSxPQUFPLGVBQWUsYUFBYSxhQUFhO0dBQ2xFLEtBQUssVUFBVTtHQUNmLEtBQUssU0FBUztHQUNkLEtBQUssTUFBTTtFQUNmO0VBQ0EsTUFBTSxjQUFjO0dBQ2hCLEtBQUssV0FBWTtJQUNiLElBQUksU0FBUyxXQUNSLE1BQU0sTUFBTSxTQUFTLENBQUMsQ0FDdEIsSUFBSSx3QkFBd0I7SUFDakMsT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFTLFFBQVE7S0FDL0MsSUFBSSxPQUFPLFdBQVcsR0FDbEIsUUFBUSxDQUFDLENBQUM7S0FDZCxJQUFJLFlBQVksT0FBTztLQUN2QixPQUFPLFFBQVEsU0FBVSxHQUFHLEdBQUc7TUFDM0IsT0FBTyxhQUFhLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLEdBQUc7T0FDN0MsT0FBTyxLQUFLO09BQ1osSUFBSSxDQUFDLEVBQUUsV0FDSCxRQUFRLE1BQU07TUFDdEIsR0FBRyxNQUFNO0tBQ2IsQ0FBQztJQUNMLENBQUM7R0FDTDtHQUNBLFNBQVMsU0FBVSxPQUFPO0lBQ3RCLElBQUksaUJBQWlCLGNBQ2pCLE9BQU87SUFDWCxJQUFJLFNBQVMsT0FBTyxNQUFNLFNBQVMsWUFDL0IsT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFTLFFBQVE7S0FDL0MsTUFBTSxLQUFLLFNBQVMsTUFBTTtJQUM5QixDQUFDO0lBRUwsT0FBTyxJQURNLGFBQWEsVUFBVSxNQUFNLEtBQ2xDO0dBQ1o7R0FDQSxRQUFRO0dBQ1IsTUFBTSxXQUFZO0lBQ2QsSUFBSSxTQUFTLFdBQ1IsTUFBTSxNQUFNLFNBQVMsQ0FBQyxDQUN0QixJQUFJLHdCQUF3QjtJQUNqQyxPQUFPLElBQUksYUFBYSxTQUFVLFNBQVMsUUFBUTtLQUMvQyxPQUFPLElBQUksU0FBVSxPQUFPO01BQUUsT0FBTyxhQUFhLFFBQVEsS0FBSyxDQUFDLENBQUMsS0FBSyxTQUFTLE1BQU07S0FBRyxDQUFDO0lBQzdGLENBQUM7R0FDTDtHQUNBLEtBQUs7SUFDRCxLQUFLLFdBQVk7S0FBRSxPQUFPO0lBQUs7SUFDL0IsS0FBSyxTQUFVLE9BQU87S0FBRSxPQUFRLE1BQU07SUFBUTtHQUNsRDtHQUNBLGFBQWEsRUFBRSxLQUFLLFdBQVk7SUFBRSxPQUFPO0dBQWEsRUFBRTtHQUN4RCxRQUFRO0dBQ0E7R0FDUixXQUFXO0lBQ1AsS0FBSyxXQUFZO0tBQUUsT0FBTztJQUFNO0lBQ2hDLEtBQUssU0FBVSxPQUFPO0tBQ2xCLE9BQU87SUFDWDtHQUNKO0dBQ0EsaUJBQWlCO0lBQ2IsS0FBSyxXQUFZO0tBQUUsT0FBTztJQUFpQjtJQUMzQyxLQUFLLFNBQVUsT0FBTztLQUNsQixrQkFBa0I7SUFDdEI7R0FDSjtHQUNBLFFBQVEsU0FBVSxJQUFJLFdBQVc7SUFDN0IsT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFTLFFBQVE7S0FDL0MsT0FBTyxTQUFTLFNBQVUsU0FBUyxRQUFRO01BQ3ZDLElBQUksTUFBTTtNQUNWLElBQUksYUFBYSxDQUFDO01BQ2xCLElBQUksY0FBYztNQUNsQixJQUFJLFdBQVcsU0FBUyxXQUFZO09BQ2hDLElBQUksUUFBUTtPQUNaLHlDQUF5QyxXQUFZO1FBQ2pELE1BQU0sV0FBVyxXQUFXLElBQ3RCLFFBQVEsSUFDUixPQUFPLE1BQU0sV0FBVyxFQUFFO09BQ3BDLENBQUM7TUFDTCxHQUFHLElBQUksUUFBUTtNQUNmLEdBQUc7S0FDUCxHQUFHLFdBQVcsU0FBUyxNQUFNO0lBQ2pDLENBQUM7R0FDTDtFQUNKLENBQUM7RUFDRCxJQUFJLGVBQWU7R0FDZixJQUFJLGNBQWMsWUFDZCxRQUFRLGNBQWMsY0FBYyxXQUFZO0lBQzVDLElBQUksbUJBQW1CLFdBQ2xCLE1BQU0sTUFBTSxTQUFTLENBQUMsQ0FDdEIsSUFBSSx3QkFBd0I7SUFDakMsT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFTO0tBQ3ZDLElBQUksaUJBQWlCLFdBQVcsR0FDNUIsUUFBUSxDQUFDLENBQUM7S0FDZCxJQUFJLFlBQVksaUJBQWlCO0tBQ2pDLElBQUksVUFBVSxJQUFJLE1BQU0sU0FBUztLQUNqQyxpQkFBaUIsUUFBUSxTQUFVLEdBQUcsR0FBRztNQUNyQyxPQUFPLGFBQWEsUUFBUSxDQUFDLENBQUMsQ0FDekIsS0FBSyxTQUFVLE9BQU87T0FBRSxPQUFRLFFBQVEsS0FBSztRQUFFLFFBQVE7UUFBb0I7T0FBTTtNQUFJLEdBQUcsU0FBVSxRQUFRO09BQUUsT0FBUSxRQUFRLEtBQUs7UUFBRSxRQUFRO1FBQW9CO09BQU87TUFBSSxDQUFDLENBQUMsQ0FDNUssS0FBSyxXQUFZO09BQUUsT0FBTyxFQUFFLGFBQWEsUUFBUSxPQUFPO01BQUcsQ0FBQztLQUNyRSxDQUFDO0lBQ0wsQ0FBQztHQUNMLENBQUM7R0FDTCxJQUFJLGNBQWMsT0FBTyxPQUFPLG1CQUFtQixhQUMvQyxRQUFRLGNBQWMsT0FBTyxXQUFZO0lBQ3JDLElBQUksbUJBQW1CLFdBQ2xCLE1BQU0sTUFBTSxTQUFTLENBQUMsQ0FDdEIsSUFBSSx3QkFBd0I7SUFDakMsT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFTLFFBQVE7S0FDL0MsSUFBSSxpQkFBaUIsV0FBVyxHQUM1Qix1QkFBTyxJQUFJLGVBQWUsQ0FBQyxDQUFDLENBQUM7S0FDakMsSUFBSSxZQUFZLGlCQUFpQjtLQUNqQyxJQUFJLFdBQVcsSUFBSSxNQUFNLFNBQVM7S0FDbEMsaUJBQWlCLFFBQVEsU0FBVSxHQUFHLEdBQUc7TUFDckMsT0FBTyxhQUFhLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLE9BQU87T0FBRSxPQUFPLFFBQVEsS0FBSztNQUFHLEdBQUcsU0FBVSxTQUFTO09BQ2hHLFNBQVMsS0FBSztPQUNkLElBQUksQ0FBQyxFQUFFLFdBQ0gsT0FBTyxJQUFJLGVBQWUsUUFBUSxDQUFDO01BQzNDLENBQUM7S0FDTCxDQUFDO0lBQ0wsQ0FBQztHQUNMLENBQUM7R0FDTCxJQUFJLGNBQWMsZUFDZCxhQUFhLGdCQUFnQixjQUFjO0VBQ25EO0VBQ0EsU0FBUyxtQkFBbUIsU0FBUyxJQUFJO0dBQ3JDLElBQUk7SUFDQSxHQUFHLFNBQVUsT0FBTztLQUNoQixJQUFJLFFBQVEsV0FBVyxNQUNuQjtLQUNKLElBQUksVUFBVSxTQUNWLE1BQU0sSUFBSSxVQUFVLDJDQUEyQztLQUNuRSxJQUFJLG9CQUFvQixRQUFRLFFBQVEsb0JBQW9CO0tBQzVELElBQUksU0FBUyxPQUFPLE1BQU0sU0FBUyxZQUMvQixtQkFBbUIsU0FBUyxTQUFVLFNBQVMsUUFBUTtNQUNuRCxpQkFBaUIsZUFDWCxNQUFNLE1BQU0sU0FBUyxNQUFNLElBQzNCLE1BQU0sS0FBSyxTQUFTLE1BQU07S0FDcEMsQ0FBQztVQUVBO01BQ0QsUUFBUSxTQUFTO01BQ2pCLFFBQVEsU0FBUztNQUNqQixzQkFBc0IsT0FBTztLQUNqQztLQUNBLElBQUksbUJBQ0Esa0JBQWtCO0lBQzFCLEdBQUcsZ0JBQWdCLEtBQUssTUFBTSxPQUFPLENBQUM7R0FDMUMsU0FDTyxJQUFJO0lBQ1AsZ0JBQWdCLFNBQVMsRUFBRTtHQUMvQjtFQUNKO0VBQ0EsU0FBUyxnQkFBZ0IsU0FBUyxRQUFRO0dBQ3RDLGdCQUFnQixLQUFLLE1BQU07R0FDM0IsSUFBSSxRQUFRLFdBQVcsTUFDbkI7R0FDSixJQUFJLG9CQUFvQixRQUFRLFFBQVEsb0JBQW9CO0dBQzVELFNBQVMsZ0JBQWdCLE1BQU07R0FDL0IsUUFBUSxTQUFTO0dBQ2pCLFFBQVEsU0FBUztHQUNqQiwwQkFBMEIsT0FBTztHQUNqQyxzQkFBc0IsT0FBTztHQUM3QixJQUFJLG1CQUNBLGtCQUFrQjtFQUMxQjtFQUNBLFNBQVMsc0JBQXNCLFNBQVM7R0FDcEMsSUFBSSxZQUFZLFFBQVE7R0FDeEIsUUFBUSxhQUFhLENBQUM7R0FDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLFVBQVUsUUFBUSxJQUFJLEtBQUssRUFBRSxHQUMvQyxvQkFBb0IsU0FBUyxVQUFVLEVBQUU7R0FFN0MsSUFBSSxNQUFNLFFBQVE7R0FDbEIsRUFBRSxJQUFJLE9BQU8sSUFBSSxTQUFTO0dBQzFCLElBQUksc0JBQXNCLEdBQUc7SUFDekIsRUFBRTtJQUNGLEtBQUssV0FBWTtLQUNiLElBQUksRUFBRSxzQkFBc0IsR0FDeEIscUJBQXFCO0lBQzdCLEdBQUcsQ0FBQyxDQUFDO0dBQ1Q7RUFDSjtFQUNBLFNBQVMsb0JBQW9CLFNBQVMsVUFBVTtHQUM1QyxJQUFJLFFBQVEsV0FBVyxNQUFNO0lBQ3pCLFFBQVEsV0FBVyxLQUFLLFFBQVE7SUFDaEM7R0FDSjtHQUNBLElBQUksS0FBSyxRQUFRLFNBQVMsU0FBUyxjQUFjLFNBQVM7R0FDMUQsSUFBSSxPQUFPLE1BQ1AsUUFBUSxRQUFRLFNBQVMsU0FBUyxVQUFVLFNBQVMsT0FBQSxDQUFRLFFBQVEsTUFBTTtHQUUvRSxFQUFFLFNBQVMsSUFBSTtHQUNmLEVBQUU7R0FDRixLQUFLLGNBQWM7SUFBQztJQUFJO0lBQVM7R0FBUSxDQUFDO0VBQzlDO0VBQ0EsU0FBUyxhQUFhLElBQUksU0FBUyxVQUFVO0dBQ3pDLElBQUk7SUFDQSxJQUFJLEtBQUssUUFBUSxRQUFRO0lBQ3pCLElBQUksQ0FBQyxRQUFRLFVBQVUsZ0JBQWdCLFFBQ25DLGtCQUFrQixDQUFDO0lBQ3ZCLE1BQ0ksU0FBUyxRQUFRLGVBQ1gsUUFBUSxhQUFhLElBQUksV0FBWTtLQUFFLE9BQU8sR0FBRyxLQUFLO0lBQUcsQ0FBQyxJQUMxRCxHQUFHLEtBQUs7SUFDbEIsSUFBSSxDQUFDLFFBQVEsVUFBVSxnQkFBZ0IsUUFBUSxLQUFLLE1BQU0sSUFDdEQsbUJBQW1CLE9BQU87SUFFOUIsU0FBUyxRQUFRLEdBQUc7R0FDeEIsU0FDTyxHQUFHO0lBQ04sU0FBUyxPQUFPLENBQUM7R0FDckIsVUFDUTtJQUNKLElBQUksRUFBRSxzQkFBc0IsR0FDeEIscUJBQXFCO0lBQ3pCLEVBQUUsU0FBUyxJQUFJLE9BQU8sU0FBUyxJQUFJLFNBQVM7R0FDaEQ7RUFDSjtFQUNBLFNBQVMsZUFBZTtHQUNwQixPQUFPLFdBQVcsV0FBWTtJQUMxQixvQkFBb0IsS0FBSyxrQkFBa0I7R0FDL0MsQ0FBQztFQUNMO0VBQ0EsU0FBUyxzQkFBc0I7R0FDM0IsSUFBSSxjQUFjO0dBQ2xCLHFCQUFxQjtHQUNyQix1QkFBdUI7R0FDdkIsT0FBTztFQUNYO0VBQ0EsU0FBUyxvQkFBb0I7R0FDekIsSUFBSSxXQUFXLEdBQUc7R0FDbEI7SUFDSSxPQUFPLGVBQWUsU0FBUyxHQUFHO0tBQzlCLFlBQVk7S0FDWixpQkFBaUIsQ0FBQztLQUNsQixJQUFJLFVBQVU7S0FDZCxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRSxHQUFHO01BQ3BCLElBQUksT0FBTyxVQUFVO01BQ3JCLEtBQUssRUFBRSxDQUFDLE1BQU0sTUFBTSxLQUFLLEVBQUU7S0FDL0I7SUFDSjtVQUNLLGVBQWUsU0FBUztHQUNqQyxxQkFBcUI7R0FDckIsdUJBQXVCO0VBQzNCO0VBQ0EsU0FBUyx1QkFBdUI7R0FDNUIsSUFBSSxnQkFBZ0I7R0FDcEIsa0JBQWtCLENBQUM7R0FDbkIsY0FBYyxRQUFRLFNBQVUsR0FBRztJQUMvQixFQUFFLEtBQUssWUFBWSxLQUFLLE1BQU0sRUFBRSxRQUFRLENBQUM7R0FDN0MsQ0FBQztHQUNELElBQUksYUFBYSxlQUFlLE1BQU0sQ0FBQztHQUN2QyxJQUFJLElBQUksV0FBVztHQUNuQixPQUFPLEdBQ0gsV0FBVyxFQUFFLEVBQUUsQ0FBQztFQUN4QjtFQUNBLFNBQVMseUNBQXlDLElBQUk7R0FDbEQsU0FBUyxZQUFZO0lBQ2pCLEdBQUc7SUFDSCxlQUFlLE9BQU8sZUFBZSxRQUFRLFNBQVMsR0FBRyxDQUFDO0dBQzlEO0dBQ0EsZUFBZSxLQUFLLFNBQVM7R0FDN0IsRUFBRTtHQUNGLEtBQUssV0FBWTtJQUNiLElBQUksRUFBRSxzQkFBc0IsR0FDeEIscUJBQXFCO0dBQzdCLEdBQUcsQ0FBQyxDQUFDO0VBQ1Q7RUFDQSxTQUFTLDBCQUEwQixTQUFTO0dBQ3hDLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxTQUFVLEdBQUc7SUFBRSxPQUFPLEVBQUUsV0FBVyxRQUFRO0dBQVEsQ0FBQyxHQUMxRSxnQkFBZ0IsS0FBSyxPQUFPO0VBQ3BDO0VBQ0EsU0FBUyxtQkFBbUIsU0FBUztHQUNqQyxJQUFJLElBQUksZ0JBQWdCO0dBQ3hCLE9BQU8sR0FDSCxJQUFJLGdCQUFnQixFQUFFLEVBQUUsQ0FBQyxXQUFXLFFBQVEsUUFBUTtJQUNoRCxnQkFBZ0IsT0FBTyxHQUFHLENBQUM7SUFDM0I7R0FDSjtFQUNSO0VBQ0EsU0FBUyxjQUFjLFFBQVE7R0FDM0IsT0FBTyxJQUFJLGFBQWEsVUFBVSxPQUFPLE1BQU07RUFDbkQ7RUFDQSxTQUFTLEtBQUssSUFBSSxjQUFjO0dBQzVCLElBQUksTUFBTTtHQUNWLE9BQU8sV0FBWTtJQUNmLElBQUksY0FBYyxvQkFBb0IsR0FBRyxhQUFhO0lBQ3RELElBQUk7S0FDQSxhQUFhLEtBQUssSUFBSTtLQUN0QixPQUFPLEdBQUcsTUFBTSxNQUFNLFNBQVM7SUFDbkMsU0FDTyxHQUFHO0tBQ04sZ0JBQWdCLGFBQWEsQ0FBQztJQUNsQyxVQUNRO0tBQ0osYUFBYSxZQUFZLEtBQUs7S0FDOUIsSUFBSSxhQUNBLGtCQUFrQjtJQUMxQjtHQUNKO0VBQ0o7RUFDQSxJQUFJLE9BQU87R0FBRSxRQUFRO0dBQUcsUUFBUTtHQUFHLElBQUk7RUFBRTtFQUN6QyxJQUFJLGNBQWM7RUFDbEIsSUFBSSxZQUFZLENBQUM7RUFDakIsSUFBSSxhQUFhO0VBQ2pCLElBQUksY0FBYztFQUNsQixJQUFJLGtCQUFrQjtFQUN0QixTQUFTLFNBQVMsSUFBSSxPQUFPLElBQUksSUFBSTtHQUNqQyxJQUFJLFNBQVMsS0FBSyxNQUFNLE9BQU8sT0FBTyxNQUFNO0dBQzVDLElBQUksU0FBUztHQUNiLElBQUksTUFBTTtHQUNWLElBQUksU0FBUztHQUNiLElBQUksS0FBSyxFQUFFO0dBQ1gsVUFBVTtHQUNWLElBQUksTUFBTSxxQkFDSjtJQUNFLFNBQVM7SUFDVCxhQUFhO0tBQ1QsT0FBTztLQUNQLGNBQWM7S0FDZCxVQUFVO0lBQ2Q7SUFDQSxLQUFLLGFBQWE7SUFDbEIsTUFBTSxhQUFhO0lBQ25CLFlBQVksYUFBYTtJQUN6QixLQUFLLGFBQWE7SUFDbEIsU0FBUyxhQUFhO0lBQ3RCLFFBQVEsYUFBYTtHQUN6QixJQUNFLENBQUM7R0FDUCxJQUFJLE9BQ0EsT0FBTyxLQUFLLEtBQUs7R0FDckIsRUFBRSxPQUFPO0dBQ1QsSUFBSSxXQUFXLFdBQVk7SUFDdkIsRUFBRSxLQUFLLE9BQU8sT0FBTyxLQUFLLE9BQU8sU0FBUztHQUM5QztHQUNBLElBQUksS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEVBQUU7R0FDL0IsSUFBSSxJQUFJLFFBQVEsR0FDWixJQUFJLFNBQVM7R0FDakIsT0FBTztFQUNYO0VBQ0EsU0FBUywwQkFBMEI7R0FDL0IsSUFBSSxDQUFDLEtBQUssSUFDTixLQUFLLEtBQUssRUFBRTtHQUNoQixFQUFFLEtBQUs7R0FDUCxLQUFLLFVBQVU7R0FDZixPQUFPLEtBQUs7RUFDaEI7RUFDQSxTQUFTLDBCQUEwQjtHQUMvQixJQUFJLENBQUMsS0FBSyxRQUNOLE9BQU87R0FDWCxJQUFJLEVBQUUsS0FBSyxXQUFXLEdBQ2xCLEtBQUssS0FBSztHQUNkLEtBQUssU0FBUyxLQUFLLFNBQVM7R0FDNUIsT0FBTztFQUNYO0VBQ0EsS0FBSyxLQUFLLGtCQUFBLENBQW1CLFFBQVEsZUFBZSxNQUFNLElBQ3RELDBCQUEwQiwwQkFBMEI7RUFFeEQsU0FBUyx5QkFBeUIsaUJBQWlCO0dBQy9DLElBQUksS0FBSyxVQUNMLG1CQUNBLGdCQUFnQixnQkFBZ0IsZUFBZTtJQUMvQyx3QkFBd0I7SUFDeEIsT0FBTyxnQkFBZ0IsS0FBSyxTQUFVLEdBQUc7S0FDckMsd0JBQXdCO0tBQ3hCLE9BQU87SUFDWCxHQUFHLFNBQVUsR0FBRztLQUNaLHdCQUF3QjtLQUN4QixPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0dBQ0w7R0FDQSxPQUFPO0VBQ1g7RUFDQSxTQUFTLGNBQWMsWUFBWTtHQUMvQixFQUFFO0dBQ0YsSUFBSSxDQUFDLEtBQUssVUFBVSxFQUFFLEtBQUssV0FBVyxHQUNsQyxLQUFLLFNBQVMsS0FBSyxTQUFTLEtBQUssS0FBSztHQUUxQyxVQUFVLEtBQUssR0FBRztHQUNsQixhQUFhLFlBQVksSUFBSTtFQUNqQztFQUNBLFNBQVMsZ0JBQWdCO0dBQ3JCLElBQUksT0FBTyxVQUFVLFVBQVUsU0FBUztHQUN4QyxVQUFVLElBQUk7R0FDZCxhQUFhLE1BQU0sS0FBSztFQUM1QjtFQUNBLFNBQVMsYUFBYSxZQUFZLGVBQWU7R0FDN0MsSUFBSSxjQUFjO0dBQ2xCLElBQUksZ0JBQ0UsS0FBSyxXQUFXLENBQUMsZ0JBQWdCLGVBQWUsT0FDaEQsZUFBZSxDQUFDLEVBQUUsY0FBYyxlQUFlLE1BQ2pELGVBQWUsZ0JBQWdCLGNBQWMsS0FBSyxNQUFNLFVBQVUsSUFBSSxhQUFhO0dBRXZGLElBQUksZUFBZSxLQUNmO0dBQ0osTUFBTTtHQUNOLElBQUksZ0JBQWdCLFdBQ2hCLFVBQVUsTUFBTSxTQUFTO0dBQzdCLElBQUksb0JBQW9CO0lBQ3BCLElBQUksZ0JBQWdCLFVBQVUsSUFBSTtJQUNsQyxJQUFJLFlBQVksV0FBVztJQUMzQixJQUFJLFlBQVksVUFBVSxXQUFXLFFBQVE7S0FDekMsT0FBTyxlQUFlLFNBQVMsV0FBVyxVQUFVLFdBQVc7S0FDL0QsY0FBYyxNQUFNLFVBQVU7S0FDOUIsY0FBYyxPQUFPLFVBQVU7S0FDL0IsY0FBYyxVQUFVLFVBQVU7S0FDbEMsY0FBYyxTQUFTLFVBQVU7S0FDakMsSUFBSSxVQUFVLFlBQ1YsY0FBYyxhQUFhLFVBQVU7S0FDekMsSUFBSSxVQUFVLEtBQ1YsY0FBYyxNQUFNLFVBQVU7SUFDdEM7R0FDSjtFQUNKO0VBQ0EsU0FBUyxXQUFXO0dBQ2hCLElBQUksZ0JBQWdCLFFBQVE7R0FDNUIsT0FBTyxxQkFDRDtJQUNFLFNBQVM7SUFDVCxhQUFhLE9BQU8seUJBQXlCLFNBQVMsU0FBUztJQUMvRCxLQUFLLGNBQWM7SUFDbkIsTUFBTSxjQUFjO0lBQ3BCLFlBQVksY0FBYztJQUMxQixLQUFLLGNBQWM7SUFDbkIsU0FBUyxjQUFjO0lBQ3ZCLFFBQVEsY0FBYztHQUMxQixJQUNFLENBQUM7RUFDWDtFQUNBLFNBQVMsT0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUk7R0FDakMsSUFBSSxhQUFhO0dBQ2pCLElBQUk7SUFDQSxhQUFhLEtBQUssSUFBSTtJQUN0QixPQUFPLEdBQUcsSUFBSSxJQUFJLEVBQUU7R0FDeEIsVUFDUTtJQUNKLGFBQWEsWUFBWSxLQUFLO0dBQ2xDO0VBQ0o7RUFDQSxTQUFTLDBCQUEwQixJQUFJLE1BQU0sZUFBZSxTQUFTO0dBQ2pFLE9BQU8sT0FBTyxPQUFPLGFBQ2YsS0FDQSxXQUFZO0lBQ1YsSUFBSSxZQUFZO0lBQ2hCLElBQUksZUFDQSx3QkFBd0I7SUFDNUIsYUFBYSxNQUFNLElBQUk7SUFDdkIsSUFBSTtLQUNBLE9BQU8sR0FBRyxNQUFNLE1BQU0sU0FBUztJQUNuQyxVQUNRO0tBQ0osYUFBYSxXQUFXLEtBQUs7S0FDN0IsSUFBSSxTQUNBLGVBQWUsdUJBQXVCO0lBQzlDO0dBQ0o7RUFDUjtFQUNBLFNBQVMsb0JBQW9CLElBQUk7R0FDN0IsSUFBSSxZQUFZLGlCQUFpQixLQUFLLFdBQVcsR0FBRztJQUNoRCxJQUFJLGVBQWUsR0FDZixHQUFHO1NBR0gsdUJBQXVCLEVBQUU7R0FFakMsT0FFSSxXQUFXLElBQUksQ0FBQztFQUV4QjtFQUNBLElBQUksWUFBWSxhQUFhO0VBRTdCLFNBQVMsZ0JBQWdCLElBQUksTUFBTSxZQUFZLElBQUk7R0FDL0MsSUFBSSxDQUFDLEdBQUcsU0FBVSxDQUFDLEdBQUcsT0FBTyxnQkFBZ0IsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxHQUFHLE1BQU87SUFDdkUsSUFBSSxHQUFHLE9BQU8sY0FDVixPQUFPLFVBQVUsSUFBSSxXQUFXLGVBQWUsR0FBRyxPQUFPLFdBQVcsQ0FBQztJQUV6RSxJQUFJLENBQUMsR0FBRyxPQUFPLGVBQWU7S0FDMUIsSUFBSSxDQUFDLEdBQUcsT0FBTyxVQUNYLE9BQU8sVUFBVSxJQUFJLFdBQVcsZUFBZSxDQUFDO0tBQ3BELEdBQUcsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHO0lBQ3ZCO0lBQ0EsT0FBTyxHQUFHLE9BQU8sZUFBZSxLQUFLLFdBQVk7S0FDN0MsT0FBTyxnQkFBZ0IsSUFBSSxNQUFNLFlBQVksRUFBRTtJQUNuRCxDQUFDO0dBQ0wsT0FDSztJQUNELElBQUksUUFBUSxHQUFHLG1CQUFtQixNQUFNLFlBQVksR0FBRyxTQUFTO0lBQ2hFLElBQUk7S0FDQSxNQUFNLE9BQU87S0FDYixHQUFHLE9BQU8saUJBQWlCO0lBQy9CLFNBQ08sSUFBSTtLQUNQLElBQUksR0FBRyxTQUFTLFNBQVMsZ0JBQ3JCLEdBQUcsT0FBTyxLQUNWLEVBQUUsR0FBRyxPQUFPLGlCQUFpQixHQUFHO01BQ2hDLFFBQVEsS0FBSywwQkFBMEI7TUFDdkMsR0FBRyxNQUFNLEVBQUUsaUJBQWlCLE1BQU0sQ0FBQztNQUNuQyxPQUFPLEdBQUcsS0FBSyxDQUFDLENBQUMsS0FBSyxXQUFZO09BQUUsT0FBTyxnQkFBZ0IsSUFBSSxNQUFNLFlBQVksRUFBRTtNQUFHLENBQUM7S0FDM0Y7S0FDQSxPQUFPLFVBQVUsRUFBRTtJQUN2QjtJQUNBLE9BQU8sTUFDRixTQUFTLE1BQU0sU0FBVSxTQUFTLFFBQVE7S0FDM0MsT0FBTyxTQUFTLFdBQVk7TUFDeEIsSUFBSSxRQUFRO01BQ1osT0FBTyxHQUFHLFNBQVMsUUFBUSxLQUFLO0tBQ3BDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FDRyxLQUFLLFNBQVUsUUFBUTtLQUN4QixJQUFJLFNBQVMsYUFDVCxJQUFJO01BQ0EsTUFBTSxTQUFTLE9BQU87S0FDMUIsU0FDTyxJQUFJLENBQUU7S0FDakIsT0FBTyxTQUFTLGFBQ1YsU0FDQSxNQUFNLFlBQVksS0FBSyxXQUFZO01BQUUsT0FBTztLQUFRLENBQUM7SUFDL0QsQ0FBQztHQUNMO0VBQ0o7RUFFQSxJQUFJLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksT0FBTyxhQUFhLEtBQUs7RUFDekMsSUFBSSxTQUFTO0VBQ2IsSUFBSSx1QkFBdUI7RUFDM0IsSUFBSSxrQkFBa0I7RUFDdEIsSUFBSSwwQkFBMEI7RUFDOUIsSUFBSSxhQUFhO0VBQ2pCLElBQUksV0FBVztFQUNmLElBQUksWUFBWTtFQUVoQixTQUFTLFFBQVEsU0FBUyxTQUFTO0dBQy9CLE9BQU8sVUFDRCxVQUNJLFdBQVk7SUFDVixPQUFRLFFBQVEsTUFBTSxNQUFNLFNBQVMsS0FBSyxRQUFRLE1BQU0sTUFBTSxTQUFTO0dBQzNFLElBQ0UsVUFDSjtFQUNWO0VBRUEsSUFBSSxXQUFXO0dBQ1gsTUFBTTtHQUNOLE9BQU87R0FDUCxXQUFXO0dBQ1gsT0FBTyxDQUFDLENBQUMsQ0FBQztHQUNWLFdBQVc7RUFDZjtFQUVBLFNBQVMsOEJBQThCLFNBQVM7R0FDNUMsT0FBTyxPQUFPLFlBQVksWUFBWSxDQUFDLEtBQUssS0FBSyxPQUFPLElBQ2xELFNBQVUsS0FBSztJQUNiLElBQUksSUFBSSxhQUFhLEtBQUEsS0FBYSxXQUFXLEtBQUs7S0FDOUMsTUFBTSxVQUFVLEdBQUc7S0FDbkIsT0FBTyxJQUFJO0lBQ2Y7SUFDQSxPQUFPO0dBQ1gsSUFDRSxTQUFVLEtBQUs7SUFBRSxPQUFPO0dBQUs7RUFDdkM7RUFFQSxTQUFTLFNBQVM7R0FDZCxNQUFNLFdBQVcsS0FBSyw0R0FBNEc7RUFDdEk7RUFFQSxTQUFTLElBQUksR0FBRyxHQUFHO0dBQ2YsSUFBSTtJQUNBLElBQUksS0FBSyxLQUFLLENBQUM7SUFDZixJQUFJLEtBQUssS0FBSyxDQUFDO0lBQ2YsSUFBSSxPQUFPLElBQUk7S0FDWCxJQUFJLE9BQU8sU0FDUCxPQUFPO0tBQ1gsSUFBSSxPQUFPLFNBQ1AsT0FBTztLQUNYLElBQUksT0FBTyxVQUNQLE9BQU87S0FDWCxJQUFJLE9BQU8sVUFDUCxPQUFPO0tBQ1gsSUFBSSxPQUFPLFVBQ1AsT0FBTztLQUNYLElBQUksT0FBTyxVQUNQLE9BQU87S0FDWCxJQUFJLE9BQU8sUUFDUCxPQUFPO0tBQ1gsSUFBSSxPQUFPLFFBQ1AsT0FBTztLQUNYLE9BQU87SUFDWDtJQUNBLFFBQVEsSUFBUjtLQUNJLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSyxVQUNELE9BQU8sSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUs7S0FDcEMsS0FBSyxVQUNELE9BQU8sbUJBQW1CLGNBQWMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxDQUFDO0tBRWhFLEtBQUssU0FDRCxPQUFPLGNBQWMsR0FBRyxDQUFDO0lBQ2pDO0dBQ0osU0FDTyxJQUFJLENBQUU7R0FDYixPQUFPO0VBQ1g7RUFDQSxTQUFTLGNBQWMsR0FBRyxHQUFHO0dBQ3pCLElBQUksS0FBSyxFQUFFO0dBQ1gsSUFBSSxLQUFLLEVBQUU7R0FDWCxJQUFJLElBQUksS0FBSyxLQUFLLEtBQUs7R0FDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRSxHQUFHO0lBQ3hCLElBQUksTUFBTSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUU7SUFDeEIsSUFBSSxRQUFRLEdBQ1IsT0FBTztHQUNmO0dBQ0EsT0FBTyxPQUFPLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSztFQUMxQztFQUNBLFNBQVMsbUJBQW1CLEdBQUcsR0FBRztHQUM5QixJQUFJLEtBQUssRUFBRTtHQUNYLElBQUksS0FBSyxFQUFFO0dBQ1gsSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLO0dBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FDckIsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUNYLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxLQUFLO0dBRWxDLE9BQU8sT0FBTyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUs7RUFDMUM7RUFDQSxTQUFTLEtBQUssR0FBRztHQUNiLElBQUksSUFBSSxPQUFPO0dBQ2YsSUFBSSxNQUFNLFVBQ04sT0FBTztHQUNYLElBQUksWUFBWSxPQUFPLENBQUMsR0FDcEIsT0FBTztHQUNYLElBQUksUUFBUSxZQUFZLENBQUM7R0FDekIsT0FBTyxVQUFVLGdCQUFnQixXQUFXO0VBQ2hEO0VBQ0EsU0FBUyxjQUFjLEdBQUc7R0FDdEIsSUFBSSxhQUFhLFlBQ2IsT0FBTztHQUNYLElBQUksWUFBWSxPQUFPLENBQUMsR0FDcEIsT0FBTyxJQUFJLFdBQVcsRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLFVBQVU7R0FDOUQsT0FBTyxJQUFJLFdBQVcsQ0FBQztFQUMzQjtFQUVBLFNBQVMsdUJBQXVCLE9BQU8sTUFBTSxLQUFLO0dBQzlDLElBQUksU0FBUyxNQUFNLE9BQU87R0FDMUIsSUFBSSxDQUFDLFFBQ0QsT0FBTztHQUNYLElBQUksUUFBUSxJQUFJLGNBQWMsR0FDMUIsT0FBTyxLQUFLLE9BQU8sU0FBVSxHQUFHLEdBQUc7SUFBRSxPQUFPLENBQUMsSUFBSSxTQUFTO0dBQUksQ0FBQztHQUNuRSxPQUFPLFFBQVEsSUFBSSxPQUFPLElBQUksU0FBVSxJQUFJO0lBQ3hDLElBQUksZUFBZSxHQUFHO0lBQ3RCLE9BQU8sT0FDRCxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsT0FBTyxJQUMzRCxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsQ0FBQyxNQUFNO0dBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFZO0lBQUUsT0FBTztHQUFLLENBQUM7RUFDeEM7RUFFQSxJQUFJLG1CQUFxQixXQUFZO0dBQ2pDLFNBQVMsaUJBQWlCLE1BQU07SUFDNUIsS0FBSyxlQUFlO0dBQ3hCO0dBQ0EsaUJBQWlCLFVBQVUsVUFBVSxTQUFVLE9BQU87SUFDbEQsSUFBSTtJQUNKLElBQUksT0FBTyxLQUFLO0lBQ2hCLElBQUksS0FBSyxRQUFRLEtBQUEsR0FBVztLQUN4QixJQUFJLE9BQU8sS0FBSztLQUNoQixJQUFJLFFBQVEsSUFBSSxHQUNaLE9BQU8sY0FBYyxjQUFjLENBQUMsR0FBSSxRQUFRLEtBQUssSUFBSSxRQUFRLENBQUMsR0FBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUMsQ0FBQyxLQUFLO0tBRWxHLElBQUksT0FBTyxTQUFTLFVBQ2hCLFFBQVEsT0FBTyxLQUFLLEtBQUssS0FBSztLQUNsQyxJQUFJLE9BQU8sU0FBUyxVQUNoQixJQUFJO01BQ0EsT0FBTyxPQUFPLEtBQUssSUFBSTtLQUMzQixTQUNPLElBQUk7TUFDUCxPQUFPLE9BQU8sQ0FBQyxJQUFJO0tBQ3ZCO0tBRUosTUFBTSxJQUFJLFVBQVUsZ0JBQWdCLE9BQU8sSUFBSSxDQUFDO0lBQ3BEO0lBQ0EsSUFBSSxLQUFLLFdBQVcsS0FBQSxHQUFXO0tBQzNCLElBQUksZUFBZSxLQUFLO0tBQ3hCLElBQUksUUFBUSxZQUFZLEdBQ3BCLE9BQU8sUUFBUSxLQUFLLElBQ2QsTUFBTSxPQUFPLFNBQVUsTUFBTTtNQUFFLE9BQU8sQ0FBQyxhQUFhLFNBQVMsSUFBSTtLQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFDNUUsQ0FBQztLQUVYLElBQUksT0FBTyxpQkFBaUIsVUFDeEIsT0FBTyxPQUFPLEtBQUssSUFBSTtLQUMzQixJQUFJLE9BQU8saUJBQWlCLFVBQ3hCLElBQUk7TUFDQSxPQUFPLE9BQU8sS0FBSyxJQUFJO0tBQzNCLFNBQ08sSUFBSTtNQUNQLE9BQU8sT0FBTyxDQUFDLElBQUk7S0FDdkI7S0FFSixNQUFNLElBQUksVUFBVSxzQkFBc0IsT0FBTyxZQUFZLENBQUM7SUFDbEU7SUFDQSxJQUFJLG1CQUFtQixLQUFLLEtBQUssbUJBQW1CLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUc7SUFDeEYsSUFBSSxtQkFDQSxPQUFPLFVBQVUsWUFDakIsTUFBTSxXQUFXLGVBQWUsR0FDaEMsT0FBTyxLQUFLLGNBQWMsS0FBSyxNQUFNLFVBQVUsZ0JBQWdCLE1BQU07SUFFekUsT0FBTztHQUNYO0dBQ0EsT0FBTztFQUNYLEVBQUU7RUFFRixTQUFTLGdCQUFnQixLQUFLLFNBQVM7R0FDbkMsSUFBSSxXQUFXLEtBQUssT0FBTztHQUMzQixJQUFJLFVBQVUsU0FBUztHQUN2QixJQUFJLG1CQUFtQjtHQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxFQUFFLEdBQUc7SUFDOUIsSUFBSSxVQUFVLFNBQVM7SUFDdkIsSUFBSSxRQUFRLFFBQVE7SUFDcEIsSUFBSSxZQUFZLGFBQWEsS0FBSyxPQUFPO0lBQ3pDLElBQUksaUJBQWlCLGtCQUFrQjtLQUNuQyxhQUFhLEtBQUssU0FBUyxNQUFNLFFBQVEsU0FBUyxDQUFDO0tBQ25ELG1CQUFtQjtJQUN2QixPQUNLLElBQUksY0FBYyxPQUFPO0tBQzFCLGFBQWEsS0FBSyxTQUFTLEtBQUs7S0FDaEMsbUJBQW1CO0lBQ3ZCO0dBQ0o7R0FDQSxPQUFPO0VBQ1g7RUFFQSxJQUFJLFFBQVUsV0FBWTtHQUN0QixTQUFTLFFBQVEsQ0FDakI7R0FDQSxNQUFNLFVBQVUsU0FBUyxTQUFVLE1BQU0sSUFBSSxhQUFhO0lBQ3RELElBQUksUUFBUSxLQUFLLE9BQU8sSUFBSTtJQUM1QixJQUFJLFlBQVksS0FBSztJQUNyQixJQUFJLE9BQU8sU0FDUCxPQUFPLFlBQVksZUFDbkIsUUFBUSxjQUNSLFFBQVEsV0FBVyxVQUFVLE9BQU8sU0FBUyxhQUFhLFNBQVMsU0FBUyxHQUFHLENBQUMsQ0FBQyxPQUFPLEtBQUssSUFBSSxDQUFDO0lBQ3RHLFNBQVMsd0JBQXdCLFNBQVMsUUFBUSxPQUFPO0tBQ3JELElBQUksQ0FBQyxNQUFNLE9BQU8sWUFDZCxNQUFNLElBQUksV0FBVyxTQUFTLFdBQVcsWUFBWSwwQkFBMEI7S0FDbkYsT0FBTyxHQUFHLE1BQU0sVUFBVSxLQUFLO0lBQ25DO0lBQ0EsSUFBSSxjQUFjLG9CQUFvQjtJQUN0QyxJQUFJO0tBQ0EsSUFBSSxJQUFJLFNBQVMsTUFBTSxHQUFHLFdBQVcsS0FBSyxHQUFHLFNBQ3ZDLFVBQVUsSUFBSSxRQUNWLE1BQU0sU0FBUyxNQUFNLHlCQUF5QixXQUFXLElBQ3pELFNBQVMsV0FBWTtNQUNuQixPQUFPLE1BQU0sU0FBUyxNQUFNLHlCQUF5QixXQUFXO0tBQ3BFLEdBQUc7TUFBUztNQUFPLFdBQVcsSUFBSSxhQUFhO0tBQUksQ0FBQyxJQUN0RCxnQkFBZ0IsS0FBSyxJQUFJLE1BQU0sQ0FBQyxLQUFLLElBQUksR0FBRyx1QkFBdUI7S0FDekUsSUFBSSxNQUFNO01BQ04sRUFBRSxlQUFlO01BQ2pCLElBQUksRUFBRSxNQUFNLFNBQVUsS0FBSztPQUN2QixRQUFRLE1BQU0sR0FBRztPQUNqQixPQUFPLFVBQVUsR0FBRztNQUN4QixDQUFDO0tBQ0w7S0FDQSxPQUFPO0lBQ1gsVUFDUTtLQUNKLElBQUksYUFDQSxrQkFBa0I7SUFDMUI7R0FDSjtHQUNBLE1BQU0sVUFBVSxNQUFNLFNBQVUsV0FBVyxJQUFJO0lBQzNDLElBQUksUUFBUTtJQUNaLElBQUksYUFBYSxVQUFVLGdCQUFnQixRQUN2QyxPQUFPLEtBQUssTUFBTSxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQUU7SUFDekMsSUFBSSxhQUFhLE1BQ2IsT0FBTyxVQUFVLElBQUksV0FBVyxLQUFLLGlDQUFpQyxDQUFDO0lBQzNFLE9BQU8sS0FBSyxPQUFPLFlBQVksU0FBVSxPQUFPO0tBQzVDLE9BQU8sTUFBTSxLQUNSLElBQUk7TUFBUztNQUFPLEtBQUs7S0FBVSxDQUFDLENBQUMsQ0FDckMsS0FBSyxTQUFVLEtBQUs7TUFBRSxPQUFPLE1BQU0sS0FBSyxRQUFRLEtBQUssR0FBRztLQUFHLENBQUM7SUFDckUsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO0dBQ2Q7R0FDQSxNQUFNLFVBQVUsUUFBUSxTQUFVLGFBQWE7SUFDM0MsSUFBSSxPQUFPLGdCQUFnQixVQUN2QixPQUFPLElBQUksS0FBSyxHQUFHLFlBQVksTUFBTSxXQUFXO0lBQ3BELElBQUksUUFBUSxXQUFXLEdBQ25CLE9BQU8sSUFBSSxLQUFLLEdBQUcsWUFBWSxNQUFNLElBQUksT0FBTyxZQUFZLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUMvRSxJQUFJLFdBQVcsS0FBSyxXQUFXO0lBQy9CLElBQUksU0FBUyxXQUFXLEdBQ3BCLE9BQU8sS0FBSyxNQUFNLFNBQVMsRUFBRSxDQUFDLENBQUMsT0FBTyxZQUFZLFNBQVMsR0FBRztJQUNsRSxJQUFJLGdCQUFnQixLQUFLLE9BQU8sUUFDM0IsT0FBTyxLQUFLLE9BQU8sT0FBTyxDQUFDLENBQzNCLE9BQU8sU0FBVSxJQUFJO0tBQ3RCLElBQUksR0FBRyxZQUNILFNBQVMsTUFBTSxTQUFVLFNBQVM7TUFBRSxPQUFPLEdBQUcsUUFBUSxRQUFRLE9BQU8sS0FBSztLQUFHLENBQUMsR0FBRztNQUNqRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEVBQUUsR0FDbkMsSUFBSSxTQUFTLFFBQVEsR0FBRyxRQUFRLEVBQUUsTUFBTSxJQUNwQyxPQUFPO01BRWYsT0FBTztLQUNYO0tBQ0EsT0FBTztJQUNYLENBQUMsQ0FBQyxDQUNHLEtBQUssU0FBVSxHQUFHLEdBQUc7S0FBRSxPQUFPLEVBQUUsUUFBUSxTQUFTLEVBQUUsUUFBUTtJQUFRLENBQUMsQ0FBQyxDQUFDO0lBQzNFLElBQUksaUJBQWlCLEtBQUssR0FBRyxZQUFZLFdBQVc7S0FDaEQsSUFBSSx1QkFBdUIsY0FBYyxRQUFRLE1BQU0sR0FBRyxTQUFTLE1BQU07S0FDekUsT0FBTyxLQUFLLE1BQU0sb0JBQW9CLENBQUMsQ0FBQyxPQUFPLHFCQUFxQixJQUFJLFNBQVUsSUFBSTtNQUFFLE9BQU8sWUFBWTtLQUFLLENBQUMsQ0FBQztJQUN0SDtJQUNBLElBQUksQ0FBQyxpQkFBaUIsT0FDbEIsUUFBUSxLQUFLLGFBQWEsT0FBTyxLQUFLLFVBQVUsV0FBVyxHQUFHLE1BQU0sQ0FBQyxDQUFDLE9BQU8sS0FBSyxNQUFNLHdCQUF3QixJQUM1RyxtQkFBbUIsT0FBTyxTQUFTLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUMxRCxJQUFJLFlBQVksS0FBSyxPQUFPO0lBQzVCLFNBQVMsT0FBTyxHQUFHLEdBQUc7S0FDbEIsT0FBTyxJQUFJLEdBQUcsQ0FBQyxNQUFNO0lBQ3pCO0lBQ0EsSUFBSSxLQUFLLFNBQVMsT0FBTyxTQUFVLElBQUksU0FBUztLQUM1QyxJQUFJLFlBQVksR0FBRyxJQUFJLGVBQWUsR0FBRztLQUN6QyxJQUFJLFFBQVEsVUFBVTtLQUN0QixJQUFJLFFBQVEsWUFBWTtLQUN4QixPQUFPLENBQ0gsYUFBYSxPQUNiLGFBQWEsQ0FBQyxRQUNSLFFBQVEsY0FBYyxTQUFTLE1BQU0sUUFDakMsU0FBVSxHQUFHO01BQ1gsSUFBSSxPQUFPLGFBQWEsR0FBRyxPQUFPO01BQ2xDLE9BQVEsUUFBUSxJQUFJLEtBQ2hCLEtBQUssS0FBSyxTQUFVLE1BQU07T0FBRSxPQUFPLE9BQU8sT0FBTyxJQUFJO01BQUcsQ0FBQztLQUNqRSxJQUNFLFNBQVUsR0FBRztNQUFFLE9BQU8sT0FBTyxPQUFPLGFBQWEsR0FBRyxPQUFPLENBQUM7S0FBRyxDQUFDLElBQ3BFLFlBQ1Y7SUFDSixHQUFHLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLEdBQUcsSUFBSSxpQkFBaUIsR0FBRztJQUNuRCxPQUFPLE1BQ0QsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLENBQ2pCLE9BQU8sWUFBWSxJQUFJLFFBQVEsQ0FBQyxDQUNoQyxPQUFPLGNBQWMsSUFDeEIsZ0JBQ0ksS0FBSyxPQUFPLGNBQWMsSUFDMUIsS0FBSyxNQUFNLFFBQVEsQ0FBQyxDQUFDLE9BQU8sRUFBRTtHQUM1QztHQUNBLE1BQU0sVUFBVSxTQUFTLFNBQVUsZ0JBQWdCO0lBQy9DLE9BQU8sS0FBSyxhQUFhLENBQUMsQ0FBQyxJQUFJLGNBQWM7R0FDakQ7R0FDQSxNQUFNLFVBQVUsUUFBUSxTQUFVLGNBQWM7SUFDNUMsT0FBTyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE1BQU0sWUFBWTtHQUNqRDtHQUNBLE1BQU0sVUFBVSxTQUFTLFNBQVUsUUFBUTtJQUN2QyxPQUFPLEtBQUssYUFBYSxDQUFDLENBQUMsT0FBTyxNQUFNO0dBQzVDO0dBQ0EsTUFBTSxVQUFVLFFBQVEsU0FBVSxTQUFTO0lBQ3ZDLE9BQU8sS0FBSyxhQUFhLENBQUMsQ0FBQyxNQUFNLE9BQU87R0FDNUM7R0FDQSxNQUFNLFVBQVUsT0FBTyxTQUFVLFVBQVU7SUFDdkMsT0FBTyxLQUFLLGFBQWEsQ0FBQyxDQUFDLEtBQUssUUFBUTtHQUM1QztHQUNBLE1BQU0sVUFBVSxVQUFVLFNBQVUsY0FBYztJQUM5QyxPQUFPLEtBQUssYUFBYSxDQUFDLENBQUMsUUFBUSxZQUFZO0dBQ25EO0dBQ0EsTUFBTSxVQUFVLGVBQWUsV0FBWTtJQUN2QyxPQUFPLElBQUksS0FBSyxHQUFHLFdBQVcsSUFBSSxLQUFLLEdBQUcsWUFBWSxJQUFJLENBQUM7R0FDL0Q7R0FDQSxNQUFNLFVBQVUsVUFBVSxTQUFVLE9BQU87SUFDdkMsT0FBTyxJQUFJLEtBQUssR0FBRyxXQUFXLElBQUksS0FBSyxHQUFHLFlBQVksTUFBTSxRQUFRLEtBQUssSUFBSSxJQUFJLE9BQU8sTUFBTSxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksS0FBSyxDQUFDO0dBQzFIO0dBQ0EsTUFBTSxVQUFVLFVBQVUsV0FBWTtJQUNsQyxPQUFPLEtBQUssYUFBYSxDQUFDLENBQUMsUUFBUTtHQUN2QztHQUNBLE1BQU0sVUFBVSxhQUFhLFNBQVUsYUFBYTtJQUNoRCxJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUcsSUFBSSxZQUFZLEdBQUc7SUFDMUMsS0FBSyxPQUFPLGNBQWM7SUFDMUIsSUFBSSxZQUFZLHFCQUFxQixRQUNqQyxjQUFnQixTQUFVLFFBQVE7S0FDOUIsVUFBVSxTQUFTLE1BQU07S0FDekIsU0FBUyxVQUFVO01BQ2YsT0FBTyxXQUFXLFFBQVEsT0FBTyxNQUFNLE1BQU0sU0FBUyxLQUFLO0tBQy9EO0tBQ0EsT0FBTyxlQUFlLFFBQVEsV0FBVyxNQUFNO01BQzNDLEtBQUssV0FBWTtPQUNiLE9BQU87TUFDWDtNQUNBLFlBQVk7TUFDWixjQUFjO0tBQ2xCLENBQUM7S0FDRCxRQUFRLFVBQVUsUUFBUSxXQUFZO01BQ2xDLE9BQU87S0FDWDtLQUNBLE9BQU87SUFDWCxFQUFFLFdBQVc7SUFFakIsSUFBSSxpQ0FBaUIsSUFBSSxJQUFJO0lBQzdCLEtBQUssSUFBSSxRQUFRLFlBQVksV0FBVyxPQUFPLFFBQVEsU0FBUyxLQUFLLEdBQ2pFLE9BQU8sb0JBQW9CLEtBQUssQ0FBQyxDQUFDLFFBQVEsU0FBVSxVQUFVO0tBQzFELE9BQU8sZUFBZSxJQUFJLFFBQVE7SUFDdEMsQ0FBQztJQUVMLElBQUksV0FBVyxTQUFVLEtBQUs7S0FDMUIsSUFBSSxDQUFDLEtBQ0QsT0FBTztLQUNYLElBQUksTUFBTSxPQUFPLE9BQU8sWUFBWSxTQUFTO0tBQzdDLEtBQUssSUFBSSxLQUFLLEtBQ1YsSUFBSSxDQUFDLGVBQWUsSUFBSSxDQUFDLEdBQ3JCLElBQUk7TUFDQSxJQUFJLEtBQUssSUFBSTtLQUNqQixTQUNPLEdBQUcsQ0FBRTtLQUNwQixPQUFPO0lBQ1g7SUFDQSxJQUFJLEtBQUssT0FBTyxVQUNaLEtBQUssS0FBSyxRQUFRLFlBQVksS0FBSyxPQUFPLFFBQVE7SUFFdEQsS0FBSyxPQUFPLFdBQVc7SUFDdkIsS0FBSyxLQUFLLFdBQVcsUUFBUTtJQUM3QixPQUFPO0dBQ1g7R0FDQSxNQUFNLFVBQVUsY0FBYyxXQUFZO0lBQ3RDLFNBQVMsTUFBTSxTQUFTO0tBQ3BCLE9BQU8sTUFBTSxPQUFPO0lBQ3hCO0lBQ0EsT0FBTyxLQUFLLFdBQVcsS0FBSztHQUNoQztHQUNBLE1BQU0sVUFBVSxNQUFNLFNBQVUsS0FBSyxLQUFLO0lBQ3RDLElBQUksUUFBUTtJQUNaLElBQUksS0FBSyxLQUFLLE9BQU8sU0FBUyxPQUFPLEdBQUcsTUFBTSxVQUFVLEdBQUc7SUFDM0QsSUFBSSxXQUFXO0lBQ2YsSUFBSSxXQUFXLE1BQ1gsV0FBVyw4QkFBOEIsT0FBTyxDQUFDLENBQUMsR0FBRztJQUV6RCxPQUFPLEtBQUssT0FBTyxhQUFhLFNBQVUsT0FBTztLQUM3QyxPQUFPLE1BQU0sS0FBSyxPQUFPO01BQ2Q7TUFDUCxNQUFNO01BQ04sTUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFHLElBQUk7TUFDNUIsUUFBUSxDQUFDLFFBQVE7S0FDckIsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUNHLEtBQUssU0FBVSxLQUFLO0tBQ3JCLE9BQU8sSUFBSSxjQUFjLGFBQWEsT0FBTyxJQUFJLFNBQVMsRUFBRSxJQUFJLElBQUk7SUFDeEUsQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLFlBQVk7S0FDNUIsSUFBSSxTQUNBLElBQUk7TUFDQSxhQUFhLEtBQUssU0FBUyxVQUFVO0tBQ3pDLFNBQ08sR0FBRyxDQUFFO0tBRWhCLE9BQU87SUFDWCxDQUFDO0dBQ0w7R0FDQSxNQUFNLFVBQVUsU0FBUyxTQUFVLEtBQUssZUFBZTtJQUNuRCxJQUFJLFFBQVE7SUFDWixJQUFJLFVBQVUsS0FBSyxPQUFPLFFBQVE7SUFDbEMsT0FBTyxLQUFLLE9BQU8sYUFBYSxTQUFVLE9BQU87S0FDN0MsT0FBTyxNQUFNLEtBQUssSUFBSTtNQUFTO01BQVk7S0FBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVUsVUFBVTtNQUN2RSxJQUFJLE1BQU0sYUFBYSxRQUFRLGFBQWEsS0FBSyxJQUFJLFdBQVcsQ0FBQztNQUNqRSxnQkFBZ0IsS0FBSyxhQUFhO01BQ2xDLElBQUksU0FDQSxhQUFhLEtBQUssU0FBUyxHQUFHO01BQ2xDLE9BQU8sTUFBTSxLQUNSLE9BQU87T0FDRDtPQUNQLE1BQU07T0FDTixRQUFRLENBQUMsR0FBRztPQUNaLE1BQU0sQ0FBQyxHQUFHO09BQ1YsUUFBUTtPQUNSLFNBQVM7UUFBRSxNQUFNLENBQUMsR0FBRztRQUFHLGFBQWEsQ0FBQyxhQUFhO09BQUU7TUFDekQsQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLEtBQUs7T0FDckIsT0FBTyxJQUFJLGNBQWMsYUFBYSxPQUFPLElBQUksU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO01BQ3RFLENBQUM7S0FDTCxDQUFDO0lBQ0wsQ0FBQztHQUNMO0dBQ0EsTUFBTSxVQUFVLFNBQVMsU0FBVSxhQUFhLGVBQWU7SUFDM0QsSUFBSSxPQUFPLGdCQUFnQixZQUFZLENBQUMsUUFBUSxXQUFXLEdBQUc7S0FDMUQsSUFBSSxNQUFNLGFBQWEsYUFBYSxLQUFLLE9BQU8sUUFBUSxPQUFPO0tBQy9ELElBQUksUUFBUSxLQUFBLEdBQ1IsT0FBTyxVQUFVLElBQUksV0FBVyxnQkFBZ0IsK0NBQStDLENBQUM7S0FDcEcsT0FBTyxLQUFLLE1BQU0sS0FBSyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxPQUFPLGFBQWE7SUFDN0QsT0FFSSxPQUFPLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQyxPQUFPLFdBQVcsQ0FBQyxDQUFDLE9BQU8sYUFBYTtHQUV6RTtHQUNBLE1BQU0sVUFBVSxNQUFNLFNBQVUsS0FBSyxLQUFLO0lBQ3RDLElBQUksUUFBUTtJQUNaLElBQUksS0FBSyxLQUFLLE9BQU8sU0FBUyxPQUFPLEdBQUcsTUFBTSxVQUFVLEdBQUc7SUFDM0QsSUFBSSxXQUFXO0lBQ2YsSUFBSSxXQUFXLE1BQ1gsV0FBVyw4QkFBOEIsT0FBTyxDQUFDLENBQUMsR0FBRztJQUV6RCxPQUFPLEtBQUssT0FBTyxhQUFhLFNBQVUsT0FBTztLQUM3QyxPQUFPLE1BQU0sS0FBSyxPQUFPO01BQ2Q7TUFDUCxNQUFNO01BQ04sUUFBUSxDQUFDLFFBQVE7TUFDakIsTUFBTSxPQUFPLE9BQU8sQ0FBQyxHQUFHLElBQUk7S0FDaEMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUNHLEtBQUssU0FBVSxLQUFLO0tBQ3JCLE9BQU8sSUFBSSxjQUFjLGFBQWEsT0FBTyxJQUFJLFNBQVMsRUFBRSxJQUFJLElBQUk7SUFDeEUsQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLFlBQVk7S0FDNUIsSUFBSSxTQUNBLElBQUk7TUFDQSxhQUFhLEtBQUssU0FBUyxVQUFVO0tBQ3pDLFNBQ08sR0FBRyxDQUFFO0tBRWhCLE9BQU87SUFDWCxDQUFDO0dBQ0w7R0FDQSxNQUFNLFVBQVUsU0FBUyxTQUFVLEtBQUs7SUFDcEMsSUFBSSxRQUFRO0lBQ1osT0FBTyxLQUFLLE9BQU8sYUFBYSxTQUFVLE9BQU87S0FDN0MsT0FBTyxNQUFNLEtBQ1IsT0FBTztNQUFTO01BQU8sTUFBTTtNQUFVLE1BQU0sQ0FBQyxHQUFHO0tBQUUsQ0FBQyxDQUFDLENBQ3JELEtBQUssU0FBVSxLQUFLO01BQUUsT0FBTyx1QkFBdUIsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHO0tBQUcsQ0FBQyxDQUFDLENBQzFFLEtBQUssU0FBVSxLQUFLO01BQ3JCLE9BQU8sSUFBSSxjQUFjLGFBQWEsT0FBTyxJQUFJLFNBQVMsRUFBRSxJQUFJLEtBQUE7S0FDcEUsQ0FBQztJQUNMLENBQUM7R0FDTDtHQUNBLE1BQU0sVUFBVSxRQUFRLFdBQVk7SUFDaEMsSUFBSSxRQUFRO0lBQ1osT0FBTyxLQUFLLE9BQU8sYUFBYSxTQUFVLE9BQU87S0FDN0MsT0FBTyxNQUFNLEtBQ1IsT0FBTztNQUFTO01BQU8sTUFBTTtNQUFlLE9BQU87S0FBUyxDQUFDLENBQUMsQ0FDOUQsS0FBSyxTQUFVLEtBQUs7TUFBRSxPQUFPLHVCQUF1QixPQUFPLE1BQU0sR0FBRztLQUFHLENBQUM7SUFDakYsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLEtBQUs7S0FDbkIsT0FBTyxJQUFJLGNBQWMsYUFBYSxPQUFPLElBQUksU0FBUyxFQUFFLElBQUksS0FBQTtJQUNwRSxDQUFDO0dBQ0w7R0FDQSxNQUFNLFVBQVUsVUFBVSxTQUFVLE1BQU07SUFDdEMsSUFBSSxRQUFRO0lBQ1osT0FBTyxLQUFLLE9BQU8sWUFBWSxTQUFVLE9BQU87S0FDNUMsT0FBTyxNQUFNLEtBQ1IsUUFBUTtNQUNIO01BQ0M7S0FDWCxDQUFDLENBQUMsQ0FDRyxLQUFLLFNBQVUsUUFBUTtNQUFFLE9BQU8sT0FBTyxJQUFJLFNBQVUsS0FBSztPQUFFLE9BQU8sTUFBTSxLQUFLLFFBQVEsS0FBSyxHQUFHO01BQUcsQ0FBQztLQUFHLENBQUM7SUFDL0csQ0FBQztHQUNMO0dBQ0EsTUFBTSxVQUFVLFVBQVUsU0FBVSxTQUFTLGVBQWUsU0FBUztJQUNqRSxJQUFJLFFBQVE7SUFDWixJQUFJLE9BQU8sTUFBTSxRQUFRLGFBQWEsSUFBSSxnQkFBZ0IsS0FBQTtJQUMxRCxVQUNJLFlBQVksT0FBTyxLQUFBLElBQVk7SUFDbkMsSUFBSSxjQUFjLFVBQVUsUUFBUSxVQUFVLEtBQUE7SUFDOUMsT0FBTyxLQUFLLE9BQU8sYUFBYSxTQUFVLE9BQU87S0FDN0MsSUFBSSxLQUFLLE1BQU0sT0FBTyxTQUFTLE9BQU8sR0FBRyxNQUFNLFVBQVUsR0FBRztLQUM1RCxJQUFJLFdBQVcsTUFDWCxNQUFNLElBQUksV0FBVyxnQkFBZ0IsOERBQThEO0tBQ3ZHLElBQUksUUFBUSxLQUFLLFdBQVcsUUFBUSxRQUNoQyxNQUFNLElBQUksV0FBVyxnQkFBZ0Isc0RBQXNEO0tBQy9GLElBQUksYUFBYSxRQUFRO0tBQ3pCLElBQUksZUFBZSxXQUFXLE9BQ3hCLFFBQVEsSUFBSSw4QkFBOEIsT0FBTyxDQUFDLElBQ2xEO0tBQ04sT0FBTyxNQUFNLEtBQ1IsT0FBTztNQUNEO01BQ1AsTUFBTTtNQUNBO01BQ04sUUFBUTtNQUNLO0tBQ2pCLENBQUMsQ0FBQyxDQUNHLEtBQUssU0FBVSxJQUFJO01BQ3BCLElBQUksY0FBYyxHQUFHLGFBQWEsVUFBVSxHQUFHLFNBQVMsYUFBYSxHQUFHLFlBQVksV0FBVyxHQUFHO01BQ2xHLElBQUksU0FBUyxjQUFjLFVBQVU7TUFDckMsSUFBSSxnQkFBZ0IsR0FDaEIsT0FBTztNQUNYLE1BQU0sSUFBSSxVQUFVLEdBQUcsT0FBTyxNQUFNLE1BQU0sY0FBYyxDQUFDLENBQUMsT0FBTyxhQUFhLE1BQU0sQ0FBQyxDQUFDLE9BQU8sWUFBWSxvQkFBb0IsR0FBRyxRQUFRO0tBQzVJLENBQUM7SUFDTCxDQUFDO0dBQ0w7R0FDQSxNQUFNLFVBQVUsVUFBVSxTQUFVLFNBQVMsZUFBZSxTQUFTO0lBQ2pFLElBQUksUUFBUTtJQUNaLElBQUksT0FBTyxNQUFNLFFBQVEsYUFBYSxJQUFJLGdCQUFnQixLQUFBO0lBQzFELFVBQ0ksWUFBWSxPQUFPLEtBQUEsSUFBWTtJQUNuQyxJQUFJLGNBQWMsVUFBVSxRQUFRLFVBQVUsS0FBQTtJQUM5QyxPQUFPLEtBQUssT0FBTyxhQUFhLFNBQVUsT0FBTztLQUM3QyxJQUFJLEtBQUssTUFBTSxPQUFPLFNBQVMsT0FBTyxHQUFHLE1BQU0sVUFBVSxHQUFHO0tBQzVELElBQUksV0FBVyxNQUNYLE1BQU0sSUFBSSxXQUFXLGdCQUFnQiw4REFBOEQ7S0FDdkcsSUFBSSxRQUFRLEtBQUssV0FBVyxRQUFRLFFBQ2hDLE1BQU0sSUFBSSxXQUFXLGdCQUFnQixzREFBc0Q7S0FDL0YsSUFBSSxhQUFhLFFBQVE7S0FDekIsSUFBSSxlQUFlLFdBQVcsT0FDeEIsUUFBUSxJQUFJLDhCQUE4QixPQUFPLENBQUMsSUFDbEQ7S0FDTixPQUFPLE1BQU0sS0FDUixPQUFPO01BQ0Q7TUFDUCxNQUFNO01BQ0E7TUFDTixRQUFRO01BQ0s7S0FDakIsQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLElBQUk7TUFDcEIsSUFBSSxjQUFjLEdBQUcsYUFBYSxVQUFVLEdBQUcsU0FBUyxhQUFhLEdBQUcsWUFBWSxXQUFXLEdBQUc7TUFDbEcsSUFBSSxTQUFTLGNBQWMsVUFBVTtNQUNyQyxJQUFJLGdCQUFnQixHQUNoQixPQUFPO01BQ1gsTUFBTSxJQUFJLFVBQVUsR0FBRyxPQUFPLE1BQU0sTUFBTSxjQUFjLENBQUMsQ0FBQyxPQUFPLGFBQWEsTUFBTSxDQUFDLENBQUMsT0FBTyxZQUFZLG9CQUFvQixHQUFHLFFBQVE7S0FDNUksQ0FBQztJQUNMLENBQUM7R0FDTDtHQUNBLE1BQU0sVUFBVSxhQUFhLFNBQVUsZ0JBQWdCO0lBQ25ELElBQUksUUFBUTtJQUNaLElBQUksWUFBWSxLQUFLO0lBQ3JCLElBQUksT0FBTyxlQUFlLElBQUksU0FBVSxPQUFPO0tBQUUsT0FBTyxNQUFNO0lBQUssQ0FBQztJQUNwRSxJQUFJLGNBQWMsZUFBZSxJQUFJLFNBQVUsT0FBTztLQUFFLE9BQU8sTUFBTTtJQUFTLENBQUM7SUFDL0UsSUFBSSxZQUFZLENBQUM7SUFDakIsT0FBTyxLQUFLLE9BQU8sYUFBYSxTQUFVLE9BQU87S0FDN0MsT0FBTyxVQUFVLFFBQVE7TUFBUztNQUFhO01BQU0sT0FBTztLQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBVSxNQUFNO01BQ3hGLElBQUksYUFBYSxDQUFDO01BQ2xCLElBQUksYUFBYSxDQUFDO01BQ2xCLGVBQWUsUUFBUSxTQUFVLElBQUksS0FBSztPQUN0QyxJQUFJLE1BQU0sR0FBRyxLQUFLLFVBQVUsR0FBRztPQUMvQixJQUFJLE1BQU0sS0FBSztPQUNmLElBQUksS0FBSztRQUNMLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxPQUFPLEtBQUssT0FBTyxHQUFHLEtBQUssR0FBRyxRQUFRLE1BQU07U0FDOUQsSUFBSSxVQUFVLEdBQUc7U0FDakIsSUFBSSxRQUFRLFFBQVE7U0FDcEIsSUFBSSxZQUFZLE1BQU0sT0FBTyxRQUFRLFNBQzdCO2NBQUEsSUFBSSxPQUFPLEdBQUcsTUFBTSxHQUNwQixNQUFNLElBQUksV0FBVyxXQUFXLDJDQUEyQztTQUFBLE9BSS9FLGFBQWEsS0FBSyxTQUFTLEtBQUs7UUFFeEM7UUFDQSxVQUFVLEtBQUssR0FBRztRQUNsQixXQUFXLEtBQUssR0FBRztRQUNuQixXQUFXLEtBQUssR0FBRztPQUN2QjtNQUNKLENBQUM7TUFDRCxJQUFJLGFBQWEsV0FBVztNQUM1QixPQUFPLFVBQ0YsT0FBTztPQUNEO09BQ1AsTUFBTTtPQUNOLE1BQU07T0FDTixRQUFRO09BQ1IsU0FBUztRQUNDO1FBQ087T0FDakI7TUFDSixDQUFDLENBQUMsQ0FDRyxLQUFLLFNBQVUsSUFBSTtPQUNwQixJQUFJLGNBQWMsR0FBRyxhQUFhLFdBQVcsR0FBRztPQUNoRCxJQUFJLGdCQUFnQixHQUNoQixPQUFPO09BQ1gsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLE9BQU8sS0FBSyxRQUFRLEdBQUcsS0FBSyxHQUFHLFFBQVEsTUFBTTtRQUMvRCxJQUFJLFNBQVMsR0FBRztRQUNoQixJQUFJLGVBQWUsVUFBVSxPQUFPLE1BQU07UUFDMUMsSUFBSSxnQkFBZ0IsTUFBTTtTQUN0QixJQUFJLFVBQVUsU0FBUztTQUN2QixPQUFPLFNBQVM7U0FDaEIsU0FBUyxnQkFBZ0I7UUFDN0I7T0FDSjtPQUNBLE1BQU0sSUFBSSxVQUFVLEdBQUcsT0FBTyxNQUFNLE1BQU0saUJBQWlCLENBQUMsQ0FBQyxPQUFPLGFBQWEsTUFBTSxDQUFDLENBQUMsT0FBTyxZQUFZLG9CQUFvQixHQUFHLFFBQVE7TUFDL0ksQ0FBQztLQUNMLENBQUM7SUFDTCxDQUFDO0dBQ0w7R0FDQSxNQUFNLFVBQVUsYUFBYSxTQUFVLE1BQU07SUFDekMsSUFBSSxRQUFRO0lBQ1osSUFBSSxVQUFVLEtBQUs7SUFDbkIsT0FBTyxLQUFLLE9BQU8sYUFBYSxTQUFVLE9BQU87S0FDN0MsT0FBTyxNQUFNLEtBQ1IsT0FBTztNQUFTO01BQU8sTUFBTTtNQUFnQjtLQUFLLENBQUMsQ0FBQyxDQUNwRCxLQUFLLFNBQVUsS0FBSztNQUFFLE9BQU8sdUJBQXVCLE9BQU8sTUFBTSxHQUFHO0tBQUcsQ0FBQztJQUNqRixDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVUsSUFBSTtLQUNsQixJQUFJLGNBQWMsR0FBRyxhQUFhLGFBQWEsR0FBRyxZQUFZLFdBQVcsR0FBRztLQUM1RSxJQUFJLGdCQUFnQixHQUNoQixPQUFPO0tBQ1gsTUFBTSxJQUFJLFVBQVUsR0FBRyxPQUFPLE1BQU0sTUFBTSxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sYUFBYSxNQUFNLENBQUMsQ0FBQyxPQUFPLFNBQVMsb0JBQW9CLEdBQUcsUUFBUTtJQUM1SSxDQUFDO0dBQ0w7R0FDQSxPQUFPO0VBQ1gsRUFBRTtFQUVGLFNBQVMsT0FBTyxLQUFLO0dBQ2pCLElBQUksTUFBTSxDQUFDO0dBQ1gsSUFBSSxLQUFLLFNBQVUsV0FBVyxZQUFZO0lBQ3RDLElBQUksWUFBWTtLQUNaLElBQUksSUFBSSxVQUFVLFFBQVEsT0FBTyxJQUFJLE1BQU0sSUFBSSxDQUFDO0tBQ2hELE9BQU8sRUFBRSxHQUNMLEtBQUssSUFBSSxLQUFLLFVBQVU7S0FDNUIsSUFBSSxVQUFVLENBQUMsVUFBVSxNQUFNLE1BQU0sSUFBSTtLQUN6QyxPQUFPO0lBQ1gsT0FDSyxJQUFJLE9BQU8sY0FBYyxVQUMxQixPQUFPLElBQUk7R0FFbkI7R0FDQSxHQUFHLGVBQWU7R0FDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxJQUFJLEdBQUcsRUFBRSxHQUMzQyxJQUFJLFVBQVUsRUFBRTtHQUVwQixPQUFPO0dBQ1AsU0FBUyxJQUFJLFdBQVcsZUFBZSxpQkFBaUI7SUFDcEQsSUFBSSxPQUFPLGNBQWMsVUFDckIsT0FBTyxvQkFBb0IsU0FBUztJQUN4QyxJQUFJLENBQUMsZUFDRCxnQkFBZ0I7SUFDcEIsSUFBSSxDQUFDLGlCQUNELGtCQUFrQjtJQUN0QixJQUFJLFVBQVU7S0FDVixhQUFhLENBQUM7S0FDZCxNQUFNO0tBQ04sV0FBVyxTQUFVLElBQUk7TUFDckIsSUFBSSxRQUFRLFlBQVksUUFBUSxFQUFFLE1BQU0sSUFBSTtPQUN4QyxRQUFRLFlBQVksS0FBSyxFQUFFO09BQzNCLFFBQVEsT0FBTyxjQUFjLFFBQVEsTUFBTSxFQUFFO01BQ2pEO0tBQ0o7S0FDQSxhQUFhLFNBQVUsSUFBSTtNQUN2QixRQUFRLGNBQWMsUUFBUSxZQUFZLE9BQU8sU0FBVSxJQUFJO09BQzNELE9BQU8sT0FBTztNQUNsQixDQUFDO01BQ0QsUUFBUSxPQUFPLFFBQVEsWUFBWSxPQUFPLGVBQWUsZUFBZTtLQUM1RTtJQUNKO0lBQ0EsSUFBSSxhQUFhLEdBQUcsYUFBYTtJQUNqQyxPQUFPO0dBQ1g7R0FDQSxTQUFTLG9CQUFvQixLQUFLO0lBQzlCLEtBQUssR0FBRyxDQUFDLENBQUMsUUFBUSxTQUFVLFdBQVc7S0FDbkMsSUFBSSxPQUFPLElBQUk7S0FDZixJQUFJLFFBQVEsSUFBSSxHQUNaLElBQUksV0FBVyxJQUFJLFVBQVUsQ0FBQyxJQUFJLElBQUksVUFBVSxDQUFDLEVBQUU7VUFFbEQsSUFBSSxTQUFTLFFBQ2QsSUFBSSxVQUFVLElBQUksV0FBVyxRQUFRLFNBQVMsT0FBTztNQUNqRCxJQUFJLElBQUksVUFBVSxRQUFRLE9BQU8sSUFBSSxNQUFNLENBQUM7TUFDNUMsT0FBTyxLQUNILEtBQUssS0FBSyxVQUFVO01BQ3hCLFFBQVEsWUFBWSxRQUFRLFNBQVUsSUFBSTtPQUN0QyxPQUFPLFNBQVMsWUFBWTtRQUN4QixHQUFHLE1BQU0sTUFBTSxJQUFJO09BQ3ZCLENBQUM7TUFDTCxDQUFDO0tBQ0wsQ0FBQztVQUdELE1BQU0sSUFBSSxXQUFXLGdCQUFnQixzQkFBc0I7SUFDbkUsQ0FBQztHQUNMO0VBQ0o7RUFFQSxTQUFTLHFCQUFxQixXQUFXLGFBQWE7R0FDbEQsT0FBTyxXQUFXLENBQUMsQ0FBQyxLQUFLLEVBQWEsVUFBVSxDQUFDO0dBQ2pELE9BQU87RUFDWDtFQUVBLFNBQVMsdUJBQXVCLElBQUk7R0FDaEMsT0FBTyxxQkFBcUIsTUFBTSxXQUFXLFNBQVMsTUFBTSxNQUFNLGFBQWEsT0FBTztJQUNsRixLQUFLLEtBQUs7SUFDVixLQUFLLE1BQU07SUFDWCxLQUFLLE9BQU87SUFDWixLQUFLLFNBQVM7SUFDZCxLQUFLLE9BQU8sR0FBRyxXQUFXLFFBQ3BCLEdBQUcsV0FBVyxLQUFLLENBQUMsT0FDcEIsT0FBTyxNQUFNO0tBQ1gsVUFBVSxDQUFDLG1CQUFtQixHQUFHO0tBQ2pDLFNBQVMsQ0FBQyxtQkFBbUIsTUFBTTtLQUNuQyxVQUFVLENBQUMsbUJBQW1CLEdBQUc7S0FDakMsVUFBVSxDQUFDLG1CQUFtQixHQUFHO0lBQ3JDLENBQUM7R0FDVCxDQUFDO0VBQ0w7RUFFQSxTQUFTLGdCQUFnQixLQUFLLG1CQUFtQjtHQUM3QyxPQUFRLEVBQUUsSUFBSSxVQUFVLElBQUksYUFBYSxJQUFJLFFBQ3hDLG9CQUFvQixJQUFJLFlBQVksQ0FBQyxJQUFJO0VBQ2xEO0VBQ0EsU0FBUyxVQUFVLEtBQUssSUFBSTtHQUN4QixJQUFJLFNBQVMsUUFBUSxJQUFJLFFBQVEsRUFBRTtFQUN2QztFQUNBLFNBQVMsZ0JBQWdCLEtBQUssU0FBUyxlQUFlO0dBQ2xELElBQUksT0FBTyxJQUFJO0dBQ2YsSUFBSSxlQUFlLE9BQU8sV0FBWTtJQUFFLE9BQU8sUUFBUSxLQUFLLEdBQUcsUUFBUSxDQUFDO0dBQUcsSUFBSTtHQUMvRSxJQUFJLFlBQVksaUJBQWlCLENBQUM7RUFDdEM7RUFDQSxTQUFTLGVBQWUsS0FBSyxJQUFJO0dBQzdCLElBQUksVUFBVSxRQUFRLElBQUksU0FBUyxFQUFFO0VBQ3pDO0VBQ0EsU0FBUyxnQkFBZ0IsS0FBSyxZQUFZO0dBQ3RDLElBQUksSUFBSSxXQUNKLE9BQU8sV0FBVztHQUN0QixJQUFJLFFBQVEsV0FBVyxrQkFBa0IsSUFBSSxLQUFLO0dBQ2xELElBQUksQ0FBQyxPQUNELE1BQU0sSUFBSSxXQUFXLE9BQU8sYUFDeEIsSUFBSSxRQUNKLHNCQUNBLFdBQVcsT0FDWCxpQkFBaUI7R0FDekIsT0FBTztFQUNYO0VBQ0EsU0FBUyxXQUFXLEtBQUssV0FBVyxPQUFPO0dBQ3ZDLElBQUksUUFBUSxnQkFBZ0IsS0FBSyxVQUFVLE1BQU07R0FDakQsT0FBTyxVQUFVLFdBQVc7SUFDakI7SUFDUCxRQUFRLENBQUMsSUFBSTtJQUNiLFNBQVMsSUFBSSxRQUFRO0lBQ3JCLFFBQVEsQ0FBQyxDQUFDLElBQUk7SUFDZCxPQUFPO0tBQ0k7S0FDUCxPQUFPLElBQUk7SUFDZjtHQUNKLENBQUM7RUFDTDtFQUNBLFNBQVMsS0FBSyxLQUFLLElBQUksV0FBVyxXQUFXO0dBQ3pDLElBQUksU0FBUyxJQUFJLGVBQ1gsUUFBUSxJQUFJLFFBQVEsSUFBSSxhQUFhLENBQUMsSUFDdEMsSUFBSTtHQUNWLElBQUksQ0FBQyxJQUFJLElBQ0wsT0FBTyxRQUFRLFdBQVcsS0FBSyxXQUFXLFNBQVMsR0FBRyxRQUFRLElBQUksV0FBVyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksWUFBWSxJQUFJLFdBQVc7UUFFekg7SUFDRCxJQUFJLFFBQVEsQ0FBQztJQUNiLElBQUksUUFBUSxTQUFVLE1BQU0sUUFBUSxTQUFTO0tBQ3pDLElBQUksQ0FBQyxVQUNELE9BQU8sUUFBUSxTQUFTLFNBQVUsUUFBUTtNQUFFLE9BQU8sT0FBTyxLQUFLLE1BQU07S0FBRyxHQUFHLFNBQVUsS0FBSztNQUFFLE9BQU8sT0FBTyxLQUFLLEdBQUc7S0FBRyxDQUFDLEdBQUc7TUFDekgsSUFBSSxhQUFhLE9BQU87TUFDeEIsSUFBSSxNQUFNLEtBQUs7TUFDZixJQUFJLFFBQVEsd0JBQ1IsTUFBTSxLQUFLLElBQUksV0FBVyxVQUFVO01BQ3hDLElBQUksQ0FBQyxPQUFPLE9BQU8sR0FBRyxHQUFHO09BQ3JCLE1BQU0sT0FBTztPQUNiLEdBQUcsTUFBTSxRQUFRLE9BQU87TUFDNUI7S0FDSjtJQUNKO0lBQ0EsT0FBTyxRQUFRLElBQUksQ0FDZixJQUFJLEdBQUcsU0FBUyxPQUFPLFNBQVMsR0FDaEMsUUFBUSxXQUFXLEtBQUssV0FBVyxTQUFTLEdBQUcsSUFBSSxXQUFXLE9BQU8sQ0FBQyxJQUFJLFlBQVksSUFBSSxXQUFXLENBQ3pHLENBQUM7R0FDTDtFQUNKO0VBQ0EsU0FBUyxRQUFRLGVBQWUsUUFBUSxJQUFJLGFBQWE7R0FFckQsSUFBSSxZQUFZLEtBREQsY0FBYyxTQUFVLEdBQUcsR0FBRyxHQUFHO0lBQUUsT0FBTyxHQUFHLFlBQVksQ0FBQyxHQUFHLEdBQUcsQ0FBQztHQUFHLElBQUksRUFDMUQ7R0FDN0IsT0FBTyxjQUFjLEtBQUssU0FBVSxRQUFRO0lBQ3hDLElBQUksUUFDQSxPQUFPLE9BQU8sTUFBTSxXQUFZO0tBQzVCLElBQUksSUFBSSxXQUFZO01BQUUsT0FBTyxPQUFPLFNBQVM7S0FBRztLQUNoRCxJQUFJLENBQUMsVUFDRCxPQUFPLFFBQVEsU0FBVSxVQUFVO01BQUUsT0FBUSxJQUFJO0tBQVcsR0FBRyxTQUFVLEtBQUs7TUFDMUUsT0FBTyxLQUFLLEdBQUc7TUFDZixJQUFJO0tBQ1IsR0FBRyxTQUFVLEdBQUc7TUFDWixPQUFPLEtBQUssQ0FBQztNQUNiLElBQUk7S0FDUixDQUFDLEdBQ0QsVUFBVSxPQUFPLE9BQU8sUUFBUSxTQUFVLFVBQVU7TUFBRSxPQUFRLElBQUk7S0FBVyxDQUFDO0tBQ2xGLEVBQUU7SUFDTixDQUFDO0dBRVQsQ0FBQztFQUNMO0VBRUEsSUFBSSxhQUFlLFdBQVk7R0FDM0IsU0FBUyxhQUFhLENBQ3RCO0dBQ0EsV0FBVyxVQUFVLFFBQVEsU0FBVSxJQUFJLElBQUk7SUFDM0MsSUFBSSxNQUFNLEtBQUs7SUFDZixPQUFPLElBQUksUUFDTCxJQUFJLE1BQU0sT0FBTyxNQUFNLFVBQVUsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDLElBQ3RELElBQUksTUFBTSxPQUFPLFlBQVksRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFO0dBQ2xEO0dBQ0EsV0FBVyxVQUFVLFNBQVMsU0FBVSxJQUFJO0lBQ3hDLElBQUksTUFBTSxLQUFLO0lBQ2YsT0FBTyxJQUFJLFFBQ0wsSUFBSSxNQUFNLE9BQU8sTUFBTSxVQUFVLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQyxJQUN0RCxJQUFJLE1BQU0sT0FBTyxhQUFhLElBQUksUUFBUTtHQUNwRDtHQUNBLFdBQVcsVUFBVSxnQkFBZ0IsU0FBVSxJQUFJO0lBQy9DLElBQUksTUFBTSxLQUFLO0lBQ2YsSUFBSSxZQUFZLFFBQVEsSUFBSSxXQUFXLEVBQUU7R0FDN0M7R0FDQSxXQUFXLFVBQVUsV0FBVyxTQUFVLElBQUksV0FBVztJQUNyRCxPQUFPLEtBQUssS0FBSyxNQUFNLElBQUksV0FBVyxLQUFLLEtBQUssTUFBTSxJQUFJO0dBQzlEO0dBQ0EsV0FBVyxVQUFVLFFBQVEsU0FBVSxPQUFPO0lBQzFDLElBQUksS0FBSyxPQUFPLE9BQU8sS0FBSyxZQUFZLFNBQVMsR0FBRyxNQUFNLE9BQU8sT0FBTyxLQUFLLElBQUk7SUFDakYsSUFBSSxPQUNBLE9BQU8sS0FBSyxLQUFLO0lBQ3JCLEdBQUcsT0FBTztJQUNWLE9BQU87R0FDWDtHQUNBLFdBQVcsVUFBVSxNQUFNLFdBQVk7SUFDbkMsS0FBSyxLQUFLLGNBQWM7SUFDeEIsT0FBTztHQUNYO0dBQ0EsV0FBVyxVQUFVLE9BQU8sU0FBVSxJQUFJO0lBQ3RDLElBQUksTUFBTSxLQUFLO0lBQ2YsT0FBTyxLQUFLLE1BQU0sU0FBVSxPQUFPO0tBQUUsT0FBTyxLQUFLLEtBQUssSUFBSSxPQUFPLElBQUksTUFBTSxJQUFJO0lBQUcsQ0FBQztHQUN2RjtHQUNBLFdBQVcsVUFBVSxRQUFRLFNBQVUsSUFBSTtJQUN2QyxJQUFJLFFBQVE7SUFDWixPQUFPLEtBQUssTUFBTSxTQUFVLE9BQU87S0FDL0IsSUFBSSxNQUFNLE1BQU07S0FDaEIsSUFBSSxZQUFZLElBQUksTUFBTTtLQUMxQixJQUFJLGdCQUFnQixLQUFLLElBQUksR0FDekIsT0FBTyxVQUNGLE1BQU07TUFDQTtNQUNQLE9BQU87T0FDSCxPQUFPLGdCQUFnQixLQUFLLFVBQVUsTUFBTTtPQUM1QyxPQUFPLElBQUk7TUFDZjtLQUNKLENBQUMsQ0FBQyxDQUNHLEtBQUssU0FBVSxPQUFPO01BQUUsT0FBTyxLQUFLLElBQUksT0FBTyxJQUFJLEtBQUs7S0FBRyxDQUFDO1VBRWhFO01BQ0QsSUFBSSxRQUFRO01BQ1osT0FBTyxLQUFLLEtBQUssV0FBWTtPQUN6QixFQUFFO09BQ0YsT0FBTztNQUNYLEdBQUcsT0FBTyxTQUFTLENBQUMsQ0FBQyxLQUFLLFdBQVk7T0FBRSxPQUFPO01BQU8sQ0FBQztLQUMzRDtJQUNKLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtHQUNkO0dBQ0EsV0FBVyxVQUFVLFNBQVMsU0FBVSxTQUFTLElBQUk7SUFDakQsSUFBSSxRQUFRLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLEdBQUcsV0FBVyxNQUFNLElBQUksWUFBWSxNQUFNLFNBQVM7SUFDMUYsU0FBUyxPQUFPLEtBQUssR0FBRztLQUNwQixJQUFJLEdBQ0EsT0FBTyxPQUFPLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQztLQUN0QyxPQUFPLElBQUk7SUFDZjtJQUNBLElBQUksUUFBUSxLQUFLLEtBQUssUUFBUSxTQUFTLElBQUk7SUFDM0MsU0FBUyxPQUFPLEdBQUcsR0FBRztLQUVsQixPQUFPLElBREksT0FBTyxHQUFHLFNBQ1AsR0FEMEIsT0FBTyxHQUFHLFNBQzlCLENBQUMsSUFBSTtJQUM3QjtJQUNBLE9BQU8sS0FBSyxRQUFRLFNBQVUsR0FBRztLQUM3QixPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUMsS0FBSyxNQUFNO0lBQ2hDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtHQUNkO0dBQ0EsV0FBVyxVQUFVLFVBQVUsU0FBVSxJQUFJO0lBQ3pDLElBQUksUUFBUTtJQUNaLE9BQU8sS0FBSyxNQUFNLFNBQVUsT0FBTztLQUMvQixJQUFJLE1BQU0sTUFBTTtLQUNoQixJQUFJLGdCQUFnQixLQUFLLElBQUksS0FBSyxJQUFJLFFBQVEsR0FBRztNQUM3QyxJQUFJLGdCQUFnQixJQUFJO01BQ3hCLElBQUksUUFBUSxnQkFBZ0IsS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNO01BQ3RELE9BQU8sSUFBSSxNQUFNLEtBQ1osTUFBTTtPQUNBO09BQ1AsT0FBTyxJQUFJO09BQ1gsUUFBUTtPQUNSLFdBQVcsSUFBSSxRQUFRLFNBQVMsU0FBUyxLQUFBO09BQ3pDLE9BQU87UUFDSTtRQUNQLE9BQU8sSUFBSTtPQUNmO01BQ0osQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLElBQUk7T0FDcEIsSUFBSSxTQUFTLEdBQUc7T0FDaEIsT0FBTyxnQkFBZ0IsT0FBTyxJQUFJLGFBQWEsSUFBSTtNQUN2RCxDQUFDO0tBQ0wsT0FDSztNQUNELElBQUksTUFBTSxDQUFDO01BQ1gsT0FBTyxLQUFLLEtBQUssU0FBVSxNQUFNO09BQUUsT0FBTyxJQUFJLEtBQUssSUFBSTtNQUFHLEdBQUcsT0FBTyxJQUFJLE1BQU0sSUFBSSxDQUFDLENBQUMsS0FBSyxXQUFZO09BQUUsT0FBTztNQUFLLENBQUM7S0FDeEg7SUFDSixHQUFHLEVBQUU7R0FDVDtHQUNBLFdBQVcsVUFBVSxTQUFTLFNBQVUsUUFBUTtJQUM1QyxJQUFJLE1BQU0sS0FBSztJQUNmLElBQUksVUFBVSxHQUNWLE9BQU87SUFDWCxJQUFJLFVBQVU7SUFDZCxJQUFJLGdCQUFnQixHQUFHLEdBQ25CLGdCQUFnQixLQUFLLFdBQVk7S0FDN0IsSUFBSSxhQUFhO0tBQ2pCLE9BQU8sU0FBVSxRQUFRLFNBQVM7TUFDOUIsSUFBSSxlQUFlLEdBQ2YsT0FBTztNQUNYLElBQUksZUFBZSxHQUFHO09BQ2xCLEVBQUU7T0FDRixPQUFPO01BQ1g7TUFDQSxRQUFRLFdBQVk7T0FDaEIsT0FBTyxRQUFRLFVBQVU7T0FDekIsYUFBYTtNQUNqQixDQUFDO01BQ0QsT0FBTztLQUNYO0lBQ0osQ0FBQztTQUdELGdCQUFnQixLQUFLLFdBQVk7S0FDN0IsSUFBSSxhQUFhO0tBQ2pCLE9BQU8sV0FBWTtNQUFFLE9BQU8sRUFBRSxhQUFhO0tBQUc7SUFDbEQsQ0FBQztJQUVMLE9BQU87R0FDWDtHQUNBLFdBQVcsVUFBVSxRQUFRLFNBQVUsU0FBUztJQUM1QyxLQUFLLEtBQUssUUFBUSxLQUFLLElBQUksS0FBSyxLQUFLLE9BQU8sT0FBTztJQUNuRCxnQkFBZ0IsS0FBSyxNQUFNLFdBQVk7S0FDbkMsSUFBSSxXQUFXO0tBQ2YsT0FBTyxTQUFVLFFBQVEsU0FBUyxTQUFTO01BQ3ZDLElBQUksRUFBRSxZQUFZLEdBQ2QsUUFBUSxPQUFPO01BQ25CLE9BQU8sWUFBWTtLQUN2QjtJQUNKLEdBQUcsSUFBSTtJQUNQLE9BQU87R0FDWDtHQUNBLFdBQVcsVUFBVSxRQUFRLFNBQVUsZ0JBQWdCLG1CQUFtQjtJQUN0RSxVQUFVLEtBQUssTUFBTSxTQUFVLFFBQVEsU0FBUyxTQUFTO0tBQ3JELElBQUksZUFBZSxPQUFPLEtBQUssR0FBRztNQUM5QixRQUFRLE9BQU87TUFDZixPQUFPO0tBQ1gsT0FFSSxPQUFPO0lBRWYsQ0FBQztJQUNELE9BQU87R0FDWDtHQUNBLFdBQVcsVUFBVSxRQUFRLFNBQVUsSUFBSTtJQUN2QyxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FDZixRQUFRLFNBQVUsR0FBRztLQUN0QixPQUFPLEVBQUU7SUFDYixDQUFDLENBQUMsQ0FDRyxLQUFLLEVBQUU7R0FDaEI7R0FDQSxXQUFXLFVBQVUsT0FBTyxTQUFVLElBQUk7SUFDdEMsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLE1BQU0sRUFBRTtHQUNsQztHQUNBLFdBQVcsVUFBVSxTQUFTLFNBQVUsZ0JBQWdCO0lBQ3BELFVBQVUsS0FBSyxNQUFNLFNBQVUsUUFBUTtLQUNuQyxPQUFPLGVBQWUsT0FBTyxLQUFLO0lBQ3RDLENBQUM7SUFDRCxlQUFlLEtBQUssTUFBTSxjQUFjO0lBQ3hDLE9BQU87R0FDWDtHQUNBLFdBQVcsVUFBVSxNQUFNLFNBQVUsUUFBUTtJQUN6QyxPQUFPLEtBQUssT0FBTyxNQUFNO0dBQzdCO0dBQ0EsV0FBVyxVQUFVLEtBQUssU0FBVSxXQUFXO0lBQzNDLE9BQU8sSUFBSSxLQUFLLEdBQUcsWUFBWSxLQUFLLEtBQUssT0FBTyxXQUFXLElBQUk7R0FDbkU7R0FDQSxXQUFXLFVBQVUsVUFBVSxXQUFZO0lBQ3ZDLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxRQUFRLFNBQVMsU0FBUztJQUNwRCxJQUFJLEtBQUssb0JBQ0wsS0FBSyxtQkFBbUIsS0FBSyxLQUFLLEdBQUc7SUFDekMsT0FBTztHQUNYO0dBQ0EsV0FBVyxVQUFVLE9BQU8sV0FBWTtJQUNwQyxPQUFPLEtBQUssUUFBUTtHQUN4QjtHQUNBLFdBQVcsVUFBVSxVQUFVLFNBQVUsSUFBSTtJQUN6QyxJQUFJLE1BQU0sS0FBSztJQUNmLElBQUksV0FBVyxDQUFDLElBQUk7SUFDcEIsT0FBTyxLQUFLLEtBQUssU0FBVSxLQUFLLFFBQVE7S0FDcEMsR0FBRyxPQUFPLEtBQUssTUFBTTtJQUN6QixDQUFDO0dBQ0w7R0FDQSxXQUFXLFVBQVUsZ0JBQWdCLFNBQVUsSUFBSTtJQUMvQyxLQUFLLEtBQUssU0FBUztJQUNuQixPQUFPLEtBQUssUUFBUSxFQUFFO0dBQzFCO0dBQ0EsV0FBVyxVQUFVLGlCQUFpQixTQUFVLElBQUk7SUFDaEQsSUFBSSxNQUFNLEtBQUs7SUFDZixJQUFJLFdBQVcsQ0FBQyxJQUFJO0lBQ3BCLE9BQU8sS0FBSyxLQUFLLFNBQVUsS0FBSyxRQUFRO0tBQ3BDLEdBQUcsT0FBTyxZQUFZLE1BQU07SUFDaEMsQ0FBQztHQUNMO0dBQ0EsV0FBVyxVQUFVLE9BQU8sU0FBVSxJQUFJO0lBQ3RDLElBQUksTUFBTSxLQUFLO0lBQ2YsSUFBSSxXQUFXLENBQUMsSUFBSTtJQUNwQixJQUFJLElBQUksQ0FBQztJQUNULE9BQU8sS0FBSyxLQUFLLFNBQVUsTUFBTSxRQUFRO0tBQ3JDLEVBQUUsS0FBSyxPQUFPLEdBQUc7SUFDckIsQ0FBQyxDQUFDLENBQ0csS0FBSyxXQUFZO0tBQ2xCLE9BQU87SUFDWCxDQUFDLENBQUMsQ0FDRyxLQUFLLEVBQUU7R0FDaEI7R0FDQSxXQUFXLFVBQVUsY0FBYyxTQUFVLElBQUk7SUFDN0MsSUFBSSxNQUFNLEtBQUs7SUFDZixJQUFJLGdCQUFnQixLQUFLLElBQUksS0FBSyxJQUFJLFFBQVEsR0FDMUMsT0FBTyxLQUFLLE1BQU0sU0FBVSxPQUFPO0tBQy9CLElBQUksUUFBUSxnQkFBZ0IsS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNO0tBQ3RELE9BQU8sSUFBSSxNQUFNLEtBQUssTUFBTTtNQUNqQjtNQUNQLFFBQVE7TUFDUixPQUFPLElBQUk7TUFDWCxXQUFXLElBQUksUUFBUSxTQUFTLFNBQVMsS0FBQTtNQUN6QyxPQUFPO09BQ0k7T0FDUCxPQUFPLElBQUk7TUFDZjtLQUNKLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FDRyxLQUFLLFNBQVUsSUFBSTtLQUVwQixPQURhLEdBQUc7SUFFcEIsQ0FBQyxDQUFDLENBQ0csS0FBSyxFQUFFO0lBRWhCLElBQUksV0FBVyxDQUFDLElBQUk7SUFDcEIsSUFBSSxJQUFJLENBQUM7SUFDVCxPQUFPLEtBQUssS0FBSyxTQUFVLE1BQU0sUUFBUTtLQUNyQyxFQUFFLEtBQUssT0FBTyxVQUFVO0lBQzVCLENBQUMsQ0FBQyxDQUNHLEtBQUssV0FBWTtLQUNsQixPQUFPO0lBQ1gsQ0FBQyxDQUFDLENBQ0csS0FBSyxFQUFFO0dBQ2hCO0dBQ0EsV0FBVyxVQUFVLGFBQWEsU0FBVSxJQUFJO0lBQzVDLEtBQUssS0FBSyxTQUFTO0lBQ25CLE9BQU8sS0FBSyxLQUFLLEVBQUU7R0FDdkI7R0FDQSxXQUFXLFVBQVUsV0FBVyxTQUFVLElBQUk7SUFDMUMsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQ2YsS0FBSyxTQUFVLEdBQUc7S0FDbkIsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDLENBQ0csS0FBSyxFQUFFO0dBQ2hCO0dBQ0EsV0FBVyxVQUFVLFVBQVUsU0FBVSxJQUFJO0lBQ3pDLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFTLEVBQUU7R0FDckM7R0FDQSxXQUFXLFVBQVUsV0FBVyxXQUFZO0lBQ3hDLElBQUksTUFBTSxLQUFLLE1BQU0sTUFBTSxJQUFJLFNBQVMsSUFBSSxNQUFNLE9BQU8sVUFBVSxJQUFJO0lBQ3ZFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUNiLE9BQU87SUFDWCxJQUFJLE1BQU0sQ0FBQztJQUNYLFVBQVUsS0FBSyxNQUFNLFNBQVUsUUFBUTtLQUNuQyxJQUFJLFNBQVMsT0FBTyxXQUFXLFNBQVM7S0FDeEMsSUFBSSxRQUFRLE9BQU8sS0FBSyxNQUFNO0tBQzlCLElBQUksVUFBVTtLQUNkLE9BQU8sQ0FBQztJQUNaLENBQUM7SUFDRCxPQUFPO0dBQ1g7R0FDQSxXQUFXLFVBQVUsU0FBUyxTQUFVLFNBQVM7SUFDN0MsSUFBSSxRQUFRO0lBQ1osSUFBSSxNQUFNLEtBQUs7SUFDZixPQUFPLEtBQUssT0FBTyxTQUFVLE9BQU87S0FDaEMsSUFBSTtLQUNKLElBQUksT0FBTyxZQUFZLFlBQ25CLFdBQVc7VUFHWCxXQUFXLFNBQVUsTUFBTTtNQUFFLE9BQU8sZ0JBQWdCLE1BQU0sT0FBTztLQUFHO0tBRXhFLElBQUksWUFBWSxJQUFJLE1BQU07S0FDMUIsSUFBSSxLQUFLLFVBQVUsT0FBTyxZQUFZLFdBQVcsR0FBRyxVQUFVLGFBQWEsR0FBRztLQUM5RSxJQUFJLFFBQVE7S0FDWixJQUFJLGtCQUFrQixNQUFNLEdBQUcsU0FBUztLQUN4QyxJQUFJLGlCQUFpQjtNQUNqQixJQUFJLE9BQU8sbUJBQW1CLFVBQzFCLFFBQ0ksZ0JBQWdCLFVBQVUsU0FBUyxnQkFBZ0IsUUFBUTtXQUcvRCxRQUFRO0tBRWhCO0tBQ0EsSUFBSSxnQkFBZ0IsQ0FBQztLQUNyQixJQUFJLGVBQWU7S0FDbkIsSUFBSSxhQUFhLENBQUM7S0FDbEIsSUFBSSxvQkFBb0IsU0FBVSxlQUFlLEtBQUs7TUFDbEQsSUFBSSxXQUFXLElBQUksVUFBVSxjQUFjLElBQUk7TUFDL0MsZ0JBQWdCLGdCQUFnQjtNQUNoQyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssS0FBSyxRQUFRLEdBQUcsS0FBSyxHQUFHLFFBQVEsTUFBTTtPQUN4RCxJQUFJLE1BQU0sR0FBRztPQUNiLGNBQWMsS0FBSyxTQUFTLElBQUk7TUFDcEM7S0FDSjtLQUNBLElBQUksd0JBQXdCLFlBQVk7S0FDeEMsT0FBTyxNQUFNLE1BQU0sQ0FBQyxDQUNmLFlBQVksQ0FBQyxDQUNiLEtBQUssU0FBVSxNQUFNO01BQ3RCLElBQUksV0FBVyxnQkFBZ0IsR0FBRyxLQUM5QixJQUFJLFVBQVUsYUFDYixPQUFPLFlBQVksY0FBYywwQkFBMEI7T0FDNUQsT0FBTyxJQUFJO09BQ1gsT0FBTyxJQUFJO01BQ2Y7TUFDQSxJQUFJLFlBQVksU0FBVSxRQUFRO09BQzlCLElBQUksUUFBUSxLQUFLLElBQUksT0FBTyxLQUFLLFNBQVMsTUFBTTtPQUNoRCxJQUFJLGNBQWMsS0FBSyxNQUFNLFFBQVEsU0FBUyxLQUFLO09BQ25ELFFBQVEsd0JBQ0YsUUFBUSxRQUFRLENBQUMsQ0FBQyxJQUNsQixVQUFVLFFBQVE7UUFDVDtRQUNQLE1BQU07UUFDTixPQUFPO09BQ1gsQ0FBQyxFQUFBLENBQUcsS0FBSyxTQUFVLFFBQVE7UUFDM0IsSUFBSSxZQUFZLENBQUM7UUFDakIsSUFBSSxZQUFZLENBQUM7UUFDakIsSUFBSSxVQUFVLFdBQVcsQ0FBQyxJQUFJO1FBQzlCLElBQUksYUFBYSx3QkFBd0IsY0FBYyxDQUFDO1FBQ3hELElBQUksQ0FBQyx1QkFDRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFLEdBQUc7U0FDNUIsSUFBSSxZQUFZLE9BQU87U0FDdkIsSUFBSSxRQUFRO1VBQ1IsT0FBTyxVQUFVLFNBQVM7VUFDMUIsU0FBUyxLQUFLLFNBQVM7U0FDM0I7U0FDQSxJQUFJLFNBQVMsS0FBSyxPQUFPLE1BQU0sT0FBTyxLQUFLLE1BQU0sT0FBTztVQUNwRCxJQUFJLE1BQU0sU0FBUyxNQUNmLFdBQVcsS0FBSyxLQUFLLFNBQVMsRUFBRTtlQUUvQixJQUFJLENBQUMsWUFDTixJQUFJLFdBQVcsU0FBUyxHQUFHLFdBQVcsTUFBTSxLQUFLLENBQUMsTUFBTSxHQUFHO1dBQzNELFdBQVcsS0FBSyxLQUFLLFNBQVMsRUFBRTtXQUNoQyxVQUFVLEtBQUssTUFBTSxLQUFLO1VBQzlCLE9BQ0s7V0FDRCxVQUFVLEtBQUssTUFBTSxLQUFLO1dBQzFCLElBQUksVUFDQSxRQUFRLEtBQUssS0FBSyxTQUFTLEVBQUU7VUFDckM7U0FDSjtRQUNKO1FBQ0osT0FBTyxRQUFRLFFBQVEsVUFBVSxTQUFTLEtBQ3RDLFVBQ0ssT0FBTztTQUFTO1NBQU8sTUFBTTtTQUFPLFFBQVE7UUFBVSxDQUFDLENBQUMsQ0FDeEQsS0FBSyxTQUFVLEtBQUs7U0FDckIsS0FBSyxJQUFJLE9BQU8sSUFBSSxVQUNoQixXQUFXLE9BQU8sU0FBUyxHQUFHLEdBQUcsQ0FBQztTQUV0QyxrQkFBa0IsVUFBVSxRQUFRLEdBQUc7UUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FDRixLQUFLLFdBQVk7U0FDbEIsUUFBUSxVQUFVLFNBQVMsS0FDdEIsWUFBWSxPQUFPLFlBQVksYUFDaEMsVUFDSyxPQUFPO1VBQ0Q7VUFDUCxNQUFNO1VBQ04sTUFBTTtVQUNOLFFBQVE7VUFDRTtVQUNWLFlBQVksT0FBTyxZQUFZLGNBQWM7VUFDN0MsbUJBQW1CLFNBQVM7U0FDaEMsQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLEtBQUs7VUFBRSxPQUFPLGtCQUFrQixVQUFVLFFBQVEsR0FBRztTQUFHLENBQUM7UUFDckYsQ0FBQyxDQUFDLENBQ0csS0FBSyxXQUFZO1NBQ2xCLFFBQVEsV0FBVyxTQUFTLEtBQ3ZCLFlBQVksMEJBQ2IsVUFDSyxPQUFPO1VBQ0Q7VUFDUCxNQUFNO1VBQ04sTUFBTTtVQUNJO1VBQ1YsbUJBQW1CLFNBQVM7U0FDaEMsQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLEtBQUs7VUFDckIsT0FBTyx1QkFBdUIsSUFBSSxPQUFPLFlBQVksR0FBRztTQUM1RCxDQUFDLENBQUMsQ0FDRyxLQUFLLFNBQVUsS0FBSztVQUFFLE9BQU8sa0JBQWtCLFdBQVcsUUFBUSxHQUFHO1NBQUcsQ0FBQztRQUN0RixDQUFDLENBQUMsQ0FDRyxLQUFLLFdBQVk7U0FDbEIsT0FBUSxLQUFLLFNBQVMsU0FBUyxTQUFTLFVBQVUsU0FBUyxLQUFLO1FBQ3BFLENBQUM7T0FDTCxDQUFDO01BQ0w7TUFDQSxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFZO09BQ2pDLElBQUksY0FBYyxTQUFTLEdBQ3ZCLE1BQU0sSUFBSSxZQUFZLHVDQUF1QyxlQUFlLGNBQWMsVUFBVTtPQUN4RyxPQUFPLEtBQUs7TUFDaEIsQ0FBQztLQUNMLENBQUM7SUFDTCxDQUFDO0dBQ0w7R0FDQSxXQUFXLFVBQVUsU0FBUyxXQUFZO0lBQ3RDLElBQUksTUFBTSxLQUFLLE1BQU0sUUFBUSxJQUFJO0lBQ2pDLElBQUksZ0JBQWdCLEdBQUcsS0FDbkIsQ0FBQyxJQUFJLE1BQU0sT0FBTyxXQUNqQixJQUFJLGFBQWEsTUFBTSxTQUFTLElBRWpDLE9BQU8sS0FBSyxPQUFPLFNBQVUsT0FBTztLQUNoQyxJQUFJLGFBQWEsSUFBSSxNQUFNLEtBQUssT0FBTztLQUN2QyxJQUFJLFlBQVk7S0FDaEIsT0FBTyxJQUFJLE1BQU0sS0FDWixNQUFNO01BQVM7TUFBTyxPQUFPO09BQUUsT0FBTztPQUFZLE9BQU87TUFBVTtLQUFFLENBQUMsQ0FBQyxDQUN2RSxLQUFLLFNBQVUsT0FBTztNQUN2QixPQUFPLElBQUksTUFBTSxLQUNaLE9BQU87T0FBUztPQUFPLE1BQU07T0FBZSxPQUFPO01BQVUsQ0FBQyxDQUFDLENBQy9ELEtBQUssU0FBVSxJQUFJO09BQ3BCLElBQUksV0FBVyxHQUFHLFVBQVUsY0FBYyxHQUFHO09BQzdDLElBQUksYUFDQSxNQUFNLElBQUksWUFBWSxnQ0FBZ0MsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLElBQUksU0FBVSxLQUFLO1FBQUUsT0FBTyxTQUFTO09BQU0sQ0FBQyxHQUFHLFFBQVEsV0FBVztPQUNsSixPQUFPLFFBQVE7TUFDbkIsQ0FBQztLQUNMLENBQUM7SUFDTCxDQUFDO0lBRUwsT0FBTyxLQUFLLE9BQU8sY0FBYztHQUNyQztHQUNBLE9BQU87RUFDWCxFQUFFO0VBQ0YsSUFBSSxpQkFBaUIsU0FBVSxPQUFPLEtBQUs7R0FBRSxPQUFRLElBQUksUUFBUTtFQUFPO0VBRXhFLFNBQVMsNEJBQTRCLElBQUk7R0FDckMsT0FBTyxxQkFBcUIsV0FBVyxXQUFXLFNBQVMsV0FBVyxhQUFhLG1CQUFtQjtJQUNsRyxLQUFLLEtBQUs7SUFDVixJQUFJLFdBQVcsVUFBVSxRQUFRO0lBQ2pDLElBQUksbUJBQ0EsSUFBSTtLQUNBLFdBQVcsa0JBQWtCO0lBQ2pDLFNBQ08sSUFBSTtLQUNQLFFBQVE7SUFDWjtJQUNKLElBQUksV0FBVyxZQUFZO0lBQzNCLElBQUksUUFBUSxTQUFTO0lBQ3JCLElBQUksY0FBYyxNQUFNLEtBQUssUUFBUTtJQUNyQyxLQUFLLE9BQU87S0FDRDtLQUNQLE9BQU8sU0FBUztLQUNoQixXQUFXLENBQUMsU0FBUyxTQUNoQixNQUFNLE9BQU8sUUFBUSxXQUNsQixTQUFTLFVBQVUsTUFBTSxPQUFPLFFBQVE7S0FDaEQsT0FBTztLQUNQLFVBQVU7S0FDVixLQUFLO0tBQ0wsUUFBUTtLQUNSLFdBQVc7S0FDWCxRQUFRO0tBQ1IsY0FBYztLQUNkLFdBQVc7S0FDWCxTQUFTO0tBQ1QsUUFBUTtLQUNSLE9BQU87S0FDQTtLQUNQLElBQUksU0FBUztLQUNiLGFBQWEsZ0JBQWdCLFNBQVMsY0FBYztJQUN4RDtHQUNKLENBQUM7RUFDTDtFQUVBLFNBQVMsY0FBYyxHQUFHLEdBQUc7R0FDekIsT0FBTyxJQUFJLElBQUksS0FBSyxNQUFNLElBQUksSUFBSTtFQUN0QztFQUNBLFNBQVMscUJBQXFCLEdBQUcsR0FBRztHQUNoQyxPQUFPLElBQUksSUFBSSxLQUFLLE1BQU0sSUFBSSxJQUFJO0VBQ3RDO0VBRUEsU0FBUyxLQUFLLHlCQUF5QixLQUFLLEdBQUc7R0FDM0MsSUFBSSxhQUFhLG1DQUFtQyxjQUM5QyxJQUFJLHdCQUF3QixXQUFXLHVCQUF1QixJQUM5RDtHQUNOLFdBQVcsS0FBSyxRQUFRLElBQUksSUFBSSxFQUFFLEdBQUcsSUFBSSxJQUFJLFVBQVUsR0FBRztHQUMxRCxPQUFPO0VBQ1g7RUFDQSxTQUFTLGdCQUFnQixhQUFhO0dBQ2xDLE9BQU8sSUFBSSxZQUFZLFdBQVcsYUFBYSxXQUFZO0lBQUUsT0FBTyxXQUFXLEVBQUU7R0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7RUFDbEc7RUFDQSxTQUFTLGFBQWEsS0FBSztHQUN2QixPQUFPLFFBQVEsU0FDVCxTQUFVLEdBQUc7SUFBRSxPQUFPLEVBQUUsWUFBWTtHQUFHLElBQ3ZDLFNBQVUsR0FBRztJQUFFLE9BQU8sRUFBRSxZQUFZO0dBQUc7RUFDakQ7RUFDQSxTQUFTLGFBQWEsS0FBSztHQUN2QixPQUFPLFFBQVEsU0FDVCxTQUFVLEdBQUc7SUFBRSxPQUFPLEVBQUUsWUFBWTtHQUFHLElBQ3ZDLFNBQVUsR0FBRztJQUFFLE9BQU8sRUFBRSxZQUFZO0dBQUc7RUFDakQ7RUFDQSxTQUFTLFdBQVcsS0FBSyxVQUFVLGFBQWEsYUFBYSxLQUFLLEtBQUs7R0FDbkUsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLFFBQVEsWUFBWSxNQUFNO0dBQ3BELElBQUksTUFBTTtHQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEVBQUUsR0FBRztJQUM3QixJQUFJLGFBQWEsU0FBUztJQUMxQixJQUFJLGVBQWUsWUFBWSxJQUFJO0tBQy9CLElBQUksSUFBSSxJQUFJLElBQUksWUFBWSxFQUFFLElBQUksR0FDOUIsT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLElBQUksWUFBWSxLQUFLLFlBQVksT0FBTyxJQUFJLENBQUM7S0FDdkUsSUFBSSxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUUsSUFBSSxHQUM5QixPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsSUFBSSxZQUFZLEtBQUssWUFBWSxPQUFPLElBQUksQ0FBQztLQUN2RSxJQUFJLE9BQU8sR0FDUCxPQUFPLElBQUksT0FBTyxHQUFHLEdBQUcsSUFBSSxTQUFTLE9BQU8sWUFBWSxPQUFPLE1BQU0sQ0FBQztLQUMxRSxPQUFPO0lBQ1g7SUFDQSxJQUFJLElBQUksSUFBSSxJQUFJLFVBQVUsSUFBSSxHQUMxQixNQUFNO0dBQ2Q7R0FDQSxJQUFJLFNBQVMsWUFBWSxVQUFVLFFBQVEsUUFDdkMsT0FBTyxNQUFNLFlBQVksT0FBTyxJQUFJLE1BQU07R0FDOUMsSUFBSSxTQUFTLElBQUksVUFBVSxRQUFRLFFBQy9CLE9BQU8sSUFBSSxPQUFPLEdBQUcsWUFBWSxNQUFNO0dBQzNDLE9BQU8sTUFBTSxJQUNQLE9BQ0EsSUFBSSxPQUFPLEdBQUcsR0FBRyxJQUFJLFlBQVksT0FBTyxZQUFZLE9BQU8sTUFBTSxDQUFDO0VBQzVFO0VBQ0EsU0FBUyx1QkFBdUIsYUFBYSxPQUFPLFNBQVMsUUFBUTtHQUNqRSxJQUFJLE9BQU8sT0FBTyxTQUFTLGNBQWMsY0FBYyxXQUFXLGVBQWUsYUFBYSxRQUFRO0dBQ3RHLElBQUksQ0FBQyxRQUFRLE1BQU0sU0FBVSxHQUFHO0lBQUUsT0FBTyxPQUFPLE1BQU07R0FBVSxDQUFDLEdBQzdELE9BQU8sS0FBSyxhQUFhLGVBQWU7R0FFNUMsU0FBUyxjQUFjLEtBQUs7SUFDeEIsUUFBUSxhQUFhLEdBQUc7SUFDeEIsUUFBUSxhQUFhLEdBQUc7SUFDeEIsVUFBVSxRQUFRLFNBQVMsZ0JBQWdCO0lBQzNDLElBQUksZUFBZSxRQUNkLElBQUksU0FBVSxRQUFRO0tBQ3ZCLE9BQU87TUFBRSxPQUFPLE1BQU0sTUFBTTtNQUFHLE9BQU8sTUFBTSxNQUFNO0tBQUU7SUFDeEQsQ0FBQyxDQUFDLENBQ0csS0FBSyxTQUFVLEdBQUcsR0FBRztLQUN0QixPQUFPLFFBQVEsRUFBRSxPQUFPLEVBQUUsS0FBSztJQUNuQyxDQUFDO0lBQ0QsZUFBZSxhQUFhLElBQUksU0FBVSxJQUFJO0tBQzFDLE9BQU8sR0FBRztJQUNkLENBQUM7SUFDRCxlQUFlLGFBQWEsSUFBSSxTQUFVLElBQUk7S0FDMUMsT0FBTyxHQUFHO0lBQ2QsQ0FBQztJQUNELFlBQVk7SUFDWixnQkFBZ0IsUUFBUSxTQUFTLEtBQUs7R0FDMUM7R0FDQSxjQUFjLE1BQU07R0FDcEIsSUFBSSxJQUFJLElBQUksWUFBWSxXQUFXLGFBQWEsV0FBWTtJQUN4RCxPQUFPLFlBQVksYUFBYSxJQUFJLGFBQWEsYUFBYSxLQUFLLE1BQU07R0FDN0UsQ0FBQztHQUNELEVBQUUscUJBQXFCLFNBQVUsV0FBVztJQUN4QyxjQUFjLFNBQVM7R0FDM0I7R0FDQSxJQUFJLHNCQUFzQjtHQUMxQixFQUFFLGNBQWMsU0FBVSxRQUFRLFNBQVMsU0FBUztJQUNoRCxJQUFJLE1BQU0sT0FBTztJQUNqQixJQUFJLE9BQU8sUUFBUSxVQUNmLE9BQU87SUFDWCxJQUFJLFdBQVcsTUFBTSxHQUFHO0lBQ3hCLElBQUksTUFBTSxVQUFVLGNBQWMsbUJBQW1CLEdBQ2pELE9BQU87U0FFTjtLQUNELElBQUksdUJBQXVCO0tBQzNCLEtBQUssSUFBSSxJQUFJLHFCQUFxQixJQUFJLFlBQVksRUFBRSxHQUFHO01BQ25ELElBQUksU0FBUyxXQUFXLEtBQUssVUFBVSxhQUFhLElBQUksYUFBYSxJQUFJLFNBQVMsU0FBUztNQUMzRixJQUFJLFdBQVcsUUFBUSx5QkFBeUIsTUFDNUMsc0JBQXNCLElBQUk7V0FDekIsSUFBSSx5QkFBeUIsUUFDOUIsUUFBUSxzQkFBc0IsTUFBTSxJQUFJLEdBQ3hDLHVCQUF1QjtLQUUvQjtLQUNBLElBQUkseUJBQXlCLE1BQ3pCLFFBQVEsV0FBWTtNQUNoQixPQUFPLFNBQVMsdUJBQXVCLGFBQWE7S0FDeEQsQ0FBQztVQUdELFFBQVEsT0FBTztLQUVuQixPQUFPO0lBQ1g7R0FDSixDQUFDO0dBQ0QsT0FBTztFQUNYO0VBQ0EsU0FBUyxZQUFZLE9BQU8sT0FBTyxXQUFXLFdBQVc7R0FDckQsT0FBTztJQUNILE1BQU07SUFDQztJQUNBO0lBQ0k7SUFDQTtHQUNmO0VBQ0o7RUFDQSxTQUFTLFdBQVcsT0FBTztHQUN2QixPQUFPO0lBQ0gsTUFBTTtJQUNOLE9BQU87SUFDUCxPQUFPO0dBQ1g7RUFDSjtFQUVBLElBQUksY0FBZ0IsV0FBWTtHQUM1QixTQUFTLGNBQWMsQ0FDdkI7R0FDQSxPQUFPLGVBQWUsWUFBWSxXQUFXLGNBQWM7SUFDdkQsS0FBSyxXQUFZO0tBQ2IsT0FBTyxLQUFLLEtBQUssTUFBTSxHQUFHO0lBQzlCO0lBQ0EsWUFBWTtJQUNaLGNBQWM7R0FDbEIsQ0FBQztHQUNELFlBQVksVUFBVSxVQUFVLFNBQVUsT0FBTyxPQUFPLGNBQWMsY0FBYztJQUNoRixlQUFlLGlCQUFpQjtJQUNoQyxlQUFlLGlCQUFpQjtJQUNoQyxJQUFJO0tBQ0EsSUFBSSxLQUFLLEtBQUssT0FBTyxLQUFLLElBQUksS0FDekIsS0FBSyxLQUFLLE9BQU8sS0FBSyxNQUFNLE1BQ3hCLGdCQUFnQixpQkFDakIsRUFBRSxnQkFBZ0IsZUFDdEIsT0FBTyxnQkFBZ0IsSUFBSTtLQUMvQixPQUFPLElBQUksS0FBSyxXQUFXLE1BQU0sV0FBWTtNQUN6QyxPQUFPLFlBQVksT0FBTyxPQUFPLENBQUMsY0FBYyxDQUFDLFlBQVk7S0FDakUsQ0FBQztJQUNMLFNBQ08sR0FBRztLQUNOLE9BQU8sS0FBSyxNQUFNLG9CQUFvQjtJQUMxQztHQUNKO0dBQ0EsWUFBWSxVQUFVLFNBQVMsU0FBVSxPQUFPO0lBQzVDLElBQUksU0FBUyxNQUNULE9BQU8sS0FBSyxNQUFNLG9CQUFvQjtJQUMxQyxPQUFPLElBQUksS0FBSyxXQUFXLE1BQU0sV0FBWTtLQUFFLE9BQU8sV0FBVyxLQUFLO0lBQUcsQ0FBQztHQUM5RTtHQUNBLFlBQVksVUFBVSxRQUFRLFNBQVUsT0FBTztJQUMzQyxJQUFJLFNBQVMsTUFDVCxPQUFPLEtBQUssTUFBTSxvQkFBb0I7SUFDMUMsT0FBTyxJQUFJLEtBQUssV0FBVyxNQUFNLFdBQVk7S0FBRSxPQUFPLFlBQVksT0FBTyxLQUFBLEdBQVcsSUFBSTtJQUFHLENBQUM7R0FDaEc7R0FDQSxZQUFZLFVBQVUsZUFBZSxTQUFVLE9BQU87SUFDbEQsSUFBSSxTQUFTLE1BQ1QsT0FBTyxLQUFLLE1BQU0sb0JBQW9CO0lBQzFDLE9BQU8sSUFBSSxLQUFLLFdBQVcsTUFBTSxXQUFZO0tBQ3pDLE9BQU8sWUFBWSxPQUFPLEtBQUEsR0FBVyxLQUFLO0lBQzlDLENBQUM7R0FDTDtHQUNBLFlBQVksVUFBVSxRQUFRLFNBQVUsT0FBTztJQUMzQyxJQUFJLFNBQVMsTUFDVCxPQUFPLEtBQUssTUFBTSxvQkFBb0I7SUFDMUMsT0FBTyxJQUFJLEtBQUssV0FBVyxNQUFNLFdBQVk7S0FDekMsT0FBTyxZQUFZLEtBQUEsR0FBVyxPQUFPLE9BQU8sSUFBSTtJQUNwRCxDQUFDO0dBQ0w7R0FDQSxZQUFZLFVBQVUsZUFBZSxTQUFVLE9BQU87SUFDbEQsSUFBSSxTQUFTLE1BQ1QsT0FBTyxLQUFLLE1BQU0sb0JBQW9CO0lBQzFDLE9BQU8sSUFBSSxLQUFLLFdBQVcsTUFBTSxXQUFZO0tBQUUsT0FBTyxZQUFZLEtBQUEsR0FBVyxLQUFLO0lBQUcsQ0FBQztHQUMxRjtHQUNBLFlBQVksVUFBVSxhQUFhLFNBQVUsS0FBSztJQUM5QyxJQUFJLE9BQU8sUUFBUSxVQUNmLE9BQU8sS0FBSyxNQUFNLGVBQWU7SUFDckMsT0FBTyxLQUFLLFFBQVEsS0FBSyxNQUFNLFdBQVcsTUFBTSxJQUFJO0dBQ3hEO0dBQ0EsWUFBWSxVQUFVLHVCQUF1QixTQUFVLEtBQUs7SUFDeEQsSUFBSSxRQUFRLElBQ1IsT0FBTyxLQUFLLFdBQVcsR0FBRztJQUM5QixPQUFPLHVCQUF1QixNQUFNLFNBQVUsR0FBRyxHQUFHO0tBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFLE1BQU07SUFBRyxHQUFHLENBQUMsR0FBRyxHQUFHLFNBQVM7R0FDM0c7R0FDQSxZQUFZLFVBQVUsbUJBQW1CLFNBQVUsS0FBSztJQUNwRCxPQUFPLHVCQUF1QixNQUFNLFNBQVUsR0FBRyxHQUFHO0tBQUUsT0FBTyxNQUFNLEVBQUU7SUFBSSxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUU7R0FDekY7R0FDQSxZQUFZLFVBQVUsa0JBQWtCLFdBQVk7SUFDaEQsSUFBSSxNQUFNLFdBQVcsTUFBTSxlQUFlLFNBQVM7SUFDbkQsSUFBSSxJQUFJLFdBQVcsR0FDZixPQUFPLGdCQUFnQixJQUFJO0lBQy9CLE9BQU8sdUJBQXVCLE1BQU0sU0FBVSxHQUFHLEdBQUc7S0FBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU07SUFBSSxHQUFHLEtBQUssRUFBRTtHQUNoRztHQUNBLFlBQVksVUFBVSw0QkFBNEIsV0FBWTtJQUMxRCxJQUFJLE1BQU0sV0FBVyxNQUFNLGVBQWUsU0FBUztJQUNuRCxJQUFJLElBQUksV0FBVyxHQUNmLE9BQU8sZ0JBQWdCLElBQUk7SUFDL0IsT0FBTyx1QkFBdUIsTUFBTSxTQUFVLEdBQUcsR0FBRztLQUFFLE9BQU8sRUFBRSxLQUFLLFNBQVUsR0FBRztNQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsTUFBTTtLQUFHLENBQUM7SUFBRyxHQUFHLEtBQUssU0FBUztHQUN2STtHQUNBLFlBQVksVUFBVSxRQUFRLFdBQVk7SUFDdEMsSUFBSSxRQUFRO0lBQ1osSUFBSSxNQUFNLFdBQVcsTUFBTSxlQUFlLFNBQVM7SUFDbkQsSUFBSSxVQUFVLEtBQUs7SUFDbkIsSUFBSTtLQUNBLElBQUksS0FBSyxPQUFPO0lBQ3BCLFNBQ08sR0FBRztLQUNOLE9BQU8sS0FBSyxNQUFNLG9CQUFvQjtJQUMxQztJQUNBLElBQUksSUFBSSxXQUFXLEdBQ2YsT0FBTyxnQkFBZ0IsSUFBSTtJQUMvQixJQUFJLElBQUksSUFBSSxLQUFLLFdBQVcsTUFBTSxXQUFZO0tBQzFDLE9BQU8sWUFBWSxJQUFJLElBQUksSUFBSSxJQUFJLFNBQVMsRUFBRTtJQUNsRCxDQUFDO0lBQ0QsRUFBRSxxQkFBcUIsU0FBVSxXQUFXO0tBQ3hDLFVBQVUsY0FBYyxTQUFTLE1BQU0sYUFBYSxNQUFNO0tBQzFELElBQUksS0FBSyxPQUFPO0lBQ3BCO0lBQ0EsSUFBSSxJQUFJO0lBQ1IsRUFBRSxjQUFjLFNBQVUsUUFBUSxTQUFTLFNBQVM7S0FDaEQsSUFBSSxNQUFNLE9BQU87S0FDakIsT0FBTyxRQUFRLEtBQUssSUFBSSxFQUFFLElBQUksR0FBRztNQUM3QixFQUFFO01BQ0YsSUFBSSxNQUFNLElBQUksUUFBUTtPQUNsQixRQUFRLE9BQU87T0FDZixPQUFPO01BQ1g7S0FDSjtLQUNBLElBQUksUUFBUSxLQUFLLElBQUksRUFBRSxNQUFNLEdBQ3pCLE9BQU87VUFFTjtNQUNELFFBQVEsV0FBWTtPQUNoQixPQUFPLFNBQVMsSUFBSSxFQUFFO01BQzFCLENBQUM7TUFDRCxPQUFPO0tBQ1g7SUFDSixDQUFDO0lBQ0QsT0FBTztHQUNYO0dBQ0EsWUFBWSxVQUFVLFdBQVcsU0FBVSxPQUFPO0lBQzlDLE9BQU8sS0FBSyxXQUFXLENBQ25CLENBQUMsUUFBUSxLQUFLLEdBQ2QsQ0FBQyxPQUFPLEtBQUssR0FBRyxPQUFPLENBQzNCLEdBQUc7S0FBRSxlQUFlO0tBQU8sZUFBZTtJQUFNLENBQUM7R0FDckQ7R0FDQSxZQUFZLFVBQVUsU0FBUyxXQUFZO0lBQ3ZDLElBQUksTUFBTSxXQUFXLE1BQU0sZUFBZSxTQUFTO0lBQ25ELElBQUksSUFBSSxXQUFXLEdBQ2YsT0FBTyxJQUFJLEtBQUssV0FBVyxJQUFJO0lBQ25DLElBQUk7S0FDQSxJQUFJLEtBQUssS0FBSyxVQUFVO0lBQzVCLFNBQ08sR0FBRztLQUNOLE9BQU8sS0FBSyxNQUFNLG9CQUFvQjtJQUMxQztJQUNBLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBVSxLQUFLLEtBQUs7S0FDeEMsT0FBTyxNQUFNLElBQUksT0FBTyxDQUFDLENBQUMsSUFBSSxJQUFJLFNBQVMsRUFBRSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUM7SUFDN0UsR0FBRyxJQUFJO0lBQ1AsT0FBTyxLQUFLLENBQUMsSUFBSSxJQUFJLFNBQVMsSUFBSSxLQUFLLEdBQUcsT0FBTyxDQUFDO0lBQ2xELE9BQU8sS0FBSyxXQUFXLFFBQVE7S0FDM0IsZUFBZTtLQUNmLGVBQWU7SUFDbkIsQ0FBQztHQUNMO0dBQ0EsWUFBWSxVQUFVLGFBQWEsU0FBVSxRQUFRLFNBQVM7SUFDMUQsSUFBSSxRQUFRO0lBQ1osSUFBSSxNQUFNLEtBQUssTUFBTSxZQUFZLEtBQUssWUFBWSxhQUFhLEtBQUssYUFBYSxNQUFNLEtBQUssTUFBTSxNQUFNLEtBQUs7SUFDN0csSUFBSSxPQUFPLFdBQVcsR0FDbEIsT0FBTyxnQkFBZ0IsSUFBSTtJQUMvQixJQUFJLENBQUMsT0FBTyxNQUFNLFNBQVUsT0FBTztLQUMvQixPQUFPLE1BQU0sT0FBTyxLQUFBLEtBQ2hCLE1BQU0sT0FBTyxLQUFBLEtBQ2IsVUFBVSxNQUFNLElBQUksTUFBTSxFQUFFLEtBQUs7SUFDekMsQ0FBQyxHQUNHLE9BQU8sS0FBSyxNQUFNLDhIQUE4SCxXQUFXLGVBQWU7SUFFOUssSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLFFBQVEsa0JBQWtCO0lBQzFELElBQUksZ0JBQWdCLFdBQVcsUUFBUSxrQkFBa0I7SUFDekQsU0FBUyxTQUFTLFFBQVEsVUFBVTtLQUNoQyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU87S0FDdEIsT0FBTyxJQUFJLEdBQUcsRUFBRSxHQUFHO01BQ2YsSUFBSSxRQUFRLE9BQU87TUFDbkIsSUFBSSxJQUFJLFNBQVMsSUFBSSxNQUFNLEVBQUUsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLE1BQU0sRUFBRSxJQUFJLEdBQUc7T0FDbEUsTUFBTSxLQUFLLElBQUksTUFBTSxJQUFJLFNBQVMsRUFBRTtPQUNwQyxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUksU0FBUyxFQUFFO09BQ3BDO01BQ0o7S0FDSjtLQUNBLElBQUksTUFBTSxHQUNOLE9BQU8sS0FBSyxRQUFRO0tBQ3hCLE9BQU87SUFDWDtJQUNBLElBQUksZ0JBQWdCO0lBQ3BCLFNBQVMsWUFBWSxHQUFHLEdBQUc7S0FDdkIsT0FBTyxjQUFjLEVBQUUsSUFBSSxFQUFFLEVBQUU7SUFDbkM7SUFDQSxJQUFJO0lBQ0osSUFBSTtLQUNBLE1BQU0sT0FBTyxPQUFPLFVBQVUsQ0FBQyxDQUFDO0tBQ2hDLElBQUksS0FBSyxXQUFXO0lBQ3hCLFNBQ08sSUFBSTtLQUNQLE9BQU8sS0FBSyxNQUFNLG9CQUFvQjtJQUMxQztJQUNBLElBQUksV0FBVztJQUNmLElBQUksMEJBQTBCLGdCQUN4QixTQUFVLEtBQUs7S0FBRSxPQUFPLFVBQVUsS0FBSyxJQUFJLFNBQVMsQ0FBQyxFQUFFLElBQUk7SUFBRyxJQUM5RCxTQUFVLEtBQUs7S0FBRSxPQUFPLFVBQVUsS0FBSyxJQUFJLFNBQVMsQ0FBQyxFQUFFLEtBQUs7SUFBRztJQUNyRSxJQUFJLDBCQUEwQixnQkFDeEIsU0FBVSxLQUFLO0tBQUUsT0FBTyxXQUFXLEtBQUssSUFBSSxTQUFTLENBQUMsRUFBRSxJQUFJO0lBQUcsSUFDL0QsU0FBVSxLQUFLO0tBQUUsT0FBTyxXQUFXLEtBQUssSUFBSSxTQUFTLENBQUMsRUFBRSxLQUFLO0lBQUc7SUFDdEUsU0FBUyxzQkFBc0IsS0FBSztLQUNoQyxPQUFPLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDLHdCQUF3QixHQUFHO0lBQ3hFO0lBQ0EsSUFBSSxXQUFXO0lBQ2YsSUFBSSxJQUFJLElBQUksS0FBSyxXQUFXLE1BQU0sV0FBWTtLQUMxQyxPQUFPLFlBQVksSUFBSSxFQUFFLENBQUMsSUFBSSxJQUFJLElBQUksU0FBUyxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhO0lBQ3hGLENBQUM7SUFDRCxFQUFFLHFCQUFxQixTQUFVLFdBQVc7S0FDeEMsSUFBSSxjQUFjLFFBQVE7TUFDdEIsV0FBVztNQUNYLGdCQUFnQjtLQUNwQixPQUNLO01BQ0QsV0FBVztNQUNYLGdCQUFnQjtLQUNwQjtLQUNBLElBQUksS0FBSyxXQUFXO0lBQ3hCO0lBQ0EsRUFBRSxjQUFjLFNBQVUsUUFBUSxTQUFTLFNBQVM7S0FDaEQsSUFBSSxNQUFNLE9BQU87S0FDakIsT0FBTyxTQUFTLEdBQUcsR0FBRztNQUNsQixFQUFFO01BQ0YsSUFBSSxhQUFhLElBQUksUUFBUTtPQUN6QixRQUFRLE9BQU87T0FDZixPQUFPO01BQ1g7S0FDSjtLQUNBLElBQUksc0JBQXNCLEdBQUcsR0FDekIsT0FBTztVQUVOLElBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxTQUFTLENBQUMsRUFBRSxNQUFNLEtBQzNDLE1BQU0sS0FBSyxLQUFLLElBQUksU0FBUyxDQUFDLEVBQUUsTUFBTSxHQUN0QyxPQUFPO1VBRU47TUFDRCxRQUFRLFdBQVk7T0FDaEIsSUFBSSxrQkFBa0IsV0FDbEIsT0FBTyxTQUFTLElBQUksU0FBUyxDQUFDLEVBQUU7WUFFaEMsT0FBTyxTQUFTLElBQUksU0FBUyxDQUFDLEVBQUU7TUFDeEMsQ0FBQztNQUNELE9BQU87S0FDWDtJQUNKLENBQUM7SUFDRCxPQUFPO0dBQ1g7R0FDQSxZQUFZLFVBQVUsa0JBQWtCLFdBQVk7SUFDaEQsSUFBSSxNQUFNLFdBQVcsTUFBTSxlQUFlLFNBQVM7SUFDbkQsSUFBSSxDQUFDLElBQUksTUFBTSxTQUFVLEdBQUc7S0FBRSxPQUFPLE9BQU8sTUFBTTtJQUFVLENBQUMsR0FDekQsT0FBTyxLQUFLLE1BQU0sMkNBQTJDO0lBRWpFLElBQUksSUFBSSxXQUFXLEdBQ2YsT0FBTyxnQkFBZ0IsSUFBSTtJQUMvQixPQUFPLEtBQUssV0FBVyxJQUFJLElBQUksU0FBVSxLQUFLO0tBQUUsT0FBTyxDQUFDLEtBQUssTUFBTSxTQUFTO0lBQUcsQ0FBQyxDQUFDO0dBQ3JGO0dBQ0EsT0FBTztFQUNYLEVBQUU7RUFFRixTQUFTLDZCQUE2QixJQUFJO0dBQ3RDLE9BQU8scUJBQXFCLFlBQVksV0FBVyxTQUFTLFlBQVksT0FBTyxPQUFPLGNBQWM7SUFDaEcsS0FBSyxLQUFLO0lBQ1YsS0FBSyxPQUFPO0tBQ0Q7S0FDUCxPQUFPLFVBQVUsUUFBUSxPQUFPO0tBQ2hDLElBQUk7SUFDUjtJQUNBLEtBQUssT0FBTyxLQUFLLGFBQWE7SUFDOUIsS0FBSyxjQUFjLFNBQVUsR0FBRyxHQUFHO0tBQUUsT0FBTyxJQUFJLEdBQUcsQ0FBQztJQUFHO0lBQ3ZELEtBQUssT0FBTyxTQUFVLEdBQUcsR0FBRztLQUFFLE9BQVEsSUFBSSxHQUFHLENBQUMsSUFBSSxJQUFJLElBQUk7SUFBSTtJQUM5RCxLQUFLLE9BQU8sU0FBVSxHQUFHLEdBQUc7S0FBRSxPQUFRLElBQUksR0FBRyxDQUFDLElBQUksSUFBSSxJQUFJO0lBQUk7SUFDOUQsS0FBSyxlQUFlLEdBQUcsTUFBTTtJQUM3QixJQUFJLENBQUMsS0FBSyxjQUNOLE1BQU0sSUFBSSxXQUFXLFdBQVc7R0FDeEMsQ0FBQztFQUNMO0VBRUEsU0FBUyxtQkFBbUIsUUFBUTtHQUNoQyxPQUFPLEtBQUssU0FBVSxPQUFPO0lBQ3pCLGVBQWUsS0FBSztJQUNwQixPQUFPLE1BQU0sT0FBTyxLQUFLO0lBQ3pCLE9BQU87R0FDWCxDQUFDO0VBQ0w7RUFDQSxTQUFTLGVBQWUsT0FBTztHQUMzQixJQUFJLE1BQU0saUJBQ04sTUFBTSxnQkFBZ0I7R0FDMUIsSUFBSSxNQUFNLGdCQUNOLE1BQU0sZUFBZTtFQUM3QjtFQUVBLElBQUksbUNBQW1DO0VBQ3ZDLElBQUksaUNBQWlDO0VBQ3JDLElBQUksZUFBZSxPQUFPLE1BQU0sZ0NBQWdDO0VBRWhFLElBQUksY0FBZ0IsV0FBWTtHQUM1QixTQUFTLGNBQWMsQ0FDdkI7R0FDQSxZQUFZLFVBQVUsUUFBUSxXQUFZO0lBQ3RDLE9BQU8sQ0FBQyxJQUFJLE1BQU07SUFDbEIsRUFBRSxLQUFLO0lBQ1AsSUFBSSxLQUFLLGNBQWMsS0FBSyxDQUFDLElBQUksUUFDN0IsSUFBSSxlQUFlO0lBQ3ZCLE9BQU87R0FDWDtHQUNBLFlBQVksVUFBVSxVQUFVLFdBQVk7SUFDeEMsT0FBTyxDQUFDLElBQUksTUFBTTtJQUNsQixJQUFJLEVBQUUsS0FBSyxjQUFjLEdBQUc7S0FDeEIsSUFBSSxDQUFDLElBQUksUUFDTCxJQUFJLGVBQWU7S0FDdkIsT0FBTyxLQUFLLGNBQWMsU0FBUyxLQUFLLENBQUMsS0FBSyxRQUFRLEdBQUc7TUFDckQsSUFBSSxXQUFXLEtBQUssY0FBYyxNQUFNO01BQ3hDLElBQUk7T0FDQSxPQUFPLFNBQVMsSUFBSSxTQUFTLEVBQUU7TUFDbkMsU0FDTyxHQUFHLENBQUU7S0FDaEI7SUFDSjtJQUNBLE9BQU87R0FDWDtHQUNBLFlBQVksVUFBVSxVQUFVLFdBQVk7SUFDeEMsT0FBTyxLQUFLLGFBQWEsSUFBSSxpQkFBaUI7R0FDbEQ7R0FDQSxZQUFZLFVBQVUsU0FBUyxTQUFVLFVBQVU7SUFDL0MsSUFBSSxRQUFRO0lBQ1osSUFBSSxDQUFDLEtBQUssTUFDTixPQUFPO0lBQ1gsSUFBSSxRQUFRLEtBQUssR0FBRztJQUNwQixJQUFJLGNBQWMsS0FBSyxHQUFHLE9BQU87SUFDakMsT0FBTyxDQUFDLEtBQUssUUFBUTtJQUNyQixJQUFJLENBQUMsWUFBWSxDQUFDLE9BQ2QsUUFBUSxlQUFlLFlBQVksTUFBbkM7S0FDSSxLQUFLLHVCQUNELE1BQU0sSUFBSSxXQUFXLGVBQWUsV0FBVztLQUNuRCxLQUFLLG1CQUNELE1BQU0sSUFBSSxXQUFXLFdBQVcsWUFBWSxTQUFTLFdBQVc7S0FDcEUsU0FDSSxNQUFNLElBQUksV0FBVyxXQUFXLFdBQVc7SUFDbkQ7SUFFSixJQUFJLENBQUMsS0FBSyxRQUNOLE1BQU0sSUFBSSxXQUFXLG9CQUFvQjtJQUM3QyxPQUFPLEtBQUssWUFBWSxXQUFXLElBQUk7SUFDdkMsV0FBVyxLQUFLLFdBQ1osYUFDSyxLQUFLLEdBQUcsT0FDSCxLQUFLLEdBQUcsS0FBSyxZQUFZLEtBQUssWUFBWSxLQUFLLE1BQU0sRUFBRSxZQUFZLEtBQUssNEJBQTRCLENBQUMsSUFDckcsTUFBTSxZQUFZLEtBQUssWUFBWSxLQUFLLE1BQU0sRUFDNUMsWUFBWSxLQUFLLDRCQUNyQixDQUFDO0lBQ2IsU0FBUyxVQUFVLEtBQUssU0FBVSxJQUFJO0tBQ2xDLGVBQWUsRUFBRTtLQUNqQixNQUFNLFFBQVEsU0FBUyxLQUFLO0lBQ2hDLENBQUM7SUFDRCxTQUFTLFVBQVUsS0FBSyxTQUFVLElBQUk7S0FDbEMsZUFBZSxFQUFFO0tBQ2pCLE1BQU0sVUFBVSxNQUFNLFFBQVEsSUFBSSxXQUFXLE1BQU0sU0FBUyxLQUFLLENBQUM7S0FDbEUsTUFBTSxTQUFTO0tBQ2YsTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRTtJQUM3QixDQUFDO0lBQ0QsU0FBUyxhQUFhLEtBQUssV0FBWTtLQUNuQyxNQUFNLFNBQVM7S0FDZixNQUFNLFNBQVM7S0FDZixJQUFJLGtCQUFrQixVQUNsQixhQUFhLGVBQWUsS0FBSyxTQUFTLGVBQWU7SUFFakUsQ0FBQztJQUNELE9BQU87R0FDWDtHQUNBLFlBQVksVUFBVSxXQUFXLFNBQVUsTUFBTSxJQUFJLFlBQVk7SUFDN0QsSUFBSSxRQUFRO0lBQ1osSUFBSSxTQUFTLGVBQWUsS0FBSyxTQUFTLGFBQ3RDLE9BQU8sVUFBVSxJQUFJLFdBQVcsU0FBUyx5QkFBeUIsQ0FBQztJQUN2RSxJQUFJLENBQUMsS0FBSyxRQUNOLE9BQU8sVUFBVSxJQUFJLFdBQVcsb0JBQW9CLENBQUM7SUFDekQsSUFBSSxLQUFLLFFBQVEsR0FDYixPQUFPLElBQUksYUFBYSxTQUFVLFNBQVMsUUFBUTtLQUMvQyxNQUFNLGNBQWMsS0FBSyxDQUNyQixXQUFZO01BQ1IsTUFBTSxTQUFTLE1BQU0sSUFBSSxVQUFVLENBQUMsQ0FBQyxLQUFLLFNBQVMsTUFBTTtLQUM3RCxHQUNBLEdBQ0osQ0FBQztJQUNMLENBQUM7U0FFQSxJQUFJLFlBQ0wsT0FBTyxTQUFTLFdBQVk7S0FDeEIsSUFBSSxJQUFJLElBQUksYUFBYSxTQUFVLFNBQVMsUUFBUTtNQUNoRCxNQUFNLE1BQU07TUFDWixJQUFJLEtBQUssR0FBRyxTQUFTLFFBQVEsS0FBSztNQUNsQyxJQUFJLE1BQU0sR0FBRyxNQUNULEdBQUcsS0FBSyxTQUFTLE1BQU07S0FDL0IsQ0FBQztLQUNELEVBQUUsUUFBUSxXQUFZO01BQUUsT0FBTyxNQUFNLFFBQVE7S0FBRyxDQUFDO0tBQ2pELEVBQUUsT0FBTztLQUNULE9BQU87SUFDWCxDQUFDO1NBRUE7S0FDRCxJQUFJLElBQUksSUFBSSxhQUFhLFNBQVUsU0FBUyxRQUFRO01BQ2hELElBQUksS0FBSyxHQUFHLFNBQVMsUUFBUSxLQUFLO01BQ2xDLElBQUksTUFBTSxHQUFHLE1BQ1QsR0FBRyxLQUFLLFNBQVMsTUFBTTtLQUMvQixDQUFDO0tBQ0QsRUFBRSxPQUFPO0tBQ1QsT0FBTztJQUNYO0dBQ0o7R0FDQSxZQUFZLFVBQVUsUUFBUSxXQUFZO0lBQ3RDLE9BQU8sS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLElBQUk7R0FDL0M7R0FDQSxZQUFZLFVBQVUsVUFBVSxTQUFVLGFBQWE7SUFDbkQsSUFBSSxPQUFPLEtBQUssTUFBTTtJQUN0QixJQUFJLFVBQVUsYUFBYSxRQUFRLFdBQVc7SUFDOUMsSUFBSSxLQUFLLGFBQ0wsS0FBSyxjQUFjLEtBQUssWUFBWSxLQUFLLFdBQVk7S0FBRSxPQUFPO0lBQVMsQ0FBQztTQUV2RTtLQUNELEtBQUssY0FBYztLQUNuQixLQUFLLGdCQUFnQixDQUFDO0tBQ3RCLElBQUksUUFBUSxLQUFLLFNBQVMsWUFBWSxLQUFLLFdBQVcsRUFBRTtLQUN4RCxDQUFDLFNBQVMsT0FBTztNQUNiLEVBQUUsS0FBSztNQUNQLE9BQU8sS0FBSyxjQUFjLFFBQ3RCLEtBQUssY0FBYyxNQUFNLENBQUMsQ0FBQztNQUMvQixJQUFJLEtBQUssYUFDTCxNQUFNLElBQUksU0FBUyxDQUFDLENBQUMsWUFBWTtLQUN6QyxFQUFBLENBQUc7SUFDUDtJQUNBLElBQUkscUJBQXFCLEtBQUs7SUFDOUIsT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFTLFFBQVE7S0FDL0MsUUFDSyxLQUFLLFNBQVUsS0FBSztNQUFFLE9BQU8sS0FBSyxjQUFjLEtBQUssS0FBSyxRQUFRLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztLQUFHLEdBQUcsU0FBVSxLQUFLO01BQUUsT0FBTyxLQUFLLGNBQWMsS0FBSyxLQUFLLE9BQU8sS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0tBQUcsQ0FBQyxDQUFDLENBQ3pLLFFBQVEsV0FBWTtNQUNyQixJQUFJLEtBQUssZ0JBQWdCLG9CQUNyQixLQUFLLGNBQWM7S0FFM0IsQ0FBQztJQUNMLENBQUM7R0FDTDtHQUNBLFlBQVksVUFBVSxRQUFRLFdBQVk7SUFDdEMsSUFBSSxLQUFLLFFBQVE7S0FDYixLQUFLLFNBQVM7S0FDZCxJQUFJLEtBQUssVUFDTCxLQUFLLFNBQVMsTUFBTTtLQUN4QixLQUFLLFFBQVEsSUFBSSxXQUFXLE1BQU0sQ0FBQztJQUN2QztHQUNKO0dBQ0EsWUFBWSxVQUFVLFFBQVEsU0FBVSxXQUFXO0lBQy9DLElBQUksaUJBQWlCLEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLENBQUM7SUFDdEUsSUFBSSxPQUFPLGdCQUFnQixTQUFTLEdBQ2hDLE9BQU8sZUFBZTtJQUMxQixJQUFJLGNBQWMsS0FBSyxPQUFPO0lBQzlCLElBQUksQ0FBQyxhQUNELE1BQU0sSUFBSSxXQUFXLFNBQVMsV0FBVyxZQUFZLDBCQUEwQjtJQUVuRixJQUFJLHdCQUF3QixJQUFJLEtBQUssR0FBRyxNQUFNLFdBQVcsYUFBYSxJQUFJO0lBQzFFLHNCQUFzQixPQUFPLEtBQUssR0FBRyxLQUFLLE1BQU0sU0FBUztJQUN6RCxlQUFlLGFBQWE7SUFDNUIsT0FBTztHQUNYO0dBQ0EsT0FBTztFQUNYLEVBQUU7RUFFRixTQUFTLDZCQUE2QixJQUFJO0dBQ3RDLE9BQU8scUJBQXFCLFlBQVksV0FBVyxTQUFTLFlBQVksTUFBTSxZQUFZLFVBQVUsNkJBQTZCLFFBQVE7SUFDckksSUFBSSxRQUFRO0lBQ1osSUFBSSxTQUFTLFlBQ1QsV0FBVyxRQUFRLFNBQVUsV0FBVztLQUNwQyxJQUFJO0tBQ0osSUFBSSxVQUFVLEtBQUssU0FBUyxnQkFBZ0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRztLQUNoRixJQUFJLFFBQ0EsYUFBYSxXQUFXLE9BQU8sT0FBTyxJQUFJLFNBQVUsR0FBRztNQUFFLE9BQU8sRUFBRTtLQUFjLENBQUMsQ0FBQztJQUMxRixDQUFDO0lBQ0wsS0FBSyxLQUFLO0lBQ1YsS0FBSyxPQUFPO0lBQ1osS0FBSyxhQUFhO0lBQ2xCLEtBQUssU0FBUztJQUNkLEtBQUssOEJBQThCO0lBQ25DLEtBQUssV0FBVztJQUNoQixLQUFLLEtBQUssT0FBTyxNQUFNLFlBQVksU0FBUyxPQUFPO0lBQ25ELEtBQUssU0FBUyxVQUFVO0lBQ3hCLEtBQUssU0FBUztJQUNkLEtBQUssWUFBWTtJQUNqQixLQUFLLGdCQUFnQixDQUFDO0lBQ3RCLEtBQUssV0FBVztJQUNoQixLQUFLLFVBQVU7SUFDZixLQUFLLGNBQWM7SUFDbkIsS0FBSyxnQkFBZ0I7SUFDckIsS0FBSyxhQUFhO0lBQ2xCLEtBQUssY0FBYyxJQUFJLGFBQWEsU0FBVSxTQUFTLFFBQVE7S0FDM0QsTUFBTSxXQUFXO0tBQ2pCLE1BQU0sVUFBVTtJQUNwQixDQUFDO0lBQ0QsS0FBSyxZQUFZLEtBQUssV0FBWTtLQUM5QixNQUFNLFNBQVM7S0FDZixNQUFNLEdBQUcsU0FBUyxLQUFLO0lBQzNCLEdBQUcsU0FBVSxHQUFHO0tBQ1osSUFBSSxZQUFZLE1BQU07S0FDdEIsTUFBTSxTQUFTO0tBQ2YsTUFBTSxHQUFHLE1BQU0sS0FBSyxDQUFDO0tBQ3JCLE1BQU0sU0FDQSxNQUFNLE9BQU8sUUFBUSxDQUFDLElBQ3RCLGFBQWEsTUFBTSxZQUFZLE1BQU0sU0FBUyxNQUFNO0tBQzFELE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7R0FDTCxDQUFDO0VBQ0w7RUFFQSxTQUFTLGdCQUFnQixNQUFNLFNBQVMsUUFBUSxPQUFPLE1BQU0sVUFBVSxXQUFXLE1BQU07R0FDcEYsT0FBTztJQUNHO0lBQ0c7SUFDRDtJQUNEO0lBQ0Q7SUFDSTtJQUNWLE1BQU0sVUFBVSxDQUFDLFlBQVksTUFBTSxPQUM5QixRQUFRLE1BQU0sT0FDZCxPQUFPLE9BQU8sTUFDZixnQkFBZ0IsT0FBTztJQUNyQjtHQUNWO0VBQ0o7RUFDQSxTQUFTLGdCQUFnQixTQUFTO0dBQzlCLE9BQU8sT0FBTyxZQUFZLFdBQ3BCLFVBQ0EsVUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxTQUFTLEdBQUcsSUFBSSxNQUNuQztFQUNkO0VBRUEsU0FBUyxrQkFBa0IsTUFBTSxTQUFTLFNBQVM7R0FDL0MsT0FBTztJQUNHO0lBQ0c7SUFDQTtJQUNULGFBQWE7SUFDYixXQUFXLGNBQWMsU0FBUyxTQUFVLE9BQU87S0FBRSxPQUFPLENBQUMsTUFBTSxNQUFNLEtBQUs7SUFBRyxDQUFDO0dBQ3RGO0VBQ0o7RUFFQSxTQUFTLG9CQUFvQixZQUFZO0dBQ3JDLE9BQU8sV0FBVyxXQUFXLElBQUksV0FBVyxLQUFLO0VBQ3JEO0VBQ0EsSUFBSSxZQUFZLFNBQVUsYUFBYTtHQUNuQyxJQUFJO0lBQ0EsWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDckIsWUFBWSxXQUFZO0tBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUFHO0lBQ3ZDLE9BQU8sQ0FBQyxDQUFDLENBQUM7R0FDZCxTQUNPLEdBQUc7SUFDTixZQUFZLFdBQVk7S0FBRSxPQUFPO0lBQVc7SUFDNUMsT0FBTztHQUNYO0VBQ0o7RUFFQSxTQUFTLGdCQUFnQixTQUFTO0dBQzlCLElBQUksV0FBVyxNQUNYLE9BQU8sV0FBWSxDQUFvQjtRQUV0QyxJQUFJLE9BQU8sWUFBWSxVQUN4QixPQUFPLDBCQUEwQixPQUFPO1FBR3hDLE9BQU8sU0FBVSxLQUFLO0lBQUUsT0FBTyxhQUFhLEtBQUssT0FBTztHQUFHO0VBRW5FO0VBQ0EsU0FBUywwQkFBMEIsU0FBUztHQUV4QyxJQURZLFFBQVEsTUFBTSxHQUNsQixDQUFDLENBQUMsV0FBVyxHQUNqQixPQUFPLFNBQVUsS0FBSztJQUFFLE9BQU8sSUFBSTtHQUFVO1FBRzdDLE9BQU8sU0FBVSxLQUFLO0lBQUUsT0FBTyxhQUFhLEtBQUssT0FBTztHQUFHO0VBRW5FO0VBRUEsU0FBUyxTQUFTLFdBQVc7R0FDekIsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssU0FBUztFQUNsQztFQUNBLElBQUksY0FBYztFQUNsQixTQUFTLGdCQUFnQixTQUFTO0dBQzlCLE9BQU8sV0FBVyxPQUNaLFFBQ0EsT0FBTyxZQUFZLFdBQ2YsVUFDQSxJQUFJLE9BQU8sUUFBUSxLQUFLLEdBQUcsR0FBRyxHQUFHO0VBQy9DO0VBQ0EsU0FBUyxhQUFhLElBQUksYUFBYSxVQUFVO0dBQzdDLFNBQVMsY0FBYyxJQUFJLE9BQU87SUFDOUIsSUFBSSxTQUFTLFNBQVMsR0FBRyxnQkFBZ0I7SUFDekMsSUFBSSxZQUFZLE9BQU8sU0FBUyxJQUFJLE1BQU0sWUFBWSxPQUFPLEVBQUUsSUFBSSxDQUFDO0lBQ3BFLE9BQU87S0FDSCxRQUFRO01BQ0osTUFBTSxHQUFHO01BQ1QsUUFBUSxPQUNILElBQUksU0FBVSxPQUFPO09BQUUsT0FBTyxNQUFNLFlBQVksS0FBSztNQUFHLENBQUMsQ0FBQyxDQUMxRCxJQUFJLFNBQVUsT0FBTztPQUN0QixJQUFJLFVBQVUsTUFBTSxTQUFTLGdCQUFnQixNQUFNO09BQ25ELElBQUksV0FBVyxRQUFRLE9BQU87T0FDOUIsSUFBSSxXQUFXLFdBQVc7T0FDMUIsSUFBSSxpQkFBaUIsQ0FBQztPQUN0QixJQUFJLFNBQVM7UUFDVCxNQUFNLE1BQU07UUFDWixZQUFZO1NBQ1IsTUFBTTtTQUNOLGNBQWM7U0FDSjtTQUNBO1NBQ0Q7U0FDTTtTQUNmLFFBQVE7U0FDUixZQUFZLGdCQUFnQixPQUFPO1FBQ3ZDO1FBQ0EsU0FBUyxTQUFTLE1BQU0sVUFBVSxDQUFDLENBQzlCLElBQUksU0FBVSxXQUFXO1NBQUUsT0FBTyxNQUFNLE1BQU0sU0FBUztRQUFHLENBQUMsQ0FBQyxDQUM1RCxJQUFJLFNBQVUsT0FBTztTQUN0QixJQUFJLE9BQU8sTUFBTSxNQUFNLFNBQVMsTUFBTSxRQUFRLGFBQWEsTUFBTSxZQUFZLFVBQVUsTUFBTTtTQUU3RixJQUFJLFNBQVM7VUFDSDtVQUNOLFVBSFcsUUFBUSxPQUdGO1VBQ1I7VUFDRDtVQUNJO1VBQ1osWUFBWSxnQkFBZ0IsT0FBTztTQUN2QztTQUNBLGVBQWUsZ0JBQWdCLE9BQU8sS0FBSztTQUMzQyxPQUFPO1FBQ1gsQ0FBQztRQUNELG1CQUFtQixTQUFVLFNBQVM7U0FDbEMsT0FBTyxlQUFlLGdCQUFnQixPQUFPO1FBQ2pEO09BQ0o7T0FDQSxlQUFlLFNBQVMsT0FBTztPQUMvQixJQUFJLFdBQVcsTUFDWCxlQUFlLGdCQUFnQixPQUFPLEtBQUssT0FBTztPQUV0RCxPQUFPO01BQ1gsQ0FBQztLQUNMO0tBQ0EsV0FBVyxPQUFPLFNBQVMsS0FDdkIsWUFBWSxhQUNaLEVBQUUsT0FBTyxjQUFjLGVBQ25CLFNBQVMsS0FBSyxVQUFVLFNBQVMsS0FDakMsQ0FBQyxvQkFBb0IsS0FBSyxVQUFVLFNBQVMsS0FDN0MsQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVLFVBQVUsTUFBTSxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUs7S0FDbkUsaUJBQWlCLG1CQUFtQjtJQUN4QztHQUNKO0dBQ0EsU0FBUyxnQkFBZ0IsT0FBTztJQUM1QixJQUFJLE1BQU0sU0FBUyxHQUNmLE9BQU87SUFDWCxJQUFJLE1BQU0sU0FBUyxHQUNmLE1BQU0sSUFBSSxNQUFNLDBDQUEwQztJQUM5RCxJQUFJLFFBQVEsTUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLFlBQVksTUFBTSxXQUFXLFlBQVksTUFBTTtJQVE3RixPQVBlLFVBQVUsS0FBQSxJQUNuQixVQUFVLEtBQUEsSUFDTixPQUNBLFlBQVksV0FBVyxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQzdDLFVBQVUsS0FBQSxJQUNOLFlBQVksV0FBVyxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQ3pDLFlBQVksTUFBTSxPQUFPLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVM7R0FFdEU7R0FDQSxTQUFTLGtCQUFrQixhQUFhO0lBQ3BDLElBQUksWUFBWSxZQUFZO0lBQzVCLFNBQVMsT0FBTyxJQUFJO0tBQ2hCLElBQUksUUFBUSxHQUFHLE9BQU8sT0FBTyxHQUFHLE1BQU0sT0FBTyxHQUFHLE1BQU0sU0FBUyxHQUFHLFFBQVEsUUFBUSxHQUFHO0tBQ3JGLE9BQU8sSUFBSSxRQUFRLFNBQVUsU0FBUyxRQUFRO01BQzFDLFVBQVUsS0FBSyxPQUFPO01BQ3RCLElBQUksUUFBUSxNQUFNLFlBQVksU0FBUztNQUN2QyxJQUFJLFdBQVcsTUFBTSxXQUFXO01BQ2hDLElBQUksYUFBYSxTQUFTLFNBQVMsU0FBUztNQUM1QyxJQUFJLENBQUMsY0FBYyxTQUFTLFlBQVksU0FBUyxlQUM3QyxNQUFNLElBQUksTUFBTSw2QkFBNkIsSUFBSTtNQUNyRCxJQUFJLFVBQVUsUUFBUSxVQUFVLEVBQUUsUUFBUSxFQUFFLEVBQUEsQ0FBRztNQUMvQyxJQUFJLFFBQVEsVUFBVSxLQUFLLFdBQVcsT0FBTyxRQUN6QyxNQUFNLElBQUksTUFBTSwrREFBK0Q7TUFFbkYsSUFBSSxXQUFXLEdBQ1gsT0FBTyxRQUFRO09BQ1gsYUFBYTtPQUNiLFVBQVUsQ0FBQztPQUNYLFNBQVMsQ0FBQztPQUNWLFlBQVksS0FBQTtNQUNoQixDQUFDO01BQ0wsSUFBSTtNQUNKLElBQUksT0FBTyxDQUFDO01BQ1osSUFBSSxXQUFXLENBQUM7TUFDaEIsSUFBSSxjQUFjO01BQ2xCLElBQUksZUFBZSxTQUFVLE9BQU87T0FDaEMsRUFBRTtPQUNGLGVBQWUsS0FBSztNQUN4QjtNQUNBLElBQUksU0FBUyxlQUFlO09BQ3hCLElBQUksTUFBTSxTQUFTLEdBQ2YsT0FBTyxRQUFRO1FBQ0U7UUFDSDtRQUNWLFNBQVMsQ0FBQztRQUNWLFlBQVksS0FBQTtPQUNoQixDQUFDO09BQ0wsSUFBSSxNQUFNLFNBQVMsR0FDZixLQUFLLEtBQU0sTUFBTSxNQUFNLE1BQU0sQ0FBRTtZQUUvQixLQUFLLEtBQU0sTUFBTSxNQUFNLE9BQU8sZ0JBQWdCLEtBQUssQ0FBQyxDQUFFO01BQzlELE9BQ0s7T0FDRCxJQUFJLEtBQUssYUFDSCxXQUNJLENBQUMsUUFBUSxJQUFJLElBQ2IsQ0FBQyxRQUFRLElBQUksSUFDakIsQ0FBQyxNQUFNLElBQUksR0FBRyxRQUFRLEdBQUcsSUFBSSxRQUFRLEdBQUc7T0FDOUMsSUFBSSxZQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEVBQUUsR0FBRztRQUM3QixLQUFLLEtBQU0sTUFBTyxTQUFTLE1BQU0sT0FBTyxLQUFBLElBQ2xDLE1BQU0sS0FBSyxDQUFDLE1BQU0sSUFBSSxNQUFNLEVBQUUsSUFDOUIsTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUc7UUFDN0IsSUFBSSxVQUFVO09BQ2xCO1lBR0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsRUFBRSxHQUFHO1FBQzdCLEtBQUssS0FBTSxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFFO1FBQ3ZDLElBQUksVUFBVTtPQUNsQjtNQUVSO01BQ0EsSUFBSSxPQUFPLFNBQVUsT0FBTztPQUN4QixJQUFJLGFBQWEsTUFBTSxPQUFPO09BQzlCLEtBQUssUUFBUSxTQUFVLEtBQUssR0FBRztRQUFFLE9BQU8sSUFBSSxTQUFTLFNBQVMsU0FBUyxLQUFLLElBQUk7T0FBUSxDQUFDO09BQ3pGLFFBQVE7UUFDUztRQUNIO1FBQ1YsU0FBUyxTQUFTLFdBQVcsT0FBTyxLQUFLLElBQUksU0FBVSxLQUFLO1NBQUUsT0FBTyxJQUFJO1FBQVEsQ0FBQztRQUN0RTtPQUNoQixDQUFDO01BQ0w7TUFDQSxJQUFJLFVBQVUsU0FBVSxPQUFPO09BQzNCLGFBQWEsS0FBSztPQUNsQixLQUFLLEtBQUs7TUFDZDtNQUNBLElBQUksWUFBWTtLQUNwQixDQUFDO0lBQ0w7SUFDQSxTQUFTLFdBQVcsSUFBSTtLQUNwQixJQUFJLFFBQVEsR0FBRyxPQUFPLFNBQVMsR0FBRyxRQUFRLFFBQVEsR0FBRyxPQUFPLFVBQVUsR0FBRyxTQUFTLFNBQVMsR0FBRztLQUM5RixPQUFPLElBQUksUUFBUSxTQUFVLFNBQVMsUUFBUTtNQUMxQyxVQUFVLEtBQUssT0FBTztNQUN0QixJQUFJLFFBQVEsTUFBTSxPQUFPLFFBQVEsTUFBTTtNQUN2QyxJQUFJLFFBQVEsTUFBTSxZQUFZLFNBQVM7TUFDdkMsSUFBSSxTQUFTLE1BQU0sZUFBZSxRQUFRLE1BQU0sTUFBTSxNQUFNLElBQUk7TUFDaEUsSUFBSSxZQUFZLFVBQ1YsU0FDSSxlQUNBLFNBQ0osU0FDSSxlQUNBO01BQ1YsSUFBSSxNQUFNLFVBQVUsRUFBRSxtQkFBbUIsVUFDbkMsT0FBTyxXQUFXLGdCQUFnQixLQUFLLEdBQUcsU0FBUyxJQUNuRCxPQUFPLGNBQWMsZ0JBQWdCLEtBQUssR0FBRyxTQUFTO01BQzVELElBQUksVUFBVSxtQkFBbUIsTUFBTTtNQUN2QyxJQUFJLFlBQVksS0FBSyxTQUFVLElBQUk7T0FDL0IsSUFBSSxTQUFTLElBQUk7T0FDakIsSUFBSSxDQUFDLFFBQVE7UUFDVCxRQUFRLElBQUk7UUFDWjtPQUNKO09BQ0EsT0FBTyxRQUFRLEVBQUU7T0FDakIsT0FBTyxPQUFPO09BQ2QsSUFBSSxrQkFBa0IsT0FBTyxTQUFTLEtBQUssTUFBTTtPQUNqRCxJQUFJLDRCQUE0QixPQUFPO09BQ3ZDLElBQUksMkJBQ0EsNEJBQTRCLDBCQUEwQixLQUFLLE1BQU07T0FDckUsSUFBSSxpQkFBaUIsT0FBTyxRQUFRLEtBQUssTUFBTTtPQUMvQyxJQUFJLDRCQUE0QixXQUFZO1FBQ3hDLE1BQU0sSUFBSSxNQUFNLG9CQUFvQjtPQUN4QztPQUNBLElBQUkseUJBQXlCLFdBQVk7UUFDckMsTUFBTSxJQUFJLE1BQU0sb0JBQW9CO09BQ3hDO09BQ0EsT0FBTyxRQUFRO09BQ2YsT0FBTyxPQUNILE9BQU8sV0FDSCxPQUFPLHFCQUNILE9BQU8sVUFDSDtPQUNoQixPQUFPLE9BQU8sS0FBSyxNQUFNO09BQ3pCLE9BQU8sT0FBTyxXQUFZO1FBQ3RCLElBQUksUUFBUTtRQUNaLElBQUksU0FBUztRQUNiLE9BQU8sS0FBSyxNQUFNLFdBQVk7U0FDMUIsT0FBTyxXQUFXLE1BQU0sU0FBUyxJQUFJLE1BQU0sS0FBSztRQUNwRCxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVk7U0FBRSxPQUFPO1FBQU8sQ0FBQztPQUN6QztPQUNBLE9BQU8sUUFBUSxTQUFVLFVBQVU7UUFDL0IsSUFBSSxtQkFBbUIsSUFBSSxRQUFRLFNBQVUsa0JBQWtCLGlCQUFpQjtTQUM1RSxtQkFBbUIsS0FBSyxnQkFBZ0I7U0FDeEMsSUFBSSxVQUFVLG1CQUFtQixlQUFlO1NBQ2hELE9BQU8sT0FBTztTQUNkLE9BQU8sT0FBTyxTQUFVLE9BQU87VUFDM0IsT0FBTyxPQUNILE9BQU8sV0FDSCxPQUFPLHFCQUNILE9BQU8sVUFDSDtVQUNoQixpQkFBaUIsS0FBSztTQUMxQjtRQUNKLENBQUM7UUFDRCxJQUFJLGtCQUFrQixXQUFZO1NBQzlCLElBQUksSUFBSSxRQUNKLElBQUk7VUFDQSxTQUFTO1NBQ2IsU0FDTyxLQUFLO1VBQ1IsT0FBTyxLQUFLLEdBQUc7U0FDbkI7Y0FFQztVQUNELE9BQU8sT0FBTztVQUNkLE9BQU8sUUFBUSxXQUFZO1dBQ3ZCLE1BQU0sSUFBSSxNQUFNLDBCQUEwQjtVQUM5QztVQUNBLE9BQU8sS0FBSztTQUNoQjtRQUNKO1FBQ0EsSUFBSSxZQUFZLEtBQUssU0FBVSxJQUFJO1NBQy9CLElBQUksWUFBWTtTQUNoQixnQkFBZ0I7UUFDcEIsQ0FBQztRQUNELE9BQU8sV0FBVztRQUNsQixPQUFPLHFCQUFxQjtRQUM1QixPQUFPLFVBQVU7UUFDakIsZ0JBQWdCO1FBQ2hCLE9BQU87T0FDWDtPQUNBLFFBQVEsTUFBTTtNQUNsQixHQUFHLE1BQU07S0FDYixDQUFDO0lBQ0w7SUFDQSxTQUFTLE1BQU0sV0FBVyxpQkFBaUI7S0FDdkMsT0FBTyxTQUFVLFNBQVM7TUFDdEIsT0FBTyxJQUFJLFFBQVEsU0FBVSxTQUFTLFFBQVE7T0FDMUMsSUFBSTtPQUNKLFVBQVUsS0FBSyxPQUFPO09BQ3RCLElBQUksUUFBUSxRQUFRLE9BQU8sU0FBUyxRQUFRLFFBQVEsUUFBUSxRQUFRLE9BQU8sUUFBUSxRQUFRO09BQzNGLElBQUksYUFBYSxLQUFLLFFBQVEsZUFBZSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7T0FDMUUsSUFBSSxrQkFBa0IsVUFBVSxXQUFXLEtBQUEsSUFBWTtPQUN2RCxJQUFJLFFBQVEsTUFBTSxPQUFPLFFBQVEsTUFBTTtPQUN2QyxJQUFJLFFBQVEsTUFBTSxZQUFZLFNBQVM7T0FDdkMsSUFBSSxTQUFTLE1BQU0sZUFBZSxRQUFRLE1BQU0sTUFBTSxNQUFNLElBQUk7T0FDaEUsSUFBSSxjQUFjLGdCQUFnQixLQUFLO09BQ3ZDLElBQUksVUFBVSxHQUNWLE9BQU8sUUFBUSxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUM7T0FDakMsSUFBSSxpQkFBaUI7UUFDakIsSUFBSSxVQUFVO1NBQ1YsT0FBTztTQUNQLE9BQU87U0FDSTtRQUNmO1FBQ0EsSUFBSSxNQUFNLFNBQ0osT0FBTyxPQUFPLE9BQU8sSUFDckIsT0FBTyxXQUFXLE9BQU87UUFDL0IsSUFBSSxZQUFZLFNBQVUsT0FBTztTQUFFLE9BQU8sUUFBUSxFQUFFLFFBQVEsTUFBTSxPQUFPLE9BQU8sQ0FBQztRQUFHO1FBQ3BGLElBQUksVUFBVSxtQkFBbUIsTUFBTTtPQUMzQyxPQUNLLElBQUksYUFBYSxjQUFjLFFBQVE7UUFDeEMsSUFBSSxNQUFNLFNBQ0osT0FBTyxPQUFPLGFBQWEsZUFBZSxJQUMxQyxPQUFPLFdBQVcsYUFBYSxlQUFlO1FBQ3BELElBQUksWUFBWSxTQUFVLE9BQU87U0FDN0IsT0FBTyxRQUFRLEVBQUUsUUFBUSxNQUFNLE9BQU8sT0FBTyxDQUFDO1FBQ2xEO1FBQ0EsSUFBSSxVQUFVLG1CQUFtQixNQUFNO09BQzNDLE9BQ0s7UUFDRCxJQUFJLFVBQVU7UUFDZCxJQUFJLFFBQVEsVUFBVSxFQUFFLG1CQUFtQixVQUNyQyxPQUFPLFdBQVcsYUFBYSxTQUFTLElBQ3hDLE9BQU8sY0FBYyxhQUFhLFNBQVM7UUFDakQsSUFBSSxXQUFXLENBQUM7UUFDaEIsTUFBTSxZQUFZLFdBQVk7U0FDMUIsSUFBSSxTQUFTLE1BQU07U0FDbkIsSUFBSSxDQUFDLFFBQ0QsT0FBTyxRQUFRLEVBQUUsUUFBUSxTQUFTLENBQUM7U0FDdkMsU0FBUyxLQUFLLFNBQVMsT0FBTyxRQUFRLE9BQU8sVUFBVTtTQUN2RCxJQUFJLEVBQUUsWUFBWSxPQUNkLE9BQU8sUUFBUSxFQUFFLFFBQVEsU0FBUyxDQUFDO1NBQ3ZDLE9BQU8sU0FBUztRQUNwQjtRQUNBLE1BQU0sVUFBVSxtQkFBbUIsTUFBTTtPQUM3QztNQUNKLENBQUM7S0FDTDtJQUNKO0lBQ0EsT0FBTztLQUNILE1BQU07S0FDTixRQUFRO0tBQ0E7S0FDUixTQUFTLFNBQVUsSUFBSTtNQUNuQixJQUFJLFFBQVEsR0FBRyxPQUFPLE9BQU8sR0FBRztNQUNoQyxPQUFPLElBQUksUUFBUSxTQUFVLFNBQVMsUUFBUTtPQUMxQyxVQUFVLEtBQUssT0FBTztPQUN0QixJQUFJLFFBQVEsTUFBTSxZQUFZLFNBQVM7T0FDdkMsSUFBSSxTQUFTLEtBQUs7T0FDbEIsSUFBSSxTQUFTLElBQUksTUFBTSxNQUFNO09BQzdCLElBQUksV0FBVztPQUNmLElBQUksZ0JBQWdCO09BQ3BCLElBQUk7T0FDSixJQUFJLGlCQUFpQixTQUFVLE9BQU87UUFDbEMsSUFBSSxNQUFNLE1BQU07UUFDaEIsS0FBSyxPQUFPLElBQUksUUFBUSxJQUFJLFdBQVc7UUFFdkMsSUFBSSxFQUFFLGtCQUFrQixVQUNwQixRQUFRLE1BQU07T0FDdEI7T0FDQSxJQUFJLGVBQWUsbUJBQW1CLE1BQU07T0FDNUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsRUFBRSxHQUUxQixJQURVLEtBQUssTUFDSixNQUFNO1FBQ2IsTUFBTSxNQUFNLElBQUksS0FBSyxFQUFFO1FBQ3ZCLElBQUksT0FBTztRQUNYLElBQUksWUFBWTtRQUNoQixJQUFJLFVBQVU7UUFDZCxFQUFFO09BQ047T0FFSixJQUFJLGFBQWEsR0FDYixRQUFRLE1BQU07TUFDdEIsQ0FBQztLQUNMO0tBQ0EsS0FBSyxTQUFVLElBQUk7TUFDZixJQUFJLFFBQVEsR0FBRyxPQUFPLE1BQU0sR0FBRztNQUMvQixPQUFPLElBQUksUUFBUSxTQUFVLFNBQVMsUUFBUTtPQUMxQyxVQUFVLEtBQUssT0FBTztPQUV0QixJQUFJLE1BRFEsTUFBTSxZQUFZLFNBQ2hCLENBQUMsQ0FBQyxJQUFJLEdBQUc7T0FDdkIsSUFBSSxZQUFZLFNBQVUsT0FBTztRQUFFLE9BQU8sUUFBUSxNQUFNLE9BQU8sTUFBTTtPQUFHO09BQ3hFLElBQUksVUFBVSxtQkFBbUIsTUFBTTtNQUMzQyxDQUFDO0tBQ0w7S0FDQSxPQUFPLE1BQU0sV0FBVyxlQUFlO0tBQzNCO0tBQ1osT0FBTyxTQUFVLElBQUk7TUFDakIsSUFBSSxRQUFRLEdBQUcsT0FBTyxRQUFRLEdBQUc7TUFDakMsSUFBSSxRQUFRLE1BQU0sT0FBTyxRQUFRLE1BQU07TUFDdkMsT0FBTyxJQUFJLFFBQVEsU0FBVSxTQUFTLFFBQVE7T0FDMUMsSUFBSSxRQUFRLE1BQU0sWUFBWSxTQUFTO09BQ3ZDLElBQUksU0FBUyxNQUFNLGVBQWUsUUFBUSxNQUFNLE1BQU0sTUFBTSxJQUFJO09BQ2hFLElBQUksY0FBYyxnQkFBZ0IsS0FBSztPQUN2QyxJQUFJLE1BQU0sY0FBYyxPQUFPLE1BQU0sV0FBVyxJQUFJLE9BQU8sTUFBTTtPQUNqRSxJQUFJLFlBQVksS0FBSyxTQUFVLElBQUk7UUFDL0IsT0FBTyxRQUFRLEdBQUcsT0FBTyxNQUFNO09BQ25DLENBQUM7T0FDRCxJQUFJLFVBQVUsbUJBQW1CLE1BQU07TUFDM0MsQ0FBQztLQUNMO0lBQ0o7R0FDSjtHQUNBLElBQUksS0FBSyxjQUFjLElBQUksUUFBUSxHQUFHLFNBQVMsR0FBRyxRQUFRLFlBQVksR0FBRyxXQUFXLGtCQUFrQixHQUFHO0dBQ3pHLElBQUksU0FBUyxPQUFPLE9BQU8sSUFBSSxTQUFVLGFBQWE7SUFDbEQsT0FBTyxrQkFBa0IsV0FBVztHQUN4QyxDQUFDO0dBQ0QsSUFBSSxXQUFXLENBQUM7R0FDaEIsT0FBTyxRQUFRLFNBQVUsT0FBTztJQUFFLE9BQVEsU0FBUyxNQUFNLFFBQVE7R0FBUSxDQUFDO0dBQzFFLE9BQU87SUFDSCxPQUFPO0lBQ1AsYUFBYSxHQUFHLFlBQVksS0FBSyxFQUFFO0lBQ25DLE9BQU8sU0FBVSxNQUFNO0tBRW5CLElBQUksQ0FEUyxTQUFTLE9BRWxCLE1BQU0sSUFBSSxNQUFNLFVBQVUsT0FBTyxNQUFNLGFBQWEsQ0FBQztLQUN6RCxPQUFPLFNBQVM7SUFDcEI7SUFDQSxTQUFTO0lBQ1QsU0FBUyxVQUFVLFdBQVc7SUFDdEI7R0FDWjtFQUNKO0VBRUEsU0FBUyxzQkFBc0IsV0FBVyxhQUFhO0dBQ25ELE9BQU8sWUFBWSxPQUFPLFNBQVUsTUFBTSxJQUFJO0lBQzFDLElBQUksU0FBUyxHQUFHO0lBQ2hCLE9BQVEsU0FBUyxTQUFTLENBQUMsR0FBRyxJQUFJLEdBQUcsT0FBTyxJQUFJLENBQUM7R0FDckQsR0FBRyxTQUFTO0VBQ2hCO0VBQ0EsU0FBUyx1QkFBdUIsYUFBYSxPQUFPLElBQUksVUFBVTtHQUM5RCxJQUFJLGNBQWMsR0FBRztHQUFhLEdBQUc7R0FFckMsT0FBTyxFQUNILFFBRlMsc0JBQXNCLGFBQWEsT0FBTyxhQUFhLFFBQVEsR0FBRyxZQUFZLE1BRTFFLEVBQ2pCO0VBQ0o7RUFDQSxTQUFTLHlCQUF5QixJQUFJLFVBQVU7R0FDNUMsSUFBSSxRQUFRLFNBQVM7R0FFckIsR0FBRyxPQURVLHVCQUF1QixHQUFHLGNBQWMsT0FBTyxHQUFHLE9BQU8sUUFDdkQsQ0FBQyxDQUFDO0dBQ2pCLEdBQUcsT0FBTyxRQUFRLFNBQVUsT0FBTztJQUMvQixJQUFJLFlBQVksTUFBTTtJQUN0QixJQUFJLEdBQUcsS0FBSyxPQUFPLE9BQU8sS0FBSyxTQUFVLEtBQUs7S0FBRSxPQUFPLElBQUksU0FBUztJQUFXLENBQUMsR0FBRztLQUMvRSxNQUFNLE9BQU8sR0FBRyxLQUFLLE1BQU0sU0FBUztLQUNwQyxJQUFJLEdBQUcsc0JBQXNCLEdBQUcsT0FDNUIsR0FBRyxVQUFVLENBQUMsT0FBTyxNQUFNO0lBRW5DO0dBQ0osQ0FBQztFQUNMO0VBRUEsU0FBUyxjQUFjLElBQUksTUFBTSxZQUFZLFVBQVU7R0FDbkQsV0FBVyxRQUFRLFNBQVUsV0FBVztJQUNwQyxJQUFJLFNBQVMsU0FBUztJQUN0QixLQUFLLFFBQVEsU0FBVSxLQUFLO0tBQ3hCLElBQUksV0FBVyxzQkFBc0IsS0FBSyxTQUFTO0tBQ25ELElBQUksQ0FBQyxZQUFhLFdBQVcsWUFBWSxTQUFTLFVBQVUsS0FBQSxHQUFZO01BQ3BFLElBQUksUUFBUSxHQUFHLFlBQVksYUFBYSxlQUFlLEdBQUcsYUFDdEQsUUFBUSxLQUFLLFdBQVc7T0FDcEIsS0FBSyxXQUFZO1FBQ2IsT0FBTyxLQUFLLE1BQU0sU0FBUztPQUMvQjtPQUNBLEtBQUssU0FBVSxPQUFPO1FBQ2xCLGVBQWUsTUFBTSxXQUFXO1NBQ3JCO1NBQ1AsVUFBVTtTQUNWLGNBQWM7U0FDZCxZQUFZO1FBQ2hCLENBQUM7T0FDTDtNQUNKLENBQUM7V0FHRCxJQUFJLGFBQWEsSUFBSSxHQUFHLE1BQU0sV0FBVyxNQUFNO0tBRXZEO0lBQ0osQ0FBQztHQUNMLENBQUM7RUFDTDtFQUNBLFNBQVMsZ0JBQWdCLElBQUksTUFBTTtHQUMvQixLQUFLLFFBQVEsU0FBVSxLQUFLO0lBQ3hCLEtBQUssSUFBSSxPQUFPLEtBQ1osSUFBSSxJQUFJLGdCQUFnQixHQUFHLE9BQ3ZCLE9BQU8sSUFBSTtHQUV2QixDQUFDO0VBQ0w7RUFDQSxTQUFTLGtCQUFrQixHQUFHLEdBQUc7R0FDN0IsT0FBTyxFQUFFLEtBQUssVUFBVSxFQUFFLEtBQUs7RUFDbkM7RUFDQSxTQUFTLGFBQWEsSUFBSSxZQUFZLGlCQUFpQixRQUFRO0dBQzNELElBQUksZUFBZSxHQUFHO0dBQ3RCLElBQUksZ0JBQWdCLGlCQUFpQixTQUFTLE9BQU8sS0FDakQsQ0FBQyxhQUFhLE9BQU87SUFDckIsYUFBYSxRQUFRLGtCQUFrQixTQUFTLGlCQUFpQixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMzRSxHQUFHLFlBQVksS0FBSyxPQUFPO0dBQy9CO0dBQ0EsSUFBSSxRQUFRLEdBQUcsbUJBQW1CLGFBQWEsR0FBRyxhQUFhLFlBQVk7R0FDM0UsTUFBTSxPQUFPLGVBQWU7R0FDNUIsTUFBTSxZQUFZLE1BQU0sTUFBTTtHQUM5QixJQUFJLG9CQUFvQixNQUFNLFFBQVEsS0FBSyxLQUFLO0dBQ2hELElBQUksWUFBWSxJQUFJLGFBQWE7R0FDakMsU0FBUyxXQUFZO0lBQ2pCLElBQUksUUFBUTtJQUNaLElBQUksWUFBWTtJQUNoQixJQUFJLGVBQWUsR0FBRztLQUNsQixLQUFLLFlBQVksQ0FBQyxDQUFDLFFBQVEsU0FBVSxXQUFXO01BQzVDLFlBQVksaUJBQWlCLFdBQVcsYUFBYSxVQUFVLENBQUMsU0FBUyxhQUFhLFVBQVUsQ0FBQyxPQUFPO0tBQzVHLENBQUM7S0FDRCx5QkFBeUIsSUFBSSxlQUFlO0tBQzVDLGFBQWEsT0FBTyxXQUFZO01BQUUsT0FBTyxHQUFHLEdBQUcsU0FBUyxLQUFLLEtBQUs7S0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLGlCQUFpQjtJQUNuRyxPQUNLO0tBQ0QseUJBQXlCLElBQUksZUFBZTtLQUM1QyxPQUFPLG1CQUFtQixJQUFJLE9BQU8sVUFBVSxDQUFDLENBQzNDLEtBQUssU0FBVSxZQUFZO01BQzVCLE9BQU8sdUJBQXVCLElBQUksWUFBWSxPQUFPLGVBQWU7S0FDeEUsQ0FBQyxDQUFDLENBQ0csTUFBTSxpQkFBaUI7SUFDaEM7R0FDSixDQUFDO0VBQ0w7RUFDQSxTQUFTLG9CQUFvQixJQUFJLGlCQUFpQjtHQUM5QyxvQkFBb0IsR0FBRyxXQUFXLGVBQWU7R0FDakQsSUFBSSxnQkFBZ0IsR0FBRyxVQUFVLE9BQU8sS0FDcEMsQ0FBQyxnQkFBZ0IsaUJBQWlCLFNBQVMsT0FBTyxHQUNsRCxnQkFBZ0IsR0FDWCxrQkFBa0IsT0FBTyxDQUFDLENBQzFCLElBQUksS0FBSyxLQUFLLGdCQUFnQixHQUFHLFVBQVUsS0FBSyxDQUFDLEdBQUcsU0FBUztHQUV0RSxJQUFJLGVBQWUsa0JBQWtCLElBQUksR0FBRyxPQUFPLGVBQWU7R0FDbEUsMkJBQTJCLElBQUksR0FBRyxXQUFXLGVBQWU7R0FDNUQsSUFBSSxPQUFPLGNBQWMsY0FBYyxHQUFHLFNBQVM7R0FDbkQsSUFBSSxVQUFVLFNBQVUsYUFBYTtJQUNqQyxJQUFJLFlBQVksT0FBTyxVQUFVLFlBQVksVUFBVTtLQUNuRCxRQUFRLEtBQUssb0NBQW9DLE9BQU8sWUFBWSxNQUFNLDhEQUE4RCxDQUFDO0tBQ3pJLE9BQU8sRUFBRSxPQUFPLEtBQUssRUFBRTtJQUMzQjtJQUNBLElBQUksUUFBUSxnQkFBZ0IsWUFBWSxZQUFZLElBQUk7SUFDeEQsWUFBWSxJQUFJLFFBQVEsU0FBVSxLQUFLO0tBQ25DLElBQUksT0FDQSxRQUFRLE1BQU0sK0NBQStDLE9BQU8sWUFBWSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUM7S0FDOUcsU0FBUyxPQUFPLEdBQUc7SUFDdkIsQ0FBQztHQUNMO0dBQ0EsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEtBQUssUUFBUSxLQUFLLEdBQUcsUUFBUSxNQUFNO0lBQ3JELElBQUksY0FBYyxHQUFHO0lBQ3JCLElBQUksVUFBVSxRQUFRLFdBQVc7SUFDakMsSUFBSSxPQUFPLFlBQVksVUFDbkIsT0FBTyxRQUFRO0dBQ3ZCO0VBQ0o7RUFDQSxTQUFTLG1CQUFtQixJQUFJLE9BQU8sWUFBWTtHQUMvQyxJQUFJLE1BQU0sV0FBVyxTQUFTLE9BQU8sR0FDakMsT0FBTyxNQUNGLE1BQU0sT0FBTyxDQUFDLENBQ2QsSUFBSSxTQUFTLENBQUMsQ0FDZCxLQUFLLFNBQVUsYUFBYTtJQUM3QixPQUFPLGVBQWUsT0FBTyxjQUFjO0dBQy9DLENBQUM7UUFHRCxPQUFPLGFBQWEsUUFBUSxVQUFVO0VBRTlDO0VBQ0EsU0FBUyx1QkFBdUIsSUFBSSxZQUFZLE9BQU8saUJBQWlCO0dBQ3BFLElBQUksUUFBUSxDQUFDO0dBQ2IsSUFBSSxXQUFXLEdBQUc7R0FDbEIsSUFBSSxlQUFnQixHQUFHLFlBQVksa0JBQWtCLElBQUksR0FBRyxPQUFPLGVBQWU7R0FDbEYsSUFBSSxZQUFZLFNBQVMsT0FBTyxTQUFVLEdBQUc7SUFBRSxPQUFPLEVBQUUsS0FBSyxXQUFXO0dBQVksQ0FBQztHQUNyRixJQUFJLFVBQVUsV0FBVyxHQUNyQixPQUFPLGFBQWEsUUFBUTtHQUVoQyxVQUFVLFFBQVEsU0FBVSxTQUFTO0lBQ2pDLE1BQU0sS0FBSyxXQUFZO0tBQ25CLElBQUksWUFBWTtLQUNoQixJQUFJLFlBQVksUUFBUSxLQUFLO0tBQzdCLDJCQUEyQixJQUFJLFdBQVcsZUFBZTtLQUN6RCwyQkFBMkIsSUFBSSxXQUFXLGVBQWU7S0FDekQsZUFBZSxHQUFHLFlBQVk7S0FDOUIsSUFBSSxPQUFPLGNBQWMsV0FBVyxTQUFTO0tBQzdDLEtBQUssSUFBSSxRQUFRLFNBQVUsT0FBTztNQUM5QixZQUFZLGlCQUFpQixNQUFNLElBQUksTUFBTSxFQUFFLENBQUMsU0FBUyxNQUFNLEVBQUUsQ0FBQyxPQUFPO0tBQzdFLENBQUM7S0FDRCxLQUFLLE9BQU8sUUFBUSxTQUFVLFFBQVE7TUFDbEMsSUFBSSxPQUFPLFVBQ1AsTUFBTSxJQUFJLFdBQVcsUUFBUSwwQ0FBMEM7V0FFdEU7T0FDRCxJQUFJLFVBQVUsZ0JBQWdCLFlBQVksT0FBTyxJQUFJO09BQ3JELE9BQU8sSUFBSSxRQUFRLFNBQVUsS0FBSztRQUFFLE9BQU8sU0FBUyxTQUFTLEdBQUc7T0FBRyxDQUFDO09BQ3BFLE9BQU8sT0FBTyxRQUFRLFNBQVUsS0FBSztRQUNqQyxRQUFRLFlBQVksSUFBSSxJQUFJO1FBQzVCLFNBQVMsU0FBUyxHQUFHO09BQ3pCLENBQUM7T0FDRCxPQUFPLElBQUksUUFBUSxTQUFVLFNBQVM7UUFBRSxPQUFPLFFBQVEsWUFBWSxPQUFPO09BQUcsQ0FBQztNQUNsRjtLQUNKLENBQUM7S0FDRCxJQUFJLGlCQUFpQixRQUFRLEtBQUs7S0FDbEMsSUFBSSxrQkFBa0IsUUFBUSxLQUFLLFVBQVUsWUFBWTtNQUNyRCx5QkFBeUIsSUFBSSxlQUFlO01BQzVDLE1BQU0sa0JBQWtCLENBQUM7TUFDekIsSUFBSSxrQkFBa0IsYUFBYSxTQUFTO01BQzVDLEtBQUssSUFBSSxRQUFRLFNBQVUsT0FBTztPQUM5QixnQkFBZ0IsU0FBUyxVQUFVO01BQ3ZDLENBQUM7TUFDRCxnQkFBZ0IsSUFBSSxDQUFDLEdBQUcsWUFBWSxTQUFTLENBQUM7TUFDOUMsY0FBYyxJQUFJLENBQUMsR0FBRyxZQUFZLFNBQVMsR0FBRyxLQUFLLGVBQWUsR0FBRyxlQUFlO01BQ3BGLE1BQU0sU0FBUztNQUNmLElBQUksMEJBQTBCLGdCQUFnQixjQUFjO01BQzVELElBQUkseUJBQ0Esd0JBQXdCO01BRTVCLElBQUk7TUFDSixJQUFJLGtCQUFrQixhQUFhLE9BQU8sV0FBWTtPQUNsRCxnQkFBZ0IsZUFBZSxLQUFLO09BQ3BDLElBQUksZUFDSTtZQUFBLHlCQUF5QjtTQUN6QixJQUFJLGNBQWMsd0JBQXdCLEtBQUssTUFBTSxJQUFJO1NBQ3pELGNBQWMsS0FBSyxhQUFhLFdBQVc7UUFDL0M7O01BRVIsQ0FBQztNQUNELE9BQU8saUJBQWlCLE9BQU8sY0FBYyxTQUFTLGFBQ2hELGFBQWEsUUFBUSxhQUFhLElBQ2xDLGdCQUFnQixLQUFLLFdBQVk7T0FBRSxPQUFPO01BQWUsQ0FBQztLQUNwRTtJQUNKLENBQUM7SUFDRCxNQUFNLEtBQUssU0FBVSxVQUFVO0tBQzNCLElBQUksWUFBWSxRQUFRLEtBQUs7S0FDN0Isb0JBQW9CLFdBQVcsUUFBUTtLQUN2QyxnQkFBZ0IsSUFBSSxDQUFDLEdBQUcsWUFBWSxTQUFTLENBQUM7S0FDOUMsY0FBYyxJQUFJLENBQUMsR0FBRyxZQUFZLFNBQVMsR0FBRyxHQUFHLGFBQWEsR0FBRyxTQUFTO0tBQzFFLE1BQU0sU0FBUyxHQUFHO0lBQ3RCLENBQUM7SUFDRCxNQUFNLEtBQUssU0FBVSxVQUFVO0tBQzNCLElBQUksR0FBRyxNQUFNLGlCQUFpQixTQUFTLE9BQU8sR0FBRztNQUM3QyxJQUFJLEtBQUssS0FBSyxHQUFHLE1BQU0sVUFBVSxFQUFFLE1BQU0sUUFBUSxLQUFLLFNBQVM7T0FDM0QsR0FBRyxNQUFNLGtCQUFrQixPQUFPO09BQ2xDLE9BQU8sR0FBRyxVQUFVO09BQ3BCLEdBQUcsY0FBYyxHQUFHLFlBQVksT0FBTyxTQUFVLE1BQU07UUFBRSxPQUFPLFNBQVM7T0FBUyxDQUFDO01BQ3ZGLE9BRUksU0FBUyxZQUFZLE9BQU8sQ0FBQyxDQUFDLElBQUksUUFBUSxLQUFLLFNBQVMsU0FBUztLQUV6RTtJQUNKLENBQUM7R0FDTCxDQUFDO0dBQ0QsU0FBUyxXQUFXO0lBQ2hCLE9BQU8sTUFBTSxTQUNQLGFBQWEsUUFBUSxNQUFNLE1BQU0sQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFDakUsYUFBYSxRQUFRO0dBQy9CO0dBQ0EsT0FBTyxTQUFTLENBQUMsQ0FBQyxLQUFLLFdBQVk7SUFDL0Isb0JBQW9CLGNBQWMsZUFBZTtHQUNyRCxDQUFDO0VBQ0w7RUFDQSxTQUFTLGNBQWMsV0FBVyxXQUFXO0dBQ3pDLElBQUksT0FBTztJQUNQLEtBQUssQ0FBQztJQUNOLEtBQUssQ0FBQztJQUNOLFFBQVEsQ0FBQztHQUNiO0dBQ0EsSUFBSTtHQUNKLEtBQUssU0FBUyxXQUNWLElBQUksQ0FBQyxVQUFVLFFBQ1gsS0FBSyxJQUFJLEtBQUssS0FBSztHQUUzQixLQUFLLFNBQVMsV0FBVztJQUNyQixJQUFJLFNBQVMsVUFBVSxRQUFRLFNBQVMsVUFBVTtJQUNsRCxJQUFJLENBQUMsUUFDRCxLQUFLLElBQUksS0FBSyxDQUFDLE9BQU8sTUFBTSxDQUFDO1NBRTVCO0tBQ0QsSUFBSSxTQUFTO01BQ1QsTUFBTTtNQUNOLEtBQUs7TUFDTCxVQUFVO01BQ1YsS0FBSyxDQUFDO01BQ04sS0FBSyxDQUFDO01BQ04sUUFBUSxDQUFDO0tBQ2I7S0FDQSxJQUNBLE1BQU0sT0FBTyxRQUFRLFdBQVcsUUFDNUIsTUFBTSxPQUFPLFFBQVEsV0FBVyxPQUNoQyxPQUFPLFFBQVEsU0FBUyxPQUFPLFFBQVEsTUFBTTtNQUM3QyxPQUFPLFdBQVc7TUFDbEIsS0FBSyxPQUFPLEtBQUssTUFBTTtLQUMzQixPQUNLO01BQ0QsSUFBSSxhQUFhLE9BQU87TUFDeEIsSUFBSSxhQUFhLE9BQU87TUFDeEIsSUFBSSxVQUFVLEtBQUs7TUFDbkIsS0FBSyxXQUFXLFlBQ1osSUFBSSxDQUFDLFdBQVcsVUFDWixPQUFPLElBQUksS0FBSyxPQUFPO01BRS9CLEtBQUssV0FBVyxZQUFZO09BQ3hCLElBQUksU0FBUyxXQUFXLFVBQVUsU0FBUyxXQUFXO09BQ3RELElBQUksQ0FBQyxRQUNELE9BQU8sSUFBSSxLQUFLLE1BQU07WUFDckIsSUFBSSxPQUFPLFFBQVEsT0FBTyxLQUMzQixPQUFPLE9BQU8sS0FBSyxNQUFNO01BQ2pDO01BQ0EsSUFBSSxPQUFPLElBQUksU0FBUyxLQUNwQixPQUFPLElBQUksU0FBUyxLQUNwQixPQUFPLE9BQU8sU0FBUyxHQUN2QixLQUFLLE9BQU8sS0FBSyxNQUFNO0tBRS9CO0lBQ0o7R0FDSjtHQUNBLE9BQU87RUFDWDtFQUNBLFNBQVMsWUFBWSxVQUFVLFdBQVcsU0FBUyxTQUFTO0dBQ3hELElBQUksUUFBUSxTQUFTLEdBQUcsa0JBQWtCLFdBQVcsUUFBUSxVQUN2RDtJQUFFLFNBQVMsUUFBUTtJQUFTLGVBQWUsUUFBUTtHQUFLLElBQ3hELEVBQUUsZUFBZSxRQUFRLEtBQUssQ0FBQztHQUNyQyxRQUFRLFFBQVEsU0FBVSxLQUFLO0lBQUUsT0FBTyxTQUFTLE9BQU8sR0FBRztHQUFHLENBQUM7R0FDL0QsT0FBTztFQUNYO0VBQ0EsU0FBUyxvQkFBb0IsV0FBVyxVQUFVO0dBQzlDLEtBQUssU0FBUyxDQUFDLENBQUMsUUFBUSxTQUFVLFdBQVc7SUFDekMsSUFBSSxDQUFDLFNBQVMsR0FBRyxpQkFBaUIsU0FBUyxTQUFTLEdBQUc7S0FDbkQsSUFBSSxPQUNBLFFBQVEsTUFBTSxpQ0FBaUMsU0FBUztLQUM1RCxZQUFZLFVBQVUsV0FBVyxVQUFVLFVBQVUsQ0FBQyxTQUFTLFVBQVUsVUFBVSxDQUFDLE9BQU87SUFDL0Y7R0FDSixDQUFDO0VBQ0w7RUFDQSxTQUFTLG9CQUFvQixXQUFXLFVBQVU7R0FDOUMsQ0FBQyxDQUFDLENBQUMsTUFDRSxLQUFLLFNBQVMsR0FBRyxnQkFBZ0IsQ0FBQyxDQUNsQyxRQUFRLFNBQVUsV0FBVztJQUM5QixPQUFPLFVBQVUsY0FBYyxRQUFRLFNBQVMsR0FBRyxrQkFBa0IsU0FBUztHQUNsRixDQUFDO0VBQ0w7RUFDQSxTQUFTLFNBQVMsT0FBTyxLQUFLO0dBQzFCLE1BQU0sWUFBWSxJQUFJLE1BQU0sSUFBSSxTQUFTO0lBQ3JDLFFBQVEsSUFBSTtJQUNaLFlBQVksSUFBSTtHQUNwQixDQUFDO0VBQ0w7RUFDQSxTQUFTLGtCQUFrQixJQUFJLE9BQU8sVUFBVTtHQUM1QyxJQUFJLGVBQWUsQ0FBQztHQUVwQixNQUR5QixNQUFNLGtCQUFrQixDQUN0QyxDQUFDLENBQUMsUUFBUSxTQUFVLFdBQVc7SUFDdEMsSUFBSSxRQUFRLFNBQVMsWUFBWSxTQUFTO0lBQzFDLElBQUksVUFBVSxNQUFNO0lBQ3BCLElBQUksVUFBVSxnQkFBZ0IsZ0JBQWdCLE9BQU8sR0FBRyxXQUFXLElBQUksTUFBTSxPQUFPLENBQUMsQ0FBQyxNQUFNLGVBQWUsV0FBVyxPQUFPLFlBQVksVUFBVSxJQUFJO0lBQ3ZKLElBQUksVUFBVSxDQUFDO0lBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sV0FBVyxRQUFRLEVBQUUsR0FBRztLQUM5QyxJQUFJLFdBQVcsTUFBTSxNQUFNLE1BQU0sV0FBVyxFQUFFO0tBQzlDLFVBQVUsU0FBUztLQUNuQixJQUFJLFFBQVEsZ0JBQWdCLFNBQVMsTUFBTSxTQUFTLENBQUMsQ0FBQyxTQUFTLFFBQVEsQ0FBQyxDQUFDLFNBQVMsWUFBWSxPQUFPLFdBQVcsT0FBTyxZQUFZLFVBQVUsS0FBSztLQUNsSixRQUFRLEtBQUssS0FBSztJQUN0QjtJQUNBLGFBQWEsYUFBYSxrQkFBa0IsV0FBVyxTQUFTLE9BQU87R0FDM0UsQ0FBQztHQUNELE9BQU87RUFDWDtFQUNBLFNBQVMsaUJBQWlCLElBQUksT0FBTyxVQUFVO0dBQzNDLEdBQUcsUUFBUSxNQUFNLFVBQVU7R0FDM0IsSUFBSSxlQUFnQixHQUFHLFlBQVksa0JBQWtCLElBQUksT0FBTyxRQUFRO0dBQ3hFLEdBQUcsY0FBYyxNQUFNLE1BQU0sa0JBQWtCLENBQUM7R0FDaEQsY0FBYyxJQUFJLENBQUMsR0FBRyxVQUFVLEdBQUcsS0FBSyxZQUFZLEdBQUcsWUFBWTtFQUN2RTtFQUNBLFNBQVMsc0JBQXNCLElBQUksVUFBVTtHQUV6QyxJQUFJLE9BQU8sY0FEVyxrQkFBa0IsSUFBSSxHQUFHLE9BQU8sUUFDZixHQUFHLEdBQUcsU0FBUztHQUN0RCxPQUFPLEVBQUUsS0FBSyxJQUFJLFVBQ2QsS0FBSyxPQUFPLEtBQUssU0FBVSxJQUFJO0lBQUUsT0FBTyxHQUFHLElBQUksVUFBVSxHQUFHLE9BQU87R0FBUSxDQUFDO0VBQ3BGO0VBQ0EsU0FBUywyQkFBMkIsSUFBSSxRQUFRLFVBQVU7R0FDdEQsSUFBSSxhQUFhLFNBQVMsR0FBRztHQUM3QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEVBQUUsR0FBRztJQUN4QyxJQUFJLFlBQVksV0FBVztJQUMzQixJQUFJLFFBQVEsU0FBUyxZQUFZLFNBQVM7SUFDMUMsR0FBRyxhQUFhLFlBQVk7SUFDNUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sV0FBVyxRQUFRLEVBQUUsR0FBRztLQUM5QyxJQUFJLFlBQVksTUFBTSxXQUFXO0tBQ2pDLElBQUksVUFBVSxNQUFNLE1BQU0sU0FBUyxDQUFDLENBQUM7S0FDckMsSUFBSSxZQUFZLE9BQU8sWUFBWSxXQUM3QixVQUNBLE1BQU0sTUFBTSxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSTtLQUN2QyxJQUFJLE9BQU8sWUFBWTtNQUNuQixJQUFJLFlBQVksT0FBTyxVQUFVLENBQUMsVUFBVTtNQUM1QyxJQUFJLFdBQVc7T0FDWCxVQUFVLE9BQU87T0FDakIsT0FBTyxPQUFPLFVBQVUsQ0FBQyxVQUFVO09BQ25DLE9BQU8sVUFBVSxDQUFDLFVBQVUsYUFBYTtNQUM3QztLQUNKO0lBQ0o7R0FDSjtHQUNBLElBQUksT0FBTyxjQUFjLGVBQ3JCLFNBQVMsS0FBSyxVQUFVLFNBQVMsS0FDakMsQ0FBQyxvQkFBb0IsS0FBSyxVQUFVLFNBQVMsS0FDN0MsUUFBUSxxQkFDUixtQkFBbUIsUUFBUSxxQkFDM0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVLFVBQVUsTUFBTSxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FDM0QsR0FBRyxhQUFhO0VBRXhCO0VBQ0EsU0FBUyxpQkFBaUIsbUJBQW1CO0dBQ3pDLE9BQU8sa0JBQWtCLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxTQUFVLE9BQU8sVUFBVTtJQUMvRCxJQUFJO0lBQ0osSUFBSSxZQUFZLE1BQU0sTUFBTSxHQUFHO0lBQy9CLElBQUksUUFBUSxLQUFLLFVBQVUsUUFBUSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUs7SUFDNUUsUUFBUSxVQUFVLEVBQUUsQ0FBQyxLQUFLO0lBQzFCLElBQUksT0FBTyxNQUFNLFFBQVEsZ0JBQWdCLEVBQUU7SUFDM0MsSUFBSSxVQUFVLE1BQU0sS0FBSyxJQUFJLElBQ3ZCLEtBQUssTUFBTSxZQUFZLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxHQUFHLElBQ3JDO0lBQ04sT0FBTyxnQkFBZ0IsTUFBTSxXQUFXLE1BQU0sS0FBSyxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssS0FBSyxHQUFHLE9BQU8sS0FBSyxLQUFLLEdBQUcsUUFBUSxPQUFPLEdBQUcsYUFBYSxHQUFHLElBQUk7R0FDaEosQ0FBQztFQUNMO0VBRUEsSUFBSSxVQUFZLFdBQVk7R0FDeEIsU0FBUyxVQUFVLENBQ25CO0dBQ0EsUUFBUSxVQUFVLHFCQUFxQixTQUFVLE1BQU0sU0FBUyxTQUFTO0lBQ3JFLE9BQU8sa0JBQWtCLE1BQU0sU0FBUyxPQUFPO0dBQ25EO0dBQ0EsUUFBUSxVQUFVLG9CQUFvQixTQUFVLG1CQUFtQjtJQUMvRCxPQUFPLGlCQUFpQixpQkFBaUI7R0FDN0M7R0FDQSxRQUFRLFVBQVUsbUJBQW1CLFNBQVUsUUFBUSxXQUFXO0lBQzlELElBQUksUUFBUTtJQUNaLEtBQUssTUFBTSxDQUFDLENBQUMsUUFBUSxTQUFVLFdBQVc7S0FDdEMsSUFBSSxPQUFPLGVBQWUsTUFBTTtNQUM1QixJQUFJLFVBQVUsTUFBTSxrQkFBa0IsT0FBTyxVQUFVO01BQ3ZELElBQUksVUFBVSxRQUFRLE1BQU07TUFDNUIsSUFBSSxDQUFDLFNBQ0QsTUFBTSxJQUFJLFdBQVcsT0FBTyw4QkFBOEIsWUFBWSxPQUFPLE9BQU8sVUFBVTtNQUVsRyxRQUFRLFNBQVM7TUFDakIsSUFBSSxRQUFRLE9BQ1IsTUFBTSxJQUFJLFdBQVcsT0FBTyxtQ0FBbUM7TUFDbkUsUUFBUSxRQUFRLFNBQVUsS0FBSztPQUMzQixJQUFJLElBQUksTUFDSixNQUFNLElBQUksV0FBVyxPQUFPLHNEQUFzRDtPQUN0RixJQUFJLENBQUMsSUFBSSxTQUNMLE1BQU0sSUFBSSxXQUFXLE9BQU8sc0RBQXNEO01BQzFGLENBQUM7TUFFRCxVQUFVLGFBRE0sTUFBTSxtQkFBbUIsV0FBVyxTQUFTLE9BQzlCO0tBQ25DO0lBQ0osQ0FBQztHQUNMO0dBQ0EsUUFBUSxVQUFVLFNBQVMsU0FBVSxRQUFRO0lBQ3pDLElBQUksS0FBSyxLQUFLO0lBQ2QsS0FBSyxLQUFLLGVBQWUsS0FBSyxLQUFLLGVBQzdCLE9BQU8sS0FBSyxLQUFLLGNBQWMsTUFBTSxJQUNyQztJQUNOLElBQUksV0FBVyxHQUFHO0lBQ2xCLElBQUksYUFBYSxDQUFDO0lBQ2xCLElBQUksV0FBVyxDQUFDO0lBQ2hCLFNBQVMsUUFBUSxTQUFVLFNBQVM7S0FDaEMsT0FBTyxZQUFZLFFBQVEsS0FBSyxZQUFZO0tBQzVDLFdBQVcsUUFBUSxLQUFLLFdBQVcsQ0FBQztLQUNwQyxRQUFRLGlCQUFpQixZQUFZLFFBQVE7SUFDakQsQ0FBQztJQUNELEdBQUcsWUFBWTtJQUNmLGdCQUFnQixJQUFJO0tBQUMsR0FBRztLQUFZO0tBQUksR0FBRyxZQUFZO0lBQVMsQ0FBQztJQUNqRSxjQUFjLElBQUk7S0FBQyxHQUFHO0tBQVk7S0FBSSxHQUFHLFlBQVk7S0FBVyxLQUFLLEtBQUs7SUFBTSxHQUFHLEtBQUssUUFBUSxHQUFHLFFBQVE7SUFDM0csR0FBRyxjQUFjLEtBQUssUUFBUTtJQUM5QixPQUFPO0dBQ1g7R0FDQSxRQUFRLFVBQVUsVUFBVSxTQUFVLGlCQUFpQjtJQUNuRCxLQUFLLEtBQUssaUJBQWlCLGdCQUFnQixLQUFLLEtBQUssa0JBQWtCLEtBQUssZUFBZTtJQUMzRixPQUFPO0dBQ1g7R0FDQSxPQUFPO0VBQ1gsRUFBRTtFQUVGLFNBQVMseUJBQXlCLElBQUk7R0FDbEMsT0FBTyxxQkFBcUIsUUFBUSxXQUFXLFNBQVMsUUFBUSxlQUFlO0lBQzNFLEtBQUssS0FBSztJQUNWLEtBQUssT0FBTztLQUNSLFNBQVM7S0FDVCxjQUFjO0tBQ2QsVUFBVSxDQUFDO0tBQ1gsUUFBUSxDQUFDO0tBQ1QsZ0JBQWdCO0lBQ3BCO0dBQ0osQ0FBQztFQUNMO0VBRUEsSUFBSSxjQUFjLHlCQUF5QjtFQUMzQyxTQUFTLDJCQUEyQjtHQUNoQyxJQUFJLE9BQU8seUJBQXlCLGVBQ2hDLE9BQU8sWUFBWSxhQUFhO0lBQ2hDLElBQUksMEJBQVUsSUFBSSxJQUFJO0lBQ3RCLElBQUksY0FBYyxJQUFJLHFCQUFxQixTQUFVLEtBQUs7S0FDdEQsUUFBUSxPQUFPLEdBQUc7SUFDdEIsQ0FBQztJQUNELElBQUksVUFBVSxXQUFZO0tBQ3RCLE9BQU8sTUFBTSxLQUFLLE9BQU8sQ0FBQyxDQUNyQixJQUFJLFNBQVUsS0FBSztNQUFFLE9BQU8sSUFBSSxNQUFNO0tBQUcsQ0FBQyxDQUFDLENBQzNDLE9BQU8sU0FBVSxJQUFJO01BQUUsT0FBTyxPQUFPLEtBQUE7S0FBVyxDQUFDO0lBQzFEO0lBQ0EsSUFBSSxNQUFNLFNBQVUsSUFBSTtLQUNwQixJQUFJLE1BQU0sSUFBSSxRQUFRLEdBQUcsTUFBTTtLQUMvQixRQUFRLElBQUksR0FBRztLQUNmLFlBQVksU0FBUyxHQUFHLFFBQVEsS0FBSyxHQUFHO0tBQ3hDLElBQUksUUFBUSxPQUFPLEdBQUcsU0FBUyxnQkFBZ0I7TUFDM0MsSUFBSSxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7TUFDeEMsUUFBUSxPQUFPLFNBQVM7TUFDeEIsWUFBWSxXQUFXLFNBQVM7S0FDcEM7SUFDSjtJQUNBLElBQUksU0FBUyxTQUFVLElBQUk7S0FDdkIsSUFBSSxDQUFDLElBQ0Q7S0FDSixJQUFJLFdBQVcsUUFBUSxPQUFPO0tBQzlCLElBQUksU0FBUyxTQUFTLEtBQUs7S0FDM0IsT0FBTyxDQUFDLE9BQU8sTUFBTTtNQUNqQixJQUFJLE1BQU0sT0FBTztNQUNqQixJQUFJLElBQUksTUFBTSxNQUFNLEdBQUcsUUFBUTtPQUMzQixRQUFRLE9BQU8sR0FBRztPQUNsQixZQUFZLFdBQVcsR0FBRztPQUMxQjtNQUNKO01BQ0EsU0FBUyxTQUFTLEtBQUs7S0FDM0I7SUFDSjtJQUNBLE9BQU87S0FBVztLQUFjO0tBQWE7SUFBTztHQUN4RCxPQUNLO0lBQ0QsSUFBSSxnQkFBZ0IsQ0FBQztJQUNyQixJQUFJLFVBQVUsV0FBWTtLQUFFLE9BQU87SUFBZTtJQUNsRCxJQUFJLE1BQU0sU0FBVSxJQUFJO0tBQ3BCLGNBQWMsS0FBSyxHQUFHLE1BQU07SUFDaEM7SUFDQSxJQUFJLFNBQVMsU0FBVSxJQUFJO0tBQ3ZCLElBQUksQ0FBQyxJQUNEO0tBQ0osSUFBSSxRQUFRLGNBQWMsUUFBUSxHQUFHLE1BQU07S0FDM0MsSUFBSSxVQUFVLElBQ1YsY0FBYyxPQUFPLE9BQU8sQ0FBQztJQUVyQztJQUNBLE9BQU87S0FBVztLQUFjO0tBQWE7SUFBTztHQUN4RDtFQUNKO0VBRUEsU0FBUyxnQkFBZ0IsV0FBVyxhQUFhO0dBQzdDLElBQUksWUFBWSxVQUFVO0dBQzFCLElBQUksQ0FBQyxXQUFXO0lBQ1osWUFBWSxVQUFVLGdCQUFnQixJQUFJLFFBQVEsWUFBWTtLQUMxRCxRQUFRLENBQUM7S0FDRTtLQUNFO0lBQ2pCLENBQUM7SUFDRCxVQUFVLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLFNBQVMsT0FBTyxDQUFDO0dBQ25EO0dBQ0EsT0FBTyxVQUFVLE1BQU0sU0FBUztFQUNwQztFQUNBLFNBQVMsbUJBQW1CLFdBQVc7R0FDbkMsT0FBTyxhQUFhLE9BQU8sVUFBVSxjQUFjO0VBQ3ZEO0VBQ0EsU0FBUyxpQkFBaUIsSUFBSTtHQUMxQixJQUFJLFlBQVksR0FBRyxXQUFXLGNBQWMsR0FBRztHQUMvQyxPQUFPLG1CQUFtQixTQUFTLElBQzdCLFFBQVEsUUFBUSxVQUFVLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLE9BQU87SUFDM0QsT0FBTyxNQUNGLElBQUksU0FBVSxNQUFNO0tBQUUsT0FBTyxLQUFLO0lBQU0sQ0FBQyxDQUFDLENBQzFDLE9BQU8sU0FBVSxNQUFNO0tBQUUsT0FBTyxTQUFTO0lBQVksQ0FBQztHQUMvRCxDQUFDLElBQ0MsZ0JBQWdCLFdBQVcsV0FBVyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsWUFBWTtFQUM3RTtFQUNBLFNBQVMsbUJBQW1CLElBQUksTUFBTTtHQUNsQyxJQUFJLFlBQVksR0FBRyxXQUFXLGNBQWMsR0FBRztHQUMvQyxDQUFDLG1CQUFtQixTQUFTLEtBQ3pCLFNBQVMsY0FDVCxnQkFBZ0IsV0FBVyxXQUFXLENBQUMsQ0FBQyxJQUFJLEVBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUc7RUFDN0U7RUFDQSxTQUFTLG1CQUFtQixJQUFJLE1BQU07R0FDbEMsSUFBSSxZQUFZLEdBQUcsV0FBVyxjQUFjLEdBQUc7R0FDL0MsQ0FBQyxtQkFBbUIsU0FBUyxLQUN6QixTQUFTLGNBQ1QsZ0JBQWdCLFdBQVcsV0FBVyxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUc7RUFDdEU7RUFFQSxTQUFTLElBQUksSUFBSTtHQUNiLE9BQU8sU0FBUyxXQUFZO0lBQ3hCLElBQUksYUFBYTtJQUNqQixPQUFPLEdBQUc7R0FDZCxDQUFDO0VBQ0w7RUFFQSxTQUFTLFdBQVc7R0FJaEIsSUFBSSxFQUhXLENBQUMsVUFBVSxpQkFDdEIsV0FBVyxLQUFLLFVBQVUsU0FBUyxLQUNuQyxDQUFDLGlCQUFpQixLQUFLLFVBQVUsU0FBUyxNQUM3QixDQUFDLFVBQVUsV0FDeEIsT0FBTyxRQUFRLFFBQVE7R0FDM0IsSUFBSTtHQUNKLE9BQU8sSUFBSSxRQUFRLFNBQVUsU0FBUztJQUNsQyxJQUFJLFNBQVMsV0FBWTtLQUFFLE9BQU8sVUFBVSxVQUFVLENBQUMsQ0FBQyxRQUFRLE9BQU87SUFBRztJQUMxRSxhQUFhLFlBQVksUUFBUSxHQUFHO0lBQ3BDLE9BQU87R0FDWCxDQUFDLENBQUMsQ0FBQyxRQUFRLFdBQVk7SUFBRSxPQUFPLGNBQWMsVUFBVTtHQUFHLENBQUM7RUFDaEU7RUFFQSxJQUFJO0VBQ0osU0FBUyxhQUFhLE1BQU07R0FDeEIsT0FBTyxFQUFFLFVBQVU7RUFDdkI7RUFDQSxJQUFJLFdBQVcsU0FBVSxZQUFZLElBQUk7R0FDckMsSUFBSSxNQUNBLE9BQU8sTUFBTSxVQUFVLFNBQ2pCO0lBQUUsR0FBRztJQUFHLE1BQU07SUFBWSxJQUFJLFVBQVUsU0FBUyxJQUFJLEtBQUs7R0FBVyxJQUNyRSxFQUFFLEdBQUcsRUFBRSxDQUFDO1FBRWI7SUFDRCxJQUFJLEtBQUssSUFBSSxTQUFTO0lBQ3RCLElBQUksY0FBYyxPQUFPLFlBQ3JCLE9BQU8sSUFBSSxVQUFVO0lBRXpCLE9BQU87R0FDWDtFQUNKO0VBQ0EsTUFBTSxTQUFTLFlBQVksS0FBSztHQUN4QixLQUFLLFNBQVUsVUFBVTtJQUNyQixZQUFZLE1BQU0sUUFBUTtJQUMxQixPQUFPO0dBQ1g7R0FDQSxRQUFRLFNBQVUsS0FBSztJQUNuQixTQUFTLE1BQU0sS0FBSyxHQUFHO0lBQ3ZCLE9BQU87R0FDWDtHQUNBLFNBQVMsU0FBVSxNQUFNO0lBQ3JCLElBQUksUUFBUTtJQUNaLEtBQUssUUFBUSxTQUFVLEtBQUs7S0FBRSxPQUFPLFNBQVMsT0FBTyxLQUFLLEdBQUc7SUFBRyxDQUFDO0lBQ2pFLE9BQU87R0FDWDtHQUNBLFFBQVEsU0FBVSxLQUFLO0lBQ25CLElBQUksT0FBTyxvQkFBb0IsSUFBSSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztJQUMvQyxPQUFPLFFBQVEsSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLO0dBQ3BFO0VBQ0osR0FDQSxHQUFHLGtCQUFrQixXQUFZO0dBQzdCLE9BQU8sb0JBQW9CLElBQUk7RUFDbkMsR0FDQSxHQUFHO0VBQ1AsU0FBUyxTQUFTLFFBQVEsTUFBTSxJQUFJO0dBQ2hDLElBQUksT0FBTyxJQUFJLE1BQU0sRUFBRTtHQUN2QixJQUFJLE1BQU0sSUFBSSxHQUNWO0dBQ0osSUFBSSxPQUFPLEdBQ1AsTUFBTSxXQUFXO0dBQ3JCLElBQUksYUFBYSxNQUFNLEdBQ25CLE9BQU8sT0FBTyxRQUFRO0lBQVE7SUFBVTtJQUFJLEdBQUc7R0FBRSxDQUFDO0dBQ3RELElBQUksT0FBTyxPQUFPO0dBQ2xCLElBQUksUUFBUSxPQUFPO0dBQ25CLElBQUksSUFBSSxJQUFJLE9BQU8sSUFBSSxJQUFJLEdBQUc7SUFDMUIsT0FDTSxTQUFTLE1BQU0sTUFBTSxFQUFFLElBQ3RCLE9BQU8sSUFBSTtLQUFRO0tBQVU7S0FBSSxHQUFHO0tBQUcsR0FBRztLQUFNLEdBQUc7SUFBSztJQUMvRCxPQUFPLFVBQVUsTUFBTTtHQUMzQjtHQUNBLElBQUksSUFBSSxNQUFNLE9BQU8sRUFBRSxJQUFJLEdBQUc7SUFDMUIsUUFDTSxTQUFTLE9BQU8sTUFBTSxFQUFFLElBQ3ZCLE9BQU8sSUFBSTtLQUFRO0tBQVU7S0FBSSxHQUFHO0tBQUcsR0FBRztLQUFNLEdBQUc7SUFBSztJQUMvRCxPQUFPLFVBQVUsTUFBTTtHQUMzQjtHQUNBLElBQUksSUFBSSxNQUFNLE9BQU8sSUFBSSxJQUFJLEdBQUc7SUFDNUIsT0FBTyxPQUFPO0lBQ2QsT0FBTyxJQUFJO0lBQ1gsT0FBTyxJQUFJLFFBQVEsTUFBTSxJQUFJLElBQUk7R0FDckM7R0FDQSxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsSUFBSSxHQUFHO0lBQ3hCLE9BQU8sS0FBSztJQUNaLE9BQU8sSUFBSTtJQUNYLE9BQU8sSUFBSSxPQUFPLElBQUksT0FBTyxFQUFFLElBQUksSUFBSTtHQUMzQztHQUNBLElBQUksaUJBQWlCLENBQUMsT0FBTztHQUM3QixJQUFJLFFBQVEsQ0FBQyxPQUFPLEdBQ2hCLFlBQVksUUFBUSxJQUFJO0dBRTVCLElBQUksU0FBUyxnQkFDVCxZQUFZLFFBQVEsS0FBSztFQUVqQztFQUNBLFNBQVMsWUFBWSxRQUFRLFFBQVE7R0FDakMsU0FBUyxhQUFhLFFBQVEsSUFBSTtJQUM5QixJQUFJLE9BQU8sR0FBRyxNQUFNLEtBQUssR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLElBQUksR0FBRztJQUNqRCxTQUFTLFFBQVEsTUFBTSxFQUFFO0lBQ3pCLElBQUksR0FDQSxhQUFhLFFBQVEsQ0FBQztJQUMxQixJQUFJLEdBQ0EsYUFBYSxRQUFRLENBQUM7R0FDOUI7R0FDQSxJQUFJLENBQUMsYUFBYSxNQUFNLEdBQ3BCLGFBQWEsUUFBUSxNQUFNO0VBQ25DO0VBQ0EsU0FBUyxjQUFjLFdBQVcsV0FBVztHQUN6QyxJQUFJLEtBQUssb0JBQW9CLFNBQVM7R0FDdEMsSUFBSSxjQUFjLEdBQUcsS0FBSztHQUMxQixJQUFJLFlBQVksTUFDWixPQUFPO0dBQ1gsSUFBSSxJQUFJLFlBQVk7R0FDcEIsSUFBSSxLQUFLLG9CQUFvQixTQUFTO0dBQ3RDLElBQUksY0FBYyxHQUFHLEtBQUssRUFBRSxJQUFJO0dBQ2hDLElBQUksSUFBSSxZQUFZO0dBQ3BCLE9BQU8sQ0FBQyxZQUFZLFFBQVEsQ0FBQyxZQUFZLE1BQU07SUFDM0MsSUFBSSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUUsS0FBSyxLQUFLLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxLQUFLLEdBQy9DLE9BQU87SUFDWCxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksSUFBSSxJQUNmLEtBQUssY0FBYyxHQUFHLEtBQUssRUFBRSxJQUFJLEVBQUEsQ0FBRyxRQUNwQyxLQUFLLGNBQWMsR0FBRyxLQUFLLEVBQUUsSUFBSSxFQUFBLENBQUc7R0FDL0M7R0FDQSxPQUFPO0VBQ1g7RUFDQSxTQUFTLG9CQUFvQixNQUFNO0dBQy9CLElBQUksUUFBUSxhQUFhLElBQUksSUFDdkIsT0FDQTtJQUFFLEdBQUc7SUFBRyxHQUFHO0dBQUs7R0FDdEIsT0FBTyxFQUNILE1BQU0sU0FBVSxLQUFLO0lBQ2pCLElBQUksY0FBYyxVQUFVLFNBQVM7SUFDckMsT0FBTyxPQUNILFFBQVEsTUFBTSxHQUFkO0tBQ0ksS0FBSztNQUNELE1BQU0sSUFBSTtNQUNWLElBQUksYUFDQSxPQUFPLE1BQU0sRUFBRSxLQUFLLElBQUksS0FBSyxNQUFNLEVBQUUsSUFBSSxJQUFJLEdBQ3pDLFFBQVE7T0FBRSxJQUFJO09BQU8sR0FBRyxNQUFNLEVBQUU7T0FBRyxHQUFHO01BQUU7V0FHNUMsT0FBTyxNQUFNLEVBQUUsR0FDWCxRQUFRO09BQUUsSUFBSTtPQUFPLEdBQUcsTUFBTSxFQUFFO09BQUcsR0FBRztNQUFFO0tBRXBELEtBQUs7TUFDRCxNQUFNLElBQUk7TUFDVixJQUFJLENBQUMsZUFBZSxJQUFJLEtBQUssTUFBTSxFQUFFLEVBQUUsS0FBSyxHQUN4QyxPQUFPO09BQUUsT0FBTyxNQUFNO09BQUcsTUFBTTtNQUFNO0tBQzdDLEtBQUssR0FDRCxJQUFJLE1BQU0sRUFBRSxHQUFHO01BQ1gsTUFBTSxJQUFJO01BQ1YsUUFBUTtPQUFFLElBQUk7T0FBTyxHQUFHLE1BQU0sRUFBRTtPQUFHLEdBQUc7TUFBRTtNQUN4QztLQUNKO0tBQ0osS0FBSyxHQUNELFFBQVEsTUFBTTtJQUN0QjtJQUVKLE9BQU8sRUFBRSxNQUFNLEtBQUs7R0FDeEIsRUFDSjtFQUNKO0VBQ0EsU0FBUyxVQUFVLFFBQVE7R0FDdkIsSUFBSSxJQUFJO0dBQ1IsSUFBSSxVQUFVLEtBQUssT0FBTyxPQUFPLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsTUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsTUFBTTtHQUNoSixJQUFJLElBQUksT0FBTyxJQUFJLE1BQU0sT0FBTyxLQUFLLE1BQU07R0FDM0MsSUFBSSxHQUFHO0lBQ0gsSUFBSSxJQUFJLE1BQU0sTUFBTSxNQUFNO0lBQzFCLElBQUksWUFBWSxTQUFTLENBQUMsR0FBRyxNQUFNO0lBQ25DLElBQUksZUFBZSxPQUFPO0lBQzFCLE9BQU8sT0FBTyxhQUFhO0lBQzNCLE9BQU8sS0FBSyxhQUFhO0lBQ3pCLE9BQU8sS0FBSyxhQUFhO0lBQ3pCLFVBQVUsS0FBSyxhQUFhO0lBQzVCLE9BQU8sS0FBSztJQUNaLFVBQVUsSUFBSSxhQUFhLFNBQVM7R0FDeEM7R0FDQSxPQUFPLElBQUksYUFBYSxNQUFNO0VBQ2xDO0VBQ0EsU0FBUyxhQUFhLElBQUk7R0FDdEIsSUFBSSxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUc7R0FDckIsUUFBUSxJQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLElBQUssSUFBSSxFQUFFLElBQUksS0FBSztFQUNoRTtFQUVBLFNBQVMsdUJBQXVCLFFBQVEsUUFBUTtHQUM1QyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFFBQVEsU0FBVSxNQUFNO0lBQ2pDLElBQUksT0FBTyxPQUNQLFlBQVksT0FBTyxPQUFPLE9BQU8sS0FBSztTQUV0QyxPQUFPLFFBQVEsc0JBQXNCLE9BQU8sS0FBSztHQUN6RCxDQUFDO0dBQ0QsT0FBTztFQUNYO0VBRUEsU0FBUyxlQUFlLEtBQUssS0FBSztHQUM5QixPQUFRLElBQUksT0FDUixJQUFJLE9BQ0osT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssU0FBVSxLQUFLO0lBQUUsT0FBTyxJQUFJLFFBQVEsY0FBYyxJQUFJLE1BQU0sSUFBSSxJQUFJO0dBQUcsQ0FBQztFQUN0RztFQUVBLElBQUksUUFBUSxDQUFDO0VBRWIsSUFBSSxrQkFBa0IsQ0FBQztFQUN2QixJQUFJLGlCQUFpQjtFQUNyQixTQUFTLHdCQUF3QixNQUFNLFlBQVk7R0FDL0MsdUJBQXVCLGlCQUFpQixJQUFJO0dBQzVDLElBQUksQ0FBQyxnQkFBZ0I7SUFDakIsaUJBQWlCO0lBQ2pCLFdBQVcsV0FBWTtLQUNuQixpQkFBaUI7S0FDakIsSUFBSSxRQUFRO0tBQ1osa0JBQWtCLENBQUM7S0FDbkIscUJBQXFCLE9BQU8sS0FBSztJQUNyQyxHQUFHLENBQUM7R0FDUjtFQUNKO0VBQ0EsU0FBUyxxQkFBcUIsY0FBYyw0QkFBNEI7R0FDcEUsSUFBSSwrQkFBK0IsS0FBSyxHQUFLLDZCQUE2QjtHQUMxRSxJQUFJLGtDQUFrQixJQUFJLElBQUk7R0FDOUIsSUFBSSxhQUFhLEtBQ2IsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLE9BQU8sT0FBTyxLQUFLLEdBQUcsS0FBSyxHQUFHLFFBQVEsTUFBTTtJQUM5RCxJQUFJLFdBQVcsR0FBRztJQUNsQix3QkFBd0IsVUFBVSxjQUFjLGlCQUFpQiwwQkFBMEI7R0FDL0Y7UUFHQSxLQUFLLElBQUksT0FBTyxjQUFjO0lBQzFCLElBQUksUUFBUSx5QkFBeUIsS0FBSyxHQUFHO0lBQzdDLElBQUksT0FBTztLQUNQLElBQUksU0FBUyxNQUFNLElBQUksWUFBWSxNQUFNO0tBQ3pDLElBQUksV0FBVyxNQUFNLFNBQVMsT0FBTyxRQUFRLEdBQUcsQ0FBQyxDQUFDLE9BQU8sU0FBUztLQUNsRSxJQUFJLFVBQ0Esd0JBQXdCLFVBQVUsY0FBYyxpQkFBaUIsMEJBQTBCO0lBQ25HO0dBQ0o7R0FFSixnQkFBZ0IsUUFBUSxTQUFVLFNBQVM7SUFBRSxPQUFPLFFBQVE7R0FBRyxDQUFDO0VBQ3BFO0VBQ0EsU0FBUyx3QkFBd0IsVUFBVSxjQUFjLG9CQUFvQiw0QkFBNEI7R0FDckcsSUFBSSxvQkFBb0IsQ0FBQztHQUN6QixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssT0FBTyxRQUFRLFNBQVMsUUFBUSxLQUFLLEdBQUcsS0FBSyxHQUFHLFFBQVEsTUFBTTtJQUNoRixJQUFJLEtBQUssR0FBRyxLQUFLLFlBQVksR0FBRyxJQUFJLFVBQVUsR0FBRztJQUNqRCxJQUFJLGtCQUFrQixDQUFDO0lBQ3ZCLEtBQUssSUFBSSxLQUFLLEdBQUcsWUFBWSxTQUFTLEtBQUssVUFBVSxRQUFRLE1BQU07S0FDL0QsSUFBSSxRQUFRLFVBQVU7S0FDdEIsSUFBSSxlQUFlLGNBQWMsTUFBTSxNQUFNLEdBQ3pDLE1BQU0sWUFBWSxRQUFRLFNBQVUsU0FBUztNQUFFLE9BQU8sbUJBQW1CLElBQUksT0FBTztLQUFHLENBQUM7VUFFdkYsSUFBSSw0QkFDTCxnQkFBZ0IsS0FBSyxLQUFLO0lBRWxDO0lBQ0EsSUFBSSw0QkFDQSxrQkFBa0IsS0FBSyxDQUFDLFdBQVcsZUFBZSxDQUFDO0dBQzNEO0dBQ0EsSUFBSSw0QkFDQSxLQUFLLElBQUksS0FBSyxHQUFHLHNCQUFzQixtQkFBbUIsS0FBSyxvQkFBb0IsUUFBUSxNQUFNO0lBQzdGLElBQUksS0FBSyxvQkFBb0IsS0FBSyxZQUFZLEdBQUcsSUFBSSxrQkFBa0IsR0FBRztJQUMxRSxTQUFTLFFBQVEsTUFBTSxhQUFhO0dBQ3hDO0VBRVI7RUFFQSxTQUFTLFVBQVUsSUFBSTtHQUNuQixJQUFJLFFBQVEsR0FBRztHQUNmLElBQUksWUFBWSxHQUFHLE1BQU07R0FDekIsSUFBSSxNQUFNLGlCQUFpQixHQUFHLE9BQzFCLE9BQU8sTUFBTSxlQUFlLEtBQUssV0FBWTtJQUN6QyxPQUFPLE1BQU0sY0FBYyxVQUFVLE1BQU0sV0FBVyxJQUFJO0dBQzlELENBQUM7R0FDTCxNQUFNLGdCQUFnQjtHQUN0QixNQUFNLGNBQWM7R0FDcEIsTUFBTSxlQUFlO0dBQ3JCLElBQUksZ0JBQWdCLE1BQU07R0FDMUIsSUFBSSxrQkFBa0IsS0FBSyxNQUFNLEdBQUcsUUFBUSxFQUFFO0dBQzlDLElBQUksa0JBQWtCO0dBQ3RCLFNBQVMsbUJBQW1CO0lBQ3hCLElBQUksTUFBTSxrQkFBa0IsZUFDeEIsTUFBTSxJQUFJLFdBQVcsZUFBZSx5QkFBeUI7R0FDckU7R0FDQSxJQUFJLGlCQUFpQixNQUFNLGdCQUMzQixxQkFBcUIsTUFBTSxhQUFhO0dBQ3hDLElBQUksWUFBWSxXQUFZO0lBQ3hCLE9BQU8sSUFBSSxhQUFhLFNBQVUsU0FBUyxRQUFRO0tBQy9DLGlCQUFpQjtLQUNqQixJQUFJLENBQUMsV0FDRCxNQUFNLElBQUksV0FBVyxXQUFXO0tBQ3BDLElBQUksU0FBUyxHQUFHO0tBQ2hCLElBQUksTUFBTSxNQUFNLGNBQWMsQ0FBQyxrQkFDekIsVUFBVSxLQUFLLE1BQU0sSUFDckIsVUFBVSxLQUFLLFFBQVEsZUFBZTtLQUM1QyxJQUFJLENBQUMsS0FDRCxNQUFNLElBQUksV0FBVyxXQUFXO0tBQ3BDLElBQUksVUFBVSxtQkFBbUIsTUFBTTtLQUN2QyxJQUFJLFlBQVksS0FBSyxHQUFHLGNBQWM7S0FDdEMsSUFBSSxrQkFBa0IsS0FBSyxTQUFVLEdBQUc7TUFDcEMscUJBQXFCLElBQUk7TUFDekIsSUFBSSxNQUFNLGNBQWMsQ0FBQyxHQUFHLFNBQVMsY0FBYztPQUMvQyxJQUFJLFVBQVU7T0FDZCxtQkFBbUIsTUFBTTtPQUN6QixJQUFJLE9BQU8sTUFBTTtPQUNqQixJQUFJLFNBQVMsVUFBVSxlQUFlLE1BQU07T0FDNUMsT0FBTyxZQUFZLE9BQU8sVUFBVSxLQUFLLFdBQVk7UUFDakQsT0FBTyxJQUFJLFdBQVcsZUFBZSxZQUFZLE9BQU8sUUFBUSxlQUFlLENBQUMsQ0FBQztPQUNyRixDQUFDO01BQ0wsT0FDSztPQUNELG1CQUFtQixVQUFVLG1CQUFtQixNQUFNO09BQ3RELElBQUksU0FBUyxFQUFFLGFBQWEsS0FBSyxJQUFJLEdBQUcsRUFBRSxJQUFJLElBQUksRUFBRTtPQUNwRCxhQUFhLFNBQVM7T0FDdEIsR0FBRyxRQUFRLElBQUk7T0FDZixJQUFJLGlCQUNBLG9CQUFvQixJQUFJLGtCQUFrQjtPQUU5QyxhQUFhLElBQUksU0FBUyxJQUFJLG9CQUFvQixNQUFNO01BQzVEO0tBQ0osR0FBRyxNQUFNO0tBQ1QsSUFBSSxZQUFZLEtBQUssV0FBWTtNQUM3QixxQkFBcUI7TUFDckIsSUFBSSxRQUFTLEdBQUcsUUFBUSxJQUFJO01BQzVCLElBQUksbUJBQW1CLE1BQU0sTUFBTSxnQkFBZ0I7TUFDbkQsSUFBSSxpQkFBaUIsU0FBUyxHQUMxQixJQUFJO09BQ0EsSUFBSSxXQUFXLE1BQU0sWUFBWSxvQkFBb0IsZ0JBQWdCLEdBQUcsVUFBVTtPQUNsRixJQUFJLE1BQU0sWUFDTixpQkFBaUIsSUFBSSxPQUFPLFFBQVE7WUFDbkM7UUFDRCwyQkFBMkIsSUFBSSxHQUFHLFdBQVcsUUFBUTtRQUNyRCxJQUFJLENBQUMsc0JBQXNCLElBQUksUUFBUSxLQUFLLENBQUMsaUJBQWlCO1NBQzFELFFBQVEsS0FBSyxrTEFBa0w7U0FDL0wsTUFBTSxNQUFNO1NBQ1osa0JBQWtCLE1BQU0sVUFBVTtTQUNsQyxrQkFBa0I7U0FDbEIsT0FBTyxRQUFRLFVBQVUsQ0FBQztRQUM5QjtPQUNKO09BQ0EseUJBQXlCLElBQUksUUFBUTtNQUN6QyxTQUNPLEdBQUcsQ0FDVjtNQUNKLFlBQVksSUFBSSxFQUFFO01BQ2xCLE1BQU0sa0JBQWtCLEtBQUssU0FBVSxJQUFJO09BQ3ZDLE1BQU0sVUFBVTtPQUNoQixHQUFHLEdBQUcsZUFBZSxDQUFDLENBQUMsS0FBSyxFQUFFO01BQ2xDLENBQUM7TUFDRCxNQUFNLFVBQVUsS0FBSyxXQUFZO09BQzdCLEdBQUcsTUFBTSxFQUFFLGlCQUFpQixNQUFNLENBQUM7TUFDdkMsQ0FBQztNQUNELElBQUksWUFDQSxtQkFBbUIsR0FBRyxPQUFPLE1BQU07TUFDdkMsUUFBUTtLQUNaLEdBQUcsTUFBTTtJQUNiLENBQUMsQ0FBQyxDQUFDLE1BQU0sU0FBVSxLQUFLO0tBQ3BCLFFBQVEsUUFBUSxRQUFRLFFBQVEsS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQXREO01BQ0ksS0FBSztPQUNELElBQUksTUFBTSxpQkFBaUIsR0FBRztRQUMxQixNQUFNO1FBQ04sUUFBUSxLQUFLLHFEQUFxRDtRQUNsRSxPQUFPLFVBQVU7T0FDckI7T0FDQTtNQUNKLEtBQUssZ0JBQ0QsSUFBSSxrQkFBa0IsR0FBRztPQUNyQixrQkFBa0I7T0FDbEIsT0FBTyxVQUFVO01BQ3JCO0tBRVI7S0FDQSxPQUFPLGFBQWEsT0FBTyxHQUFHO0lBQ2xDLENBQUM7R0FDTDtHQUNBLE9BQU8sYUFBYSxLQUFLLENBQ3JCLGdCQUNDLE9BQU8sY0FBYyxjQUNoQixhQUFhLFFBQVEsSUFDckIsU0FBUyxFQUFBLENBQUcsS0FBSyxTQUFTLENBQ3BDLENBQUMsQ0FBQyxDQUNHLEtBQUssV0FBWTtJQUNsQixpQkFBaUI7SUFDakIsTUFBTSxvQkFBb0IsQ0FBQztJQUMzQixPQUFPLGFBQWEsUUFBUSxJQUFJLFdBQVk7S0FBRSxPQUFPLEdBQUcsR0FBRyxNQUFNLEtBQUssR0FBRyxHQUFHO0lBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsaUJBQWlCO0tBQzlHLElBQUksTUFBTSxrQkFBa0IsU0FBUyxHQUFHO01BQ3BDLElBQUksZUFBZSxNQUFNLGtCQUFrQixPQUFPLGlCQUFpQixHQUFHO01BQ3RFLE1BQU0sb0JBQW9CLENBQUM7TUFDM0IsT0FBTyxhQUFhLFFBQVEsSUFBSSxXQUFZO09BQUUsT0FBTyxhQUFhLEdBQUcsR0FBRztNQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxjQUFjO0tBQ3RHO0lBQ0osQ0FBQztHQUNMLENBQUMsQ0FBQyxDQUNHLFFBQVEsV0FBWTtJQUNyQixJQUFJLE1BQU0sa0JBQWtCLGVBQWU7S0FDdkMsTUFBTSxvQkFBb0I7S0FDMUIsTUFBTSxnQkFBZ0I7SUFDMUI7R0FDSixDQUFDLENBQUMsQ0FDRyxNQUFNLFNBQVUsS0FBSztJQUN0QixNQUFNLGNBQWM7SUFDcEIsSUFBSTtLQUNBLHNCQUFzQixtQkFBbUIsTUFBTTtJQUNuRCxTQUNPLElBQUksQ0FBRTtJQUNiLElBQUksa0JBQWtCLE1BQU0sZUFDeEIsR0FBRyxPQUFPO0lBRWQsT0FBTyxVQUFVLEdBQUc7R0FDeEIsQ0FBQyxDQUFDLENBQ0csUUFBUSxXQUFZO0lBQ3JCLE1BQU0sZUFBZTtJQUNyQixlQUFlO0dBQ25CLENBQUMsQ0FBQyxDQUNHLEtBQUssV0FBWTtJQUNsQixJQUFJLFlBQVk7S0FDWixJQUFJLGVBQWUsQ0FBQztLQUNwQixHQUFHLE9BQU8sUUFBUSxTQUFVLE9BQU87TUFDL0IsTUFBTSxPQUFPLFFBQVEsUUFBUSxTQUFVLEtBQUs7T0FDeEMsSUFBSSxJQUFJLE1BQ0osYUFBYSxTQUFTLE9BQU8sR0FBRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sSUFBSSxJQUFJLEtBQzlFLElBQUksU0FBUyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQzFDLENBQUM7TUFDRCxhQUFhLFNBQVMsT0FBTyxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBTyxNQUFNLE1BQU0sR0FBRyxLQUFLLGFBQWEsU0FBUyxPQUFPLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQyxPQUFPLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxTQUFTLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDbkwsQ0FBQztLQUNELGFBQWEsZ0NBQWdDLENBQUMsQ0FBQyxLQUFLLFlBQVk7S0FDaEUscUJBQXFCLGNBQWMsSUFBSTtJQUMzQztJQUNBLE9BQU87R0FDWCxDQUFDO0VBQ0w7RUFFQSxTQUFTLGNBQWMsVUFBVTtHQUM3QixJQUFJLFdBQVcsU0FBVSxRQUFRO0lBQUUsT0FBTyxTQUFTLEtBQUssTUFBTTtHQUFHLEdBQUcsVUFBVSxTQUFVLE9BQU87SUFBRSxPQUFPLFNBQVMsTUFBTSxLQUFLO0dBQUcsR0FBRyxZQUFZLEtBQUssUUFBUSxHQUFHLFVBQVUsS0FBSyxPQUFPO0dBQ3BMLFNBQVMsS0FBSyxTQUFTO0lBQ25CLE9BQU8sU0FBVSxLQUFLO0tBQ2xCLElBQUksT0FBTyxRQUFRLEdBQUcsR0FBRyxRQUFRLEtBQUs7S0FDdEMsT0FBTyxLQUFLLE9BQ04sUUFDQSxDQUFDLFNBQVMsT0FBTyxNQUFNLFNBQVMsYUFDNUIsUUFBUSxLQUFLLElBQ1QsUUFBUSxJQUFJLEtBQUssQ0FBQyxDQUFDLEtBQUssV0FBVyxPQUFPLElBQzFDLFVBQVUsS0FBSyxJQUNuQixNQUFNLEtBQUssV0FBVyxPQUFPO0lBQzNDO0dBQ0o7R0FDQSxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUM7RUFDMUI7RUFFQSxTQUFTLHVCQUF1QixNQUFNLGFBQWEsV0FBVztHQUMxRCxJQUFJLElBQUksVUFBVTtHQUNsQixJQUFJLElBQUksR0FDSixNQUFNLElBQUksV0FBVyxnQkFBZ0IsbUJBQW1CO0dBQzVELElBQUksT0FBTyxJQUFJLE1BQU0sSUFBSSxDQUFDO0dBQzFCLE9BQU8sRUFBRSxHQUNMLEtBQUssSUFBSSxLQUFLLFVBQVU7R0FDNUIsWUFBWSxLQUFLLElBQUk7R0FFckIsT0FBTztJQUFDO0lBREssUUFBUSxJQUNGO0lBQUc7R0FBUztFQUNuQztFQUNBLFNBQVMsc0JBQXNCLElBQUksTUFBTSxZQUFZLG1CQUFtQixXQUFXO0dBQy9FLE9BQU8sYUFBYSxRQUFRLENBQUMsQ0FBQyxLQUFLLFdBQVk7SUFDM0MsSUFBSSxZQUFZLElBQUksYUFBYTtJQUNqQyxJQUFJLFFBQVEsR0FBRyxtQkFBbUIsTUFBTSxZQUFZLEdBQUcsV0FBVyxpQkFBaUI7SUFDbkYsTUFBTSxXQUFXO0lBQ2pCLElBQUksWUFBWTtLQUNMO0tBQ0k7SUFDZjtJQUNBLElBQUksbUJBQ0EsTUFBTSxXQUFXLGtCQUFrQjtTQUduQyxJQUFJO0tBQ0EsTUFBTSxPQUFPO0tBQ2IsTUFBTSxTQUFTLFlBQVk7S0FDM0IsR0FBRyxPQUFPLGlCQUFpQjtJQUMvQixTQUNPLElBQUk7S0FDUCxJQUFJLEdBQUcsU0FBUyxTQUFTLGdCQUNyQixHQUFHLE9BQU8sS0FDVixFQUFFLEdBQUcsT0FBTyxpQkFBaUIsR0FBRztNQUNoQyxRQUFRLEtBQUssMEJBQTBCO01BQ3ZDLEdBQUcsTUFBTSxFQUFFLGlCQUFpQixNQUFNLENBQUM7TUFDbkMsT0FBTyxHQUNGLEtBQUssQ0FBQyxDQUNOLEtBQUssV0FBWTtPQUNsQixPQUFPLHNCQUFzQixJQUFJLE1BQU0sWUFBWSxNQUFNLFNBQVM7TUFDdEUsQ0FBQztLQUNMO0tBQ0EsT0FBTyxVQUFVLEVBQUU7SUFDdkI7SUFFSixJQUFJLG1CQUFtQixnQkFBZ0IsU0FBUztJQUNoRCxJQUFJLGtCQUNBLHdCQUF3QjtJQUU1QixJQUFJO0lBQ0osSUFBSSxrQkFBa0IsYUFBYSxPQUFPLFdBQVk7S0FDbEQsY0FBYyxVQUFVLEtBQUssT0FBTyxLQUFLO0tBQ3pDLElBQUksYUFBYTtNQUNiLElBQUksa0JBQWtCO09BQ2xCLElBQUksY0FBYyx3QkFBd0IsS0FBSyxNQUFNLElBQUk7T0FDekQsWUFBWSxLQUFLLGFBQWEsV0FBVztNQUM3QyxPQUNLLElBQUksT0FBTyxZQUFZLFNBQVMsY0FDakMsT0FBTyxZQUFZLFVBQVUsWUFDN0IsY0FBYyxjQUFjLFdBQVc7S0FFL0M7SUFDSixHQUFHLFNBQVM7SUFDWixRQUFRLGVBQWUsT0FBTyxZQUFZLFNBQVMsYUFFM0MsYUFBYSxRQUFRLFdBQVcsQ0FBQyxDQUFDLEtBQUssU0FBVSxHQUFHO0tBQ2hELE9BQU8sTUFBTSxTQUNQLElBQ0EsVUFBVSxJQUFJLFdBQVcsZ0JBQWdCLDREQUE0RCxDQUFDO0lBQ2hILENBQUMsSUFFRCxnQkFBZ0IsS0FBSyxXQUFZO0tBQUUsT0FBTztJQUFhLENBQUMsRUFBQSxDQUMzRCxLQUFLLFNBQVUsR0FBRztLQUNuQixJQUFJLG1CQUNBLE1BQU0sU0FBUztLQUNuQixPQUFPLE1BQU0sWUFBWSxLQUFLLFdBQVk7TUFBRSxPQUFPO0tBQUcsQ0FBQztJQUMzRCxDQUFDLENBQUMsQ0FDRyxNQUFNLFNBQVUsR0FBRztLQUNwQixNQUFNLFFBQVEsQ0FBQztLQUNmLE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7R0FDTCxDQUFDO0VBQ0w7RUFFQSxTQUFTLElBQUksR0FBRyxPQUFPLE9BQU87R0FDMUIsSUFBSSxTQUFTLFFBQVEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQztHQUN4QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFLEdBQ3pCLE9BQU8sS0FBSyxLQUFLO0dBQ3JCLE9BQU87RUFDWDtFQUNBLFNBQVMsNkJBQTZCLE1BQU07R0FDeEMsT0FBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLE9BQU8sU0FBVSxXQUFXO0lBQzFELElBQUksUUFBUSxLQUFLLE1BQU0sU0FBUztJQUNoQyxJQUFJLFNBQVMsTUFBTTtJQUNuQixJQUFJLGNBQWMsT0FBTyxPQUFPLElBQUk7SUFDcEMsSUFBSSxvQkFBb0IsQ0FBQztJQUN6QixTQUFTLGtCQUFrQixTQUFTLFNBQVMsZUFBZTtLQUN4RCxJQUFJLGVBQWUsZ0JBQWdCLE9BQU87S0FDMUMsSUFBSSxZQUFhLFlBQVksZ0JBQ3pCLFlBQVksaUJBQWlCLENBQUM7S0FDbEMsSUFBSSxZQUFZLFdBQVcsT0FDckIsSUFDQSxPQUFPLFlBQVksV0FDZixJQUNBLFFBQVE7S0FDbEIsSUFBSSxZQUFZLFVBQVU7S0FDMUIsSUFBSSxlQUFlLFNBQVMsU0FBUyxDQUFDLEdBQUcsYUFBYSxHQUFHO01BQUUsTUFBTSxZQUN2RCxHQUFHLE9BQU8sY0FBYyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sY0FBYyxNQUFNLEdBQUcsSUFDeEUsY0FBYztNQUFxQjtNQUEwQjtNQUFvQjtNQUFvQjtNQUFXLFlBQVksZ0JBQWdCLE9BQU87TUFBRyxRQUFRLENBQUMsYUFBYSxjQUFjO0tBQU8sQ0FBQztLQUM1TSxVQUFVLEtBQUssWUFBWTtLQUMzQixJQUFJLENBQUMsYUFBYSxjQUNkLGtCQUFrQixLQUFLLFlBQVk7S0FFdkMsSUFBSSxZQUFZLEdBSVosa0JBSHFCLGNBQWMsSUFDN0IsUUFBUSxLQUNSLFFBQVEsTUFBTSxHQUFHLFlBQVksQ0FBQyxHQUNGLFVBQVUsR0FBRyxhQUFhO0tBRWhFLFVBQVUsS0FBSyxTQUFVLEdBQUcsR0FBRztNQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUU7S0FBUyxDQUFDO0tBQ2hFLE9BQU87SUFDWDtJQUNBLElBQUksYUFBYSxrQkFBa0IsT0FBTyxXQUFXLFNBQVMsR0FBRyxPQUFPLFVBQVU7SUFDbEYsWUFBWSxTQUFTLENBQUMsVUFBVTtJQUNoQyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssT0FBTyxTQUFTLEtBQUssR0FBRyxRQUFRLE1BQU07S0FDeEQsSUFBSSxRQUFRLEdBQUc7S0FDZixrQkFBa0IsTUFBTSxTQUFTLEdBQUcsS0FBSztJQUM3QztJQUNBLFNBQVMsY0FBYyxTQUFTO0tBQzVCLElBQUksU0FBUyxZQUFZLGdCQUFnQixPQUFPO0tBQ2hELE9BQU8sVUFBVSxPQUFPO0lBQzVCO0lBQ0EsU0FBUyxlQUFlLE9BQU8sU0FBUztLQUNwQyxPQUFPO01BQ0gsTUFBTSxNQUFNLFNBQVMsSUFDZixJQUNBLE1BQU07TUFDWixPQUFPLElBQUksTUFBTSxPQUFPLE1BQU0sWUFBWSxLQUFLLFVBQVUsS0FBSyxTQUFTLE9BQU87TUFDOUUsV0FBVztNQUNYLE9BQU8sSUFBSSxNQUFNLE9BQU8sTUFBTSxZQUFZLEtBQUssVUFBVSxLQUFLLFNBQVMsT0FBTztNQUM5RSxXQUFXO0tBQ2Y7SUFDSjtJQUNBLFNBQVMsaUJBQWlCLEtBQUs7S0FDM0IsSUFBSSxRQUFRLElBQUksTUFBTTtLQUN0QixPQUFPLE1BQU0sWUFDUCxTQUFTLFNBQVMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxFQUFFLE9BQU87TUFDL0IsT0FBTyxNQUFNO01BQ2IsT0FBTyxlQUFlLElBQUksTUFBTSxPQUFPLE1BQU0sT0FBTztLQUN4RCxFQUFFLENBQUMsSUFBSTtJQUNuQjtJQW9EQSxPQW5EYSxTQUFTLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRztLQUFFLFFBQVEsU0FBUyxTQUFTLENBQUMsR0FBRyxNQUFNLEdBQUc7TUFBYztNQUFZLFNBQVM7TUFBbUIsbUJBQW1CO0tBQWMsQ0FBQztLQUFHLE9BQU8sU0FBVSxLQUFLO01BQzdMLE9BQU8sTUFBTSxNQUFNLGlCQUFpQixHQUFHLENBQUM7S0FDNUM7S0FBRyxPQUFPLFNBQVUsS0FBSztNQUNyQixPQUFPLE1BQU0sTUFBTSxpQkFBaUIsR0FBRyxDQUFDO0tBQzVDO0tBQUcsWUFBWSxTQUFVLEtBQUs7TUFDMUIsSUFBSSxLQUFLLElBQUksTUFDUixPQUFPLFVBQVUsR0FBRyxTQUFTLFlBQVksR0FBRyxXQUFXLFlBQVksR0FBRztNQUMzRSxJQUFJLENBQUMsV0FDRCxPQUFPLE1BQU0sV0FBVyxHQUFHO01BQy9CLFNBQVMsb0JBQW9CLFFBQVE7T0FDakMsU0FBUyxVQUFVLEtBQUs7UUFDcEIsT0FBTyxPQUNELE9BQU8sU0FBUyxJQUFJLEtBQUssSUFBSSxVQUFVLEtBQUssVUFBVSxLQUFLLFNBQVMsT0FBTyxDQUFDLElBQzVFLElBQUksU0FDQSxPQUFPLFNBQVMsT0FBTyxJQUNwQixNQUFNLEdBQUcsU0FBUyxDQUFDLENBQ25CLE9BQU8sSUFBSSxVQUFVLEtBQUssVUFBVSxLQUFLLFNBQVMsT0FBTyxDQUFDLElBQzdELE9BQU8sU0FBUztPQUM5QjtPQTJCQSxPQTFCb0IsT0FBTyxPQUFPLFFBQVE7UUFDdEMsVUFBVSxFQUFFLE9BQU8sVUFBVTtRQUM3QixvQkFBb0IsRUFDaEIsT0FBTyxTQUFVLEtBQUssWUFBWTtTQUM5QixPQUFPLG1CQUFtQixJQUFJLEtBQUssS0FBSyxTQUFTLE9BQU8sR0FBRyxVQUFVO1FBQ3pFLEVBQ0o7UUFDQSxZQUFZLEVBQ1IsS0FBSyxXQUFZO1NBQ2IsT0FBTyxPQUFPO1FBQ2xCLEVBQ0o7UUFDQSxLQUFLLEVBQ0QsS0FBSyxXQUFZO1NBQ2IsSUFBSSxNQUFNLE9BQU87U0FDakIsT0FBTyxjQUFjLElBQ2YsSUFBSSxLQUNKLElBQUksTUFBTSxHQUFHLFNBQVM7UUFDaEMsRUFDSjtRQUNBLE9BQU8sRUFDSCxLQUFLLFdBQVk7U0FDYixPQUFPLE9BQU87UUFDbEIsRUFDSjtPQUNKLENBQ21CO01BQ3ZCO01BQ0EsT0FBTyxNQUNGLFdBQVcsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLENBQ2pDLEtBQUssU0FBVSxRQUFRO09BQUUsT0FBTyxVQUFVLG9CQUFvQixNQUFNO01BQUcsQ0FBQztLQUNqRjtJQUFFLENBQ007R0FDaEIsRUFBRSxDQUFDO0VBQ1g7RUFDQSxJQUFJLHlCQUF5QjtHQUN6QixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxRQUFRO0VBQ1o7RUFFQSxTQUFTLGNBQWMsR0FBRyxHQUFHLElBQUksTUFBTTtHQUNuQyxLQUFLLE1BQU0sQ0FBQztHQUNaLE9BQU8sUUFBUTtHQUNmLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFVLE1BQU07SUFDNUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLEdBQ2YsR0FBRyxPQUFPLFFBQVEsS0FBQTtTQUVqQjtLQUNELElBQUksS0FBSyxFQUFFLE9BQU8sS0FBSyxFQUFFO0tBQ3pCLElBQUksT0FBTyxPQUFPLFlBQVksT0FBTyxPQUFPLFlBQVksTUFBTSxJQUFJO01BQzlELElBQUksYUFBYSxZQUFZLEVBQUU7TUFFL0IsSUFBSSxlQURhLFlBQVksRUFDRCxHQUN4QixHQUFHLE9BQU8sUUFBUSxFQUFFO1dBRW5CLElBQUksZUFBZSxVQUNwQixjQUFjLElBQUksSUFBSSxJQUFJLE9BQU8sT0FBTyxHQUFHO1dBRTFDLElBQUksT0FBTyxJQUNaLEdBQUcsT0FBTyxRQUFRLEVBQUU7S0FFNUIsT0FDSyxJQUFJLE9BQU8sSUFDWixHQUFHLE9BQU8sUUFBUSxFQUFFO0lBQzVCO0dBQ0osQ0FBQztHQUNELEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFVLE1BQU07SUFDNUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLEdBQ2YsR0FBRyxPQUFPLFFBQVEsRUFBRTtHQUU1QixDQUFDO0dBQ0QsT0FBTztFQUNYO0VBRUEsU0FBUyxpQkFBaUIsWUFBWSxLQUFLO0dBQ3ZDLElBQUksSUFBSSxTQUFTLFVBQ2IsT0FBTyxJQUFJO0dBQ2YsT0FBTyxJQUFJLFFBQVEsSUFBSSxPQUFPLElBQUksV0FBVyxVQUFVO0VBQzNEO0VBRUEsSUFBSSxrQkFBa0I7R0FDbEIsT0FBTztHQUNQLE1BQU07R0FDTixPQUFPO0dBQ1AsUUFBUSxTQUFVLFVBQVU7SUFDeEIsT0FBUSxTQUFTLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxFQUFFLE9BQU8sU0FBVSxXQUFXO0tBQy9ELElBQUksWUFBWSxTQUFTLE1BQU0sU0FBUztLQUN4QyxJQUFJLGFBQWEsVUFBVSxPQUFPO0tBbUlsQyxPQWxJc0IsU0FBUyxTQUFTLENBQUMsR0FBRyxTQUFTLEdBQUcsRUFBRSxRQUFRLFNBQVUsS0FBSztNQUN6RSxJQUFJLFVBQVUsSUFBSTtNQUNsQixJQUFJLEtBQUssUUFBUSxNQUFNLFNBQVMsQ0FBQyxDQUFDLE1BQU0sV0FBVyxHQUFHLFVBQVUsV0FBVyxHQUFHLFVBQVUsV0FBVyxHQUFHO01BQ3RHLFFBQVEsSUFBSSxNQUFaO09BQ0ksS0FBSztRQUNELElBQUksU0FBUyxTQUFTLEtBQ2xCO1FBQ0osT0FBTyxRQUFRLFNBQVMsYUFBYSxXQUFZO1NBQUUsT0FBTyxlQUFlLEdBQUc7UUFBRyxHQUFHLElBQUk7T0FDMUYsS0FBSztRQUNELElBQUksU0FBUyxTQUFTLE9BQU8sU0FBUyxTQUFTLEtBQzNDO1FBQ0osT0FBTyxRQUFRLFNBQVMsYUFBYSxXQUFZO1NBQUUsT0FBTyxlQUFlLEdBQUc7UUFBRyxHQUFHLElBQUk7T0FDMUYsS0FBSztRQUNELElBQUksU0FBUyxTQUFTLEtBQ2xCO1FBQ0osT0FBTyxRQUFRLFNBQVMsYUFBYSxXQUFZO1NBQUUsT0FBTyxlQUFlLEdBQUc7UUFBRyxHQUFHLElBQUk7T0FDMUYsS0FBSztRQUNELElBQUksU0FBUyxTQUFTLEtBQ2xCO1FBQ0osT0FBTyxRQUFRLFNBQVMsYUFBYSxXQUFZO1NBQUUsT0FBTyxZQUFZLEdBQUc7UUFBRyxHQUFHLElBQUk7TUFDM0Y7TUFDQSxPQUFPLFVBQVUsT0FBTyxHQUFHO01BQzNCLFNBQVMsZUFBZSxLQUFLO09BQ3pCLElBQUksVUFBVSxJQUFJO09BQ2xCLElBQUksT0FBTyxJQUFJLFFBQVEsaUJBQWlCLFlBQVksR0FBRztPQUN2RCxJQUFJLENBQUMsTUFDRCxNQUFNLElBQUksTUFBTSxjQUFjO09BQ2xDLE1BQ0ksSUFBSSxTQUFTLFNBQVMsSUFBSSxTQUFTLFFBQzdCLFNBQVMsU0FBUyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQVEsS0FBSyxDQUFDLElBQUksU0FBUyxDQUFDLEdBQUcsR0FBRztPQUN4RSxJQUFJLElBQUksU0FBUyxVQUNiLElBQUksU0FBUyxjQUFjLENBQUMsR0FBRyxJQUFJLFFBQVEsSUFBSTtPQUNuRCxJQUFJLElBQUksTUFDSixJQUFJLE9BQU8sY0FBYyxDQUFDLEdBQUcsSUFBSSxNQUFNLElBQUk7T0FDL0MsT0FBTyxrQkFBa0IsV0FBVyxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssU0FBVSxnQkFBZ0I7UUFDMUUsSUFBSSxXQUFXLEtBQUssSUFBSSxTQUFVLEtBQUssR0FBRztTQUN0QyxJQUFJLGdCQUFnQixlQUFlO1NBQ25DLElBQUksTUFBTTtVQUFFLFNBQVM7VUFBTSxXQUFXO1NBQUs7U0FDM0MsSUFBSSxJQUFJLFNBQVMsVUFDYixTQUFTLEtBQUssS0FBSyxLQUFLLEtBQUssZUFBZSxPQUFPO2NBRWxELElBQUksSUFBSSxTQUFTLFNBQ2xCLGtCQUFrQixLQUFBLEdBQVc7VUFDN0IsSUFBSSxzQkFBc0IsU0FBUyxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksT0FBTyxJQUFJLE9BQU87VUFDN0UsSUFBSSxPQUFPLFFBQVEsdUJBQXVCLE1BQU07V0FDNUMsTUFBTTtXQUNOLElBQUksS0FBSyxLQUFLO1dBQ2QsSUFBSSxDQUFDLFdBQVcsVUFDWixhQUFhLElBQUksT0FBTyxJQUFJLFdBQVcsU0FBUyxHQUFHO1VBRTNEO1NBQ0osT0FDSztVQUNELElBQUksYUFBYSxjQUFjLGVBQWUsSUFBSSxPQUFPLEVBQUU7VUFDM0QsSUFBSSxzQkFBc0IsU0FBUyxLQUFLLEtBQUssS0FBSyxZQUFZLEtBQUssZUFBZSxPQUFPO1VBQ3pGLElBQUkscUJBQXFCO1dBQ3JCLElBQUksbUJBQW1CLElBQUksT0FBTztXQUNsQyxPQUFPLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxRQUFRLFNBQVUsU0FBUztZQUN4RCxJQUFJLE9BQU8sa0JBQWtCLE9BQU8sR0FDaEMsaUJBQWlCLFdBQ2Isb0JBQW9CO2lCQUd4QixhQUFhLGtCQUFrQixTQUFTLG9CQUFvQixRQUFRO1dBRTVFLENBQUM7VUFDTDtTQUNKO1NBQ0EsT0FBTztRQUNYLENBQUM7UUFDRCxPQUFPLFVBQ0YsT0FBTyxHQUFHLENBQUMsQ0FDWCxLQUFLLFNBQVUsSUFBSTtTQUNwQixJQUFJLFdBQVcsR0FBRyxVQUFVLFVBQVUsR0FBRyxTQUFTLGNBQWMsR0FBRyxhQUFhLGFBQWEsR0FBRztTQUNoRyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEVBQUUsR0FBRztVQUNsQyxJQUFJLFVBQVUsVUFBVSxRQUFRLEtBQUssS0FBSztVQUMxQyxJQUFJLE1BQU0sU0FBUztVQUNuQixJQUFJLFdBQVcsTUFDWCxJQUFJLFdBQVcsSUFBSSxRQUFRLFNBQVMsRUFBRTtlQUd0QyxJQUFJLGFBQ0EsSUFBSSxVQUFVLElBQUksU0FBUyxTQUFTLGVBQWUsS0FDN0MsSUFBSSxPQUFPLEtBQ1gsT0FDTjtTQUVaO1NBQ0EsT0FBTztVQUFZO1VBQW1CO1VBQXNCO1VBQXlCO1NBQVc7UUFDcEcsQ0FBQyxDQUFDLENBQ0csTUFBTSxTQUFVLE9BQU87U0FDeEIsU0FBUyxRQUFRLFNBQVUsS0FBSztVQUFFLE9BQU8sSUFBSSxXQUFXLElBQUksUUFBUSxLQUFLO1NBQUcsQ0FBQztTQUM3RSxPQUFPLFFBQVEsT0FBTyxLQUFLO1FBQy9CLENBQUM7T0FDTCxDQUFDO01BQ0w7TUFDQSxTQUFTLFlBQVksS0FBSztPQUN0QixPQUFPLGdCQUFnQixJQUFJLE9BQU8sSUFBSSxPQUFPLEdBQUs7TUFDdEQ7TUFDQSxTQUFTLGdCQUFnQixPQUFPLE9BQU8sT0FBTztPQUMxQyxPQUFPLFVBQ0YsTUFBTTtRQUNBO1FBQ1AsUUFBUTtRQUNSLE9BQU87U0FBRSxPQUFPO1NBQW1CO1FBQU07UUFDbEM7T0FDWCxDQUFDLENBQUMsQ0FDRyxLQUFLLFNBQVUsSUFBSTtRQUNwQixJQUFJLFNBQVMsR0FBRztRQUNoQixPQUFPLGVBQWU7U0FDbEIsTUFBTTtTQUNOLE1BQU07U0FDQztRQUNYLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBVSxLQUFLO1NBQ25CLElBQUksSUFBSSxjQUFjLEdBQ2xCLE9BQU8sUUFBUSxPQUFPLElBQUksU0FBUyxFQUFFO1NBQ3pDLElBQUksT0FBTyxTQUFTLE9BQ2hCLE9BQU87VUFDSCxVQUFVLENBQUM7VUFDWCxhQUFhO1VBQ2IsWUFBWSxLQUFBO1NBQ2hCO2NBR0EsT0FBTyxnQkFBZ0IsT0FBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRztVQUFFLE9BQU8sT0FBTyxPQUFPLFNBQVM7VUFBSSxXQUFXO1NBQUssQ0FBQyxHQUFHLEtBQUs7UUFFakksQ0FBQztPQUNMLENBQUM7TUFDTDtLQUNKLEVBQUUsQ0FDZTtJQUN6QixFQUFFLENBQUM7R0FDWDtFQUNKO0VBQ0EsU0FBUyxrQkFBa0IsT0FBTyxLQUFLLGVBQWU7R0FDbEQsT0FBTyxJQUFJLFNBQVMsUUFDZCxRQUFRLFFBQVEsQ0FBQyxDQUFDLElBQ2xCLE1BQU0sUUFBUTtJQUNaLE9BQU8sSUFBSTtJQUNYLE1BQU07SUFDTixPQUFPO0dBQ1gsQ0FBQztFQUNUO0VBRUEsU0FBUyx3QkFBd0IsTUFBTSxPQUFPLE9BQU87R0FDakQsSUFBSTtJQUNBLElBQUksQ0FBQyxPQUNELE9BQU87SUFDWCxJQUFJLE1BQU0sS0FBSyxTQUFTLEtBQUssUUFDekIsT0FBTztJQUNYLElBQUksU0FBUyxDQUFDO0lBQ2QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUssVUFBVSxJQUFJLEtBQUssUUFBUSxFQUFFLEdBQUc7S0FDbEUsSUFBSSxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxNQUFNLEdBQ2hDO0tBQ0osT0FBTyxLQUFLLFFBQVEsVUFBVSxNQUFNLE9BQU8sRUFBRSxJQUFJLE1BQU0sT0FBTyxFQUFFO0tBQ2hFLEVBQUU7SUFDTjtJQUNBLE9BQU8sT0FBTyxXQUFXLEtBQUssU0FBUyxTQUFTO0dBQ3BELFNBQ08sSUFBSTtJQUNQLE9BQU87R0FDWDtFQUNKO0VBQ0EsSUFBSSxnQ0FBZ0M7R0FDaEMsT0FBTztHQUNQLE9BQU87R0FDUCxRQUFRLFNBQVUsTUFBTTtJQUNwQixPQUFPLEVBQ0gsT0FBTyxTQUFVLFdBQVc7S0FDeEIsSUFBSSxRQUFRLEtBQUssTUFBTSxTQUFTO0tBQ2hDLE9BQU8sU0FBUyxTQUFTLENBQUMsR0FBRyxLQUFLLEdBQUc7TUFBRSxTQUFTLFNBQVUsS0FBSztPQUN2RCxJQUFJLENBQUMsSUFBSSxPQUNMLE9BQU8sTUFBTSxRQUFRLEdBQUc7T0FFNUIsSUFBSSxlQUFlLHdCQUF3QixJQUFJLE1BQU0sSUFBSSxNQUFNLFdBQVcsSUFBSSxVQUFVLE9BQU87T0FDL0YsSUFBSSxjQUNBLE9BQU8sYUFBYSxRQUFRLFlBQVk7T0FFNUMsT0FBTyxNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsS0FBSyxTQUFVLEtBQUs7UUFDMUMsSUFBSSxNQUFNLFlBQVk7U0FDbEIsTUFBTSxJQUFJO1NBQ1YsUUFBUSxJQUFJLFVBQVUsVUFBVSxVQUFVLEdBQUcsSUFBSTtRQUNyRDtRQUNBLE9BQU87T0FDWCxDQUFDO01BQ0w7TUFBRyxRQUFRLFNBQVUsS0FBSztPQUN0QixJQUFJLElBQUksU0FBUyxPQUNiLElBQUksTUFBTSxZQUFZO09BQzFCLE9BQU8sTUFBTSxPQUFPLEdBQUc7TUFDM0I7S0FBRSxDQUFDO0lBQ1gsRUFDSjtHQUNKO0VBQ0o7RUFFQSxTQUFTLGtCQUFrQixLQUFLLE9BQU87R0FDbkMsT0FBUSxJQUFJLE1BQU0sU0FBUyxjQUN2QixDQUFDLENBQUMsSUFBSSxVQUNOLENBQUMsSUFBSSxNQUFNLFlBQ1gsSUFBSSxNQUFNLEdBQUcsU0FBUyxVQUFVLGNBQ2hDLENBQUMsTUFBTSxPQUFPLFdBQVc7RUFDakM7RUFFQSxTQUFTLGtCQUFrQixNQUFNLEtBQUs7R0FDbEMsUUFBUSxNQUFSO0lBQ0ksS0FBSyxTQUNELE9BQU8sSUFBSSxVQUFVLENBQUMsSUFBSTtJQUM5QixLQUFLLE9BQ0QsT0FBTztJQUNYLEtBQUssV0FDRCxPQUFPO0lBQ1gsS0FBSyxTQUNELE9BQU87SUFDWCxLQUFLLGNBQ0QsT0FBTztHQUNmO0VBQ0o7RUFFQSxJQUFJLDBCQUEwQjtHQUMxQixPQUFPO0dBQ1AsT0FBTztHQUNQLE1BQU07R0FDTixRQUFRLFNBQVUsTUFBTTtJQUNwQixJQUFJLFNBQVMsS0FBSyxPQUFPO0lBQ3pCLElBQUksYUFBYSxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssT0FBTztJQUN4RCxPQUFPLFNBQVMsU0FBUyxDQUFDLEdBQUcsSUFBSSxHQUFHO0tBQUUsYUFBYSxTQUFVLFFBQVEsTUFBTSxTQUFTO01BQzVFLElBQUksSUFBSSxVQUFVLFNBQVMsWUFDdkIsTUFBTSxJQUFJLFdBQVcsU0FBUywrREFBK0QsT0FBTyxJQUFJLE9BQU8sQ0FBQztNQUVwSCxPQUFPLEtBQUssWUFBWSxRQUFRLE1BQU0sT0FBTztLQUNqRDtLQUFHLE9BQU8sU0FBVSxXQUFXO01BQzNCLElBQUksUUFBUSxLQUFLLE1BQU0sU0FBUztNQUNoQyxJQUFJLFNBQVMsTUFBTTtNQUNuQixJQUFJLGFBQWEsT0FBTyxZQUFZLFVBQVUsT0FBTztNQUNyRCxJQUFJLGFBQWEsV0FBVyxZQUFZLFdBQVcsV0FBVztNQUM5RCxJQUFJLHVCQUF1QixXQUFXLGlCQUNsQyxRQUFRLE9BQU8sU0FBVSxPQUFPO09BQzVCLE9BQU8sTUFBTSxZQUNULE1BQU0sUUFBUSxTQUFTLFdBQVcsT0FBTztNQUNqRCxDQUFDO01BQ0wsSUFBSSxhQUFhLFNBQVMsU0FBUyxDQUFDLEdBQUcsS0FBSyxHQUFHLEVBQUUsUUFBUSxTQUFVLEtBQUs7T0FDaEUsSUFBSSxJQUFJO09BQ1IsSUFBSSxRQUFRLElBQUk7T0FDaEIsSUFBSSxlQUFlLElBQUksaUJBQWlCLElBQUksZUFBZSxDQUFDO09BQzVELElBQUksY0FBYyxTQUFVLFdBQVc7UUFDbkMsSUFBSSxPQUFPLFNBQVMsT0FBTyxRQUFRLEdBQUcsQ0FBQyxDQUFDLE9BQU8sV0FBVyxHQUFHLENBQUMsQ0FBQyxPQUFPLFNBQVM7UUFDL0UsT0FBUSxhQUFhLFVBQ2hCLGFBQWEsUUFBUSxJQUFJLFNBQVM7T0FDM0M7T0FDQSxJQUFJLGFBQWEsWUFBWSxFQUFFO09BQy9CLElBQUksZUFBZSxZQUFZLE9BQU87T0FDdEMsSUFBSSxPQUFPLElBQUk7T0FDZixJQUFJLEtBQUssSUFBSSxTQUFTLGdCQUNoQixDQUFDLElBQUksS0FBSyxJQUNWLElBQUksU0FBUyxXQUNULENBQUMsSUFBSSxJQUFJLElBQ1QsSUFBSSxPQUFPLFNBQVMsS0FDaEIsQ0FDRSxpQkFBaUIsWUFBWSxHQUFHLENBQUMsQ0FBQyxPQUFPLFNBQVUsSUFBSTtRQUFFLE9BQU87T0FBSSxDQUFDLEdBQ3JFLElBQUksTUFDUixJQUNFLENBQUMsR0FBRyxPQUFPLEdBQUcsSUFBSSxVQUFVLEdBQUc7T0FDN0MsSUFBSSxXQUFXLElBQUksTUFBTTtPQUN6QixJQUFJLFFBQVEsSUFBSSxHQUFHO1FBQ2YsV0FBVyxRQUFRLElBQUk7UUFDdkIsSUFBSSxVQUFVLFNBQVMsWUFBWSxLQUFLLFdBQVcsUUFBUSxTQUNyRCx3QkFBd0IsTUFBTSxRQUFRLElBQ3RDO1FBQ04sSUFBSSxDQUFDLFNBQ0QsYUFBYSxRQUFRLElBQUk7UUFFN0IsSUFBSSxXQUFXLFNBQ1gscUJBQXFCLGFBQWEsUUFBUSxTQUFTLE9BQU87T0FFbEUsT0FDSyxJQUFJLE1BQU07UUFDWCxJQUFJLFFBQVE7U0FDUixPQUFPLEtBQUssS0FBSyxXQUFXLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxLQUFLO1NBQzlELEtBQUssS0FBSyxLQUFLLFdBQVcsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLEtBQUs7UUFDaEU7UUFDQSxhQUFhLElBQUksS0FBSztRQUN0QixXQUFXLElBQUksS0FBSztPQUN4QixPQUNLO1FBQ0QsV0FBVyxJQUFJLFVBQVU7UUFDekIsYUFBYSxJQUFJLFVBQVU7UUFDM0IsT0FBTyxRQUFRLFFBQVEsU0FBVSxLQUFLO1NBQ2xDLE9BQU8sWUFBWSxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksVUFBVTtRQUMvQyxDQUFDO09BQ0w7T0FDQSxPQUFPLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLFNBQVUsS0FBSztRQUN6QyxJQUFJLFNBQVMsSUFBSSxTQUFTLFNBQVMsSUFBSSxTQUFTLFFBQVE7U0FDcEQsV0FBVyxRQUFRLElBQUksT0FBTztTQUM5QixJQUFJLHNCQUNBLHFCQUFxQixRQUFRLFNBQVUsS0FBSztVQUN4QyxJQUFJLFVBQVUsSUFBSSxPQUFPLElBQUksU0FBVSxHQUFHO1dBQUUsT0FBTyxJQUFJLFdBQVcsQ0FBQztVQUFHLENBQUM7VUFDdkUsSUFBSSxRQUFRLElBQUksUUFBUSxVQUFVLFNBQVUsTUFBTTtXQUFFLE9BQU8sU0FBUyxXQUFXO1VBQVMsQ0FBQztVQUN6RixLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sSUFBSSxRQUFRLFFBQVEsSUFBSSxLQUFLLEVBQUUsR0FDakQsUUFBUSxFQUFFLENBQUMsU0FBUyxJQUFJLFFBQVE7VUFFcEMsWUFBWSxJQUFJLElBQUksQ0FBQyxDQUFDLFFBQVEsT0FBTztTQUN6QyxDQUFDO1FBRVQ7UUFDQSxNQUFNLGVBQWUsdUJBQXVCLE1BQU0sZ0JBQWdCLENBQUMsR0FBRyxZQUFZO1FBQ2xGLE9BQU87T0FDWCxDQUFDO01BQ0wsRUFBRSxDQUFDO01BQ1AsSUFBSSxXQUFXLFNBQVUsSUFBSTtPQUN6QixJQUFJLElBQUk7T0FDUixJQUFJLEtBQUssR0FBRyxPQUFPLFFBQVEsR0FBRyxPQUFPLFFBQVEsR0FBRztPQUNoRCxPQUFPLENBQ0gsT0FDQSxJQUFJLFVBQVUsS0FBSyxNQUFNLFdBQVcsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLEtBQUssVUFBVSxLQUFLLE1BQU0sV0FBVyxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLENBQ25KO01BQ0o7TUFDQSxJQUFJLGtCQUFrQjtPQUNsQixLQUFLLFNBQVUsS0FBSztRQUFFLE9BQU8sQ0FBQyxZQUFZLElBQUksU0FBUyxJQUFJLEdBQUcsQ0FBQztPQUFHO09BQ2xFLFNBQVMsU0FBVSxLQUFLO1FBQUUsT0FBTyxDQUFDLFlBQVksSUFBSSxTQUFTLENBQUMsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDO09BQUc7T0FDakYsT0FBTztPQUNQLE9BQU87T0FDUCxZQUFZO01BQ2hCO01BQ0EsS0FBSyxlQUFlLENBQUMsQ0FBQyxRQUFRLFNBQVUsUUFBUTtPQUM1QyxXQUFXLFVBQVUsU0FBVSxLQUFLO1FBQ2hDLElBQUksU0FBUyxJQUFJO1FBQ2pCLElBQUksY0FBYyxDQUFDLENBQUM7UUFHcEIsSUFBSSxTQUZXLGtCQUFrQixLQUFLLEtBQUssS0FDdkMsa0JBQWtCLFFBQVEsR0FBRyxJQUUxQixJQUFJLFNBQVMsQ0FBQyxJQUNmO1FBQ04sSUFBSSxhQUFhO1NBQ2IsSUFBSSxjQUFjLFNBQVUsV0FBVztVQUNuQyxJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxXQUFXLEdBQUcsQ0FBQyxDQUFDLE9BQU8sU0FBUztVQUMvRSxPQUFRLE9BQU8sVUFDVixPQUFPLFFBQVEsSUFBSSxTQUFTO1NBQ3JDO1NBQ0EsSUFBSSxlQUFlLFlBQVksRUFBRTtTQUNqQyxJQUFJLGlCQUFpQixZQUFZLE9BQU87U0FDeEMsSUFBSSxLQUFLLGdCQUFnQixPQUFPLENBQUMsR0FBRyxHQUFHLGVBQWUsR0FBRyxJQUFJLGdCQUFnQixHQUFHO1NBQ2hGLElBQUksV0FBVyxXQUNYLGFBQWEsZ0JBQ2IsQ0FBQyxJQUFJLFFBQ0wsZUFBZSxJQUFJLGFBQWE7Y0FHaEMsWUFBWSxhQUFhLFFBQVEsRUFBRSxDQUFDLENBQUMsSUFBSSxhQUFhO1NBRTFELElBQUksQ0FBQyxhQUFhLGNBQWM7VUFDNUIsSUFBSSxXQUFXLFNBQ1gsZUFBZSxJQUFJLFVBQVU7ZUFFNUI7V0FDRCxJQUFJLGdCQUFnQixXQUFXLFdBQzNCLFlBQ0EsSUFBSSxVQUNKLE1BQU0sTUFBTSxTQUFTLFNBQVMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxFQUFFLFFBQVEsTUFBTSxDQUFDLENBQUM7V0FDOUQsT0FBTyxNQUFNLE9BQU8sQ0FBQyxNQUFNLE1BQU0sU0FBUyxDQUFDLENBQUMsS0FBSyxTQUFVLEtBQUs7WUFDNUQsSUFBSSxXQUFXLFNBQVM7YUFDcEIsSUFBSSxZQUFZLElBQUksUUFDaEIsT0FBTyxjQUFjLEtBQUssU0FBVSxJQUFJO2NBQ3BDLElBQUksZ0JBQWdCLEdBQUc7Y0FDdkIsYUFBYSxRQUFRLGFBQWE7Y0FDbEMsT0FBTzthQUNYLENBQUM7YUFFTCxJQUFJLFFBQVEsSUFBSSxTQUNWLElBQUksT0FBTyxJQUFJLFVBQVUsSUFDekIsSUFBSTthQUNWLElBQUksSUFBSSxRQUNKLGFBQWEsUUFBUSxLQUFLO2tCQUcxQixlQUFlLFFBQVEsS0FBSztZQUVwQyxPQUNLLElBQUksV0FBVyxjQUFjO2FBQzlCLElBQUksV0FBVzthQUNmLElBQUksZUFBZSxJQUNkO2FBQ0wsT0FBUSxZQUNKLE9BQU8sT0FBTyxVQUFVO2NBQ3BCLEtBQUssRUFDRCxLQUFLLFdBQVk7ZUFDYixlQUFlLE9BQU8sU0FBUyxVQUFVO2VBQ3pDLE9BQU8sU0FBUztjQUNwQixFQUNKO2NBQ0EsWUFBWSxFQUNSLEtBQUssV0FBWTtlQUNiLElBQUksT0FBTyxTQUFTO2VBQ3BCLGVBQWUsT0FBTyxJQUFJO2VBQzFCLE9BQU87Y0FDWCxFQUNKO2NBQ0EsT0FBTyxFQUNILEtBQUssV0FBWTtlQUNiLGdCQUNJLGFBQWEsT0FBTyxTQUFTLFVBQVU7ZUFDM0MsT0FBTyxTQUFTO2NBQ3BCLEVBQ0o7YUFDSixDQUFDO1lBQ1Q7WUFDQSxPQUFPO1dBQ1gsQ0FBQztVQUNMO1NBQ0o7UUFDSjtRQUNBLE9BQU8sTUFBTSxPQUFPLENBQUMsTUFBTSxNQUFNLFNBQVM7T0FDOUM7TUFDSixDQUFDO01BQ0QsT0FBTztLQUNYO0lBQUUsQ0FBQztHQUNYO0VBQ0o7RUFDQSxTQUFTLHFCQUFxQixhQUFhLFFBQVEsU0FBUyxTQUFTO0dBQ2pFLFNBQVMsaUJBQWlCLElBQUk7SUFDMUIsSUFBSSxXQUFXLFlBQVksR0FBRyxRQUFRLEVBQUU7SUFDeEMsU0FBUyxXQUFXLEtBQUs7S0FDckIsT0FBTyxPQUFPLE9BQU8sR0FBRyxXQUFXLEdBQUcsSUFBSTtJQUM5QztJQUNBLElBQUksZUFBZSxTQUFVLEtBQUs7S0FDOUIsT0FBTyxHQUFHLGNBQWMsUUFBUSxHQUFHLElBRTNCLElBQUksUUFBUSxTQUFVLEtBQUs7TUFBRSxPQUFPLFNBQVMsT0FBTyxHQUFHO0tBQUcsQ0FBQyxJQUUzRCxTQUFTLE9BQU8sR0FBRztJQUMvQjtJQUNBLENBQUMsV0FBVyxRQUFBLENBQVMsUUFBUSxTQUFVLEdBQUcsR0FBRztLQUN6QyxJQUFJLFNBQVMsV0FBVyxXQUFXLFFBQVEsRUFBRTtLQUM3QyxJQUFJLFNBQVMsV0FBVyxXQUFXLFFBQVEsRUFBRTtLQUM3QyxJQUFJLElBQUksUUFBUSxNQUFNLE1BQU0sR0FBRztNQUMzQixJQUFJLFVBQVUsTUFDVixhQUFhLE1BQU07TUFDdkIsSUFBSSxVQUFVLE1BQ1YsYUFBYSxNQUFNO0tBQzNCO0lBQ0osQ0FBQztHQUNMO0dBQ0EsT0FBTyxRQUFRLFFBQVEsZ0JBQWdCO0VBQzNDO0VBRUEsU0FBUyw2QkFBNkIsVUFBVSxLQUFLLEtBQUs7R0FDdEQsSUFBSSxJQUFJLGdCQUFnQixHQUNwQixPQUFPO0dBQ1gsSUFBSSxJQUFJLFNBQVMsZUFDYixPQUFPO0dBRVgsSUFBSSxhQUFhLElBQUksT0FDZixJQUFJLEtBQUssU0FDVCxZQUFZLE9BQU8sSUFBSSxTQUNuQixJQUFJLE9BQU8sU0FDWDtHQUNWLElBQUksSUFBSSxnQkFBZ0IsWUFDcEIsT0FBTztHQUVYLElBQUksUUFBUSxTQUFTLENBQUMsR0FBRyxHQUFHO0dBQzVCLElBQUksUUFBUSxNQUFNLElBQUksR0FDbEIsTUFBTSxPQUFPLE1BQU0sS0FBSyxPQUFPLFNBQVUsR0FBRyxHQUFHO0lBQUUsT0FBTyxFQUFFLEtBQUssSUFBSTtHQUFXLENBQUM7R0FFbkYsSUFBSSxZQUFZLFNBQVMsUUFBUSxNQUFNLE1BQU0sR0FDekMsTUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLFNBQVUsR0FBRyxHQUFHO0lBQUUsT0FBTyxFQUFFLEtBQUssSUFBSTtHQUFXLENBQUM7R0FFdkYsT0FBTztFQUNYO0VBRUEsU0FBUyxhQUFhLEtBQUssT0FBTztHQUM5QixPQUFPLE1BQU0sVUFBVSxLQUFBLElBQ2pCLE9BQ0EsTUFBTSxZQUNGLElBQUksS0FBSyxNQUFNLEtBQUssSUFBSSxJQUN4QixJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUs7RUFDdkM7RUFDQSxTQUFTLGFBQWEsS0FBSyxPQUFPO0dBQzlCLE9BQU8sTUFBTSxVQUFVLEtBQUEsSUFDakIsT0FDQSxNQUFNLFlBQ0YsSUFBSSxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQ3hCLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSztFQUN2QztFQUNBLFNBQVMsY0FBYyxLQUFLLE9BQU87R0FDL0IsT0FBTyxhQUFhLEtBQUssS0FBSyxLQUFLLGFBQWEsS0FBSyxLQUFLO0VBQzlEO0VBRUEsU0FBUyxtQkFBbUIsUUFBUSxLQUFLLEtBQUssT0FBTyxZQUFZLFdBQVc7R0FDeEUsSUFBSSxDQUFDLE9BQU8sSUFBSSxXQUFXLEdBQ3ZCLE9BQU87R0FDWCxJQUFJLFFBQVEsSUFBSSxNQUFNO0dBQ3RCLElBQUksYUFBYSxNQUFNO0dBQ3ZCLElBQUksYUFBYSxJQUFJLE1BQU07R0FFM0IsSUFBSSxpQkFEYSxNQUFNLE9BQU8sV0FDRTtHQUNoQyxJQUFJLGVBQWUsTUFBTTtHQUN6QixJQUFJLHdCQUF3QixNQUFNLGlCQUFpQixNQUFBLENBQU87R0FDMUQsSUFBSSxjQUFjLElBQUksT0FBTyxTQUFVLFFBQVEsSUFBSTtJQUMvQyxJQUFJLGdCQUFnQjtJQUNwQixJQUFJLGlCQUFpQixDQUFDO0lBQ3RCLElBQUksR0FBRyxTQUFTLFNBQVMsR0FBRyxTQUFTLE9BQU87S0FDeEMsSUFBSSxjQUFjLElBQUksU0FBUztLQUMvQixLQUFLLElBQUksSUFBSSxHQUFHLE9BQU8sU0FBUyxHQUFHLEtBQUssR0FBRyxFQUFFLEdBQUc7TUFDNUMsSUFBSSxRQUFRLEdBQUcsT0FBTztNQUN0QixJQUFJLEtBQUssZUFBZSxLQUFLO01BQzdCLElBQUksWUFBWSxPQUFPLEVBQUUsR0FDckI7TUFDSixJQUFJLE1BQU0sYUFBYSxLQUFLO01BQzVCLElBQUksY0FBYyxRQUFRLEdBQUcsSUFDdkIsSUFBSSxLQUFLLFNBQVUsR0FBRztPQUFFLE9BQU8sY0FBYyxHQUFHLFVBQVU7TUFBRyxDQUFDLElBQzlELGNBQWMsS0FBSyxVQUFVLEdBQUc7T0FDbEMsWUFBWSxPQUFPLEVBQUU7T0FDckIsZUFBZSxLQUFLLEtBQUs7TUFDN0I7S0FDSjtJQUNKO0lBQ0EsUUFBUSxHQUFHLE1BQVg7S0FDSSxLQUFLO01BQ0QsSUFBSSxpQkFBaUIsSUFBSSxTQUFTLENBQUMsQ0FBQyxRQUFRLElBQUksU0FBUyxPQUFPLElBQUksU0FBVSxHQUFHO09BQUUsT0FBTyxlQUFlLENBQUM7TUFBRyxDQUFDLElBQUksTUFBTTtNQUN4SCxnQkFBZ0IsT0FBTyxPQUFPLElBQUksU0FDNUIsZUFBZSxPQUFPLFNBQVUsR0FBRztPQUNqQyxJQUFJLE1BQU0sZUFBZSxDQUFDO09BQzFCLElBQUksZUFBZSxPQUFPLEdBQUcsR0FDekIsT0FBTztPQUNYLGVBQWUsT0FBTyxHQUFHO09BQ3pCLE9BQU87TUFDWCxDQUFDLElBQ0MsZUFDRyxJQUFJLFNBQVUsR0FBRztPQUFFLE9BQU8sZUFBZSxDQUFDO01BQUcsQ0FBQyxDQUFDLENBQy9DLE9BQU8sU0FBVSxHQUFHO09BQ3JCLElBQUksZUFBZSxPQUFPLENBQUMsR0FDdkIsT0FBTztPQUNYLGVBQWUsT0FBTyxDQUFDO09BQ3ZCLE9BQU87TUFDWCxDQUFDLENBQUM7TUFDTjtLQUVKLEtBQUs7TUFDRCxJQUFJLFdBQVcsSUFBSSxTQUFTLENBQUMsQ0FBQyxRQUFRLEdBQUcsT0FBTyxJQUFJLFNBQVUsR0FBRztPQUFFLE9BQU8sZUFBZSxDQUFDO01BQUcsQ0FBQyxDQUFDO01BQy9GLGdCQUFnQixPQUNYLE9BQ0wsU0FBVSxNQUFNO09BQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxJQUFJLFNBQVMsZUFBZSxJQUFJLElBQUksSUFBSTtNQUFHLENBQUMsQ0FBQyxDQUNsRixPQUNMLElBQUksU0FDRSxpQkFDQSxlQUFlLElBQUksU0FBVSxHQUFHO09BQUUsT0FBTyxlQUFlLENBQUM7TUFBRyxDQUFDLENBQUM7TUFDcEU7S0FFSixLQUFLO01BQ0QsSUFBSSxpQkFBaUIsSUFBSSxTQUFTLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSTtNQUNuRCxnQkFBZ0IsT0FBTyxPQUFPLFNBQVUsTUFBTTtPQUMxQyxPQUFPLENBQUMsZUFBZSxPQUFPLElBQUksU0FBUyxlQUFlLElBQUksSUFBSSxJQUFJO01BQzFFLENBQUM7TUFDRDtLQUNKLEtBQUs7TUFDRCxJQUFJLFVBQVUsR0FBRztNQUNqQixnQkFBZ0IsT0FBTyxPQUFPLFNBQVUsTUFBTTtPQUFFLE9BQU8sQ0FBQyxjQUFjLGVBQWUsSUFBSSxHQUFHLE9BQU87TUFBRyxDQUFDO0lBRS9HO0lBQ0EsT0FBTztHQUNYLEdBQUcsTUFBTTtHQUNULElBQUksZ0JBQWdCLFFBQ2hCLE9BQU87R0FDWCxJQUFJLFNBQVMsU0FBVSxHQUFHLEdBQUc7SUFDekIsT0FBTyxJQUFJLHFCQUFxQixDQUFDLEdBQUcscUJBQXFCLENBQUMsQ0FBQyxLQUN2RCxJQUFJLGVBQWUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxDQUFDO0dBQ2hEO0dBQ0EsWUFBWSxLQUFLLElBQUksY0FBYyxVQUFVLElBQUksY0FBYyxlQUN6RCxTQUFVLEdBQUcsR0FBRztJQUFFLE9BQU8sT0FBTyxHQUFHLENBQUM7R0FBRyxJQUN2QyxNQUFNO0dBQ1osSUFBSSxJQUFJLFNBQVMsSUFBSSxRQUFRLFVBQVU7SUFDbkMsSUFBSSxZQUFZLFNBQVMsSUFBSSxPQUN6QixZQUFZLFNBQVMsSUFBSTtTQUV4QixJQUFJLE9BQU8sV0FBVyxJQUFJLFNBQVMsWUFBWSxTQUFTLElBQUksT0FDN0QsV0FBVyxRQUFRO0dBRTNCO0dBQ0EsT0FBTyxZQUFZLE9BQU8sT0FBTyxXQUFXLElBQUk7RUFDcEQ7RUFFQSxTQUFTLGVBQWUsSUFBSSxJQUFJO0dBQzVCLE9BQVEsSUFBSSxHQUFHLE9BQU8sR0FBRyxLQUFLLE1BQU0sS0FDaEMsSUFBSSxHQUFHLE9BQU8sR0FBRyxLQUFLLE1BQU0sS0FDNUIsQ0FBQyxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUMsR0FBRyxhQUN4QixDQUFDLENBQUMsR0FBRyxjQUFjLENBQUMsQ0FBQyxHQUFHO0VBQ2hDO0VBRUEsU0FBUyxjQUFjLFFBQVEsUUFBUSxZQUFZLFlBQVk7R0FDM0QsSUFBSSxXQUFXLEtBQUEsR0FDWCxPQUFPLFdBQVcsS0FBQSxJQUFZLEtBQUs7R0FDdkMsSUFBSSxXQUFXLEtBQUEsR0FDWCxPQUFPO0dBQ1gsSUFBSSxJQUFJLElBQUksUUFBUSxNQUFNO0dBQzFCLElBQUksTUFBTSxHQUFHO0lBQ1QsSUFBSSxjQUFjLFlBQ2QsT0FBTztJQUNYLElBQUksWUFDQSxPQUFPO0lBQ1gsSUFBSSxZQUNBLE9BQU87R0FDZjtHQUNBLE9BQU87RUFDWDtFQUNBLFNBQVMsY0FBYyxRQUFRLFFBQVEsWUFBWSxZQUFZO0dBQzNELElBQUksV0FBVyxLQUFBLEdBQ1gsT0FBTyxXQUFXLEtBQUEsSUFBWSxJQUFJO0dBQ3RDLElBQUksV0FBVyxLQUFBLEdBQ1gsT0FBTztHQUNYLElBQUksSUFBSSxJQUFJLFFBQVEsTUFBTTtHQUMxQixJQUFJLE1BQU0sR0FBRztJQUNULElBQUksY0FBYyxZQUNkLE9BQU87SUFDWCxJQUFJLFlBQ0EsT0FBTztJQUNYLElBQUksWUFDQSxPQUFPO0dBQ2Y7R0FDQSxPQUFPO0VBQ1g7RUFDQSxTQUFTLGFBQWEsSUFBSSxJQUFJO0dBQzFCLE9BQVEsY0FBYyxHQUFHLE9BQU8sR0FBRyxPQUFPLEdBQUcsV0FBVyxHQUFHLFNBQVMsS0FBSyxLQUNyRSxjQUFjLEdBQUcsT0FBTyxHQUFHLE9BQU8sR0FBRyxXQUFXLEdBQUcsU0FBUyxLQUFLO0VBQ3pFO0VBRUEsU0FBUyxvQkFBb0IsUUFBUSxXQUFXLE1BQU0sS0FBSztHQUN2RCxJQUFJO0dBQ0osSUFBSSxXQUFXLE1BQU0sU0FBUyxPQUFPLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxTQUFTO0dBQ2xFLElBQUksQ0FBQyxVQUNELE9BQU8sQ0FBQztHQUNaLElBQUksVUFBVSxTQUFTLFFBQVE7R0FDL0IsSUFBSSxDQUFDLFNBQ0QsT0FBTztJQUFDO0lBQU07SUFBTztJQUFVO0dBQUk7R0FFdkMsSUFBSSxVQUFVLFNBREUsSUFBSSxRQUFRLElBQUksTUFBTSxNQUFNLE9BQU8sU0FDaEI7R0FDbkMsSUFBSSxDQUFDLFNBQ0QsT0FBTztJQUFDO0lBQU07SUFBTztJQUFVO0dBQUk7R0FDdkMsUUFBUSxNQUFSO0lBQ0ksS0FBSztLQUNELElBQUksa0JBQWtCLEtBQUssSUFBSSxlQUFlLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztLQUMzRSxJQUFJLGFBQWEsUUFBUSxLQUFLLFNBQVUsT0FBTztNQUMzQyxJQUFJO01BQ0osT0FBTyxNQUFNLElBQUksVUFBVSxJQUFJLFNBQzNCLE1BQU0sSUFBSSxXQUFXLElBQUksWUFDdkIsS0FBSyxNQUFNLElBQUksZUFBZSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssWUFDekQsa0JBQ0osZUFBZSxNQUFNLElBQUksTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLO0tBQzdELENBQUM7S0FDRCxJQUFJLFlBQ0EsT0FBTztNQUNIO01BQ0E7TUFDQTtNQUNBO0tBQ0o7S0FVSixPQUFPO01BVFUsUUFBUSxLQUFLLFNBQVUsT0FBTztPQUMzQyxJQUFJO09BRUosUUFEWSxXQUFXLE1BQU0sTUFBTSxNQUFNLElBQUksUUFBUSxhQUNwQyxJQUFJLFdBQ2YsS0FBSyxNQUFNLElBQUksZUFBZSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssWUFDekQsbUJBQ0gsSUFBSSxTQUFTLE1BQU0sSUFBSSxTQUFTLFNBQ2pDLGFBQWEsTUFBTSxJQUFJLE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSztNQUMzRCxDQUNpQjtNQUFHO01BQU87TUFBVTtLQUFPO0lBQ2hELEtBQUs7S0FDRCxJQUFJLGFBQWEsUUFBUSxLQUFLLFNBQVUsT0FBTztNQUMzQyxPQUFPLGVBQWUsTUFBTSxJQUFJLE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSztLQUNoRSxDQUFDO0tBQ0QsT0FBTztNQUFDO01BQVksQ0FBQyxDQUFDO01BQVk7TUFBVTtLQUFPO0dBQzNEO0VBQ0o7RUFFQSxTQUFTLHNCQUFzQixZQUFZLFdBQVcsU0FBUyxRQUFRO0dBQ25FLFdBQVcsWUFBWSxJQUFJLE9BQU87R0FDbEMsT0FBTyxpQkFBaUIsU0FBUyxXQUFZO0lBQ3pDLFdBQVcsWUFBWSxPQUFPLE9BQU87SUFDckMsSUFBSSxXQUFXLFlBQVksU0FBUyxHQUNoQyxpQkFBaUIsWUFBWSxTQUFTO0dBRTlDLENBQUM7RUFDTDtFQUNBLFNBQVMsaUJBQWlCLFlBQVksV0FBVztHQUM3QyxXQUFXLFdBQVk7SUFDbkIsSUFBSSxXQUFXLFlBQVksU0FBUyxHQUNoQyxhQUFhLFdBQVcsVUFBVTtHQUUxQyxHQUFHLEdBQUk7RUFDWDtFQUVBLElBQUksa0JBQWtCO0dBQ2xCLE9BQU87R0FDUCxPQUFPO0dBQ1AsTUFBTTtHQUNOLFFBQVEsU0FBVSxNQUFNO0lBQ3BCLElBQUksU0FBUyxLQUFLLE9BQU87SUFtTnpCLE9BbE5hLFNBQVMsU0FBUyxDQUFDLEdBQUcsSUFBSSxHQUFHO0tBQUUsYUFBYSxTQUFVLFFBQVEsTUFBTSxTQUFTO01BQ2xGLElBQUksV0FBVyxLQUFLLFlBQVksUUFBUSxNQUFNLE9BQU87TUFDckQsSUFBSSxTQUFTLGFBQWE7T0FDdEIsSUFBSSxPQUFPLElBQUksZ0JBQWdCO09BQy9CLElBQUksU0FBUyxLQUFLO09BQ2xCLElBQUksaUJBQWlCLFNBQVUsY0FBYztRQUFFLE9BQU8sV0FBWTtTQUM5RCxLQUFLLE1BQU07U0FDWCxJQUFJLFNBQVMsYUFBYTtVQUN0QixJQUFJLHdDQUF3QixJQUFJLElBQUk7VUFDcEMsS0FBSyxJQUFJLEtBQUssR0FBRyxXQUFXLFFBQVEsS0FBSyxTQUFTLFFBQVEsTUFBTTtXQUM1RCxJQUFJLFlBQVksU0FBUztXQUN6QixJQUFJLFdBQVcsTUFBTSxTQUFTLE9BQU8sUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLFNBQVM7V0FDbEUsSUFBSSxVQUFVO1lBQ1YsSUFBSSxRQUFRLEtBQUssTUFBTSxTQUFTO1lBQ2hDLElBQUksTUFBTSxTQUFTLGNBQWMsT0FBTyxTQUFVLElBQUk7YUFBRSxPQUFPLEdBQUcsVUFBVTtZQUFVLENBQUM7WUFDdkYsSUFBSSxTQUFTLGFBQ1QsZ0JBQ0EsU0FBUyxjQUNULEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxPQUFPLE9BQU8sU0FBUyxRQUFRLEtBQUssR0FBRyxLQUFLLEdBQUcsUUFBUSxNQUFNO2FBQy9FLElBQUksVUFBVSxHQUFHO2FBQ2pCLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxRQUFRLE1BQU0sR0FBRyxLQUFLLEdBQUcsUUFBUSxNQUFNO2NBQ3pELElBQUksUUFBUSxHQUFHO2NBQ2YsSUFBSSxlQUFlLE1BQU0sUUFBUSxTQUFTLFlBQVksR0FBRztlQUNyRCxhQUFhLFNBQVMsS0FBSztlQUMzQixNQUFNLFlBQVksUUFBUSxTQUFVLFNBQVM7Z0JBQ3pDLE9BQU8sc0JBQXNCLElBQUksT0FBTztlQUM1QyxDQUFDO2NBQ0w7YUFDSjtZQUNKO2lCQUVDLElBQUksSUFBSSxTQUFTLEdBQUc7YUFDckIsU0FBUyxnQkFBZ0IsU0FBUyxjQUFjLE9BQU8sU0FBVSxJQUFJO2NBQUUsT0FBTyxHQUFHLFVBQVU7YUFBVSxDQUFDO2FBQ3RHLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxPQUFPLE9BQU8sU0FBUyxRQUFRLEtBQUssR0FBRyxLQUFLLEdBQUcsUUFBUSxNQUFNO2NBQy9FLElBQUksVUFBVSxHQUFHO2NBQ2pCLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxRQUFRLE1BQU0sR0FBRyxLQUFLLEdBQUcsUUFBUSxNQUFNO2VBQ3pELElBQUksUUFBUSxHQUFHO2VBQ2YsSUFBSSxNQUFNLE9BQU8sUUFDYixTQUFTLGNBQzNEO2dCQUNrRCxJQUFJLGdCQUFnQixDQUFDLE1BQU0sT0FBTztpQkFDOUIsSUFBSSxnQkFBZ0IsT0FBTyxTQUFTLE1BQU0sR0FBRztpQkFDN0MsSUFBSSxTQUFTLG1CQUFtQixNQUFNLEtBQUssTUFBTSxLQUFLLEtBQUssT0FBTyxPQUFPLGFBQWE7aUJBQ3RGLElBQUksTUFBTSxPQUFPO2tCQUNiLGFBQWEsU0FBUyxLQUFLO2tCQUMzQixNQUFNLFlBQVksUUFBUSxTQUFVLFNBQVM7bUJBQ3pDLE9BQU8sc0JBQXNCLElBQUksT0FBTztrQkFDNUMsQ0FBQztpQkFDTCxPQUNLLElBQUksV0FBVyxNQUFNLEtBQUs7a0JBQzNCLE1BQU0sTUFBTTtrQkFDWixNQUFNLFVBQVUsYUFBYSxRQUFRLEVBQ2pDLFFBQVEsT0FDWixDQUFDO2lCQUNMO2dCQUNKLE9BQ0s7aUJBQ0QsSUFBSSxNQUFNLE9BQ04sYUFBYSxTQUFTLEtBQUs7aUJBRS9CLE1BQU0sWUFBWSxRQUFRLFNBQVUsU0FBUztrQkFDekMsT0FBTyxzQkFBc0IsSUFBSSxPQUFPO2lCQUM1QyxDQUFDO2dCQUNMO2VBQ0o7Y0FDSjthQUNKO1lBQ0o7V0FDSjtVQUNKO1VBQ0Esc0JBQXNCLFFBQVEsU0FBVSxTQUFTO1dBQUUsT0FBTyxRQUFRO1VBQUcsQ0FBQztTQUMxRTtRQUNKO09BQUc7T0FDSCxTQUFTLGlCQUFpQixTQUFTLGVBQWUsS0FBSyxHQUFHLEVBQzlDLE9BQ1osQ0FBQztPQUNELFNBQVMsaUJBQWlCLFNBQVMsZUFBZSxLQUFLLEdBQUcsRUFDOUMsT0FDWixDQUFDO09BQ0QsU0FBUyxpQkFBaUIsWUFBWSxlQUFlLElBQUksR0FBRyxFQUNoRCxPQUNaLENBQUM7TUFDTDtNQUNBLE9BQU87S0FDWDtLQUFHLE9BQU8sU0FBVSxXQUFXO01BQzNCLElBQUksWUFBWSxLQUFLLE1BQU0sU0FBUztNQUNwQyxJQUFJLFVBQVUsVUFBVSxPQUFPO01BMEgvQixPQXpIYyxTQUFTLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRztPQUFFLFFBQVEsU0FBVSxLQUFLO1FBQ2pFLElBQUksUUFBUSxJQUFJO1FBQ2hCLElBQUksUUFBUSxZQUNSLE1BQU0sR0FBRyxTQUFTLFVBQVUsY0FDNUIsTUFBTSxZQUNOLE1BQU0sU0FBUyxTQUFTLGFBRXhCLE9BQU8sVUFBVSxPQUFPLEdBQUc7UUFFL0IsSUFBSSxXQUFXLE1BQU0sU0FBUyxPQUFPLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxTQUFTO1FBQ2xFLElBQUksQ0FBQyxVQUNELE9BQU8sVUFBVSxPQUFPLEdBQUc7UUFDL0IsSUFBSSxVQUFVLFVBQVUsT0FBTyxHQUFHO1FBQ2xDLEtBQUssSUFBSSxTQUFTLFNBQVMsSUFBSSxTQUFTLFdBQ25DLElBQUksT0FBTyxVQUFVLE1BQ2xCLGlCQUFpQixTQUFTLEdBQUcsQ0FBQyxDQUFDLEtBQUssU0FBVSxLQUFLO1NBQUUsT0FBTyxPQUFPO1FBQU0sQ0FBQyxJQUM5RSxRQUFRLEtBQUssU0FBVSxLQUFLO1NBV3hCLElBQUksY0FBYyw2QkFBNkIsVUFWckIsU0FBUyxTQUFTLENBQUMsR0FBRyxHQUFHLEdBQUcsRUFBRSxRQUFRLElBQUksT0FBTyxJQUFJLFNBQVUsT0FBTyxHQUFHO1VBQzNGLElBQUk7VUFDSixJQUFJLElBQUksU0FBUyxJQUNiLE9BQU87VUFDWCxJQUFJLGlCQUFpQixLQUFLLFFBQVEsYUFBYSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLFNBQVMsR0FBRyxLQUN6RixVQUFVLEtBQUssSUFDZixTQUFTLENBQUMsR0FBRyxLQUFLO1VBQ3hCLGFBQWEsY0FBYyxRQUFRLFNBQVMsSUFBSSxRQUFRLEVBQUU7VUFDMUQsT0FBTztTQUNYLENBQUMsRUFBRSxDQUNvRSxHQUFHLEdBQUc7U0FDakYsU0FBUyxjQUFjLEtBQUssV0FBVztTQUN2QyxlQUFlLFdBQVk7VUFDdkIsT0FBTyxJQUFJLGdCQUNQLHdCQUF3QixJQUFJLFlBQVk7U0FDaEQsQ0FBQztRQUNMLENBQUM7YUFFQTtTQUNELFNBQVMsY0FBYyxLQUFLLEdBQUc7U0FDL0IsSUFBSSxnQkFBZ0Isd0JBQXdCLElBQUksWUFBWTtTQUM1RCxRQUFRLEtBQUssU0FBVSxLQUFLO1VBQ3hCLElBQUksSUFBSSxjQUFjLEdBQUc7V0FDckIsYUFBYSxTQUFTLGVBQWUsR0FBRztXQUN4QyxJQUFJLGNBQWMsNkJBQTZCLFVBQVUsS0FBSyxHQUFHO1dBQ2pFLElBQUksYUFDQSxTQUFTLGNBQWMsS0FBSyxXQUFXO1dBRTNDLElBQUksZ0JBQWdCLHdCQUF3QixJQUFJLFlBQVk7VUFDaEU7U0FDSixDQUFDO1NBQ0QsUUFBUSxNQUFNLFdBQVk7VUFDdEIsYUFBYSxTQUFTLGVBQWUsR0FBRztVQUN4QyxJQUFJLGdCQUFnQix3QkFBd0IsSUFBSSxZQUFZO1NBQ2hFLENBQUM7UUFDTDtRQUNBLE9BQU87T0FDWDtPQUFHLE9BQU8sU0FBVSxLQUFLO1FBQ3JCLElBQUk7UUFDSixJQUFJLENBQUMsa0JBQWtCLEtBQUssU0FBUyxLQUNqQyxDQUFDLGtCQUFrQixTQUFTLEdBQUcsR0FDL0IsT0FBTyxVQUFVLE1BQU0sR0FBRztRQUM5QixJQUFJLGtCQUFrQixLQUFLLElBQUksV0FBVyxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLEdBQUcsU0FBUyxXQUN0RjtRQUNKLElBQUksS0FBSyxLQUFLLFVBQVUsR0FBRyxTQUFTLFNBQVMsR0FBRztRQUNoRCxJQUFJLEtBQUssb0JBQW9CLFFBQVEsV0FBVyxTQUFTLEdBQUcsR0FBRyxhQUFhLEdBQUcsSUFBSSxhQUFhLEdBQUcsSUFBSSxXQUFXLEdBQUcsSUFBSSxZQUFZLEdBQUc7UUFDeEksSUFBSSxjQUFjLFlBQ2QsV0FBVyxTQUFTLElBQUk7YUFFdkI7U0FDRCxJQUFJLFVBQVUsVUFDVCxNQUFNLEdBQUcsQ0FBQyxDQUNWLEtBQUssU0FBVSxLQUFLO1VBQ3JCLElBQUksU0FBUyxJQUFJO1VBQ2pCLElBQUksWUFDQSxXQUFXLE1BQU07VUFDckIsSUFBSSxlQUFlO1dBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxJQUFJLEdBQUcsRUFBRSxHQUN4QyxPQUFPLE9BQU8sT0FBTyxFQUFFO1dBRTNCLE9BQU8sT0FBTyxNQUFNO1VBQ3hCO1VBQ0EsT0FBTztTQUNYLENBQUMsQ0FBQyxDQUNHLE1BQU0sU0FBVSxPQUFPO1VBQ3hCLElBQUksYUFBYSxZQUNiLGFBQWEsV0FBVyxVQUFVO1VBQ3RDLE9BQU8sUUFBUSxPQUFPLEtBQUs7U0FDL0IsQ0FBQztTQUNELGFBQWE7VUFDVCxRQUFRLElBQUk7VUFDSDtVQUNULDZCQUFhLElBQUksSUFBSTtVQUNyQixNQUFNO1VBQ0Q7VUFDTCxPQUFPO1NBQ1g7U0FDQSxJQUFJLFdBQ0EsVUFBVSxLQUFLLFVBQVU7Y0FFeEI7VUFDRCxZQUFZLENBQUMsVUFBVTtVQUN2QixJQUFJLENBQUMsVUFDRCxXQUFXLE1BQU0sU0FBUyxPQUFPLFFBQVEsR0FBRyxDQUFDLENBQUMsT0FBTyxTQUFTLEtBQUs7V0FDL0QsU0FBUztZQUNMLE9BQU8sQ0FBQztZQUNSLE9BQU8sQ0FBQztXQUNaO1dBQ0Esc0JBQU0sSUFBSSxJQUFJO1dBQ2QsZUFBZSxDQUFDO1dBQ2hCLGlCQUFpQixDQUFDO1VBQ3RCO1VBRUosU0FBUyxRQUFRLE1BQU0sSUFBSSxNQUFNLE1BQU0sUUFBUSxNQUFNO1NBQ3pEO1FBQ0o7UUFDQSxzQkFBc0IsWUFBWSxXQUFXLFNBQVMsTUFBTTtRQUM1RCxPQUFPLFdBQVcsUUFBUSxLQUFLLFNBQVUsS0FBSztTQUMxQyxJQUFJLFNBQVMsbUJBQW1CLElBQUksUUFBUSxLQUFLLGFBQWEsUUFBUSxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxlQUFlLFdBQVcsWUFBWSxhQUFhO1NBQ2pLLE9BQU8sRUFDSCxRQUFRLGdCQUFnQixTQUFTLFVBQVUsTUFBTSxFQUNyRDtRQUNKLENBQUM7T0FDTDtNQUFFLENBQ087S0FDakI7SUFBRSxDQUNNO0dBQ2hCO0VBQ0o7RUFFQSxTQUFTLE9BQU8sUUFBUSxPQUFPO0dBQzNCLE9BQU8sSUFBSSxNQUFNLFFBQVEsRUFDckIsS0FBSyxTQUFVLFFBQVEsTUFBTSxVQUFVO0lBQ25DLElBQUksU0FBUyxNQUNULE9BQU87SUFDWCxPQUFPLFFBQVEsSUFBSSxRQUFRLE1BQU0sUUFBUTtHQUM3QyxFQUNKLENBQUM7RUFDTDtFQUVBLElBQUksVUFBWSxXQUFZO0dBQ3hCLFNBQVMsTUFBTSxNQUFNLFNBQVM7SUFDMUIsSUFBSSxRQUFRO0lBQ1osS0FBSyxlQUFlLENBQUM7SUFDckIsS0FBSyxRQUFRO0lBQ2IsSUFBSSxPQUFPLE1BQU07SUFDakIsS0FBSyxXQUFXLFVBQVUsU0FBUztLQUMvQixRQUFRLE1BQU07S0FBUSxVQUFVO0tBQ2hDLFdBQVcsS0FBSztLQUFXLGFBQWEsS0FBSztLQUFhLE9BQU87S0FBVSxnQkFBZ0I7SUFBd0IsR0FBRyxPQUFPO0lBQ2pJLEtBQUssUUFBUTtLQUNULFdBQVcsUUFBUTtLQUNuQixhQUFhLFFBQVE7SUFDekI7SUFDQSxJQUFJLFNBQVMsUUFBUTtJQUNyQixLQUFLLFlBQVksQ0FBQztJQUNsQixLQUFLLFlBQVksQ0FBQztJQUNsQixLQUFLLGNBQWMsQ0FBQztJQUNwQixLQUFLLGFBQWEsQ0FBQztJQUNuQixLQUFLLFFBQVE7SUFDYixLQUFLLFNBQVM7SUFDZCxJQUFJLFFBQVE7S0FDUixhQUFhO0tBQ2IsZUFBZTtLQUNmLG1CQUFtQjtLQUNuQixjQUFjO0tBQ2QsZ0JBQWdCO0tBQ2hCLGdCQUFnQjtLQUNoQixZQUFZO0tBQ1osZUFBZTtLQUNmLFlBQVk7S0FDWixnQkFBZ0I7S0FDaEIsVUFBVSxRQUFRO0lBQ3RCO0lBQ0EsTUFBTSxpQkFBaUIsSUFBSSxhQUFhLFNBQVUsU0FBUztLQUN2RCxNQUFNLGlCQUFpQjtJQUMzQixDQUFDO0lBQ0QsTUFBTSxnQkFBZ0IsSUFBSSxhQUFhLFNBQVUsR0FBRyxRQUFRO0tBQ3hELE1BQU0sYUFBYTtJQUN2QixDQUFDO0lBQ0QsS0FBSyxTQUFTO0lBQ2QsS0FBSyxPQUFPO0lBQ1osS0FBSyxLQUFLLE9BQU8sTUFBTSxZQUFZLFdBQVcsaUJBQWlCLFNBQVMsRUFDcEUsT0FBTyxDQUFDLGlCQUFpQixHQUFHLEVBQ2hDLENBQUM7SUFDRCxLQUFLLE9BQU8sU0FBVSxPQUFPLFVBQVU7S0FDbkMsSUFBSSxLQUFLLFdBQVk7TUFDakIsSUFBSSxPQUFPLENBQUM7TUFDWixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLEtBQUssTUFBTSxVQUFVO01BRXpCLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUU7TUFDOUIsU0FBUyxNQUFNLE9BQU8sSUFBSTtLQUM5QjtLQUNBLE9BQU8sTUFBTSxHQUFHLE9BQU8sRUFBRTtJQUM3QjtJQUNBLEtBQUssR0FBRyxNQUFNLFlBQVksU0FBUyxLQUFLLEdBQUcsTUFBTSxXQUFXLFNBQVUsV0FBVztLQUM3RSxPQUFPLFNBQVUsWUFBWSxTQUFTO01BQ2xDLE1BQU0sSUFBSSxXQUFZO09BQ2xCLElBQUksUUFBUSxNQUFNO09BQ2xCLElBQUksTUFBTSxjQUFjO1FBQ3BCLElBQUksQ0FBQyxNQUFNLGFBQ1AsYUFBYSxRQUFRLENBQUMsQ0FBQyxLQUFLLFVBQVU7UUFDMUMsSUFBSSxTQUNBLFVBQVUsVUFBVTtPQUM1QixPQUNLLElBQUksTUFBTSxtQkFBbUI7UUFDOUIsTUFBTSxrQkFBa0IsS0FBSyxVQUFVO1FBQ3ZDLElBQUksU0FDQSxVQUFVLFVBQVU7T0FDNUIsT0FDSztRQUNELFVBQVUsVUFBVTtRQUNwQixJQUFJLE9BQU87UUFDWCxJQUFJLENBQUMsU0FDRCxVQUFVLFNBQVMsY0FBYztTQUM3QixLQUFLLEdBQUcsTUFBTSxZQUFZLFVBQVU7U0FDcEMsS0FBSyxHQUFHLE1BQU0sWUFBWSxXQUFXO1FBQ3pDLENBQUM7T0FDVDtNQUNKLENBQUM7S0FDTDtJQUNKLENBQUM7SUFDRCxLQUFLLGFBQWEsNEJBQTRCLElBQUk7SUFDbEQsS0FBSyxRQUFRLHVCQUF1QixJQUFJO0lBQ3hDLEtBQUssY0FBYyw2QkFBNkIsSUFBSTtJQUNwRCxLQUFLLFVBQVUseUJBQXlCLElBQUk7SUFDNUMsS0FBSyxjQUFjLDZCQUE2QixJQUFJO0lBQ3BELEtBQUssR0FBRyxpQkFBaUIsU0FBVSxJQUFJO0tBQ25DLElBQUksR0FBRyxhQUFhLEdBQ2hCLFFBQVEsS0FBSyxpREFBaUQsT0FBTyxNQUFNLE1BQU0sMENBQTBDLENBQUM7VUFFNUgsUUFBUSxLQUFLLGdEQUFnRCxPQUFPLE1BQU0sTUFBTSxpREFBaUQsQ0FBQztLQUN0SSxNQUFNLE1BQU0sRUFBRSxpQkFBaUIsTUFBTSxDQUFDO0lBQzFDLENBQUM7SUFDRCxLQUFLLEdBQUcsV0FBVyxTQUFVLElBQUk7S0FDN0IsSUFBSSxDQUFDLEdBQUcsY0FBYyxHQUFHLGFBQWEsR0FBRyxZQUNyQyxRQUFRLEtBQUssaUJBQWlCLE9BQU8sTUFBTSxNQUFNLGdCQUFnQixDQUFDO1VBRWxFLFFBQVEsS0FBSyxZQUFZLE9BQU8sTUFBTSxNQUFNLGdEQUFnRCxDQUFDLENBQUMsT0FBTyxHQUFHLGFBQWEsRUFBRSxDQUFDO0lBQ2hJLENBQUM7SUFDRCxLQUFLLFVBQVUsVUFBVSxRQUFRLFdBQVc7SUFDNUMsS0FBSyxxQkFBcUIsU0FBVSxNQUFNLFlBQVksVUFBVSxtQkFBbUI7S0FDL0UsT0FBTyxJQUFJLE1BQU0sWUFBWSxNQUFNLFlBQVksVUFBVSxNQUFNLFNBQVMsNkJBQTZCLGlCQUFpQjtJQUMxSDtJQUNBLEtBQUssaUJBQWlCLFNBQVUsSUFBSTtLQUNoQyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUMsS0FBSyxFQUFFO0tBQzNCLFlBQ0ssUUFBUSxDQUFDLENBQ1QsT0FBTyxTQUFVLEdBQUc7TUFBRSxPQUFPLEVBQUUsU0FBUyxNQUFNLFFBQVEsTUFBTSxTQUFTLENBQUMsRUFBRSxPQUFPO0tBQVMsQ0FBQyxDQUFDLENBQzFGLElBQUksU0FBVSxHQUFHO01BQUUsT0FBTyxFQUFFLEdBQUcsZUFBZSxDQUFDLENBQUMsS0FBSyxFQUFFO0tBQUcsQ0FBQztJQUNwRTtJQUNBLEtBQUssSUFBSSw2QkFBNkI7SUFDdEMsS0FBSyxJQUFJLGVBQWU7SUFDeEIsS0FBSyxJQUFJLHVCQUF1QjtJQUNoQyxLQUFLLElBQUksc0JBQXNCO0lBQy9CLEtBQUssSUFBSSxlQUFlO0lBQ3hCLElBQUksUUFBUSxJQUFJLE1BQU0sTUFBTSxFQUN4QixLQUFLLFNBQVUsR0FBRyxNQUFNLFVBQVU7S0FDOUIsSUFBSSxTQUFTLFFBQ1QsT0FBTztLQUNYLElBQUksU0FBUyxTQUNULE9BQU8sU0FBVSxXQUFXO01BQUUsT0FBTyxPQUFPLE1BQU0sTUFBTSxTQUFTLEdBQUcsS0FBSztLQUFHO0tBQ2hGLElBQUksS0FBSyxRQUFRLElBQUksR0FBRyxNQUFNLFFBQVE7S0FDdEMsSUFBSSxjQUFjLE9BQ2QsT0FBTyxPQUFPLElBQUksS0FBSztLQUMzQixJQUFJLFNBQVMsVUFDVCxPQUFPLEdBQUcsSUFBSSxTQUFVLEdBQUc7TUFBRSxPQUFPLE9BQU8sR0FBRyxLQUFLO0tBQUcsQ0FBQztLQUMzRCxJQUFJLFNBQVMsc0JBQ1QsT0FBTyxXQUFZO01BRWYsT0FBTyxPQURFLEdBQUcsTUFBTSxNQUFNLFNBQ1QsR0FBRyxLQUFLO0tBQzNCO0tBQ0osT0FBTztJQUNYLEVBQ0osQ0FBQztJQUNELEtBQUssTUFBTTtJQUNYLE9BQU8sUUFBUSxTQUFVLE9BQU87S0FBRSxPQUFPLE1BQU0sS0FBSztJQUFHLENBQUM7R0FDNUQ7R0FDQSxNQUFNLFVBQVUsVUFBVSxTQUFVLGVBQWU7SUFDL0MsSUFBSSxNQUFNLGFBQWEsS0FBSyxnQkFBZ0IsSUFDeEMsTUFBTSxJQUFJLFdBQVcsS0FBSyx3Q0FBd0M7SUFDdEUsZ0JBQWdCLEtBQUssTUFBTSxnQkFBZ0IsRUFBRSxJQUFJO0lBQ2pELElBQUksS0FBSyxTQUFTLEtBQUssT0FBTyxlQUMxQixNQUFNLElBQUksV0FBVyxPQUFPLDBDQUEwQztJQUMxRSxLQUFLLFFBQVEsS0FBSyxJQUFJLEtBQUssT0FBTyxhQUFhO0lBQy9DLElBQUksV0FBVyxLQUFLO0lBQ3BCLElBQUksa0JBQWtCLFNBQVMsT0FBTyxTQUFVLEdBQUc7S0FBRSxPQUFPLEVBQUUsS0FBSyxZQUFZO0lBQWUsQ0FBQyxDQUFDLENBQUM7SUFDakcsSUFBSSxpQkFDQSxPQUFPO0lBQ1gsa0JBQWtCLElBQUksS0FBSyxRQUFRLGFBQWE7SUFDaEQsU0FBUyxLQUFLLGVBQWU7SUFDN0IsU0FBUyxLQUFLLGlCQUFpQjtJQUMvQixnQkFBZ0IsT0FBTyxDQUFDLENBQUM7SUFDekIsS0FBSyxPQUFPLGFBQWE7SUFDekIsT0FBTztHQUNYO0dBQ0EsTUFBTSxVQUFVLGFBQWEsU0FBVSxJQUFJO0lBQ3ZDLElBQUksUUFBUTtJQUNaLE9BQU8sS0FBSyxVQUNQLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxjQUFjLEtBQUssUUFDbEQsR0FBRyxJQUNILElBQUksYUFBYSxTQUFVLFNBQVMsUUFBUTtLQUMxQyxJQUFJLE1BQU0sT0FBTyxjQUNiLE9BQU8sT0FBTyxJQUFJLFdBQVcsZUFBZSxNQUFNLE9BQU8sV0FBVyxDQUFDO0tBRXpFLElBQUksQ0FBQyxNQUFNLE9BQU8sZUFBZTtNQUM3QixJQUFJLENBQUMsTUFBTSxPQUFPLFVBQVU7T0FDeEIsT0FBTyxJQUFJLFdBQVcsZUFBZSxDQUFDO09BQ3RDO01BQ0o7TUFDQSxNQUFNLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRztLQUMxQjtLQUNBLE1BQU0sT0FBTyxlQUFlLEtBQUssU0FBUyxNQUFNO0lBQ3BELENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtHQUNsQjtHQUNBLE1BQU0sVUFBVSxNQUFNLFNBQVUsSUFBSTtJQUNoQyxJQUFJLFFBQVEsR0FBRyxPQUFPLFNBQVMsR0FBRyxRQUFRLFFBQVEsR0FBRyxPQUFPLE9BQU8sR0FBRztJQUN0RSxJQUFJLE1BQ0EsS0FBSyxNQUFNO0tBQVM7S0FBYTtJQUFLLENBQUM7SUFDM0MsSUFBSSxjQUFjLEtBQUssYUFBYSxXQUFXLEtBQUssYUFBYSxTQUFTLENBQUM7SUFDM0UsWUFBWSxLQUFLO0tBQ047S0FDQztLQUNSLE9BQU8sU0FBUyxPQUFPLEtBQUs7S0FDdEI7SUFDVixDQUFDO0lBQ0QsWUFBWSxLQUFLLFNBQVUsR0FBRyxHQUFHO0tBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRTtJQUFPLENBQUM7SUFDOUQsT0FBTztHQUNYO0dBQ0EsTUFBTSxVQUFVLFFBQVEsU0FBVSxJQUFJO0lBQ2xDLElBQUksUUFBUSxHQUFHLE9BQU8sT0FBTyxHQUFHLE1BQU0sU0FBUyxHQUFHO0lBQ2xELElBQUksU0FBUyxLQUFLLGFBQWEsUUFDM0IsS0FBSyxhQUFhLFNBQVMsS0FBSyxhQUFhLE1BQU0sQ0FBQyxPQUFPLFNBQVUsSUFBSTtLQUNyRSxPQUFPLFNBQ0QsR0FBRyxXQUFXLFNBQ2QsT0FDSSxHQUFHLFNBQVMsT0FDWjtJQUNkLENBQUM7SUFFTCxPQUFPO0dBQ1g7R0FDQSxNQUFNLFVBQVUsT0FBTyxXQUFZO0lBQy9CLElBQUksUUFBUTtJQUNaLE9BQU8sT0FBTyxXQUNkLFdBQVk7S0FBRSxPQUFPLFVBQVUsS0FBSztJQUFHLENBQUM7R0FDNUM7R0FDQSxNQUFNLFVBQVUsU0FBUyxXQUFZO0lBQ2pDLEtBQUssR0FBRyxNQUFNLEtBQUssSUFBSSxZQUFZLE9BQU8sQ0FBQztJQUMzQyxJQUFJLFFBQVEsS0FBSztJQUNqQixZQUFZLE9BQU8sSUFBSTtJQUN2QixJQUFJLEtBQUssT0FBTztLQUNaLElBQUk7TUFDQSxLQUFLLE1BQU0sTUFBTTtLQUNyQixTQUNPLEdBQUcsQ0FBRTtLQUNaLEtBQUssUUFBUTtJQUNqQjtJQUNBLElBQUksQ0FBQyxNQUFNLGVBQWU7S0FDdEIsTUFBTSxpQkFBaUIsSUFBSSxhQUFhLFNBQVUsU0FBUztNQUN2RCxNQUFNLGlCQUFpQjtLQUMzQixDQUFDO0tBQ0QsTUFBTSxnQkFBZ0IsSUFBSSxhQUFhLFNBQVUsR0FBRyxRQUFRO01BQ3hELE1BQU0sYUFBYTtLQUN2QixDQUFDO0lBQ0w7R0FDSjtHQUNBLE1BQU0sVUFBVSxRQUFRLFNBQVUsSUFBSTtJQUNsQyxJQUF5RCxtQkFBaEQsT0FBTyxLQUFLLElBQUksRUFBRSxpQkFBaUIsS0FBSyxJQUFJLEdBQUEsQ0FBeUI7SUFDOUUsSUFBSSxRQUFRLEtBQUs7SUFDakIsSUFBSSxpQkFBaUI7S0FDakIsSUFBSSxNQUFNLGVBQ04sTUFBTSxXQUFXLElBQUksV0FBVyxlQUFlLENBQUM7S0FFcEQsS0FBSyxPQUFPO0tBQ1osTUFBTSxXQUFXO0tBQ2pCLE1BQU0sY0FBYyxJQUFJLFdBQVcsZUFBZTtJQUN0RCxPQUNLO0tBQ0QsS0FBSyxPQUFPO0tBQ1osTUFBTSxXQUFXLEtBQUssU0FBUyxZQUFZLE1BQU07S0FDakQsTUFBTSxlQUFlO0tBQ3JCLE1BQU0sY0FBYztJQUN4QjtHQUNKO0dBQ0EsTUFBTSxVQUFVLFNBQVMsU0FBVSxjQUFjO0lBQzdDLElBQUksUUFBUTtJQUNaLElBQUksaUJBQWlCLEtBQUssR0FBSyxlQUFlLEVBQUUsaUJBQWlCLEtBQUs7SUFDdEUsSUFBSSxzQkFBc0IsVUFBVSxTQUFTLEtBQUssT0FBTyxVQUFVLE9BQU87SUFDMUUsSUFBSSxRQUFRLEtBQUs7SUFDakIsT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFTLFFBQVE7S0FDL0MsSUFBSSxXQUFXLFdBQVk7TUFDdkIsTUFBTSxNQUFNLFlBQVk7TUFDeEIsSUFBSSxNQUFNLE1BQU0sTUFBTSxVQUFVLGVBQWUsTUFBTSxJQUFJO01BQ3pELElBQUksWUFBWSxLQUFLLFdBQVk7T0FDN0IsbUJBQW1CLE1BQU0sT0FBTyxNQUFNLElBQUk7T0FDMUMsUUFBUTtNQUNaLENBQUM7TUFDRCxJQUFJLFVBQVUsbUJBQW1CLE1BQU07TUFDdkMsSUFBSSxZQUFZLE1BQU07S0FDMUI7S0FDQSxJQUFJLHFCQUNBLE1BQU0sSUFBSSxXQUFXLGdCQUFnQiw4Q0FBOEM7S0FDdkYsSUFBSSxNQUFNLGVBQ04sTUFBTSxlQUFlLEtBQUssUUFBUTtVQUdsQyxTQUFTO0lBRWpCLENBQUM7R0FDTDtHQUNBLE1BQU0sVUFBVSxZQUFZLFdBQVk7SUFDcEMsT0FBTyxLQUFLO0dBQ2hCO0dBQ0EsTUFBTSxVQUFVLFNBQVMsV0FBWTtJQUNqQyxPQUFPLEtBQUssVUFBVTtHQUMxQjtHQUNBLE1BQU0sVUFBVSxnQkFBZ0IsV0FBWTtJQUN4QyxJQUFJLGNBQWMsS0FBSyxPQUFPO0lBQzlCLE9BQU8sZUFBZSxZQUFZLFNBQVM7R0FDL0M7R0FDQSxNQUFNLFVBQVUsWUFBWSxXQUFZO0lBQ3BDLE9BQU8sS0FBSyxPQUFPLGdCQUFnQjtHQUN2QztHQUNBLE1BQU0sVUFBVSxvQkFBb0IsV0FBWTtJQUM1QyxPQUFPLEtBQUssT0FBTztHQUN2QjtHQUNBLE9BQU8sZUFBZSxNQUFNLFdBQVcsVUFBVTtJQUM3QyxLQUFLLFdBQVk7S0FDYixJQUFJLFFBQVE7S0FDWixPQUFPLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FBQyxJQUFJLFNBQVUsTUFBTTtNQUFFLE9BQU8sTUFBTSxXQUFXO0tBQU8sQ0FBQztJQUN2RjtJQUNBLFlBQVk7SUFDWixjQUFjO0dBQ2xCLENBQUM7R0FDRCxNQUFNLFVBQVUsY0FBYyxXQUFZO0lBQ3RDLElBQUksT0FBTyx1QkFBdUIsTUFBTSxNQUFNLFNBQVM7SUFDdkQsT0FBTyxLQUFLLGFBQWEsTUFBTSxNQUFNLElBQUk7R0FDN0M7R0FDQSxNQUFNLFVBQVUsZUFBZSxTQUFVLE1BQU0sUUFBUSxXQUFXO0lBQzlELElBQUksUUFBUTtJQUNaLElBQUksb0JBQW9CLElBQUk7SUFDNUIsSUFBSSxDQUFDLHFCQUNELGtCQUFrQixPQUFPLFFBQ3pCLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFDdEIsb0JBQW9CO0lBQ3hCLElBQUksbUJBQW1CLEtBQUssUUFBUSxHQUFHLE1BQU07SUFDN0MsT0FBTyxLQUFLLFFBQVEsS0FBSyxFQUFFLENBQUMsQ0FBQyxRQUFRLEtBQUssRUFBRTtJQUM1QyxJQUFJLFNBQVM7SUFDYixJQUFJO0tBQ0EsYUFBYSxPQUFPLElBQUksU0FBVSxPQUFPO01BQ3JDLElBQUksWUFBWSxpQkFBaUIsTUFBTSxRQUFRLE1BQU0sT0FBTztNQUM1RCxJQUFJLE9BQU8sY0FBYyxVQUNyQixNQUFNLElBQUksVUFBVSxpRkFBaUY7TUFDekcsT0FBTztLQUNYLENBQUM7S0FDRCxJQUFJLFFBQVEsT0FBTyxTQUFTLFVBQ3hCLFVBQVU7VUFDVCxJQUFJLFFBQVEsUUFBUSxRQUFRLFdBQzdCLFVBQVU7VUFFVixNQUFNLElBQUksV0FBVyxnQkFBZ0IsK0JBQStCLElBQUk7S0FDNUUsSUFBSSxtQkFBbUI7TUFDbkIsSUFBSSxrQkFBa0IsU0FBUyxZQUFZLFlBQVksV0FBVztPQUM5RCxJQUFJLGtCQUNBLG9CQUFvQjtZQUdwQixNQUFNLElBQUksV0FBVyxlQUFlLHdGQUF3RjtNQUNwSTtNQUNBLElBQUksbUJBQ0EsV0FBVyxRQUFRLFNBQVUsV0FBVztPQUNwQyxJQUFJLHFCQUNBLGtCQUFrQixXQUFXLFFBQVEsU0FBUyxNQUFNLElBQUk7UUFDeEQsSUFBSSxrQkFDQSxvQkFBb0I7YUFHcEIsTUFBTSxJQUFJLFdBQVcsZUFBZSxXQUFXLFlBQVksc0NBQXNDO09BQ3pHO01BQ0osQ0FBQztNQUVMLElBQUksb0JBQ0EscUJBQ0EsQ0FBQyxrQkFBa0IsUUFDbkIsb0JBQW9CO0tBRTVCO0lBQ0osU0FDTyxHQUFHO0tBQ04sT0FBTyxvQkFDRCxrQkFBa0IsU0FBUyxNQUFNLFNBQVUsR0FBRyxRQUFRO01BQ3BELE9BQU8sQ0FBQztLQUNaLENBQUMsSUFDQyxVQUFVLENBQUM7SUFDckI7SUFDQSxJQUFJLG1CQUFtQixzQkFBc0IsS0FBSyxNQUFNLE1BQU0sU0FBUyxZQUFZLG1CQUFtQixTQUFTO0lBQy9HLE9BQU8sb0JBQ0Qsa0JBQWtCLFNBQVMsU0FBUyxrQkFBa0IsTUFBTSxJQUM1RCxJQUFJLFFBRUUsT0FBTyxJQUFJLFdBQVcsV0FBWTtLQUFFLE9BQU8sTUFBTSxXQUFXLGdCQUFnQjtJQUFHLENBQUMsSUFDbEYsS0FBSyxXQUFXLGdCQUFnQjtHQUM5QztHQUNBLE1BQU0sVUFBVSxRQUFRLFNBQVUsV0FBVztJQUN6QyxJQUFJLENBQUMsT0FBTyxLQUFLLFlBQVksU0FBUyxHQUNsQyxNQUFNLElBQUksV0FBVyxhQUFhLFNBQVMsT0FBTyxXQUFXLGlCQUFpQixDQUFDO0lBRW5GLE9BQU8sS0FBSyxXQUFXO0dBQzNCO0dBQ0EsT0FBTztFQUNYLEVBQUU7RUFFRixJQUFJLG1CQUFtQixPQUFPLFdBQVcsZUFBZSxnQkFBZ0IsU0FDbEUsT0FBTyxhQUNQO0VBQ04sSUFBSSxhQUFlLFdBQVk7R0FDM0IsU0FBUyxXQUFXLFdBQVc7SUFDM0IsS0FBSyxhQUFhO0dBQ3RCO0dBQ0EsV0FBVyxVQUFVLFlBQVksU0FBVSxHQUFHLE9BQU8sVUFBVTtJQUMzRCxPQUFPLEtBQUssV0FBVyxDQUFDLEtBQUssT0FBTyxNQUFNLGFBQWE7S0FBRSxNQUFNO0tBQVU7S0FBaUI7SUFBUyxJQUFJLENBQUM7R0FDNUc7R0FDQSxXQUFXLFVBQVUsb0JBQW9CLFdBQVk7SUFDakQsT0FBTztHQUNYO0dBQ0EsT0FBTztFQUNYLEVBQUU7RUFFRixJQUFJO0VBQ0osSUFBSTtHQUNBLFVBQVU7SUFDTixXQUFXLFFBQVEsYUFDZixRQUFRLGdCQUNSLFFBQVEsbUJBQ1IsUUFBUTtJQUNaLGFBQWEsUUFBUSxlQUFlLFFBQVE7R0FDaEQ7RUFDSixTQUNPLEdBQUc7R0FDTixVQUFVO0lBQUUsV0FBVztJQUFNLGFBQWE7R0FBSztFQUNuRDtFQUVBLFNBQVMsVUFBVSxTQUFTO0dBQ3hCLElBQUksV0FBVztHQUNmLElBQUk7R0FDSixJQUFJLGFBQWEsSUFBSSxXQUFXLFNBQVUsVUFBVTtJQUNoRCxJQUFJLG1CQUFtQixnQkFBZ0IsT0FBTztJQUM5QyxTQUFTLFFBQVEsS0FBSztLQUNsQixJQUFJLGNBQWMsb0JBQW9CO0tBQ3RDLElBQUk7TUFDQSxJQUFJLGtCQUNBLHdCQUF3QjtNQUU1QixJQUFJLEtBQUssU0FBUyxTQUFTLEdBQUc7TUFDOUIsSUFBSSxrQkFDQSxLQUFLLEdBQUcsUUFBUSx1QkFBdUI7TUFFM0MsT0FBTztLQUNYLFVBQ1E7TUFDSixlQUFlLGtCQUFrQjtLQUNyQztJQUNKO0lBQ0EsSUFBSSxTQUFTO0lBQ2IsSUFBSTtJQUNKLElBQUksWUFBWSxDQUFDO0lBQ2pCLElBQUksYUFBYSxDQUFDO0lBQ2xCLElBQUksZUFBZTtLQUNmLElBQUksU0FBUztNQUNULE9BQU87S0FDWDtLQUNBLGFBQWEsV0FBWTtNQUNyQixJQUFJLFFBQ0E7TUFDSixTQUFTO01BQ1QsSUFBSSxpQkFDQSxnQkFBZ0IsTUFBTTtNQUMxQixJQUFJLGtCQUNBLGFBQWEsZUFBZSxZQUFZLGdCQUFnQjtLQUNoRTtJQUNKO0lBQ0EsU0FBUyxTQUFTLFNBQVMsTUFBTSxZQUFZO0lBQzdDLElBQUksbUJBQW1CO0lBQ3ZCLElBQUksVUFBVSxXQUFZO0tBQUUsT0FBTyxvQkFBb0IsUUFBUTtJQUFHO0lBQ2xFLFNBQVMsZUFBZTtLQUNwQixPQUFPLGVBQWUsWUFBWSxTQUFTO0lBQy9DO0lBQ0EsSUFBSSxtQkFBbUIsU0FBVSxPQUFPO0tBQ3BDLHVCQUF1QixXQUFXLEtBQUs7S0FDdkMsSUFBSSxhQUFhLEdBQ2IsUUFBUTtJQUVoQjtJQUNBLElBQUksV0FBVyxXQUFZO0tBQ3ZCLElBQUksVUFDQSxDQUFDLFFBQVEsV0FFVDtLQUVKLFlBQVksQ0FBQztLQUNiLElBQUksU0FBUyxDQUFDO0tBQ2QsSUFBSSxpQkFDQSxnQkFBZ0IsTUFBTTtLQUMxQixrQkFBa0IsSUFBSSxnQkFBZ0I7S0FDdEMsSUFBSSxNQUFNO01BQ0U7TUFDUixRQUFRLGdCQUFnQjtNQUN4QixTQUFTO01BQ0E7TUFDVCxPQUFPO0tBQ1g7S0FDQSxJQUFJLE1BQU0sUUFBUSxHQUFHO0tBQ3JCLElBQUksQ0FBQyxrQkFBa0I7TUFDbkIsYUFBYSxlQUFlLFVBQVUsZ0JBQWdCO01BQ3RELG1CQUFtQjtLQUN2QjtLQUNBLFFBQVEsUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLFNBQVUsUUFBUTtNQUN4QyxXQUFXO01BQ1gsZUFBZTtNQUNmLElBQUksVUFBVSxJQUFJLE9BQU8sU0FDckI7TUFFSixJQUFJLGFBQWEsR0FDYixRQUFRO1dBRVA7T0FDRCxhQUFhO09BQ2IsSUFBSSxhQUFhLEdBQ2IsUUFBUTtZQUVQO1FBQ0QsWUFBWSxDQUFDO1FBQ2Isb0JBQW9CLFdBQVk7U0FBRSxPQUFPLENBQUMsVUFBVSxTQUFTLFFBQVEsU0FBUyxLQUFLLE1BQU07UUFBRyxDQUFDO09BQ2pHO01BQ0o7S0FDSixHQUFHLFNBQVUsS0FBSztNQUNkLFdBQVc7TUFDWCxJQUFJLENBQUMsQ0FBQyx1QkFBdUIsWUFBWSxDQUFDLENBQUMsU0FBUyxRQUFRLFFBQVEsUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxHQUM5RjtXQUFBLENBQUMsUUFDRCxvQkFBb0IsV0FBWTtRQUM1QixJQUFJLFFBQ0E7UUFDSixTQUFTLFNBQVMsU0FBUyxNQUFNLEdBQUc7T0FDeEMsQ0FBQztNQUFBO0tBRWIsQ0FBQztJQUNMO0lBQ0EsV0FBVyxTQUFTLENBQUM7SUFDckIsT0FBTztHQUNYLENBQUM7R0FDRCxXQUFXLFdBQVcsV0FBWTtJQUFFLE9BQU87R0FBVTtHQUNyRCxXQUFXLFdBQVcsV0FBWTtJQUFFLE9BQU87R0FBYztHQUN6RCxPQUFPO0VBQ1g7RUFFQSxJQUFJLFFBQVE7RUFDWixNQUFNLE9BQU8sU0FBUyxTQUFTLENBQUMsR0FBRyxrQkFBa0IsR0FBRztHQUNwRCxRQUFRLFNBQVUsY0FBYztJQUU1QixPQUFPLElBRE0sTUFBTSxjQUFjLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FDdEMsQ0FBQyxDQUFDLE9BQU87R0FDckI7R0FDQSxRQUFRLFNBQVUsTUFBTTtJQUNwQixPQUFPLElBQUksTUFBTSxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQ2pDLEtBQUssQ0FBQyxDQUNOLEtBQUssU0FBVSxJQUFJO0tBQ3BCLEdBQUcsTUFBTTtLQUNULE9BQU87SUFDWCxDQUFDLENBQUMsQ0FDRyxNQUFNLHVCQUF1QixXQUFZO0tBQUUsT0FBTztJQUFPLENBQUM7R0FDbkU7R0FDQSxrQkFBa0IsU0FBVSxJQUFJO0lBQzVCLElBQUk7S0FDQSxPQUFPLGlCQUFpQixNQUFNLFlBQVksQ0FBQyxDQUFDLEtBQUssRUFBRTtJQUN2RCxTQUNPLElBQUk7S0FDUCxPQUFPLFVBQVUsSUFBSSxXQUFXLFdBQVcsQ0FBQztJQUNoRDtHQUNKO0dBQ0EsYUFBYSxXQUFZO0lBQ3JCLFNBQVMsTUFBTSxTQUFTO0tBQ3BCLE9BQU8sTUFBTSxPQUFPO0lBQ3hCO0lBQ0EsT0FBTztHQUNYO0dBQUcsbUJBQW1CLFNBQVUsV0FBVztJQUN2QyxPQUFPLElBQUksUUFDTCxPQUFPLElBQUksYUFBYSxXQUFXLFNBQVMsSUFDNUMsVUFBVTtHQUNwQjtHQUFRO0dBQUssT0FBTyxTQUFVLGFBQWE7SUFDdkMsT0FBTyxXQUFZO0tBQ2YsSUFBSTtNQUNBLElBQUksS0FBSyxjQUFjLFlBQVksTUFBTSxNQUFNLFNBQVMsQ0FBQztNQUN6RCxJQUFJLENBQUMsTUFBTSxPQUFPLEdBQUcsU0FBUyxZQUMxQixPQUFPLGFBQWEsUUFBUSxFQUFFO01BQ2xDLE9BQU87S0FDWCxTQUNPLEdBQUc7TUFDTixPQUFPLFVBQVUsQ0FBQztLQUN0QjtJQUNKO0dBQ0o7R0FBRyxPQUFPLFNBQVUsYUFBYSxNQUFNLE1BQU07SUFDekMsSUFBSTtLQUNBLElBQUksS0FBSyxjQUFjLFlBQVksTUFBTSxNQUFNLFFBQVEsQ0FBQyxDQUFDLENBQUM7S0FDMUQsSUFBSSxDQUFDLE1BQU0sT0FBTyxHQUFHLFNBQVMsWUFDMUIsT0FBTyxhQUFhLFFBQVEsRUFBRTtLQUNsQyxPQUFPO0lBQ1gsU0FDTyxHQUFHO0tBQ04sT0FBTyxVQUFVLENBQUM7SUFDdEI7R0FDSjtHQUNBLG9CQUFvQixFQUNoQixLQUFLLFdBQVk7SUFBRSxPQUFPLElBQUksU0FBUztHQUFNLEVBQ2pEO0dBQUcsU0FBUyxTQUFVLG1CQUFtQixpQkFBaUI7SUFDdEQsSUFBSSxVQUFVLGFBQWEsUUFBUSxPQUFPLHNCQUFzQixhQUMxRCxNQUFNLGtCQUFrQixpQkFBaUIsSUFDekMsaUJBQWlCLENBQUMsQ0FBQyxRQUFRLG1CQUFtQixHQUFLO0lBQ3pELE9BQU8sSUFBSSxRQUFRLElBQUksTUFBTSxRQUFRLE9BQU8sSUFBSTtHQUNwRDtHQUNBLFNBQVM7R0FDVCxPQUFPO0lBQ0gsS0FBSyxXQUFZO0tBQUUsT0FBTztJQUFPO0lBQ2pDLEtBQUssU0FBVSxPQUFPO0tBQ2xCLFNBQVMsS0FBSztJQUNsQjtHQUNKO0dBQ1E7R0FBZ0I7R0FBZTtHQUFpQjtHQUNoRDtHQUFRLElBQUk7R0FBeUI7R0FBbUM7R0FDbEU7R0FBNEI7R0FBNEI7R0FBNEI7R0FBeUI7R0FBMEI7R0FBb0I7R0FBSyxNQUFNO0dBQzVLO0dBQ1IsUUFBUSxDQUFDO0dBQ1QsYUFBYSxFQUNULEtBQUssWUFBWSxRQUNyQjtHQUNVO0dBQ1YsY0FBYztHQUFnQjtHQUM5QixRQUFRO0dBQWUsU0FBUyxjQUFjLE1BQU0sR0FBRyxDQUFDLENBQ25ELElBQUksU0FBVSxHQUFHO0lBQUUsT0FBTyxTQUFTLENBQUM7R0FBRyxDQUFDLENBQUMsQ0FDekMsT0FBTyxTQUFVLEdBQUcsR0FBRyxHQUFHO0lBQUUsT0FBTyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDO0dBQUcsQ0FBQztFQUFFLENBQUMsQ0FBQztFQUM5RSxNQUFNLFNBQVMsVUFBVSxNQUFNLGFBQWEsV0FBVztFQUV2RCxJQUFJLE9BQU8sa0JBQWtCLGVBQ3pCLE9BQU8scUJBQXFCLGFBQWE7R0FDekMsYUFBYSxrQ0FBa0MsU0FBVSxjQUFjO0lBQ25FLElBQUksQ0FBQyxvQkFBb0I7S0FDckIsSUFBSSxVQUNNLElBQUksWUFBWSxnQ0FBZ0MsRUFDdEQsUUFBUSxhQUNaLENBQUM7S0FDRCxxQkFBcUI7S0FDckIsY0FBYyxPQUFPO0tBQ3JCLHFCQUFxQjtJQUN6QjtHQUNKLENBQUM7R0FDRCxpQkFBaUIsZ0NBQWdDLFNBQVUsSUFBSTtJQUMzRCxJQUFJLFNBQVMsR0FBRztJQUNoQixJQUFJLENBQUMsb0JBQ0QsaUJBQWlCLE1BQU07R0FFL0IsQ0FBQztFQUNMO0VBQ0EsU0FBUyxpQkFBaUIsYUFBYTtHQUNuQyxJQUFJLFFBQVE7R0FDWixJQUFJO0lBQ0EscUJBQXFCO0lBQ3JCLGFBQWEsZUFBZSxLQUFLLFdBQVc7SUFDNUMscUJBQXFCLGFBQWEsSUFBSTtHQUMxQyxVQUNRO0lBQ0oscUJBQXFCO0dBQ3pCO0VBQ0o7RUFDQSxJQUFJLHFCQUFxQjtFQUV6QixJQUFJO0VBQ0osSUFBSSxXQUFXLFdBQVksQ0FBRTtFQUM3QixJQUFJLE9BQU8scUJBQXFCLGFBQWE7R0FDekMsV0FBVyxXQUFZO0lBQ25CLEtBQUssSUFBSSxpQkFBaUIsOEJBQThCO0lBQ3hELEdBQUcsWUFBWSxTQUFVLElBQUk7S0FBRSxPQUFPLEdBQUcsUUFBUSxpQkFBaUIsR0FBRyxJQUFJO0lBQUc7R0FDaEY7R0FDQSxTQUFTO0dBQ1QsSUFBSSxPQUFPLEdBQUcsVUFBVSxZQUNwQixHQUFHLE1BQU07R0FFYixhQUFhLGtDQUFrQyxTQUFVLGNBQWM7SUFDbkUsSUFBSSxDQUFDLG9CQUNELEdBQUcsWUFBWSxZQUFZO0dBRW5DLENBQUM7RUFDTDtFQUVBLElBQUksT0FBTyxxQkFBcUIsYUFBYTtHQUN6QyxpQkFBaUIsWUFBWSxTQUFVLE9BQU87SUFDMUMsSUFBSSxDQUFDLFFBQVEsa0JBQWtCLE1BQU0sV0FBVztLQUM1QyxJQUFJLE9BQ0EsUUFBUSxNQUFNLG9DQUFvQztLQUN0RCxPQUFPLFFBQVEsT0FBTyxLQUFLLEtBQWEsR0FBRyxNQUFNO0tBQ2pELEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxZQUFZLFFBQVEsR0FBRyxLQUFLLEdBQUcsUUFBUSxNQUV6RCxHQURZLEdBQ1YsQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLE1BQU0sQ0FBQztJQUUzQztHQUNKLENBQUM7R0FDRCxpQkFBaUIsWUFBWSxTQUFVLE9BQU87SUFDMUMsSUFBSSxDQUFDLFFBQVEsa0JBQWtCLE1BQU0sV0FBVztLQUM1QyxJQUFJLE9BQ0EsUUFBUSxNQUFNLG9DQUFvQztLQUN0RCxTQUFTO0tBQ1QsaUJBQWlCLEVBQUUsS0FBSyxJQUFJLFNBQVMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUMzRDtHQUNKLENBQUM7RUFDTDtFQUVBLFNBQVMsSUFBSSxPQUFPO0dBQ2hCLE9BQU8sSUFBSSxpQkFBaUIsRUFBRSxLQUFLLE1BQU0sQ0FBQztFQUM5QztFQUVBLFNBQVMsT0FBTyxPQUFPO0dBQ25CLE9BQU8sSUFBSSxpQkFBaUIsRUFBRSxRQUFRLE1BQU0sQ0FBQztFQUNqRDtFQUVBLFNBQVMsY0FBYyxHQUFHLEdBQUc7R0FDekIsT0FBTyxJQUFJLGlCQUFpQixFQUFFLGVBQWUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0VBQ3pEO0VBRUEsYUFBYSxrQkFBa0I7RUFDL0IsU0FBUyxLQUFLO0VBbUJkLFNBQVMsU0FqQnVCLHVCQUFPLE9BQU87R0FDNUMsV0FBVztHQUNjO0dBQ3pCLE9BQU87R0FDQztHQUNVO0dBQ1I7R0FDTDtHQUNBO0dBQ0wsU0FBUztHQUNFO0dBQ0U7R0FDRTtHQUNQO0dBQ087RUFDakIsQ0FFNkIsR0FBRyxFQUFFLFNBQVMsUUFBUSxDQUFDO0VBRXBELE9BQU87Q0FFVCxFQUFFOztBQ3I2TUYsSUFBTSxjQUFjLE9BQU8sSUFBSSxPQUFPO0FBQ3RDLElBQU0sUUFBUSxXQUFXLGlCQUFpQixXQUFXLGVBQWVBLGFBQUFBO0FBQ3BFLElBQUlBLGFBQUFBLFFBQU8sV0FBVyxNQUFNLFFBQ3hCLE1BQU0sSUFBSSxNQUFNLDJEQUEyREEsYUFBQUEsUUFBTyxPQUFPLE9BQU8sTUFBTSxRQUFRO0FBRWxILElBQU0sRUFBRSxXQUFXLGFBQWEsZUFBZSxVQUFVLEtBQUssUUFDMUQsa0JBQWtCLGVBQWUsS0FBSyxRQUN0QyxtQkFBbUIiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxXX0=