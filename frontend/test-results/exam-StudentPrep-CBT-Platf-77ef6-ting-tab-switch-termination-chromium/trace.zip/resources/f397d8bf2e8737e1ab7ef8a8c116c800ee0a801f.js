//#region node_modules/reselect/dist/reselect.mjs
var CACHE_SIZE_CHECK_THRESHOLD = 1e3;
var runCacheSizeCheck = (cacheSize, funcName) => {
	let stack = void 0;
	try {
		throw new Error();
	} catch (e) {
		({stack} = e);
	}
	console.warn(`A function memoized with weakMapMemoize${funcName ? ` (\`${funcName}\`)` : ""} has seen over ${cacheSize} distinct values for the same primitive argument position.
Results keyed by primitive arguments are held strongly and are only released by \`clearCache()\`, so this cache will keep growing for as long as the function keeps seeing new values.
If it is called with ever-changing primitives (ids, offsets, timestamps), pass the \`maxSize\` option to bound the cache, switch to \`lruMemoize\`, or call \`.clearCache()\` at a suitable point.
See https://reselect.js.org/api/development-only-checks#cachesizecheck for details.`, { stack });
};
var globalDevModeChecks = {
	inputStabilityCheck: "once",
	identityFunctionCheck: "once",
	cacheSizeCheck: "once"
};
var StrongRef = class {
	constructor(value) {
		this.value = value;
	}
	deref() {
		return this.value;
	}
};
var getWeakRef = () => typeof WeakRef === "undefined" ? StrongRef : WeakRef;
var Ref = /* @__PURE__ */ getWeakRef();
var UNTERMINATED = 0;
var TERMINATED = 1;
function createCacheNode() {
	return {
		s: UNTERMINATED,
		v: void 0,
		o: null,
		p: null
	};
}
function maybeDeref(r) {
	if (r instanceof Ref) return r.deref();
	return r;
}
function weakMapMemoize(func, options = {}) {
	let fnNode = createCacheNode();
	const { resultEqualityCheck, maxSize } = options;
	const useGenerations = maxSize !== void 0;
	if (useGenerations && (!Number.isInteger(maxSize) || maxSize < 1)) throw new TypeError(`maxSize must be a positive integer, received: ${maxSize}`);
	let prevNode = null;
	let insertionCount = 0;
	let lastResult;
	let resultsCount = 0;
	let hasWarnedAboutCacheSize = false;
	function maybeFlipGenerations() {
		if (insertionCount >= maxSize) {
			prevNode = fnNode;
			fnNode = createCacheNode();
			insertionCount = 0;
		}
	}
	function memoized() {
		let cacheNode = fnNode;
		const { length } = arguments;
		for (let i = 0, l = length; i < l; i++) {
			const arg = arguments[i];
			if (typeof arg === "function" || typeof arg === "object" && arg !== null) {
				let objectCache = cacheNode.o;
				if (objectCache === null) cacheNode.o = objectCache = /* @__PURE__ */ new WeakMap();
				const objectNode = objectCache.get(arg);
				if (objectNode === void 0) {
					cacheNode = createCacheNode();
					objectCache.set(arg, cacheNode);
				} else cacheNode = objectNode;
			} else {
				let primitiveCache = cacheNode.p;
				if (primitiveCache === null) cacheNode.p = primitiveCache = /* @__PURE__ */ new Map();
				const primitiveNode = primitiveCache.get(arg);
				if (primitiveNode === void 0) {
					cacheNode = createCacheNode();
					primitiveCache.set(arg, cacheNode);
					insertionCount++;
					if (primitiveCache.size > CACHE_SIZE_CHECK_THRESHOLD) {
						const { cacheSizeCheck } = globalDevModeChecks;
						if (cacheSizeCheck === "always" || cacheSizeCheck === "once" && !hasWarnedAboutCacheSize) {
							hasWarnedAboutCacheSize = true;
							runCacheSizeCheck(primitiveCache.size, func.name);
						}
					}
				} else cacheNode = primitiveNode;
			}
		}
		if (cacheNode.s === TERMINATED) return cacheNode.v;
		if (prevNode !== null) {
			let prevCacheNode = prevNode;
			for (let i = 0, l = length; i < l; i++) {
				const arg = arguments[i];
				let next;
				if (typeof arg === "function" || typeof arg === "object" && arg !== null) {
					const prevObjectCache = prevCacheNode.o;
					next = prevObjectCache !== null ? prevObjectCache.get(arg) : void 0;
				} else {
					const prevPrimitiveCache = prevCacheNode.p;
					next = prevPrimitiveCache !== null ? prevPrimitiveCache.get(arg) : void 0;
				}
				if (next === void 0) {
					prevCacheNode = null;
					break;
				}
				prevCacheNode = next;
			}
			if (prevCacheNode !== null && prevCacheNode.s === TERMINATED) {
				const promotedNode = cacheNode;
				promotedNode.s = TERMINATED;
				promotedNode.v = prevCacheNode.v;
				maybeFlipGenerations();
				return prevCacheNode.v;
			}
		}
		const terminatedNode = cacheNode;
		let result = func.apply(null, arguments);
		resultsCount++;
		if (resultEqualityCheck) {
			const lastResultValue = maybeDeref(lastResult);
			if (lastResultValue != null && resultEqualityCheck(lastResultValue, result)) {
				result = lastResultValue;
				resultsCount !== 0 && resultsCount--;
			}
			lastResult = typeof result === "object" && result !== null || typeof result === "function" ? /* @__PURE__ */ new Ref(result) : result;
		}
		terminatedNode.s = TERMINATED;
		terminatedNode.v = result;
		if (useGenerations) maybeFlipGenerations();
		return result;
	}
	memoized.clearCache = () => {
		fnNode = createCacheNode();
		prevNode = null;
		insertionCount = 0;
		memoized.resetResultsCount();
		hasWarnedAboutCacheSize = false;
	};
	memoized.resultsCount = () => resultsCount;
	memoized.resetResultsCount = () => {
		resultsCount = 0;
	};
	return memoized;
}
var runIdentityFunctionCheck = (resultFunc, inputSelectorsResults, outputSelectorResult) => {
	if (inputSelectorsResults.length === 1 && inputSelectorsResults[0] === outputSelectorResult) {
		let isInputSameAsOutput = false;
		try {
			const emptyObject = {};
			if (resultFunc(emptyObject) === emptyObject) isInputSameAsOutput = true;
		} catch {}
		if (isInputSameAsOutput) {
			let stack = void 0;
			try {
				throw new Error();
			} catch (e) {
				({stack} = e);
			}
			console.warn("The result function returned its own inputs without modification. e.g\n`createSelector([state => state.todos], todos => todos)`\nThis could lead to inefficient memoization and unnecessary re-renders.\nEnsure transformation logic is in the result function, and extraction logic is in the input selectors.", { stack });
		}
	}
};
var withoutResultEqualityCheck = (option) => {
	if (option === null || typeof option !== "object" || !("resultEqualityCheck" in option)) return option;
	const optionCopy = { ...option };
	delete optionCopy.resultEqualityCheck;
	return optionCopy;
};
var runInputStabilityCheck = (inputSelectorResultsObject, options, inputSelectorArgs) => {
	const { memoize, memoizeOptions } = options;
	const { inputSelectorResults, inputSelectorResultsCopy } = inputSelectorResultsObject;
	const probeMemoizeOptions = [];
	const { length } = memoizeOptions;
	for (let i = 0; i < length; i++) probeMemoizeOptions.push(withoutResultEqualityCheck(memoizeOptions[i]));
	const createAnEmptyObject = memoize(() => ({}), ...probeMemoizeOptions);
	if (!(createAnEmptyObject.apply(null, inputSelectorResults) === createAnEmptyObject.apply(null, inputSelectorResultsCopy))) {
		let stack = void 0;
		try {
			throw new Error();
		} catch (e) {
			({stack} = e);
		}
		console.warn("An input selector returned a different result when passed same arguments.\nThis means your output selector will likely run more frequently than intended.\nAvoid returning a new reference inside your input selector, e.g.\n`createSelector([state => state.todos.map(todo => todo.id)], todoIds => todoIds.length)`", {
			arguments: inputSelectorArgs,
			firstInputs: inputSelectorResults,
			secondInputs: inputSelectorResultsCopy,
			stack
		});
	}
};
var NOT_FOUND = /* @__PURE__ */ Symbol("NOT_FOUND");
function assertIsFunction(func, errorMessage = `expected a function, instead received ${typeof func}`) {
	if (typeof func !== "function") throw new TypeError(errorMessage);
}
function assertIsArrayOfFunctions(array, errorMessage = `expected all items to be functions, instead received the following types: `) {
	if (!array.every((item) => typeof item === "function")) {
		const itemTypes = array.map((item) => typeof item === "function" ? `function ${item.name || "unnamed"}()` : typeof item).join(", ");
		throw new TypeError(`${errorMessage}[${itemTypes}]`);
	}
}
var ensureIsArray = (item) => {
	return Array.isArray(item) ? item : [item];
};
function getDependencies(createSelectorArgs) {
	const dependencies = Array.isArray(createSelectorArgs[0]) ? createSelectorArgs[0] : createSelectorArgs;
	assertIsArrayOfFunctions(dependencies, `createSelector expects all input-selectors to be functions, but received the following types: `);
	return dependencies;
}
function collectInputSelectorResults(dependencies, inputSelectorArgs) {
	const inputSelectorResults = [];
	const { length } = dependencies;
	for (let i = 0; i < length; i++) inputSelectorResults.push(dependencies[i].apply(null, inputSelectorArgs));
	return inputSelectorResults;
}
function createSelectorCreator(memoizeOrOptions, ...memoizeOptionsFromArgs) {
	const createSelectorCreatorOptions = typeof memoizeOrOptions === "function" ? {
		memoize: memoizeOrOptions,
		memoizeOptions: memoizeOptionsFromArgs
	} : memoizeOrOptions;
	const createSelector2 = (...createSelectorArgs) => {
		let recomputations = 0;
		let dependencyRecomputations = 0;
		let lastResult;
		let directlyPassedOptions = {};
		let resultFunc = createSelectorArgs.pop();
		if (typeof resultFunc === "object") {
			directlyPassedOptions = resultFunc;
			resultFunc = createSelectorArgs.pop();
		}
		assertIsFunction(resultFunc, `createSelector expects an output function after the inputs, but received: [${typeof resultFunc}]`);
		const combinedOptions = {
			...createSelectorCreatorOptions,
			...directlyPassedOptions
		};
		const { memoize, memoizeOptions = [], argsMemoize = weakMapMemoize, argsMemoizeOptions = [] } = combinedOptions;
		const finalMemoizeOptions = ensureIsArray(memoizeOptions);
		const finalArgsMemoizeOptions = ensureIsArray(argsMemoizeOptions);
		const dependencies = getDependencies(createSelectorArgs);
		const memoizedResultFunc = memoize(function recomputationWrapper() {
			recomputations++;
			return resultFunc.apply(null, arguments);
		}, ...finalMemoizeOptions);
		let firstRun = true;
		const selector = argsMemoize(function dependenciesChecker() {
			dependencyRecomputations++;
			const { length } = dependencies;
			const inputSelectorResults = new Array(length);
			for (let i = 0; i < length; i++) inputSelectorResults[i] = dependencies[i].apply(null, arguments);
			lastResult = memoizedResultFunc.apply(null, inputSelectorResults);
			{
				const { devModeChecks } = combinedOptions;
				const identityFunctionCheck = devModeChecks !== void 0 && Object.prototype.hasOwnProperty.call(devModeChecks, "identityFunctionCheck") ? devModeChecks.identityFunctionCheck : globalDevModeChecks.identityFunctionCheck;
				const inputStabilityCheck = devModeChecks !== void 0 && Object.prototype.hasOwnProperty.call(devModeChecks, "inputStabilityCheck") ? devModeChecks.inputStabilityCheck : globalDevModeChecks.inputStabilityCheck;
				if (identityFunctionCheck === "always" || identityFunctionCheck === "once" && firstRun) runIdentityFunctionCheck(resultFunc, inputSelectorResults, lastResult);
				if (inputStabilityCheck === "always" || inputStabilityCheck === "once" && firstRun) runInputStabilityCheck({
					inputSelectorResults,
					inputSelectorResultsCopy: collectInputSelectorResults(dependencies, arguments)
				}, {
					memoize,
					memoizeOptions: finalMemoizeOptions
				}, arguments);
				if (firstRun) firstRun = false;
			}
			return lastResult;
		}, ...finalArgsMemoizeOptions);
		return Object.assign(selector, {
			resultFunc,
			memoizedResultFunc,
			dependencies,
			dependencyRecomputations: () => dependencyRecomputations,
			resetDependencyRecomputations: () => {
				dependencyRecomputations = 0;
			},
			lastResult: () => lastResult,
			recomputations: () => recomputations,
			resetRecomputations: () => {
				recomputations = 0;
			},
			memoize,
			argsMemoize
		});
	};
	Object.assign(createSelector2, { withTypes: () => createSelector2 });
	return createSelector2;
}
var createSelector = /* @__PURE__ */ createSelectorCreator(weakMapMemoize);
function createSingletonCache(equals) {
	let entry;
	return {
		get(key) {
			if (entry && equals(entry.key, key)) return entry.value;
			return NOT_FOUND;
		},
		put(key, value) {
			entry = {
				key,
				value
			};
		},
		findMatchingEntry(value, resultEqualityCheck) {
			const current = entry;
			return current !== void 0 && resultEqualityCheck(current.value, value) ? current : void 0;
		},
		clear() {
			entry = void 0;
		}
	};
}
function createLruCache(maxSize, equals) {
	let entries = [];
	function get(key) {
		const cacheIndex = entries.findIndex((entry) => equals(entry.key, key));
		if (cacheIndex > -1) {
			const entry = entries[cacheIndex];
			if (cacheIndex > 0) {
				entries.splice(cacheIndex, 1);
				entries.unshift(entry);
			}
			return entry.value;
		}
		return NOT_FOUND;
	}
	function put(key, value) {
		entries.unshift({
			key,
			value
		});
		if (entries.length > maxSize) entries.pop();
	}
	function findMatchingEntry(value, resultEqualityCheck) {
		const currentEntries = entries;
		const { length } = currentEntries;
		for (let i = 0; i < length; i++) {
			const entry = currentEntries[i];
			if (resultEqualityCheck(entry.value, value)) return entry;
		}
	}
	function clear() {
		entries = [];
	}
	return {
		get,
		put,
		findMatchingEntry,
		clear
	};
}
var referenceEqualityCheck = (a, b) => a === b;
function createCacheKeyComparator(equalityCheck) {
	return function areArgumentsShallowlyEqual(prev, next) {
		if (prev === null || next === null || prev.length !== next.length) return false;
		const { length } = prev;
		for (let i = 0; i < length; i++) if (!equalityCheck(prev[i], next[i])) return false;
		return true;
	};
}
function lruMemoize(func, equalityCheckOrOptions) {
	const { equalityCheck = referenceEqualityCheck, maxSize = 1, resultEqualityCheck } = typeof equalityCheckOrOptions === "object" ? equalityCheckOrOptions : { equalityCheck: equalityCheckOrOptions };
	const comparator = createCacheKeyComparator(equalityCheck);
	let resultsCount = 0;
	const cache = maxSize <= 1 ? createSingletonCache(comparator) : createLruCache(maxSize, comparator);
	function memoized() {
		let value = cache.get(arguments);
		if (value === NOT_FOUND) {
			value = func.apply(null, arguments);
			resultsCount++;
			if (resultEqualityCheck) {
				const matchingEntry = cache.findMatchingEntry(value, resultEqualityCheck);
				if (matchingEntry) {
					value = matchingEntry.value;
					resultsCount !== 0 && resultsCount--;
				}
			}
			cache.put(arguments, value);
		}
		return value;
	}
	memoized.clearCache = () => {
		cache.clear();
		memoized.resetResultsCount();
	};
	memoized.resultsCount = () => resultsCount;
	memoized.resetResultsCount = () => {
		resultsCount = 0;
	};
	return memoized;
}
//#endregion
//#region node_modules/redux/dist/redux.mjs
var symbol_observable_default = /* @__PURE__ */ (() => typeof Symbol === "function" && Symbol.observable || "@@observable")();
var randomString = () => Math.random().toString(36).substring(7).split("").join(".");
var actionTypes_default = {
	INIT: `@@redux/INIT${/* @__PURE__ */ randomString()}`,
	REPLACE: `@@redux/REPLACE${/* @__PURE__ */ randomString()}`,
	PROBE_UNKNOWN_ACTION: () => `@@redux/PROBE_UNKNOWN_ACTION${randomString()}`
};
function isPlainObject(obj) {
	if (typeof obj !== "object" || obj === null) return false;
	let proto = obj;
	while (Object.getPrototypeOf(proto) !== null) proto = Object.getPrototypeOf(proto);
	return Object.getPrototypeOf(obj) === proto || Object.getPrototypeOf(obj) === null;
}
function miniKindOf(val) {
	if (val === void 0) return "undefined";
	if (val === null) return "null";
	const type = typeof val;
	switch (type) {
		case "boolean":
		case "string":
		case "number":
		case "symbol":
		case "function": return type;
	}
	if (Array.isArray(val)) return "array";
	if (isDate(val)) return "date";
	if (isError(val)) return "error";
	const constructorName = ctorName(val);
	switch (constructorName) {
		case "Symbol":
		case "Promise":
		case "WeakMap":
		case "WeakSet":
		case "Map":
		case "Set": return constructorName;
	}
	return Object.prototype.toString.call(val).slice(8, -1).toLowerCase().replace(/\s/g, "");
}
function ctorName(val) {
	return typeof val.constructor === "function" ? val.constructor.name : null;
}
function isError(val) {
	return val instanceof Error || typeof val.message === "string" && val.constructor && typeof val.constructor.stackTraceLimit === "number";
}
function isDate(val) {
	if (val instanceof Date) return true;
	return typeof val.toDateString === "function" && typeof val.getDate === "function" && typeof val.setDate === "function";
}
function kindOf(val) {
	let typeOfVal = typeof val;
	typeOfVal = miniKindOf(val);
	return typeOfVal;
}
function createStore(reducer, preloadedState, enhancer) {
	if (typeof reducer !== "function") throw new Error(`Expected the root reducer to be a function. Instead, received: '${kindOf(reducer)}'`);
	if (typeof preloadedState === "function" && typeof enhancer === "function" || typeof enhancer === "function" && typeof arguments[3] === "function") throw new Error("It looks like you are passing several store enhancers to createStore(). This is not supported. Instead, compose them together to a single function. See https://redux.js.org/tutorials/fundamentals/part-4-store#creating-a-store-with-enhancers for an example.");
	if (typeof preloadedState === "function" && typeof enhancer === "undefined") {
		enhancer = preloadedState;
		preloadedState = void 0;
	}
	if (typeof enhancer !== "undefined") {
		if (typeof enhancer !== "function") throw new Error(`Expected the enhancer to be a function. Instead, received: '${kindOf(enhancer)}'`);
		return enhancer(createStore)(reducer, preloadedState);
	}
	let currentReducer = reducer;
	let currentState = preloadedState;
	let currentListeners = /* @__PURE__ */ new Map();
	let nextListeners = currentListeners;
	let listenerIdCounter = 0;
	let isDispatching = false;
	function ensureCanMutateNextListeners() {
		if (nextListeners === currentListeners) {
			nextListeners = /* @__PURE__ */ new Map();
			currentListeners.forEach((listener, key) => {
				nextListeners.set(key, listener);
			});
		}
	}
	function getState() {
		if (isDispatching) throw new Error("You may not call store.getState() while the reducer is executing. The reducer has already received the state as an argument. Pass it down from the top reducer instead of reading it from the store.");
		return currentState;
	}
	function subscribe(listener) {
		if (typeof listener !== "function") throw new Error(`Expected the listener to be a function. Instead, received: '${kindOf(listener)}'`);
		if (isDispatching) throw new Error("You may not call store.subscribe() while the reducer is executing. If you would like to be notified after the store has been updated, subscribe from a component and invoke store.getState() in the callback to access the latest state. See https://redux.js.org/api/store#subscribelistener for more details.");
		let isSubscribed = true;
		ensureCanMutateNextListeners();
		const listenerId = listenerIdCounter++;
		nextListeners.set(listenerId, listener);
		return function unsubscribe() {
			if (!isSubscribed) return;
			if (isDispatching) throw new Error("You may not unsubscribe from a store listener while the reducer is executing. See https://redux.js.org/api/store#subscribelistener for more details.");
			isSubscribed = false;
			ensureCanMutateNextListeners();
			nextListeners.delete(listenerId);
			currentListeners = null;
		};
	}
	function dispatch(action) {
		if (!isPlainObject(action)) throw new Error(`Actions must be plain objects. Instead, the actual type was: '${kindOf(action)}'. You may need to add middleware to your store setup to handle dispatching other values, such as 'redux-thunk' to handle dispatching functions. See https://redux.js.org/tutorials/fundamentals/part-4-store#middleware and https://redux.js.org/tutorials/fundamentals/part-6-async-logic#using-the-redux-thunk-middleware for examples.`);
		if (typeof action.type === "undefined") throw new Error("Actions may not have an undefined \"type\" property. You may have misspelled an action type string constant.");
		if (typeof action.type !== "string") throw new Error(`Action "type" property must be a string. Instead, the actual type was: '${kindOf(action.type)}'. Value was: '${action.type}' (stringified)`);
		if (isDispatching) throw new Error("Reducers may not dispatch actions.");
		try {
			isDispatching = true;
			currentState = currentReducer(currentState, action);
		} finally {
			isDispatching = false;
		}
		(currentListeners = nextListeners).forEach((listener) => {
			listener();
		});
		return action;
	}
	function replaceReducer(nextReducer) {
		if (typeof nextReducer !== "function") throw new Error(`Expected the nextReducer to be a function. Instead, received: '${kindOf(nextReducer)}`);
		currentReducer = nextReducer;
		dispatch({ type: actionTypes_default.REPLACE });
	}
	function observable() {
		const outerSubscribe = subscribe;
		return {
			/**
			* The minimal observable subscription method.
			* @param observer Any object that can be used as an observer.
			* The observer object should have a `next` method.
			* @returns An object with an `unsubscribe` method that can
			* be used to unsubscribe the observable from the store, and prevent further
			* emission of values from the observable.
			*/
			subscribe(observer) {
				if (typeof observer !== "object" || observer === null) throw new Error(`Expected the observer to be an object. Instead, received: '${kindOf(observer)}'`);
				function observeState() {
					const observerAsObserver = observer;
					if (observerAsObserver.next) observerAsObserver.next(getState());
				}
				observeState();
				return { unsubscribe: outerSubscribe(observeState) };
			},
			[symbol_observable_default]() {
				return this;
			}
		};
	}
	dispatch({ type: actionTypes_default.INIT });
	return {
		dispatch,
		subscribe,
		getState,
		replaceReducer,
		[symbol_observable_default]: observable
	};
}
function legacy_createStore(reducer, preloadedState, enhancer) {
	return createStore(reducer, preloadedState, enhancer);
}
function warning(message) {
	if (typeof console !== "undefined" && typeof console.error === "function") console.error(message);
	try {
		throw new Error(message);
	} catch (e) {}
}
function getUnexpectedStateShapeWarningMessage(inputState, reducers, action, unexpectedKeyCache) {
	const reducerKeys = Object.keys(reducers);
	const argumentName = action && action.type === actionTypes_default.INIT ? "preloadedState argument passed to createStore" : "previous state received by the reducer";
	if (reducerKeys.length === 0) return "Store does not have a valid reducer. Make sure the argument passed to combineReducers is an object whose values are reducers.";
	if (!isPlainObject(inputState)) return `The ${argumentName} has unexpected type of "${kindOf(inputState)}". Expected argument to be an object with the following keys: "${reducerKeys.join("\", \"")}"`;
	const unexpectedKeys = Object.keys(inputState).filter((key) => !reducers.hasOwnProperty(key) && !unexpectedKeyCache[key]);
	unexpectedKeys.forEach((key) => {
		unexpectedKeyCache[key] = true;
	});
	if (action && action.type === actionTypes_default.REPLACE) return;
	if (unexpectedKeys.length > 0) return `Unexpected ${unexpectedKeys.length > 1 ? "keys" : "key"} "${unexpectedKeys.join("\", \"")}" found in ${argumentName}. Expected to find one of the known reducer keys instead: "${reducerKeys.join("\", \"")}". Unexpected keys will be ignored.`;
}
function assertReducerShape(reducers) {
	Object.keys(reducers).forEach((key) => {
		const reducer = reducers[key];
		if (typeof reducer(void 0, { type: actionTypes_default.INIT }) === "undefined") throw new Error(`The slice reducer for key "${key}" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined.`);
		if (typeof reducer(void 0, { type: actionTypes_default.PROBE_UNKNOWN_ACTION() }) === "undefined") throw new Error(`The slice reducer for key "${key}" returned undefined when probed with a random type. Don't try to handle '${actionTypes_default.INIT}' or other actions in "redux/*" namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined, but can be null.`);
	});
}
function combineReducers(reducers) {
	const reducerKeys = Object.keys(reducers);
	const finalReducers = {};
	for (let i = 0; i < reducerKeys.length; i++) {
		const key = reducerKeys[i];
		if (typeof reducers[key] === "undefined") warning(`No reducer provided for key "${key}"`);
		if (typeof reducers[key] === "function") finalReducers[key] = reducers[key];
	}
	const finalReducerKeys = Object.keys(finalReducers);
	let unexpectedKeyCache = {};
	let shapeAssertionError;
	try {
		assertReducerShape(finalReducers);
	} catch (e) {
		shapeAssertionError = e;
	}
	return function combination(state = {}, action) {
		if (shapeAssertionError) throw shapeAssertionError;
		{
			const warningMessage = getUnexpectedStateShapeWarningMessage(state, finalReducers, action, unexpectedKeyCache);
			if (warningMessage) warning(warningMessage);
		}
		let hasChanged = false;
		const nextState = {};
		for (let i = 0; i < finalReducerKeys.length; i++) {
			const key = finalReducerKeys[i];
			const reducer = finalReducers[key];
			const previousStateForKey = state[key];
			const nextStateForKey = reducer(previousStateForKey, action);
			if (typeof nextStateForKey === "undefined") {
				const actionType = action && action.type;
				throw new Error(`When called with an action of type ${actionType ? `"${String(actionType)}"` : "(unknown type)"}, the slice reducer for key "${key}" returned undefined. To ignore an action, you must explicitly return the previous state. If you want this reducer to hold no value, you can return null instead of undefined.`);
			}
			nextState[key] = nextStateForKey;
			hasChanged = hasChanged || nextStateForKey !== previousStateForKey;
		}
		hasChanged = hasChanged || finalReducerKeys.length !== Object.keys(state).length;
		return hasChanged ? nextState : state;
	};
}
function bindActionCreator(actionCreator, dispatch) {
	return function(...args) {
		return dispatch(actionCreator.apply(this, args));
	};
}
function bindActionCreators(actionCreators, dispatch) {
	if (typeof actionCreators === "function") return bindActionCreator(actionCreators, dispatch);
	if (typeof actionCreators !== "object" || actionCreators === null) throw new Error(`bindActionCreators expected an object or a function, but instead received: '${kindOf(actionCreators)}'. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?`);
	const boundActionCreators = {};
	for (const key in actionCreators) {
		const actionCreator = actionCreators[key];
		if (typeof actionCreator === "function") boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
	}
	return boundActionCreators;
}
function compose(...funcs) {
	if (funcs.length === 0) return (arg) => arg;
	if (funcs.length === 1) return funcs[0];
	return funcs.reduce((a, b) => (...args) => a(b(...args)));
}
function applyMiddleware(...middlewares) {
	return (createStore2) => (reducer, preloadedState) => {
		const store = createStore2(reducer, preloadedState);
		let dispatch = () => {
			throw new Error("Dispatching while constructing your middleware is not allowed. Other middleware would not be applied to this dispatch.");
		};
		const middlewareAPI = {
			getState: store.getState,
			dispatch: (action, ...args) => dispatch(action, ...args)
		};
		dispatch = compose(...middlewares.map((middleware) => middleware(middlewareAPI)))(store.dispatch);
		return {
			...store,
			dispatch
		};
	};
}
function isAction(action) {
	return isPlainObject(action) && "type" in action && typeof action.type === "string";
}
//#endregion
//#region node_modules/immer/dist/immer.mjs
var NOTHING = Symbol.for("immer-nothing");
var DRAFTABLE = Symbol.for("immer-draftable");
var DRAFT_STATE = Symbol.for("immer-state");
var errors = [
	function(plugin) {
		return `The plugin for '${plugin}' has not been loaded into Immer. To enable the plugin, import and call \`enable${plugin}()\` when initializing your application.`;
	},
	function(thing) {
		return `produce can only be called on things that are draftable: plain objects, arrays, Map, Set or classes that are marked with '[immerable]: true'. Got '${thing}'`;
	},
	"This object has been frozen and should not be mutated",
	function(data) {
		return "Cannot use a proxy that has been revoked. Did you pass an object from inside an immer function to an async process? " + data;
	},
	"An immer producer returned a new value *and* modified its draft. Either return a new value *or* modify the draft.",
	"Immer forbids circular references",
	"The first or second argument to `produce` must be a function",
	"The third argument to `produce` must be a function or undefined",
	"First argument to `createDraft` must be a plain object, an array, or an immerable object",
	"First argument to `finishDraft` must be a draft returned by `createDraft`",
	function(thing) {
		return `'current' expects a draft, got: ${thing}`;
	},
	"Object.defineProperty() cannot be used on an Immer draft",
	"Object.setPrototypeOf() cannot be used on an Immer draft",
	"Immer only supports deleting array indices",
	"Immer only supports setting array indices and the 'length' property",
	function(thing) {
		return `'original' expects a draft, got: ${thing}`;
	}
];
function die(error, ...args) {
	{
		const e = errors[error];
		const msg = isFunction(e) ? e.apply(null, args) : e;
		throw new Error(`[Immer] ${msg}`);
	}
}
var O = Object;
var getPrototypeOf = O.getPrototypeOf;
var CONSTRUCTOR = "constructor";
var PROTOTYPE = "prototype";
var CONFIGURABLE = "configurable";
var ENUMERABLE = "enumerable";
var WRITABLE = "writable";
var VALUE = "value";
var isDraft = (value) => !!value && !!value[DRAFT_STATE];
function isDraftable(value) {
	if (!value) return false;
	return isPlainObject$1(value) || isArray(value) || !!value[DRAFTABLE] || !!value[CONSTRUCTOR]?.[DRAFTABLE] || isMap(value) || isSet(value);
}
var objectCtorString = O[PROTOTYPE][CONSTRUCTOR].toString();
var cachedCtorStrings = /* @__PURE__ */ new WeakMap();
function isPlainObject$1(value) {
	if (!value || !isObjectish(value)) return false;
	const proto = getPrototypeOf(value);
	if (proto === null || proto === O[PROTOTYPE]) return true;
	const Ctor = O.hasOwnProperty.call(proto, CONSTRUCTOR) && proto[CONSTRUCTOR];
	if (Ctor === Object) return true;
	if (!isFunction(Ctor)) return false;
	let ctorString = cachedCtorStrings.get(Ctor);
	if (ctorString === void 0) {
		ctorString = Function.toString.call(Ctor);
		cachedCtorStrings.set(Ctor, ctorString);
	}
	return ctorString === objectCtorString;
}
function original(value) {
	if (!isDraft(value)) die(15, value);
	return value[DRAFT_STATE].base_;
}
function each(obj, iter, strict = true) {
	if (getArchtype(obj) === 0) (strict ? Reflect.ownKeys(obj) : O.keys(obj)).forEach((key) => {
		iter(key, obj[key], obj);
	});
	else obj.forEach((entry, index) => iter(index, entry, obj));
}
function getArchtype(thing) {
	const state = thing[DRAFT_STATE];
	return state ? state.type_ : isArray(thing) ? 1 : isMap(thing) ? 2 : isSet(thing) ? 3 : 0;
}
var has = (thing, prop, type = getArchtype(thing)) => type === 2 ? thing.has(prop) : O[PROTOTYPE].hasOwnProperty.call(thing, prop);
var get = (thing, prop, type = getArchtype(thing)) => type === 2 ? thing.get(prop) : thing[prop];
var set = (thing, propOrOldValue, value, type = getArchtype(thing)) => {
	if (type === 2) thing.set(propOrOldValue, value);
	else if (type === 3) thing.add(value);
	else thing[propOrOldValue] = value;
};
function is(x, y) {
	if (x === y) return x !== 0 || 1 / x === 1 / y;
	else return x !== x && y !== y;
}
var isArray = Array.isArray;
var isMap = (target) => target instanceof Map;
var isSet = (target) => target instanceof Set;
var isObjectish = (target) => typeof target === "object";
var isFunction = (target) => typeof target === "function";
var isBoolean$1 = (target) => typeof target === "boolean";
function isArrayIndex(value) {
	const n = +value;
	return Number.isInteger(n) && String(n) === value;
}
var latest = (state) => state.copy_ || state.base_;
var getFinalValue = (state) => state.modified_ ? state.copy_ : state.base_;
function shallowCopy(base, strict) {
	if (isMap(base)) return new Map(base);
	if (isSet(base)) return new Set(base);
	if (isArray(base)) return Array[PROTOTYPE].slice.call(base);
	const isPlain = isPlainObject$1(base);
	if (strict === true || strict === "class_only" && !isPlain) {
		const descriptors = O.getOwnPropertyDescriptors(base);
		delete descriptors[DRAFT_STATE];
		let keys = Reflect.ownKeys(descriptors);
		for (let i = 0; i < keys.length; i++) {
			const key = keys[i];
			const desc = descriptors[key];
			if (desc[WRITABLE] === false) {
				desc[WRITABLE] = true;
				desc[CONFIGURABLE] = true;
			}
			if (desc.get || desc.set) descriptors[key] = {
				[CONFIGURABLE]: true,
				[WRITABLE]: true,
				[ENUMERABLE]: desc[ENUMERABLE],
				[VALUE]: base[key]
			};
		}
		return O.create(getPrototypeOf(base), descriptors);
	} else {
		const proto = getPrototypeOf(base);
		if (proto !== null && isPlain) return { ...base };
		const obj = O.create(proto);
		return O.assign(obj, base);
	}
}
function freeze(obj, deep = false) {
	if (isFrozen(obj) || isDraft(obj) || !isDraftable(obj)) return obj;
	if (getArchtype(obj) > 1) O.defineProperties(obj, {
		set: dontMutateMethodOverride,
		add: dontMutateMethodOverride,
		clear: dontMutateMethodOverride,
		delete: dontMutateMethodOverride
	});
	O.freeze(obj);
	if (deep) each(obj, (_key, value) => {
		freeze(value, true);
	}, false);
	return obj;
}
function dontMutateFrozenCollections() {
	die(2);
}
var dontMutateMethodOverride = { [VALUE]: dontMutateFrozenCollections };
function isFrozen(obj) {
	if (obj === null || !isObjectish(obj)) return true;
	return O.isFrozen(obj);
}
var PluginMapSet = "MapSet";
var PluginPatches = "Patches";
var PluginArrayMethods = "ArrayMethods";
var plugins = {};
function getPlugin(pluginKey) {
	const plugin = plugins[pluginKey];
	if (!plugin) die(0, pluginKey);
	return plugin;
}
var isPluginLoaded = (pluginKey) => !!plugins[pluginKey];
var currentScope;
var getCurrentScope = () => currentScope;
var createScope = (parent_, immer_) => ({
	drafts_: [],
	parent_,
	immer_,
	canAutoFreeze_: true,
	unfinalizedDrafts_: 0,
	handledSet_: /* @__PURE__ */ new Set(),
	processedForPatches_: /* @__PURE__ */ new Set(),
	mapSetPlugin_: isPluginLoaded(PluginMapSet) ? getPlugin(PluginMapSet) : void 0,
	arrayMethodsPlugin_: isPluginLoaded(PluginArrayMethods) ? getPlugin(PluginArrayMethods) : void 0
});
function usePatchesInScope(scope, patchListener) {
	if (patchListener) {
		scope.patchPlugin_ = getPlugin(PluginPatches);
		scope.patches_ = [];
		scope.inversePatches_ = [];
		scope.patchListener_ = patchListener;
	}
}
function revokeScope(scope) {
	leaveScope(scope);
	scope.drafts_.forEach(revokeDraft);
	scope.drafts_ = null;
}
function leaveScope(scope) {
	if (scope === currentScope) currentScope = scope.parent_;
}
var enterScope = (immer2) => currentScope = createScope(currentScope, immer2);
function revokeDraft(draft) {
	const state = draft[DRAFT_STATE];
	if (state.type_ === 0 || state.type_ === 1) state.revoke_();
	else state.revoked_ = true;
}
function processResult(result, scope) {
	scope.unfinalizedDrafts_ = scope.drafts_.length;
	const baseDraft = scope.drafts_[0];
	if (result !== void 0 && result !== baseDraft) {
		if (baseDraft[DRAFT_STATE].modified_) {
			revokeScope(scope);
			die(4);
		}
		if (isDraftable(result)) result = finalize(scope, result);
		const { patchPlugin_ } = scope;
		if (patchPlugin_) patchPlugin_.generateReplacementPatches_(baseDraft[DRAFT_STATE].base_, result, scope);
	} else result = finalize(scope, baseDraft);
	maybeFreeze(scope, result, true);
	revokeScope(scope);
	if (scope.patches_) scope.patchListener_(scope.patches_, scope.inversePatches_);
	return result !== NOTHING ? result : void 0;
}
function finalize(rootScope, value) {
	if (isFrozen(value)) return value;
	const state = value[DRAFT_STATE];
	if (!state) return handleValue(value, rootScope.handledSet_, rootScope);
	if (!isSameScope(state, rootScope)) return value;
	if (!state.modified_) return state.base_;
	if (!state.finalized_) {
		const { callbacks_ } = state;
		if (callbacks_) while (callbacks_.length > 0) callbacks_.pop()(rootScope);
		generatePatchesAndFinalize(state, rootScope);
	}
	return state.copy_;
}
function maybeFreeze(scope, value, deep = false) {
	if (!scope.parent_ && scope.immer_.autoFreeze_ && scope.canAutoFreeze_) freeze(value, deep);
}
function markStateFinalized(state) {
	state.finalized_ = true;
	state.scope_.unfinalizedDrafts_--;
}
var isSameScope = (state, rootScope) => state.scope_ === rootScope;
var EMPTY_LOCATIONS_RESULT = [];
function updateDraftInParent(parent, draftValue, finalizedValue, originalKey) {
	const parentCopy = latest(parent);
	const parentType = parent.type_;
	if (originalKey !== void 0) {
		if (get(parentCopy, originalKey, parentType) === draftValue) {
			set(parentCopy, originalKey, finalizedValue, parentType);
			return;
		}
	}
	if (!parent.draftLocations_) {
		const draftLocations = parent.draftLocations_ = /* @__PURE__ */ new Map();
		each(parentCopy, (key, value) => {
			if (isDraft(value)) {
				const keys = draftLocations.get(value) || [];
				keys.push(key);
				draftLocations.set(value, keys);
			}
		});
	}
	const locations = parent.draftLocations_.get(draftValue) ?? EMPTY_LOCATIONS_RESULT;
	for (const location of locations) set(parentCopy, location, finalizedValue, parentType);
}
function registerChildFinalizationCallback(parent, child, key) {
	parent.callbacks_.push(function childCleanup(rootScope) {
		const state = child;
		if (!state || !isSameScope(state, rootScope)) return;
		rootScope.mapSetPlugin_?.fixSetContents(state);
		const finalizedValue = getFinalValue(state);
		updateDraftInParent(parent, state.draft_ ?? state, finalizedValue, key);
		generatePatchesAndFinalize(state, rootScope);
	});
}
function generatePatchesAndFinalize(state, rootScope) {
	if (state.modified_ && !state.finalized_ && (state.type_ === 3 || state.type_ === 1 && state.allIndicesReassigned_ || (state.assigned_?.size ?? 0) > 0)) {
		const { patchPlugin_ } = rootScope;
		if (patchPlugin_) {
			const basePath = patchPlugin_.getPath(state);
			if (basePath) patchPlugin_.generatePatches_(state, basePath, rootScope);
		}
		markStateFinalized(state);
	}
}
function handleCrossReference(target, key, value) {
	const { scope_ } = target;
	if (isDraft(value)) {
		const state = value[DRAFT_STATE];
		if (isSameScope(state, scope_)) state.callbacks_.push(function crossReferenceCleanup() {
			prepareCopy(target);
			updateDraftInParent(target, value, getFinalValue(state), key);
		});
	} else if (isDraftable(value)) target.callbacks_.push(function nestedDraftCleanup() {
		const targetCopy = latest(target);
		if (target.type_ === 3) {
			if (targetCopy.has(value)) handleValue(value, scope_.handledSet_, scope_);
		} else if (get(targetCopy, key, target.type_) === value) {
			if (scope_.drafts_.length > 1 && (target.assigned_.get(key) ?? false) === true && target.copy_) handleValue(get(target.copy_, key, target.type_), scope_.handledSet_, scope_);
		}
	});
}
function handleValue(target, handledSet, rootScope) {
	if (!rootScope.immer_.autoFreeze_ && rootScope.unfinalizedDrafts_ < 1) return target;
	if (isDraft(target) || handledSet.has(target) || !isDraftable(target) || isFrozen(target)) return target;
	handledSet.add(target);
	each(target, (key, value) => {
		if (isDraft(value)) {
			const state = value[DRAFT_STATE];
			if (isSameScope(state, rootScope)) {
				set(target, key, getFinalValue(state), target.type_);
				markStateFinalized(state);
			}
		} else if (isDraftable(value)) handleValue(value, handledSet, rootScope);
	});
	return target;
}
function createProxyProxy(base, parent) {
	const baseIsArray = isArray(base);
	const state = {
		type_: baseIsArray ? 1 : 0,
		scope_: parent ? parent.scope_ : getCurrentScope(),
		modified_: false,
		finalized_: false,
		assigned_: void 0,
		parent_: parent,
		base_: base,
		draft_: null,
		copy_: null,
		revoke_: null,
		isManual_: false,
		callbacks_: void 0
	};
	let target = state;
	let traps = objectTraps;
	if (baseIsArray) {
		target = [state];
		traps = arrayTraps;
	}
	const { revoke, proxy } = Proxy.revocable(target, traps);
	state.draft_ = proxy;
	state.revoke_ = revoke;
	return [proxy, state];
}
var objectTraps = {
	get(state, prop) {
		if (prop === DRAFT_STATE) return state;
		let arrayPlugin = state.scope_.arrayMethodsPlugin_;
		const isArrayWithStringProp = state.type_ === 1 && typeof prop === "string";
		if (isArrayWithStringProp) {
			if (arrayPlugin?.isArrayOperationMethod(prop)) return arrayPlugin.createMethodInterceptor(state, prop);
		}
		const source = latest(state);
		if (!has(source, prop, state.type_)) return readPropFromProto(state, source, prop);
		const value = source[prop];
		if (state.finalized_ || !isDraftable(value)) return value;
		if (isArrayWithStringProp && state.operationMethod && arrayPlugin?.isMutatingArrayMethod(state.operationMethod) && isArrayIndex(prop)) return value;
		if (value === peek(state.base_, prop) || isRelocatedBaseRef(state, prop, value)) {
			prepareCopy(state);
			const childKey = state.type_ === 1 ? +prop : prop;
			const childDraft = createProxy(state.scope_, value, state, childKey);
			return state.copy_[childKey] = childDraft;
		}
		return value;
	},
	has(state, prop) {
		return prop in latest(state);
	},
	ownKeys(state) {
		return Reflect.ownKeys(latest(state));
	},
	set(state, prop, value) {
		const desc = getDescriptorFromProto(latest(state), prop);
		if (desc?.set) {
			desc.set.call(state.draft_, value);
			return true;
		}
		if (!state.modified_) {
			const current2 = peek(latest(state), prop);
			const currentState = current2?.[DRAFT_STATE];
			if (currentState && currentState.base_ === value) {
				state.copy_[prop] = value;
				state.assigned_.set(prop, false);
				return true;
			}
			if (is(value, current2) && (value !== void 0 || has(state.base_, prop, state.type_))) return true;
			prepareCopy(state);
			markChanged(state);
		}
		if (state.copy_[prop] === value && (value !== void 0 || has(state.copy_, prop, state.type_)) || Number.isNaN(value) && Number.isNaN(state.copy_[prop])) return true;
		state.copy_[prop] = value;
		state.assigned_.set(prop, true);
		handleCrossReference(state, prop, value);
		return true;
	},
	deleteProperty(state, prop) {
		prepareCopy(state);
		if (peek(state.base_, prop) !== void 0 || prop in state.base_) {
			state.assigned_.set(prop, false);
			markChanged(state);
		} else state.assigned_.delete(prop);
		if (state.copy_) delete state.copy_[prop];
		return true;
	},
	getOwnPropertyDescriptor(state, prop) {
		const owner = latest(state);
		const desc = Reflect.getOwnPropertyDescriptor(owner, prop);
		if (!desc) return desc;
		return {
			[WRITABLE]: true,
			[CONFIGURABLE]: state.type_ !== 1 || prop !== "length",
			[ENUMERABLE]: desc[ENUMERABLE],
			[VALUE]: owner[prop]
		};
	},
	defineProperty() {
		die(11);
	},
	getPrototypeOf(state) {
		return getPrototypeOf(state.base_);
	},
	setPrototypeOf() {
		die(12);
	}
};
var arrayTraps = {};
for (let key in objectTraps) {
	let fn = objectTraps[key];
	arrayTraps[key] = function() {
		const args = arguments;
		args[0] = args[0][0];
		return fn.apply(this, args);
	};
}
arrayTraps.deleteProperty = function(state, prop) {
	if (isNaN(parseInt(prop))) die(13);
	return arrayTraps.set.call(this, state, prop, void 0);
};
arrayTraps.set = function(state, prop, value) {
	if (prop !== "length" && isNaN(parseInt(prop))) die(14);
	return objectTraps.set.call(this, state[0], prop, value, state[0]);
};
function peek(draft, prop) {
	const state = draft[DRAFT_STATE];
	return (state ? latest(state) : draft)[prop];
}
function isRelocatedBaseRef(state, prop, value) {
	if (state.type_ !== 1 || !state.allIndicesReassigned_ || state.assigned_?.get(prop) || !isDraftable(value) || value[DRAFT_STATE]) return false;
	return state.baseRefs_.has(value);
}
function readPropFromProto(state, source, prop) {
	const desc = getDescriptorFromProto(source, prop);
	return desc ? VALUE in desc ? desc[VALUE] : desc.get?.call(state.draft_) : void 0;
}
function getDescriptorFromProto(source, prop) {
	if (!(prop in source)) return void 0;
	let proto = getPrototypeOf(source);
	while (proto) {
		const desc = Object.getOwnPropertyDescriptor(proto, prop);
		if (desc) return desc;
		proto = getPrototypeOf(proto);
	}
}
function markChanged(state) {
	if (!state.modified_) {
		state.modified_ = true;
		if (state.parent_) markChanged(state.parent_);
	}
}
function prepareCopy(state) {
	if (!state.copy_) {
		state.assigned_ = /* @__PURE__ */ new Map();
		state.copy_ = shallowCopy(state.base_, state.scope_.immer_.useStrictShallowCopy_);
	}
}
var Immer2 = class {
	constructor(config) {
		this.autoFreeze_ = true;
		this.useStrictShallowCopy_ = false;
		this.useStrictIteration_ = false;
		/**
		* The `produce` function takes a value and a "recipe function" (whose
		* return value often depends on the base state). The recipe function is
		* free to mutate its first argument however it wants. All mutations are
		* only ever applied to a __copy__ of the base state.
		*
		* Pass only a function to create a "curried producer" which relieves you
		* from passing the recipe function every time.
		*
		* Only plain objects and arrays are made mutable. All other objects are
		* considered uncopyable.
		*
		* Note: This function is __bound__ to its `Immer` instance.
		*
		* @param {any} base - the initial state
		* @param {Function} recipe - function that receives a proxy of the base state as first argument and which can be freely modified
		* @param {Function} patchListener - optional function that will be called with all the patches produced here
		* @returns {any} a new state, or the initial state if nothing was modified
		*/
		this.produce = (base, recipe, patchListener) => {
			if (isFunction(base) && !isFunction(recipe)) {
				const defaultBase = recipe;
				recipe = base;
				const self = this;
				return function curriedProduce(base2 = defaultBase, ...args) {
					return self.produce(base2, (draft) => recipe.call(this, draft, ...args));
				};
			}
			if (!isFunction(recipe)) die(6);
			if (patchListener !== void 0 && !isFunction(patchListener)) die(7);
			let result;
			if (isDraftable(base)) {
				const scope = enterScope(this);
				const proxy = createProxy(scope, base, void 0);
				let hasError = true;
				try {
					result = recipe(proxy);
					hasError = false;
				} finally {
					if (hasError) revokeScope(scope);
					else leaveScope(scope);
				}
				usePatchesInScope(scope, patchListener);
				return processResult(result, scope);
			} else if (!base || !isObjectish(base)) {
				result = recipe(base);
				if (result === void 0) result = base;
				if (result === NOTHING) result = void 0;
				if (this.autoFreeze_) freeze(result, true);
				if (patchListener) {
					const p = [];
					const ip = [];
					getPlugin(PluginPatches).generateReplacementPatches_(base, result, {
						patches_: p,
						inversePatches_: ip
					});
					patchListener(p, ip);
				}
				return result;
			} else die(1, base);
		};
		this.produceWithPatches = (base, recipe) => {
			if (isFunction(base)) return (state, ...args) => this.produceWithPatches(state, (draft) => base(draft, ...args));
			let patches, inversePatches;
			return [
				this.produce(base, recipe, (p, ip) => {
					patches = p;
					inversePatches = ip;
				}),
				patches,
				inversePatches
			];
		};
		if (isBoolean$1(config?.autoFreeze)) this.setAutoFreeze(config.autoFreeze);
		if (isBoolean$1(config?.useStrictShallowCopy)) this.setUseStrictShallowCopy(config.useStrictShallowCopy);
		if (isBoolean$1(config?.useStrictIteration)) this.setUseStrictIteration(config.useStrictIteration);
	}
	createDraft(base) {
		if (!isDraftable(base)) die(8);
		if (isDraft(base)) base = current(base);
		const scope = enterScope(this);
		const proxy = createProxy(scope, base, void 0);
		proxy[DRAFT_STATE].isManual_ = true;
		leaveScope(scope);
		return proxy;
	}
	finishDraft(draft, patchListener) {
		const state = draft && draft[DRAFT_STATE];
		if (!state || !state.isManual_) die(9);
		const { scope_: scope } = state;
		usePatchesInScope(scope, patchListener);
		return processResult(void 0, scope);
	}
	/**
	* Pass true to automatically freeze all copies created by Immer.
	*
	* By default, auto-freezing is enabled.
	*/
	setAutoFreeze(value) {
		this.autoFreeze_ = value;
	}
	/**
	* Pass true to enable strict shallow copy.
	*
	* By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
	*/
	setUseStrictShallowCopy(value) {
		this.useStrictShallowCopy_ = value;
	}
	/**
	* Pass false to use faster iteration that skips non-enumerable properties
	* but still handles symbols for compatibility.
	*
	* By default, strict iteration is enabled (includes all own properties).
	*/
	setUseStrictIteration(value) {
		this.useStrictIteration_ = value;
	}
	shouldUseStrictIteration() {
		return this.useStrictIteration_;
	}
	applyPatches(base, patches) {
		let i;
		for (i = patches.length - 1; i >= 0; i--) {
			const patch = patches[i];
			if (patch.path.length === 0 && patch.op === "replace") {
				base = patch.value;
				break;
			}
		}
		if (i > -1) patches = patches.slice(i + 1);
		const applyPatchesImpl = getPlugin(PluginPatches).applyPatches_;
		if (isDraft(base)) return applyPatchesImpl(base, patches);
		return this.produce(base, (draft) => applyPatchesImpl(draft, patches));
	}
};
function createProxy(rootScope, value, parent, key) {
	const [draft, state] = isMap(value) ? getPlugin(PluginMapSet).proxyMap_(value, parent) : isSet(value) ? getPlugin(PluginMapSet).proxySet_(value, parent) : createProxyProxy(value, parent);
	(parent?.scope_ ?? getCurrentScope()).drafts_.push(draft);
	state.callbacks_ = parent?.callbacks_ ?? [];
	state.key_ = key;
	if (parent && key !== void 0) registerChildFinalizationCallback(parent, state, key);
	else state.callbacks_.push(function rootDraftCleanup(rootScope2) {
		rootScope2.mapSetPlugin_?.fixSetContents(state);
		const { patchPlugin_ } = rootScope2;
		if (state.modified_ && patchPlugin_) patchPlugin_.generatePatches_(state, [], rootScope2);
	});
	return draft;
}
function current(value) {
	if (!isDraft(value)) die(10, value);
	return currentImpl(value);
}
function currentImpl(value) {
	if (!isDraftable(value) || isFrozen(value)) return value;
	const state = value[DRAFT_STATE];
	let copy;
	let strict = true;
	if (state) {
		if (!state.modified_) return state.base_;
		state.finalized_ = true;
		copy = shallowCopy(value, state.scope_.immer_.useStrictShallowCopy_);
		strict = state.scope_.immer_.shouldUseStrictIteration();
	} else copy = shallowCopy(value, true);
	each(copy, (key, childValue) => {
		set(copy, key, currentImpl(childValue));
	}, strict);
	if (state) state.finalized_ = false;
	return copy;
}
globalThis.Iterator?.from;
var produce = new Immer2().produce;
//#endregion
//#region node_modules/redux-thunk/dist/redux-thunk.mjs
function createThunkMiddleware(extraArgument) {
	const middleware = ({ dispatch, getState }) => (next) => (action) => {
		if (typeof action === "function") return action(dispatch, getState, extraArgument);
		return next(action);
	};
	return middleware;
}
var thunk = createThunkMiddleware();
var withExtraArgument = createThunkMiddleware;
//#endregion
//#region node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs
var createDraftSafeSelectorCreator = (...args) => {
	const createSelector2 = createSelectorCreator(...args);
	const createDraftSafeSelector2 = Object.assign((...args2) => {
		const selector = createSelector2(...args2);
		const wrappedSelector = (value, ...rest) => selector(isDraft(value) ? current(value) : value, ...rest);
		Object.assign(wrappedSelector, selector);
		return wrappedSelector;
	}, { withTypes: () => createDraftSafeSelector2 });
	return createDraftSafeSelector2;
};
var createDraftSafeSelector = /* @__PURE__ */ createDraftSafeSelectorCreator(weakMapMemoize);
var composeWithDevTools = typeof window !== "undefined" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : function() {
	if (arguments.length === 0) return void 0;
	if (typeof arguments[0] === "object") return compose;
	return compose.apply(null, arguments);
};
typeof window !== "undefined" && window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__;
var hasMatchFunction = (v) => {
	return v && typeof v.match === "function";
};
function createAction(type, prepareAction) {
	function actionCreator(...args) {
		if (prepareAction) {
			let prepared = prepareAction(...args);
			if (!prepared) throw new Error("prepareAction did not return an object");
			return {
				type,
				payload: prepared.payload,
				..."meta" in prepared && { meta: prepared.meta },
				..."error" in prepared && { error: prepared.error }
			};
		}
		return {
			type,
			payload: args[0]
		};
	}
	actionCreator.toString = () => `${type}`;
	actionCreator.type = type;
	actionCreator.match = (action) => isAction(action) && action.type === type;
	return actionCreator;
}
function isActionCreator(action) {
	return typeof action === "function" && "type" in action && hasMatchFunction(action);
}
function isFSA(action) {
	return isAction(action) && Object.keys(action).every(isValidKey);
}
function isValidKey(key) {
	return [
		"type",
		"payload",
		"error",
		"meta"
	].indexOf(key) > -1;
}
function getMessage(type) {
	const splitType = type ? `${type}`.split("/") : [];
	const actionName = splitType[splitType.length - 1] || "actionCreator";
	return `Detected an action creator with type "${type || "unknown"}" being dispatched.
Make sure you're calling the action creator before dispatching, i.e. \`dispatch(${actionName}())\` instead of \`dispatch(${actionName})\`. This is necessary even if the action has no payload.`;
}
function createActionCreatorInvariantMiddleware(options = {}) {
	const { isActionCreator: isActionCreator2 = isActionCreator } = options;
	return () => (next) => (action) => {
		if (isActionCreator2(action)) console.warn(getMessage(action.type));
		return next(action);
	};
}
function getTimeMeasureUtils(maxDelay, fnName) {
	let elapsed = 0;
	return {
		measureTime(fn) {
			const started = Date.now();
			try {
				return fn();
			} finally {
				elapsed += Date.now() - started;
			}
		},
		warnIfExceeded() {
			if (elapsed > maxDelay) console.warn(`${fnName} took ${elapsed}ms, which is more than the warning threshold of ${maxDelay}ms. 
If your state or actions are very large, you may want to disable the middleware as it might cause too much of a slowdown in development mode. See https://redux-toolkit.js.org/api/getDefaultMiddleware for instructions.
It is disabled in production builds, so you don't need to worry about that.`);
		}
	};
}
var Tuple = class _Tuple extends Array {
	constructor(...items) {
		super(...items);
		Object.setPrototypeOf(this, _Tuple.prototype);
	}
	static get [Symbol.species]() {
		return _Tuple;
	}
	concat(...arr) {
		return super.concat.apply(this, arr);
	}
	prepend(...arr) {
		if (arr.length === 1 && Array.isArray(arr[0])) return new _Tuple(...arr[0].concat(this));
		return new _Tuple(...arr.concat(this));
	}
};
function freezeDraftable(val) {
	return isDraftable(val) ? produce(val, () => {}) : val;
}
function getOrInsertComputed(map, key, compute) {
	if (map.has(key)) return map.get(key);
	return map.set(key, compute(key)).get(key);
}
function isImmutableDefault(value) {
	return typeof value !== "object" || value == null || Object.isFrozen(value);
}
function trackForMutations(isImmutable, ignoredPaths, obj) {
	const trackedProperties = trackProperties(isImmutable, ignoredPaths, obj);
	return { detectMutations() {
		return detectMutations(isImmutable, ignoredPaths, trackedProperties, obj);
	} };
}
function trackProperties(isImmutable, ignoredPaths = [], obj, path = "", checkedObjects = /* @__PURE__ */ new Set()) {
	const tracked = { value: obj };
	if (!isImmutable(obj) && !checkedObjects.has(obj)) {
		checkedObjects.add(obj);
		tracked.children = {};
		const hasIgnoredPaths = ignoredPaths.length > 0;
		for (const key in obj) {
			const nestedPath = path ? path + "." + key : key;
			if (hasIgnoredPaths) {
				if (ignoredPaths.some((ignored) => {
					if (ignored instanceof RegExp) return ignored.test(nestedPath);
					return nestedPath === ignored;
				})) continue;
			}
			tracked.children[key] = trackProperties(isImmutable, ignoredPaths, obj[key], nestedPath);
		}
	}
	return tracked;
}
function detectMutations(isImmutable, ignoredPaths = [], trackedProperty, obj, sameParentRef = false, path = "") {
	const prevObj = trackedProperty ? trackedProperty.value : void 0;
	const sameRef = prevObj === obj;
	if (sameParentRef && !sameRef && !Number.isNaN(obj)) return {
		wasMutated: true,
		path
	};
	if (isImmutable(prevObj) || isImmutable(obj)) return { wasMutated: false };
	const keysToDetect = {};
	for (let key in trackedProperty.children) keysToDetect[key] = true;
	for (let key in obj) keysToDetect[key] = true;
	const hasIgnoredPaths = ignoredPaths.length > 0;
	for (let key in keysToDetect) {
		const nestedPath = path ? path + "." + key : key;
		if (hasIgnoredPaths) {
			if (ignoredPaths.some((ignored) => {
				if (ignored instanceof RegExp) return ignored.test(nestedPath);
				return nestedPath === ignored;
			})) continue;
		}
		const result = detectMutations(isImmutable, ignoredPaths, trackedProperty.children[key], obj[key], sameRef, nestedPath);
		if (result.wasMutated) return result;
	}
	return { wasMutated: false };
}
function createImmutableStateInvariantMiddleware(options = {}) {
	{
		let stringify2 = function(obj, serializer, indent, decycler) {
			return JSON.stringify(obj, getSerialize2(serializer, decycler), indent);
		}, getSerialize2 = function(serializer, decycler) {
			let stack = [], keys = [];
			if (!decycler) decycler = function(_, value) {
				if (stack[0] === value) return "[Circular ~]";
				return "[Circular ~." + keys.slice(0, stack.indexOf(value)).join(".") + "]";
			};
			return function(key, value) {
				if (stack.length > 0) {
					var thisPos = stack.indexOf(this);
					~thisPos ? stack.splice(thisPos + 1) : stack.push(this);
					~thisPos ? keys.splice(thisPos, Infinity, key) : keys.push(key);
					if (~stack.indexOf(value)) value = decycler.call(this, key, value);
				} else stack.push(value);
				return serializer == null ? value : serializer.call(this, key, value);
			};
		};
		let { isImmutable = isImmutableDefault, ignoredPaths, warnAfter = 32 } = options;
		const track = trackForMutations.bind(null, isImmutable, ignoredPaths);
		return ({ getState }) => {
			let state = getState();
			let tracker = track(state);
			let result;
			return (next) => (action) => {
				const measureUtils = getTimeMeasureUtils(warnAfter, "ImmutableStateInvariantMiddleware");
				measureUtils.measureTime(() => {
					state = getState();
					result = tracker.detectMutations();
					tracker = track(state);
					if (result.wasMutated) throw new Error(`A state mutation was detected between dispatches, in the path '${result.path || ""}'.  This may cause incorrect behavior. (https://redux.js.org/style-guide/style-guide#do-not-mutate-state)`);
				});
				const dispatchedAction = next(action);
				measureUtils.measureTime(() => {
					state = getState();
					result = tracker.detectMutations();
					tracker = track(state);
					if (result.wasMutated) throw new Error(`A state mutation was detected inside a dispatch, in the path: ${result.path || ""}. Take a look at the reducer(s) handling the action ${stringify2(action)}. (https://redux.js.org/style-guide/style-guide#do-not-mutate-state)`);
				});
				measureUtils.warnIfExceeded();
				return dispatchedAction;
			};
		};
	}
}
function isPlain(val) {
	const type = typeof val;
	return val == null || type === "string" || type === "boolean" || type === "number" || Array.isArray(val) || isPlainObject(val);
}
function findNonSerializableValue(value, path = "", isSerializable = isPlain, getEntries, ignoredPaths = [], cache) {
	let foundNestedSerializable;
	if (!isSerializable(value)) return {
		keyPath: path || "<root>",
		value
	};
	if (typeof value !== "object" || value === null) return false;
	if (cache?.has(value)) return false;
	const entries = getEntries != null ? getEntries(value) : Object.entries(value);
	const hasIgnoredPaths = ignoredPaths.length > 0;
	for (const [key, nestedValue] of entries) {
		const nestedPath = path ? path + "." + key : key;
		if (hasIgnoredPaths) {
			if (ignoredPaths.some((ignored) => {
				if (ignored instanceof RegExp) return ignored.test(nestedPath);
				return nestedPath === ignored;
			})) continue;
		}
		if (!isSerializable(nestedValue)) return {
			keyPath: nestedPath,
			value: nestedValue
		};
		if (typeof nestedValue === "object") {
			foundNestedSerializable = findNonSerializableValue(nestedValue, nestedPath, isSerializable, getEntries, ignoredPaths, cache);
			if (foundNestedSerializable) return foundNestedSerializable;
		}
	}
	if (cache && isNestedFrozen(value)) cache.add(value);
	return false;
}
function isNestedFrozen(value) {
	if (!Object.isFrozen(value)) return false;
	for (const nestedValue of Object.values(value)) {
		if (typeof nestedValue !== "object" || nestedValue === null) continue;
		if (!isNestedFrozen(nestedValue)) return false;
	}
	return true;
}
function createSerializableStateInvariantMiddleware(options = {}) {
	{
		const { isSerializable = isPlain, getEntries, ignoredActions = [], ignoredActionPaths = ["meta.arg", "meta.baseQueryMeta"], ignoredPaths = [], warnAfter = 32, ignoreState = false, ignoreActions = false, disableCache = false } = options;
		const cache = !disableCache && WeakSet ? /* @__PURE__ */ new WeakSet() : void 0;
		return (storeAPI) => (next) => (action) => {
			if (!isAction(action)) return next(action);
			const result = next(action);
			const measureUtils = getTimeMeasureUtils(warnAfter, "SerializableStateInvariantMiddleware");
			if (!ignoreActions && !(ignoredActions.length && ignoredActions.indexOf(action.type) !== -1)) measureUtils.measureTime(() => {
				const foundActionNonSerializableValue = findNonSerializableValue(action, "", isSerializable, getEntries, ignoredActionPaths, cache);
				if (foundActionNonSerializableValue) {
					const { keyPath, value } = foundActionNonSerializableValue;
					console.error(`A non-serializable value was detected in an action, in the path: \`${keyPath}\`. Value:`, value, "\nTake a look at the logic that dispatched this action: ", action, "\n(See https://redux.js.org/faq/actions#why-should-type-be-a-string-or-at-least-serializable-why-should-my-action-types-be-constants)", "\n(To allow non-serializable values see: https://redux-toolkit.js.org/usage/usage-guide#working-with-non-serializable-data)");
				}
			});
			if (!ignoreState) {
				measureUtils.measureTime(() => {
					const foundStateNonSerializableValue = findNonSerializableValue(storeAPI.getState(), "", isSerializable, getEntries, ignoredPaths, cache);
					if (foundStateNonSerializableValue) {
						const { keyPath, value } = foundStateNonSerializableValue;
						console.error(`A non-serializable value was detected in the state, in the path: \`${keyPath}\`. Value:`, value, `
Take a look at the reducer(s) handling this action type: ${action.type}.
(See https://redux.js.org/faq/organizing-state#can-i-put-functions-promises-or-other-non-serializable-items-in-my-store-state)`);
					}
				});
				measureUtils.warnIfExceeded();
			}
			return result;
		};
	}
}
function isBoolean(x) {
	return typeof x === "boolean";
}
var buildGetDefaultMiddleware = () => function getDefaultMiddleware(options) {
	const { thunk: thunk$1 = true, immutableCheck = true, serializableCheck = true, actionCreatorCheck = true } = options ?? {};
	let middlewareArray = new Tuple();
	if (thunk$1) {
		if (isBoolean(thunk$1)) middlewareArray.push(thunk);
		else middlewareArray.push(withExtraArgument(thunk$1.extraArgument));
	}
	if (immutableCheck) {
		let immutableOptions = {};
		if (!isBoolean(immutableCheck)) immutableOptions = immutableCheck;
		middlewareArray.unshift(createImmutableStateInvariantMiddleware(immutableOptions));
	}
	if (serializableCheck) {
		let serializableOptions = {};
		if (!isBoolean(serializableCheck)) serializableOptions = serializableCheck;
		middlewareArray.push(createSerializableStateInvariantMiddleware(serializableOptions));
	}
	if (actionCreatorCheck) {
		let actionCreatorOptions = {};
		if (!isBoolean(actionCreatorCheck)) actionCreatorOptions = actionCreatorCheck;
		middlewareArray.unshift(createActionCreatorInvariantMiddleware(actionCreatorOptions));
	}
	return middlewareArray;
};
var SHOULD_AUTOBATCH = "RTK_autoBatch";
var prepareAutoBatched = () => (payload) => ({
	payload,
	meta: { [SHOULD_AUTOBATCH]: true }
});
var createQueueWithTimer = (timeout) => {
	return (notify) => {
		setTimeout(notify, timeout);
	};
};
var createRafWithFallbackTimer = (raf, timeout) => {
	return (notify) => {
		let called = false;
		const callback = () => {
			if (called) return;
			called = true;
			cancelAnimationFrame(rafId);
			clearTimeout(timerId);
			notify();
		};
		const rafId = raf(callback);
		const timerId = setTimeout(callback, timeout);
	};
};
var autoBatchEnhancer = (options = { type: "raf" }) => (next) => (...args) => {
	const store = next(...args);
	let notifying = true;
	let shouldNotifyAtEndOfTick = false;
	let notificationQueued = false;
	const listeners = /* @__PURE__ */ new Set();
	const queueCallback = options.type === "tick" ? queueMicrotask : options.type === "raf" ? typeof window !== "undefined" && window.requestAnimationFrame ? createRafWithFallbackTimer(window.requestAnimationFrame, 100) : createQueueWithTimer(10) : options.type === "callback" ? options.queueNotification : createQueueWithTimer(options.timeout);
	const notifyListeners = () => {
		notificationQueued = false;
		if (shouldNotifyAtEndOfTick) {
			shouldNotifyAtEndOfTick = false;
			listeners.forEach((l) => l());
		}
	};
	return Object.assign({}, store, {
		subscribe(listener2) {
			const wrappedListener = () => notifying && listener2();
			const unsubscribe = store.subscribe(wrappedListener);
			listeners.add(listener2);
			return () => {
				unsubscribe();
				listeners.delete(listener2);
			};
		},
		dispatch(action) {
			try {
				notifying = !action?.meta?.[SHOULD_AUTOBATCH];
				shouldNotifyAtEndOfTick = !notifying;
				if (shouldNotifyAtEndOfTick) {
					if (!notificationQueued) {
						notificationQueued = true;
						queueCallback(notifyListeners);
					}
				}
				return store.dispatch(action);
			} finally {
				notifying = true;
			}
		}
	});
};
var buildGetDefaultEnhancers = (middlewareEnhancer) => function getDefaultEnhancers(options) {
	const { autoBatch = true } = options ?? {};
	let enhancerArray = new Tuple(middlewareEnhancer);
	if (autoBatch) enhancerArray.push(autoBatchEnhancer(typeof autoBatch === "object" ? autoBatch : void 0));
	return enhancerArray;
};
function configureStore(options) {
	const getDefaultMiddleware = buildGetDefaultMiddleware();
	const { reducer = void 0, middleware, devTools = true, duplicateMiddlewareCheck = true, preloadedState = void 0, enhancers = void 0 } = options || {};
	let rootReducer;
	if (typeof reducer === "function") rootReducer = reducer;
	else if (isPlainObject(reducer)) rootReducer = combineReducers(reducer);
	else throw new Error("`reducer` is a required argument, and must be a function or an object of functions that can be passed to combineReducers");
	if (middleware && typeof middleware !== "function") throw new Error("`middleware` field must be a callback");
	let finalMiddleware;
	if (typeof middleware === "function") {
		finalMiddleware = middleware(getDefaultMiddleware);
		if (!Array.isArray(finalMiddleware)) throw new Error("when using a middleware builder function, an array of middleware must be returned");
	} else finalMiddleware = getDefaultMiddleware();
	if (finalMiddleware.some((item) => typeof item !== "function")) throw new Error("each middleware provided to configureStore must be a function");
	if (duplicateMiddlewareCheck) {
		let middlewareReferences = /* @__PURE__ */ new Set();
		finalMiddleware.forEach((middleware2) => {
			if (middlewareReferences.has(middleware2)) throw new Error("Duplicate middleware references found when creating the store. Ensure that each middleware is only included once.");
			middlewareReferences.add(middleware2);
		});
	}
	let finalCompose = compose;
	if (devTools) finalCompose = composeWithDevTools({
		trace: true,
		...typeof devTools === "object" && devTools
	});
	const middlewareEnhancer = applyMiddleware(...finalMiddleware);
	const getDefaultEnhancers = buildGetDefaultEnhancers(middlewareEnhancer);
	if (enhancers && typeof enhancers !== "function") throw new Error("`enhancers` field must be a callback");
	let storeEnhancers = typeof enhancers === "function" ? enhancers(getDefaultEnhancers) : getDefaultEnhancers();
	if (!Array.isArray(storeEnhancers)) throw new Error("`enhancers` callback must return an array");
	if (storeEnhancers.some((item) => typeof item !== "function")) throw new Error("each enhancer provided to configureStore must be a function");
	if (finalMiddleware.length && !storeEnhancers.includes(middlewareEnhancer)) console.error("middlewares were provided, but middleware enhancer was not included in final enhancers - make sure to call `getDefaultEnhancers`");
	const composedEnhancer = finalCompose(...storeEnhancers);
	return createStore(rootReducer, preloadedState, composedEnhancer);
}
function executeReducerBuilderCallback(builderCallback) {
	const actionsMap = {};
	const actionMatchers = [];
	let defaultCaseReducer;
	const builder = {
		addCase(typeOrActionCreator, reducer) {
			if (actionMatchers.length > 0) throw new Error("`builder.addCase` should only be called before calling `builder.addMatcher`");
			if (defaultCaseReducer) throw new Error("`builder.addCase` should only be called before calling `builder.addDefaultCase`");
			const type = typeof typeOrActionCreator === "string" ? typeOrActionCreator : typeOrActionCreator.type;
			if (!type) throw new Error("`builder.addCase` cannot be called with an empty action type");
			if (type in actionsMap) throw new Error(`\`builder.addCase\` cannot be called with two reducers for the same action type '${type}'`);
			actionsMap[type] = reducer;
			return builder;
		},
		addAsyncThunk(asyncThunk, reducers) {
			if (defaultCaseReducer) throw new Error("`builder.addAsyncThunk` should only be called before calling `builder.addDefaultCase`");
			if (reducers.pending) actionsMap[asyncThunk.pending.type] = reducers.pending;
			if (reducers.rejected) actionsMap[asyncThunk.rejected.type] = reducers.rejected;
			if (reducers.fulfilled) actionsMap[asyncThunk.fulfilled.type] = reducers.fulfilled;
			if (reducers.settled) actionMatchers.push({
				matcher: asyncThunk.settled,
				reducer: reducers.settled
			});
			return builder;
		},
		addMatcher(matcher, reducer) {
			if (defaultCaseReducer) throw new Error("`builder.addMatcher` should only be called before calling `builder.addDefaultCase`");
			actionMatchers.push({
				matcher,
				reducer
			});
			return builder;
		},
		addDefaultCase(reducer) {
			if (defaultCaseReducer) throw new Error("`builder.addDefaultCase` can only be called once");
			defaultCaseReducer = reducer;
			return builder;
		}
	};
	builderCallback(builder);
	return [
		actionsMap,
		actionMatchers,
		defaultCaseReducer
	];
}
function isStateFunction(x) {
	return typeof x === "function";
}
function createReducer(initialState, mapOrBuilderCallback) {
	if (typeof mapOrBuilderCallback === "object") throw new Error("The object notation for `createReducer` has been removed. Please use the 'builder callback' notation instead: https://redux-toolkit.js.org/api/createReducer");
	let [actionsMap, finalActionMatchers, finalDefaultCaseReducer] = executeReducerBuilderCallback(mapOrBuilderCallback);
	let getInitialState;
	if (isStateFunction(initialState)) getInitialState = () => freezeDraftable(initialState());
	else {
		const frozenInitialState = freezeDraftable(initialState);
		getInitialState = () => frozenInitialState;
	}
	function reducer(state = getInitialState(), action) {
		let caseReducers = [actionsMap[action.type], ...finalActionMatchers.filter(({ matcher }) => matcher(action)).map(({ reducer: reducer2 }) => reducer2)];
		if (caseReducers.filter((cr) => !!cr).length === 0) caseReducers = [finalDefaultCaseReducer];
		return caseReducers.reduce((previousState, caseReducer) => {
			if (caseReducer) {
				if (isDraft(previousState)) {
					const result = caseReducer(previousState, action);
					if (result === void 0) return previousState;
					return result;
				} else if (!isDraftable(previousState)) {
					const result = caseReducer(previousState, action);
					if (result === void 0) {
						if (previousState === null) return previousState;
						throw Error("A case reducer on a non-draftable value must not return undefined");
					}
					return result;
				} else return produce(previousState, (draft) => {
					return caseReducer(draft, action);
				});
			}
			return previousState;
		}, state);
	}
	reducer.getInitialState = getInitialState;
	return reducer;
}
var matches = (matcher, action) => {
	if (hasMatchFunction(matcher)) return matcher.match(action);
	else return matcher(action);
};
function isAnyOf(...matchers) {
	return (action) => {
		return matchers.some((matcher) => matches(matcher, action));
	};
}
function isAllOf(...matchers) {
	return (action) => {
		return matchers.every((matcher) => matches(matcher, action));
	};
}
function hasExpectedRequestMetadata(action, validStatus) {
	if (!action || !action.meta) return false;
	const hasValidRequestId = typeof action.meta.requestId === "string";
	const hasValidRequestStatus = validStatus.indexOf(action.meta.requestStatus) > -1;
	return hasValidRequestId && hasValidRequestStatus;
}
function isAsyncThunkArray(a) {
	return typeof a[0] === "function" && "pending" in a[0] && "fulfilled" in a[0] && "rejected" in a[0];
}
function isPending(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, ["pending"]);
	if (!isAsyncThunkArray(asyncThunks)) return isPending()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.map((asyncThunk) => asyncThunk.pending));
}
function isRejected(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, ["rejected"]);
	if (!isAsyncThunkArray(asyncThunks)) return isRejected()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.map((asyncThunk) => asyncThunk.rejected));
}
function isRejectedWithValue(...asyncThunks) {
	const hasFlag = (action) => {
		return action && action.meta && action.meta.rejectedWithValue;
	};
	if (asyncThunks.length === 0) return isAllOf(isRejected(...asyncThunks), hasFlag);
	if (!isAsyncThunkArray(asyncThunks)) return isRejectedWithValue()(asyncThunks[0]);
	return isAllOf(isRejected(...asyncThunks), hasFlag);
}
function isFulfilled(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, ["fulfilled"]);
	if (!isAsyncThunkArray(asyncThunks)) return isFulfilled()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.map((asyncThunk) => asyncThunk.fulfilled));
}
function isAsyncThunkAction(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, [
		"pending",
		"fulfilled",
		"rejected"
	]);
	if (!isAsyncThunkArray(asyncThunks)) return isAsyncThunkAction()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.flatMap((asyncThunk) => [
		asyncThunk.pending,
		asyncThunk.rejected,
		asyncThunk.fulfilled
	]));
}
var urlAlphabet = "ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW";
var nanoid = (size = 21) => {
	let id = "";
	let i = size;
	while (i--) id += urlAlphabet[Math.random() * 64 | 0];
	return id;
};
var commonProperties = [
	"name",
	"message",
	"stack",
	"code"
];
var RejectWithValue = class {
	constructor(payload, meta) {
		this.payload = payload;
		this.meta = meta;
	}
	payload;
	meta;
	_type;
};
var FulfillWithMeta = class {
	constructor(payload, meta) {
		this.payload = payload;
		this.meta = meta;
	}
	payload;
	meta;
	_type;
};
var miniSerializeError = (value) => {
	if (typeof value === "object" && value !== null) {
		const simpleError = {};
		for (const property of commonProperties) if (typeof value[property] === "string") simpleError[property] = value[property];
		return simpleError;
	}
	return { message: String(value) };
};
var externalAbortMessage = "External signal was aborted";
var createAsyncThunk = /* @__PURE__ */ (() => {
	function createAsyncThunk2(typePrefix, payloadCreator, options) {
		const fulfilled = createAction(typePrefix + "/fulfilled", (payload, requestId, arg, meta) => ({
			payload,
			meta: {
				...meta || {},
				arg,
				requestId,
				requestStatus: "fulfilled"
			}
		}));
		const pending = createAction(typePrefix + "/pending", (requestId, arg, meta) => ({
			payload: void 0,
			meta: {
				...meta || {},
				arg,
				requestId,
				requestStatus: "pending"
			}
		}));
		const rejected = createAction(typePrefix + "/rejected", (error, requestId, arg, payload, meta) => ({
			payload,
			error: (options && options.serializeError || miniSerializeError)(error || "Rejected"),
			meta: {
				...meta || {},
				arg,
				requestId,
				rejectedWithValue: !!payload,
				requestStatus: "rejected",
				aborted: error?.name === "AbortError",
				condition: error?.name === "ConditionError"
			}
		}));
		function actionCreator(arg, { signal } = {}) {
			return (dispatch, getState, extra) => {
				const requestId = options?.idGenerator ? options.idGenerator(arg) : nanoid();
				const abortController = new AbortController();
				let abortHandler;
				let abortReason;
				function abort(reason) {
					abortReason = reason;
					abortController.abort();
				}
				if (signal) {
					if (signal.aborted) abort(externalAbortMessage);
					else signal.addEventListener("abort", () => abort(externalAbortMessage), { once: true });
				}
				const promise = (async function() {
					let finalAction;
					try {
						let conditionResult = options?.condition?.(arg, {
							getState,
							extra
						});
						if (isThenable(conditionResult)) conditionResult = await conditionResult;
						if (conditionResult === false || abortController.signal.aborted) throw {
							name: "ConditionError",
							message: "Aborted due to condition callback returning false."
						};
						const abortedPromise = new Promise((_, reject) => {
							abortHandler = () => {
								reject({
									name: "AbortError",
									message: abortReason || "Aborted"
								});
							};
							abortController.signal.addEventListener("abort", abortHandler, { once: true });
						});
						dispatch(pending(requestId, arg, options?.getPendingMeta?.({
							requestId,
							arg
						}, {
							getState,
							extra
						})));
						finalAction = await Promise.race([abortedPromise, Promise.resolve(payloadCreator(arg, {
							dispatch,
							getState,
							extra,
							requestId,
							signal: abortController.signal,
							abort,
							rejectWithValue: ((value, meta) => {
								return new RejectWithValue(value, meta);
							}),
							fulfillWithValue: ((value, meta) => {
								return new FulfillWithMeta(value, meta);
							})
						})).then((result) => {
							if (result instanceof RejectWithValue) throw result;
							if (result instanceof FulfillWithMeta) return fulfilled(result.payload, requestId, arg, result.meta);
							return fulfilled(result, requestId, arg);
						})]);
					} catch (err) {
						finalAction = err instanceof RejectWithValue ? rejected(null, requestId, arg, err.payload, err.meta) : rejected(err, requestId, arg);
					} finally {
						if (abortHandler) abortController.signal.removeEventListener("abort", abortHandler);
					}
					if (!(options && !options.dispatchConditionRejection && rejected.match(finalAction) && finalAction.meta.condition)) dispatch(finalAction);
					return finalAction;
				})();
				return Object.assign(promise, {
					abort,
					requestId,
					arg,
					unwrap() {
						return promise.then(unwrapResult);
					}
				});
			};
		}
		return Object.assign(actionCreator, {
			pending,
			rejected,
			fulfilled,
			settled: isAnyOf(rejected, fulfilled),
			typePrefix
		});
	}
	createAsyncThunk2.withTypes = () => createAsyncThunk2;
	return createAsyncThunk2;
})();
function unwrapResult(action) {
	if (action.meta && action.meta.rejectedWithValue) throw action.payload;
	if (action.error) throw action.error;
	return action.payload;
}
function isThenable(value) {
	return value !== null && typeof value === "object" && typeof value.then === "function";
}
var asyncThunkSymbol = /* @__PURE__ */ Symbol.for("rtk-slice-createasyncthunk");
var asyncThunkCreator = { [asyncThunkSymbol]: createAsyncThunk };
var ReducerType = /* @__PURE__ */ ((ReducerType2) => {
	ReducerType2["reducer"] = "reducer";
	ReducerType2["reducerWithPrepare"] = "reducerWithPrepare";
	ReducerType2["asyncThunk"] = "asyncThunk";
	return ReducerType2;
})(ReducerType || {});
function getType(slice, actionKey) {
	return `${slice}/${actionKey}`;
}
function buildCreateSlice({ creators } = {}) {
	const cAT = creators?.asyncThunk?.[asyncThunkSymbol];
	return function createSlice2(options) {
		const { name, reducerPath = name } = options;
		if (!name) throw new Error("`name` is a required option for createSlice");
		if (typeof process !== "undefined" && true) {
			if (options.initialState === void 0) console.error("You must provide an `initialState` value that is not `undefined`. You may have misspelled `initialState`");
		}
		const reducers = (typeof options.reducers === "function" ? options.reducers(buildReducerCreators()) : options.reducers) || {};
		const reducerNames = Object.keys(reducers);
		const context = {
			sliceCaseReducersByName: {},
			sliceCaseReducersByType: {},
			actionCreators: {},
			sliceMatchers: []
		};
		const contextMethods = {
			addCase(typeOrActionCreator, reducer2) {
				const type = typeof typeOrActionCreator === "string" ? typeOrActionCreator : typeOrActionCreator.type;
				if (!type) throw new Error("`context.addCase` cannot be called with an empty action type");
				if (type in context.sliceCaseReducersByType) throw new Error("`context.addCase` cannot be called with two reducers for the same action type: " + type);
				context.sliceCaseReducersByType[type] = reducer2;
				return contextMethods;
			},
			addMatcher(matcher, reducer2) {
				context.sliceMatchers.push({
					matcher,
					reducer: reducer2
				});
				return contextMethods;
			},
			exposeAction(name2, actionCreator) {
				context.actionCreators[name2] = actionCreator;
				return contextMethods;
			},
			exposeCaseReducer(name2, reducer2) {
				context.sliceCaseReducersByName[name2] = reducer2;
				return contextMethods;
			}
		};
		reducerNames.forEach((reducerName) => {
			const reducerDefinition = reducers[reducerName];
			const reducerDetails = {
				reducerName,
				type: getType(name, reducerName),
				createNotation: typeof options.reducers === "function"
			};
			if (isAsyncThunkSliceReducerDefinition(reducerDefinition)) handleThunkCaseReducerDefinition(reducerDetails, reducerDefinition, contextMethods, cAT);
			else handleNormalReducerDefinition(reducerDetails, reducerDefinition, contextMethods);
		});
		function buildReducer() {
			if (typeof options.extraReducers === "object") throw new Error("The object notation for `createSlice.extraReducers` has been removed. Please use the 'builder callback' notation instead: https://redux-toolkit.js.org/api/createSlice");
			const [extraReducers = {}, actionMatchers = [], defaultCaseReducer = void 0] = typeof options.extraReducers === "function" ? executeReducerBuilderCallback(options.extraReducers) : [options.extraReducers];
			const finalCaseReducers = {
				...extraReducers,
				...context.sliceCaseReducersByType
			};
			return createReducer(options.initialState, (builder) => {
				for (let key in finalCaseReducers) builder.addCase(key, finalCaseReducers[key]);
				for (let sM of context.sliceMatchers) builder.addMatcher(sM.matcher, sM.reducer);
				for (let m of actionMatchers) builder.addMatcher(m.matcher, m.reducer);
				if (defaultCaseReducer) builder.addDefaultCase(defaultCaseReducer);
			});
		}
		const selectSelf = (state) => state;
		const injectedSelectorCache = /* @__PURE__ */ new Map();
		const injectedStateCache = /* @__PURE__ */ new WeakMap();
		let _reducer;
		function reducer(state, action) {
			if (!_reducer) _reducer = buildReducer();
			return _reducer(state, action);
		}
		function getInitialState() {
			if (!_reducer) _reducer = buildReducer();
			return _reducer.getInitialState();
		}
		function makeSelectorProps(reducerPath2, injected = false) {
			function selectSlice(state) {
				let sliceState = state[reducerPath2];
				if (typeof sliceState === "undefined") {
					if (injected) sliceState = getOrInsertComputed(injectedStateCache, selectSlice, getInitialState);
					else throw new Error("selectSlice returned undefined for an uninjected slice reducer");
				}
				return sliceState;
			}
			function getSelectors(selectState = selectSelf) {
				return getOrInsertComputed(getOrInsertComputed(injectedSelectorCache, injected, () => /* @__PURE__ */ new WeakMap()), selectState, () => {
					const map = {};
					for (const [name2, selector] of Object.entries(options.selectors ?? {})) map[name2] = wrapSelector(selector, selectState, () => getOrInsertComputed(injectedStateCache, selectState, getInitialState), injected);
					return map;
				});
			}
			return {
				reducerPath: reducerPath2,
				getSelectors,
				get selectors() {
					return getSelectors(selectSlice);
				},
				selectSlice
			};
		}
		const slice = {
			name,
			reducer,
			actions: context.actionCreators,
			caseReducers: context.sliceCaseReducersByName,
			getInitialState,
			...makeSelectorProps(reducerPath),
			injectInto(injectable, { reducerPath: pathOpt, ...config } = {}) {
				const newReducerPath = pathOpt ?? reducerPath;
				injectable.inject({
					reducerPath: newReducerPath,
					reducer
				}, config);
				return {
					...slice,
					...makeSelectorProps(newReducerPath, true)
				};
			}
		};
		return slice;
	};
}
function wrapSelector(selector, selectState, getInitialState, injected) {
	function wrapper(rootState, ...args) {
		let sliceState = selectState(rootState);
		if (typeof sliceState === "undefined") {
			if (injected) sliceState = getInitialState();
			else throw new Error("selectState returned undefined for an uninjected slice reducer");
		}
		return selector(sliceState, ...args);
	}
	wrapper.unwrapped = selector;
	return wrapper;
}
var createSlice = /* @__PURE__ */ buildCreateSlice();
function buildReducerCreators() {
	function asyncThunk(payloadCreator, config) {
		return {
			_reducerDefinitionType: "asyncThunk",
			payloadCreator,
			...config
		};
	}
	asyncThunk.withTypes = () => asyncThunk;
	return {
		reducer(caseReducer) {
			return Object.assign({ [caseReducer.name](...args) {
				return caseReducer(...args);
			} }[caseReducer.name], { _reducerDefinitionType: "reducer" });
		},
		preparedReducer(prepare, reducer) {
			return {
				_reducerDefinitionType: "reducerWithPrepare",
				prepare,
				reducer
			};
		},
		asyncThunk
	};
}
function handleNormalReducerDefinition({ type, reducerName, createNotation }, maybeReducerWithPrepare, context) {
	let caseReducer;
	let prepareCallback;
	if ("reducer" in maybeReducerWithPrepare) {
		if (createNotation && !isCaseReducerWithPrepareDefinition(maybeReducerWithPrepare)) throw new Error("Please use the `create.preparedReducer` notation for prepared action creators with the `create` notation.");
		caseReducer = maybeReducerWithPrepare.reducer;
		prepareCallback = maybeReducerWithPrepare.prepare;
	} else caseReducer = maybeReducerWithPrepare;
	context.addCase(type, caseReducer).exposeCaseReducer(reducerName, caseReducer).exposeAction(reducerName, prepareCallback ? createAction(type, prepareCallback) : createAction(type));
}
function isAsyncThunkSliceReducerDefinition(reducerDefinition) {
	return reducerDefinition._reducerDefinitionType === "asyncThunk";
}
function isCaseReducerWithPrepareDefinition(reducerDefinition) {
	return reducerDefinition._reducerDefinitionType === "reducerWithPrepare";
}
function handleThunkCaseReducerDefinition({ type, reducerName }, reducerDefinition, context, cAT) {
	if (!cAT) throw new Error("Cannot use `create.asyncThunk` in the built-in `createSlice`. Use `buildCreateSlice({ creators: { asyncThunk: asyncThunkCreator } })` to create a customised version of `createSlice`.");
	const { payloadCreator, fulfilled, pending, rejected, settled, options } = reducerDefinition;
	const thunk = cAT(type, payloadCreator, options);
	context.exposeAction(reducerName, thunk);
	if (fulfilled) context.addCase(thunk.fulfilled, fulfilled);
	if (pending) context.addCase(thunk.pending, pending);
	if (rejected) context.addCase(thunk.rejected, rejected);
	if (settled) context.addMatcher(thunk.settled, settled);
	context.exposeCaseReducer(reducerName, {
		fulfilled: fulfilled || noop,
		pending: pending || noop,
		rejected: rejected || noop,
		settled: settled || noop
	});
}
function noop() {}
function getInitialEntityState() {
	return {
		ids: [],
		entities: {}
	};
}
function createInitialStateFactory(stateAdapter) {
	function getInitialState(additionalState = {}, entities) {
		const state = Object.assign(getInitialEntityState(), additionalState);
		return entities ? stateAdapter.setAll(state, entities) : state;
	}
	return { getInitialState };
}
function createSelectorsFactory() {
	function getSelectors(selectState, options = {}) {
		const { createSelector: createSelector2 = createDraftSafeSelector } = options;
		const selectIds = (state) => state.ids;
		const selectEntities = (state) => state.entities;
		const selectAll = createSelector2(selectIds, selectEntities, (ids, entities) => ids.map((id) => entities[id]));
		const selectId = (_, id) => id;
		const selectById = (entities, id) => entities[id];
		const selectTotal = createSelector2(selectIds, (ids) => ids.length);
		if (!selectState) return {
			selectIds,
			selectEntities,
			selectAll,
			selectTotal,
			selectById: createSelector2(selectEntities, selectId, selectById)
		};
		const selectGlobalizedEntities = createSelector2(selectState, selectEntities);
		return {
			selectIds: createSelector2(selectState, selectIds),
			selectEntities: selectGlobalizedEntities,
			selectAll: createSelector2(selectState, selectAll),
			selectTotal: createSelector2(selectState, selectTotal),
			selectById: createSelector2(selectGlobalizedEntities, selectId, selectById)
		};
	}
	return { getSelectors };
}
var isDraftTyped = isDraft;
function createSingleArgumentStateOperator(mutator) {
	const operator = createStateOperator((_, state) => mutator(state));
	return function operation(state) {
		return operator(state, void 0);
	};
}
function createStateOperator(mutator) {
	return function operation(state, arg) {
		function isPayloadActionArgument(arg2) {
			return isFSA(arg2);
		}
		const runMutator = (draft) => {
			if (isPayloadActionArgument(arg)) mutator(arg.payload, draft);
			else mutator(arg, draft);
		};
		if (isDraftTyped(state)) {
			runMutator(state);
			return state;
		}
		return produce(state, runMutator);
	};
}
function selectIdValue(entity, selectId) {
	const key = selectId(entity);
	if (key === void 0) console.warn("The entity passed to the `selectId` implementation returned undefined.", "You should probably provide your own `selectId` implementation.", "The entity that was passed:", entity, "The `selectId` implementation:", selectId.toString());
	return key;
}
function ensureEntitiesArray(entities) {
	if (!Array.isArray(entities)) entities = Object.values(entities);
	return entities;
}
function getCurrent(value) {
	return isDraft(value) ? current(value) : value;
}
function splitAddedUpdatedEntities(newEntities, selectId, state) {
	newEntities = ensureEntitiesArray(newEntities);
	const existingIdsArray = getCurrent(state.ids);
	const existingIds = new Set(existingIdsArray);
	const added = [];
	const addedIds = /* @__PURE__ */ new Set([]);
	const updated = [];
	for (const entity of newEntities) {
		const id = selectIdValue(entity, selectId);
		if (existingIds.has(id) || addedIds.has(id)) updated.push({
			id,
			changes: entity
		});
		else {
			addedIds.add(id);
			added.push(entity);
		}
	}
	return [
		added,
		updated,
		existingIdsArray
	];
}
function createUnsortedStateAdapter(selectId) {
	function addOneMutably(entity, state) {
		const key = selectIdValue(entity, selectId);
		if (key in state.entities) return;
		state.ids.push(key);
		state.entities[key] = entity;
	}
	function addManyMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		for (const entity of newEntities) addOneMutably(entity, state);
	}
	function setOneMutably(entity, state) {
		const key = selectIdValue(entity, selectId);
		if (!(key in state.entities)) state.ids.push(key);
		state.entities[key] = entity;
	}
	function setManyMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		for (const entity of newEntities) setOneMutably(entity, state);
	}
	function setAllMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		state.ids = [];
		state.entities = {};
		addManyMutably(newEntities, state);
	}
	function removeOneMutably(key, state) {
		return removeManyMutably([key], state);
	}
	function removeManyMutably(keys, state) {
		let didMutate = false;
		keys.forEach((key) => {
			if (key in state.entities) {
				delete state.entities[key];
				didMutate = true;
			}
		});
		if (didMutate) state.ids = state.ids.filter((id) => id in state.entities);
	}
	function removeAllMutably(state) {
		Object.assign(state, {
			ids: [],
			entities: {}
		});
	}
	function takeNewKey(keys, update, state) {
		const original3 = state.entities[update.id];
		if (original3 === void 0) return false;
		const updated = Object.assign({}, original3, update.changes);
		const newKey = selectIdValue(updated, selectId);
		const hasNewKey = newKey !== update.id;
		if (hasNewKey) {
			keys[update.id] = newKey;
			delete state.entities[update.id];
		}
		state.entities[newKey] = updated;
		return hasNewKey;
	}
	function updateOneMutably(update, state) {
		return updateManyMutably([update], state);
	}
	function updateManyMutably(updates, state) {
		const newKeys = {};
		const updatesPerEntity = {};
		updates.forEach((update) => {
			if (update.id in state.entities) updatesPerEntity[update.id] = {
				id: update.id,
				changes: {
					...updatesPerEntity[update.id]?.changes,
					...update.changes
				}
			};
		});
		updates = Object.values(updatesPerEntity);
		if (updates.length > 0) {
			if (updates.filter((update) => takeNewKey(newKeys, update, state)).length > 0) state.ids = Object.values(state.entities).map((e) => selectIdValue(e, selectId));
		}
	}
	function upsertOneMutably(entity, state) {
		return upsertManyMutably([entity], state);
	}
	function upsertManyMutably(newEntities, state) {
		const [added, updated] = splitAddedUpdatedEntities(newEntities, selectId, state);
		addManyMutably(added, state);
		updateManyMutably(updated, state);
	}
	return {
		removeAll: createSingleArgumentStateOperator(removeAllMutably),
		addOne: createStateOperator(addOneMutably),
		addMany: createStateOperator(addManyMutably),
		setOne: createStateOperator(setOneMutably),
		setMany: createStateOperator(setManyMutably),
		setAll: createStateOperator(setAllMutably),
		updateOne: createStateOperator(updateOneMutably),
		updateMany: createStateOperator(updateManyMutably),
		upsertOne: createStateOperator(upsertOneMutably),
		upsertMany: createStateOperator(upsertManyMutably),
		removeOne: createStateOperator(removeOneMutably),
		removeMany: createStateOperator(removeManyMutably)
	};
}
function findInsertIndex(sortedItems, item, comparisonFunction) {
	let lowIndex = 0;
	let highIndex = sortedItems.length;
	while (lowIndex < highIndex) {
		let middleIndex = lowIndex + highIndex >>> 1;
		const currentItem = sortedItems[middleIndex];
		if (comparisonFunction(item, currentItem) >= 0) lowIndex = middleIndex + 1;
		else highIndex = middleIndex;
	}
	return lowIndex;
}
function insert(sortedItems, item, comparisonFunction) {
	const insertAtIndex = findInsertIndex(sortedItems, item, comparisonFunction);
	sortedItems.splice(insertAtIndex, 0, item);
	return sortedItems;
}
function createSortedStateAdapter(selectId, comparer) {
	const { removeOne, removeMany, removeAll } = createUnsortedStateAdapter(selectId);
	function addOneMutably(entity, state) {
		return addManyMutably([entity], state);
	}
	function addManyMutably(newEntities, state, existingIds) {
		newEntities = ensureEntitiesArray(newEntities);
		const existingKeys = new Set(existingIds ?? getCurrent(state.ids));
		const addedKeys = /* @__PURE__ */ new Set();
		const models = newEntities.filter((model) => {
			const modelId = selectIdValue(model, selectId);
			const notAdded = !addedKeys.has(modelId);
			if (notAdded) addedKeys.add(modelId);
			return !existingKeys.has(modelId) && notAdded;
		});
		if (models.length !== 0) mergeFunction(state, models);
	}
	function setOneMutably(entity, state) {
		return setManyMutably([entity], state);
	}
	function setManyMutably(newEntities, state) {
		let deduplicatedEntities = {};
		newEntities = ensureEntitiesArray(newEntities);
		if (newEntities.length !== 0) {
			for (const item of newEntities) {
				const entityId = selectId(item);
				deduplicatedEntities[entityId] = item;
				delete state.entities[entityId];
			}
			newEntities = ensureEntitiesArray(deduplicatedEntities);
			mergeFunction(state, newEntities);
		}
	}
	function setAllMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		state.entities = {};
		state.ids = [];
		addManyMutably(newEntities, state, []);
	}
	function updateOneMutably(update, state) {
		return updateManyMutably([update], state);
	}
	function updateManyMutably(updates, state) {
		let appliedUpdates = false;
		let replacedIds = false;
		for (let update of updates) {
			const entity = state.entities[update.id];
			if (!entity) continue;
			appliedUpdates = true;
			Object.assign(entity, update.changes);
			const newId = selectId(entity);
			if (update.id !== newId) {
				replacedIds = true;
				delete state.entities[update.id];
				const oldIndex = state.ids.indexOf(update.id);
				state.ids[oldIndex] = newId;
				state.entities[newId] = entity;
			}
		}
		if (appliedUpdates) mergeFunction(state, [], appliedUpdates, replacedIds);
	}
	function upsertOneMutably(entity, state) {
		return upsertManyMutably([entity], state);
	}
	function upsertManyMutably(newEntities, state) {
		const [added, updated, existingIdsArray] = splitAddedUpdatedEntities(newEntities, selectId, state);
		if (added.length) addManyMutably(added, state, existingIdsArray);
		if (updated.length) updateManyMutably(updated, state);
	}
	function areArraysEqual(a, b) {
		if (a.length !== b.length) return false;
		for (let i = 0; i < a.length; i++) {
			if (a[i] === b[i]) continue;
			return false;
		}
		return true;
	}
	const mergeFunction = (state, addedItems, appliedUpdates, replacedIds) => {
		const currentEntities = getCurrent(state.entities);
		const currentIds = getCurrent(state.ids);
		const stateEntities = state.entities;
		let ids = currentIds;
		if (replacedIds) ids = new Set(currentIds);
		let sortedEntities = [];
		for (const id of ids) {
			const entity = currentEntities[id];
			if (entity) sortedEntities.push(entity);
		}
		const wasPreviouslyEmpty = sortedEntities.length === 0;
		for (const item of addedItems) {
			stateEntities[selectId(item)] = item;
			if (!wasPreviouslyEmpty) insert(sortedEntities, item, comparer);
		}
		if (wasPreviouslyEmpty) sortedEntities = addedItems.slice().sort(comparer);
		else if (appliedUpdates) sortedEntities.sort(comparer);
		const newSortedIds = sortedEntities.map(selectId);
		if (!areArraysEqual(currentIds, newSortedIds)) state.ids = newSortedIds;
	};
	return {
		removeOne,
		removeMany,
		removeAll,
		addOne: createStateOperator(addOneMutably),
		updateOne: createStateOperator(updateOneMutably),
		upsertOne: createStateOperator(upsertOneMutably),
		setOne: createStateOperator(setOneMutably),
		setMany: createStateOperator(setManyMutably),
		setAll: createStateOperator(setAllMutably),
		addMany: createStateOperator(addManyMutably),
		updateMany: createStateOperator(updateManyMutably),
		upsertMany: createStateOperator(upsertManyMutably)
	};
}
function createEntityAdapter(options = {}) {
	const { selectId, sortComparer } = {
		sortComparer: false,
		selectId: (instance) => instance.id,
		...options
	};
	const stateAdapter = sortComparer ? createSortedStateAdapter(selectId, sortComparer) : createUnsortedStateAdapter(selectId);
	const stateFactory = createInitialStateFactory(stateAdapter);
	const selectorsFactory = createSelectorsFactory();
	return {
		selectId,
		sortComparer,
		...stateFactory,
		...selectorsFactory,
		...stateAdapter
	};
}
var task = "task";
var listener = "listener";
var completed = "completed";
var cancelled = "cancelled";
var taskCancelled = `task-${cancelled}`;
var taskCompleted = `task-${completed}`;
var listenerCancelled = `${listener}-${cancelled}`;
var listenerCompleted = `${listener}-${completed}`;
var TaskAbortError = class {
	constructor(code) {
		this.code = code;
		this.message = `${task} ${cancelled} (reason: ${code})`;
	}
	code;
	name = "TaskAbortError";
	message;
};
var assertFunction = (func, expected) => {
	if (typeof func !== "function") throw new TypeError(`${expected} is not a function`);
};
var noop2 = () => {};
var catchRejection = (promise, onError = noop2) => {
	promise.catch(onError);
	return promise;
};
var addAbortSignalListener = (abortSignal, callback) => {
	abortSignal.addEventListener("abort", callback, { once: true });
	return () => abortSignal.removeEventListener("abort", callback);
};
var validateActive = (signal) => {
	if (signal.aborted) throw new TaskAbortError(signal.reason);
};
function raceWithSignal(signal, promise) {
	let cleanup = noop2;
	return new Promise((resolve, reject) => {
		const notifyRejection = () => reject(new TaskAbortError(signal.reason));
		if (signal.aborted) {
			notifyRejection();
			return;
		}
		cleanup = addAbortSignalListener(signal, notifyRejection);
		promise.finally(() => cleanup()).then(resolve, reject);
	}).finally(() => {
		cleanup = noop2;
	});
}
var runTask = async (task2, cleanUp) => {
	try {
		await Promise.resolve();
		return {
			status: "ok",
			value: await task2()
		};
	} catch (error) {
		return {
			status: error instanceof TaskAbortError ? "cancelled" : "rejected",
			error
		};
	} finally {
		cleanUp?.();
	}
};
var createPause = (signal) => {
	return (promise) => {
		return catchRejection(raceWithSignal(signal, promise).then((output) => {
			validateActive(signal);
			return output;
		}));
	};
};
var createDelay = (signal) => {
	const pause = createPause(signal);
	return (timeoutMs) => {
		return pause(new Promise((resolve) => setTimeout(resolve, timeoutMs)));
	};
};
var { assign } = Object;
var INTERNAL_NIL_TOKEN = {};
var alm = "listenerMiddleware";
var createFork = (parentAbortSignal, parentBlockingPromises) => {
	const linkControllers = (controller) => addAbortSignalListener(parentAbortSignal, () => controller.abort(parentAbortSignal.reason));
	return (taskExecutor, opts) => {
		assertFunction(taskExecutor, "taskExecutor");
		const childAbortController = new AbortController();
		linkControllers(childAbortController);
		const result = runTask(async () => {
			validateActive(parentAbortSignal);
			validateActive(childAbortController.signal);
			const result2 = await taskExecutor({
				pause: createPause(childAbortController.signal),
				delay: createDelay(childAbortController.signal),
				signal: childAbortController.signal
			});
			validateActive(childAbortController.signal);
			return result2;
		}, () => childAbortController.abort(taskCompleted));
		if (opts?.autoJoin) parentBlockingPromises.push(result.catch(noop2));
		return {
			result: createPause(parentAbortSignal)(result),
			cancel() {
				childAbortController.abort(taskCancelled);
			}
		};
	};
};
var createTakePattern = (startListening, signal) => {
	const take = async (predicate, timeout) => {
		validateActive(signal);
		let unsubscribe = () => {};
		const promises = [new Promise((resolve, reject) => {
			let stopListening = startListening({
				predicate,
				effect: (action, listenerApi) => {
					listenerApi.unsubscribe();
					resolve([
						action,
						listenerApi.getState(),
						listenerApi.getOriginalState()
					]);
				}
			});
			unsubscribe = () => {
				stopListening();
				reject();
			};
		})];
		if (timeout != null) promises.push(new Promise((resolve) => setTimeout(resolve, timeout, null)));
		try {
			const output = await raceWithSignal(signal, Promise.race(promises));
			validateActive(signal);
			return output;
		} finally {
			unsubscribe();
		}
	};
	return ((predicate, timeout) => catchRejection(take(predicate, timeout)));
};
var getListenerEntryPropsFrom = (options) => {
	let { type, actionCreator, matcher, predicate, effect } = options;
	if (type) predicate = createAction(type).match;
	else if (actionCreator) {
		type = actionCreator.type;
		predicate = actionCreator.match;
	} else if (matcher) predicate = matcher;
	else if (predicate) {} else throw new Error("Creating or removing a listener requires one of the known fields for matching an action");
	assertFunction(effect, "options.listener");
	return {
		predicate,
		type,
		effect
	};
};
var createListenerEntry = /* @__PURE__ */ assign((options) => {
	const { type, predicate, effect } = getListenerEntryPropsFrom(options);
	return {
		id: nanoid(),
		effect,
		type,
		predicate,
		pending: /* @__PURE__ */ new Set(),
		unsubscribe: () => {
			throw new Error("Unsubscribe not initialized");
		}
	};
}, { withTypes: () => createListenerEntry });
var findListenerEntry = (listenerMap, options) => {
	const { type, effect, predicate } = getListenerEntryPropsFrom(options);
	return Array.from(listenerMap.values()).find((entry) => {
		return (typeof type === "string" ? entry.type === type : entry.predicate === predicate) && entry.effect === effect;
	});
};
var cancelActiveListeners = (entry) => {
	entry.pending.forEach((controller) => {
		controller.abort(listenerCancelled);
	});
};
var createClearListenerMiddleware = (listenerMap, executingListeners) => {
	return () => {
		for (const listener2 of executingListeners.keys()) cancelActiveListeners(listener2);
		listenerMap.clear();
	};
};
var safelyNotifyError = (errorHandler, errorToNotify, errorInfo) => {
	try {
		errorHandler(errorToNotify, errorInfo);
	} catch (errorHandlerError) {
		setTimeout(() => {
			throw errorHandlerError;
		}, 0);
	}
};
var addListener = /* @__PURE__ */ assign(/* @__PURE__ */ createAction(`${alm}/add`), { withTypes: () => addListener });
var clearAllListeners = /* @__PURE__ */ createAction(`${alm}/removeAll`);
var removeListener = /* @__PURE__ */ assign(/* @__PURE__ */ createAction(`${alm}/remove`), { withTypes: () => removeListener });
var defaultErrorHandler = (...args) => {
	console.error(`${alm}/error`, ...args);
};
var createListenerMiddleware = (middlewareOptions = {}) => {
	const listenerMap = /* @__PURE__ */ new Map();
	const executingListeners = /* @__PURE__ */ new Map();
	const trackExecutingListener = (entry) => {
		const count = executingListeners.get(entry) ?? 0;
		executingListeners.set(entry, count + 1);
	};
	const untrackExecutingListener = (entry) => {
		const count = executingListeners.get(entry) ?? 1;
		if (count === 1) executingListeners.delete(entry);
		else executingListeners.set(entry, count - 1);
	};
	const { extra, onError = defaultErrorHandler } = middlewareOptions;
	assertFunction(onError, "onError");
	const insertEntry = (entry) => {
		entry.unsubscribe = () => listenerMap.delete(entry.id);
		listenerMap.set(entry.id, entry);
		return (cancelOptions) => {
			entry.unsubscribe();
			if (cancelOptions?.cancelActive) cancelActiveListeners(entry);
		};
	};
	const startListening = ((options) => {
		const entry = findListenerEntry(listenerMap, options) ?? createListenerEntry(options);
		return insertEntry(entry);
	});
	assign(startListening, { withTypes: () => startListening });
	const stopListening = (options) => {
		const entry = findListenerEntry(listenerMap, options);
		if (entry) {
			entry.unsubscribe();
			if (options.cancelActive) cancelActiveListeners(entry);
		}
		return !!entry;
	};
	assign(stopListening, { withTypes: () => stopListening });
	const notifyListener = async (entry, action, api, getOriginalState) => {
		const internalTaskController = new AbortController();
		const take = createTakePattern(startListening, internalTaskController.signal);
		const autoJoinPromises = [];
		try {
			entry.pending.add(internalTaskController);
			trackExecutingListener(entry);
			await Promise.resolve(entry.effect(action, assign({}, api, {
				getOriginalState,
				condition: (predicate, timeout) => take(predicate, timeout).then(Boolean),
				take,
				delay: createDelay(internalTaskController.signal),
				pause: createPause(internalTaskController.signal),
				extra,
				signal: internalTaskController.signal,
				fork: createFork(internalTaskController.signal, autoJoinPromises),
				unsubscribe: entry.unsubscribe,
				subscribe: () => {
					listenerMap.set(entry.id, entry);
				},
				cancelActiveListeners: () => {
					entry.pending.forEach((controller, _, set) => {
						if (controller !== internalTaskController) {
							controller.abort(listenerCancelled);
							set.delete(controller);
						}
					});
				},
				cancel: () => {
					internalTaskController.abort(listenerCancelled);
					entry.pending.delete(internalTaskController);
				},
				throwIfCancelled: () => {
					validateActive(internalTaskController.signal);
				}
			})));
		} catch (listenerError) {
			if (!(listenerError instanceof TaskAbortError)) safelyNotifyError(onError, listenerError, { raisedBy: "effect" });
		} finally {
			await Promise.all(autoJoinPromises);
			internalTaskController.abort(listenerCompleted);
			untrackExecutingListener(entry);
			entry.pending.delete(internalTaskController);
		}
	};
	const clearListenerMiddleware = createClearListenerMiddleware(listenerMap, executingListeners);
	const middleware = (api) => (next) => (action) => {
		if (!isAction(action)) return next(action);
		if (addListener.match(action)) return startListening(action.payload);
		if (clearAllListeners.match(action)) {
			clearListenerMiddleware();
			return;
		}
		if (removeListener.match(action)) return stopListening(action.payload);
		let originalState = api.getState();
		const getOriginalState = () => {
			if (originalState === INTERNAL_NIL_TOKEN) throw new Error(`${alm}: getOriginalState can only be called synchronously`);
			return originalState;
		};
		let result;
		try {
			result = next(action);
			if (listenerMap.size > 0) {
				const currentState = api.getState();
				const listenerEntries = Array.from(listenerMap.values());
				for (const entry of listenerEntries) {
					let runListener = false;
					try {
						runListener = entry.predicate(action, currentState, originalState);
					} catch (predicateError) {
						runListener = false;
						safelyNotifyError(onError, predicateError, { raisedBy: "predicate" });
					}
					if (!runListener) continue;
					notifyListener(entry, action, api, getOriginalState);
				}
			}
		} finally {
			originalState = INTERNAL_NIL_TOKEN;
		}
		return result;
	};
	return {
		middleware,
		startListening,
		stopListening,
		clearListeners: clearListenerMiddleware
	};
};
var createMiddlewareEntry = (middleware) => ({
	middleware,
	applied: /* @__PURE__ */ new Map()
});
var matchInstance = (instanceId) => (action) => action?.meta?.instanceId === instanceId;
var createDynamicMiddleware = () => {
	const instanceId = nanoid();
	const middlewareMap = /* @__PURE__ */ new Map();
	const withMiddleware = Object.assign(createAction("dynamicMiddleware/add", (...middlewares) => ({
		payload: middlewares,
		meta: { instanceId }
	})), { withTypes: () => withMiddleware });
	const addMiddleware = Object.assign(function addMiddleware2(...middlewares) {
		middlewares.forEach((middleware2) => {
			getOrInsertComputed(middlewareMap, middleware2, createMiddlewareEntry);
		});
	}, { withTypes: () => addMiddleware });
	const getFinalMiddleware = (api) => {
		return compose(...Array.from(middlewareMap.values()).map((entry) => getOrInsertComputed(entry.applied, api, entry.middleware)));
	};
	const isWithMiddleware = isAllOf(withMiddleware, matchInstance(instanceId));
	const middleware = (api) => (next) => (action) => {
		if (isWithMiddleware(action)) {
			addMiddleware(...action.payload);
			return api.dispatch;
		}
		return getFinalMiddleware(api)(next)(action);
	};
	return {
		middleware,
		addMiddleware,
		withMiddleware,
		instanceId
	};
};
var isSliceLike = (maybeSliceLike) => "reducerPath" in maybeSliceLike && typeof maybeSliceLike.reducerPath === "string";
var getReducers = (slices) => slices.flatMap((sliceOrMap) => isSliceLike(sliceOrMap) ? [[sliceOrMap.reducerPath, sliceOrMap.reducer]] : Object.entries(sliceOrMap));
var ORIGINAL_STATE = /* @__PURE__ */ Symbol.for("rtk-state-proxy-original");
var isStateProxy = (value) => !!value && !!value[ORIGINAL_STATE];
var stateProxyMap = /* @__PURE__ */ new WeakMap();
var createStateProxy = (state, reducerMap, initialStateCache) => getOrInsertComputed(stateProxyMap, state, () => new Proxy(state, { get: (target, prop, receiver) => {
	if (prop === ORIGINAL_STATE) return target;
	const result = Reflect.get(target, prop, receiver);
	if (typeof result === "undefined") {
		const cached = initialStateCache[prop];
		if (typeof cached !== "undefined") return cached;
		const reducer = reducerMap[prop];
		if (reducer) {
			const reducerResult = reducer(void 0, { type: nanoid() });
			if (typeof reducerResult === "undefined") throw new Error(`The slice reducer for key "${prop.toString()}" returned undefined when called for selector(). If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined.`);
			initialStateCache[prop] = reducerResult;
			return reducerResult;
		}
	}
	return result;
} }));
var original$1 = (state) => {
	if (!isStateProxy(state)) throw new Error("original must be used on state Proxy");
	return state[ORIGINAL_STATE];
};
var emptyObject = {};
var noopReducer = (state = emptyObject) => state;
function combineSlices(...slices) {
	const reducerMap = Object.fromEntries(getReducers(slices));
	const getReducer = () => Object.keys(reducerMap).length ? combineReducers(reducerMap) : noopReducer;
	let reducer = getReducer();
	function combinedReducer(state, action) {
		return reducer(state, action);
	}
	combinedReducer.withLazyLoadedSlices = () => combinedReducer;
	const initialStateCache = {};
	const inject = (slice, config = {}) => {
		const { reducerPath, reducer: reducerToInject } = slice;
		const currentReducer = reducerMap[reducerPath];
		if (!config.overrideExisting && currentReducer && currentReducer !== reducerToInject) {
			if (typeof process !== "undefined" && true) console.error(`called \`inject\` to override already-existing reducer ${reducerPath} without specifying \`overrideExisting: true\``);
			return combinedReducer;
		}
		if (config.overrideExisting && currentReducer !== reducerToInject) delete initialStateCache[reducerPath];
		reducerMap[reducerPath] = reducerToInject;
		reducer = getReducer();
		return combinedReducer;
	};
	const selector = Object.assign(function makeSelector(selectorFn, selectState) {
		return function selector2(state, ...args) {
			return selectorFn(createStateProxy(selectState ? selectState(state, ...args) : state, reducerMap, initialStateCache), ...args);
		};
	}, { original: original$1 });
	return Object.assign(combinedReducer, {
		inject,
		selector
	});
}
function formatProdErrorMessage(code) {
	return `Minified Redux Toolkit error #${code}; visit https://redux-toolkit.js.org/Errors?code=${code} for the full message or use the non-minified dev environment for full errors. `;
}
//#endregion
export { ReducerType, SHOULD_AUTOBATCH, TaskAbortError, Tuple, actionTypes_default as __DO_NOT_USE__ActionTypes, addListener, applyMiddleware, asyncThunkCreator, autoBatchEnhancer, bindActionCreators, buildCreateSlice, clearAllListeners, combineReducers, combineSlices, compose, configureStore, createAction, createActionCreatorInvariantMiddleware, createAsyncThunk, createDraftSafeSelector, createDraftSafeSelectorCreator, createDynamicMiddleware, createEntityAdapter, createImmutableStateInvariantMiddleware, createListenerMiddleware, produce as createNextState, createReducer, createSelector, createSelectorCreator, createSerializableStateInvariantMiddleware, createSlice, createStore, current, findNonSerializableValue, formatProdErrorMessage, freeze, isAction, isActionCreator, isAllOf, isAnyOf, isAsyncThunkAction, isDraft, isFSA as isFluxStandardAction, isFulfilled, isImmutableDefault, isPending, isPlain, isPlainObject, isRejected, isRejectedWithValue, legacy_createStore, lruMemoize, miniSerializeError, nanoid, original, prepareAutoBatched, removeListener, unwrapResult, weakMapMemoize };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHJlZHV4anNfdG9vbGtpdC5qcyIsIm5hbWVzIjpbImlzUGxhaW5PYmplY3QiLCJpc0Jvb2xlYW4iLCJ0aHVuayIsInRodW5rTWlkZGxld2FyZSIsImRyYWZ0Iiwib3JpZ2luYWwiLCJjb21iaW5lUmVkdWNlcnMyIl0sInNvdXJjZXMiOlsiLi4vLi4vcmVzZWxlY3QvZGlzdC9yZXNlbGVjdC5tanMiLCIuLi8uLi9yZWR1eC9kaXN0L3JlZHV4Lm1qcyIsIi4uLy4uL2ltbWVyL2Rpc3QvaW1tZXIubWpzIiwiLi4vLi4vcmVkdXgtdGh1bmsvZGlzdC9yZWR1eC10aHVuay5tanMiLCIuLi8uLi9AcmVkdXhqcy90b29sa2l0L2Rpc3QvcmVkdXgtdG9vbGtpdC5tb2Rlcm4ubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy9kZXZNb2RlQ2hlY2tzL2NhY2hlU2l6ZUNoZWNrLnRzXG52YXIgQ0FDSEVfU0laRV9DSEVDS19USFJFU0hPTEQgPSAxZTM7XG52YXIgcnVuQ2FjaGVTaXplQ2hlY2sgPSAoY2FjaGVTaXplLCBmdW5jTmFtZSkgPT4ge1xuICBsZXQgc3RhY2sgPSB2b2lkIDA7XG4gIHRyeSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICA7XG4gICAgKHsgc3RhY2sgfSA9IGUpO1xuICB9XG4gIGNvbnNvbGUud2FybihcbiAgICBgQSBmdW5jdGlvbiBtZW1vaXplZCB3aXRoIHdlYWtNYXBNZW1vaXplJHtmdW5jTmFtZSA/IGAgKFxcYCR7ZnVuY05hbWV9XFxgKWAgOiBcIlwifSBoYXMgc2VlbiBvdmVyICR7Y2FjaGVTaXplfSBkaXN0aW5jdCB2YWx1ZXMgZm9yIHRoZSBzYW1lIHByaW1pdGl2ZSBhcmd1bWVudCBwb3NpdGlvbi5cblJlc3VsdHMga2V5ZWQgYnkgcHJpbWl0aXZlIGFyZ3VtZW50cyBhcmUgaGVsZCBzdHJvbmdseSBhbmQgYXJlIG9ubHkgcmVsZWFzZWQgYnkgXFxgY2xlYXJDYWNoZSgpXFxgLCBzbyB0aGlzIGNhY2hlIHdpbGwga2VlcCBncm93aW5nIGZvciBhcyBsb25nIGFzIHRoZSBmdW5jdGlvbiBrZWVwcyBzZWVpbmcgbmV3IHZhbHVlcy5cbklmIGl0IGlzIGNhbGxlZCB3aXRoIGV2ZXItY2hhbmdpbmcgcHJpbWl0aXZlcyAoaWRzLCBvZmZzZXRzLCB0aW1lc3RhbXBzKSwgcGFzcyB0aGUgXFxgbWF4U2l6ZVxcYCBvcHRpb24gdG8gYm91bmQgdGhlIGNhY2hlLCBzd2l0Y2ggdG8gXFxgbHJ1TWVtb2l6ZVxcYCwgb3IgY2FsbCBcXGAuY2xlYXJDYWNoZSgpXFxgIGF0IGEgc3VpdGFibGUgcG9pbnQuXG5TZWUgaHR0cHM6Ly9yZXNlbGVjdC5qcy5vcmcvYXBpL2RldmVsb3BtZW50LW9ubHktY2hlY2tzI2NhY2hlc2l6ZWNoZWNrIGZvciBkZXRhaWxzLmAsXG4gICAgeyBzdGFjayB9XG4gICk7XG59O1xuXG4vLyBzcmMvZGV2TW9kZUNoZWNrcy9zZXRHbG9iYWxEZXZNb2RlQ2hlY2tzLnRzXG52YXIgZ2xvYmFsRGV2TW9kZUNoZWNrcyA9IHtcbiAgaW5wdXRTdGFiaWxpdHlDaGVjazogXCJvbmNlXCIsXG4gIGlkZW50aXR5RnVuY3Rpb25DaGVjazogXCJvbmNlXCIsXG4gIGNhY2hlU2l6ZUNoZWNrOiBcIm9uY2VcIlxufTtcbnZhciBzZXRHbG9iYWxEZXZNb2RlQ2hlY2tzID0gKGRldk1vZGVDaGVja3MpID0+IHtcbiAgT2JqZWN0LmFzc2lnbihnbG9iYWxEZXZNb2RlQ2hlY2tzLCBkZXZNb2RlQ2hlY2tzKTtcbn07XG5cbi8vIHNyYy93ZWFrTWFwTWVtb2l6ZS50c1xudmFyIFN0cm9uZ1JlZiA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IodmFsdWUpIHtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gIH1cbiAgZGVyZWYoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWU7XG4gIH1cbn07XG52YXIgZ2V0V2Vha1JlZiA9ICgpID0+IHR5cGVvZiBXZWFrUmVmID09PSBcInVuZGVmaW5lZFwiID8gU3Ryb25nUmVmIDogV2Vha1JlZjtcbnZhciBSZWYgPSAvKiBAX19QVVJFX18gKi8gZ2V0V2Vha1JlZigpO1xudmFyIFVOVEVSTUlOQVRFRCA9IDA7XG52YXIgVEVSTUlOQVRFRCA9IDE7XG5mdW5jdGlvbiBjcmVhdGVDYWNoZU5vZGUoKSB7XG4gIHJldHVybiB7XG4gICAgczogVU5URVJNSU5BVEVELFxuICAgIHY6IHZvaWQgMCxcbiAgICBvOiBudWxsLFxuICAgIHA6IG51bGxcbiAgfTtcbn1cbmZ1bmN0aW9uIG1heWJlRGVyZWYocikge1xuICBpZiAociBpbnN0YW5jZW9mIFJlZikge1xuICAgIHJldHVybiByLmRlcmVmKCk7XG4gIH1cbiAgcmV0dXJuIHI7XG59XG5mdW5jdGlvbiB3ZWFrTWFwTWVtb2l6ZShmdW5jLCBvcHRpb25zID0ge30pIHtcbiAgbGV0IGZuTm9kZSA9IGNyZWF0ZUNhY2hlTm9kZSgpO1xuICBjb25zdCB7IHJlc3VsdEVxdWFsaXR5Q2hlY2ssIG1heFNpemUgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHVzZUdlbmVyYXRpb25zID0gbWF4U2l6ZSAhPT0gdm9pZCAwO1xuICBpZiAodXNlR2VuZXJhdGlvbnMgJiYgKCFOdW1iZXIuaXNJbnRlZ2VyKG1heFNpemUpIHx8IG1heFNpemUgPCAxKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXG4gICAgICBgbWF4U2l6ZSBtdXN0IGJlIGEgcG9zaXRpdmUgaW50ZWdlciwgcmVjZWl2ZWQ6ICR7bWF4U2l6ZX1gXG4gICAgKTtcbiAgfVxuICBsZXQgcHJldk5vZGUgPSBudWxsO1xuICBsZXQgaW5zZXJ0aW9uQ291bnQgPSAwO1xuICBsZXQgbGFzdFJlc3VsdDtcbiAgbGV0IHJlc3VsdHNDb3VudCA9IDA7XG4gIGxldCBoYXNXYXJuZWRBYm91dENhY2hlU2l6ZSA9IGZhbHNlO1xuICBmdW5jdGlvbiBtYXliZUZsaXBHZW5lcmF0aW9ucygpIHtcbiAgICBpZiAoaW5zZXJ0aW9uQ291bnQgPj0gbWF4U2l6ZSkge1xuICAgICAgcHJldk5vZGUgPSBmbk5vZGU7XG4gICAgICBmbk5vZGUgPSBjcmVhdGVDYWNoZU5vZGUoKTtcbiAgICAgIGluc2VydGlvbkNvdW50ID0gMDtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gbWVtb2l6ZWQoKSB7XG4gICAgbGV0IGNhY2hlTm9kZSA9IGZuTm9kZTtcbiAgICBjb25zdCB7IGxlbmd0aCB9ID0gYXJndW1lbnRzO1xuICAgIGZvciAobGV0IGkgPSAwLCBsID0gbGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICBjb25zdCBhcmcgPSBhcmd1bWVudHNbaV07XG4gICAgICBpZiAodHlwZW9mIGFyZyA9PT0gXCJmdW5jdGlvblwiIHx8IHR5cGVvZiBhcmcgPT09IFwib2JqZWN0XCIgJiYgYXJnICE9PSBudWxsKSB7XG4gICAgICAgIGxldCBvYmplY3RDYWNoZSA9IGNhY2hlTm9kZS5vO1xuICAgICAgICBpZiAob2JqZWN0Q2FjaGUgPT09IG51bGwpIHtcbiAgICAgICAgICBjYWNoZU5vZGUubyA9IG9iamVjdENhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb2JqZWN0Tm9kZSA9IG9iamVjdENhY2hlLmdldChhcmcpO1xuICAgICAgICBpZiAob2JqZWN0Tm9kZSA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgY2FjaGVOb2RlID0gY3JlYXRlQ2FjaGVOb2RlKCk7XG4gICAgICAgICAgb2JqZWN0Q2FjaGUuc2V0KGFyZywgY2FjaGVOb2RlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjYWNoZU5vZGUgPSBvYmplY3ROb2RlO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZXQgcHJpbWl0aXZlQ2FjaGUgPSBjYWNoZU5vZGUucDtcbiAgICAgICAgaWYgKHByaW1pdGl2ZUNhY2hlID09PSBudWxsKSB7XG4gICAgICAgICAgY2FjaGVOb2RlLnAgPSBwcmltaXRpdmVDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJpbWl0aXZlTm9kZSA9IHByaW1pdGl2ZUNhY2hlLmdldChhcmcpO1xuICAgICAgICBpZiAocHJpbWl0aXZlTm9kZSA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgY2FjaGVOb2RlID0gY3JlYXRlQ2FjaGVOb2RlKCk7XG4gICAgICAgICAgcHJpbWl0aXZlQ2FjaGUuc2V0KGFyZywgY2FjaGVOb2RlKTtcbiAgICAgICAgICBpbnNlcnRpb25Db3VudCsrO1xuICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgICAgICAgIGlmIChwcmltaXRpdmVDYWNoZS5zaXplID4gQ0FDSEVfU0laRV9DSEVDS19USFJFU0hPTEQpIHtcbiAgICAgICAgICAgICAgY29uc3QgeyBjYWNoZVNpemVDaGVjayB9ID0gZ2xvYmFsRGV2TW9kZUNoZWNrcztcbiAgICAgICAgICAgICAgaWYgKGNhY2hlU2l6ZUNoZWNrID09PSBcImFsd2F5c1wiIHx8IGNhY2hlU2l6ZUNoZWNrID09PSBcIm9uY2VcIiAmJiAhaGFzV2FybmVkQWJvdXRDYWNoZVNpemUpIHtcbiAgICAgICAgICAgICAgICBoYXNXYXJuZWRBYm91dENhY2hlU2l6ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgcnVuQ2FjaGVTaXplQ2hlY2socHJpbWl0aXZlQ2FjaGUuc2l6ZSwgZnVuYy5uYW1lKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjYWNoZU5vZGUgPSBwcmltaXRpdmVOb2RlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChjYWNoZU5vZGUucyA9PT0gVEVSTUlOQVRFRCkge1xuICAgICAgcmV0dXJuIGNhY2hlTm9kZS52O1xuICAgIH1cbiAgICBpZiAocHJldk5vZGUgIT09IG51bGwpIHtcbiAgICAgIGxldCBwcmV2Q2FjaGVOb2RlID0gcHJldk5vZGU7XG4gICAgICBmb3IgKGxldCBpID0gMCwgbCA9IGxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICBjb25zdCBhcmcgPSBhcmd1bWVudHNbaV07XG4gICAgICAgIGxldCBuZXh0O1xuICAgICAgICBpZiAodHlwZW9mIGFyZyA9PT0gXCJmdW5jdGlvblwiIHx8IHR5cGVvZiBhcmcgPT09IFwib2JqZWN0XCIgJiYgYXJnICE9PSBudWxsKSB7XG4gICAgICAgICAgY29uc3QgcHJldk9iamVjdENhY2hlID0gcHJldkNhY2hlTm9kZS5vO1xuICAgICAgICAgIG5leHQgPSBwcmV2T2JqZWN0Q2FjaGUgIT09IG51bGwgPyBwcmV2T2JqZWN0Q2FjaGUuZ2V0KGFyZykgOiB2b2lkIDA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgcHJldlByaW1pdGl2ZUNhY2hlID0gcHJldkNhY2hlTm9kZS5wO1xuICAgICAgICAgIG5leHQgPSBwcmV2UHJpbWl0aXZlQ2FjaGUgIT09IG51bGwgPyBwcmV2UHJpbWl0aXZlQ2FjaGUuZ2V0KGFyZykgOiB2b2lkIDA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5leHQgPT09IHZvaWQgMCkge1xuICAgICAgICAgIHByZXZDYWNoZU5vZGUgPSBudWxsO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHByZXZDYWNoZU5vZGUgPSBuZXh0O1xuICAgICAgfVxuICAgICAgaWYgKHByZXZDYWNoZU5vZGUgIT09IG51bGwgJiYgcHJldkNhY2hlTm9kZS5zID09PSBURVJNSU5BVEVEKSB7XG4gICAgICAgIGNvbnN0IHByb21vdGVkTm9kZSA9IGNhY2hlTm9kZTtcbiAgICAgICAgcHJvbW90ZWROb2RlLnMgPSBURVJNSU5BVEVEO1xuICAgICAgICBwcm9tb3RlZE5vZGUudiA9IHByZXZDYWNoZU5vZGUudjtcbiAgICAgICAgbWF5YmVGbGlwR2VuZXJhdGlvbnMoKTtcbiAgICAgICAgcmV0dXJuIHByZXZDYWNoZU5vZGUudjtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgdGVybWluYXRlZE5vZGUgPSBjYWNoZU5vZGU7XG4gICAgbGV0IHJlc3VsdCA9IGZ1bmMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTtcbiAgICByZXN1bHRzQ291bnQrKztcbiAgICBpZiAocmVzdWx0RXF1YWxpdHlDaGVjaykge1xuICAgICAgY29uc3QgbGFzdFJlc3VsdFZhbHVlID0gbWF5YmVEZXJlZihsYXN0UmVzdWx0KTtcbiAgICAgIGlmIChsYXN0UmVzdWx0VmFsdWUgIT0gbnVsbCAmJiByZXN1bHRFcXVhbGl0eUNoZWNrKGxhc3RSZXN1bHRWYWx1ZSwgcmVzdWx0KSkge1xuICAgICAgICByZXN1bHQgPSBsYXN0UmVzdWx0VmFsdWU7XG4gICAgICAgIHJlc3VsdHNDb3VudCAhPT0gMCAmJiByZXN1bHRzQ291bnQtLTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG5lZWRzV2Vha1JlZiA9IHR5cGVvZiByZXN1bHQgPT09IFwib2JqZWN0XCIgJiYgcmVzdWx0ICE9PSBudWxsIHx8IHR5cGVvZiByZXN1bHQgPT09IFwiZnVuY3Rpb25cIjtcbiAgICAgIGxhc3RSZXN1bHQgPSBuZWVkc1dlYWtSZWYgPyAvKiBAX19QVVJFX18gKi8gbmV3IFJlZihyZXN1bHQpIDogcmVzdWx0O1xuICAgIH1cbiAgICB0ZXJtaW5hdGVkTm9kZS5zID0gVEVSTUlOQVRFRDtcbiAgICB0ZXJtaW5hdGVkTm9kZS52ID0gcmVzdWx0O1xuICAgIGlmICh1c2VHZW5lcmF0aW9ucykge1xuICAgICAgbWF5YmVGbGlwR2VuZXJhdGlvbnMoKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBtZW1vaXplZC5jbGVhckNhY2hlID0gKCkgPT4ge1xuICAgIGZuTm9kZSA9IGNyZWF0ZUNhY2hlTm9kZSgpO1xuICAgIHByZXZOb2RlID0gbnVsbDtcbiAgICBpbnNlcnRpb25Db3VudCA9IDA7XG4gICAgbWVtb2l6ZWQucmVzZXRSZXN1bHRzQ291bnQoKTtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBoYXNXYXJuZWRBYm91dENhY2hlU2l6ZSA9IGZhbHNlO1xuICAgIH1cbiAgfTtcbiAgbWVtb2l6ZWQucmVzdWx0c0NvdW50ID0gKCkgPT4gcmVzdWx0c0NvdW50O1xuICBtZW1vaXplZC5yZXNldFJlc3VsdHNDb3VudCA9ICgpID0+IHtcbiAgICByZXN1bHRzQ291bnQgPSAwO1xuICB9O1xuICByZXR1cm4gbWVtb2l6ZWQ7XG59XG5cbi8vIHNyYy9kZXZNb2RlQ2hlY2tzL2lkZW50aXR5RnVuY3Rpb25DaGVjay50c1xudmFyIHJ1bklkZW50aXR5RnVuY3Rpb25DaGVjayA9IChyZXN1bHRGdW5jLCBpbnB1dFNlbGVjdG9yc1Jlc3VsdHMsIG91dHB1dFNlbGVjdG9yUmVzdWx0KSA9PiB7XG4gIGlmIChpbnB1dFNlbGVjdG9yc1Jlc3VsdHMubGVuZ3RoID09PSAxICYmIGlucHV0U2VsZWN0b3JzUmVzdWx0c1swXSA9PT0gb3V0cHV0U2VsZWN0b3JSZXN1bHQpIHtcbiAgICBsZXQgaXNJbnB1dFNhbWVBc091dHB1dCA9IGZhbHNlO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBlbXB0eU9iamVjdCA9IHt9O1xuICAgICAgaWYgKHJlc3VsdEZ1bmMoZW1wdHlPYmplY3QpID09PSBlbXB0eU9iamVjdCkgaXNJbnB1dFNhbWVBc091dHB1dCA9IHRydWU7XG4gICAgfSBjYXRjaCB7XG4gICAgfVxuICAgIGlmIChpc0lucHV0U2FtZUFzT3V0cHV0KSB7XG4gICAgICBsZXQgc3RhY2sgPSB2b2lkIDA7XG4gICAgICB0cnkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgO1xuICAgICAgICAoeyBzdGFjayB9ID0gZSk7XG4gICAgICB9XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIFwiVGhlIHJlc3VsdCBmdW5jdGlvbiByZXR1cm5lZCBpdHMgb3duIGlucHV0cyB3aXRob3V0IG1vZGlmaWNhdGlvbi4gZS5nXFxuYGNyZWF0ZVNlbGVjdG9yKFtzdGF0ZSA9PiBzdGF0ZS50b2Rvc10sIHRvZG9zID0+IHRvZG9zKWBcXG5UaGlzIGNvdWxkIGxlYWQgdG8gaW5lZmZpY2llbnQgbWVtb2l6YXRpb24gYW5kIHVubmVjZXNzYXJ5IHJlLXJlbmRlcnMuXFxuRW5zdXJlIHRyYW5zZm9ybWF0aW9uIGxvZ2ljIGlzIGluIHRoZSByZXN1bHQgZnVuY3Rpb24sIGFuZCBleHRyYWN0aW9uIGxvZ2ljIGlzIGluIHRoZSBpbnB1dCBzZWxlY3RvcnMuXCIsXG4gICAgICAgIHsgc3RhY2sgfVxuICAgICAgKTtcbiAgICB9XG4gIH1cbn07XG5cbi8vIHNyYy9kZXZNb2RlQ2hlY2tzL2lucHV0U3RhYmlsaXR5Q2hlY2sudHNcbnZhciB3aXRob3V0UmVzdWx0RXF1YWxpdHlDaGVjayA9IChvcHRpb24pID0+IHtcbiAgaWYgKG9wdGlvbiA9PT0gbnVsbCB8fCB0eXBlb2Ygb3B0aW9uICE9PSBcIm9iamVjdFwiIHx8ICEoXCJyZXN1bHRFcXVhbGl0eUNoZWNrXCIgaW4gb3B0aW9uKSkge1xuICAgIHJldHVybiBvcHRpb247XG4gIH1cbiAgY29uc3Qgb3B0aW9uQ29weSA9IHsgLi4ub3B0aW9uIH07XG4gIGRlbGV0ZSBvcHRpb25Db3B5LnJlc3VsdEVxdWFsaXR5Q2hlY2s7XG4gIHJldHVybiBvcHRpb25Db3B5O1xufTtcbnZhciBydW5JbnB1dFN0YWJpbGl0eUNoZWNrID0gKGlucHV0U2VsZWN0b3JSZXN1bHRzT2JqZWN0LCBvcHRpb25zLCBpbnB1dFNlbGVjdG9yQXJncykgPT4ge1xuICBjb25zdCB7IG1lbW9pemUsIG1lbW9pemVPcHRpb25zIH0gPSBvcHRpb25zO1xuICBjb25zdCB7IGlucHV0U2VsZWN0b3JSZXN1bHRzLCBpbnB1dFNlbGVjdG9yUmVzdWx0c0NvcHkgfSA9IGlucHV0U2VsZWN0b3JSZXN1bHRzT2JqZWN0O1xuICBjb25zdCBwcm9iZU1lbW9pemVPcHRpb25zID0gW107XG4gIGNvbnN0IHsgbGVuZ3RoIH0gPSBtZW1vaXplT3B0aW9ucztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgIHByb2JlTWVtb2l6ZU9wdGlvbnMucHVzaCh3aXRob3V0UmVzdWx0RXF1YWxpdHlDaGVjayhtZW1vaXplT3B0aW9uc1tpXSkpO1xuICB9XG4gIGNvbnN0IGNyZWF0ZUFuRW1wdHlPYmplY3QgPSBtZW1vaXplKCgpID0+ICh7fSksIC4uLnByb2JlTWVtb2l6ZU9wdGlvbnMpO1xuICBjb25zdCBhcmVJbnB1dFNlbGVjdG9yUmVzdWx0c0VxdWFsID0gY3JlYXRlQW5FbXB0eU9iamVjdC5hcHBseShudWxsLCBpbnB1dFNlbGVjdG9yUmVzdWx0cykgPT09IGNyZWF0ZUFuRW1wdHlPYmplY3QuYXBwbHkobnVsbCwgaW5wdXRTZWxlY3RvclJlc3VsdHNDb3B5KTtcbiAgaWYgKCFhcmVJbnB1dFNlbGVjdG9yUmVzdWx0c0VxdWFsKSB7XG4gICAgbGV0IHN0YWNrID0gdm9pZCAwO1xuICAgIHRyeSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICA7XG4gICAgICAoeyBzdGFjayB9ID0gZSk7XG4gICAgfVxuICAgIGNvbnNvbGUud2FybihcbiAgICAgIFwiQW4gaW5wdXQgc2VsZWN0b3IgcmV0dXJuZWQgYSBkaWZmZXJlbnQgcmVzdWx0IHdoZW4gcGFzc2VkIHNhbWUgYXJndW1lbnRzLlxcblRoaXMgbWVhbnMgeW91ciBvdXRwdXQgc2VsZWN0b3Igd2lsbCBsaWtlbHkgcnVuIG1vcmUgZnJlcXVlbnRseSB0aGFuIGludGVuZGVkLlxcbkF2b2lkIHJldHVybmluZyBhIG5ldyByZWZlcmVuY2UgaW5zaWRlIHlvdXIgaW5wdXQgc2VsZWN0b3IsIGUuZy5cXG5gY3JlYXRlU2VsZWN0b3IoW3N0YXRlID0+IHN0YXRlLnRvZG9zLm1hcCh0b2RvID0+IHRvZG8uaWQpXSwgdG9kb0lkcyA9PiB0b2RvSWRzLmxlbmd0aClgXCIsXG4gICAgICB7XG4gICAgICAgIGFyZ3VtZW50czogaW5wdXRTZWxlY3RvckFyZ3MsXG4gICAgICAgIGZpcnN0SW5wdXRzOiBpbnB1dFNlbGVjdG9yUmVzdWx0cyxcbiAgICAgICAgc2Vjb25kSW5wdXRzOiBpbnB1dFNlbGVjdG9yUmVzdWx0c0NvcHksXG4gICAgICAgIHN0YWNrXG4gICAgICB9XG4gICAgKTtcbiAgfVxufTtcblxuLy8gc3JjL3V0aWxzLnRzXG52YXIgTk9UX0ZPVU5EID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcIk5PVF9GT1VORFwiKTtcbmZ1bmN0aW9uIGFzc2VydElzRnVuY3Rpb24oZnVuYywgZXJyb3JNZXNzYWdlID0gYGV4cGVjdGVkIGEgZnVuY3Rpb24sIGluc3RlYWQgcmVjZWl2ZWQgJHt0eXBlb2YgZnVuY31gKSB7XG4gIGlmICh0eXBlb2YgZnVuYyAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihlcnJvck1lc3NhZ2UpO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRJc09iamVjdChvYmplY3QsIGVycm9yTWVzc2FnZSA9IGBleHBlY3RlZCBhbiBvYmplY3QsIGluc3RlYWQgcmVjZWl2ZWQgJHt0eXBlb2Ygb2JqZWN0fWApIHtcbiAgaWYgKHR5cGVvZiBvYmplY3QgIT09IFwib2JqZWN0XCIpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGVycm9yTWVzc2FnZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGFzc2VydElzQXJyYXlPZkZ1bmN0aW9ucyhhcnJheSwgZXJyb3JNZXNzYWdlID0gYGV4cGVjdGVkIGFsbCBpdGVtcyB0byBiZSBmdW5jdGlvbnMsIGluc3RlYWQgcmVjZWl2ZWQgdGhlIGZvbGxvd2luZyB0eXBlczogYCkge1xuICBpZiAoIWFycmF5LmV2ZXJ5KChpdGVtKSA9PiB0eXBlb2YgaXRlbSA9PT0gXCJmdW5jdGlvblwiKSkge1xuICAgIGNvbnN0IGl0ZW1UeXBlcyA9IGFycmF5Lm1hcChcbiAgICAgIChpdGVtKSA9PiB0eXBlb2YgaXRlbSA9PT0gXCJmdW5jdGlvblwiID8gYGZ1bmN0aW9uICR7aXRlbS5uYW1lIHx8IFwidW5uYW1lZFwifSgpYCA6IHR5cGVvZiBpdGVtXG4gICAgKS5qb2luKFwiLCBcIik7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgJHtlcnJvck1lc3NhZ2V9WyR7aXRlbVR5cGVzfV1gKTtcbiAgfVxufVxudmFyIGVuc3VyZUlzQXJyYXkgPSAoaXRlbSkgPT4ge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheShpdGVtKSA/IGl0ZW0gOiBbaXRlbV07XG59O1xuZnVuY3Rpb24gZ2V0RGVwZW5kZW5jaWVzKGNyZWF0ZVNlbGVjdG9yQXJncykge1xuICBjb25zdCBkZXBlbmRlbmNpZXMgPSBBcnJheS5pc0FycmF5KGNyZWF0ZVNlbGVjdG9yQXJnc1swXSkgPyBjcmVhdGVTZWxlY3RvckFyZ3NbMF0gOiBjcmVhdGVTZWxlY3RvckFyZ3M7XG4gIGFzc2VydElzQXJyYXlPZkZ1bmN0aW9ucyhcbiAgICBkZXBlbmRlbmNpZXMsXG4gICAgYGNyZWF0ZVNlbGVjdG9yIGV4cGVjdHMgYWxsIGlucHV0LXNlbGVjdG9ycyB0byBiZSBmdW5jdGlvbnMsIGJ1dCByZWNlaXZlZCB0aGUgZm9sbG93aW5nIHR5cGVzOiBgXG4gICk7XG4gIHJldHVybiBkZXBlbmRlbmNpZXM7XG59XG5mdW5jdGlvbiBjb2xsZWN0SW5wdXRTZWxlY3RvclJlc3VsdHMoZGVwZW5kZW5jaWVzLCBpbnB1dFNlbGVjdG9yQXJncykge1xuICBjb25zdCBpbnB1dFNlbGVjdG9yUmVzdWx0cyA9IFtdO1xuICBjb25zdCB7IGxlbmd0aCB9ID0gZGVwZW5kZW5jaWVzO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgaW5wdXRTZWxlY3RvclJlc3VsdHMucHVzaChkZXBlbmRlbmNpZXNbaV0uYXBwbHkobnVsbCwgaW5wdXRTZWxlY3RvckFyZ3MpKTtcbiAgfVxuICByZXR1cm4gaW5wdXRTZWxlY3RvclJlc3VsdHM7XG59XG5cbi8vIHNyYy9jcmVhdGVTZWxlY3RvckNyZWF0b3IudHNcbmZ1bmN0aW9uIGNyZWF0ZVNlbGVjdG9yQ3JlYXRvcihtZW1vaXplT3JPcHRpb25zLCAuLi5tZW1vaXplT3B0aW9uc0Zyb21BcmdzKSB7XG4gIGNvbnN0IGNyZWF0ZVNlbGVjdG9yQ3JlYXRvck9wdGlvbnMgPSB0eXBlb2YgbWVtb2l6ZU9yT3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiID8ge1xuICAgIG1lbW9pemU6IG1lbW9pemVPck9wdGlvbnMsXG4gICAgbWVtb2l6ZU9wdGlvbnM6IG1lbW9pemVPcHRpb25zRnJvbUFyZ3NcbiAgfSA6IG1lbW9pemVPck9wdGlvbnM7XG4gIGNvbnN0IGNyZWF0ZVNlbGVjdG9yMiA9ICguLi5jcmVhdGVTZWxlY3RvckFyZ3MpID0+IHtcbiAgICBsZXQgcmVjb21wdXRhdGlvbnMgPSAwO1xuICAgIGxldCBkZXBlbmRlbmN5UmVjb21wdXRhdGlvbnMgPSAwO1xuICAgIGxldCBsYXN0UmVzdWx0O1xuICAgIGxldCBkaXJlY3RseVBhc3NlZE9wdGlvbnMgPSB7fTtcbiAgICBsZXQgcmVzdWx0RnVuYyA9IGNyZWF0ZVNlbGVjdG9yQXJncy5wb3AoKTtcbiAgICBpZiAodHlwZW9mIHJlc3VsdEZ1bmMgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGRpcmVjdGx5UGFzc2VkT3B0aW9ucyA9IHJlc3VsdEZ1bmM7XG4gICAgICByZXN1bHRGdW5jID0gY3JlYXRlU2VsZWN0b3JBcmdzLnBvcCgpO1xuICAgIH1cbiAgICBhc3NlcnRJc0Z1bmN0aW9uKFxuICAgICAgcmVzdWx0RnVuYyxcbiAgICAgIGBjcmVhdGVTZWxlY3RvciBleHBlY3RzIGFuIG91dHB1dCBmdW5jdGlvbiBhZnRlciB0aGUgaW5wdXRzLCBidXQgcmVjZWl2ZWQ6IFske3R5cGVvZiByZXN1bHRGdW5jfV1gXG4gICAgKTtcbiAgICBjb25zdCBjb21iaW5lZE9wdGlvbnMgPSB7XG4gICAgICAuLi5jcmVhdGVTZWxlY3RvckNyZWF0b3JPcHRpb25zLFxuICAgICAgLi4uZGlyZWN0bHlQYXNzZWRPcHRpb25zXG4gICAgfTtcbiAgICBjb25zdCB7XG4gICAgICBtZW1vaXplLFxuICAgICAgbWVtb2l6ZU9wdGlvbnMgPSBbXSxcbiAgICAgIGFyZ3NNZW1vaXplID0gd2Vha01hcE1lbW9pemUsXG4gICAgICBhcmdzTWVtb2l6ZU9wdGlvbnMgPSBbXVxuICAgIH0gPSBjb21iaW5lZE9wdGlvbnM7XG4gICAgY29uc3QgZmluYWxNZW1vaXplT3B0aW9ucyA9IGVuc3VyZUlzQXJyYXkobWVtb2l6ZU9wdGlvbnMpO1xuICAgIGNvbnN0IGZpbmFsQXJnc01lbW9pemVPcHRpb25zID0gZW5zdXJlSXNBcnJheShhcmdzTWVtb2l6ZU9wdGlvbnMpO1xuICAgIGNvbnN0IGRlcGVuZGVuY2llcyA9IGdldERlcGVuZGVuY2llcyhjcmVhdGVTZWxlY3RvckFyZ3MpO1xuICAgIGNvbnN0IG1lbW9pemVkUmVzdWx0RnVuYyA9IG1lbW9pemUoZnVuY3Rpb24gcmVjb21wdXRhdGlvbldyYXBwZXIoKSB7XG4gICAgICByZWNvbXB1dGF0aW9ucysrO1xuICAgICAgcmV0dXJuIHJlc3VsdEZ1bmMuYXBwbHkoXG4gICAgICAgIG51bGwsXG4gICAgICAgIGFyZ3VtZW50c1xuICAgICAgKTtcbiAgICB9LCAuLi5maW5hbE1lbW9pemVPcHRpb25zKTtcbiAgICBsZXQgZmlyc3RSdW4gPSB0cnVlO1xuICAgIGNvbnN0IHNlbGVjdG9yID0gYXJnc01lbW9pemUoZnVuY3Rpb24gZGVwZW5kZW5jaWVzQ2hlY2tlcigpIHtcbiAgICAgIGRlcGVuZGVuY3lSZWNvbXB1dGF0aW9ucysrO1xuICAgICAgY29uc3QgeyBsZW5ndGggfSA9IGRlcGVuZGVuY2llcztcbiAgICAgIGNvbnN0IGlucHV0U2VsZWN0b3JSZXN1bHRzID0gbmV3IEFycmF5KGxlbmd0aCk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlucHV0U2VsZWN0b3JSZXN1bHRzW2ldID0gZGVwZW5kZW5jaWVzW2ldLmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG4gICAgICB9XG4gICAgICBsYXN0UmVzdWx0ID0gbWVtb2l6ZWRSZXN1bHRGdW5jLmFwcGx5KG51bGwsIGlucHV0U2VsZWN0b3JSZXN1bHRzKTtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgICAgY29uc3QgeyBkZXZNb2RlQ2hlY2tzIH0gPSBjb21iaW5lZE9wdGlvbnM7XG4gICAgICAgIGNvbnN0IGlkZW50aXR5RnVuY3Rpb25DaGVjayA9IGRldk1vZGVDaGVja3MgIT09IHZvaWQgMCAmJiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoXG4gICAgICAgICAgZGV2TW9kZUNoZWNrcyxcbiAgICAgICAgICBcImlkZW50aXR5RnVuY3Rpb25DaGVja1wiXG4gICAgICAgICkgPyBkZXZNb2RlQ2hlY2tzLmlkZW50aXR5RnVuY3Rpb25DaGVjayA6IGdsb2JhbERldk1vZGVDaGVja3MuaWRlbnRpdHlGdW5jdGlvbkNoZWNrO1xuICAgICAgICBjb25zdCBpbnB1dFN0YWJpbGl0eUNoZWNrID0gZGV2TW9kZUNoZWNrcyAhPT0gdm9pZCAwICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChcbiAgICAgICAgICBkZXZNb2RlQ2hlY2tzLFxuICAgICAgICAgIFwiaW5wdXRTdGFiaWxpdHlDaGVja1wiXG4gICAgICAgICkgPyBkZXZNb2RlQ2hlY2tzLmlucHV0U3RhYmlsaXR5Q2hlY2sgOiBnbG9iYWxEZXZNb2RlQ2hlY2tzLmlucHV0U3RhYmlsaXR5Q2hlY2s7XG4gICAgICAgIGlmIChpZGVudGl0eUZ1bmN0aW9uQ2hlY2sgPT09IFwiYWx3YXlzXCIgfHwgaWRlbnRpdHlGdW5jdGlvbkNoZWNrID09PSBcIm9uY2VcIiAmJiBmaXJzdFJ1bikge1xuICAgICAgICAgIHJ1bklkZW50aXR5RnVuY3Rpb25DaGVjayhcbiAgICAgICAgICAgIHJlc3VsdEZ1bmMsXG4gICAgICAgICAgICBpbnB1dFNlbGVjdG9yUmVzdWx0cyxcbiAgICAgICAgICAgIGxhc3RSZXN1bHRcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpbnB1dFN0YWJpbGl0eUNoZWNrID09PSBcImFsd2F5c1wiIHx8IGlucHV0U3RhYmlsaXR5Q2hlY2sgPT09IFwib25jZVwiICYmIGZpcnN0UnVuKSB7XG4gICAgICAgICAgY29uc3QgaW5wdXRTZWxlY3RvclJlc3VsdHNDb3B5ID0gY29sbGVjdElucHV0U2VsZWN0b3JSZXN1bHRzKFxuICAgICAgICAgICAgZGVwZW5kZW5jaWVzLFxuICAgICAgICAgICAgYXJndW1lbnRzXG4gICAgICAgICAgKTtcbiAgICAgICAgICBydW5JbnB1dFN0YWJpbGl0eUNoZWNrKFxuICAgICAgICAgICAgeyBpbnB1dFNlbGVjdG9yUmVzdWx0cywgaW5wdXRTZWxlY3RvclJlc3VsdHNDb3B5IH0sXG4gICAgICAgICAgICB7IG1lbW9pemUsIG1lbW9pemVPcHRpb25zOiBmaW5hbE1lbW9pemVPcHRpb25zIH0sXG4gICAgICAgICAgICBhcmd1bWVudHNcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmaXJzdFJ1bikgZmlyc3RSdW4gPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBsYXN0UmVzdWx0O1xuICAgIH0sIC4uLmZpbmFsQXJnc01lbW9pemVPcHRpb25zKTtcbiAgICByZXR1cm4gT2JqZWN0LmFzc2lnbihzZWxlY3Rvciwge1xuICAgICAgcmVzdWx0RnVuYyxcbiAgICAgIG1lbW9pemVkUmVzdWx0RnVuYyxcbiAgICAgIGRlcGVuZGVuY2llcyxcbiAgICAgIGRlcGVuZGVuY3lSZWNvbXB1dGF0aW9uczogKCkgPT4gZGVwZW5kZW5jeVJlY29tcHV0YXRpb25zLFxuICAgICAgcmVzZXREZXBlbmRlbmN5UmVjb21wdXRhdGlvbnM6ICgpID0+IHtcbiAgICAgICAgZGVwZW5kZW5jeVJlY29tcHV0YXRpb25zID0gMDtcbiAgICAgIH0sXG4gICAgICBsYXN0UmVzdWx0OiAoKSA9PiBsYXN0UmVzdWx0LFxuICAgICAgcmVjb21wdXRhdGlvbnM6ICgpID0+IHJlY29tcHV0YXRpb25zLFxuICAgICAgcmVzZXRSZWNvbXB1dGF0aW9uczogKCkgPT4ge1xuICAgICAgICByZWNvbXB1dGF0aW9ucyA9IDA7XG4gICAgICB9LFxuICAgICAgbWVtb2l6ZSxcbiAgICAgIGFyZ3NNZW1vaXplXG4gICAgfSk7XG4gIH07XG4gIE9iamVjdC5hc3NpZ24oY3JlYXRlU2VsZWN0b3IyLCB7XG4gICAgd2l0aFR5cGVzOiAoKSA9PiBjcmVhdGVTZWxlY3RvcjJcbiAgfSk7XG4gIHJldHVybiBjcmVhdGVTZWxlY3RvcjI7XG59XG52YXIgY3JlYXRlU2VsZWN0b3IgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlU2VsZWN0b3JDcmVhdG9yKHdlYWtNYXBNZW1vaXplKTtcblxuLy8gc3JjL2NyZWF0ZVN0cnVjdHVyZWRTZWxlY3Rvci50c1xudmFyIGNyZWF0ZVN0cnVjdHVyZWRTZWxlY3RvciA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuYXNzaWduKFxuICAoaW5wdXRTZWxlY3RvcnNPYmplY3QsIHNlbGVjdG9yQ3JlYXRvciA9IGNyZWF0ZVNlbGVjdG9yKSA9PiB7XG4gICAgYXNzZXJ0SXNPYmplY3QoXG4gICAgICBpbnB1dFNlbGVjdG9yc09iamVjdCxcbiAgICAgIGBjcmVhdGVTdHJ1Y3R1cmVkU2VsZWN0b3IgZXhwZWN0cyBmaXJzdCBhcmd1bWVudCB0byBiZSBhbiBvYmplY3Qgd2hlcmUgZWFjaCBwcm9wZXJ0eSBpcyBhIHNlbGVjdG9yLCBpbnN0ZWFkIHJlY2VpdmVkIGEgJHt0eXBlb2YgaW5wdXRTZWxlY3RvcnNPYmplY3R9YFxuICAgICk7XG4gICAgY29uc3QgaW5wdXRTZWxlY3RvcktleXMgPSBPYmplY3Qua2V5cyhpbnB1dFNlbGVjdG9yc09iamVjdCk7XG4gICAgY29uc3QgZGVwZW5kZW5jaWVzID0gaW5wdXRTZWxlY3RvcktleXMubWFwKFxuICAgICAgKGtleSkgPT4gaW5wdXRTZWxlY3RvcnNPYmplY3Rba2V5XVxuICAgICk7XG4gICAgY29uc3Qgc3RydWN0dXJlZFNlbGVjdG9yID0gc2VsZWN0b3JDcmVhdG9yKFxuICAgICAgZGVwZW5kZW5jaWVzLFxuICAgICAgKC4uLmlucHV0U2VsZWN0b3JSZXN1bHRzKSA9PiB7XG4gICAgICAgIHJldHVybiBpbnB1dFNlbGVjdG9yUmVzdWx0cy5yZWR1Y2UoKGNvbXBvc2l0aW9uLCB2YWx1ZSwgaW5kZXgpID0+IHtcbiAgICAgICAgICBjb21wb3NpdGlvbltpbnB1dFNlbGVjdG9yS2V5c1tpbmRleF1dID0gdmFsdWU7XG4gICAgICAgICAgcmV0dXJuIGNvbXBvc2l0aW9uO1xuICAgICAgICB9LCB7fSk7XG4gICAgICB9XG4gICAgKTtcbiAgICByZXR1cm4gc3RydWN0dXJlZFNlbGVjdG9yO1xuICB9LFxuICB7IHdpdGhUeXBlczogKCkgPT4gY3JlYXRlU3RydWN0dXJlZFNlbGVjdG9yIH1cbik7XG5cbi8vIHNyYy9scnVNZW1vaXplLnRzXG5mdW5jdGlvbiBjcmVhdGVTaW5nbGV0b25DYWNoZShlcXVhbHMpIHtcbiAgbGV0IGVudHJ5O1xuICByZXR1cm4ge1xuICAgIGdldChrZXkpIHtcbiAgICAgIGlmIChlbnRyeSAmJiBlcXVhbHMoZW50cnkua2V5LCBrZXkpKSB7XG4gICAgICAgIHJldHVybiBlbnRyeS52YWx1ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBOT1RfRk9VTkQ7XG4gICAgfSxcbiAgICBwdXQoa2V5LCB2YWx1ZSkge1xuICAgICAgZW50cnkgPSB7IGtleSwgdmFsdWUgfTtcbiAgICB9LFxuICAgIGZpbmRNYXRjaGluZ0VudHJ5KHZhbHVlLCByZXN1bHRFcXVhbGl0eUNoZWNrKSB7XG4gICAgICBjb25zdCBjdXJyZW50ID0gZW50cnk7XG4gICAgICByZXR1cm4gY3VycmVudCAhPT0gdm9pZCAwICYmIHJlc3VsdEVxdWFsaXR5Q2hlY2soY3VycmVudC52YWx1ZSwgdmFsdWUpID8gY3VycmVudCA6IHZvaWQgMDtcbiAgICB9LFxuICAgIGNsZWFyKCkge1xuICAgICAgZW50cnkgPSB2b2lkIDA7XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gY3JlYXRlTHJ1Q2FjaGUobWF4U2l6ZSwgZXF1YWxzKSB7XG4gIGxldCBlbnRyaWVzID0gW107XG4gIGZ1bmN0aW9uIGdldChrZXkpIHtcbiAgICBjb25zdCBjYWNoZUluZGV4ID0gZW50cmllcy5maW5kSW5kZXgoKGVudHJ5KSA9PiBlcXVhbHMoZW50cnkua2V5LCBrZXkpKTtcbiAgICBpZiAoY2FjaGVJbmRleCA+IC0xKSB7XG4gICAgICBjb25zdCBlbnRyeSA9IGVudHJpZXNbY2FjaGVJbmRleF07XG4gICAgICBpZiAoY2FjaGVJbmRleCA+IDApIHtcbiAgICAgICAgZW50cmllcy5zcGxpY2UoY2FjaGVJbmRleCwgMSk7XG4gICAgICAgIGVudHJpZXMudW5zaGlmdChlbnRyeSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZW50cnkudmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBOT1RfRk9VTkQ7XG4gIH1cbiAgZnVuY3Rpb24gcHV0KGtleSwgdmFsdWUpIHtcbiAgICBlbnRyaWVzLnVuc2hpZnQoeyBrZXksIHZhbHVlIH0pO1xuICAgIGlmIChlbnRyaWVzLmxlbmd0aCA+IG1heFNpemUpIHtcbiAgICAgIGVudHJpZXMucG9wKCk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGZpbmRNYXRjaGluZ0VudHJ5KHZhbHVlLCByZXN1bHRFcXVhbGl0eUNoZWNrKSB7XG4gICAgY29uc3QgY3VycmVudEVudHJpZXMgPSBlbnRyaWVzO1xuICAgIGNvbnN0IHsgbGVuZ3RoIH0gPSBjdXJyZW50RW50cmllcztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBlbnRyeSA9IGN1cnJlbnRFbnRyaWVzW2ldO1xuICAgICAgaWYgKHJlc3VsdEVxdWFsaXR5Q2hlY2soZW50cnkudmFsdWUsIHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gZW50cnk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cbiAgZnVuY3Rpb24gY2xlYXIoKSB7XG4gICAgZW50cmllcyA9IFtdO1xuICB9XG4gIHJldHVybiB7IGdldCwgcHV0LCBmaW5kTWF0Y2hpbmdFbnRyeSwgY2xlYXIgfTtcbn1cbnZhciByZWZlcmVuY2VFcXVhbGl0eUNoZWNrID0gKGEsIGIpID0+IGEgPT09IGI7XG5mdW5jdGlvbiBjcmVhdGVDYWNoZUtleUNvbXBhcmF0b3IoZXF1YWxpdHlDaGVjaykge1xuICByZXR1cm4gZnVuY3Rpb24gYXJlQXJndW1lbnRzU2hhbGxvd2x5RXF1YWwocHJldiwgbmV4dCkge1xuICAgIGlmIChwcmV2ID09PSBudWxsIHx8IG5leHQgPT09IG51bGwgfHwgcHJldi5sZW5ndGggIT09IG5leHQubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHsgbGVuZ3RoIH0gPSBwcmV2O1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmICghZXF1YWxpdHlDaGVjayhwcmV2W2ldLCBuZXh0W2ldKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9O1xufVxuZnVuY3Rpb24gbHJ1TWVtb2l6ZShmdW5jLCBlcXVhbGl0eUNoZWNrT3JPcHRpb25zKSB7XG4gIGNvbnN0IHByb3ZpZGVkT3B0aW9ucyA9IHR5cGVvZiBlcXVhbGl0eUNoZWNrT3JPcHRpb25zID09PSBcIm9iamVjdFwiID8gZXF1YWxpdHlDaGVja09yT3B0aW9ucyA6IHsgZXF1YWxpdHlDaGVjazogZXF1YWxpdHlDaGVja09yT3B0aW9ucyB9O1xuICBjb25zdCB7XG4gICAgZXF1YWxpdHlDaGVjayA9IHJlZmVyZW5jZUVxdWFsaXR5Q2hlY2ssXG4gICAgbWF4U2l6ZSA9IDEsXG4gICAgcmVzdWx0RXF1YWxpdHlDaGVja1xuICB9ID0gcHJvdmlkZWRPcHRpb25zO1xuICBjb25zdCBjb21wYXJhdG9yID0gY3JlYXRlQ2FjaGVLZXlDb21wYXJhdG9yKGVxdWFsaXR5Q2hlY2spO1xuICBsZXQgcmVzdWx0c0NvdW50ID0gMDtcbiAgY29uc3QgY2FjaGUgPSBtYXhTaXplIDw9IDEgPyBjcmVhdGVTaW5nbGV0b25DYWNoZShjb21wYXJhdG9yKSA6IGNyZWF0ZUxydUNhY2hlKG1heFNpemUsIGNvbXBhcmF0b3IpO1xuICBmdW5jdGlvbiBtZW1vaXplZCgpIHtcbiAgICBsZXQgdmFsdWUgPSBjYWNoZS5nZXQoYXJndW1lbnRzKTtcbiAgICBpZiAodmFsdWUgPT09IE5PVF9GT1VORCkge1xuICAgICAgdmFsdWUgPSBmdW5jLmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG4gICAgICByZXN1bHRzQ291bnQrKztcbiAgICAgIGlmIChyZXN1bHRFcXVhbGl0eUNoZWNrKSB7XG4gICAgICAgIGNvbnN0IG1hdGNoaW5nRW50cnkgPSBjYWNoZS5maW5kTWF0Y2hpbmdFbnRyeShcbiAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICByZXN1bHRFcXVhbGl0eUNoZWNrXG4gICAgICAgICk7XG4gICAgICAgIGlmIChtYXRjaGluZ0VudHJ5KSB7XG4gICAgICAgICAgdmFsdWUgPSBtYXRjaGluZ0VudHJ5LnZhbHVlO1xuICAgICAgICAgIHJlc3VsdHNDb3VudCAhPT0gMCAmJiByZXN1bHRzQ291bnQtLTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY2FjaGUucHV0KGFyZ3VtZW50cywgdmFsdWUpO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgbWVtb2l6ZWQuY2xlYXJDYWNoZSA9ICgpID0+IHtcbiAgICBjYWNoZS5jbGVhcigpO1xuICAgIG1lbW9pemVkLnJlc2V0UmVzdWx0c0NvdW50KCk7XG4gIH07XG4gIG1lbW9pemVkLnJlc3VsdHNDb3VudCA9ICgpID0+IHJlc3VsdHNDb3VudDtcbiAgbWVtb2l6ZWQucmVzZXRSZXN1bHRzQ291bnQgPSAoKSA9PiB7XG4gICAgcmVzdWx0c0NvdW50ID0gMDtcbiAgfTtcbiAgcmV0dXJuIG1lbW9pemVkO1xufVxuZXhwb3J0IHtcbiAgY3JlYXRlU2VsZWN0b3IsXG4gIGNyZWF0ZVNlbGVjdG9yQ3JlYXRvcixcbiAgY3JlYXRlU3RydWN0dXJlZFNlbGVjdG9yLFxuICBscnVNZW1vaXplLFxuICByZWZlcmVuY2VFcXVhbGl0eUNoZWNrLFxuICBzZXRHbG9iYWxEZXZNb2RlQ2hlY2tzLFxuICB3ZWFrTWFwTWVtb2l6ZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlc2VsZWN0Lm1qcy5tYXAiLCIvLyBzcmMvdXRpbHMvZm9ybWF0UHJvZEVycm9yTWVzc2FnZS50c1xuZnVuY3Rpb24gZm9ybWF0UHJvZEVycm9yTWVzc2FnZShjb2RlKSB7XG4gIHJldHVybiBgTWluaWZpZWQgUmVkdXggZXJyb3IgIyR7Y29kZX07IHZpc2l0IGh0dHBzOi8vcmVkdXguanMub3JnL0Vycm9ycz9jb2RlPSR7Y29kZX0gZm9yIHRoZSBmdWxsIG1lc3NhZ2Ugb3IgdXNlIHRoZSBub24tbWluaWZpZWQgZGV2IGVudmlyb25tZW50IGZvciBmdWxsIGVycm9ycy4gYDtcbn1cblxuLy8gc3JjL3V0aWxzL3N5bWJvbC1vYnNlcnZhYmxlLnRzXG52YXIgJCRvYnNlcnZhYmxlID0gLyogQF9fUFVSRV9fICovICgoKSA9PiB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgU3ltYm9sLm9ic2VydmFibGUgfHwgXCJAQG9ic2VydmFibGVcIikoKTtcbnZhciBzeW1ib2xfb2JzZXJ2YWJsZV9kZWZhdWx0ID0gJCRvYnNlcnZhYmxlO1xuXG4vLyBzcmMvdXRpbHMvYWN0aW9uVHlwZXMudHNcbnZhciByYW5kb21TdHJpbmcgPSAoKSA9PiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoNykuc3BsaXQoXCJcIikuam9pbihcIi5cIik7XG52YXIgQWN0aW9uVHlwZXMgPSB7XG4gIElOSVQ6IGBAQHJlZHV4L0lOSVQkey8qIEBfX1BVUkVfXyAqLyByYW5kb21TdHJpbmcoKX1gLFxuICBSRVBMQUNFOiBgQEByZWR1eC9SRVBMQUNFJHsvKiBAX19QVVJFX18gKi8gcmFuZG9tU3RyaW5nKCl9YCxcbiAgUFJPQkVfVU5LTk9XTl9BQ1RJT046ICgpID0+IGBAQHJlZHV4L1BST0JFX1VOS05PV05fQUNUSU9OJHtyYW5kb21TdHJpbmcoKX1gXG59O1xudmFyIGFjdGlvblR5cGVzX2RlZmF1bHQgPSBBY3Rpb25UeXBlcztcblxuLy8gc3JjL3V0aWxzL2lzUGxhaW5PYmplY3QudHNcbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qob2JqKSB7XG4gIGlmICh0eXBlb2Ygb2JqICE9PSBcIm9iamVjdFwiIHx8IG9iaiA9PT0gbnVsbClcbiAgICByZXR1cm4gZmFsc2U7XG4gIGxldCBwcm90byA9IG9iajtcbiAgd2hpbGUgKE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90bykgIT09IG51bGwpIHtcbiAgICBwcm90byA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90byk7XG4gIH1cbiAgcmV0dXJuIE9iamVjdC5nZXRQcm90b3R5cGVPZihvYmopID09PSBwcm90byB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2Yob2JqKSA9PT0gbnVsbDtcbn1cblxuLy8gc3JjL3V0aWxzL2tpbmRPZi50c1xuZnVuY3Rpb24gbWluaUtpbmRPZih2YWwpIHtcbiAgaWYgKHZhbCA9PT0gdm9pZCAwKVxuICAgIHJldHVybiBcInVuZGVmaW5lZFwiO1xuICBpZiAodmFsID09PSBudWxsKVxuICAgIHJldHVybiBcIm51bGxcIjtcbiAgY29uc3QgdHlwZSA9IHR5cGVvZiB2YWw7XG4gIHN3aXRjaCAodHlwZSkge1xuICAgIGNhc2UgXCJib29sZWFuXCI6XG4gICAgY2FzZSBcInN0cmluZ1wiOlxuICAgIGNhc2UgXCJudW1iZXJcIjpcbiAgICBjYXNlIFwic3ltYm9sXCI6XG4gICAgY2FzZSBcImZ1bmN0aW9uXCI6IHtcbiAgICAgIHJldHVybiB0eXBlO1xuICAgIH1cbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWwpKVxuICAgIHJldHVybiBcImFycmF5XCI7XG4gIGlmIChpc0RhdGUodmFsKSlcbiAgICByZXR1cm4gXCJkYXRlXCI7XG4gIGlmIChpc0Vycm9yKHZhbCkpXG4gICAgcmV0dXJuIFwiZXJyb3JcIjtcbiAgY29uc3QgY29uc3RydWN0b3JOYW1lID0gY3Rvck5hbWUodmFsKTtcbiAgc3dpdGNoIChjb25zdHJ1Y3Rvck5hbWUpIHtcbiAgICBjYXNlIFwiU3ltYm9sXCI6XG4gICAgY2FzZSBcIlByb21pc2VcIjpcbiAgICBjYXNlIFwiV2Vha01hcFwiOlxuICAgIGNhc2UgXCJXZWFrU2V0XCI6XG4gICAgY2FzZSBcIk1hcFwiOlxuICAgIGNhc2UgXCJTZXRcIjpcbiAgICAgIHJldHVybiBjb25zdHJ1Y3Rvck5hbWU7XG4gIH1cbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpLnNsaWNlKDgsIC0xKS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1xccy9nLCBcIlwiKTtcbn1cbmZ1bmN0aW9uIGN0b3JOYW1lKHZhbCkge1xuICByZXR1cm4gdHlwZW9mIHZhbC5jb25zdHJ1Y3RvciA9PT0gXCJmdW5jdGlvblwiID8gdmFsLmNvbnN0cnVjdG9yLm5hbWUgOiBudWxsO1xufVxuZnVuY3Rpb24gaXNFcnJvcih2YWwpIHtcbiAgcmV0dXJuIHZhbCBpbnN0YW5jZW9mIEVycm9yIHx8IHR5cGVvZiB2YWwubWVzc2FnZSA9PT0gXCJzdHJpbmdcIiAmJiB2YWwuY29uc3RydWN0b3IgJiYgdHlwZW9mIHZhbC5jb25zdHJ1Y3Rvci5zdGFja1RyYWNlTGltaXQgPT09IFwibnVtYmVyXCI7XG59XG5mdW5jdGlvbiBpc0RhdGUodmFsKSB7XG4gIGlmICh2YWwgaW5zdGFuY2VvZiBEYXRlKVxuICAgIHJldHVybiB0cnVlO1xuICByZXR1cm4gdHlwZW9mIHZhbC50b0RhdGVTdHJpbmcgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgdmFsLmdldERhdGUgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgdmFsLnNldERhdGUgPT09IFwiZnVuY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGtpbmRPZih2YWwpIHtcbiAgbGV0IHR5cGVPZlZhbCA9IHR5cGVvZiB2YWw7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICB0eXBlT2ZWYWwgPSBtaW5pS2luZE9mKHZhbCk7XG4gIH1cbiAgcmV0dXJuIHR5cGVPZlZhbDtcbn1cblxuLy8gc3JjL2NyZWF0ZVN0b3JlLnRzXG5mdW5jdGlvbiBjcmVhdGVTdG9yZShyZWR1Y2VyLCBwcmVsb2FkZWRTdGF0ZSwgZW5oYW5jZXIpIHtcbiAgaWYgKHR5cGVvZiByZWR1Y2VyICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgyKSA6IGBFeHBlY3RlZCB0aGUgcm9vdCByZWR1Y2VyIHRvIGJlIGEgZnVuY3Rpb24uIEluc3RlYWQsIHJlY2VpdmVkOiAnJHtraW5kT2YocmVkdWNlcil9J2ApO1xuICB9XG4gIGlmICh0eXBlb2YgcHJlbG9hZGVkU3RhdGUgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgZW5oYW5jZXIgPT09IFwiZnVuY3Rpb25cIiB8fCB0eXBlb2YgZW5oYW5jZXIgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgYXJndW1lbnRzWzNdID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgwKSA6IFwiSXQgbG9va3MgbGlrZSB5b3UgYXJlIHBhc3Npbmcgc2V2ZXJhbCBzdG9yZSBlbmhhbmNlcnMgdG8gY3JlYXRlU3RvcmUoKS4gVGhpcyBpcyBub3Qgc3VwcG9ydGVkLiBJbnN0ZWFkLCBjb21wb3NlIHRoZW0gdG9nZXRoZXIgdG8gYSBzaW5nbGUgZnVuY3Rpb24uIFNlZSBodHRwczovL3JlZHV4LmpzLm9yZy90dXRvcmlhbHMvZnVuZGFtZW50YWxzL3BhcnQtNC1zdG9yZSNjcmVhdGluZy1hLXN0b3JlLXdpdGgtZW5oYW5jZXJzIGZvciBhbiBleGFtcGxlLlwiKTtcbiAgfVxuICBpZiAodHlwZW9mIHByZWxvYWRlZFN0YXRlID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIGVuaGFuY2VyID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgZW5oYW5jZXIgPSBwcmVsb2FkZWRTdGF0ZTtcbiAgICBwcmVsb2FkZWRTdGF0ZSA9IHZvaWQgMDtcbiAgfVxuICBpZiAodHlwZW9mIGVuaGFuY2VyICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgaWYgKHR5cGVvZiBlbmhhbmNlciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxKSA6IGBFeHBlY3RlZCB0aGUgZW5oYW5jZXIgdG8gYmUgYSBmdW5jdGlvbi4gSW5zdGVhZCwgcmVjZWl2ZWQ6ICcke2tpbmRPZihlbmhhbmNlcil9J2ApO1xuICAgIH1cbiAgICByZXR1cm4gZW5oYW5jZXIoY3JlYXRlU3RvcmUpKHJlZHVjZXIsIHByZWxvYWRlZFN0YXRlKTtcbiAgfVxuICBsZXQgY3VycmVudFJlZHVjZXIgPSByZWR1Y2VyO1xuICBsZXQgY3VycmVudFN0YXRlID0gcHJlbG9hZGVkU3RhdGU7XG4gIGxldCBjdXJyZW50TGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgbGV0IG5leHRMaXN0ZW5lcnMgPSBjdXJyZW50TGlzdGVuZXJzO1xuICBsZXQgbGlzdGVuZXJJZENvdW50ZXIgPSAwO1xuICBsZXQgaXNEaXNwYXRjaGluZyA9IGZhbHNlO1xuICBmdW5jdGlvbiBlbnN1cmVDYW5NdXRhdGVOZXh0TGlzdGVuZXJzKCkge1xuICAgIGlmIChuZXh0TGlzdGVuZXJzID09PSBjdXJyZW50TGlzdGVuZXJzKSB7XG4gICAgICBuZXh0TGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICAgIGN1cnJlbnRMaXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIsIGtleSkgPT4ge1xuICAgICAgICBuZXh0TGlzdGVuZXJzLnNldChrZXksIGxpc3RlbmVyKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBnZXRTdGF0ZSgpIHtcbiAgICBpZiAoaXNEaXNwYXRjaGluZykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMykgOiBcIllvdSBtYXkgbm90IGNhbGwgc3RvcmUuZ2V0U3RhdGUoKSB3aGlsZSB0aGUgcmVkdWNlciBpcyBleGVjdXRpbmcuIFRoZSByZWR1Y2VyIGhhcyBhbHJlYWR5IHJlY2VpdmVkIHRoZSBzdGF0ZSBhcyBhbiBhcmd1bWVudC4gUGFzcyBpdCBkb3duIGZyb20gdGhlIHRvcCByZWR1Y2VyIGluc3RlYWQgb2YgcmVhZGluZyBpdCBmcm9tIHRoZSBzdG9yZS5cIik7XG4gICAgfVxuICAgIHJldHVybiBjdXJyZW50U3RhdGU7XG4gIH1cbiAgZnVuY3Rpb24gc3Vic2NyaWJlKGxpc3RlbmVyKSB7XG4gICAgaWYgKHR5cGVvZiBsaXN0ZW5lciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg0KSA6IGBFeHBlY3RlZCB0aGUgbGlzdGVuZXIgdG8gYmUgYSBmdW5jdGlvbi4gSW5zdGVhZCwgcmVjZWl2ZWQ6ICcke2tpbmRPZihsaXN0ZW5lcil9J2ApO1xuICAgIH1cbiAgICBpZiAoaXNEaXNwYXRjaGluZykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoNSkgOiBcIllvdSBtYXkgbm90IGNhbGwgc3RvcmUuc3Vic2NyaWJlKCkgd2hpbGUgdGhlIHJlZHVjZXIgaXMgZXhlY3V0aW5nLiBJZiB5b3Ugd291bGQgbGlrZSB0byBiZSBub3RpZmllZCBhZnRlciB0aGUgc3RvcmUgaGFzIGJlZW4gdXBkYXRlZCwgc3Vic2NyaWJlIGZyb20gYSBjb21wb25lbnQgYW5kIGludm9rZSBzdG9yZS5nZXRTdGF0ZSgpIGluIHRoZSBjYWxsYmFjayB0byBhY2Nlc3MgdGhlIGxhdGVzdCBzdGF0ZS4gU2VlIGh0dHBzOi8vcmVkdXguanMub3JnL2FwaS9zdG9yZSNzdWJzY3JpYmVsaXN0ZW5lciBmb3IgbW9yZSBkZXRhaWxzLlwiKTtcbiAgICB9XG4gICAgbGV0IGlzU3Vic2NyaWJlZCA9IHRydWU7XG4gICAgZW5zdXJlQ2FuTXV0YXRlTmV4dExpc3RlbmVycygpO1xuICAgIGNvbnN0IGxpc3RlbmVySWQgPSBsaXN0ZW5lcklkQ291bnRlcisrO1xuICAgIG5leHRMaXN0ZW5lcnMuc2V0KGxpc3RlbmVySWQsIGxpc3RlbmVyKTtcbiAgICByZXR1cm4gZnVuY3Rpb24gdW5zdWJzY3JpYmUoKSB7XG4gICAgICBpZiAoIWlzU3Vic2NyaWJlZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoaXNEaXNwYXRjaGluZykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg2KSA6IFwiWW91IG1heSBub3QgdW5zdWJzY3JpYmUgZnJvbSBhIHN0b3JlIGxpc3RlbmVyIHdoaWxlIHRoZSByZWR1Y2VyIGlzIGV4ZWN1dGluZy4gU2VlIGh0dHBzOi8vcmVkdXguanMub3JnL2FwaS9zdG9yZSNzdWJzY3JpYmVsaXN0ZW5lciBmb3IgbW9yZSBkZXRhaWxzLlwiKTtcbiAgICAgIH1cbiAgICAgIGlzU3Vic2NyaWJlZCA9IGZhbHNlO1xuICAgICAgZW5zdXJlQ2FuTXV0YXRlTmV4dExpc3RlbmVycygpO1xuICAgICAgbmV4dExpc3RlbmVycy5kZWxldGUobGlzdGVuZXJJZCk7XG4gICAgICBjdXJyZW50TGlzdGVuZXJzID0gbnVsbDtcbiAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIGRpc3BhdGNoKGFjdGlvbikge1xuICAgIGlmICghaXNQbGFpbk9iamVjdChhY3Rpb24pKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg3KSA6IGBBY3Rpb25zIG11c3QgYmUgcGxhaW4gb2JqZWN0cy4gSW5zdGVhZCwgdGhlIGFjdHVhbCB0eXBlIHdhczogJyR7a2luZE9mKGFjdGlvbil9Jy4gWW91IG1heSBuZWVkIHRvIGFkZCBtaWRkbGV3YXJlIHRvIHlvdXIgc3RvcmUgc2V0dXAgdG8gaGFuZGxlIGRpc3BhdGNoaW5nIG90aGVyIHZhbHVlcywgc3VjaCBhcyAncmVkdXgtdGh1bmsnIHRvIGhhbmRsZSBkaXNwYXRjaGluZyBmdW5jdGlvbnMuIFNlZSBodHRwczovL3JlZHV4LmpzLm9yZy90dXRvcmlhbHMvZnVuZGFtZW50YWxzL3BhcnQtNC1zdG9yZSNtaWRkbGV3YXJlIGFuZCBodHRwczovL3JlZHV4LmpzLm9yZy90dXRvcmlhbHMvZnVuZGFtZW50YWxzL3BhcnQtNi1hc3luYy1sb2dpYyN1c2luZy10aGUtcmVkdXgtdGh1bmstbWlkZGxld2FyZSBmb3IgZXhhbXBsZXMuYCk7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgYWN0aW9uLnR5cGUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDgpIDogJ0FjdGlvbnMgbWF5IG5vdCBoYXZlIGFuIHVuZGVmaW5lZCBcInR5cGVcIiBwcm9wZXJ0eS4gWW91IG1heSBoYXZlIG1pc3NwZWxsZWQgYW4gYWN0aW9uIHR5cGUgc3RyaW5nIGNvbnN0YW50LicpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGFjdGlvbi50eXBlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxNykgOiBgQWN0aW9uIFwidHlwZVwiIHByb3BlcnR5IG11c3QgYmUgYSBzdHJpbmcuIEluc3RlYWQsIHRoZSBhY3R1YWwgdHlwZSB3YXM6ICcke2tpbmRPZihhY3Rpb24udHlwZSl9Jy4gVmFsdWUgd2FzOiAnJHthY3Rpb24udHlwZX0nIChzdHJpbmdpZmllZClgKTtcbiAgICB9XG4gICAgaWYgKGlzRGlzcGF0Y2hpbmcpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDkpIDogXCJSZWR1Y2VycyBtYXkgbm90IGRpc3BhdGNoIGFjdGlvbnMuXCIpO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgaXNEaXNwYXRjaGluZyA9IHRydWU7XG4gICAgICBjdXJyZW50U3RhdGUgPSBjdXJyZW50UmVkdWNlcihjdXJyZW50U3RhdGUsIGFjdGlvbik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGlzRGlzcGF0Y2hpbmcgPSBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgbGlzdGVuZXJzID0gY3VycmVudExpc3RlbmVycyA9IG5leHRMaXN0ZW5lcnM7XG4gICAgbGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG4gICAgICBsaXN0ZW5lcigpO1xuICAgIH0pO1xuICAgIHJldHVybiBhY3Rpb247XG4gIH1cbiAgZnVuY3Rpb24gcmVwbGFjZVJlZHVjZXIobmV4dFJlZHVjZXIpIHtcbiAgICBpZiAodHlwZW9mIG5leHRSZWR1Y2VyICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEwKSA6IGBFeHBlY3RlZCB0aGUgbmV4dFJlZHVjZXIgdG8gYmUgYSBmdW5jdGlvbi4gSW5zdGVhZCwgcmVjZWl2ZWQ6ICcke2tpbmRPZihuZXh0UmVkdWNlcil9YCk7XG4gICAgfVxuICAgIGN1cnJlbnRSZWR1Y2VyID0gbmV4dFJlZHVjZXI7XG4gICAgZGlzcGF0Y2goe1xuICAgICAgdHlwZTogYWN0aW9uVHlwZXNfZGVmYXVsdC5SRVBMQUNFXG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gb2JzZXJ2YWJsZSgpIHtcbiAgICBjb25zdCBvdXRlclN1YnNjcmliZSA9IHN1YnNjcmliZTtcbiAgICByZXR1cm4ge1xuICAgICAgLyoqXG4gICAgICAgKiBUaGUgbWluaW1hbCBvYnNlcnZhYmxlIHN1YnNjcmlwdGlvbiBtZXRob2QuXG4gICAgICAgKiBAcGFyYW0gb2JzZXJ2ZXIgQW55IG9iamVjdCB0aGF0IGNhbiBiZSB1c2VkIGFzIGFuIG9ic2VydmVyLlxuICAgICAgICogVGhlIG9ic2VydmVyIG9iamVjdCBzaG91bGQgaGF2ZSBhIGBuZXh0YCBtZXRob2QuXG4gICAgICAgKiBAcmV0dXJucyBBbiBvYmplY3Qgd2l0aCBhbiBgdW5zdWJzY3JpYmVgIG1ldGhvZCB0aGF0IGNhblxuICAgICAgICogYmUgdXNlZCB0byB1bnN1YnNjcmliZSB0aGUgb2JzZXJ2YWJsZSBmcm9tIHRoZSBzdG9yZSwgYW5kIHByZXZlbnQgZnVydGhlclxuICAgICAgICogZW1pc3Npb24gb2YgdmFsdWVzIGZyb20gdGhlIG9ic2VydmFibGUuXG4gICAgICAgKi9cbiAgICAgIHN1YnNjcmliZShvYnNlcnZlcikge1xuICAgICAgICBpZiAodHlwZW9mIG9ic2VydmVyICE9PSBcIm9iamVjdFwiIHx8IG9ic2VydmVyID09PSBudWxsKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTEpIDogYEV4cGVjdGVkIHRoZSBvYnNlcnZlciB0byBiZSBhbiBvYmplY3QuIEluc3RlYWQsIHJlY2VpdmVkOiAnJHtraW5kT2Yob2JzZXJ2ZXIpfSdgKTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBvYnNlcnZlU3RhdGUoKSB7XG4gICAgICAgICAgY29uc3Qgb2JzZXJ2ZXJBc09ic2VydmVyID0gb2JzZXJ2ZXI7XG4gICAgICAgICAgaWYgKG9ic2VydmVyQXNPYnNlcnZlci5uZXh0KSB7XG4gICAgICAgICAgICBvYnNlcnZlckFzT2JzZXJ2ZXIubmV4dChnZXRTdGF0ZSgpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgb2JzZXJ2ZVN0YXRlKCk7XG4gICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gb3V0ZXJTdWJzY3JpYmUob2JzZXJ2ZVN0YXRlKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB1bnN1YnNjcmliZVxuICAgICAgICB9O1xuICAgICAgfSxcbiAgICAgIFtzeW1ib2xfb2JzZXJ2YWJsZV9kZWZhdWx0XSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9XG4gICAgfTtcbiAgfVxuICBkaXNwYXRjaCh7XG4gICAgdHlwZTogYWN0aW9uVHlwZXNfZGVmYXVsdC5JTklUXG4gIH0pO1xuICBjb25zdCBzdG9yZSA9IHtcbiAgICBkaXNwYXRjaCxcbiAgICBzdWJzY3JpYmUsXG4gICAgZ2V0U3RhdGUsXG4gICAgcmVwbGFjZVJlZHVjZXIsXG4gICAgW3N5bWJvbF9vYnNlcnZhYmxlX2RlZmF1bHRdOiBvYnNlcnZhYmxlXG4gIH07XG4gIHJldHVybiBzdG9yZTtcbn1cbmZ1bmN0aW9uIGxlZ2FjeV9jcmVhdGVTdG9yZShyZWR1Y2VyLCBwcmVsb2FkZWRTdGF0ZSwgZW5oYW5jZXIpIHtcbiAgcmV0dXJuIGNyZWF0ZVN0b3JlKHJlZHVjZXIsIHByZWxvYWRlZFN0YXRlLCBlbmhhbmNlcik7XG59XG5cbi8vIHNyYy91dGlscy93YXJuaW5nLnRzXG5mdW5jdGlvbiB3YXJuaW5nKG1lc3NhZ2UpIHtcbiAgaWYgKHR5cGVvZiBjb25zb2xlICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiBjb25zb2xlLmVycm9yID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICBjb25zb2xlLmVycm9yKG1lc3NhZ2UpO1xuICB9XG4gIHRyeSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xuICB9IGNhdGNoIChlKSB7XG4gIH1cbn1cblxuLy8gc3JjL2NvbWJpbmVSZWR1Y2Vycy50c1xuZnVuY3Rpb24gZ2V0VW5leHBlY3RlZFN0YXRlU2hhcGVXYXJuaW5nTWVzc2FnZShpbnB1dFN0YXRlLCByZWR1Y2VycywgYWN0aW9uLCB1bmV4cGVjdGVkS2V5Q2FjaGUpIHtcbiAgY29uc3QgcmVkdWNlcktleXMgPSBPYmplY3Qua2V5cyhyZWR1Y2Vycyk7XG4gIGNvbnN0IGFyZ3VtZW50TmFtZSA9IGFjdGlvbiAmJiBhY3Rpb24udHlwZSA9PT0gYWN0aW9uVHlwZXNfZGVmYXVsdC5JTklUID8gXCJwcmVsb2FkZWRTdGF0ZSBhcmd1bWVudCBwYXNzZWQgdG8gY3JlYXRlU3RvcmVcIiA6IFwicHJldmlvdXMgc3RhdGUgcmVjZWl2ZWQgYnkgdGhlIHJlZHVjZXJcIjtcbiAgaWYgKHJlZHVjZXJLZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBcIlN0b3JlIGRvZXMgbm90IGhhdmUgYSB2YWxpZCByZWR1Y2VyLiBNYWtlIHN1cmUgdGhlIGFyZ3VtZW50IHBhc3NlZCB0byBjb21iaW5lUmVkdWNlcnMgaXMgYW4gb2JqZWN0IHdob3NlIHZhbHVlcyBhcmUgcmVkdWNlcnMuXCI7XG4gIH1cbiAgaWYgKCFpc1BsYWluT2JqZWN0KGlucHV0U3RhdGUpKSB7XG4gICAgcmV0dXJuIGBUaGUgJHthcmd1bWVudE5hbWV9IGhhcyB1bmV4cGVjdGVkIHR5cGUgb2YgXCIke2tpbmRPZihpbnB1dFN0YXRlKX1cIi4gRXhwZWN0ZWQgYXJndW1lbnQgdG8gYmUgYW4gb2JqZWN0IHdpdGggdGhlIGZvbGxvd2luZyBrZXlzOiBcIiR7cmVkdWNlcktleXMuam9pbignXCIsIFwiJyl9XCJgO1xuICB9XG4gIGNvbnN0IHVuZXhwZWN0ZWRLZXlzID0gT2JqZWN0LmtleXMoaW5wdXRTdGF0ZSkuZmlsdGVyKChrZXkpID0+ICFyZWR1Y2Vycy5oYXNPd25Qcm9wZXJ0eShrZXkpICYmICF1bmV4cGVjdGVkS2V5Q2FjaGVba2V5XSk7XG4gIHVuZXhwZWN0ZWRLZXlzLmZvckVhY2goKGtleSkgPT4ge1xuICAgIHVuZXhwZWN0ZWRLZXlDYWNoZVtrZXldID0gdHJ1ZTtcbiAgfSk7XG4gIGlmIChhY3Rpb24gJiYgYWN0aW9uLnR5cGUgPT09IGFjdGlvblR5cGVzX2RlZmF1bHQuUkVQTEFDRSlcbiAgICByZXR1cm47XG4gIGlmICh1bmV4cGVjdGVkS2V5cy5sZW5ndGggPiAwKSB7XG4gICAgcmV0dXJuIGBVbmV4cGVjdGVkICR7dW5leHBlY3RlZEtleXMubGVuZ3RoID4gMSA/IFwia2V5c1wiIDogXCJrZXlcIn0gXCIke3VuZXhwZWN0ZWRLZXlzLmpvaW4oJ1wiLCBcIicpfVwiIGZvdW5kIGluICR7YXJndW1lbnROYW1lfS4gRXhwZWN0ZWQgdG8gZmluZCBvbmUgb2YgdGhlIGtub3duIHJlZHVjZXIga2V5cyBpbnN0ZWFkOiBcIiR7cmVkdWNlcktleXMuam9pbignXCIsIFwiJyl9XCIuIFVuZXhwZWN0ZWQga2V5cyB3aWxsIGJlIGlnbm9yZWQuYDtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0UmVkdWNlclNoYXBlKHJlZHVjZXJzKSB7XG4gIE9iamVjdC5rZXlzKHJlZHVjZXJzKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICBjb25zdCByZWR1Y2VyID0gcmVkdWNlcnNba2V5XTtcbiAgICBjb25zdCBpbml0aWFsU3RhdGUgPSByZWR1Y2VyKHZvaWQgMCwge1xuICAgICAgdHlwZTogYWN0aW9uVHlwZXNfZGVmYXVsdC5JTklUXG4gICAgfSk7XG4gICAgaWYgKHR5cGVvZiBpbml0aWFsU3RhdGUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEyKSA6IGBUaGUgc2xpY2UgcmVkdWNlciBmb3Iga2V5IFwiJHtrZXl9XCIgcmV0dXJuZWQgdW5kZWZpbmVkIGR1cmluZyBpbml0aWFsaXphdGlvbi4gSWYgdGhlIHN0YXRlIHBhc3NlZCB0byB0aGUgcmVkdWNlciBpcyB1bmRlZmluZWQsIHlvdSBtdXN0IGV4cGxpY2l0bHkgcmV0dXJuIHRoZSBpbml0aWFsIHN0YXRlLiBUaGUgaW5pdGlhbCBzdGF0ZSBtYXkgbm90IGJlIHVuZGVmaW5lZC4gSWYgeW91IGRvbid0IHdhbnQgdG8gc2V0IGEgdmFsdWUgZm9yIHRoaXMgcmVkdWNlciwgeW91IGNhbiB1c2UgbnVsbCBpbnN0ZWFkIG9mIHVuZGVmaW5lZC5gKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiByZWR1Y2VyKHZvaWQgMCwge1xuICAgICAgdHlwZTogYWN0aW9uVHlwZXNfZGVmYXVsdC5QUk9CRV9VTktOT1dOX0FDVElPTigpXG4gICAgfSkgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEzKSA6IGBUaGUgc2xpY2UgcmVkdWNlciBmb3Iga2V5IFwiJHtrZXl9XCIgcmV0dXJuZWQgdW5kZWZpbmVkIHdoZW4gcHJvYmVkIHdpdGggYSByYW5kb20gdHlwZS4gRG9uJ3QgdHJ5IHRvIGhhbmRsZSAnJHthY3Rpb25UeXBlc19kZWZhdWx0LklOSVR9JyBvciBvdGhlciBhY3Rpb25zIGluIFwicmVkdXgvKlwiIG5hbWVzcGFjZS4gVGhleSBhcmUgY29uc2lkZXJlZCBwcml2YXRlLiBJbnN0ZWFkLCB5b3UgbXVzdCByZXR1cm4gdGhlIGN1cnJlbnQgc3RhdGUgZm9yIGFueSB1bmtub3duIGFjdGlvbnMsIHVubGVzcyBpdCBpcyB1bmRlZmluZWQsIGluIHdoaWNoIGNhc2UgeW91IG11c3QgcmV0dXJuIHRoZSBpbml0aWFsIHN0YXRlLCByZWdhcmRsZXNzIG9mIHRoZSBhY3Rpb24gdHlwZS4gVGhlIGluaXRpYWwgc3RhdGUgbWF5IG5vdCBiZSB1bmRlZmluZWQsIGJ1dCBjYW4gYmUgbnVsbC5gKTtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gY29tYmluZVJlZHVjZXJzKHJlZHVjZXJzKSB7XG4gIGNvbnN0IHJlZHVjZXJLZXlzID0gT2JqZWN0LmtleXMocmVkdWNlcnMpO1xuICBjb25zdCBmaW5hbFJlZHVjZXJzID0ge307XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcmVkdWNlcktleXMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBrZXkgPSByZWR1Y2VyS2V5c1tpXTtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBpZiAodHlwZW9mIHJlZHVjZXJzW2tleV0gPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgd2FybmluZyhgTm8gcmVkdWNlciBwcm92aWRlZCBmb3Iga2V5IFwiJHtrZXl9XCJgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHR5cGVvZiByZWR1Y2Vyc1trZXldID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIGZpbmFsUmVkdWNlcnNba2V5XSA9IHJlZHVjZXJzW2tleV07XG4gICAgfVxuICB9XG4gIGNvbnN0IGZpbmFsUmVkdWNlcktleXMgPSBPYmplY3Qua2V5cyhmaW5hbFJlZHVjZXJzKTtcbiAgbGV0IHVuZXhwZWN0ZWRLZXlDYWNoZTtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIHVuZXhwZWN0ZWRLZXlDYWNoZSA9IHt9O1xuICB9XG4gIGxldCBzaGFwZUFzc2VydGlvbkVycm9yO1xuICB0cnkge1xuICAgIGFzc2VydFJlZHVjZXJTaGFwZShmaW5hbFJlZHVjZXJzKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHNoYXBlQXNzZXJ0aW9uRXJyb3IgPSBlO1xuICB9XG4gIHJldHVybiBmdW5jdGlvbiBjb21iaW5hdGlvbihzdGF0ZSA9IHt9LCBhY3Rpb24pIHtcbiAgICBpZiAoc2hhcGVBc3NlcnRpb25FcnJvcikge1xuICAgICAgdGhyb3cgc2hhcGVBc3NlcnRpb25FcnJvcjtcbiAgICB9XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgY29uc3Qgd2FybmluZ01lc3NhZ2UgPSBnZXRVbmV4cGVjdGVkU3RhdGVTaGFwZVdhcm5pbmdNZXNzYWdlKHN0YXRlLCBmaW5hbFJlZHVjZXJzLCBhY3Rpb24sIHVuZXhwZWN0ZWRLZXlDYWNoZSk7XG4gICAgICBpZiAod2FybmluZ01lc3NhZ2UpIHtcbiAgICAgICAgd2FybmluZyh3YXJuaW5nTWVzc2FnZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGxldCBoYXNDaGFuZ2VkID0gZmFsc2U7XG4gICAgY29uc3QgbmV4dFN0YXRlID0ge307XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmaW5hbFJlZHVjZXJLZXlzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBrZXkgPSBmaW5hbFJlZHVjZXJLZXlzW2ldO1xuICAgICAgY29uc3QgcmVkdWNlciA9IGZpbmFsUmVkdWNlcnNba2V5XTtcbiAgICAgIGNvbnN0IHByZXZpb3VzU3RhdGVGb3JLZXkgPSBzdGF0ZVtrZXldO1xuICAgICAgY29uc3QgbmV4dFN0YXRlRm9yS2V5ID0gcmVkdWNlcihwcmV2aW91c1N0YXRlRm9yS2V5LCBhY3Rpb24pO1xuICAgICAgaWYgKHR5cGVvZiBuZXh0U3RhdGVGb3JLZXkgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgY29uc3QgYWN0aW9uVHlwZSA9IGFjdGlvbiAmJiBhY3Rpb24udHlwZTtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTQpIDogYFdoZW4gY2FsbGVkIHdpdGggYW4gYWN0aW9uIG9mIHR5cGUgJHthY3Rpb25UeXBlID8gYFwiJHtTdHJpbmcoYWN0aW9uVHlwZSl9XCJgIDogXCIodW5rbm93biB0eXBlKVwifSwgdGhlIHNsaWNlIHJlZHVjZXIgZm9yIGtleSBcIiR7a2V5fVwiIHJldHVybmVkIHVuZGVmaW5lZC4gVG8gaWdub3JlIGFuIGFjdGlvbiwgeW91IG11c3QgZXhwbGljaXRseSByZXR1cm4gdGhlIHByZXZpb3VzIHN0YXRlLiBJZiB5b3Ugd2FudCB0aGlzIHJlZHVjZXIgdG8gaG9sZCBubyB2YWx1ZSwgeW91IGNhbiByZXR1cm4gbnVsbCBpbnN0ZWFkIG9mIHVuZGVmaW5lZC5gKTtcbiAgICAgIH1cbiAgICAgIG5leHRTdGF0ZVtrZXldID0gbmV4dFN0YXRlRm9yS2V5O1xuICAgICAgaGFzQ2hhbmdlZCA9IGhhc0NoYW5nZWQgfHwgbmV4dFN0YXRlRm9yS2V5ICE9PSBwcmV2aW91c1N0YXRlRm9yS2V5O1xuICAgIH1cbiAgICBoYXNDaGFuZ2VkID0gaGFzQ2hhbmdlZCB8fCBmaW5hbFJlZHVjZXJLZXlzLmxlbmd0aCAhPT0gT2JqZWN0LmtleXMoc3RhdGUpLmxlbmd0aDtcbiAgICByZXR1cm4gaGFzQ2hhbmdlZCA/IG5leHRTdGF0ZSA6IHN0YXRlO1xuICB9O1xufVxuXG4vLyBzcmMvYmluZEFjdGlvbkNyZWF0b3JzLnRzXG5mdW5jdGlvbiBiaW5kQWN0aW9uQ3JlYXRvcihhY3Rpb25DcmVhdG9yLCBkaXNwYXRjaCkge1xuICByZXR1cm4gZnVuY3Rpb24oLi4uYXJncykge1xuICAgIHJldHVybiBkaXNwYXRjaChhY3Rpb25DcmVhdG9yLmFwcGx5KHRoaXMsIGFyZ3MpKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIGJpbmRBY3Rpb25DcmVhdG9ycyhhY3Rpb25DcmVhdG9ycywgZGlzcGF0Y2gpIHtcbiAgaWYgKHR5cGVvZiBhY3Rpb25DcmVhdG9ycyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIGJpbmRBY3Rpb25DcmVhdG9yKGFjdGlvbkNyZWF0b3JzLCBkaXNwYXRjaCk7XG4gIH1cbiAgaWYgKHR5cGVvZiBhY3Rpb25DcmVhdG9ycyAhPT0gXCJvYmplY3RcIiB8fCBhY3Rpb25DcmVhdG9ycyA9PT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDE2KSA6IGBiaW5kQWN0aW9uQ3JlYXRvcnMgZXhwZWN0ZWQgYW4gb2JqZWN0IG9yIGEgZnVuY3Rpb24sIGJ1dCBpbnN0ZWFkIHJlY2VpdmVkOiAnJHtraW5kT2YoYWN0aW9uQ3JlYXRvcnMpfScuIERpZCB5b3Ugd3JpdGUgXCJpbXBvcnQgQWN0aW9uQ3JlYXRvcnMgZnJvbVwiIGluc3RlYWQgb2YgXCJpbXBvcnQgKiBhcyBBY3Rpb25DcmVhdG9ycyBmcm9tXCI/YCk7XG4gIH1cbiAgY29uc3QgYm91bmRBY3Rpb25DcmVhdG9ycyA9IHt9O1xuICBmb3IgKGNvbnN0IGtleSBpbiBhY3Rpb25DcmVhdG9ycykge1xuICAgIGNvbnN0IGFjdGlvbkNyZWF0b3IgPSBhY3Rpb25DcmVhdG9yc1trZXldO1xuICAgIGlmICh0eXBlb2YgYWN0aW9uQ3JlYXRvciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICBib3VuZEFjdGlvbkNyZWF0b3JzW2tleV0gPSBiaW5kQWN0aW9uQ3JlYXRvcihhY3Rpb25DcmVhdG9yLCBkaXNwYXRjaCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBib3VuZEFjdGlvbkNyZWF0b3JzO1xufVxuXG4vLyBzcmMvY29tcG9zZS50c1xuZnVuY3Rpb24gY29tcG9zZSguLi5mdW5jcykge1xuICBpZiAoZnVuY3MubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIChhcmcpID0+IGFyZztcbiAgfVxuICBpZiAoZnVuY3MubGVuZ3RoID09PSAxKSB7XG4gICAgcmV0dXJuIGZ1bmNzWzBdO1xuICB9XG4gIHJldHVybiBmdW5jcy5yZWR1Y2UoKGEsIGIpID0+ICguLi5hcmdzKSA9PiBhKGIoLi4uYXJncykpKTtcbn1cblxuLy8gc3JjL2FwcGx5TWlkZGxld2FyZS50c1xuZnVuY3Rpb24gYXBwbHlNaWRkbGV3YXJlKC4uLm1pZGRsZXdhcmVzKSB7XG4gIHJldHVybiAoY3JlYXRlU3RvcmUyKSA9PiAocmVkdWNlciwgcHJlbG9hZGVkU3RhdGUpID0+IHtcbiAgICBjb25zdCBzdG9yZSA9IGNyZWF0ZVN0b3JlMihyZWR1Y2VyLCBwcmVsb2FkZWRTdGF0ZSk7XG4gICAgbGV0IGRpc3BhdGNoID0gKCkgPT4ge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTUpIDogXCJEaXNwYXRjaGluZyB3aGlsZSBjb25zdHJ1Y3RpbmcgeW91ciBtaWRkbGV3YXJlIGlzIG5vdCBhbGxvd2VkLiBPdGhlciBtaWRkbGV3YXJlIHdvdWxkIG5vdCBiZSBhcHBsaWVkIHRvIHRoaXMgZGlzcGF0Y2guXCIpO1xuICAgIH07XG4gICAgY29uc3QgbWlkZGxld2FyZUFQSSA9IHtcbiAgICAgIGdldFN0YXRlOiBzdG9yZS5nZXRTdGF0ZSxcbiAgICAgIGRpc3BhdGNoOiAoYWN0aW9uLCAuLi5hcmdzKSA9PiBkaXNwYXRjaChhY3Rpb24sIC4uLmFyZ3MpXG4gICAgfTtcbiAgICBjb25zdCBjaGFpbiA9IG1pZGRsZXdhcmVzLm1hcCgobWlkZGxld2FyZSkgPT4gbWlkZGxld2FyZShtaWRkbGV3YXJlQVBJKSk7XG4gICAgZGlzcGF0Y2ggPSBjb21wb3NlKC4uLmNoYWluKShzdG9yZS5kaXNwYXRjaCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLnN0b3JlLFxuICAgICAgZGlzcGF0Y2hcbiAgICB9O1xuICB9O1xufVxuXG4vLyBzcmMvdXRpbHMvaXNBY3Rpb24udHNcbmZ1bmN0aW9uIGlzQWN0aW9uKGFjdGlvbikge1xuICByZXR1cm4gaXNQbGFpbk9iamVjdChhY3Rpb24pICYmIFwidHlwZVwiIGluIGFjdGlvbiAmJiB0eXBlb2YgYWN0aW9uLnR5cGUgPT09IFwic3RyaW5nXCI7XG59XG5leHBvcnQge1xuICBhY3Rpb25UeXBlc19kZWZhdWx0IGFzIF9fRE9fTk9UX1VTRV9fQWN0aW9uVHlwZXMsXG4gIGFwcGx5TWlkZGxld2FyZSxcbiAgYmluZEFjdGlvbkNyZWF0b3JzLFxuICBjb21iaW5lUmVkdWNlcnMsXG4gIGNvbXBvc2UsXG4gIGNyZWF0ZVN0b3JlLFxuICBpc0FjdGlvbixcbiAgaXNQbGFpbk9iamVjdCxcbiAgbGVnYWN5X2NyZWF0ZVN0b3JlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVkdXgubWpzLm1hcCIsIi8vIHNyYy91dGlscy9lbnYudHNcbnZhciBOT1RISU5HID0gU3ltYm9sLmZvcihcImltbWVyLW5vdGhpbmdcIik7XG52YXIgRFJBRlRBQkxFID0gU3ltYm9sLmZvcihcImltbWVyLWRyYWZ0YWJsZVwiKTtcbnZhciBEUkFGVF9TVEFURSA9IFN5bWJvbC5mb3IoXCJpbW1lci1zdGF0ZVwiKTtcblxuLy8gc3JjL3V0aWxzL2Vycm9ycy50c1xudmFyIGVycm9ycyA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFtcbiAgLy8gQWxsIGVycm9yIGNvZGVzLCBzdGFydGluZyBieSAwOlxuICBmdW5jdGlvbihwbHVnaW4pIHtcbiAgICByZXR1cm4gYFRoZSBwbHVnaW4gZm9yICcke3BsdWdpbn0nIGhhcyBub3QgYmVlbiBsb2FkZWQgaW50byBJbW1lci4gVG8gZW5hYmxlIHRoZSBwbHVnaW4sIGltcG9ydCBhbmQgY2FsbCBcXGBlbmFibGUke3BsdWdpbn0oKVxcYCB3aGVuIGluaXRpYWxpemluZyB5b3VyIGFwcGxpY2F0aW9uLmA7XG4gIH0sXG4gIGZ1bmN0aW9uKHRoaW5nKSB7XG4gICAgcmV0dXJuIGBwcm9kdWNlIGNhbiBvbmx5IGJlIGNhbGxlZCBvbiB0aGluZ3MgdGhhdCBhcmUgZHJhZnRhYmxlOiBwbGFpbiBvYmplY3RzLCBhcnJheXMsIE1hcCwgU2V0IG9yIGNsYXNzZXMgdGhhdCBhcmUgbWFya2VkIHdpdGggJ1tpbW1lcmFibGVdOiB0cnVlJy4gR290ICcke3RoaW5nfSdgO1xuICB9LFxuICBcIlRoaXMgb2JqZWN0IGhhcyBiZWVuIGZyb3plbiBhbmQgc2hvdWxkIG5vdCBiZSBtdXRhdGVkXCIsXG4gIGZ1bmN0aW9uKGRhdGEpIHtcbiAgICByZXR1cm4gXCJDYW5ub3QgdXNlIGEgcHJveHkgdGhhdCBoYXMgYmVlbiByZXZva2VkLiBEaWQgeW91IHBhc3MgYW4gb2JqZWN0IGZyb20gaW5zaWRlIGFuIGltbWVyIGZ1bmN0aW9uIHRvIGFuIGFzeW5jIHByb2Nlc3M/IFwiICsgZGF0YTtcbiAgfSxcbiAgXCJBbiBpbW1lciBwcm9kdWNlciByZXR1cm5lZCBhIG5ldyB2YWx1ZSAqYW5kKiBtb2RpZmllZCBpdHMgZHJhZnQuIEVpdGhlciByZXR1cm4gYSBuZXcgdmFsdWUgKm9yKiBtb2RpZnkgdGhlIGRyYWZ0LlwiLFxuICBcIkltbWVyIGZvcmJpZHMgY2lyY3VsYXIgcmVmZXJlbmNlc1wiLFxuICBcIlRoZSBmaXJzdCBvciBzZWNvbmQgYXJndW1lbnQgdG8gYHByb2R1Y2VgIG11c3QgYmUgYSBmdW5jdGlvblwiLFxuICBcIlRoZSB0aGlyZCBhcmd1bWVudCB0byBgcHJvZHVjZWAgbXVzdCBiZSBhIGZ1bmN0aW9uIG9yIHVuZGVmaW5lZFwiLFxuICBcIkZpcnN0IGFyZ3VtZW50IHRvIGBjcmVhdGVEcmFmdGAgbXVzdCBiZSBhIHBsYWluIG9iamVjdCwgYW4gYXJyYXksIG9yIGFuIGltbWVyYWJsZSBvYmplY3RcIixcbiAgXCJGaXJzdCBhcmd1bWVudCB0byBgZmluaXNoRHJhZnRgIG11c3QgYmUgYSBkcmFmdCByZXR1cm5lZCBieSBgY3JlYXRlRHJhZnRgXCIsXG4gIGZ1bmN0aW9uKHRoaW5nKSB7XG4gICAgcmV0dXJuIGAnY3VycmVudCcgZXhwZWN0cyBhIGRyYWZ0LCBnb3Q6ICR7dGhpbmd9YDtcbiAgfSxcbiAgXCJPYmplY3QuZGVmaW5lUHJvcGVydHkoKSBjYW5ub3QgYmUgdXNlZCBvbiBhbiBJbW1lciBkcmFmdFwiLFxuICBcIk9iamVjdC5zZXRQcm90b3R5cGVPZigpIGNhbm5vdCBiZSB1c2VkIG9uIGFuIEltbWVyIGRyYWZ0XCIsXG4gIFwiSW1tZXIgb25seSBzdXBwb3J0cyBkZWxldGluZyBhcnJheSBpbmRpY2VzXCIsXG4gIFwiSW1tZXIgb25seSBzdXBwb3J0cyBzZXR0aW5nIGFycmF5IGluZGljZXMgYW5kIHRoZSAnbGVuZ3RoJyBwcm9wZXJ0eVwiLFxuICBmdW5jdGlvbih0aGluZykge1xuICAgIHJldHVybiBgJ29yaWdpbmFsJyBleHBlY3RzIGEgZHJhZnQsIGdvdDogJHt0aGluZ31gO1xuICB9XG4gIC8vIE5vdGU6IGlmIG1vcmUgZXJyb3JzIGFyZSBhZGRlZCwgdGhlIGVycm9yT2Zmc2V0IGluIFBhdGNoZXMudHMgc2hvdWxkIGJlIGluY3JlYXNlZFxuICAvLyBTZWUgUGF0Y2hlcy50cyBmb3IgYWRkaXRpb25hbCBlcnJvcnNcbl0gOiBbXTtcbmZ1bmN0aW9uIGRpZShlcnJvciwgLi4uYXJncykge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgY29uc3QgZSA9IGVycm9yc1tlcnJvcl07XG4gICAgY29uc3QgbXNnID0gaXNGdW5jdGlvbihlKSA/IGUuYXBwbHkobnVsbCwgYXJncykgOiBlO1xuICAgIHRocm93IG5ldyBFcnJvcihgW0ltbWVyXSAke21zZ31gKTtcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgYFtJbW1lcl0gbWluaWZpZWQgZXJyb3IgbnI6ICR7ZXJyb3J9LiBGdWxsIGVycm9yIGF0OiBodHRwczovL2JpdC5seS8zY1hFS1dmYFxuICApO1xufVxuXG4vLyBzcmMvdXRpbHMvY29tbW9uLnRzXG52YXIgTyA9IE9iamVjdDtcbnZhciBnZXRQcm90b3R5cGVPZiA9IE8uZ2V0UHJvdG90eXBlT2Y7XG52YXIgQ09OU1RSVUNUT1IgPSBcImNvbnN0cnVjdG9yXCI7XG52YXIgUFJPVE9UWVBFID0gXCJwcm90b3R5cGVcIjtcbnZhciBDT05GSUdVUkFCTEUgPSBcImNvbmZpZ3VyYWJsZVwiO1xudmFyIEVOVU1FUkFCTEUgPSBcImVudW1lcmFibGVcIjtcbnZhciBXUklUQUJMRSA9IFwid3JpdGFibGVcIjtcbnZhciBWQUxVRSA9IFwidmFsdWVcIjtcbnZhciBpc0RyYWZ0ID0gKHZhbHVlKSA9PiAhIXZhbHVlICYmICEhdmFsdWVbRFJBRlRfU1RBVEVdO1xuZnVuY3Rpb24gaXNEcmFmdGFibGUodmFsdWUpIHtcbiAgaWYgKCF2YWx1ZSlcbiAgICByZXR1cm4gZmFsc2U7XG4gIHJldHVybiBpc1BsYWluT2JqZWN0KHZhbHVlKSB8fCBpc0FycmF5KHZhbHVlKSB8fCAhIXZhbHVlW0RSQUZUQUJMRV0gfHwgISF2YWx1ZVtDT05TVFJVQ1RPUl0/LltEUkFGVEFCTEVdIHx8IGlzTWFwKHZhbHVlKSB8fCBpc1NldCh2YWx1ZSk7XG59XG52YXIgb2JqZWN0Q3RvclN0cmluZyA9IE9bUFJPVE9UWVBFXVtDT05TVFJVQ1RPUl0udG9TdHJpbmcoKTtcbnZhciBjYWNoZWRDdG9yU3RyaW5ncyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuZnVuY3Rpb24gaXNQbGFpbk9iamVjdCh2YWx1ZSkge1xuICBpZiAoIXZhbHVlIHx8ICFpc09iamVjdGlzaCh2YWx1ZSkpXG4gICAgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBwcm90byA9IGdldFByb3RvdHlwZU9mKHZhbHVlKTtcbiAgaWYgKHByb3RvID09PSBudWxsIHx8IHByb3RvID09PSBPW1BST1RPVFlQRV0pXG4gICAgcmV0dXJuIHRydWU7XG4gIGNvbnN0IEN0b3IgPSBPLmhhc093blByb3BlcnR5LmNhbGwocHJvdG8sIENPTlNUUlVDVE9SKSAmJiBwcm90b1tDT05TVFJVQ1RPUl07XG4gIGlmIChDdG9yID09PSBPYmplY3QpXG4gICAgcmV0dXJuIHRydWU7XG4gIGlmICghaXNGdW5jdGlvbihDdG9yKSlcbiAgICByZXR1cm4gZmFsc2U7XG4gIGxldCBjdG9yU3RyaW5nID0gY2FjaGVkQ3RvclN0cmluZ3MuZ2V0KEN0b3IpO1xuICBpZiAoY3RvclN0cmluZyA9PT0gdm9pZCAwKSB7XG4gICAgY3RvclN0cmluZyA9IEZ1bmN0aW9uLnRvU3RyaW5nLmNhbGwoQ3Rvcik7XG4gICAgY2FjaGVkQ3RvclN0cmluZ3Muc2V0KEN0b3IsIGN0b3JTdHJpbmcpO1xuICB9XG4gIHJldHVybiBjdG9yU3RyaW5nID09PSBvYmplY3RDdG9yU3RyaW5nO1xufVxuZnVuY3Rpb24gb3JpZ2luYWwodmFsdWUpIHtcbiAgaWYgKCFpc0RyYWZ0KHZhbHVlKSlcbiAgICBkaWUoMTUsIHZhbHVlKTtcbiAgcmV0dXJuIHZhbHVlW0RSQUZUX1NUQVRFXS5iYXNlXztcbn1cbmZ1bmN0aW9uIGVhY2gob2JqLCBpdGVyLCBzdHJpY3QgPSB0cnVlKSB7XG4gIGlmIChnZXRBcmNodHlwZShvYmopID09PSAwIC8qIE9iamVjdCAqLykge1xuICAgIGNvbnN0IGtleXMgPSBzdHJpY3QgPyBSZWZsZWN0Lm93bktleXMob2JqKSA6IE8ua2V5cyhvYmopO1xuICAgIGtleXMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBpdGVyKGtleSwgb2JqW2tleV0sIG9iaik7XG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgb2JqLmZvckVhY2goKGVudHJ5LCBpbmRleCkgPT4gaXRlcihpbmRleCwgZW50cnksIG9iaikpO1xuICB9XG59XG5mdW5jdGlvbiBnZXRBcmNodHlwZSh0aGluZykge1xuICBjb25zdCBzdGF0ZSA9IHRoaW5nW0RSQUZUX1NUQVRFXTtcbiAgcmV0dXJuIHN0YXRlID8gc3RhdGUudHlwZV8gOiBpc0FycmF5KHRoaW5nKSA/IDEgLyogQXJyYXkgKi8gOiBpc01hcCh0aGluZykgPyAyIC8qIE1hcCAqLyA6IGlzU2V0KHRoaW5nKSA/IDMgLyogU2V0ICovIDogMCAvKiBPYmplY3QgKi87XG59XG52YXIgaGFzID0gKHRoaW5nLCBwcm9wLCB0eXBlID0gZ2V0QXJjaHR5cGUodGhpbmcpKSA9PiB0eXBlID09PSAyIC8qIE1hcCAqLyA/IHRoaW5nLmhhcyhwcm9wKSA6IE9bUFJPVE9UWVBFXS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHRoaW5nLCBwcm9wKTtcbnZhciBnZXQgPSAodGhpbmcsIHByb3AsIHR5cGUgPSBnZXRBcmNodHlwZSh0aGluZykpID0+IChcbiAgLy8gQHRzLWlnbm9yZVxuICB0eXBlID09PSAyIC8qIE1hcCAqLyA/IHRoaW5nLmdldChwcm9wKSA6IHRoaW5nW3Byb3BdXG4pO1xudmFyIHNldCA9ICh0aGluZywgcHJvcE9yT2xkVmFsdWUsIHZhbHVlLCB0eXBlID0gZ2V0QXJjaHR5cGUodGhpbmcpKSA9PiB7XG4gIGlmICh0eXBlID09PSAyIC8qIE1hcCAqLylcbiAgICB0aGluZy5zZXQocHJvcE9yT2xkVmFsdWUsIHZhbHVlKTtcbiAgZWxzZSBpZiAodHlwZSA9PT0gMyAvKiBTZXQgKi8pIHtcbiAgICB0aGluZy5hZGQodmFsdWUpO1xuICB9IGVsc2VcbiAgICB0aGluZ1twcm9wT3JPbGRWYWx1ZV0gPSB2YWx1ZTtcbn07XG5mdW5jdGlvbiBpcyh4LCB5KSB7XG4gIGlmICh4ID09PSB5KSB7XG4gICAgcmV0dXJuIHggIT09IDAgfHwgMSAvIHggPT09IDEgLyB5O1xuICB9IGVsc2Uge1xuICAgIHJldHVybiB4ICE9PSB4ICYmIHkgIT09IHk7XG4gIH1cbn1cbnZhciBpc0FycmF5ID0gQXJyYXkuaXNBcnJheTtcbnZhciBpc01hcCA9ICh0YXJnZXQpID0+IHRhcmdldCBpbnN0YW5jZW9mIE1hcDtcbnZhciBpc1NldCA9ICh0YXJnZXQpID0+IHRhcmdldCBpbnN0YW5jZW9mIFNldDtcbnZhciBpc09iamVjdGlzaCA9ICh0YXJnZXQpID0+IHR5cGVvZiB0YXJnZXQgPT09IFwib2JqZWN0XCI7XG52YXIgaXNGdW5jdGlvbiA9ICh0YXJnZXQpID0+IHR5cGVvZiB0YXJnZXQgPT09IFwiZnVuY3Rpb25cIjtcbnZhciBpc0Jvb2xlYW4gPSAodGFyZ2V0KSA9PiB0eXBlb2YgdGFyZ2V0ID09PSBcImJvb2xlYW5cIjtcbmZ1bmN0aW9uIGlzQXJyYXlJbmRleCh2YWx1ZSkge1xuICBjb25zdCBuID0gK3ZhbHVlO1xuICByZXR1cm4gTnVtYmVyLmlzSW50ZWdlcihuKSAmJiBTdHJpbmcobikgPT09IHZhbHVlO1xufVxudmFyIGdldFByb3h5RHJhZnQgPSAodmFsdWUpID0+IHtcbiAgaWYgKCFpc09iamVjdGlzaCh2YWx1ZSkpXG4gICAgcmV0dXJuIG51bGw7XG4gIHJldHVybiB2YWx1ZT8uW0RSQUZUX1NUQVRFXTtcbn07XG52YXIgbGF0ZXN0ID0gKHN0YXRlKSA9PiBzdGF0ZS5jb3B5XyB8fCBzdGF0ZS5iYXNlXztcbnZhciBnZXRWYWx1ZSA9ICh2YWx1ZSkgPT4ge1xuICBjb25zdCBwcm94eURyYWZ0ID0gZ2V0UHJveHlEcmFmdCh2YWx1ZSk7XG4gIHJldHVybiBwcm94eURyYWZ0ID8gZ2V0RmluYWxWYWx1ZShwcm94eURyYWZ0KSA6IHZhbHVlO1xufTtcbnZhciBnZXRGaW5hbFZhbHVlID0gKHN0YXRlKSA9PiBzdGF0ZS5tb2RpZmllZF8gPyBzdGF0ZS5jb3B5XyA6IHN0YXRlLmJhc2VfO1xuZnVuY3Rpb24gc2hhbGxvd0NvcHkoYmFzZSwgc3RyaWN0KSB7XG4gIGlmIChpc01hcChiYXNlKSkge1xuICAgIHJldHVybiBuZXcgTWFwKGJhc2UpO1xuICB9XG4gIGlmIChpc1NldChiYXNlKSkge1xuICAgIHJldHVybiBuZXcgU2V0KGJhc2UpO1xuICB9XG4gIGlmIChpc0FycmF5KGJhc2UpKVxuICAgIHJldHVybiBBcnJheVtQUk9UT1RZUEVdLnNsaWNlLmNhbGwoYmFzZSk7XG4gIGNvbnN0IGlzUGxhaW4gPSBpc1BsYWluT2JqZWN0KGJhc2UpO1xuICBpZiAoc3RyaWN0ID09PSB0cnVlIHx8IHN0cmljdCA9PT0gXCJjbGFzc19vbmx5XCIgJiYgIWlzUGxhaW4pIHtcbiAgICBjb25zdCBkZXNjcmlwdG9ycyA9IE8uZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhiYXNlKTtcbiAgICBkZWxldGUgZGVzY3JpcHRvcnNbRFJBRlRfU1RBVEVdO1xuICAgIGxldCBrZXlzID0gUmVmbGVjdC5vd25LZXlzKGRlc2NyaXB0b3JzKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGtleSA9IGtleXNbaV07XG4gICAgICBjb25zdCBkZXNjID0gZGVzY3JpcHRvcnNba2V5XTtcbiAgICAgIGlmIChkZXNjW1dSSVRBQkxFXSA9PT0gZmFsc2UpIHtcbiAgICAgICAgZGVzY1tXUklUQUJMRV0gPSB0cnVlO1xuICAgICAgICBkZXNjW0NPTkZJR1VSQUJMRV0gPSB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKGRlc2MuZ2V0IHx8IGRlc2Muc2V0KVxuICAgICAgICBkZXNjcmlwdG9yc1trZXldID0ge1xuICAgICAgICAgIFtDT05GSUdVUkFCTEVdOiB0cnVlLFxuICAgICAgICAgIFtXUklUQUJMRV06IHRydWUsXG4gICAgICAgICAgLy8gY291bGQgbGl2ZSB3aXRoICEhZGVzYy5zZXQgYXMgd2VsbCBoZXJlLi4uXG4gICAgICAgICAgW0VOVU1FUkFCTEVdOiBkZXNjW0VOVU1FUkFCTEVdLFxuICAgICAgICAgIFtWQUxVRV06IGJhc2Vba2V5XVxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gTy5jcmVhdGUoZ2V0UHJvdG90eXBlT2YoYmFzZSksIGRlc2NyaXB0b3JzKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBwcm90byA9IGdldFByb3RvdHlwZU9mKGJhc2UpO1xuICAgIGlmIChwcm90byAhPT0gbnVsbCAmJiBpc1BsYWluKSB7XG4gICAgICByZXR1cm4geyAuLi5iYXNlIH07XG4gICAgfVxuICAgIGNvbnN0IG9iaiA9IE8uY3JlYXRlKHByb3RvKTtcbiAgICByZXR1cm4gTy5hc3NpZ24ob2JqLCBiYXNlKTtcbiAgfVxufVxuZnVuY3Rpb24gZnJlZXplKG9iaiwgZGVlcCA9IGZhbHNlKSB7XG4gIGlmIChpc0Zyb3plbihvYmopIHx8IGlzRHJhZnQob2JqKSB8fCAhaXNEcmFmdGFibGUob2JqKSlcbiAgICByZXR1cm4gb2JqO1xuICBpZiAoZ2V0QXJjaHR5cGUob2JqKSA+IDEpIHtcbiAgICBPLmRlZmluZVByb3BlcnRpZXMob2JqLCB7XG4gICAgICBzZXQ6IGRvbnRNdXRhdGVNZXRob2RPdmVycmlkZSxcbiAgICAgIGFkZDogZG9udE11dGF0ZU1ldGhvZE92ZXJyaWRlLFxuICAgICAgY2xlYXI6IGRvbnRNdXRhdGVNZXRob2RPdmVycmlkZSxcbiAgICAgIGRlbGV0ZTogZG9udE11dGF0ZU1ldGhvZE92ZXJyaWRlXG4gICAgfSk7XG4gIH1cbiAgTy5mcmVlemUob2JqKTtcbiAgaWYgKGRlZXApXG4gICAgZWFjaChcbiAgICAgIG9iaixcbiAgICAgIChfa2V5LCB2YWx1ZSkgPT4ge1xuICAgICAgICBmcmVlemUodmFsdWUsIHRydWUpO1xuICAgICAgfSxcbiAgICAgIGZhbHNlXG4gICAgKTtcbiAgcmV0dXJuIG9iajtcbn1cbmZ1bmN0aW9uIGRvbnRNdXRhdGVGcm96ZW5Db2xsZWN0aW9ucygpIHtcbiAgZGllKDIpO1xufVxudmFyIGRvbnRNdXRhdGVNZXRob2RPdmVycmlkZSA9IHtcbiAgW1ZBTFVFXTogZG9udE11dGF0ZUZyb3plbkNvbGxlY3Rpb25zXG59O1xuZnVuY3Rpb24gaXNGcm96ZW4ob2JqKSB7XG4gIGlmIChvYmogPT09IG51bGwgfHwgIWlzT2JqZWN0aXNoKG9iaikpXG4gICAgcmV0dXJuIHRydWU7XG4gIHJldHVybiBPLmlzRnJvemVuKG9iaik7XG59XG5cbi8vIHNyYy91dGlscy9wbHVnaW5zLnRzXG52YXIgUGx1Z2luTWFwU2V0ID0gXCJNYXBTZXRcIjtcbnZhciBQbHVnaW5QYXRjaGVzID0gXCJQYXRjaGVzXCI7XG52YXIgUGx1Z2luQXJyYXlNZXRob2RzID0gXCJBcnJheU1ldGhvZHNcIjtcbnZhciBwbHVnaW5zID0ge307XG5mdW5jdGlvbiBnZXRQbHVnaW4ocGx1Z2luS2V5KSB7XG4gIGNvbnN0IHBsdWdpbiA9IHBsdWdpbnNbcGx1Z2luS2V5XTtcbiAgaWYgKCFwbHVnaW4pIHtcbiAgICBkaWUoMCwgcGx1Z2luS2V5KTtcbiAgfVxuICByZXR1cm4gcGx1Z2luO1xufVxudmFyIGlzUGx1Z2luTG9hZGVkID0gKHBsdWdpbktleSkgPT4gISFwbHVnaW5zW3BsdWdpbktleV07XG5mdW5jdGlvbiBsb2FkUGx1Z2luKHBsdWdpbktleSwgaW1wbGVtZW50YXRpb24pIHtcbiAgaWYgKCFwbHVnaW5zW3BsdWdpbktleV0pXG4gICAgcGx1Z2luc1twbHVnaW5LZXldID0gaW1wbGVtZW50YXRpb247XG59XG5cbi8vIHNyYy9jb3JlL3Njb3BlLnRzXG52YXIgY3VycmVudFNjb3BlO1xudmFyIGdldEN1cnJlbnRTY29wZSA9ICgpID0+IGN1cnJlbnRTY29wZTtcbnZhciBjcmVhdGVTY29wZSA9IChwYXJlbnRfLCBpbW1lcl8pID0+ICh7XG4gIGRyYWZ0c186IFtdLFxuICBwYXJlbnRfLFxuICBpbW1lcl8sXG4gIC8vIFdoZW5ldmVyIHRoZSBtb2RpZmllZCBkcmFmdCBjb250YWlucyBhIGRyYWZ0IGZyb20gYW5vdGhlciBzY29wZSwgd2VcbiAgLy8gbmVlZCB0byBwcmV2ZW50IGF1dG8tZnJlZXppbmcgc28gdGhlIHVub3duZWQgZHJhZnQgY2FuIGJlIGZpbmFsaXplZC5cbiAgY2FuQXV0b0ZyZWV6ZV86IHRydWUsXG4gIHVuZmluYWxpemVkRHJhZnRzXzogMCxcbiAgaGFuZGxlZFNldF86IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG4gIHByb2Nlc3NlZEZvclBhdGNoZXNfOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuICBtYXBTZXRQbHVnaW5fOiBpc1BsdWdpbkxvYWRlZChQbHVnaW5NYXBTZXQpID8gZ2V0UGx1Z2luKFBsdWdpbk1hcFNldCkgOiB2b2lkIDAsXG4gIGFycmF5TWV0aG9kc1BsdWdpbl86IGlzUGx1Z2luTG9hZGVkKFBsdWdpbkFycmF5TWV0aG9kcykgPyBnZXRQbHVnaW4oUGx1Z2luQXJyYXlNZXRob2RzKSA6IHZvaWQgMFxufSk7XG5mdW5jdGlvbiB1c2VQYXRjaGVzSW5TY29wZShzY29wZSwgcGF0Y2hMaXN0ZW5lcikge1xuICBpZiAocGF0Y2hMaXN0ZW5lcikge1xuICAgIHNjb3BlLnBhdGNoUGx1Z2luXyA9IGdldFBsdWdpbihQbHVnaW5QYXRjaGVzKTtcbiAgICBzY29wZS5wYXRjaGVzXyA9IFtdO1xuICAgIHNjb3BlLmludmVyc2VQYXRjaGVzXyA9IFtdO1xuICAgIHNjb3BlLnBhdGNoTGlzdGVuZXJfID0gcGF0Y2hMaXN0ZW5lcjtcbiAgfVxufVxuZnVuY3Rpb24gcmV2b2tlU2NvcGUoc2NvcGUpIHtcbiAgbGVhdmVTY29wZShzY29wZSk7XG4gIHNjb3BlLmRyYWZ0c18uZm9yRWFjaChyZXZva2VEcmFmdCk7XG4gIHNjb3BlLmRyYWZ0c18gPSBudWxsO1xufVxuZnVuY3Rpb24gbGVhdmVTY29wZShzY29wZSkge1xuICBpZiAoc2NvcGUgPT09IGN1cnJlbnRTY29wZSkge1xuICAgIGN1cnJlbnRTY29wZSA9IHNjb3BlLnBhcmVudF87XG4gIH1cbn1cbnZhciBlbnRlclNjb3BlID0gKGltbWVyMikgPT4gY3VycmVudFNjb3BlID0gY3JlYXRlU2NvcGUoY3VycmVudFNjb3BlLCBpbW1lcjIpO1xuZnVuY3Rpb24gcmV2b2tlRHJhZnQoZHJhZnQpIHtcbiAgY29uc3Qgc3RhdGUgPSBkcmFmdFtEUkFGVF9TVEFURV07XG4gIGlmIChzdGF0ZS50eXBlXyA9PT0gMCAvKiBPYmplY3QgKi8gfHwgc3RhdGUudHlwZV8gPT09IDEgLyogQXJyYXkgKi8pXG4gICAgc3RhdGUucmV2b2tlXygpO1xuICBlbHNlXG4gICAgc3RhdGUucmV2b2tlZF8gPSB0cnVlO1xufVxuXG4vLyBzcmMvY29yZS9maW5hbGl6ZS50c1xuZnVuY3Rpb24gcHJvY2Vzc1Jlc3VsdChyZXN1bHQsIHNjb3BlKSB7XG4gIHNjb3BlLnVuZmluYWxpemVkRHJhZnRzXyA9IHNjb3BlLmRyYWZ0c18ubGVuZ3RoO1xuICBjb25zdCBiYXNlRHJhZnQgPSBzY29wZS5kcmFmdHNfWzBdO1xuICBjb25zdCBpc1JlcGxhY2VkID0gcmVzdWx0ICE9PSB2b2lkIDAgJiYgcmVzdWx0ICE9PSBiYXNlRHJhZnQ7XG4gIGlmIChpc1JlcGxhY2VkKSB7XG4gICAgaWYgKGJhc2VEcmFmdFtEUkFGVF9TVEFURV0ubW9kaWZpZWRfKSB7XG4gICAgICByZXZva2VTY29wZShzY29wZSk7XG4gICAgICBkaWUoNCk7XG4gICAgfVxuICAgIGlmIChpc0RyYWZ0YWJsZShyZXN1bHQpKSB7XG4gICAgICByZXN1bHQgPSBmaW5hbGl6ZShzY29wZSwgcmVzdWx0KTtcbiAgICB9XG4gICAgY29uc3QgeyBwYXRjaFBsdWdpbl8gfSA9IHNjb3BlO1xuICAgIGlmIChwYXRjaFBsdWdpbl8pIHtcbiAgICAgIHBhdGNoUGx1Z2luXy5nZW5lcmF0ZVJlcGxhY2VtZW50UGF0Y2hlc18oXG4gICAgICAgIGJhc2VEcmFmdFtEUkFGVF9TVEFURV0uYmFzZV8sXG4gICAgICAgIHJlc3VsdCxcbiAgICAgICAgc2NvcGVcbiAgICAgICk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJlc3VsdCA9IGZpbmFsaXplKHNjb3BlLCBiYXNlRHJhZnQpO1xuICB9XG4gIG1heWJlRnJlZXplKHNjb3BlLCByZXN1bHQsIHRydWUpO1xuICByZXZva2VTY29wZShzY29wZSk7XG4gIGlmIChzY29wZS5wYXRjaGVzXykge1xuICAgIHNjb3BlLnBhdGNoTGlzdGVuZXJfKHNjb3BlLnBhdGNoZXNfLCBzY29wZS5pbnZlcnNlUGF0Y2hlc18pO1xuICB9XG4gIHJldHVybiByZXN1bHQgIT09IE5PVEhJTkcgPyByZXN1bHQgOiB2b2lkIDA7XG59XG5mdW5jdGlvbiBmaW5hbGl6ZShyb290U2NvcGUsIHZhbHVlKSB7XG4gIGlmIChpc0Zyb3plbih2YWx1ZSkpXG4gICAgcmV0dXJuIHZhbHVlO1xuICBjb25zdCBzdGF0ZSA9IHZhbHVlW0RSQUZUX1NUQVRFXTtcbiAgaWYgKCFzdGF0ZSkge1xuICAgIGNvbnN0IGZpbmFsVmFsdWUgPSBoYW5kbGVWYWx1ZSh2YWx1ZSwgcm9vdFNjb3BlLmhhbmRsZWRTZXRfLCByb290U2NvcGUpO1xuICAgIHJldHVybiBmaW5hbFZhbHVlO1xuICB9XG4gIGlmICghaXNTYW1lU2NvcGUoc3RhdGUsIHJvb3RTY29wZSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgaWYgKCFzdGF0ZS5tb2RpZmllZF8pIHtcbiAgICByZXR1cm4gc3RhdGUuYmFzZV87XG4gIH1cbiAgaWYgKCFzdGF0ZS5maW5hbGl6ZWRfKSB7XG4gICAgY29uc3QgeyBjYWxsYmFja3NfIH0gPSBzdGF0ZTtcbiAgICBpZiAoY2FsbGJhY2tzXykge1xuICAgICAgd2hpbGUgKGNhbGxiYWNrc18ubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zdCBjYWxsYmFjayA9IGNhbGxiYWNrc18ucG9wKCk7XG4gICAgICAgIGNhbGxiYWNrKHJvb3RTY29wZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGdlbmVyYXRlUGF0Y2hlc0FuZEZpbmFsaXplKHN0YXRlLCByb290U2NvcGUpO1xuICB9XG4gIHJldHVybiBzdGF0ZS5jb3B5Xztcbn1cbmZ1bmN0aW9uIG1heWJlRnJlZXplKHNjb3BlLCB2YWx1ZSwgZGVlcCA9IGZhbHNlKSB7XG4gIGlmICghc2NvcGUucGFyZW50XyAmJiBzY29wZS5pbW1lcl8uYXV0b0ZyZWV6ZV8gJiYgc2NvcGUuY2FuQXV0b0ZyZWV6ZV8pIHtcbiAgICBmcmVlemUodmFsdWUsIGRlZXApO1xuICB9XG59XG5mdW5jdGlvbiBtYXJrU3RhdGVGaW5hbGl6ZWQoc3RhdGUpIHtcbiAgc3RhdGUuZmluYWxpemVkXyA9IHRydWU7XG4gIHN0YXRlLnNjb3BlXy51bmZpbmFsaXplZERyYWZ0c18tLTtcbn1cbnZhciBpc1NhbWVTY29wZSA9IChzdGF0ZSwgcm9vdFNjb3BlKSA9PiBzdGF0ZS5zY29wZV8gPT09IHJvb3RTY29wZTtcbnZhciBFTVBUWV9MT0NBVElPTlNfUkVTVUxUID0gW107XG5mdW5jdGlvbiB1cGRhdGVEcmFmdEluUGFyZW50KHBhcmVudCwgZHJhZnRWYWx1ZSwgZmluYWxpemVkVmFsdWUsIG9yaWdpbmFsS2V5KSB7XG4gIGNvbnN0IHBhcmVudENvcHkgPSBsYXRlc3QocGFyZW50KTtcbiAgY29uc3QgcGFyZW50VHlwZSA9IHBhcmVudC50eXBlXztcbiAgaWYgKG9yaWdpbmFsS2V5ICE9PSB2b2lkIDApIHtcbiAgICBjb25zdCBjdXJyZW50VmFsdWUgPSBnZXQocGFyZW50Q29weSwgb3JpZ2luYWxLZXksIHBhcmVudFR5cGUpO1xuICAgIGlmIChjdXJyZW50VmFsdWUgPT09IGRyYWZ0VmFsdWUpIHtcbiAgICAgIHNldChwYXJlbnRDb3B5LCBvcmlnaW5hbEtleSwgZmluYWxpemVkVmFsdWUsIHBhcmVudFR5cGUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgfVxuICBpZiAoIXBhcmVudC5kcmFmdExvY2F0aW9uc18pIHtcbiAgICBjb25zdCBkcmFmdExvY2F0aW9ucyA9IHBhcmVudC5kcmFmdExvY2F0aW9uc18gPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIGVhY2gocGFyZW50Q29weSwgKGtleSwgdmFsdWUpID0+IHtcbiAgICAgIGlmIChpc0RyYWZ0KHZhbHVlKSkge1xuICAgICAgICBjb25zdCBrZXlzID0gZHJhZnRMb2NhdGlvbnMuZ2V0KHZhbHVlKSB8fCBbXTtcbiAgICAgICAga2V5cy5wdXNoKGtleSk7XG4gICAgICAgIGRyYWZ0TG9jYXRpb25zLnNldCh2YWx1ZSwga2V5cyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgY29uc3QgbG9jYXRpb25zID0gcGFyZW50LmRyYWZ0TG9jYXRpb25zXy5nZXQoZHJhZnRWYWx1ZSkgPz8gRU1QVFlfTE9DQVRJT05TX1JFU1VMVDtcbiAgZm9yIChjb25zdCBsb2NhdGlvbiBvZiBsb2NhdGlvbnMpIHtcbiAgICBzZXQocGFyZW50Q29weSwgbG9jYXRpb24sIGZpbmFsaXplZFZhbHVlLCBwYXJlbnRUeXBlKTtcbiAgfVxufVxuZnVuY3Rpb24gcmVnaXN0ZXJDaGlsZEZpbmFsaXphdGlvbkNhbGxiYWNrKHBhcmVudCwgY2hpbGQsIGtleSkge1xuICBwYXJlbnQuY2FsbGJhY2tzXy5wdXNoKGZ1bmN0aW9uIGNoaWxkQ2xlYW51cChyb290U2NvcGUpIHtcbiAgICBjb25zdCBzdGF0ZSA9IGNoaWxkO1xuICAgIGlmICghc3RhdGUgfHwgIWlzU2FtZVNjb3BlKHN0YXRlLCByb290U2NvcGUpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJvb3RTY29wZS5tYXBTZXRQbHVnaW5fPy5maXhTZXRDb250ZW50cyhzdGF0ZSk7XG4gICAgY29uc3QgZmluYWxpemVkVmFsdWUgPSBnZXRGaW5hbFZhbHVlKHN0YXRlKTtcbiAgICB1cGRhdGVEcmFmdEluUGFyZW50KHBhcmVudCwgc3RhdGUuZHJhZnRfID8/IHN0YXRlLCBmaW5hbGl6ZWRWYWx1ZSwga2V5KTtcbiAgICBnZW5lcmF0ZVBhdGNoZXNBbmRGaW5hbGl6ZShzdGF0ZSwgcm9vdFNjb3BlKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBnZW5lcmF0ZVBhdGNoZXNBbmRGaW5hbGl6ZShzdGF0ZSwgcm9vdFNjb3BlKSB7XG4gIGNvbnN0IHNob3VsZEZpbmFsaXplID0gc3RhdGUubW9kaWZpZWRfICYmICFzdGF0ZS5maW5hbGl6ZWRfICYmIChzdGF0ZS50eXBlXyA9PT0gMyAvKiBTZXQgKi8gfHwgc3RhdGUudHlwZV8gPT09IDEgLyogQXJyYXkgKi8gJiYgc3RhdGUuYWxsSW5kaWNlc1JlYXNzaWduZWRfIHx8IChzdGF0ZS5hc3NpZ25lZF8/LnNpemUgPz8gMCkgPiAwKTtcbiAgaWYgKHNob3VsZEZpbmFsaXplKSB7XG4gICAgY29uc3QgeyBwYXRjaFBsdWdpbl8gfSA9IHJvb3RTY29wZTtcbiAgICBpZiAocGF0Y2hQbHVnaW5fKSB7XG4gICAgICBjb25zdCBiYXNlUGF0aCA9IHBhdGNoUGx1Z2luXy5nZXRQYXRoKHN0YXRlKTtcbiAgICAgIGlmIChiYXNlUGF0aCkge1xuICAgICAgICBwYXRjaFBsdWdpbl8uZ2VuZXJhdGVQYXRjaGVzXyhzdGF0ZSwgYmFzZVBhdGgsIHJvb3RTY29wZSk7XG4gICAgICB9XG4gICAgfVxuICAgIG1hcmtTdGF0ZUZpbmFsaXplZChzdGF0ZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGhhbmRsZUNyb3NzUmVmZXJlbmNlKHRhcmdldCwga2V5LCB2YWx1ZSkge1xuICBjb25zdCB7IHNjb3BlXyB9ID0gdGFyZ2V0O1xuICBpZiAoaXNEcmFmdCh2YWx1ZSkpIHtcbiAgICBjb25zdCBzdGF0ZSA9IHZhbHVlW0RSQUZUX1NUQVRFXTtcbiAgICBpZiAoaXNTYW1lU2NvcGUoc3RhdGUsIHNjb3BlXykpIHtcbiAgICAgIHN0YXRlLmNhbGxiYWNrc18ucHVzaChmdW5jdGlvbiBjcm9zc1JlZmVyZW5jZUNsZWFudXAoKSB7XG4gICAgICAgIHByZXBhcmVDb3B5KHRhcmdldCk7XG4gICAgICAgIGNvbnN0IGZpbmFsaXplZFZhbHVlID0gZ2V0RmluYWxWYWx1ZShzdGF0ZSk7XG4gICAgICAgIHVwZGF0ZURyYWZ0SW5QYXJlbnQodGFyZ2V0LCB2YWx1ZSwgZmluYWxpemVkVmFsdWUsIGtleSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNEcmFmdGFibGUodmFsdWUpKSB7XG4gICAgdGFyZ2V0LmNhbGxiYWNrc18ucHVzaChmdW5jdGlvbiBuZXN0ZWREcmFmdENsZWFudXAoKSB7XG4gICAgICBjb25zdCB0YXJnZXRDb3B5ID0gbGF0ZXN0KHRhcmdldCk7XG4gICAgICBpZiAodGFyZ2V0LnR5cGVfID09PSAzIC8qIFNldCAqLykge1xuICAgICAgICBpZiAodGFyZ2V0Q29weS5oYXModmFsdWUpKSB7XG4gICAgICAgICAgaGFuZGxlVmFsdWUodmFsdWUsIHNjb3BlXy5oYW5kbGVkU2V0Xywgc2NvcGVfKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKGdldCh0YXJnZXRDb3B5LCBrZXksIHRhcmdldC50eXBlXykgPT09IHZhbHVlKSB7XG4gICAgICAgICAgaWYgKHNjb3BlXy5kcmFmdHNfLmxlbmd0aCA+IDEgJiYgKHRhcmdldC5hc3NpZ25lZF8uZ2V0KGtleSkgPz8gZmFsc2UpID09PSB0cnVlICYmIHRhcmdldC5jb3B5Xykge1xuICAgICAgICAgICAgaGFuZGxlVmFsdWUoXG4gICAgICAgICAgICAgIGdldCh0YXJnZXQuY29weV8sIGtleSwgdGFyZ2V0LnR5cGVfKSxcbiAgICAgICAgICAgICAgc2NvcGVfLmhhbmRsZWRTZXRfLFxuICAgICAgICAgICAgICBzY29wZV9cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGhhbmRsZVZhbHVlKHRhcmdldCwgaGFuZGxlZFNldCwgcm9vdFNjb3BlKSB7XG4gIGlmICghcm9vdFNjb3BlLmltbWVyXy5hdXRvRnJlZXplXyAmJiByb290U2NvcGUudW5maW5hbGl6ZWREcmFmdHNfIDwgMSkge1xuICAgIHJldHVybiB0YXJnZXQ7XG4gIH1cbiAgaWYgKGlzRHJhZnQodGFyZ2V0KSB8fCBoYW5kbGVkU2V0Lmhhcyh0YXJnZXQpIHx8ICFpc0RyYWZ0YWJsZSh0YXJnZXQpIHx8IGlzRnJvemVuKHRhcmdldCkpIHtcbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9XG4gIGhhbmRsZWRTZXQuYWRkKHRhcmdldCk7XG4gIGVhY2godGFyZ2V0LCAoa2V5LCB2YWx1ZSkgPT4ge1xuICAgIGlmIChpc0RyYWZ0KHZhbHVlKSkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB2YWx1ZVtEUkFGVF9TVEFURV07XG4gICAgICBpZiAoaXNTYW1lU2NvcGUoc3RhdGUsIHJvb3RTY29wZSkpIHtcbiAgICAgICAgY29uc3QgdXBkYXRlZFZhbHVlID0gZ2V0RmluYWxWYWx1ZShzdGF0ZSk7XG4gICAgICAgIHNldCh0YXJnZXQsIGtleSwgdXBkYXRlZFZhbHVlLCB0YXJnZXQudHlwZV8pO1xuICAgICAgICBtYXJrU3RhdGVGaW5hbGl6ZWQoc3RhdGUpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaXNEcmFmdGFibGUodmFsdWUpKSB7XG4gICAgICBoYW5kbGVWYWx1ZSh2YWx1ZSwgaGFuZGxlZFNldCwgcm9vdFNjb3BlKTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gdGFyZ2V0O1xufVxuXG4vLyBzcmMvY29yZS9wcm94eS50c1xuZnVuY3Rpb24gY3JlYXRlUHJveHlQcm94eShiYXNlLCBwYXJlbnQpIHtcbiAgY29uc3QgYmFzZUlzQXJyYXkgPSBpc0FycmF5KGJhc2UpO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICB0eXBlXzogYmFzZUlzQXJyYXkgPyAxIC8qIEFycmF5ICovIDogMCAvKiBPYmplY3QgKi8sXG4gICAgLy8gVHJhY2sgd2hpY2ggcHJvZHVjZSBjYWxsIHRoaXMgaXMgYXNzb2NpYXRlZCB3aXRoLlxuICAgIHNjb3BlXzogcGFyZW50ID8gcGFyZW50LnNjb3BlXyA6IGdldEN1cnJlbnRTY29wZSgpLFxuICAgIC8vIFRydWUgZm9yIGJvdGggc2hhbGxvdyBhbmQgZGVlcCBjaGFuZ2VzLlxuICAgIG1vZGlmaWVkXzogZmFsc2UsXG4gICAgLy8gVXNlZCBkdXJpbmcgZmluYWxpemF0aW9uLlxuICAgIGZpbmFsaXplZF86IGZhbHNlLFxuICAgIC8vIFRyYWNrIHdoaWNoIHByb3BlcnRpZXMgaGF2ZSBiZWVuIGFzc2lnbmVkICh0cnVlKSBvciBkZWxldGVkIChmYWxzZSkuXG4gICAgLy8gYWN0dWFsbHkgaW5zdGFudGlhdGVkIGluIGBwcmVwYXJlQ29weSgpYFxuICAgIGFzc2lnbmVkXzogdm9pZCAwLFxuICAgIC8vIFRoZSBwYXJlbnQgZHJhZnQgc3RhdGUuXG4gICAgcGFyZW50XzogcGFyZW50LFxuICAgIC8vIFRoZSBiYXNlIHN0YXRlLlxuICAgIGJhc2VfOiBiYXNlLFxuICAgIC8vIFRoZSBiYXNlIHByb3h5LlxuICAgIGRyYWZ0XzogbnVsbCxcbiAgICAvLyBzZXQgYmVsb3dcbiAgICAvLyBUaGUgYmFzZSBjb3B5IHdpdGggYW55IHVwZGF0ZWQgdmFsdWVzLlxuICAgIGNvcHlfOiBudWxsLFxuICAgIC8vIENhbGxlZCBieSB0aGUgYHByb2R1Y2VgIGZ1bmN0aW9uLlxuICAgIHJldm9rZV86IG51bGwsXG4gICAgaXNNYW51YWxfOiBmYWxzZSxcbiAgICAvLyBgY2FsbGJhY2tzYCBhY3R1YWxseSBnZXRzIGFzc2lnbmVkIGluIGBjcmVhdGVQcm94eWBcbiAgICBjYWxsYmFja3NfOiB2b2lkIDBcbiAgfTtcbiAgbGV0IHRhcmdldCA9IHN0YXRlO1xuICBsZXQgdHJhcHMgPSBvYmplY3RUcmFwcztcbiAgaWYgKGJhc2VJc0FycmF5KSB7XG4gICAgdGFyZ2V0ID0gW3N0YXRlXTtcbiAgICB0cmFwcyA9IGFycmF5VHJhcHM7XG4gIH1cbiAgY29uc3QgeyByZXZva2UsIHByb3h5IH0gPSBQcm94eS5yZXZvY2FibGUodGFyZ2V0LCB0cmFwcyk7XG4gIHN0YXRlLmRyYWZ0XyA9IHByb3h5O1xuICBzdGF0ZS5yZXZva2VfID0gcmV2b2tlO1xuICByZXR1cm4gW3Byb3h5LCBzdGF0ZV07XG59XG52YXIgb2JqZWN0VHJhcHMgPSB7XG4gIGdldChzdGF0ZSwgcHJvcCkge1xuICAgIGlmIChwcm9wID09PSBEUkFGVF9TVEFURSlcbiAgICAgIHJldHVybiBzdGF0ZTtcbiAgICBsZXQgYXJyYXlQbHVnaW4gPSBzdGF0ZS5zY29wZV8uYXJyYXlNZXRob2RzUGx1Z2luXztcbiAgICBjb25zdCBpc0FycmF5V2l0aFN0cmluZ1Byb3AgPSBzdGF0ZS50eXBlXyA9PT0gMSAvKiBBcnJheSAqLyAmJiB0eXBlb2YgcHJvcCA9PT0gXCJzdHJpbmdcIjtcbiAgICBpZiAoaXNBcnJheVdpdGhTdHJpbmdQcm9wKSB7XG4gICAgICBpZiAoYXJyYXlQbHVnaW4/LmlzQXJyYXlPcGVyYXRpb25NZXRob2QocHJvcCkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5UGx1Z2luLmNyZWF0ZU1ldGhvZEludGVyY2VwdG9yKHN0YXRlLCBwcm9wKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc291cmNlID0gbGF0ZXN0KHN0YXRlKTtcbiAgICBpZiAoIWhhcyhzb3VyY2UsIHByb3AsIHN0YXRlLnR5cGVfKSkge1xuICAgICAgcmV0dXJuIHJlYWRQcm9wRnJvbVByb3RvKHN0YXRlLCBzb3VyY2UsIHByb3ApO1xuICAgIH1cbiAgICBjb25zdCB2YWx1ZSA9IHNvdXJjZVtwcm9wXTtcbiAgICBpZiAoc3RhdGUuZmluYWxpemVkXyB8fCAhaXNEcmFmdGFibGUodmFsdWUpKSB7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGlmIChpc0FycmF5V2l0aFN0cmluZ1Byb3AgJiYgc3RhdGUub3BlcmF0aW9uTWV0aG9kICYmIGFycmF5UGx1Z2luPy5pc011dGF0aW5nQXJyYXlNZXRob2QoXG4gICAgICBzdGF0ZS5vcGVyYXRpb25NZXRob2RcbiAgICApICYmIGlzQXJyYXlJbmRleChwcm9wKSkge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICBpZiAodmFsdWUgPT09IHBlZWsoc3RhdGUuYmFzZV8sIHByb3ApIHx8IGlzUmVsb2NhdGVkQmFzZVJlZihzdGF0ZSwgcHJvcCwgdmFsdWUpKSB7XG4gICAgICBwcmVwYXJlQ29weShzdGF0ZSk7XG4gICAgICBjb25zdCBjaGlsZEtleSA9IHN0YXRlLnR5cGVfID09PSAxIC8qIEFycmF5ICovID8gK3Byb3AgOiBwcm9wO1xuICAgICAgY29uc3QgY2hpbGREcmFmdCA9IGNyZWF0ZVByb3h5KHN0YXRlLnNjb3BlXywgdmFsdWUsIHN0YXRlLCBjaGlsZEtleSk7XG4gICAgICByZXR1cm4gc3RhdGUuY29weV9bY2hpbGRLZXldID0gY2hpbGREcmFmdDtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9LFxuICBoYXMoc3RhdGUsIHByb3ApIHtcbiAgICByZXR1cm4gcHJvcCBpbiBsYXRlc3Qoc3RhdGUpO1xuICB9LFxuICBvd25LZXlzKHN0YXRlKSB7XG4gICAgcmV0dXJuIFJlZmxlY3Qub3duS2V5cyhsYXRlc3Qoc3RhdGUpKTtcbiAgfSxcbiAgc2V0KHN0YXRlLCBwcm9wLCB2YWx1ZSkge1xuICAgIGNvbnN0IGRlc2MgPSBnZXREZXNjcmlwdG9yRnJvbVByb3RvKGxhdGVzdChzdGF0ZSksIHByb3ApO1xuICAgIGlmIChkZXNjPy5zZXQpIHtcbiAgICAgIGRlc2Muc2V0LmNhbGwoc3RhdGUuZHJhZnRfLCB2YWx1ZSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKCFzdGF0ZS5tb2RpZmllZF8pIHtcbiAgICAgIGNvbnN0IGN1cnJlbnQyID0gcGVlayhsYXRlc3Qoc3RhdGUpLCBwcm9wKTtcbiAgICAgIGNvbnN0IGN1cnJlbnRTdGF0ZSA9IGN1cnJlbnQyPy5bRFJBRlRfU1RBVEVdO1xuICAgICAgaWYgKGN1cnJlbnRTdGF0ZSAmJiBjdXJyZW50U3RhdGUuYmFzZV8gPT09IHZhbHVlKSB7XG4gICAgICAgIHN0YXRlLmNvcHlfW3Byb3BdID0gdmFsdWU7XG4gICAgICAgIHN0YXRlLmFzc2lnbmVkXy5zZXQocHJvcCwgZmFsc2UpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChpcyh2YWx1ZSwgY3VycmVudDIpICYmICh2YWx1ZSAhPT0gdm9pZCAwIHx8IGhhcyhzdGF0ZS5iYXNlXywgcHJvcCwgc3RhdGUudHlwZV8pKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICBwcmVwYXJlQ29weShzdGF0ZSk7XG4gICAgICBtYXJrQ2hhbmdlZChzdGF0ZSk7XG4gICAgfVxuICAgIGlmIChzdGF0ZS5jb3B5X1twcm9wXSA9PT0gdmFsdWUgJiYgLy8gc3BlY2lhbCBjYXNlOiBoYW5kbGUgbmV3IHByb3BzIHdpdGggdmFsdWUgJ3VuZGVmaW5lZCdcbiAgICAodmFsdWUgIT09IHZvaWQgMCB8fCBoYXMoc3RhdGUuY29weV8sIHByb3AsIHN0YXRlLnR5cGVfKSkgfHwgLy8gc3BlY2lhbCBjYXNlOiBOYU5cbiAgICBOdW1iZXIuaXNOYU4odmFsdWUpICYmIE51bWJlci5pc05hTihzdGF0ZS5jb3B5X1twcm9wXSkpXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICBzdGF0ZS5jb3B5X1twcm9wXSA9IHZhbHVlO1xuICAgIHN0YXRlLmFzc2lnbmVkXy5zZXQocHJvcCwgdHJ1ZSk7XG4gICAgaGFuZGxlQ3Jvc3NSZWZlcmVuY2Uoc3RhdGUsIHByb3AsIHZhbHVlKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcbiAgZGVsZXRlUHJvcGVydHkoc3RhdGUsIHByb3ApIHtcbiAgICBwcmVwYXJlQ29weShzdGF0ZSk7XG4gICAgaWYgKHBlZWsoc3RhdGUuYmFzZV8sIHByb3ApICE9PSB2b2lkIDAgfHwgcHJvcCBpbiBzdGF0ZS5iYXNlXykge1xuICAgICAgc3RhdGUuYXNzaWduZWRfLnNldChwcm9wLCBmYWxzZSk7XG4gICAgICBtYXJrQ2hhbmdlZChzdGF0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXRlLmFzc2lnbmVkXy5kZWxldGUocHJvcCk7XG4gICAgfVxuICAgIGlmIChzdGF0ZS5jb3B5Xykge1xuICAgICAgZGVsZXRlIHN0YXRlLmNvcHlfW3Byb3BdO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSxcbiAgLy8gTm90ZTogV2UgbmV2ZXIgY29lcmNlIGBkZXNjLnZhbHVlYCBpbnRvIGFuIEltbWVyIGRyYWZ0LCBiZWNhdXNlIHdlIGNhbid0IG1ha2VcbiAgLy8gdGhlIHNhbWUgZ3VhcmFudGVlIGluIEVTNSBtb2RlLlxuICBnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Ioc3RhdGUsIHByb3ApIHtcbiAgICBjb25zdCBvd25lciA9IGxhdGVzdChzdGF0ZSk7XG4gICAgY29uc3QgZGVzYyA9IFJlZmxlY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG93bmVyLCBwcm9wKTtcbiAgICBpZiAoIWRlc2MpXG4gICAgICByZXR1cm4gZGVzYztcbiAgICByZXR1cm4ge1xuICAgICAgW1dSSVRBQkxFXTogdHJ1ZSxcbiAgICAgIFtDT05GSUdVUkFCTEVdOiBzdGF0ZS50eXBlXyAhPT0gMSAvKiBBcnJheSAqLyB8fCBwcm9wICE9PSBcImxlbmd0aFwiLFxuICAgICAgW0VOVU1FUkFCTEVdOiBkZXNjW0VOVU1FUkFCTEVdLFxuICAgICAgW1ZBTFVFXTogb3duZXJbcHJvcF1cbiAgICB9O1xuICB9LFxuICBkZWZpbmVQcm9wZXJ0eSgpIHtcbiAgICBkaWUoMTEpO1xuICB9LFxuICBnZXRQcm90b3R5cGVPZihzdGF0ZSkge1xuICAgIHJldHVybiBnZXRQcm90b3R5cGVPZihzdGF0ZS5iYXNlXyk7XG4gIH0sXG4gIHNldFByb3RvdHlwZU9mKCkge1xuICAgIGRpZSgxMik7XG4gIH1cbn07XG52YXIgYXJyYXlUcmFwcyA9IHt9O1xuZm9yIChsZXQga2V5IGluIG9iamVjdFRyYXBzKSB7XG4gIGxldCBmbiA9IG9iamVjdFRyYXBzW2tleV07XG4gIGFycmF5VHJhcHNba2V5XSA9IGZ1bmN0aW9uKCkge1xuICAgIGNvbnN0IGFyZ3MgPSBhcmd1bWVudHM7XG4gICAgYXJnc1swXSA9IGFyZ3NbMF1bMF07XG4gICAgcmV0dXJuIGZuLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICB9O1xufVxuYXJyYXlUcmFwcy5kZWxldGVQcm9wZXJ0eSA9IGZ1bmN0aW9uKHN0YXRlLCBwcm9wKSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgaXNOYU4ocGFyc2VJbnQocHJvcCkpKVxuICAgIGRpZSgxMyk7XG4gIHJldHVybiBhcnJheVRyYXBzLnNldC5jYWxsKHRoaXMsIHN0YXRlLCBwcm9wLCB2b2lkIDApO1xufTtcbmFycmF5VHJhcHMuc2V0ID0gZnVuY3Rpb24oc3RhdGUsIHByb3AsIHZhbHVlKSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgcHJvcCAhPT0gXCJsZW5ndGhcIiAmJiBpc05hTihwYXJzZUludChwcm9wKSkpXG4gICAgZGllKDE0KTtcbiAgcmV0dXJuIG9iamVjdFRyYXBzLnNldC5jYWxsKHRoaXMsIHN0YXRlWzBdLCBwcm9wLCB2YWx1ZSwgc3RhdGVbMF0pO1xufTtcbmZ1bmN0aW9uIHBlZWsoZHJhZnQsIHByb3ApIHtcbiAgY29uc3Qgc3RhdGUgPSBkcmFmdFtEUkFGVF9TVEFURV07XG4gIGNvbnN0IHNvdXJjZSA9IHN0YXRlID8gbGF0ZXN0KHN0YXRlKSA6IGRyYWZ0O1xuICByZXR1cm4gc291cmNlW3Byb3BdO1xufVxuZnVuY3Rpb24gaXNSZWxvY2F0ZWRCYXNlUmVmKHN0YXRlLCBwcm9wLCB2YWx1ZSkge1xuICBpZiAoc3RhdGUudHlwZV8gIT09IDEgLyogQXJyYXkgKi8gfHwgIXN0YXRlLmFsbEluZGljZXNSZWFzc2lnbmVkXyB8fCBzdGF0ZS5hc3NpZ25lZF8/LmdldChwcm9wKSB8fCAhaXNEcmFmdGFibGUodmFsdWUpIHx8IHZhbHVlW0RSQUZUX1NUQVRFXSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gc3RhdGUuYmFzZVJlZnNfLmhhcyh2YWx1ZSk7XG59XG5mdW5jdGlvbiByZWFkUHJvcEZyb21Qcm90byhzdGF0ZSwgc291cmNlLCBwcm9wKSB7XG4gIGNvbnN0IGRlc2MgPSBnZXREZXNjcmlwdG9yRnJvbVByb3RvKHNvdXJjZSwgcHJvcCk7XG4gIHJldHVybiBkZXNjID8gVkFMVUUgaW4gZGVzYyA/IGRlc2NbVkFMVUVdIDogKFxuICAgIC8vIFRoaXMgaXMgYSB2ZXJ5IHNwZWNpYWwgY2FzZSwgaWYgdGhlIHByb3AgaXMgYSBnZXR0ZXIgZGVmaW5lZCBieSB0aGVcbiAgICAvLyBwcm90b3R5cGUsIHdlIHNob3VsZCBpbnZva2UgaXQgd2l0aCB0aGUgZHJhZnQgYXMgY29udGV4dCFcbiAgICBkZXNjLmdldD8uY2FsbChzdGF0ZS5kcmFmdF8pXG4gICkgOiB2b2lkIDA7XG59XG5mdW5jdGlvbiBnZXREZXNjcmlwdG9yRnJvbVByb3RvKHNvdXJjZSwgcHJvcCkge1xuICBpZiAoIShwcm9wIGluIHNvdXJjZSkpXG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgbGV0IHByb3RvID0gZ2V0UHJvdG90eXBlT2Yoc291cmNlKTtcbiAgd2hpbGUgKHByb3RvKSB7XG4gICAgY29uc3QgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocHJvdG8sIHByb3ApO1xuICAgIGlmIChkZXNjKVxuICAgICAgcmV0dXJuIGRlc2M7XG4gICAgcHJvdG8gPSBnZXRQcm90b3R5cGVPZihwcm90byk7XG4gIH1cbiAgcmV0dXJuIHZvaWQgMDtcbn1cbmZ1bmN0aW9uIG1hcmtDaGFuZ2VkKHN0YXRlKSB7XG4gIGlmICghc3RhdGUubW9kaWZpZWRfKSB7XG4gICAgc3RhdGUubW9kaWZpZWRfID0gdHJ1ZTtcbiAgICBpZiAoc3RhdGUucGFyZW50Xykge1xuICAgICAgbWFya0NoYW5nZWQoc3RhdGUucGFyZW50Xyk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBwcmVwYXJlQ29weShzdGF0ZSkge1xuICBpZiAoIXN0YXRlLmNvcHlfKSB7XG4gICAgc3RhdGUuYXNzaWduZWRfID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICBzdGF0ZS5jb3B5XyA9IHNoYWxsb3dDb3B5KFxuICAgICAgc3RhdGUuYmFzZV8sXG4gICAgICBzdGF0ZS5zY29wZV8uaW1tZXJfLnVzZVN0cmljdFNoYWxsb3dDb3B5X1xuICAgICk7XG4gIH1cbn1cblxuLy8gc3JjL2NvcmUvaW1tZXJDbGFzcy50c1xudmFyIEltbWVyMiA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgdGhpcy5hdXRvRnJlZXplXyA9IHRydWU7XG4gICAgdGhpcy51c2VTdHJpY3RTaGFsbG93Q29weV8gPSBmYWxzZTtcbiAgICB0aGlzLnVzZVN0cmljdEl0ZXJhdGlvbl8gPSBmYWxzZTtcbiAgICAvKipcbiAgICAgKiBUaGUgYHByb2R1Y2VgIGZ1bmN0aW9uIHRha2VzIGEgdmFsdWUgYW5kIGEgXCJyZWNpcGUgZnVuY3Rpb25cIiAod2hvc2VcbiAgICAgKiByZXR1cm4gdmFsdWUgb2Z0ZW4gZGVwZW5kcyBvbiB0aGUgYmFzZSBzdGF0ZSkuIFRoZSByZWNpcGUgZnVuY3Rpb24gaXNcbiAgICAgKiBmcmVlIHRvIG11dGF0ZSBpdHMgZmlyc3QgYXJndW1lbnQgaG93ZXZlciBpdCB3YW50cy4gQWxsIG11dGF0aW9ucyBhcmVcbiAgICAgKiBvbmx5IGV2ZXIgYXBwbGllZCB0byBhIF9fY29weV9fIG9mIHRoZSBiYXNlIHN0YXRlLlxuICAgICAqXG4gICAgICogUGFzcyBvbmx5IGEgZnVuY3Rpb24gdG8gY3JlYXRlIGEgXCJjdXJyaWVkIHByb2R1Y2VyXCIgd2hpY2ggcmVsaWV2ZXMgeW91XG4gICAgICogZnJvbSBwYXNzaW5nIHRoZSByZWNpcGUgZnVuY3Rpb24gZXZlcnkgdGltZS5cbiAgICAgKlxuICAgICAqIE9ubHkgcGxhaW4gb2JqZWN0cyBhbmQgYXJyYXlzIGFyZSBtYWRlIG11dGFibGUuIEFsbCBvdGhlciBvYmplY3RzIGFyZVxuICAgICAqIGNvbnNpZGVyZWQgdW5jb3B5YWJsZS5cbiAgICAgKlxuICAgICAqIE5vdGU6IFRoaXMgZnVuY3Rpb24gaXMgX19ib3VuZF9fIHRvIGl0cyBgSW1tZXJgIGluc3RhbmNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIHthbnl9IGJhc2UgLSB0aGUgaW5pdGlhbCBzdGF0ZVxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IHJlY2lwZSAtIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgYSBwcm94eSBvZiB0aGUgYmFzZSBzdGF0ZSBhcyBmaXJzdCBhcmd1bWVudCBhbmQgd2hpY2ggY2FuIGJlIGZyZWVseSBtb2RpZmllZFxuICAgICAqIEBwYXJhbSB7RnVuY3Rpb259IHBhdGNoTGlzdGVuZXIgLSBvcHRpb25hbCBmdW5jdGlvbiB0aGF0IHdpbGwgYmUgY2FsbGVkIHdpdGggYWxsIHRoZSBwYXRjaGVzIHByb2R1Y2VkIGhlcmVcbiAgICAgKiBAcmV0dXJucyB7YW55fSBhIG5ldyBzdGF0ZSwgb3IgdGhlIGluaXRpYWwgc3RhdGUgaWYgbm90aGluZyB3YXMgbW9kaWZpZWRcbiAgICAgKi9cbiAgICB0aGlzLnByb2R1Y2UgPSAoYmFzZSwgcmVjaXBlLCBwYXRjaExpc3RlbmVyKSA9PiB7XG4gICAgICBpZiAoaXNGdW5jdGlvbihiYXNlKSAmJiAhaXNGdW5jdGlvbihyZWNpcGUpKSB7XG4gICAgICAgIGNvbnN0IGRlZmF1bHRCYXNlID0gcmVjaXBlO1xuICAgICAgICByZWNpcGUgPSBiYXNlO1xuICAgICAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGN1cnJpZWRQcm9kdWNlKGJhc2UyID0gZGVmYXVsdEJhc2UsIC4uLmFyZ3MpIHtcbiAgICAgICAgICByZXR1cm4gc2VsZi5wcm9kdWNlKGJhc2UyLCAoZHJhZnQpID0+IHJlY2lwZS5jYWxsKHRoaXMsIGRyYWZ0LCAuLi5hcmdzKSk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZiAoIWlzRnVuY3Rpb24ocmVjaXBlKSlcbiAgICAgICAgZGllKDYpO1xuICAgICAgaWYgKHBhdGNoTGlzdGVuZXIgIT09IHZvaWQgMCAmJiAhaXNGdW5jdGlvbihwYXRjaExpc3RlbmVyKSlcbiAgICAgICAgZGllKDcpO1xuICAgICAgbGV0IHJlc3VsdDtcbiAgICAgIGlmIChpc0RyYWZ0YWJsZShiYXNlKSkge1xuICAgICAgICBjb25zdCBzY29wZSA9IGVudGVyU2NvcGUodGhpcyk7XG4gICAgICAgIGNvbnN0IHByb3h5ID0gY3JlYXRlUHJveHkoc2NvcGUsIGJhc2UsIHZvaWQgMCk7XG4gICAgICAgIGxldCBoYXNFcnJvciA9IHRydWU7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzdWx0ID0gcmVjaXBlKHByb3h5KTtcbiAgICAgICAgICBoYXNFcnJvciA9IGZhbHNlO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGlmIChoYXNFcnJvcilcbiAgICAgICAgICAgIHJldm9rZVNjb3BlKHNjb3BlKTtcbiAgICAgICAgICBlbHNlXG4gICAgICAgICAgICBsZWF2ZVNjb3BlKHNjb3BlKTtcbiAgICAgICAgfVxuICAgICAgICB1c2VQYXRjaGVzSW5TY29wZShzY29wZSwgcGF0Y2hMaXN0ZW5lcik7XG4gICAgICAgIHJldHVybiBwcm9jZXNzUmVzdWx0KHJlc3VsdCwgc2NvcGUpO1xuICAgICAgfSBlbHNlIGlmICghYmFzZSB8fCAhaXNPYmplY3Rpc2goYmFzZSkpIHtcbiAgICAgICAgcmVzdWx0ID0gcmVjaXBlKGJhc2UpO1xuICAgICAgICBpZiAocmVzdWx0ID09PSB2b2lkIDApXG4gICAgICAgICAgcmVzdWx0ID0gYmFzZTtcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gTk9USElORylcbiAgICAgICAgICByZXN1bHQgPSB2b2lkIDA7XG4gICAgICAgIGlmICh0aGlzLmF1dG9GcmVlemVfKVxuICAgICAgICAgIGZyZWV6ZShyZXN1bHQsIHRydWUpO1xuICAgICAgICBpZiAocGF0Y2hMaXN0ZW5lcikge1xuICAgICAgICAgIGNvbnN0IHAgPSBbXTtcbiAgICAgICAgICBjb25zdCBpcCA9IFtdO1xuICAgICAgICAgIGdldFBsdWdpbihQbHVnaW5QYXRjaGVzKS5nZW5lcmF0ZVJlcGxhY2VtZW50UGF0Y2hlc18oYmFzZSwgcmVzdWx0LCB7XG4gICAgICAgICAgICBwYXRjaGVzXzogcCxcbiAgICAgICAgICAgIGludmVyc2VQYXRjaGVzXzogaXBcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBwYXRjaExpc3RlbmVyKHAsIGlwKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSBlbHNlXG4gICAgICAgIGRpZSgxLCBiYXNlKTtcbiAgICB9O1xuICAgIHRoaXMucHJvZHVjZVdpdGhQYXRjaGVzID0gKGJhc2UsIHJlY2lwZSkgPT4ge1xuICAgICAgaWYgKGlzRnVuY3Rpb24oYmFzZSkpIHtcbiAgICAgICAgcmV0dXJuIChzdGF0ZSwgLi4uYXJncykgPT4gdGhpcy5wcm9kdWNlV2l0aFBhdGNoZXMoc3RhdGUsIChkcmFmdCkgPT4gYmFzZShkcmFmdCwgLi4uYXJncykpO1xuICAgICAgfVxuICAgICAgbGV0IHBhdGNoZXMsIGludmVyc2VQYXRjaGVzO1xuICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5wcm9kdWNlKGJhc2UsIHJlY2lwZSwgKHAsIGlwKSA9PiB7XG4gICAgICAgIHBhdGNoZXMgPSBwO1xuICAgICAgICBpbnZlcnNlUGF0Y2hlcyA9IGlwO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gW3Jlc3VsdCwgcGF0Y2hlcywgaW52ZXJzZVBhdGNoZXNdO1xuICAgIH07XG4gICAgaWYgKGlzQm9vbGVhbihjb25maWc/LmF1dG9GcmVlemUpKVxuICAgICAgdGhpcy5zZXRBdXRvRnJlZXplKGNvbmZpZy5hdXRvRnJlZXplKTtcbiAgICBpZiAoaXNCb29sZWFuKGNvbmZpZz8udXNlU3RyaWN0U2hhbGxvd0NvcHkpKVxuICAgICAgdGhpcy5zZXRVc2VTdHJpY3RTaGFsbG93Q29weShjb25maWcudXNlU3RyaWN0U2hhbGxvd0NvcHkpO1xuICAgIGlmIChpc0Jvb2xlYW4oY29uZmlnPy51c2VTdHJpY3RJdGVyYXRpb24pKVxuICAgICAgdGhpcy5zZXRVc2VTdHJpY3RJdGVyYXRpb24oY29uZmlnLnVzZVN0cmljdEl0ZXJhdGlvbik7XG4gIH1cbiAgY3JlYXRlRHJhZnQoYmFzZSkge1xuICAgIGlmICghaXNEcmFmdGFibGUoYmFzZSkpXG4gICAgICBkaWUoOCk7XG4gICAgaWYgKGlzRHJhZnQoYmFzZSkpXG4gICAgICBiYXNlID0gY3VycmVudChiYXNlKTtcbiAgICBjb25zdCBzY29wZSA9IGVudGVyU2NvcGUodGhpcyk7XG4gICAgY29uc3QgcHJveHkgPSBjcmVhdGVQcm94eShzY29wZSwgYmFzZSwgdm9pZCAwKTtcbiAgICBwcm94eVtEUkFGVF9TVEFURV0uaXNNYW51YWxfID0gdHJ1ZTtcbiAgICBsZWF2ZVNjb3BlKHNjb3BlKTtcbiAgICByZXR1cm4gcHJveHk7XG4gIH1cbiAgZmluaXNoRHJhZnQoZHJhZnQsIHBhdGNoTGlzdGVuZXIpIHtcbiAgICBjb25zdCBzdGF0ZSA9IGRyYWZ0ICYmIGRyYWZ0W0RSQUZUX1NUQVRFXTtcbiAgICBpZiAoIXN0YXRlIHx8ICFzdGF0ZS5pc01hbnVhbF8pXG4gICAgICBkaWUoOSk7XG4gICAgY29uc3QgeyBzY29wZV86IHNjb3BlIH0gPSBzdGF0ZTtcbiAgICB1c2VQYXRjaGVzSW5TY29wZShzY29wZSwgcGF0Y2hMaXN0ZW5lcik7XG4gICAgcmV0dXJuIHByb2Nlc3NSZXN1bHQodm9pZCAwLCBzY29wZSk7XG4gIH1cbiAgLyoqXG4gICAqIFBhc3MgdHJ1ZSB0byBhdXRvbWF0aWNhbGx5IGZyZWV6ZSBhbGwgY29waWVzIGNyZWF0ZWQgYnkgSW1tZXIuXG4gICAqXG4gICAqIEJ5IGRlZmF1bHQsIGF1dG8tZnJlZXppbmcgaXMgZW5hYmxlZC5cbiAgICovXG4gIHNldEF1dG9GcmVlemUodmFsdWUpIHtcbiAgICB0aGlzLmF1dG9GcmVlemVfID0gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIFBhc3MgdHJ1ZSB0byBlbmFibGUgc3RyaWN0IHNoYWxsb3cgY29weS5cbiAgICpcbiAgICogQnkgZGVmYXVsdCwgaW1tZXIgZG9lcyBub3QgY29weSB0aGUgb2JqZWN0IGRlc2NyaXB0b3JzIHN1Y2ggYXMgZ2V0dGVyLCBzZXR0ZXIgYW5kIG5vbi1lbnVtcmFibGUgcHJvcGVydGllcy5cbiAgICovXG4gIHNldFVzZVN0cmljdFNoYWxsb3dDb3B5KHZhbHVlKSB7XG4gICAgdGhpcy51c2VTdHJpY3RTaGFsbG93Q29weV8gPSB2YWx1ZTtcbiAgfVxuICAvKipcbiAgICogUGFzcyBmYWxzZSB0byB1c2UgZmFzdGVyIGl0ZXJhdGlvbiB0aGF0IHNraXBzIG5vbi1lbnVtZXJhYmxlIHByb3BlcnRpZXNcbiAgICogYnV0IHN0aWxsIGhhbmRsZXMgc3ltYm9scyBmb3IgY29tcGF0aWJpbGl0eS5cbiAgICpcbiAgICogQnkgZGVmYXVsdCwgc3RyaWN0IGl0ZXJhdGlvbiBpcyBlbmFibGVkIChpbmNsdWRlcyBhbGwgb3duIHByb3BlcnRpZXMpLlxuICAgKi9cbiAgc2V0VXNlU3RyaWN0SXRlcmF0aW9uKHZhbHVlKSB7XG4gICAgdGhpcy51c2VTdHJpY3RJdGVyYXRpb25fID0gdmFsdWU7XG4gIH1cbiAgc2hvdWxkVXNlU3RyaWN0SXRlcmF0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnVzZVN0cmljdEl0ZXJhdGlvbl87XG4gIH1cbiAgYXBwbHlQYXRjaGVzKGJhc2UsIHBhdGNoZXMpIHtcbiAgICBsZXQgaTtcbiAgICBmb3IgKGkgPSBwYXRjaGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBjb25zdCBwYXRjaCA9IHBhdGNoZXNbaV07XG4gICAgICBpZiAocGF0Y2gucGF0aC5sZW5ndGggPT09IDAgJiYgcGF0Y2gub3AgPT09IFwicmVwbGFjZVwiKSB7XG4gICAgICAgIGJhc2UgPSBwYXRjaC52YWx1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChpID4gLTEpIHtcbiAgICAgIHBhdGNoZXMgPSBwYXRjaGVzLnNsaWNlKGkgKyAxKTtcbiAgICB9XG4gICAgY29uc3QgYXBwbHlQYXRjaGVzSW1wbCA9IGdldFBsdWdpbihQbHVnaW5QYXRjaGVzKS5hcHBseVBhdGNoZXNfO1xuICAgIGlmIChpc0RyYWZ0KGJhc2UpKSB7XG4gICAgICByZXR1cm4gYXBwbHlQYXRjaGVzSW1wbChiYXNlLCBwYXRjaGVzKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucHJvZHVjZShcbiAgICAgIGJhc2UsXG4gICAgICAoZHJhZnQpID0+IGFwcGx5UGF0Y2hlc0ltcGwoZHJhZnQsIHBhdGNoZXMpXG4gICAgKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGNyZWF0ZVByb3h5KHJvb3RTY29wZSwgdmFsdWUsIHBhcmVudCwga2V5KSB7XG4gIGNvbnN0IFtkcmFmdCwgc3RhdGVdID0gaXNNYXAodmFsdWUpID8gZ2V0UGx1Z2luKFBsdWdpbk1hcFNldCkucHJveHlNYXBfKHZhbHVlLCBwYXJlbnQpIDogaXNTZXQodmFsdWUpID8gZ2V0UGx1Z2luKFBsdWdpbk1hcFNldCkucHJveHlTZXRfKHZhbHVlLCBwYXJlbnQpIDogY3JlYXRlUHJveHlQcm94eSh2YWx1ZSwgcGFyZW50KTtcbiAgY29uc3Qgc2NvcGUgPSBwYXJlbnQ/LnNjb3BlXyA/PyBnZXRDdXJyZW50U2NvcGUoKTtcbiAgc2NvcGUuZHJhZnRzXy5wdXNoKGRyYWZ0KTtcbiAgc3RhdGUuY2FsbGJhY2tzXyA9IHBhcmVudD8uY2FsbGJhY2tzXyA/PyBbXTtcbiAgc3RhdGUua2V5XyA9IGtleTtcbiAgaWYgKHBhcmVudCAmJiBrZXkgIT09IHZvaWQgMCkge1xuICAgIHJlZ2lzdGVyQ2hpbGRGaW5hbGl6YXRpb25DYWxsYmFjayhwYXJlbnQsIHN0YXRlLCBrZXkpO1xuICB9IGVsc2Uge1xuICAgIHN0YXRlLmNhbGxiYWNrc18ucHVzaChmdW5jdGlvbiByb290RHJhZnRDbGVhbnVwKHJvb3RTY29wZTIpIHtcbiAgICAgIHJvb3RTY29wZTIubWFwU2V0UGx1Z2luXz8uZml4U2V0Q29udGVudHMoc3RhdGUpO1xuICAgICAgY29uc3QgeyBwYXRjaFBsdWdpbl8gfSA9IHJvb3RTY29wZTI7XG4gICAgICBpZiAoc3RhdGUubW9kaWZpZWRfICYmIHBhdGNoUGx1Z2luXykge1xuICAgICAgICBwYXRjaFBsdWdpbl8uZ2VuZXJhdGVQYXRjaGVzXyhzdGF0ZSwgW10sIHJvb3RTY29wZTIpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHJldHVybiBkcmFmdDtcbn1cblxuLy8gc3JjL2NvcmUvY3VycmVudC50c1xuZnVuY3Rpb24gY3VycmVudCh2YWx1ZSkge1xuICBpZiAoIWlzRHJhZnQodmFsdWUpKVxuICAgIGRpZSgxMCwgdmFsdWUpO1xuICByZXR1cm4gY3VycmVudEltcGwodmFsdWUpO1xufVxuZnVuY3Rpb24gY3VycmVudEltcGwodmFsdWUpIHtcbiAgaWYgKCFpc0RyYWZ0YWJsZSh2YWx1ZSkgfHwgaXNGcm96ZW4odmFsdWUpKVxuICAgIHJldHVybiB2YWx1ZTtcbiAgY29uc3Qgc3RhdGUgPSB2YWx1ZVtEUkFGVF9TVEFURV07XG4gIGxldCBjb3B5O1xuICBsZXQgc3RyaWN0ID0gdHJ1ZTtcbiAgaWYgKHN0YXRlKSB7XG4gICAgaWYgKCFzdGF0ZS5tb2RpZmllZF8pXG4gICAgICByZXR1cm4gc3RhdGUuYmFzZV87XG4gICAgc3RhdGUuZmluYWxpemVkXyA9IHRydWU7XG4gICAgY29weSA9IHNoYWxsb3dDb3B5KHZhbHVlLCBzdGF0ZS5zY29wZV8uaW1tZXJfLnVzZVN0cmljdFNoYWxsb3dDb3B5Xyk7XG4gICAgc3RyaWN0ID0gc3RhdGUuc2NvcGVfLmltbWVyXy5zaG91bGRVc2VTdHJpY3RJdGVyYXRpb24oKTtcbiAgfSBlbHNlIHtcbiAgICBjb3B5ID0gc2hhbGxvd0NvcHkodmFsdWUsIHRydWUpO1xuICB9XG4gIGVhY2goXG4gICAgY29weSxcbiAgICAoa2V5LCBjaGlsZFZhbHVlKSA9PiB7XG4gICAgICBzZXQoY29weSwga2V5LCBjdXJyZW50SW1wbChjaGlsZFZhbHVlKSk7XG4gICAgfSxcbiAgICBzdHJpY3RcbiAgKTtcbiAgaWYgKHN0YXRlKSB7XG4gICAgc3RhdGUuZmluYWxpemVkXyA9IGZhbHNlO1xuICB9XG4gIHJldHVybiBjb3B5O1xufVxuXG4vLyBzcmMvcGx1Z2lucy9wYXRjaGVzLnRzXG5mdW5jdGlvbiBlbmFibGVQYXRjaGVzKCkge1xuICBjb25zdCBlcnJvck9mZnNldCA9IDE2O1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgZXJyb3JzLnB1c2goXG4gICAgICAnU2V0cyBjYW5ub3QgaGF2ZSBcInJlcGxhY2VcIiBwYXRjaGVzLicsXG4gICAgICBmdW5jdGlvbihvcCkge1xuICAgICAgICByZXR1cm4gXCJVbnN1cHBvcnRlZCBwYXRjaCBvcGVyYXRpb246IFwiICsgb3A7XG4gICAgICB9LFxuICAgICAgZnVuY3Rpb24ocGF0aCkge1xuICAgICAgICByZXR1cm4gXCJDYW5ub3QgYXBwbHkgcGF0Y2gsIHBhdGggZG9lc24ndCByZXNvbHZlOiBcIiArIHBhdGg7XG4gICAgICB9LFxuICAgICAgXCJQYXRjaGluZyByZXNlcnZlZCBhdHRyaWJ1dGVzIGxpa2UgX19wcm90b19fLCBwcm90b3R5cGUgYW5kIGNvbnN0cnVjdG9yIGlzIG5vdCBhbGxvd2VkXCJcbiAgICApO1xuICB9XG4gIGZ1bmN0aW9uIGdldFBhdGgoc3RhdGUsIHBhdGggPSBbXSkge1xuICAgIGlmIChzdGF0ZS5rZXlfICE9PSB2b2lkIDApIHtcbiAgICAgIGNvbnN0IHBhcmVudENvcHkgPSBzdGF0ZS5wYXJlbnRfLmNvcHlfID8/IHN0YXRlLnBhcmVudF8uYmFzZV87XG4gICAgICBjb25zdCBwcm94eURyYWZ0ID0gZ2V0UHJveHlEcmFmdChnZXQocGFyZW50Q29weSwgc3RhdGUua2V5XykpO1xuICAgICAgY29uc3QgdmFsdWVBdEtleSA9IGdldChwYXJlbnRDb3B5LCBzdGF0ZS5rZXlfKTtcbiAgICAgIGlmICh2YWx1ZUF0S2V5ID09PSB2b2lkIDApIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWVBdEtleSAhPT0gc3RhdGUuZHJhZnRfICYmIHZhbHVlQXRLZXkgIT09IHN0YXRlLmJhc2VfICYmIHZhbHVlQXRLZXkgIT09IHN0YXRlLmNvcHlfKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKHByb3h5RHJhZnQgIT0gbnVsbCAmJiBwcm94eURyYWZ0LmJhc2VfICE9PSBzdGF0ZS5iYXNlXykge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGlzU2V0MiA9IHN0YXRlLnBhcmVudF8udHlwZV8gPT09IDMgLyogU2V0ICovO1xuICAgICAgbGV0IGtleTtcbiAgICAgIGlmIChpc1NldDIpIHtcbiAgICAgICAgY29uc3Qgc2V0UGFyZW50ID0gc3RhdGUucGFyZW50XztcbiAgICAgICAga2V5ID0gQXJyYXkuZnJvbShzZXRQYXJlbnQuZHJhZnRzXy5rZXlzKCkpLmluZGV4T2Yoc3RhdGUua2V5Xyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBrZXkgPSBzdGF0ZS5rZXlfO1xuICAgICAgfVxuICAgICAgaWYgKCEoaXNTZXQyICYmIHBhcmVudENvcHkuc2l6ZSA+IGtleSB8fCBoYXMocGFyZW50Q29weSwga2V5KSkpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBwYXRoLnB1c2goa2V5KTtcbiAgICB9XG4gICAgaWYgKHN0YXRlLnBhcmVudF8pIHtcbiAgICAgIHJldHVybiBnZXRQYXRoKHN0YXRlLnBhcmVudF8sIHBhdGgpO1xuICAgIH1cbiAgICBwYXRoLnJldmVyc2UoKTtcbiAgICB0cnkge1xuICAgICAgcmVzb2x2ZVBhdGgoc3RhdGUuY29weV8sIHBhdGgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gcGF0aDtcbiAgfVxuICBmdW5jdGlvbiByZXNvbHZlUGF0aChiYXNlLCBwYXRoKSB7XG4gICAgbGV0IGN1cnJlbnQyID0gYmFzZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBhdGgubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICBjb25zdCBrZXkgPSBwYXRoW2ldO1xuICAgICAgY3VycmVudDIgPSBnZXQoY3VycmVudDIsIGtleSk7XG4gICAgICBpZiAoIWlzT2JqZWN0aXNoKGN1cnJlbnQyKSB8fCBjdXJyZW50MiA9PT0gbnVsbCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENhbm5vdCByZXNvbHZlIHBhdGggYXQgJyR7cGF0aC5qb2luKFwiL1wiKX0nYCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjdXJyZW50MjtcbiAgfVxuICBjb25zdCBSRVBMQUNFID0gXCJyZXBsYWNlXCI7XG4gIGNvbnN0IEFERCA9IFwiYWRkXCI7XG4gIGNvbnN0IFJFTU9WRSA9IFwicmVtb3ZlXCI7XG4gIGZ1bmN0aW9uIGdlbmVyYXRlUGF0Y2hlc18oc3RhdGUsIGJhc2VQYXRoLCBzY29wZSkge1xuICAgIGlmIChzdGF0ZS5zY29wZV8ucHJvY2Vzc2VkRm9yUGF0Y2hlc18uaGFzKHN0YXRlKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdGF0ZS5zY29wZV8ucHJvY2Vzc2VkRm9yUGF0Y2hlc18uYWRkKHN0YXRlKTtcbiAgICBjb25zdCB7IHBhdGNoZXNfLCBpbnZlcnNlUGF0Y2hlc18gfSA9IHNjb3BlO1xuICAgIHN3aXRjaCAoc3RhdGUudHlwZV8pIHtcbiAgICAgIGNhc2UgMCAvKiBPYmplY3QgKi86XG4gICAgICBjYXNlIDIgLyogTWFwICovOlxuICAgICAgICByZXR1cm4gZ2VuZXJhdGVQYXRjaGVzRnJvbUFzc2lnbmVkKFxuICAgICAgICAgIHN0YXRlLFxuICAgICAgICAgIGJhc2VQYXRoLFxuICAgICAgICAgIHBhdGNoZXNfLFxuICAgICAgICAgIGludmVyc2VQYXRjaGVzX1xuICAgICAgICApO1xuICAgICAgY2FzZSAxIC8qIEFycmF5ICovOlxuICAgICAgICByZXR1cm4gZ2VuZXJhdGVBcnJheVBhdGNoZXMoXG4gICAgICAgICAgc3RhdGUsXG4gICAgICAgICAgYmFzZVBhdGgsXG4gICAgICAgICAgcGF0Y2hlc18sXG4gICAgICAgICAgaW52ZXJzZVBhdGNoZXNfXG4gICAgICAgICk7XG4gICAgICBjYXNlIDMgLyogU2V0ICovOlxuICAgICAgICByZXR1cm4gZ2VuZXJhdGVTZXRQYXRjaGVzKFxuICAgICAgICAgIHN0YXRlLFxuICAgICAgICAgIGJhc2VQYXRoLFxuICAgICAgICAgIHBhdGNoZXNfLFxuICAgICAgICAgIGludmVyc2VQYXRjaGVzX1xuICAgICAgICApO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBnZW5lcmF0ZUFycmF5UGF0Y2hlcyhzdGF0ZSwgYmFzZVBhdGgsIHBhdGNoZXMsIGludmVyc2VQYXRjaGVzKSB7XG4gICAgbGV0IHsgYmFzZV8sIGFzc2lnbmVkXyB9ID0gc3RhdGU7XG4gICAgbGV0IGNvcHlfID0gc3RhdGUuY29weV87XG4gICAgaWYgKGNvcHlfLmxlbmd0aCA8IGJhc2VfLmxlbmd0aCkge1xuICAgICAgO1xuICAgICAgW2Jhc2VfLCBjb3B5X10gPSBbY29weV8sIGJhc2VfXTtcbiAgICAgIFtwYXRjaGVzLCBpbnZlcnNlUGF0Y2hlc10gPSBbaW52ZXJzZVBhdGNoZXMsIHBhdGNoZXNdO1xuICAgIH1cbiAgICBjb25zdCBhbGxSZWFzc2lnbmVkID0gc3RhdGUuYWxsSW5kaWNlc1JlYXNzaWduZWRfID09PSB0cnVlO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYmFzZV8ubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGNvcGllZEl0ZW0gPSBjb3B5X1tpXTtcbiAgICAgIGNvbnN0IGJhc2VJdGVtID0gYmFzZV9baV07XG4gICAgICBjb25zdCBpc0Fzc2lnbmVkID0gYWxsUmVhc3NpZ25lZCB8fCBhc3NpZ25lZF8/LmdldChpLnRvU3RyaW5nKCkpO1xuICAgICAgaWYgKGlzQXNzaWduZWQgJiYgY29waWVkSXRlbSAhPT0gYmFzZUl0ZW0pIHtcbiAgICAgICAgY29uc3QgY2hpbGRTdGF0ZSA9IGNvcGllZEl0ZW0/LltEUkFGVF9TVEFURV07XG4gICAgICAgIGlmIChjaGlsZFN0YXRlICYmIGNoaWxkU3RhdGUubW9kaWZpZWRfKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGF0aCA9IGJhc2VQYXRoLmNvbmNhdChbaV0pO1xuICAgICAgICBwYXRjaGVzLnB1c2goe1xuICAgICAgICAgIG9wOiBSRVBMQUNFLFxuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgLy8gTmVlZCB0byBtYXliZSBjbG9uZSBpdCwgYXMgaXQgY2FuIGluIGZhY3QgYmUgdGhlIG9yaWdpbmFsIHZhbHVlXG4gICAgICAgICAgLy8gZHVlIHRvIHRoZSBiYXNlL2NvcHkgaW52ZXJzaW9uIGF0IHRoZSBzdGFydCBvZiB0aGlzIGZ1bmN0aW9uXG4gICAgICAgICAgdmFsdWU6IGNsb25lUGF0Y2hWYWx1ZUlmTmVlZGVkKGNvcGllZEl0ZW0pXG4gICAgICAgIH0pO1xuICAgICAgICBpbnZlcnNlUGF0Y2hlcy5wdXNoKHtcbiAgICAgICAgICBvcDogUkVQTEFDRSxcbiAgICAgICAgICBwYXRoLFxuICAgICAgICAgIHZhbHVlOiBjbG9uZVBhdGNoVmFsdWVJZk5lZWRlZChiYXNlSXRlbSlcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSBiYXNlXy5sZW5ndGg7IGkgPCBjb3B5Xy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgcGF0aCA9IGJhc2VQYXRoLmNvbmNhdChbaV0pO1xuICAgICAgcGF0Y2hlcy5wdXNoKHtcbiAgICAgICAgb3A6IEFERCxcbiAgICAgICAgcGF0aCxcbiAgICAgICAgLy8gTmVlZCB0byBtYXliZSBjbG9uZSBpdCwgYXMgaXQgY2FuIGluIGZhY3QgYmUgdGhlIG9yaWdpbmFsIHZhbHVlXG4gICAgICAgIC8vIGR1ZSB0byB0aGUgYmFzZS9jb3B5IGludmVyc2lvbiBhdCB0aGUgc3RhcnQgb2YgdGhpcyBmdW5jdGlvblxuICAgICAgICB2YWx1ZTogY2xvbmVQYXRjaFZhbHVlSWZOZWVkZWQoY29weV9baV0pXG4gICAgICB9KTtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IGNvcHlfLmxlbmd0aCAtIDE7IGJhc2VfLmxlbmd0aCA8PSBpOyAtLWkpIHtcbiAgICAgIGNvbnN0IHBhdGggPSBiYXNlUGF0aC5jb25jYXQoW2ldKTtcbiAgICAgIGludmVyc2VQYXRjaGVzLnB1c2goe1xuICAgICAgICBvcDogUkVNT1ZFLFxuICAgICAgICBwYXRoXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gZ2VuZXJhdGVQYXRjaGVzRnJvbUFzc2lnbmVkKHN0YXRlLCBiYXNlUGF0aCwgcGF0Y2hlcywgaW52ZXJzZVBhdGNoZXMpIHtcbiAgICBjb25zdCB7IGJhc2VfLCBjb3B5XywgdHlwZV8gfSA9IHN0YXRlO1xuICAgIGVhY2goc3RhdGUuYXNzaWduZWRfLCAoa2V5LCBhc3NpZ25lZFZhbHVlKSA9PiB7XG4gICAgICBjb25zdCBvcmlnVmFsdWUgPSBnZXQoYmFzZV8sIGtleSwgdHlwZV8pO1xuICAgICAgY29uc3QgdmFsdWUgPSBnZXQoY29weV8sIGtleSwgdHlwZV8pO1xuICAgICAgY29uc3Qgb3AgPSAhYXNzaWduZWRWYWx1ZSA/IFJFTU9WRSA6IGhhcyhiYXNlXywga2V5KSA/IFJFUExBQ0UgOiBBREQ7XG4gICAgICBpZiAob3JpZ1ZhbHVlID09PSB2YWx1ZSAmJiBvcCA9PT0gUkVQTEFDRSlcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY29uc3QgcGF0aCA9IGJhc2VQYXRoLmNvbmNhdChrZXkpO1xuICAgICAgcGF0Y2hlcy5wdXNoKFxuICAgICAgICBvcCA9PT0gUkVNT1ZFID8geyBvcCwgcGF0aCB9IDogeyBvcCwgcGF0aCwgdmFsdWU6IGNsb25lUGF0Y2hWYWx1ZUlmTmVlZGVkKHZhbHVlKSB9XG4gICAgICApO1xuICAgICAgaW52ZXJzZVBhdGNoZXMucHVzaChcbiAgICAgICAgb3AgPT09IEFERCA/IHsgb3A6IFJFTU9WRSwgcGF0aCB9IDogb3AgPT09IFJFTU9WRSA/IHsgb3A6IEFERCwgcGF0aCwgdmFsdWU6IGNsb25lUGF0Y2hWYWx1ZUlmTmVlZGVkKG9yaWdWYWx1ZSkgfSA6IHsgb3A6IFJFUExBQ0UsIHBhdGgsIHZhbHVlOiBjbG9uZVBhdGNoVmFsdWVJZk5lZWRlZChvcmlnVmFsdWUpIH1cbiAgICAgICk7XG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gZ2VuZXJhdGVTZXRQYXRjaGVzKHN0YXRlLCBiYXNlUGF0aCwgcGF0Y2hlcywgaW52ZXJzZVBhdGNoZXMpIHtcbiAgICBsZXQgeyBiYXNlXywgY29weV8gfSA9IHN0YXRlO1xuICAgIGxldCBpID0gMDtcbiAgICBiYXNlXy5mb3JFYWNoKCh2YWx1ZSkgPT4ge1xuICAgICAgaWYgKCFjb3B5Xy5oYXModmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IHBhdGggPSBiYXNlUGF0aC5jb25jYXQoW2ldKTtcbiAgICAgICAgcGF0Y2hlcy5wdXNoKHtcbiAgICAgICAgICBvcDogUkVNT1ZFLFxuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgdmFsdWVcbiAgICAgICAgfSk7XG4gICAgICAgIGludmVyc2VQYXRjaGVzLnVuc2hpZnQoe1xuICAgICAgICAgIG9wOiBBREQsXG4gICAgICAgICAgcGF0aCxcbiAgICAgICAgICB2YWx1ZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGkrKztcbiAgICB9KTtcbiAgICBpID0gMDtcbiAgICBjb3B5Xy5mb3JFYWNoKCh2YWx1ZSkgPT4ge1xuICAgICAgaWYgKCFiYXNlXy5oYXModmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IHBhdGggPSBiYXNlUGF0aC5jb25jYXQoW2ldKTtcbiAgICAgICAgcGF0Y2hlcy5wdXNoKHtcbiAgICAgICAgICBvcDogQURELFxuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgdmFsdWVcbiAgICAgICAgfSk7XG4gICAgICAgIGludmVyc2VQYXRjaGVzLnVuc2hpZnQoe1xuICAgICAgICAgIG9wOiBSRU1PVkUsXG4gICAgICAgICAgcGF0aCxcbiAgICAgICAgICB2YWx1ZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGkrKztcbiAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBnZW5lcmF0ZVJlcGxhY2VtZW50UGF0Y2hlc18oYmFzZVZhbHVlLCByZXBsYWNlbWVudCwgc2NvcGUpIHtcbiAgICBjb25zdCB7IHBhdGNoZXNfLCBpbnZlcnNlUGF0Y2hlc18gfSA9IHNjb3BlO1xuICAgIHBhdGNoZXNfLnB1c2goe1xuICAgICAgb3A6IFJFUExBQ0UsXG4gICAgICBwYXRoOiBbXSxcbiAgICAgIHZhbHVlOiByZXBsYWNlbWVudCA9PT0gTk9USElORyA/IHZvaWQgMCA6IHJlcGxhY2VtZW50XG4gICAgfSk7XG4gICAgaW52ZXJzZVBhdGNoZXNfLnB1c2goe1xuICAgICAgb3A6IFJFUExBQ0UsXG4gICAgICBwYXRoOiBbXSxcbiAgICAgIHZhbHVlOiBiYXNlVmFsdWVcbiAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBhcHBseVBhdGNoZXNfKGRyYWZ0LCBwYXRjaGVzKSB7XG4gICAgcGF0Y2hlcy5mb3JFYWNoKChwYXRjaCkgPT4ge1xuICAgICAgY29uc3QgeyBwYXRoLCBvcCB9ID0gcGF0Y2g7XG4gICAgICBsZXQgYmFzZSA9IGRyYWZ0O1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICBjb25zdCBwYXJlbnRUeXBlID0gZ2V0QXJjaHR5cGUoYmFzZSk7XG4gICAgICAgIGxldCBwID0gcGF0aFtpXTtcbiAgICAgICAgaWYgKHR5cGVvZiBwICE9PSBcInN0cmluZ1wiICYmIHR5cGVvZiBwICE9PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgcCA9IFwiXCIgKyBwO1xuICAgICAgICB9XG4gICAgICAgIGlmICgocGFyZW50VHlwZSA9PT0gMCAvKiBPYmplY3QgKi8gfHwgcGFyZW50VHlwZSA9PT0gMSAvKiBBcnJheSAqLykgJiYgKHAgPT09IFwiX19wcm90b19fXCIgfHwgcCA9PT0gQ09OU1RSVUNUT1IpKVxuICAgICAgICAgIGRpZShlcnJvck9mZnNldCArIDMpO1xuICAgICAgICBpZiAoaXNGdW5jdGlvbihiYXNlKSAmJiBwID09PSBQUk9UT1RZUEUpXG4gICAgICAgICAgZGllKGVycm9yT2Zmc2V0ICsgMyk7XG4gICAgICAgIGJhc2UgPSBnZXQoYmFzZSwgcCk7XG4gICAgICAgIGlmIChiYXNlID09PSBudWxsIHx8ICFpc09iamVjdGlzaChiYXNlKSlcbiAgICAgICAgICBkaWUoZXJyb3JPZmZzZXQgKyAyLCBwYXRoLmpvaW4oXCIvXCIpKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHR5cGUgPSBnZXRBcmNodHlwZShiYXNlKTtcbiAgICAgIGNvbnN0IHZhbHVlID0gZGVlcENsb25lUGF0Y2hWYWx1ZShwYXRjaC52YWx1ZSk7XG4gICAgICBjb25zdCBrZXkgPSBwYXRoW3BhdGgubGVuZ3RoIC0gMV07XG4gICAgICBzd2l0Y2ggKG9wKSB7XG4gICAgICAgIGNhc2UgUkVQTEFDRTpcbiAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgMiAvKiBNYXAgKi86XG4gICAgICAgICAgICAgIHJldHVybiBiYXNlLnNldChrZXksIHZhbHVlKTtcbiAgICAgICAgICAgIGNhc2UgMyAvKiBTZXQgKi86XG4gICAgICAgICAgICAgIGRpZShlcnJvck9mZnNldCk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICByZXR1cm4gYmFzZVtrZXldID0gdmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICBjYXNlIEFERDpcbiAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgMSAvKiBBcnJheSAqLzpcbiAgICAgICAgICAgICAgcmV0dXJuIGtleSA9PT0gXCItXCIgPyBiYXNlLnB1c2godmFsdWUpIDogYmFzZS5zcGxpY2Uoa2V5LCAwLCB2YWx1ZSk7XG4gICAgICAgICAgICBjYXNlIDIgLyogTWFwICovOlxuICAgICAgICAgICAgICByZXR1cm4gYmFzZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICAgICAgICBjYXNlIDMgLyogU2V0ICovOlxuICAgICAgICAgICAgICByZXR1cm4gYmFzZS5hZGQodmFsdWUpO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgcmV0dXJuIGJhc2Vba2V5XSA9IHZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgY2FzZSBSRU1PVkU6XG4gICAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgICBjYXNlIDEgLyogQXJyYXkgKi86XG4gICAgICAgICAgICAgIHJldHVybiBiYXNlLnNwbGljZShrZXksIDEpO1xuICAgICAgICAgICAgY2FzZSAyIC8qIE1hcCAqLzpcbiAgICAgICAgICAgICAgcmV0dXJuIGJhc2UuZGVsZXRlKGtleSk7XG4gICAgICAgICAgICBjYXNlIDMgLyogU2V0ICovOlxuICAgICAgICAgICAgICByZXR1cm4gYmFzZS5kZWxldGUocGF0Y2gudmFsdWUpO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgcmV0dXJuIGRlbGV0ZSBiYXNlW2tleV07XG4gICAgICAgICAgfVxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIGRpZShlcnJvck9mZnNldCArIDEsIG9wKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gZHJhZnQ7XG4gIH1cbiAgZnVuY3Rpb24gZGVlcENsb25lUGF0Y2hWYWx1ZShvYmopIHtcbiAgICBpZiAoIWlzRHJhZnRhYmxlKG9iaikpXG4gICAgICByZXR1cm4gb2JqO1xuICAgIGlmIChpc0FycmF5KG9iaikpXG4gICAgICByZXR1cm4gb2JqLm1hcChkZWVwQ2xvbmVQYXRjaFZhbHVlKTtcbiAgICBpZiAoaXNNYXAob2JqKSlcbiAgICAgIHJldHVybiBuZXcgTWFwKFxuICAgICAgICBBcnJheS5mcm9tKG9iai5lbnRyaWVzKCkpLm1hcCgoW2ssIHZdKSA9PiBbaywgZGVlcENsb25lUGF0Y2hWYWx1ZSh2KV0pXG4gICAgICApO1xuICAgIGlmIChpc1NldChvYmopKVxuICAgICAgcmV0dXJuIG5ldyBTZXQoQXJyYXkuZnJvbShvYmopLm1hcChkZWVwQ2xvbmVQYXRjaFZhbHVlKSk7XG4gICAgY29uc3QgY2xvbmVkID0gT2JqZWN0LmNyZWF0ZShnZXRQcm90b3R5cGVPZihvYmopKTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBvYmopXG4gICAgICBjbG9uZWRba2V5XSA9IGRlZXBDbG9uZVBhdGNoVmFsdWUob2JqW2tleV0pO1xuICAgIGlmIChoYXMob2JqLCBEUkFGVEFCTEUpKVxuICAgICAgY2xvbmVkW0RSQUZUQUJMRV0gPSBvYmpbRFJBRlRBQkxFXTtcbiAgICByZXR1cm4gY2xvbmVkO1xuICB9XG4gIGZ1bmN0aW9uIGNsb25lUGF0Y2hWYWx1ZUlmTmVlZGVkKG9iaikge1xuICAgIGlmIChpc0RyYWZ0KG9iaikpIHtcbiAgICAgIHJldHVybiBkZWVwQ2xvbmVQYXRjaFZhbHVlKG9iaik7XG4gICAgfSBlbHNlXG4gICAgICByZXR1cm4gb2JqO1xuICB9XG4gIGxvYWRQbHVnaW4oUGx1Z2luUGF0Y2hlcywge1xuICAgIGFwcGx5UGF0Y2hlc18sXG4gICAgZ2VuZXJhdGVQYXRjaGVzXyxcbiAgICBnZW5lcmF0ZVJlcGxhY2VtZW50UGF0Y2hlc18sXG4gICAgZ2V0UGF0aFxuICB9KTtcbn1cblxuLy8gc3JjL3BsdWdpbnMvbWFwc2V0LnRzXG52YXIgX2dsb2JhbEl0ZXJhdG9yID0gZ2xvYmFsVGhpcy5JdGVyYXRvcjtcbnZhciBoYXNJdGVyYXRvckZyb20gPSB0eXBlb2YgX2dsb2JhbEl0ZXJhdG9yPy5mcm9tID09PSBcImZ1bmN0aW9uXCI7XG5mdW5jdGlvbiBlbmFibGVNYXBTZXQoKSB7XG4gIGNsYXNzIERyYWZ0TWFwIGV4dGVuZHMgTWFwIHtcbiAgICBjb25zdHJ1Y3Rvcih0YXJnZXQsIHBhcmVudCkge1xuICAgICAgc3VwZXIoKTtcbiAgICAgIHRoaXNbRFJBRlRfU1RBVEVdID0ge1xuICAgICAgICB0eXBlXzogMiAvKiBNYXAgKi8sXG4gICAgICAgIHBhcmVudF86IHBhcmVudCxcbiAgICAgICAgc2NvcGVfOiBwYXJlbnQgPyBwYXJlbnQuc2NvcGVfIDogZ2V0Q3VycmVudFNjb3BlKCksXG4gICAgICAgIG1vZGlmaWVkXzogZmFsc2UsXG4gICAgICAgIGZpbmFsaXplZF86IGZhbHNlLFxuICAgICAgICBjb3B5Xzogdm9pZCAwLFxuICAgICAgICBhc3NpZ25lZF86IHZvaWQgMCxcbiAgICAgICAgYmFzZV86IHRhcmdldCxcbiAgICAgICAgZHJhZnRfOiB0aGlzLFxuICAgICAgICBpc01hbnVhbF86IGZhbHNlLFxuICAgICAgICByZXZva2VkXzogZmFsc2UsXG4gICAgICAgIGNhbGxiYWNrc186IFtdXG4gICAgICB9O1xuICAgIH1cbiAgICBnZXQgc2l6ZSgpIHtcbiAgICAgIHJldHVybiBsYXRlc3QodGhpc1tEUkFGVF9TVEFURV0pLnNpemU7XG4gICAgfVxuICAgIGhhcyhrZXkpIHtcbiAgICAgIHJldHVybiBsYXRlc3QodGhpc1tEUkFGVF9TVEFURV0pLmhhcyhrZXkpO1xuICAgIH1cbiAgICBzZXQoa2V5LCB2YWx1ZSkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBpZiAoIWxhdGVzdChzdGF0ZSkuaGFzKGtleSkgfHwgbGF0ZXN0KHN0YXRlKS5nZXQoa2V5KSAhPT0gdmFsdWUpIHtcbiAgICAgICAgcHJlcGFyZU1hcENvcHkoc3RhdGUpO1xuICAgICAgICBtYXJrQ2hhbmdlZChzdGF0ZSk7XG4gICAgICAgIHN0YXRlLmFzc2lnbmVkXy5zZXQoa2V5LCB0cnVlKTtcbiAgICAgICAgc3RhdGUuY29weV8uc2V0KGtleSwgdmFsdWUpO1xuICAgICAgICBzdGF0ZS5hc3NpZ25lZF8uc2V0KGtleSwgdHJ1ZSk7XG4gICAgICAgIGhhbmRsZUNyb3NzUmVmZXJlbmNlKHN0YXRlLCBrZXksIHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBkZWxldGUoa2V5KSB7XG4gICAgICBpZiAoIXRoaXMuaGFzKGtleSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBwcmVwYXJlTWFwQ29weShzdGF0ZSk7XG4gICAgICBtYXJrQ2hhbmdlZChzdGF0ZSk7XG4gICAgICBpZiAoc3RhdGUuYmFzZV8uaGFzKGtleSkpIHtcbiAgICAgICAgc3RhdGUuYXNzaWduZWRfLnNldChrZXksIGZhbHNlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0YXRlLmFzc2lnbmVkXy5kZWxldGUoa2V5KTtcbiAgICAgIH1cbiAgICAgIHN0YXRlLmNvcHlfLmRlbGV0ZShrZXkpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGNsZWFyKCkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBpZiAobGF0ZXN0KHN0YXRlKS5zaXplKSB7XG4gICAgICAgIHByZXBhcmVNYXBDb3B5KHN0YXRlKTtcbiAgICAgICAgbWFya0NoYW5nZWQoc3RhdGUpO1xuICAgICAgICBzdGF0ZS5hc3NpZ25lZF8gPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgICAgICBlYWNoKHN0YXRlLmJhc2VfLCAoa2V5KSA9PiB7XG4gICAgICAgICAgc3RhdGUuYXNzaWduZWRfLnNldChrZXksIGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHN0YXRlLmNvcHlfLmNsZWFyKCk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvckVhY2goY2IsIHRoaXNBcmcpIHtcbiAgICAgIGNvbnN0IHN0YXRlID0gdGhpc1tEUkFGVF9TVEFURV07XG4gICAgICBsYXRlc3Qoc3RhdGUpLmZvckVhY2goKF92YWx1ZSwga2V5LCBfbWFwKSA9PiB7XG4gICAgICAgIGNiLmNhbGwodGhpc0FyZywgdGhpcy5nZXQoa2V5KSwga2V5LCB0aGlzKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBnZXQoa2V5KSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIGNvbnN0IHZhbHVlID0gbGF0ZXN0KHN0YXRlKS5nZXQoa2V5KTtcbiAgICAgIGlmIChzdGF0ZS5maW5hbGl6ZWRfIHx8ICFpc0RyYWZ0YWJsZSh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlICE9PSBzdGF0ZS5iYXNlXy5nZXQoa2V5KSkge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9XG4gICAgICBjb25zdCBkcmFmdCA9IGNyZWF0ZVByb3h5KHN0YXRlLnNjb3BlXywgdmFsdWUsIHN0YXRlLCBrZXkpO1xuICAgICAgcHJlcGFyZU1hcENvcHkoc3RhdGUpO1xuICAgICAgc3RhdGUuY29weV8uc2V0KGtleSwgZHJhZnQpO1xuICAgICAgcmV0dXJuIGRyYWZ0O1xuICAgIH1cbiAgICBrZXlzKCkge1xuICAgICAgcmV0dXJuIGxhdGVzdCh0aGlzW0RSQUZUX1NUQVRFXSkua2V5cygpO1xuICAgIH1cbiAgICB2YWx1ZXMoKSB7XG4gICAgICBjb25zdCBpdGVyYXRvciA9IHRoaXMua2V5cygpO1xuICAgICAgcmV0dXJuIGl0ZXJhdG9yRnJvbSh7XG4gICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICBjb25zdCByID0gaXRlcmF0b3IubmV4dCgpO1xuICAgICAgICAgIGlmIChyLmRvbmUpXG4gICAgICAgICAgICByZXR1cm4gcjtcbiAgICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0KHIudmFsdWUpO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBkb25lOiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGVudHJpZXMoKSB7XG4gICAgICBjb25zdCBpdGVyYXRvciA9IHRoaXMua2V5cygpO1xuICAgICAgcmV0dXJuIGl0ZXJhdG9yRnJvbSh7XG4gICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICBjb25zdCByID0gaXRlcmF0b3IubmV4dCgpO1xuICAgICAgICAgIGlmIChyLmRvbmUpXG4gICAgICAgICAgICByZXR1cm4gcjtcbiAgICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0KHIudmFsdWUpO1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBkb25lOiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlOiBbci52YWx1ZSwgdmFsdWVdXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIFsoRFJBRlRfU1RBVEUsIFN5bWJvbC5pdGVyYXRvcildKCkge1xuICAgICAgcmV0dXJuIHRoaXMuZW50cmllcygpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBpdGVyYXRvckZyb20oaXRlcmFibGUpIHtcbiAgICBpZiAoaGFzSXRlcmF0b3JGcm9tKSB7XG4gICAgICByZXR1cm4gX2dsb2JhbEl0ZXJhdG9yLmZyb20oaXRlcmFibGUpO1xuICAgIH1cbiAgICBjb25zdCBpdGVyYXRvciA9IHtcbiAgICAgIC4uLml0ZXJhYmxlLFxuICAgICAgW1N5bWJvbC5pdGVyYXRvcl06ICgpID0+IGl0ZXJhdG9yXG4gICAgfTtcbiAgICByZXR1cm4gaXRlcmF0b3I7XG4gIH1cbiAgZnVuY3Rpb24gcHJveHlNYXBfKHRhcmdldCwgcGFyZW50KSB7XG4gICAgY29uc3QgbWFwID0gbmV3IERyYWZ0TWFwKHRhcmdldCwgcGFyZW50KTtcbiAgICByZXR1cm4gW21hcCwgbWFwW0RSQUZUX1NUQVRFXV07XG4gIH1cbiAgZnVuY3Rpb24gcHJlcGFyZU1hcENvcHkoc3RhdGUpIHtcbiAgICBpZiAoIXN0YXRlLmNvcHlfKSB7XG4gICAgICBzdGF0ZS5hc3NpZ25lZF8gPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgICAgc3RhdGUuY29weV8gPSBuZXcgTWFwKHN0YXRlLmJhc2VfKTtcbiAgICB9XG4gIH1cbiAgY2xhc3MgRHJhZnRTZXQgZXh0ZW5kcyBTZXQge1xuICAgIGNvbnN0cnVjdG9yKHRhcmdldCwgcGFyZW50KSB7XG4gICAgICBzdXBlcigpO1xuICAgICAgdGhpc1tEUkFGVF9TVEFURV0gPSB7XG4gICAgICAgIHR5cGVfOiAzIC8qIFNldCAqLyxcbiAgICAgICAgcGFyZW50XzogcGFyZW50LFxuICAgICAgICBzY29wZV86IHBhcmVudCA/IHBhcmVudC5zY29wZV8gOiBnZXRDdXJyZW50U2NvcGUoKSxcbiAgICAgICAgbW9kaWZpZWRfOiBmYWxzZSxcbiAgICAgICAgZmluYWxpemVkXzogZmFsc2UsXG4gICAgICAgIGNvcHlfOiB2b2lkIDAsXG4gICAgICAgIGJhc2VfOiB0YXJnZXQsXG4gICAgICAgIGRyYWZ0XzogdGhpcyxcbiAgICAgICAgZHJhZnRzXzogLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSxcbiAgICAgICAgcmV2b2tlZF86IGZhbHNlLFxuICAgICAgICBpc01hbnVhbF86IGZhbHNlLFxuICAgICAgICBhc3NpZ25lZF86IHZvaWQgMCxcbiAgICAgICAgY2FsbGJhY2tzXzogW11cbiAgICAgIH07XG4gICAgfVxuICAgIGdldCBzaXplKCkge1xuICAgICAgcmV0dXJuIGxhdGVzdCh0aGlzW0RSQUZUX1NUQVRFXSkuc2l6ZTtcbiAgICB9XG4gICAgaGFzKHZhbHVlKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIGlmICghc3RhdGUuY29weV8pIHtcbiAgICAgICAgcmV0dXJuIHN0YXRlLmJhc2VfLmhhcyh2YWx1ZSk7XG4gICAgICB9XG4gICAgICBpZiAoc3RhdGUuY29weV8uaGFzKHZhbHVlKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICBpZiAoc3RhdGUuZHJhZnRzXy5oYXModmFsdWUpICYmIHN0YXRlLmNvcHlfLmhhcyhzdGF0ZS5kcmFmdHNfLmdldCh2YWx1ZSkpKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgYWRkKHZhbHVlKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIGlmICghdGhpcy5oYXModmFsdWUpKSB7XG4gICAgICAgIHByZXBhcmVTZXRDb3B5KHN0YXRlKTtcbiAgICAgICAgbWFya0NoYW5nZWQoc3RhdGUpO1xuICAgICAgICBzdGF0ZS5jb3B5Xy5hZGQodmFsdWUpO1xuICAgICAgICBoYW5kbGVDcm9zc1JlZmVyZW5jZShzdGF0ZSwgdmFsdWUsIHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBkZWxldGUodmFsdWUpIHtcbiAgICAgIGlmICghdGhpcy5oYXModmFsdWUpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHN0YXRlID0gdGhpc1tEUkFGVF9TVEFURV07XG4gICAgICBhc3NlcnRVbnJldm9rZWQoc3RhdGUpO1xuICAgICAgcHJlcGFyZVNldENvcHkoc3RhdGUpO1xuICAgICAgbWFya0NoYW5nZWQoc3RhdGUpO1xuICAgICAgcmV0dXJuIHN0YXRlLmNvcHlfLmRlbGV0ZSh2YWx1ZSkgfHwgKHN0YXRlLmRyYWZ0c18uaGFzKHZhbHVlKSA/IHN0YXRlLmNvcHlfLmRlbGV0ZShzdGF0ZS5kcmFmdHNfLmdldCh2YWx1ZSkpIDogKFxuICAgICAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuICAgICAgICBmYWxzZVxuICAgICAgKSk7XG4gICAgfVxuICAgIGNsZWFyKCkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBpZiAobGF0ZXN0KHN0YXRlKS5zaXplKSB7XG4gICAgICAgIHByZXBhcmVTZXRDb3B5KHN0YXRlKTtcbiAgICAgICAgbWFya0NoYW5nZWQoc3RhdGUpO1xuICAgICAgICBzdGF0ZS5jb3B5Xy5jbGVhcigpO1xuICAgICAgfVxuICAgIH1cbiAgICB2YWx1ZXMoKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIHByZXBhcmVTZXRDb3B5KHN0YXRlKTtcbiAgICAgIHJldHVybiBzdGF0ZS5jb3B5Xy52YWx1ZXMoKTtcbiAgICB9XG4gICAgZW50cmllcygpIHtcbiAgICAgIGNvbnN0IHN0YXRlID0gdGhpc1tEUkFGVF9TVEFURV07XG4gICAgICBhc3NlcnRVbnJldm9rZWQoc3RhdGUpO1xuICAgICAgcHJlcGFyZVNldENvcHkoc3RhdGUpO1xuICAgICAgcmV0dXJuIHN0YXRlLmNvcHlfLmVudHJpZXMoKTtcbiAgICB9XG4gICAga2V5cygpIHtcbiAgICAgIHJldHVybiB0aGlzLnZhbHVlcygpO1xuICAgIH1cbiAgICBbKERSQUZUX1NUQVRFLCBTeW1ib2wuaXRlcmF0b3IpXSgpIHtcbiAgICAgIHJldHVybiB0aGlzLnZhbHVlcygpO1xuICAgIH1cbiAgICBmb3JFYWNoKGNiLCB0aGlzQXJnKSB7XG4gICAgICBjb25zdCBpdGVyYXRvciA9IHRoaXMudmFsdWVzKCk7XG4gICAgICBsZXQgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpO1xuICAgICAgd2hpbGUgKCFyZXN1bHQuZG9uZSkge1xuICAgICAgICBjYi5jYWxsKHRoaXNBcmcsIHJlc3VsdC52YWx1ZSwgcmVzdWx0LnZhbHVlLCB0aGlzKTtcbiAgICAgICAgcmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBwcm94eVNldF8odGFyZ2V0LCBwYXJlbnQpIHtcbiAgICBjb25zdCBzZXQyID0gbmV3IERyYWZ0U2V0KHRhcmdldCwgcGFyZW50KTtcbiAgICByZXR1cm4gW3NldDIsIHNldDJbRFJBRlRfU1RBVEVdXTtcbiAgfVxuICBmdW5jdGlvbiBwcmVwYXJlU2V0Q29weShzdGF0ZSkge1xuICAgIGlmICghc3RhdGUuY29weV8pIHtcbiAgICAgIHN0YXRlLmNvcHlfID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgICAgIHN0YXRlLmJhc2VfLmZvckVhY2goKHZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChpc0RyYWZ0YWJsZSh2YWx1ZSkpIHtcbiAgICAgICAgICBjb25zdCBkcmFmdCA9IGNyZWF0ZVByb3h5KHN0YXRlLnNjb3BlXywgdmFsdWUsIHN0YXRlLCB2YWx1ZSk7XG4gICAgICAgICAgc3RhdGUuZHJhZnRzXy5zZXQodmFsdWUsIGRyYWZ0KTtcbiAgICAgICAgICBzdGF0ZS5jb3B5Xy5hZGQoZHJhZnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHN0YXRlLmNvcHlfLmFkZCh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBhc3NlcnRVbnJldm9rZWQoc3RhdGUpIHtcbiAgICBpZiAoc3RhdGUucmV2b2tlZF8pXG4gICAgICBkaWUoMywgSlNPTi5zdHJpbmdpZnkobGF0ZXN0KHN0YXRlKSkpO1xuICB9XG4gIGZ1bmN0aW9uIGZpeFNldENvbnRlbnRzKHRhcmdldCkge1xuICAgIGlmICh0YXJnZXQudHlwZV8gPT09IDMgLyogU2V0ICovICYmIHRhcmdldC5jb3B5Xykge1xuICAgICAgY29uc3QgY29weSA9IG5ldyBTZXQodGFyZ2V0LmNvcHlfKTtcbiAgICAgIHRhcmdldC5jb3B5Xy5jbGVhcigpO1xuICAgICAgY29weS5mb3JFYWNoKCh2YWx1ZSkgPT4ge1xuICAgICAgICB0YXJnZXQuY29weV8uYWRkKGdldFZhbHVlKHZhbHVlKSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgbG9hZFBsdWdpbihQbHVnaW5NYXBTZXQsIHsgcHJveHlNYXBfLCBwcm94eVNldF8sIGZpeFNldENvbnRlbnRzIH0pO1xufVxuXG4vLyBzcmMvcGx1Z2lucy9hcnJheU1ldGhvZHMudHNcbmZ1bmN0aW9uIGVuYWJsZUFycmF5TWV0aG9kcygpIHtcbiAgY29uc3QgU0hJRlRJTkdfTUVUSE9EUyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcInNoaWZ0XCIsIFwidW5zaGlmdFwiXSk7XG4gIGNvbnN0IFFVRVVFX01FVEhPRFMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbXCJwdXNoXCIsIFwicG9wXCJdKTtcbiAgY29uc3QgUkVTVUxUX1JFVFVSTklOR19NRVRIT0RTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuICAgIC4uLlFVRVVFX01FVEhPRFMsXG4gICAgLi4uU0hJRlRJTkdfTUVUSE9EU1xuICBdKTtcbiAgY29uc3QgUkVPUkRFUklOR19NRVRIT0RTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1wicmV2ZXJzZVwiLCBcInNvcnRcIl0pO1xuICBjb25zdCBNVVRBVElOR19NRVRIT0RTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuICAgIC4uLlJFU1VMVF9SRVRVUk5JTkdfTUVUSE9EUyxcbiAgICAuLi5SRU9SREVSSU5HX01FVEhPRFMsXG4gICAgXCJzcGxpY2VcIlxuICBdKTtcbiAgY29uc3QgRklORF9NRVRIT0RTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1wiZmluZFwiLCBcImZpbmRMYXN0XCJdKTtcbiAgY29uc3QgTk9OX01VVEFUSU5HX01FVEhPRFMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbXG4gICAgXCJmaWx0ZXJcIixcbiAgICBcInNsaWNlXCIsXG4gICAgXCJjb25jYXRcIixcbiAgICBcImZsYXRcIixcbiAgICAuLi5GSU5EX01FVEhPRFMsXG4gICAgXCJmaW5kSW5kZXhcIixcbiAgICBcImZpbmRMYXN0SW5kZXhcIixcbiAgICBcInNvbWVcIixcbiAgICBcImV2ZXJ5XCIsXG4gICAgXCJpbmRleE9mXCIsXG4gICAgXCJsYXN0SW5kZXhPZlwiLFxuICAgIFwiaW5jbHVkZXNcIixcbiAgICBcImpvaW5cIixcbiAgICBcInRvU3RyaW5nXCIsXG4gICAgXCJ0b0xvY2FsZVN0cmluZ1wiXG4gIF0pO1xuICBmdW5jdGlvbiBpc011dGF0aW5nQXJyYXlNZXRob2QobWV0aG9kKSB7XG4gICAgcmV0dXJuIE1VVEFUSU5HX01FVEhPRFMuaGFzKG1ldGhvZCk7XG4gIH1cbiAgZnVuY3Rpb24gaXNOb25NdXRhdGluZ0FycmF5TWV0aG9kKG1ldGhvZCkge1xuICAgIHJldHVybiBOT05fTVVUQVRJTkdfTUVUSE9EUy5oYXMobWV0aG9kKTtcbiAgfVxuICBmdW5jdGlvbiBpc0FycmF5T3BlcmF0aW9uTWV0aG9kKG1ldGhvZCkge1xuICAgIHJldHVybiBpc011dGF0aW5nQXJyYXlNZXRob2QobWV0aG9kKSB8fCBpc05vbk11dGF0aW5nQXJyYXlNZXRob2QobWV0aG9kKTtcbiAgfVxuICBmdW5jdGlvbiBlbnRlck9wZXJhdGlvbihzdGF0ZSwgbWV0aG9kKSB7XG4gICAgc3RhdGUub3BlcmF0aW9uTWV0aG9kID0gbWV0aG9kO1xuICB9XG4gIGZ1bmN0aW9uIGV4aXRPcGVyYXRpb24oc3RhdGUpIHtcbiAgICBzdGF0ZS5vcGVyYXRpb25NZXRob2QgPSB2b2lkIDA7XG4gIH1cbiAgZnVuY3Rpb24gZXhlY3V0ZUFycmF5TWV0aG9kKHN0YXRlLCBvcGVyYXRpb24sIG1hcmtMZW5ndGggPSB0cnVlKSB7XG4gICAgcHJlcGFyZUNvcHkoc3RhdGUpO1xuICAgIGNvbnN0IHJlc3VsdCA9IG9wZXJhdGlvbigpO1xuICAgIG1hcmtBcnJheUNoYW5nZWQoc3RhdGUsIG1hcmtMZW5ndGgpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgZnVuY3Rpb24gbWFya0FycmF5Q2hhbmdlZChzdGF0ZSwgbWFya0xlbmd0aCA9IHRydWUpIHtcbiAgICBtYXJrQ2hhbmdlZChzdGF0ZSk7XG4gICAgaWYgKG1hcmtMZW5ndGgpXG4gICAgICBzdGF0ZS5hc3NpZ25lZF8uc2V0KFwibGVuZ3RoXCIsIHRydWUpO1xuICB9XG4gIGZ1bmN0aW9uIG1hcmtBbGxJbmRpY2VzUmVhc3NpZ25lZChzdGF0ZSkge1xuICAgIHN0YXRlLmFsbEluZGljZXNSZWFzc2lnbmVkXyA9IHRydWU7XG4gICAgc3RhdGUuYmFzZVJlZnNfID0gbmV3IFNldChzdGF0ZS5iYXNlXyk7XG4gIH1cbiAgZnVuY3Rpb24gbm9ybWFsaXplU2xpY2VJbmRleChpbmRleCwgbGVuZ3RoKSB7XG4gICAgaWYgKGluZGV4IDwgMCkge1xuICAgICAgcmV0dXJuIE1hdGgubWF4KGxlbmd0aCArIGluZGV4LCAwKTtcbiAgICB9XG4gICAgcmV0dXJuIE1hdGgubWluKGluZGV4LCBsZW5ndGgpO1xuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZUluc2VydGVkVmFsdWVzKHN0YXRlLCBzdGFydEluZGV4LCB2YWx1ZXMpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlcy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgaW5kZXggPSBcIlwiICsgKHN0YXJ0SW5kZXggKyBpKTtcbiAgICAgIHN0YXRlLmFzc2lnbmVkXy5zZXQoaW5kZXgsIHRydWUpO1xuICAgICAgaGFuZGxlQ3Jvc3NSZWZlcmVuY2Uoc3RhdGUsIGluZGV4LCB2YWx1ZXNbaV0pO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVTaW1wbGVPcGVyYXRpb24oc3RhdGUsIG1ldGhvZCwgYXJncykge1xuICAgIGNvbnN0IGlzSW5zZXJ0ID0gbWV0aG9kID09PSBcInB1c2hcIiB8fCBtZXRob2QgPT09IFwidW5zaGlmdFwiO1xuICAgIGlmIChpc0luc2VydCA/IGFyZ3MubGVuZ3RoID09PSAwIDogbGF0ZXN0KHN0YXRlKS5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBpc0luc2VydCA/IGxhdGVzdChzdGF0ZSkubGVuZ3RoIDogdm9pZCAwO1xuICAgIH1cbiAgICBwcmVwYXJlQ29weShzdGF0ZSk7XG4gICAgY29uc3QgbGVuZ3RoQmVmb3JlID0gc3RhdGUuY29weV8ubGVuZ3RoO1xuICAgIGNvbnN0IHJlc3VsdCA9IHN0YXRlLmNvcHlfW21ldGhvZF0oLi4uYXJncyk7XG4gICAgbWFya0FycmF5Q2hhbmdlZChzdGF0ZSk7XG4gICAgaWYgKFNISUZUSU5HX01FVEhPRFMuaGFzKG1ldGhvZCkpIHtcbiAgICAgIG1hcmtBbGxJbmRpY2VzUmVhc3NpZ25lZChzdGF0ZSk7XG4gICAgfVxuICAgIGlmIChtZXRob2QgPT09IFwicHVzaFwiKSB7XG4gICAgICBoYW5kbGVJbnNlcnRlZFZhbHVlcyhzdGF0ZSwgbGVuZ3RoQmVmb3JlLCBhcmdzKTtcbiAgICB9IGVsc2UgaWYgKG1ldGhvZCA9PT0gXCJ1bnNoaWZ0XCIpIHtcbiAgICAgIGhhbmRsZUluc2VydGVkVmFsdWVzKHN0YXRlLCAwLCBhcmdzKTtcbiAgICB9XG4gICAgcmV0dXJuIFJFU1VMVF9SRVRVUk5JTkdfTUVUSE9EUy5oYXMobWV0aG9kKSA/IHJlc3VsdCA6IHN0YXRlLmRyYWZ0XztcbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVSZW9yZGVyaW5nT3BlcmF0aW9uKHN0YXRlLCBtZXRob2QsIGFyZ3MpIHtcbiAgICBpZiAobGF0ZXN0KHN0YXRlKS5sZW5ndGggPD0gMSlcbiAgICAgIHJldHVybiBzdGF0ZS5kcmFmdF87XG4gICAgcmV0dXJuIGV4ZWN1dGVBcnJheU1ldGhvZChcbiAgICAgIHN0YXRlLFxuICAgICAgKCkgPT4ge1xuICAgICAgICA7XG4gICAgICAgIHN0YXRlLmNvcHlfW21ldGhvZF0oLi4uYXJncyk7XG4gICAgICAgIG1hcmtBbGxJbmRpY2VzUmVhc3NpZ25lZChzdGF0ZSk7XG4gICAgICAgIHJldHVybiBzdGF0ZS5kcmFmdF87XG4gICAgICB9LFxuICAgICAgZmFsc2VcbiAgICApO1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZU1ldGhvZEludGVyY2VwdG9yKHN0YXRlLCBvcmlnaW5hbE1ldGhvZCkge1xuICAgIHJldHVybiBmdW5jdGlvbiBpbnRlcmNlcHRlZE1ldGhvZCguLi5hcmdzKSB7XG4gICAgICBjb25zdCBtZXRob2QgPSBvcmlnaW5hbE1ldGhvZDtcbiAgICAgIGVudGVyT3BlcmF0aW9uKHN0YXRlLCBtZXRob2QpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKGlzTXV0YXRpbmdBcnJheU1ldGhvZChtZXRob2QpKSB7XG4gICAgICAgICAgaWYgKFJFU1VMVF9SRVRVUk5JTkdfTUVUSE9EUy5oYXMobWV0aG9kKSkge1xuICAgICAgICAgICAgcmV0dXJuIGhhbmRsZVNpbXBsZU9wZXJhdGlvbihzdGF0ZSwgbWV0aG9kLCBhcmdzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKFJFT1JERVJJTkdfTUVUSE9EUy5oYXMobWV0aG9kKSkge1xuICAgICAgICAgICAgcmV0dXJuIGhhbmRsZVJlb3JkZXJpbmdPcGVyYXRpb24oc3RhdGUsIG1ldGhvZCwgYXJncyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChtZXRob2QgPT09IFwic3BsaWNlXCIpIHtcbiAgICAgICAgICAgIGNvbnN0IGluc2VydENvdW50ID0gYXJncy5sZW5ndGggPiAyID8gYXJncy5sZW5ndGggLSAyIDogMDtcbiAgICAgICAgICAgIGlmIChpbnNlcnRDb3VudCA9PT0gMCkge1xuICAgICAgICAgICAgICBjb25zdCBsZW5ndGggPSBsYXRlc3Qoc3RhdGUpLmxlbmd0aDtcbiAgICAgICAgICAgICAgaWYgKGFyZ3MubGVuZ3RoID09PSAwIHx8IG5vcm1hbGl6ZVNsaWNlSW5kZXgoYXJnc1swXSA/PyAwLCBsZW5ndGgpID09PSBsZW5ndGggfHwgYXJncy5sZW5ndGggPiAxICYmICEoYXJnc1sxXSA+PSAxKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcHJlcGFyZUNvcHkoc3RhdGUpO1xuICAgICAgICAgICAgY29uc3QgcmVzID0gc3RhdGUuY29weV8uc3BsaWNlKFxuICAgICAgICAgICAgICAuLi5hcmdzXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgaWYgKHJlcy5sZW5ndGggPT09IDAgJiYgaW5zZXJ0Q291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG1hcmtBcnJheUNoYW5nZWQoc3RhdGUpO1xuICAgICAgICAgICAgbWFya0FsbEluZGljZXNSZWFzc2lnbmVkKHN0YXRlKTtcbiAgICAgICAgICAgIGlmIChpbnNlcnRDb3VudCA+IDApIHtcbiAgICAgICAgICAgICAgY29uc3Qgc3RhcnRJbmRleCA9IG5vcm1hbGl6ZVNsaWNlSW5kZXgoXG4gICAgICAgICAgICAgICAgYXJnc1swXSA/PyAwLFxuICAgICAgICAgICAgICAgIHN0YXRlLmNvcHlfLmxlbmd0aFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBoYW5kbGVJbnNlcnRlZFZhbHVlcyhzdGF0ZSwgc3RhcnRJbmRleCwgYXJncy5zbGljZSgyKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gaGFuZGxlTm9uTXV0YXRpbmdPcGVyYXRpb24oc3RhdGUsIG1ldGhvZCwgYXJncyk7XG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGV4aXRPcGVyYXRpb24oc3RhdGUpO1xuICAgICAgfVxuICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlTm9uTXV0YXRpbmdPcGVyYXRpb24oc3RhdGUsIG1ldGhvZCwgYXJncykge1xuICAgIGNvbnN0IHNvdXJjZSA9IGxhdGVzdChzdGF0ZSk7XG4gICAgaWYgKG1ldGhvZCA9PT0gXCJmaWx0ZXJcIikge1xuICAgICAgY29uc3QgcHJlZGljYXRlID0gYXJnc1swXTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzb3VyY2UubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKHByZWRpY2F0ZShzb3VyY2VbaV0sIGksIHNvdXJjZSkpIHtcbiAgICAgICAgICByZXN1bHQucHVzaChzdGF0ZS5kcmFmdF9baV0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBpZiAoRklORF9NRVRIT0RTLmhhcyhtZXRob2QpKSB7XG4gICAgICBjb25zdCBwcmVkaWNhdGUgPSBhcmdzWzBdO1xuICAgICAgY29uc3QgaXNGb3J3YXJkID0gbWV0aG9kID09PSBcImZpbmRcIjtcbiAgICAgIGNvbnN0IHN0ZXAgPSBpc0ZvcndhcmQgPyAxIDogLTE7XG4gICAgICBjb25zdCBzdGFydCA9IGlzRm9yd2FyZCA/IDAgOiBzb3VyY2UubGVuZ3RoIC0gMTtcbiAgICAgIGZvciAobGV0IGkgPSBzdGFydDsgaSA+PSAwICYmIGkgPCBzb3VyY2UubGVuZ3RoOyBpICs9IHN0ZXApIHtcbiAgICAgICAgaWYgKHByZWRpY2F0ZShzb3VyY2VbaV0sIGksIHNvdXJjZSkpIHtcbiAgICAgICAgICByZXR1cm4gc3RhdGUuZHJhZnRfW2ldO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICBpZiAobWV0aG9kID09PSBcInNsaWNlXCIpIHtcbiAgICAgIGNvbnN0IHJhd1N0YXJ0ID0gYXJnc1swXSA/PyAwO1xuICAgICAgY29uc3QgcmF3RW5kID0gYXJnc1sxXSA/PyBzb3VyY2UubGVuZ3RoO1xuICAgICAgY29uc3Qgc3RhcnQgPSBub3JtYWxpemVTbGljZUluZGV4KHJhd1N0YXJ0LCBzb3VyY2UubGVuZ3RoKTtcbiAgICAgIGNvbnN0IGVuZCA9IG5vcm1hbGl6ZVNsaWNlSW5kZXgocmF3RW5kLCBzb3VyY2UubGVuZ3RoKTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgZW5kOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LnB1c2goc3RhdGUuZHJhZnRfW2ldKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIHJldHVybiBzb3VyY2VbbWV0aG9kXSguLi5hcmdzKTtcbiAgfVxuICBsb2FkUGx1Z2luKFBsdWdpbkFycmF5TWV0aG9kcywge1xuICAgIGNyZWF0ZU1ldGhvZEludGVyY2VwdG9yLFxuICAgIGlzQXJyYXlPcGVyYXRpb25NZXRob2QsXG4gICAgaXNNdXRhdGluZ0FycmF5TWV0aG9kXG4gIH0pO1xufVxuXG4vLyBzcmMvaW1tZXIudHNcbnZhciBpbW1lciA9IG5ldyBJbW1lcjIoKTtcbnZhciBwcm9kdWNlID0gaW1tZXIucHJvZHVjZTtcbnZhciBwcm9kdWNlV2l0aFBhdGNoZXMgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIucHJvZHVjZVdpdGhQYXRjaGVzLmJpbmQoaW1tZXIpO1xudmFyIHNldEF1dG9GcmVlemUgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuc2V0QXV0b0ZyZWV6ZS5iaW5kKGltbWVyKTtcbnZhciBzZXRVc2VTdHJpY3RTaGFsbG93Q29weSA9IC8qIEBfX1BVUkVfXyAqLyBpbW1lci5zZXRVc2VTdHJpY3RTaGFsbG93Q29weS5iaW5kKGltbWVyKTtcbnZhciBzZXRVc2VTdHJpY3RJdGVyYXRpb24gPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuc2V0VXNlU3RyaWN0SXRlcmF0aW9uLmJpbmQoaW1tZXIpO1xudmFyIGFwcGx5UGF0Y2hlcyA9IC8qIEBfX1BVUkVfXyAqLyBpbW1lci5hcHBseVBhdGNoZXMuYmluZChpbW1lcik7XG52YXIgY3JlYXRlRHJhZnQgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuY3JlYXRlRHJhZnQuYmluZChpbW1lcik7XG52YXIgZmluaXNoRHJhZnQgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuZmluaXNoRHJhZnQuYmluZChpbW1lcik7XG52YXIgY2FzdERyYWZ0ID0gKHZhbHVlKSA9PiB2YWx1ZTtcbnZhciBjYXN0SW1tdXRhYmxlID0gKHZhbHVlKSA9PiB2YWx1ZTtcbmV4cG9ydCB7XG4gIEltbWVyMiBhcyBJbW1lcixcbiAgYXBwbHlQYXRjaGVzLFxuICBjYXN0RHJhZnQsXG4gIGNhc3RJbW11dGFibGUsXG4gIGNyZWF0ZURyYWZ0LFxuICBjdXJyZW50LFxuICBlbmFibGVBcnJheU1ldGhvZHMsXG4gIGVuYWJsZU1hcFNldCxcbiAgZW5hYmxlUGF0Y2hlcyxcbiAgZmluaXNoRHJhZnQsXG4gIGZyZWV6ZSxcbiAgRFJBRlRBQkxFIGFzIGltbWVyYWJsZSxcbiAgaXNEcmFmdCxcbiAgaXNEcmFmdGFibGUsXG4gIE5PVEhJTkcgYXMgbm90aGluZyxcbiAgb3JpZ2luYWwsXG4gIHByb2R1Y2UsXG4gIHByb2R1Y2VXaXRoUGF0Y2hlcyxcbiAgc2V0QXV0b0ZyZWV6ZSxcbiAgc2V0VXNlU3RyaWN0SXRlcmF0aW9uLFxuICBzZXRVc2VTdHJpY3RTaGFsbG93Q29weVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWltbWVyLm1qcy5tYXAiLCIvLyBzcmMvaW5kZXgudHNcbmZ1bmN0aW9uIGNyZWF0ZVRodW5rTWlkZGxld2FyZShleHRyYUFyZ3VtZW50KSB7XG4gIGNvbnN0IG1pZGRsZXdhcmUgPSAoeyBkaXNwYXRjaCwgZ2V0U3RhdGUgfSkgPT4gKG5leHQpID0+IChhY3Rpb24pID0+IHtcbiAgICBpZiAodHlwZW9mIGFjdGlvbiA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICByZXR1cm4gYWN0aW9uKGRpc3BhdGNoLCBnZXRTdGF0ZSwgZXh0cmFBcmd1bWVudCk7XG4gICAgfVxuICAgIHJldHVybiBuZXh0KGFjdGlvbik7XG4gIH07XG4gIHJldHVybiBtaWRkbGV3YXJlO1xufVxudmFyIHRodW5rID0gY3JlYXRlVGh1bmtNaWRkbGV3YXJlKCk7XG52YXIgd2l0aEV4dHJhQXJndW1lbnQgPSBjcmVhdGVUaHVua01pZGRsZXdhcmU7XG5leHBvcnQge1xuICB0aHVuayxcbiAgd2l0aEV4dHJhQXJndW1lbnRcbn07XG4iLCIvLyBzcmMvaW5kZXgudHNcbmV4cG9ydCAqIGZyb20gXCJyZWR1eFwiO1xuaW1wb3J0IHsgZnJlZXplLCBvcmlnaW5hbCBhcyBvcmlnaW5hbDIgfSBmcm9tIFwiaW1tZXJcIjtcblxuLy8gc3JjL2ltbWVySW1wb3J0cy50c1xuaW1wb3J0IHsgY3VycmVudCwgaXNEcmFmdCwgcHJvZHVjZSwgaXNEcmFmdGFibGUsIHNldFVzZVN0cmljdEl0ZXJhdGlvbiB9IGZyb20gXCJpbW1lclwiO1xuXG4vLyBzcmMvaW5kZXgudHNcbmltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yLCBscnVNZW1vaXplIH0gZnJvbSBcInJlc2VsZWN0XCI7XG5cbi8vIHNyYy9yZXNlbGVjdEltcG9ydHMudHNcbmltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yQ3JlYXRvciwgd2Vha01hcE1lbW9pemUgfSBmcm9tIFwicmVzZWxlY3RcIjtcblxuLy8gc3JjL2NyZWF0ZURyYWZ0U2FmZVNlbGVjdG9yLnRzXG52YXIgY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3JDcmVhdG9yID0gKC4uLmFyZ3MpID0+IHtcbiAgY29uc3QgY3JlYXRlU2VsZWN0b3IyID0gY3JlYXRlU2VsZWN0b3JDcmVhdG9yKC4uLmFyZ3MpO1xuICBjb25zdCBjcmVhdGVEcmFmdFNhZmVTZWxlY3RvcjIgPSBPYmplY3QuYXNzaWduKCguLi5hcmdzMikgPT4ge1xuICAgIGNvbnN0IHNlbGVjdG9yID0gY3JlYXRlU2VsZWN0b3IyKC4uLmFyZ3MyKTtcbiAgICBjb25zdCB3cmFwcGVkU2VsZWN0b3IgPSAodmFsdWUsIC4uLnJlc3QpID0+IHNlbGVjdG9yKGlzRHJhZnQodmFsdWUpID8gY3VycmVudCh2YWx1ZSkgOiB2YWx1ZSwgLi4ucmVzdCk7XG4gICAgT2JqZWN0LmFzc2lnbih3cmFwcGVkU2VsZWN0b3IsIHNlbGVjdG9yKTtcbiAgICByZXR1cm4gd3JhcHBlZFNlbGVjdG9yO1xuICB9LCB7XG4gICAgd2l0aFR5cGVzOiAoKSA9PiBjcmVhdGVEcmFmdFNhZmVTZWxlY3RvcjJcbiAgfSk7XG4gIHJldHVybiBjcmVhdGVEcmFmdFNhZmVTZWxlY3RvcjI7XG59O1xudmFyIGNyZWF0ZURyYWZ0U2FmZVNlbGVjdG9yID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZURyYWZ0U2FmZVNlbGVjdG9yQ3JlYXRvcih3ZWFrTWFwTWVtb2l6ZSk7XG5cbi8vIHNyYy9yZWR1eEltcG9ydHMudHNcbmltcG9ydCB7IGNyZWF0ZVN0b3JlLCBjb21iaW5lUmVkdWNlcnMsIGFwcGx5TWlkZGxld2FyZSwgY29tcG9zZSwgaXNQbGFpbk9iamVjdCwgaXNBY3Rpb24gfSBmcm9tIFwicmVkdXhcIjtcblxuLy8gc3JjL2RldnRvb2xzRXh0ZW5zaW9uLnRzXG52YXIgY29tcG9zZVdpdGhEZXZUb29scyA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93Ll9fUkVEVVhfREVWVE9PTFNfRVhURU5TSU9OX0NPTVBPU0VfXyA/IHdpbmRvdy5fX1JFRFVYX0RFVlRPT0xTX0VYVEVOU0lPTl9DT01QT1NFX18gOiBmdW5jdGlvbigpIHtcbiAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApIHJldHVybiB2b2lkIDA7XG4gIGlmICh0eXBlb2YgYXJndW1lbnRzWzBdID09PSBcIm9iamVjdFwiKSByZXR1cm4gY29tcG9zZTtcbiAgcmV0dXJuIGNvbXBvc2UuYXBwbHkobnVsbCwgYXJndW1lbnRzKTtcbn07XG52YXIgZGV2VG9vbHNFbmhhbmNlciA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93Ll9fUkVEVVhfREVWVE9PTFNfRVhURU5TSU9OX18gPyB3aW5kb3cuX19SRURVWF9ERVZUT09MU19FWFRFTlNJT05fXyA6IGZ1bmN0aW9uKCkge1xuICByZXR1cm4gZnVuY3Rpb24obm9vcDMpIHtcbiAgICByZXR1cm4gbm9vcDM7XG4gIH07XG59O1xuXG4vLyBzcmMvZ2V0RGVmYXVsdE1pZGRsZXdhcmUudHNcbmltcG9ydCB7IHRodW5rIGFzIHRodW5rTWlkZGxld2FyZSwgd2l0aEV4dHJhQXJndW1lbnQgfSBmcm9tIFwicmVkdXgtdGh1bmtcIjtcblxuLy8gc3JjL3RzSGVscGVycy50c1xudmFyIGhhc01hdGNoRnVuY3Rpb24gPSAodikgPT4ge1xuICByZXR1cm4gdiAmJiB0eXBlb2Ygdi5tYXRjaCA9PT0gXCJmdW5jdGlvblwiO1xufTtcblxuLy8gc3JjL2NyZWF0ZUFjdGlvbi50c1xuZnVuY3Rpb24gY3JlYXRlQWN0aW9uKHR5cGUsIHByZXBhcmVBY3Rpb24pIHtcbiAgZnVuY3Rpb24gYWN0aW9uQ3JlYXRvciguLi5hcmdzKSB7XG4gICAgaWYgKHByZXBhcmVBY3Rpb24pIHtcbiAgICAgIGxldCBwcmVwYXJlZCA9IHByZXBhcmVBY3Rpb24oLi4uYXJncyk7XG4gICAgICBpZiAoIXByZXBhcmVkKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDApIDogXCJwcmVwYXJlQWN0aW9uIGRpZCBub3QgcmV0dXJuIGFuIG9iamVjdFwiKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGUsXG4gICAgICAgIHBheWxvYWQ6IHByZXBhcmVkLnBheWxvYWQsXG4gICAgICAgIC4uLlwibWV0YVwiIGluIHByZXBhcmVkICYmIHtcbiAgICAgICAgICBtZXRhOiBwcmVwYXJlZC5tZXRhXG4gICAgICAgIH0sXG4gICAgICAgIC4uLlwiZXJyb3JcIiBpbiBwcmVwYXJlZCAmJiB7XG4gICAgICAgICAgZXJyb3I6IHByZXBhcmVkLmVycm9yXG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICB0eXBlLFxuICAgICAgcGF5bG9hZDogYXJnc1swXVxuICAgIH07XG4gIH1cbiAgYWN0aW9uQ3JlYXRvci50b1N0cmluZyA9ICgpID0+IGAke3R5cGV9YDtcbiAgYWN0aW9uQ3JlYXRvci50eXBlID0gdHlwZTtcbiAgYWN0aW9uQ3JlYXRvci5tYXRjaCA9IChhY3Rpb24pID0+IGlzQWN0aW9uKGFjdGlvbikgJiYgYWN0aW9uLnR5cGUgPT09IHR5cGU7XG4gIHJldHVybiBhY3Rpb25DcmVhdG9yO1xufVxuZnVuY3Rpb24gaXNBY3Rpb25DcmVhdG9yKGFjdGlvbikge1xuICByZXR1cm4gdHlwZW9mIGFjdGlvbiA9PT0gXCJmdW5jdGlvblwiICYmIFwidHlwZVwiIGluIGFjdGlvbiAmJiAvLyBoYXNNYXRjaEZ1bmN0aW9uIG9ubHkgd2FudHMgTWF0Y2hlcnMgYnV0IEkgZG9uJ3Qgc2VlIHRoZSBwb2ludCBpbiByZXdyaXRpbmcgaXRcbiAgaGFzTWF0Y2hGdW5jdGlvbihhY3Rpb24pO1xufVxuZnVuY3Rpb24gaXNGU0EoYWN0aW9uKSB7XG4gIHJldHVybiBpc0FjdGlvbihhY3Rpb24pICYmIE9iamVjdC5rZXlzKGFjdGlvbikuZXZlcnkoaXNWYWxpZEtleSk7XG59XG5mdW5jdGlvbiBpc1ZhbGlkS2V5KGtleSkge1xuICByZXR1cm4gW1widHlwZVwiLCBcInBheWxvYWRcIiwgXCJlcnJvclwiLCBcIm1ldGFcIl0uaW5kZXhPZihrZXkpID4gLTE7XG59XG5cbi8vIHNyYy9hY3Rpb25DcmVhdG9ySW52YXJpYW50TWlkZGxld2FyZS50c1xuZnVuY3Rpb24gZ2V0TWVzc2FnZSh0eXBlKSB7XG4gIGNvbnN0IHNwbGl0VHlwZSA9IHR5cGUgPyBgJHt0eXBlfWAuc3BsaXQoXCIvXCIpIDogW107XG4gIGNvbnN0IGFjdGlvbk5hbWUgPSBzcGxpdFR5cGVbc3BsaXRUeXBlLmxlbmd0aCAtIDFdIHx8IFwiYWN0aW9uQ3JlYXRvclwiO1xuICByZXR1cm4gYERldGVjdGVkIGFuIGFjdGlvbiBjcmVhdG9yIHdpdGggdHlwZSBcIiR7dHlwZSB8fCBcInVua25vd25cIn1cIiBiZWluZyBkaXNwYXRjaGVkLlxuTWFrZSBzdXJlIHlvdSdyZSBjYWxsaW5nIHRoZSBhY3Rpb24gY3JlYXRvciBiZWZvcmUgZGlzcGF0Y2hpbmcsIGkuZS4gXFxgZGlzcGF0Y2goJHthY3Rpb25OYW1lfSgpKVxcYCBpbnN0ZWFkIG9mIFxcYGRpc3BhdGNoKCR7YWN0aW9uTmFtZX0pXFxgLiBUaGlzIGlzIG5lY2Vzc2FyeSBldmVuIGlmIHRoZSBhY3Rpb24gaGFzIG5vIHBheWxvYWQuYDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUFjdGlvbkNyZWF0b3JJbnZhcmlhbnRNaWRkbGV3YXJlKG9wdGlvbnMgPSB7fSkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgcmV0dXJuICgpID0+IChuZXh0KSA9PiAoYWN0aW9uKSA9PiBuZXh0KGFjdGlvbik7XG4gIH1cbiAgY29uc3Qge1xuICAgIGlzQWN0aW9uQ3JlYXRvcjogaXNBY3Rpb25DcmVhdG9yMiA9IGlzQWN0aW9uQ3JlYXRvclxuICB9ID0gb3B0aW9ucztcbiAgcmV0dXJuICgpID0+IChuZXh0KSA9PiAoYWN0aW9uKSA9PiB7XG4gICAgaWYgKGlzQWN0aW9uQ3JlYXRvcjIoYWN0aW9uKSkge1xuICAgICAgY29uc29sZS53YXJuKGdldE1lc3NhZ2UoYWN0aW9uLnR5cGUpKTtcbiAgICB9XG4gICAgcmV0dXJuIG5leHQoYWN0aW9uKTtcbiAgfTtcbn1cblxuLy8gc3JjL3V0aWxzLnRzXG5mdW5jdGlvbiBnZXRUaW1lTWVhc3VyZVV0aWxzKG1heERlbGF5LCBmbk5hbWUpIHtcbiAgbGV0IGVsYXBzZWQgPSAwO1xuICByZXR1cm4ge1xuICAgIG1lYXN1cmVUaW1lKGZuKSB7XG4gICAgICBjb25zdCBzdGFydGVkID0gRGF0ZS5ub3coKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBmbigpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgY29uc3QgZmluaXNoZWQgPSBEYXRlLm5vdygpO1xuICAgICAgICBlbGFwc2VkICs9IGZpbmlzaGVkIC0gc3RhcnRlZDtcbiAgICAgIH1cbiAgICB9LFxuICAgIHdhcm5JZkV4Y2VlZGVkKCkge1xuICAgICAgaWYgKGVsYXBzZWQgPiBtYXhEZWxheSkge1xuICAgICAgICBjb25zb2xlLndhcm4oYCR7Zm5OYW1lfSB0b29rICR7ZWxhcHNlZH1tcywgd2hpY2ggaXMgbW9yZSB0aGFuIHRoZSB3YXJuaW5nIHRocmVzaG9sZCBvZiAke21heERlbGF5fW1zLiBcbklmIHlvdXIgc3RhdGUgb3IgYWN0aW9ucyBhcmUgdmVyeSBsYXJnZSwgeW91IG1heSB3YW50IHRvIGRpc2FibGUgdGhlIG1pZGRsZXdhcmUgYXMgaXQgbWlnaHQgY2F1c2UgdG9vIG11Y2ggb2YgYSBzbG93ZG93biBpbiBkZXZlbG9wbWVudCBtb2RlLiBTZWUgaHR0cHM6Ly9yZWR1eC10b29sa2l0LmpzLm9yZy9hcGkvZ2V0RGVmYXVsdE1pZGRsZXdhcmUgZm9yIGluc3RydWN0aW9ucy5cbkl0IGlzIGRpc2FibGVkIGluIHByb2R1Y3Rpb24gYnVpbGRzLCBzbyB5b3UgZG9uJ3QgbmVlZCB0byB3b3JyeSBhYm91dCB0aGF0LmApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn1cbnZhciBUdXBsZSA9IGNsYXNzIF9UdXBsZSBleHRlbmRzIEFycmF5IHtcbiAgY29uc3RydWN0b3IoLi4uaXRlbXMpIHtcbiAgICBzdXBlciguLi5pdGVtcyk7XG4gICAgT2JqZWN0LnNldFByb3RvdHlwZU9mKHRoaXMsIF9UdXBsZS5wcm90b3R5cGUpO1xuICB9XG4gIHN0YXRpYyBnZXQgW1N5bWJvbC5zcGVjaWVzXSgpIHtcbiAgICByZXR1cm4gX1R1cGxlO1xuICB9XG4gIGNvbmNhdCguLi5hcnIpIHtcbiAgICByZXR1cm4gc3VwZXIuY29uY2F0LmFwcGx5KHRoaXMsIGFycik7XG4gIH1cbiAgcHJlcGVuZCguLi5hcnIpIHtcbiAgICBpZiAoYXJyLmxlbmd0aCA9PT0gMSAmJiBBcnJheS5pc0FycmF5KGFyclswXSkpIHtcbiAgICAgIHJldHVybiBuZXcgX1R1cGxlKC4uLmFyclswXS5jb25jYXQodGhpcykpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IF9UdXBsZSguLi5hcnIuY29uY2F0KHRoaXMpKTtcbiAgfVxufTtcbmZ1bmN0aW9uIGZyZWV6ZURyYWZ0YWJsZSh2YWwpIHtcbiAgcmV0dXJuIGlzRHJhZnRhYmxlKHZhbCkgPyBwcm9kdWNlKHZhbCwgKCkgPT4ge1xuICB9KSA6IHZhbDtcbn1cbmZ1bmN0aW9uIGdldE9ySW5zZXJ0Q29tcHV0ZWQobWFwLCBrZXksIGNvbXB1dGUpIHtcbiAgaWYgKG1hcC5oYXMoa2V5KSkgcmV0dXJuIG1hcC5nZXQoa2V5KTtcbiAgcmV0dXJuIG1hcC5zZXQoa2V5LCBjb21wdXRlKGtleSkpLmdldChrZXkpO1xufVxuXG4vLyBzcmMvaW1tdXRhYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlLnRzXG5mdW5jdGlvbiBpc0ltbXV0YWJsZURlZmF1bHQodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSAhPT0gXCJvYmplY3RcIiB8fCB2YWx1ZSA9PSBudWxsIHx8IE9iamVjdC5pc0Zyb3plbih2YWx1ZSk7XG59XG5mdW5jdGlvbiB0cmFja0Zvck11dGF0aW9ucyhpc0ltbXV0YWJsZSwgaWdub3JlZFBhdGhzLCBvYmopIHtcbiAgY29uc3QgdHJhY2tlZFByb3BlcnRpZXMgPSB0cmFja1Byb3BlcnRpZXMoaXNJbW11dGFibGUsIGlnbm9yZWRQYXRocywgb2JqKTtcbiAgcmV0dXJuIHtcbiAgICBkZXRlY3RNdXRhdGlvbnMoKSB7XG4gICAgICByZXR1cm4gZGV0ZWN0TXV0YXRpb25zKGlzSW1tdXRhYmxlLCBpZ25vcmVkUGF0aHMsIHRyYWNrZWRQcm9wZXJ0aWVzLCBvYmopO1xuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIHRyYWNrUHJvcGVydGllcyhpc0ltbXV0YWJsZSwgaWdub3JlZFBhdGhzID0gW10sIG9iaiwgcGF0aCA9IFwiXCIsIGNoZWNrZWRPYmplY3RzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSkge1xuICBjb25zdCB0cmFja2VkID0ge1xuICAgIHZhbHVlOiBvYmpcbiAgfTtcbiAgaWYgKCFpc0ltbXV0YWJsZShvYmopICYmICFjaGVja2VkT2JqZWN0cy5oYXMob2JqKSkge1xuICAgIGNoZWNrZWRPYmplY3RzLmFkZChvYmopO1xuICAgIHRyYWNrZWQuY2hpbGRyZW4gPSB7fTtcbiAgICBjb25zdCBoYXNJZ25vcmVkUGF0aHMgPSBpZ25vcmVkUGF0aHMubGVuZ3RoID4gMDtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICAgIGNvbnN0IG5lc3RlZFBhdGggPSBwYXRoID8gcGF0aCArIFwiLlwiICsga2V5IDoga2V5O1xuICAgICAgaWYgKGhhc0lnbm9yZWRQYXRocykge1xuICAgICAgICBjb25zdCBoYXNNYXRjaGVzID0gaWdub3JlZFBhdGhzLnNvbWUoKGlnbm9yZWQpID0+IHtcbiAgICAgICAgICBpZiAoaWdub3JlZCBpbnN0YW5jZW9mIFJlZ0V4cCkge1xuICAgICAgICAgICAgcmV0dXJuIGlnbm9yZWQudGVzdChuZXN0ZWRQYXRoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG5lc3RlZFBhdGggPT09IGlnbm9yZWQ7XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoaGFzTWF0Y2hlcykge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0cmFja2VkLmNoaWxkcmVuW2tleV0gPSB0cmFja1Byb3BlcnRpZXMoaXNJbW11dGFibGUsIGlnbm9yZWRQYXRocywgb2JqW2tleV0sIG5lc3RlZFBhdGgpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJhY2tlZDtcbn1cbmZ1bmN0aW9uIGRldGVjdE11dGF0aW9ucyhpc0ltbXV0YWJsZSwgaWdub3JlZFBhdGhzID0gW10sIHRyYWNrZWRQcm9wZXJ0eSwgb2JqLCBzYW1lUGFyZW50UmVmID0gZmFsc2UsIHBhdGggPSBcIlwiKSB7XG4gIGNvbnN0IHByZXZPYmogPSB0cmFja2VkUHJvcGVydHkgPyB0cmFja2VkUHJvcGVydHkudmFsdWUgOiB2b2lkIDA7XG4gIGNvbnN0IHNhbWVSZWYgPSBwcmV2T2JqID09PSBvYmo7XG4gIGlmIChzYW1lUGFyZW50UmVmICYmICFzYW1lUmVmICYmICFOdW1iZXIuaXNOYU4ob2JqKSkge1xuICAgIHJldHVybiB7XG4gICAgICB3YXNNdXRhdGVkOiB0cnVlLFxuICAgICAgcGF0aFxuICAgIH07XG4gIH1cbiAgaWYgKGlzSW1tdXRhYmxlKHByZXZPYmopIHx8IGlzSW1tdXRhYmxlKG9iaikpIHtcbiAgICByZXR1cm4ge1xuICAgICAgd2FzTXV0YXRlZDogZmFsc2VcbiAgICB9O1xuICB9XG4gIGNvbnN0IGtleXNUb0RldGVjdCA9IHt9O1xuICBmb3IgKGxldCBrZXkgaW4gdHJhY2tlZFByb3BlcnR5LmNoaWxkcmVuKSB7XG4gICAga2V5c1RvRGV0ZWN0W2tleV0gPSB0cnVlO1xuICB9XG4gIGZvciAobGV0IGtleSBpbiBvYmopIHtcbiAgICBrZXlzVG9EZXRlY3Rba2V5XSA9IHRydWU7XG4gIH1cbiAgY29uc3QgaGFzSWdub3JlZFBhdGhzID0gaWdub3JlZFBhdGhzLmxlbmd0aCA+IDA7XG4gIGZvciAobGV0IGtleSBpbiBrZXlzVG9EZXRlY3QpIHtcbiAgICBjb25zdCBuZXN0ZWRQYXRoID0gcGF0aCA/IHBhdGggKyBcIi5cIiArIGtleSA6IGtleTtcbiAgICBpZiAoaGFzSWdub3JlZFBhdGhzKSB7XG4gICAgICBjb25zdCBoYXNNYXRjaGVzID0gaWdub3JlZFBhdGhzLnNvbWUoKGlnbm9yZWQpID0+IHtcbiAgICAgICAgaWYgKGlnbm9yZWQgaW5zdGFuY2VvZiBSZWdFeHApIHtcbiAgICAgICAgICByZXR1cm4gaWdub3JlZC50ZXN0KG5lc3RlZFBhdGgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXN0ZWRQYXRoID09PSBpZ25vcmVkO1xuICAgICAgfSk7XG4gICAgICBpZiAoaGFzTWF0Y2hlcykge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gZGV0ZWN0TXV0YXRpb25zKGlzSW1tdXRhYmxlLCBpZ25vcmVkUGF0aHMsIHRyYWNrZWRQcm9wZXJ0eS5jaGlsZHJlbltrZXldLCBvYmpba2V5XSwgc2FtZVJlZiwgbmVzdGVkUGF0aCk7XG4gICAgaWYgKHJlc3VsdC53YXNNdXRhdGVkKSB7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIHdhc011dGF0ZWQ6IGZhbHNlXG4gIH07XG59XG5mdW5jdGlvbiBjcmVhdGVJbW11dGFibGVTdGF0ZUludmFyaWFudE1pZGRsZXdhcmUob3B0aW9ucyA9IHt9KSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICByZXR1cm4gKCkgPT4gKG5leHQpID0+IChhY3Rpb24pID0+IG5leHQoYWN0aW9uKTtcbiAgfSBlbHNlIHtcbiAgICBsZXQgc3RyaW5naWZ5MiA9IGZ1bmN0aW9uKG9iaiwgc2VyaWFsaXplciwgaW5kZW50LCBkZWN5Y2xlcikge1xuICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KG9iaiwgZ2V0U2VyaWFsaXplMihzZXJpYWxpemVyLCBkZWN5Y2xlciksIGluZGVudCk7XG4gICAgfSwgZ2V0U2VyaWFsaXplMiA9IGZ1bmN0aW9uKHNlcmlhbGl6ZXIsIGRlY3ljbGVyKSB7XG4gICAgICBsZXQgc3RhY2sgPSBbXSwga2V5cyA9IFtdO1xuICAgICAgaWYgKCFkZWN5Y2xlcikgZGVjeWNsZXIgPSBmdW5jdGlvbihfLCB2YWx1ZSkge1xuICAgICAgICBpZiAoc3RhY2tbMF0gPT09IHZhbHVlKSByZXR1cm4gXCJbQ2lyY3VsYXIgfl1cIjtcbiAgICAgICAgcmV0dXJuIFwiW0NpcmN1bGFyIH4uXCIgKyBrZXlzLnNsaWNlKDAsIHN0YWNrLmluZGV4T2YodmFsdWUpKS5qb2luKFwiLlwiKSArIFwiXVwiO1xuICAgICAgfTtcbiAgICAgIHJldHVybiBmdW5jdGlvbihrZXksIHZhbHVlKSB7XG4gICAgICAgIGlmIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgdmFyIHRoaXNQb3MgPSBzdGFjay5pbmRleE9mKHRoaXMpO1xuICAgICAgICAgIH50aGlzUG9zID8gc3RhY2suc3BsaWNlKHRoaXNQb3MgKyAxKSA6IHN0YWNrLnB1c2godGhpcyk7XG4gICAgICAgICAgfnRoaXNQb3MgPyBrZXlzLnNwbGljZSh0aGlzUG9zLCBJbmZpbml0eSwga2V5KSA6IGtleXMucHVzaChrZXkpO1xuICAgICAgICAgIGlmICh+c3RhY2suaW5kZXhPZih2YWx1ZSkpIHZhbHVlID0gZGVjeWNsZXIuY2FsbCh0aGlzLCBrZXksIHZhbHVlKTtcbiAgICAgICAgfSBlbHNlIHN0YWNrLnB1c2godmFsdWUpO1xuICAgICAgICByZXR1cm4gc2VyaWFsaXplciA9PSBudWxsID8gdmFsdWUgOiBzZXJpYWxpemVyLmNhbGwodGhpcywga2V5LCB2YWx1ZSk7XG4gICAgICB9O1xuICAgIH07XG4gICAgdmFyIHN0cmluZ2lmeSA9IHN0cmluZ2lmeTIsIGdldFNlcmlhbGl6ZSA9IGdldFNlcmlhbGl6ZTI7XG4gICAgbGV0IHtcbiAgICAgIGlzSW1tdXRhYmxlID0gaXNJbW11dGFibGVEZWZhdWx0LFxuICAgICAgaWdub3JlZFBhdGhzLFxuICAgICAgd2FybkFmdGVyID0gMzJcbiAgICB9ID0gb3B0aW9ucztcbiAgICBjb25zdCB0cmFjayA9IHRyYWNrRm9yTXV0YXRpb25zLmJpbmQobnVsbCwgaXNJbW11dGFibGUsIGlnbm9yZWRQYXRocyk7XG4gICAgcmV0dXJuICh7XG4gICAgICBnZXRTdGF0ZVxuICAgIH0pID0+IHtcbiAgICAgIGxldCBzdGF0ZSA9IGdldFN0YXRlKCk7XG4gICAgICBsZXQgdHJhY2tlciA9IHRyYWNrKHN0YXRlKTtcbiAgICAgIGxldCByZXN1bHQ7XG4gICAgICByZXR1cm4gKG5leHQpID0+IChhY3Rpb24pID0+IHtcbiAgICAgICAgY29uc3QgbWVhc3VyZVV0aWxzID0gZ2V0VGltZU1lYXN1cmVVdGlscyh3YXJuQWZ0ZXIsIFwiSW1tdXRhYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlXCIpO1xuICAgICAgICBtZWFzdXJlVXRpbHMubWVhc3VyZVRpbWUoKCkgPT4ge1xuICAgICAgICAgIHN0YXRlID0gZ2V0U3RhdGUoKTtcbiAgICAgICAgICByZXN1bHQgPSB0cmFja2VyLmRldGVjdE11dGF0aW9ucygpO1xuICAgICAgICAgIHRyYWNrZXIgPSB0cmFjayhzdGF0ZSk7XG4gICAgICAgICAgaWYgKHJlc3VsdC53YXNNdXRhdGVkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxOSkgOiBgQSBzdGF0ZSBtdXRhdGlvbiB3YXMgZGV0ZWN0ZWQgYmV0d2VlbiBkaXNwYXRjaGVzLCBpbiB0aGUgcGF0aCAnJHtyZXN1bHQucGF0aCB8fCBcIlwifScuICBUaGlzIG1heSBjYXVzZSBpbmNvcnJlY3QgYmVoYXZpb3IuIChodHRwczovL3JlZHV4LmpzLm9yZy9zdHlsZS1ndWlkZS9zdHlsZS1ndWlkZSNkby1ub3QtbXV0YXRlLXN0YXRlKWApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IGRpc3BhdGNoZWRBY3Rpb24gPSBuZXh0KGFjdGlvbik7XG4gICAgICAgIG1lYXN1cmVVdGlscy5tZWFzdXJlVGltZSgoKSA9PiB7XG4gICAgICAgICAgc3RhdGUgPSBnZXRTdGF0ZSgpO1xuICAgICAgICAgIHJlc3VsdCA9IHRyYWNrZXIuZGV0ZWN0TXV0YXRpb25zKCk7XG4gICAgICAgICAgdHJhY2tlciA9IHRyYWNrKHN0YXRlKTtcbiAgICAgICAgICBpZiAocmVzdWx0Lndhc011dGF0ZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDIwKSA6IGBBIHN0YXRlIG11dGF0aW9uIHdhcyBkZXRlY3RlZCBpbnNpZGUgYSBkaXNwYXRjaCwgaW4gdGhlIHBhdGg6ICR7cmVzdWx0LnBhdGggfHwgXCJcIn0uIFRha2UgYSBsb29rIGF0IHRoZSByZWR1Y2VyKHMpIGhhbmRsaW5nIHRoZSBhY3Rpb24gJHtzdHJpbmdpZnkyKGFjdGlvbil9LiAoaHR0cHM6Ly9yZWR1eC5qcy5vcmcvc3R5bGUtZ3VpZGUvc3R5bGUtZ3VpZGUjZG8tbm90LW11dGF0ZS1zdGF0ZSlgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBtZWFzdXJlVXRpbHMud2FybklmRXhjZWVkZWQoKTtcbiAgICAgICAgcmV0dXJuIGRpc3BhdGNoZWRBY3Rpb247XG4gICAgICB9O1xuICAgIH07XG4gIH1cbn1cblxuLy8gc3JjL3NlcmlhbGl6YWJsZVN0YXRlSW52YXJpYW50TWlkZGxld2FyZS50c1xuZnVuY3Rpb24gaXNQbGFpbih2YWwpIHtcbiAgY29uc3QgdHlwZSA9IHR5cGVvZiB2YWw7XG4gIHJldHVybiB2YWwgPT0gbnVsbCB8fCB0eXBlID09PSBcInN0cmluZ1wiIHx8IHR5cGUgPT09IFwiYm9vbGVhblwiIHx8IHR5cGUgPT09IFwibnVtYmVyXCIgfHwgQXJyYXkuaXNBcnJheSh2YWwpIHx8IGlzUGxhaW5PYmplY3QodmFsKTtcbn1cbmZ1bmN0aW9uIGZpbmROb25TZXJpYWxpemFibGVWYWx1ZSh2YWx1ZSwgcGF0aCA9IFwiXCIsIGlzU2VyaWFsaXphYmxlID0gaXNQbGFpbiwgZ2V0RW50cmllcywgaWdub3JlZFBhdGhzID0gW10sIGNhY2hlKSB7XG4gIGxldCBmb3VuZE5lc3RlZFNlcmlhbGl6YWJsZTtcbiAgaWYgKCFpc1NlcmlhbGl6YWJsZSh2YWx1ZSkpIHtcbiAgICByZXR1cm4ge1xuICAgICAga2V5UGF0aDogcGF0aCB8fCBcIjxyb290PlwiLFxuICAgICAgdmFsdWVcbiAgICB9O1xuICB9XG4gIGlmICh0eXBlb2YgdmFsdWUgIT09IFwib2JqZWN0XCIgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGNhY2hlPy5oYXModmFsdWUpKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGVudHJpZXMgPSBnZXRFbnRyaWVzICE9IG51bGwgPyBnZXRFbnRyaWVzKHZhbHVlKSA6IE9iamVjdC5lbnRyaWVzKHZhbHVlKTtcbiAgY29uc3QgaGFzSWdub3JlZFBhdGhzID0gaWdub3JlZFBhdGhzLmxlbmd0aCA+IDA7XG4gIGZvciAoY29uc3QgW2tleSwgbmVzdGVkVmFsdWVdIG9mIGVudHJpZXMpIHtcbiAgICBjb25zdCBuZXN0ZWRQYXRoID0gcGF0aCA/IHBhdGggKyBcIi5cIiArIGtleSA6IGtleTtcbiAgICBpZiAoaGFzSWdub3JlZFBhdGhzKSB7XG4gICAgICBjb25zdCBoYXNNYXRjaGVzID0gaWdub3JlZFBhdGhzLnNvbWUoKGlnbm9yZWQpID0+IHtcbiAgICAgICAgaWYgKGlnbm9yZWQgaW5zdGFuY2VvZiBSZWdFeHApIHtcbiAgICAgICAgICByZXR1cm4gaWdub3JlZC50ZXN0KG5lc3RlZFBhdGgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXN0ZWRQYXRoID09PSBpZ25vcmVkO1xuICAgICAgfSk7XG4gICAgICBpZiAoaGFzTWF0Y2hlcykge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFpc1NlcmlhbGl6YWJsZShuZXN0ZWRWYWx1ZSkpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGtleVBhdGg6IG5lc3RlZFBhdGgsXG4gICAgICAgIHZhbHVlOiBuZXN0ZWRWYWx1ZVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBuZXN0ZWRWYWx1ZSA9PT0gXCJvYmplY3RcIikge1xuICAgICAgZm91bmROZXN0ZWRTZXJpYWxpemFibGUgPSBmaW5kTm9uU2VyaWFsaXphYmxlVmFsdWUobmVzdGVkVmFsdWUsIG5lc3RlZFBhdGgsIGlzU2VyaWFsaXphYmxlLCBnZXRFbnRyaWVzLCBpZ25vcmVkUGF0aHMsIGNhY2hlKTtcbiAgICAgIGlmIChmb3VuZE5lc3RlZFNlcmlhbGl6YWJsZSkge1xuICAgICAgICByZXR1cm4gZm91bmROZXN0ZWRTZXJpYWxpemFibGU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGlmIChjYWNoZSAmJiBpc05lc3RlZEZyb3plbih2YWx1ZSkpIGNhY2hlLmFkZCh2YWx1ZSk7XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzTmVzdGVkRnJvemVuKHZhbHVlKSB7XG4gIGlmICghT2JqZWN0LmlzRnJvemVuKHZhbHVlKSkgcmV0dXJuIGZhbHNlO1xuICBmb3IgKGNvbnN0IG5lc3RlZFZhbHVlIG9mIE9iamVjdC52YWx1ZXModmFsdWUpKSB7XG4gICAgaWYgKHR5cGVvZiBuZXN0ZWRWYWx1ZSAhPT0gXCJvYmplY3RcIiB8fCBuZXN0ZWRWYWx1ZSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgaWYgKCFpc05lc3RlZEZyb3plbihuZXN0ZWRWYWx1ZSkpIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNlcmlhbGl6YWJsZVN0YXRlSW52YXJpYW50TWlkZGxld2FyZShvcHRpb25zID0ge30pIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIikge1xuICAgIHJldHVybiAoKSA9PiAobmV4dCkgPT4gKGFjdGlvbikgPT4gbmV4dChhY3Rpb24pO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IHtcbiAgICAgIGlzU2VyaWFsaXphYmxlID0gaXNQbGFpbixcbiAgICAgIGdldEVudHJpZXMsXG4gICAgICBpZ25vcmVkQWN0aW9ucyA9IFtdLFxuICAgICAgaWdub3JlZEFjdGlvblBhdGhzID0gW1wibWV0YS5hcmdcIiwgXCJtZXRhLmJhc2VRdWVyeU1ldGFcIl0sXG4gICAgICBpZ25vcmVkUGF0aHMgPSBbXSxcbiAgICAgIHdhcm5BZnRlciA9IDMyLFxuICAgICAgaWdub3JlU3RhdGUgPSBmYWxzZSxcbiAgICAgIGlnbm9yZUFjdGlvbnMgPSBmYWxzZSxcbiAgICAgIGRpc2FibGVDYWNoZSA9IGZhbHNlXG4gICAgfSA9IG9wdGlvbnM7XG4gICAgY29uc3QgY2FjaGUgPSAhZGlzYWJsZUNhY2hlICYmIFdlYWtTZXQgPyAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtTZXQoKSA6IHZvaWQgMDtcbiAgICByZXR1cm4gKHN0b3JlQVBJKSA9PiAobmV4dCkgPT4gKGFjdGlvbikgPT4ge1xuICAgICAgaWYgKCFpc0FjdGlvbihhY3Rpb24pKSB7XG4gICAgICAgIHJldHVybiBuZXh0KGFjdGlvbik7XG4gICAgICB9XG4gICAgICBjb25zdCByZXN1bHQgPSBuZXh0KGFjdGlvbik7XG4gICAgICBjb25zdCBtZWFzdXJlVXRpbHMgPSBnZXRUaW1lTWVhc3VyZVV0aWxzKHdhcm5BZnRlciwgXCJTZXJpYWxpemFibGVTdGF0ZUludmFyaWFudE1pZGRsZXdhcmVcIik7XG4gICAgICBpZiAoIWlnbm9yZUFjdGlvbnMgJiYgIShpZ25vcmVkQWN0aW9ucy5sZW5ndGggJiYgaWdub3JlZEFjdGlvbnMuaW5kZXhPZihhY3Rpb24udHlwZSkgIT09IC0xKSkge1xuICAgICAgICBtZWFzdXJlVXRpbHMubWVhc3VyZVRpbWUoKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGZvdW5kQWN0aW9uTm9uU2VyaWFsaXphYmxlVmFsdWUgPSBmaW5kTm9uU2VyaWFsaXphYmxlVmFsdWUoYWN0aW9uLCBcIlwiLCBpc1NlcmlhbGl6YWJsZSwgZ2V0RW50cmllcywgaWdub3JlZEFjdGlvblBhdGhzLCBjYWNoZSk7XG4gICAgICAgICAgaWYgKGZvdW5kQWN0aW9uTm9uU2VyaWFsaXphYmxlVmFsdWUpIHtcbiAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAga2V5UGF0aCxcbiAgICAgICAgICAgICAgdmFsdWVcbiAgICAgICAgICAgIH0gPSBmb3VuZEFjdGlvbk5vblNlcmlhbGl6YWJsZVZhbHVlO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgQSBub24tc2VyaWFsaXphYmxlIHZhbHVlIHdhcyBkZXRlY3RlZCBpbiBhbiBhY3Rpb24sIGluIHRoZSBwYXRoOiBcXGAke2tleVBhdGh9XFxgLiBWYWx1ZTpgLCB2YWx1ZSwgXCJcXG5UYWtlIGEgbG9vayBhdCB0aGUgbG9naWMgdGhhdCBkaXNwYXRjaGVkIHRoaXMgYWN0aW9uOiBcIiwgYWN0aW9uLCBcIlxcbihTZWUgaHR0cHM6Ly9yZWR1eC5qcy5vcmcvZmFxL2FjdGlvbnMjd2h5LXNob3VsZC10eXBlLWJlLWEtc3RyaW5nLW9yLWF0LWxlYXN0LXNlcmlhbGl6YWJsZS13aHktc2hvdWxkLW15LWFjdGlvbi10eXBlcy1iZS1jb25zdGFudHMpXCIsIFwiXFxuKFRvIGFsbG93IG5vbi1zZXJpYWxpemFibGUgdmFsdWVzIHNlZTogaHR0cHM6Ly9yZWR1eC10b29sa2l0LmpzLm9yZy91c2FnZS91c2FnZS1ndWlkZSN3b3JraW5nLXdpdGgtbm9uLXNlcmlhbGl6YWJsZS1kYXRhKVwiKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgaWYgKCFpZ25vcmVTdGF0ZSkge1xuICAgICAgICBtZWFzdXJlVXRpbHMubWVhc3VyZVRpbWUoKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHN0YXRlID0gc3RvcmVBUEkuZ2V0U3RhdGUoKTtcbiAgICAgICAgICBjb25zdCBmb3VuZFN0YXRlTm9uU2VyaWFsaXphYmxlVmFsdWUgPSBmaW5kTm9uU2VyaWFsaXphYmxlVmFsdWUoc3RhdGUsIFwiXCIsIGlzU2VyaWFsaXphYmxlLCBnZXRFbnRyaWVzLCBpZ25vcmVkUGF0aHMsIGNhY2hlKTtcbiAgICAgICAgICBpZiAoZm91bmRTdGF0ZU5vblNlcmlhbGl6YWJsZVZhbHVlKSB7XG4gICAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICAgIGtleVBhdGgsXG4gICAgICAgICAgICAgIHZhbHVlXG4gICAgICAgICAgICB9ID0gZm91bmRTdGF0ZU5vblNlcmlhbGl6YWJsZVZhbHVlO1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgQSBub24tc2VyaWFsaXphYmxlIHZhbHVlIHdhcyBkZXRlY3RlZCBpbiB0aGUgc3RhdGUsIGluIHRoZSBwYXRoOiBcXGAke2tleVBhdGh9XFxgLiBWYWx1ZTpgLCB2YWx1ZSwgYFxuVGFrZSBhIGxvb2sgYXQgdGhlIHJlZHVjZXIocykgaGFuZGxpbmcgdGhpcyBhY3Rpb24gdHlwZTogJHthY3Rpb24udHlwZX0uXG4oU2VlIGh0dHBzOi8vcmVkdXguanMub3JnL2ZhcS9vcmdhbml6aW5nLXN0YXRlI2Nhbi1pLXB1dC1mdW5jdGlvbnMtcHJvbWlzZXMtb3Itb3RoZXItbm9uLXNlcmlhbGl6YWJsZS1pdGVtcy1pbi1teS1zdG9yZS1zdGF0ZSlgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBtZWFzdXJlVXRpbHMud2FybklmRXhjZWVkZWQoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgfVxufVxuXG4vLyBzcmMvZ2V0RGVmYXVsdE1pZGRsZXdhcmUudHNcbmZ1bmN0aW9uIGlzQm9vbGVhbih4KSB7XG4gIHJldHVybiB0eXBlb2YgeCA9PT0gXCJib29sZWFuXCI7XG59XG52YXIgYnVpbGRHZXREZWZhdWx0TWlkZGxld2FyZSA9ICgpID0+IGZ1bmN0aW9uIGdldERlZmF1bHRNaWRkbGV3YXJlKG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHRodW5rID0gdHJ1ZSxcbiAgICBpbW11dGFibGVDaGVjayA9IHRydWUsXG4gICAgc2VyaWFsaXphYmxlQ2hlY2sgPSB0cnVlLFxuICAgIGFjdGlvbkNyZWF0b3JDaGVjayA9IHRydWVcbiAgfSA9IG9wdGlvbnMgPz8ge307XG4gIGxldCBtaWRkbGV3YXJlQXJyYXkgPSBuZXcgVHVwbGUoKTtcbiAgaWYgKHRodW5rKSB7XG4gICAgaWYgKGlzQm9vbGVhbih0aHVuaykpIHtcbiAgICAgIG1pZGRsZXdhcmVBcnJheS5wdXNoKHRodW5rTWlkZGxld2FyZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG1pZGRsZXdhcmVBcnJheS5wdXNoKHdpdGhFeHRyYUFyZ3VtZW50KHRodW5rLmV4dHJhQXJndW1lbnQpKTtcbiAgICB9XG4gIH1cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGlmIChpbW11dGFibGVDaGVjaykge1xuICAgICAgbGV0IGltbXV0YWJsZU9wdGlvbnMgPSB7fTtcbiAgICAgIGlmICghaXNCb29sZWFuKGltbXV0YWJsZUNoZWNrKSkge1xuICAgICAgICBpbW11dGFibGVPcHRpb25zID0gaW1tdXRhYmxlQ2hlY2s7XG4gICAgICB9XG4gICAgICBtaWRkbGV3YXJlQXJyYXkudW5zaGlmdChjcmVhdGVJbW11dGFibGVTdGF0ZUludmFyaWFudE1pZGRsZXdhcmUoaW1tdXRhYmxlT3B0aW9ucykpO1xuICAgIH1cbiAgICBpZiAoc2VyaWFsaXphYmxlQ2hlY2spIHtcbiAgICAgIGxldCBzZXJpYWxpemFibGVPcHRpb25zID0ge307XG4gICAgICBpZiAoIWlzQm9vbGVhbihzZXJpYWxpemFibGVDaGVjaykpIHtcbiAgICAgICAgc2VyaWFsaXphYmxlT3B0aW9ucyA9IHNlcmlhbGl6YWJsZUNoZWNrO1xuICAgICAgfVxuICAgICAgbWlkZGxld2FyZUFycmF5LnB1c2goY3JlYXRlU2VyaWFsaXphYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlKHNlcmlhbGl6YWJsZU9wdGlvbnMpKTtcbiAgICB9XG4gICAgaWYgKGFjdGlvbkNyZWF0b3JDaGVjaykge1xuICAgICAgbGV0IGFjdGlvbkNyZWF0b3JPcHRpb25zID0ge307XG4gICAgICBpZiAoIWlzQm9vbGVhbihhY3Rpb25DcmVhdG9yQ2hlY2spKSB7XG4gICAgICAgIGFjdGlvbkNyZWF0b3JPcHRpb25zID0gYWN0aW9uQ3JlYXRvckNoZWNrO1xuICAgICAgfVxuICAgICAgbWlkZGxld2FyZUFycmF5LnVuc2hpZnQoY3JlYXRlQWN0aW9uQ3JlYXRvckludmFyaWFudE1pZGRsZXdhcmUoYWN0aW9uQ3JlYXRvck9wdGlvbnMpKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG1pZGRsZXdhcmVBcnJheTtcbn07XG5cbi8vIHNyYy9hdXRvQmF0Y2hFbmhhbmNlci50c1xudmFyIFNIT1VMRF9BVVRPQkFUQ0ggPSBcIlJUS19hdXRvQmF0Y2hcIjtcbnZhciBwcmVwYXJlQXV0b0JhdGNoZWQgPSAoKSA9PiAocGF5bG9hZCkgPT4gKHtcbiAgcGF5bG9hZCxcbiAgbWV0YToge1xuICAgIFtTSE9VTERfQVVUT0JBVENIXTogdHJ1ZVxuICB9XG59KTtcbnZhciBjcmVhdGVRdWV1ZVdpdGhUaW1lciA9ICh0aW1lb3V0KSA9PiB7XG4gIHJldHVybiAobm90aWZ5KSA9PiB7XG4gICAgc2V0VGltZW91dChub3RpZnksIHRpbWVvdXQpO1xuICB9O1xufTtcbnZhciBjcmVhdGVSYWZXaXRoRmFsbGJhY2tUaW1lciA9IChyYWYsIHRpbWVvdXQpID0+IHtcbiAgcmV0dXJuIChub3RpZnkpID0+IHtcbiAgICBsZXQgY2FsbGVkID0gZmFsc2U7XG4gICAgY29uc3QgY2FsbGJhY2sgPSAoKSA9PiB7XG4gICAgICBpZiAoY2FsbGVkKSByZXR1cm47XG4gICAgICBjYWxsZWQgPSB0cnVlO1xuICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUocmFmSWQpO1xuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVySWQpO1xuICAgICAgbm90aWZ5KCk7XG4gICAgfTtcbiAgICBjb25zdCByYWZJZCA9IHJhZihjYWxsYmFjayk7XG4gICAgY29uc3QgdGltZXJJZCA9IHNldFRpbWVvdXQoY2FsbGJhY2ssIHRpbWVvdXQpO1xuICB9O1xufTtcbnZhciBhdXRvQmF0Y2hFbmhhbmNlciA9IChvcHRpb25zID0ge1xuICB0eXBlOiBcInJhZlwiXG59KSA9PiAobmV4dCkgPT4gKC4uLmFyZ3MpID0+IHtcbiAgY29uc3Qgc3RvcmUgPSBuZXh0KC4uLmFyZ3MpO1xuICBsZXQgbm90aWZ5aW5nID0gdHJ1ZTtcbiAgbGV0IHNob3VsZE5vdGlmeUF0RW5kT2ZUaWNrID0gZmFsc2U7XG4gIGxldCBub3RpZmljYXRpb25RdWV1ZWQgPSBmYWxzZTtcbiAgY29uc3QgbGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgY29uc3QgcXVldWVDYWxsYmFjayA9IG9wdGlvbnMudHlwZSA9PT0gXCJ0aWNrXCIgPyBxdWV1ZU1pY3JvdGFzayA6IG9wdGlvbnMudHlwZSA9PT0gXCJyYWZcIiA/IChcbiAgICAvLyByZXF1ZXN0QW5pbWF0aW9uRnJhbWUgd29uJ3QgZXhpc3QgaW4gU1NSIGVudmlyb25tZW50cy4gRmFsbCBiYWNrIHRvIGEgdmFndWUgYXBwcm94aW1hdGlvbiBqdXN0IHRvIGtlZXAgZnJvbSBlcnJvcmluZy5cbiAgICB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUgPyBjcmVhdGVSYWZXaXRoRmFsbGJhY2tUaW1lcih3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lLCAxMDApIDogY3JlYXRlUXVldWVXaXRoVGltZXIoMTApXG4gICkgOiBvcHRpb25zLnR5cGUgPT09IFwiY2FsbGJhY2tcIiA/IG9wdGlvbnMucXVldWVOb3RpZmljYXRpb24gOiBjcmVhdGVRdWV1ZVdpdGhUaW1lcihvcHRpb25zLnRpbWVvdXQpO1xuICBjb25zdCBub3RpZnlMaXN0ZW5lcnMgPSAoKSA9PiB7XG4gICAgbm90aWZpY2F0aW9uUXVldWVkID0gZmFsc2U7XG4gICAgaWYgKHNob3VsZE5vdGlmeUF0RW5kT2ZUaWNrKSB7XG4gICAgICBzaG91bGROb3RpZnlBdEVuZE9mVGljayA9IGZhbHNlO1xuICAgICAgbGlzdGVuZXJzLmZvckVhY2goKGwpID0+IGwoKSk7XG4gICAgfVxuICB9O1xuICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgc3RvcmUsIHtcbiAgICAvLyBPdmVycmlkZSB0aGUgYmFzZSBgc3RvcmUuc3Vic2NyaWJlYCBtZXRob2QgdG8ga2VlcCBvcmlnaW5hbCBsaXN0ZW5lcnNcbiAgICAvLyBmcm9tIHJ1bm5pbmcgaWYgd2UncmUgZGVsYXlpbmcgbm90aWZpY2F0aW9uc1xuICAgIHN1YnNjcmliZShsaXN0ZW5lcjIpIHtcbiAgICAgIGNvbnN0IHdyYXBwZWRMaXN0ZW5lciA9ICgpID0+IG5vdGlmeWluZyAmJiBsaXN0ZW5lcjIoKTtcbiAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gc3RvcmUuc3Vic2NyaWJlKHdyYXBwZWRMaXN0ZW5lcik7XG4gICAgICBsaXN0ZW5lcnMuYWRkKGxpc3RlbmVyMik7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICBsaXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyMik7XG4gICAgICB9O1xuICAgIH0sXG4gICAgLy8gT3ZlcnJpZGUgdGhlIGJhc2UgYHN0b3JlLmRpc3BhdGNoYCBtZXRob2Qgc28gdGhhdCB3ZSBjYW4gY2hlY2sgYWN0aW9uc1xuICAgIC8vIGZvciB0aGUgYHNob3VsZEF1dG9CYXRjaGAgZmxhZyBhbmQgZGV0ZXJtaW5lIGlmIGJhdGNoaW5nIGlzIGFjdGl2ZVxuICAgIGRpc3BhdGNoKGFjdGlvbikge1xuICAgICAgdHJ5IHtcbiAgICAgICAgbm90aWZ5aW5nID0gIWFjdGlvbj8ubWV0YT8uW1NIT1VMRF9BVVRPQkFUQ0hdO1xuICAgICAgICBzaG91bGROb3RpZnlBdEVuZE9mVGljayA9ICFub3RpZnlpbmc7XG4gICAgICAgIGlmIChzaG91bGROb3RpZnlBdEVuZE9mVGljaykge1xuICAgICAgICAgIGlmICghbm90aWZpY2F0aW9uUXVldWVkKSB7XG4gICAgICAgICAgICBub3RpZmljYXRpb25RdWV1ZWQgPSB0cnVlO1xuICAgICAgICAgICAgcXVldWVDYWxsYmFjayhub3RpZnlMaXN0ZW5lcnMpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RvcmUuZGlzcGF0Y2goYWN0aW9uKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIG5vdGlmeWluZyA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbn07XG5cbi8vIHNyYy9nZXREZWZhdWx0RW5oYW5jZXJzLnRzXG52YXIgYnVpbGRHZXREZWZhdWx0RW5oYW5jZXJzID0gKG1pZGRsZXdhcmVFbmhhbmNlcikgPT4gZnVuY3Rpb24gZ2V0RGVmYXVsdEVuaGFuY2VycyhvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICBhdXRvQmF0Y2ggPSB0cnVlXG4gIH0gPSBvcHRpb25zID8/IHt9O1xuICBsZXQgZW5oYW5jZXJBcnJheSA9IG5ldyBUdXBsZShtaWRkbGV3YXJlRW5oYW5jZXIpO1xuICBpZiAoYXV0b0JhdGNoKSB7XG4gICAgZW5oYW5jZXJBcnJheS5wdXNoKGF1dG9CYXRjaEVuaGFuY2VyKHR5cGVvZiBhdXRvQmF0Y2ggPT09IFwib2JqZWN0XCIgPyBhdXRvQmF0Y2ggOiB2b2lkIDApKTtcbiAgfVxuICByZXR1cm4gZW5oYW5jZXJBcnJheTtcbn07XG5cbi8vIHNyYy9jb25maWd1cmVTdG9yZS50c1xuZnVuY3Rpb24gY29uZmlndXJlU3RvcmUob3B0aW9ucykge1xuICBjb25zdCBnZXREZWZhdWx0TWlkZGxld2FyZSA9IGJ1aWxkR2V0RGVmYXVsdE1pZGRsZXdhcmUoKTtcbiAgY29uc3Qge1xuICAgIHJlZHVjZXIgPSB2b2lkIDAsXG4gICAgbWlkZGxld2FyZSxcbiAgICBkZXZUb29scyA9IHRydWUsXG4gICAgZHVwbGljYXRlTWlkZGxld2FyZUNoZWNrID0gdHJ1ZSxcbiAgICBwcmVsb2FkZWRTdGF0ZSA9IHZvaWQgMCxcbiAgICBlbmhhbmNlcnMgPSB2b2lkIDBcbiAgfSA9IG9wdGlvbnMgfHwge307XG4gIGxldCByb290UmVkdWNlcjtcbiAgaWYgKHR5cGVvZiByZWR1Y2VyID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByb290UmVkdWNlciA9IHJlZHVjZXI7XG4gIH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdChyZWR1Y2VyKSkge1xuICAgIHJvb3RSZWR1Y2VyID0gY29tYmluZVJlZHVjZXJzKHJlZHVjZXIpO1xuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEpIDogXCJgcmVkdWNlcmAgaXMgYSByZXF1aXJlZCBhcmd1bWVudCwgYW5kIG11c3QgYmUgYSBmdW5jdGlvbiBvciBhbiBvYmplY3Qgb2YgZnVuY3Rpb25zIHRoYXQgY2FuIGJlIHBhc3NlZCB0byBjb21iaW5lUmVkdWNlcnNcIik7XG4gIH1cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBtaWRkbGV3YXJlICYmIHR5cGVvZiBtaWRkbGV3YXJlICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgyKSA6IFwiYG1pZGRsZXdhcmVgIGZpZWxkIG11c3QgYmUgYSBjYWxsYmFja1wiKTtcbiAgfVxuICBsZXQgZmluYWxNaWRkbGV3YXJlO1xuICBpZiAodHlwZW9mIG1pZGRsZXdhcmUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGZpbmFsTWlkZGxld2FyZSA9IG1pZGRsZXdhcmUoZ2V0RGVmYXVsdE1pZGRsZXdhcmUpO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIUFycmF5LmlzQXJyYXkoZmluYWxNaWRkbGV3YXJlKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMykgOiBcIndoZW4gdXNpbmcgYSBtaWRkbGV3YXJlIGJ1aWxkZXIgZnVuY3Rpb24sIGFuIGFycmF5IG9mIG1pZGRsZXdhcmUgbXVzdCBiZSByZXR1cm5lZFwiKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZmluYWxNaWRkbGV3YXJlID0gZ2V0RGVmYXVsdE1pZGRsZXdhcmUoKTtcbiAgfVxuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGZpbmFsTWlkZGxld2FyZS5zb21lKChpdGVtKSA9PiB0eXBlb2YgaXRlbSAhPT0gXCJmdW5jdGlvblwiKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDQpIDogXCJlYWNoIG1pZGRsZXdhcmUgcHJvdmlkZWQgdG8gY29uZmlndXJlU3RvcmUgbXVzdCBiZSBhIGZ1bmN0aW9uXCIpO1xuICB9XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgZHVwbGljYXRlTWlkZGxld2FyZUNoZWNrKSB7XG4gICAgbGV0IG1pZGRsZXdhcmVSZWZlcmVuY2VzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgICBmaW5hbE1pZGRsZXdhcmUuZm9yRWFjaCgobWlkZGxld2FyZTIpID0+IHtcbiAgICAgIGlmIChtaWRkbGV3YXJlUmVmZXJlbmNlcy5oYXMobWlkZGxld2FyZTIpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDQyKSA6IFwiRHVwbGljYXRlIG1pZGRsZXdhcmUgcmVmZXJlbmNlcyBmb3VuZCB3aGVuIGNyZWF0aW5nIHRoZSBzdG9yZS4gRW5zdXJlIHRoYXQgZWFjaCBtaWRkbGV3YXJlIGlzIG9ubHkgaW5jbHVkZWQgb25jZS5cIik7XG4gICAgICB9XG4gICAgICBtaWRkbGV3YXJlUmVmZXJlbmNlcy5hZGQobWlkZGxld2FyZTIpO1xuICAgIH0pO1xuICB9XG4gIGxldCBmaW5hbENvbXBvc2UgPSBjb21wb3NlO1xuICBpZiAoZGV2VG9vbHMpIHtcbiAgICBmaW5hbENvbXBvc2UgPSBjb21wb3NlV2l0aERldlRvb2xzKHtcbiAgICAgIC8vIEVuYWJsZSBjYXB0dXJlIG9mIHN0YWNrIHRyYWNlcyBmb3IgZGlzcGF0Y2hlZCBSZWR1eCBhY3Rpb25zXG4gICAgICB0cmFjZTogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiLFxuICAgICAgLi4udHlwZW9mIGRldlRvb2xzID09PSBcIm9iamVjdFwiICYmIGRldlRvb2xzXG4gICAgfSk7XG4gIH1cbiAgY29uc3QgbWlkZGxld2FyZUVuaGFuY2VyID0gYXBwbHlNaWRkbGV3YXJlKC4uLmZpbmFsTWlkZGxld2FyZSk7XG4gIGNvbnN0IGdldERlZmF1bHRFbmhhbmNlcnMgPSBidWlsZEdldERlZmF1bHRFbmhhbmNlcnMobWlkZGxld2FyZUVuaGFuY2VyKTtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBlbmhhbmNlcnMgJiYgdHlwZW9mIGVuaGFuY2VycyAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoNSkgOiBcImBlbmhhbmNlcnNgIGZpZWxkIG11c3QgYmUgYSBjYWxsYmFja1wiKTtcbiAgfVxuICBsZXQgc3RvcmVFbmhhbmNlcnMgPSB0eXBlb2YgZW5oYW5jZXJzID09PSBcImZ1bmN0aW9uXCIgPyBlbmhhbmNlcnMoZ2V0RGVmYXVsdEVuaGFuY2VycykgOiBnZXREZWZhdWx0RW5oYW5jZXJzKCk7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIUFycmF5LmlzQXJyYXkoc3RvcmVFbmhhbmNlcnMpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoNikgOiBcImBlbmhhbmNlcnNgIGNhbGxiYWNrIG11c3QgcmV0dXJuIGFuIGFycmF5XCIpO1xuICB9XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgc3RvcmVFbmhhbmNlcnMuc29tZSgoaXRlbSkgPT4gdHlwZW9mIGl0ZW0gIT09IFwiZnVuY3Rpb25cIikpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg3KSA6IFwiZWFjaCBlbmhhbmNlciBwcm92aWRlZCB0byBjb25maWd1cmVTdG9yZSBtdXN0IGJlIGEgZnVuY3Rpb25cIik7XG4gIH1cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBmaW5hbE1pZGRsZXdhcmUubGVuZ3RoICYmICFzdG9yZUVuaGFuY2Vycy5pbmNsdWRlcyhtaWRkbGV3YXJlRW5oYW5jZXIpKSB7XG4gICAgY29uc29sZS5lcnJvcihcIm1pZGRsZXdhcmVzIHdlcmUgcHJvdmlkZWQsIGJ1dCBtaWRkbGV3YXJlIGVuaGFuY2VyIHdhcyBub3QgaW5jbHVkZWQgaW4gZmluYWwgZW5oYW5jZXJzIC0gbWFrZSBzdXJlIHRvIGNhbGwgYGdldERlZmF1bHRFbmhhbmNlcnNgXCIpO1xuICB9XG4gIGNvbnN0IGNvbXBvc2VkRW5oYW5jZXIgPSBmaW5hbENvbXBvc2UoLi4uc3RvcmVFbmhhbmNlcnMpO1xuICByZXR1cm4gY3JlYXRlU3RvcmUocm9vdFJlZHVjZXIsIHByZWxvYWRlZFN0YXRlLCBjb21wb3NlZEVuaGFuY2VyKTtcbn1cblxuLy8gc3JjL21hcEJ1aWxkZXJzLnRzXG5mdW5jdGlvbiBleGVjdXRlUmVkdWNlckJ1aWxkZXJDYWxsYmFjayhidWlsZGVyQ2FsbGJhY2spIHtcbiAgY29uc3QgYWN0aW9uc01hcCA9IHt9O1xuICBjb25zdCBhY3Rpb25NYXRjaGVycyA9IFtdO1xuICBsZXQgZGVmYXVsdENhc2VSZWR1Y2VyO1xuICBjb25zdCBidWlsZGVyID0ge1xuICAgIGFkZENhc2UodHlwZU9yQWN0aW9uQ3JlYXRvciwgcmVkdWNlcikge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICBpZiAoYWN0aW9uTWF0Y2hlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDI2KSA6IFwiYGJ1aWxkZXIuYWRkQ2FzZWAgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGJlZm9yZSBjYWxsaW5nIGBidWlsZGVyLmFkZE1hdGNoZXJgXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChkZWZhdWx0Q2FzZVJlZHVjZXIpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgyNykgOiBcImBidWlsZGVyLmFkZENhc2VgIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBiZWZvcmUgY2FsbGluZyBgYnVpbGRlci5hZGREZWZhdWx0Q2FzZWBcIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IHR5cGUgPSB0eXBlb2YgdHlwZU9yQWN0aW9uQ3JlYXRvciA9PT0gXCJzdHJpbmdcIiA/IHR5cGVPckFjdGlvbkNyZWF0b3IgOiB0eXBlT3JBY3Rpb25DcmVhdG9yLnR5cGU7XG4gICAgICBpZiAoIXR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMjgpIDogXCJgYnVpbGRlci5hZGRDYXNlYCBjYW5ub3QgYmUgY2FsbGVkIHdpdGggYW4gZW1wdHkgYWN0aW9uIHR5cGVcIik7XG4gICAgICB9XG4gICAgICBpZiAodHlwZSBpbiBhY3Rpb25zTWFwKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDI5KSA6IGBcXGBidWlsZGVyLmFkZENhc2VcXGAgY2Fubm90IGJlIGNhbGxlZCB3aXRoIHR3byByZWR1Y2VycyBmb3IgdGhlIHNhbWUgYWN0aW9uIHR5cGUgJyR7dHlwZX0nYCk7XG4gICAgICB9XG4gICAgICBhY3Rpb25zTWFwW3R5cGVdID0gcmVkdWNlcjtcbiAgICAgIHJldHVybiBidWlsZGVyO1xuICAgIH0sXG4gICAgYWRkQXN5bmNUaHVuayhhc3luY1RodW5rLCByZWR1Y2Vycykge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICBpZiAoZGVmYXVsdENhc2VSZWR1Y2VyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoNDMpIDogXCJgYnVpbGRlci5hZGRBc3luY1RodW5rYCBzaG91bGQgb25seSBiZSBjYWxsZWQgYmVmb3JlIGNhbGxpbmcgYGJ1aWxkZXIuYWRkRGVmYXVsdENhc2VgXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAocmVkdWNlcnMucGVuZGluZykgYWN0aW9uc01hcFthc3luY1RodW5rLnBlbmRpbmcudHlwZV0gPSByZWR1Y2Vycy5wZW5kaW5nO1xuICAgICAgaWYgKHJlZHVjZXJzLnJlamVjdGVkKSBhY3Rpb25zTWFwW2FzeW5jVGh1bmsucmVqZWN0ZWQudHlwZV0gPSByZWR1Y2Vycy5yZWplY3RlZDtcbiAgICAgIGlmIChyZWR1Y2Vycy5mdWxmaWxsZWQpIGFjdGlvbnNNYXBbYXN5bmNUaHVuay5mdWxmaWxsZWQudHlwZV0gPSByZWR1Y2Vycy5mdWxmaWxsZWQ7XG4gICAgICBpZiAocmVkdWNlcnMuc2V0dGxlZCkgYWN0aW9uTWF0Y2hlcnMucHVzaCh7XG4gICAgICAgIG1hdGNoZXI6IGFzeW5jVGh1bmsuc2V0dGxlZCxcbiAgICAgICAgcmVkdWNlcjogcmVkdWNlcnMuc2V0dGxlZFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gYnVpbGRlcjtcbiAgICB9LFxuICAgIGFkZE1hdGNoZXIobWF0Y2hlciwgcmVkdWNlcikge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICBpZiAoZGVmYXVsdENhc2VSZWR1Y2VyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMzApIDogXCJgYnVpbGRlci5hZGRNYXRjaGVyYCBzaG91bGQgb25seSBiZSBjYWxsZWQgYmVmb3JlIGNhbGxpbmcgYGJ1aWxkZXIuYWRkRGVmYXVsdENhc2VgXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhY3Rpb25NYXRjaGVycy5wdXNoKHtcbiAgICAgICAgbWF0Y2hlcixcbiAgICAgICAgcmVkdWNlclxuICAgICAgfSk7XG4gICAgICByZXR1cm4gYnVpbGRlcjtcbiAgICB9LFxuICAgIGFkZERlZmF1bHRDYXNlKHJlZHVjZXIpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgICAgaWYgKGRlZmF1bHRDYXNlUmVkdWNlcikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDMxKSA6IFwiYGJ1aWxkZXIuYWRkRGVmYXVsdENhc2VgIGNhbiBvbmx5IGJlIGNhbGxlZCBvbmNlXCIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBkZWZhdWx0Q2FzZVJlZHVjZXIgPSByZWR1Y2VyO1xuICAgICAgcmV0dXJuIGJ1aWxkZXI7XG4gICAgfVxuICB9O1xuICBidWlsZGVyQ2FsbGJhY2soYnVpbGRlcik7XG4gIHJldHVybiBbYWN0aW9uc01hcCwgYWN0aW9uTWF0Y2hlcnMsIGRlZmF1bHRDYXNlUmVkdWNlcl07XG59XG5cbi8vIHNyYy9jcmVhdGVSZWR1Y2VyLnRzXG5mdW5jdGlvbiBpc1N0YXRlRnVuY3Rpb24oeCkge1xuICByZXR1cm4gdHlwZW9mIHggPT09IFwiZnVuY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJlZHVjZXIoaW5pdGlhbFN0YXRlLCBtYXBPckJ1aWxkZXJDYWxsYmFjaykge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgaWYgKHR5cGVvZiBtYXBPckJ1aWxkZXJDYWxsYmFjayA9PT0gXCJvYmplY3RcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoOCkgOiBcIlRoZSBvYmplY3Qgbm90YXRpb24gZm9yIGBjcmVhdGVSZWR1Y2VyYCBoYXMgYmVlbiByZW1vdmVkLiBQbGVhc2UgdXNlIHRoZSAnYnVpbGRlciBjYWxsYmFjaycgbm90YXRpb24gaW5zdGVhZDogaHR0cHM6Ly9yZWR1eC10b29sa2l0LmpzLm9yZy9hcGkvY3JlYXRlUmVkdWNlclwiKTtcbiAgICB9XG4gIH1cbiAgbGV0IFthY3Rpb25zTWFwLCBmaW5hbEFjdGlvbk1hdGNoZXJzLCBmaW5hbERlZmF1bHRDYXNlUmVkdWNlcl0gPSBleGVjdXRlUmVkdWNlckJ1aWxkZXJDYWxsYmFjayhtYXBPckJ1aWxkZXJDYWxsYmFjayk7XG4gIGxldCBnZXRJbml0aWFsU3RhdGU7XG4gIGlmIChpc1N0YXRlRnVuY3Rpb24oaW5pdGlhbFN0YXRlKSkge1xuICAgIGdldEluaXRpYWxTdGF0ZSA9ICgpID0+IGZyZWV6ZURyYWZ0YWJsZShpbml0aWFsU3RhdGUoKSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgZnJvemVuSW5pdGlhbFN0YXRlID0gZnJlZXplRHJhZnRhYmxlKGluaXRpYWxTdGF0ZSk7XG4gICAgZ2V0SW5pdGlhbFN0YXRlID0gKCkgPT4gZnJvemVuSW5pdGlhbFN0YXRlO1xuICB9XG4gIGZ1bmN0aW9uIHJlZHVjZXIoc3RhdGUgPSBnZXRJbml0aWFsU3RhdGUoKSwgYWN0aW9uKSB7XG4gICAgbGV0IGNhc2VSZWR1Y2VycyA9IFthY3Rpb25zTWFwW2FjdGlvbi50eXBlXSwgLi4uZmluYWxBY3Rpb25NYXRjaGVycy5maWx0ZXIoKHtcbiAgICAgIG1hdGNoZXJcbiAgICB9KSA9PiBtYXRjaGVyKGFjdGlvbikpLm1hcCgoe1xuICAgICAgcmVkdWNlcjogcmVkdWNlcjJcbiAgICB9KSA9PiByZWR1Y2VyMildO1xuICAgIGlmIChjYXNlUmVkdWNlcnMuZmlsdGVyKChjcikgPT4gISFjcikubGVuZ3RoID09PSAwKSB7XG4gICAgICBjYXNlUmVkdWNlcnMgPSBbZmluYWxEZWZhdWx0Q2FzZVJlZHVjZXJdO1xuICAgIH1cbiAgICByZXR1cm4gY2FzZVJlZHVjZXJzLnJlZHVjZSgocHJldmlvdXNTdGF0ZSwgY2FzZVJlZHVjZXIpID0+IHtcbiAgICAgIGlmIChjYXNlUmVkdWNlcikge1xuICAgICAgICBpZiAoaXNEcmFmdChwcmV2aW91c1N0YXRlKSkge1xuICAgICAgICAgIGNvbnN0IGRyYWZ0ID0gcHJldmlvdXNTdGF0ZTtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBjYXNlUmVkdWNlcihkcmFmdCwgYWN0aW9uKTtcbiAgICAgICAgICBpZiAocmVzdWx0ID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgIHJldHVybiBwcmV2aW91c1N0YXRlO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9IGVsc2UgaWYgKCFpc0RyYWZ0YWJsZShwcmV2aW91c1N0YXRlKSkge1xuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGNhc2VSZWR1Y2VyKHByZXZpb3VzU3RhdGUsIGFjdGlvbik7XG4gICAgICAgICAgaWYgKHJlc3VsdCA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgICBpZiAocHJldmlvdXNTdGF0ZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICByZXR1cm4gcHJldmlvdXNTdGF0ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IEVycm9yKFwiQSBjYXNlIHJlZHVjZXIgb24gYSBub24tZHJhZnRhYmxlIHZhbHVlIG11c3Qgbm90IHJldHVybiB1bmRlZmluZWRcIik7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHByb2R1Y2UocHJldmlvdXNTdGF0ZSwgKGRyYWZ0KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gY2FzZVJlZHVjZXIoZHJhZnQsIGFjdGlvbik7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBwcmV2aW91c1N0YXRlO1xuICAgIH0sIHN0YXRlKTtcbiAgfVxuICByZWR1Y2VyLmdldEluaXRpYWxTdGF0ZSA9IGdldEluaXRpYWxTdGF0ZTtcbiAgcmV0dXJuIHJlZHVjZXI7XG59XG5cbi8vIHNyYy9tYXRjaGVycy50c1xudmFyIG1hdGNoZXMgPSAobWF0Y2hlciwgYWN0aW9uKSA9PiB7XG4gIGlmIChoYXNNYXRjaEZ1bmN0aW9uKG1hdGNoZXIpKSB7XG4gICAgcmV0dXJuIG1hdGNoZXIubWF0Y2goYWN0aW9uKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gbWF0Y2hlcihhY3Rpb24pO1xuICB9XG59O1xuZnVuY3Rpb24gaXNBbnlPZiguLi5tYXRjaGVycykge1xuICByZXR1cm4gKGFjdGlvbikgPT4ge1xuICAgIHJldHVybiBtYXRjaGVycy5zb21lKChtYXRjaGVyKSA9PiBtYXRjaGVzKG1hdGNoZXIsIGFjdGlvbikpO1xuICB9O1xufVxuZnVuY3Rpb24gaXNBbGxPZiguLi5tYXRjaGVycykge1xuICByZXR1cm4gKGFjdGlvbikgPT4ge1xuICAgIHJldHVybiBtYXRjaGVycy5ldmVyeSgobWF0Y2hlcikgPT4gbWF0Y2hlcyhtYXRjaGVyLCBhY3Rpb24pKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIGhhc0V4cGVjdGVkUmVxdWVzdE1ldGFkYXRhKGFjdGlvbiwgdmFsaWRTdGF0dXMpIHtcbiAgaWYgKCFhY3Rpb24gfHwgIWFjdGlvbi5tZXRhKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGhhc1ZhbGlkUmVxdWVzdElkID0gdHlwZW9mIGFjdGlvbi5tZXRhLnJlcXVlc3RJZCA9PT0gXCJzdHJpbmdcIjtcbiAgY29uc3QgaGFzVmFsaWRSZXF1ZXN0U3RhdHVzID0gdmFsaWRTdGF0dXMuaW5kZXhPZihhY3Rpb24ubWV0YS5yZXF1ZXN0U3RhdHVzKSA+IC0xO1xuICByZXR1cm4gaGFzVmFsaWRSZXF1ZXN0SWQgJiYgaGFzVmFsaWRSZXF1ZXN0U3RhdHVzO1xufVxuZnVuY3Rpb24gaXNBc3luY1RodW5rQXJyYXkoYSkge1xuICByZXR1cm4gdHlwZW9mIGFbMF0gPT09IFwiZnVuY3Rpb25cIiAmJiBcInBlbmRpbmdcIiBpbiBhWzBdICYmIFwiZnVsZmlsbGVkXCIgaW4gYVswXSAmJiBcInJlamVjdGVkXCIgaW4gYVswXTtcbn1cbmZ1bmN0aW9uIGlzUGVuZGluZyguLi5hc3luY1RodW5rcykge1xuICBpZiAoYXN5bmNUaHVua3MubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIChhY3Rpb24pID0+IGhhc0V4cGVjdGVkUmVxdWVzdE1ldGFkYXRhKGFjdGlvbiwgW1wicGVuZGluZ1wiXSk7XG4gIH1cbiAgaWYgKCFpc0FzeW5jVGh1bmtBcnJheShhc3luY1RodW5rcykpIHtcbiAgICByZXR1cm4gaXNQZW5kaW5nKCkoYXN5bmNUaHVua3NbMF0pO1xuICB9XG4gIHJldHVybiBpc0FueU9mKC4uLmFzeW5jVGh1bmtzLm1hcCgoYXN5bmNUaHVuaykgPT4gYXN5bmNUaHVuay5wZW5kaW5nKSk7XG59XG5mdW5jdGlvbiBpc1JlamVjdGVkKC4uLmFzeW5jVGh1bmtzKSB7XG4gIGlmIChhc3luY1RodW5rcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gKGFjdGlvbikgPT4gaGFzRXhwZWN0ZWRSZXF1ZXN0TWV0YWRhdGEoYWN0aW9uLCBbXCJyZWplY3RlZFwiXSk7XG4gIH1cbiAgaWYgKCFpc0FzeW5jVGh1bmtBcnJheShhc3luY1RodW5rcykpIHtcbiAgICByZXR1cm4gaXNSZWplY3RlZCgpKGFzeW5jVGh1bmtzWzBdKTtcbiAgfVxuICByZXR1cm4gaXNBbnlPZiguLi5hc3luY1RodW5rcy5tYXAoKGFzeW5jVGh1bmspID0+IGFzeW5jVGh1bmsucmVqZWN0ZWQpKTtcbn1cbmZ1bmN0aW9uIGlzUmVqZWN0ZWRXaXRoVmFsdWUoLi4uYXN5bmNUaHVua3MpIHtcbiAgY29uc3QgaGFzRmxhZyA9IChhY3Rpb24pID0+IHtcbiAgICByZXR1cm4gYWN0aW9uICYmIGFjdGlvbi5tZXRhICYmIGFjdGlvbi5tZXRhLnJlamVjdGVkV2l0aFZhbHVlO1xuICB9O1xuICBpZiAoYXN5bmNUaHVua3MubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIGlzQWxsT2YoaXNSZWplY3RlZCguLi5hc3luY1RodW5rcyksIGhhc0ZsYWcpO1xuICB9XG4gIGlmICghaXNBc3luY1RodW5rQXJyYXkoYXN5bmNUaHVua3MpKSB7XG4gICAgcmV0dXJuIGlzUmVqZWN0ZWRXaXRoVmFsdWUoKShhc3luY1RodW5rc1swXSk7XG4gIH1cbiAgcmV0dXJuIGlzQWxsT2YoaXNSZWplY3RlZCguLi5hc3luY1RodW5rcyksIGhhc0ZsYWcpO1xufVxuZnVuY3Rpb24gaXNGdWxmaWxsZWQoLi4uYXN5bmNUaHVua3MpIHtcbiAgaWYgKGFzeW5jVGh1bmtzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAoYWN0aW9uKSA9PiBoYXNFeHBlY3RlZFJlcXVlc3RNZXRhZGF0YShhY3Rpb24sIFtcImZ1bGZpbGxlZFwiXSk7XG4gIH1cbiAgaWYgKCFpc0FzeW5jVGh1bmtBcnJheShhc3luY1RodW5rcykpIHtcbiAgICByZXR1cm4gaXNGdWxmaWxsZWQoKShhc3luY1RodW5rc1swXSk7XG4gIH1cbiAgcmV0dXJuIGlzQW55T2YoLi4uYXN5bmNUaHVua3MubWFwKChhc3luY1RodW5rKSA9PiBhc3luY1RodW5rLmZ1bGZpbGxlZCkpO1xufVxuZnVuY3Rpb24gaXNBc3luY1RodW5rQWN0aW9uKC4uLmFzeW5jVGh1bmtzKSB7XG4gIGlmIChhc3luY1RodW5rcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gKGFjdGlvbikgPT4gaGFzRXhwZWN0ZWRSZXF1ZXN0TWV0YWRhdGEoYWN0aW9uLCBbXCJwZW5kaW5nXCIsIFwiZnVsZmlsbGVkXCIsIFwicmVqZWN0ZWRcIl0pO1xuICB9XG4gIGlmICghaXNBc3luY1RodW5rQXJyYXkoYXN5bmNUaHVua3MpKSB7XG4gICAgcmV0dXJuIGlzQXN5bmNUaHVua0FjdGlvbigpKGFzeW5jVGh1bmtzWzBdKTtcbiAgfVxuICByZXR1cm4gaXNBbnlPZiguLi5hc3luY1RodW5rcy5mbGF0TWFwKChhc3luY1RodW5rKSA9PiBbYXN5bmNUaHVuay5wZW5kaW5nLCBhc3luY1RodW5rLnJlamVjdGVkLCBhc3luY1RodW5rLmZ1bGZpbGxlZF0pKTtcbn1cblxuLy8gc3JjL25hbm9pZC50c1xudmFyIHVybEFscGhhYmV0ID0gXCJNb2R1bGVTeW1iaGFzT3duUHItMDEyMzQ1Njc4OUFCQ0RFRkdITlJWZmdjdGlVdnpfS3FZVEprTHhwWlhJalFXXCI7XG52YXIgbmFub2lkID0gKHNpemUgPSAyMSkgPT4ge1xuICBsZXQgaWQgPSBcIlwiO1xuICBsZXQgaSA9IHNpemU7XG4gIHdoaWxlIChpLS0pIHtcbiAgICBpZCArPSB1cmxBbHBoYWJldFtNYXRoLnJhbmRvbSgpICogNjQgfCAwXTtcbiAgfVxuICByZXR1cm4gaWQ7XG59O1xuXG4vLyBzcmMvY3JlYXRlQXN5bmNUaHVuay50c1xudmFyIGNvbW1vblByb3BlcnRpZXMgPSBbXCJuYW1lXCIsIFwibWVzc2FnZVwiLCBcInN0YWNrXCIsIFwiY29kZVwiXTtcbnZhciBSZWplY3RXaXRoVmFsdWUgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKHBheWxvYWQsIG1ldGEpIHtcbiAgICB0aGlzLnBheWxvYWQgPSBwYXlsb2FkO1xuICAgIHRoaXMubWV0YSA9IG1ldGE7XG4gIH1cbiAgcGF5bG9hZDtcbiAgbWV0YTtcbiAgLypcbiAgdHlwZS1vbmx5IHByb3BlcnR5IHRvIGRpc3Rpbmd1aXNoIGJldHdlZW4gUmVqZWN0V2l0aFZhbHVlIGFuZCBGdWxmaWxsV2l0aE1ldGFcbiAgZG9lcyBub3QgZXhpc3QgYXQgcnVudGltZVxuICAqL1xuICBfdHlwZTtcbn07XG52YXIgRnVsZmlsbFdpdGhNZXRhID0gY2xhc3Mge1xuICBjb25zdHJ1Y3RvcihwYXlsb2FkLCBtZXRhKSB7XG4gICAgdGhpcy5wYXlsb2FkID0gcGF5bG9hZDtcbiAgICB0aGlzLm1ldGEgPSBtZXRhO1xuICB9XG4gIHBheWxvYWQ7XG4gIG1ldGE7XG4gIC8qXG4gIHR5cGUtb25seSBwcm9wZXJ0eSB0byBkaXN0aW5ndWlzaCBiZXR3ZWVuIFJlamVjdFdpdGhWYWx1ZSBhbmQgRnVsZmlsbFdpdGhNZXRhXG4gIGRvZXMgbm90IGV4aXN0IGF0IHJ1bnRpbWVcbiAgKi9cbiAgX3R5cGU7XG59O1xudmFyIG1pbmlTZXJpYWxpemVFcnJvciA9ICh2YWx1ZSkgPT4ge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsKSB7XG4gICAgY29uc3Qgc2ltcGxlRXJyb3IgPSB7fTtcbiAgICBmb3IgKGNvbnN0IHByb3BlcnR5IG9mIGNvbW1vblByb3BlcnRpZXMpIHtcbiAgICAgIGlmICh0eXBlb2YgdmFsdWVbcHJvcGVydHldID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHNpbXBsZUVycm9yW3Byb3BlcnR5XSA9IHZhbHVlW3Byb3BlcnR5XTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHNpbXBsZUVycm9yO1xuICB9XG4gIHJldHVybiB7XG4gICAgbWVzc2FnZTogU3RyaW5nKHZhbHVlKVxuICB9O1xufTtcbnZhciBleHRlcm5hbEFib3J0TWVzc2FnZSA9IFwiRXh0ZXJuYWwgc2lnbmFsIHdhcyBhYm9ydGVkXCI7XG52YXIgY3JlYXRlQXN5bmNUaHVuayA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4ge1xuICBmdW5jdGlvbiBjcmVhdGVBc3luY1RodW5rMih0eXBlUHJlZml4LCBwYXlsb2FkQ3JlYXRvciwgb3B0aW9ucykge1xuICAgIGNvbnN0IGZ1bGZpbGxlZCA9IGNyZWF0ZUFjdGlvbih0eXBlUHJlZml4ICsgXCIvZnVsZmlsbGVkXCIsIChwYXlsb2FkLCByZXF1ZXN0SWQsIGFyZywgbWV0YSkgPT4gKHtcbiAgICAgIHBheWxvYWQsXG4gICAgICBtZXRhOiB7XG4gICAgICAgIC4uLm1ldGEgfHwge30sXG4gICAgICAgIGFyZyxcbiAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICByZXF1ZXN0U3RhdHVzOiBcImZ1bGZpbGxlZFwiXG4gICAgICB9XG4gICAgfSkpO1xuICAgIGNvbnN0IHBlbmRpbmcgPSBjcmVhdGVBY3Rpb24odHlwZVByZWZpeCArIFwiL3BlbmRpbmdcIiwgKHJlcXVlc3RJZCwgYXJnLCBtZXRhKSA9PiAoe1xuICAgICAgcGF5bG9hZDogdm9pZCAwLFxuICAgICAgbWV0YToge1xuICAgICAgICAuLi5tZXRhIHx8IHt9LFxuICAgICAgICBhcmcsXG4gICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICAgcmVxdWVzdFN0YXR1czogXCJwZW5kaW5nXCJcbiAgICAgIH1cbiAgICB9KSk7XG4gICAgY29uc3QgcmVqZWN0ZWQgPSBjcmVhdGVBY3Rpb24odHlwZVByZWZpeCArIFwiL3JlamVjdGVkXCIsIChlcnJvciwgcmVxdWVzdElkLCBhcmcsIHBheWxvYWQsIG1ldGEpID0+ICh7XG4gICAgICBwYXlsb2FkLFxuICAgICAgZXJyb3I6IChvcHRpb25zICYmIG9wdGlvbnMuc2VyaWFsaXplRXJyb3IgfHwgbWluaVNlcmlhbGl6ZUVycm9yKShlcnJvciB8fCBcIlJlamVjdGVkXCIpLFxuICAgICAgbWV0YToge1xuICAgICAgICAuLi5tZXRhIHx8IHt9LFxuICAgICAgICBhcmcsXG4gICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICAgcmVqZWN0ZWRXaXRoVmFsdWU6ICEhcGF5bG9hZCxcbiAgICAgICAgcmVxdWVzdFN0YXR1czogXCJyZWplY3RlZFwiLFxuICAgICAgICBhYm9ydGVkOiBlcnJvcj8ubmFtZSA9PT0gXCJBYm9ydEVycm9yXCIsXG4gICAgICAgIGNvbmRpdGlvbjogZXJyb3I/Lm5hbWUgPT09IFwiQ29uZGl0aW9uRXJyb3JcIlxuICAgICAgfVxuICAgIH0pKTtcbiAgICBmdW5jdGlvbiBhY3Rpb25DcmVhdG9yKGFyZywge1xuICAgICAgc2lnbmFsXG4gICAgfSA9IHt9KSB7XG4gICAgICByZXR1cm4gKGRpc3BhdGNoLCBnZXRTdGF0ZSwgZXh0cmEpID0+IHtcbiAgICAgICAgY29uc3QgcmVxdWVzdElkID0gb3B0aW9ucz8uaWRHZW5lcmF0b3IgPyBvcHRpb25zLmlkR2VuZXJhdG9yKGFyZykgOiBuYW5vaWQoKTtcbiAgICAgICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgICBsZXQgYWJvcnRIYW5kbGVyO1xuICAgICAgICBsZXQgYWJvcnRSZWFzb247XG4gICAgICAgIGZ1bmN0aW9uIGFib3J0KHJlYXNvbikge1xuICAgICAgICAgIGFib3J0UmVhc29uID0gcmVhc29uO1xuICAgICAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzaWduYWwpIHtcbiAgICAgICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgICAgIGFib3J0KGV4dGVybmFsQWJvcnRNZXNzYWdlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCAoKSA9PiBhYm9ydChleHRlcm5hbEFib3J0TWVzc2FnZSksIHtcbiAgICAgICAgICAgICAgb25jZTogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHByb21pc2UgPSAoYXN5bmMgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgbGV0IGZpbmFsQWN0aW9uO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBsZXQgY29uZGl0aW9uUmVzdWx0ID0gb3B0aW9ucz8uY29uZGl0aW9uPy4oYXJnLCB7XG4gICAgICAgICAgICAgIGdldFN0YXRlLFxuICAgICAgICAgICAgICBleHRyYVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoaXNUaGVuYWJsZShjb25kaXRpb25SZXN1bHQpKSB7XG4gICAgICAgICAgICAgIGNvbmRpdGlvblJlc3VsdCA9IGF3YWl0IGNvbmRpdGlvblJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjb25kaXRpb25SZXN1bHQgPT09IGZhbHNlIHx8IGFib3J0Q29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgICAgICB0aHJvdyB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJDb25kaXRpb25FcnJvclwiLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiQWJvcnRlZCBkdWUgdG8gY29uZGl0aW9uIGNhbGxiYWNrIHJldHVybmluZyBmYWxzZS5cIlxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgYWJvcnRlZFByb21pc2UgPSBuZXcgUHJvbWlzZSgoXywgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgIGFib3J0SGFuZGxlciA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICByZWplY3Qoe1xuICAgICAgICAgICAgICAgICAgbmFtZTogXCJBYm9ydEVycm9yXCIsXG4gICAgICAgICAgICAgICAgICBtZXNzYWdlOiBhYm9ydFJlYXNvbiB8fCBcIkFib3J0ZWRcIlxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydEhhbmRsZXIsIHtcbiAgICAgICAgICAgICAgICBvbmNlOiB0cnVlXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBkaXNwYXRjaChwZW5kaW5nKHJlcXVlc3RJZCwgYXJnLCBvcHRpb25zPy5nZXRQZW5kaW5nTWV0YT8uKHtcbiAgICAgICAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICAgICAgICBhcmdcbiAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgZ2V0U3RhdGUsXG4gICAgICAgICAgICAgIGV4dHJhXG4gICAgICAgICAgICB9KSkpO1xuICAgICAgICAgICAgZmluYWxBY3Rpb24gPSBhd2FpdCBQcm9taXNlLnJhY2UoW2Fib3J0ZWRQcm9taXNlLCBQcm9taXNlLnJlc29sdmUocGF5bG9hZENyZWF0b3IoYXJnLCB7XG4gICAgICAgICAgICAgIGRpc3BhdGNoLFxuICAgICAgICAgICAgICBnZXRTdGF0ZSxcbiAgICAgICAgICAgICAgZXh0cmEsXG4gICAgICAgICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAgICAgICBhYm9ydCxcbiAgICAgICAgICAgICAgcmVqZWN0V2l0aFZhbHVlOiAoKHZhbHVlLCBtZXRhKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBSZWplY3RXaXRoVmFsdWUodmFsdWUsIG1ldGEpO1xuICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgZnVsZmlsbFdpdGhWYWx1ZTogKCh2YWx1ZSwgbWV0YSkgPT4ge1xuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgRnVsZmlsbFdpdGhNZXRhKHZhbHVlLCBtZXRhKTtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pKS50aGVuKChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgaWYgKHJlc3VsdCBpbnN0YW5jZW9mIFJlamVjdFdpdGhWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHRocm93IHJlc3VsdDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAocmVzdWx0IGluc3RhbmNlb2YgRnVsZmlsbFdpdGhNZXRhKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bGZpbGxlZChyZXN1bHQucGF5bG9hZCwgcmVxdWVzdElkLCBhcmcsIHJlc3VsdC5tZXRhKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gZnVsZmlsbGVkKHJlc3VsdCwgcmVxdWVzdElkLCBhcmcpO1xuICAgICAgICAgICAgfSldKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGZpbmFsQWN0aW9uID0gZXJyIGluc3RhbmNlb2YgUmVqZWN0V2l0aFZhbHVlID8gcmVqZWN0ZWQobnVsbCwgcmVxdWVzdElkLCBhcmcsIGVyci5wYXlsb2FkLCBlcnIubWV0YSkgOiByZWplY3RlZChlcnIsIHJlcXVlc3RJZCwgYXJnKTtcbiAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgaWYgKGFib3J0SGFuZGxlcikge1xuICAgICAgICAgICAgICBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydEhhbmRsZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBza2lwRGlzcGF0Y2ggPSBvcHRpb25zICYmICFvcHRpb25zLmRpc3BhdGNoQ29uZGl0aW9uUmVqZWN0aW9uICYmIHJlamVjdGVkLm1hdGNoKGZpbmFsQWN0aW9uKSAmJiBmaW5hbEFjdGlvbi5tZXRhLmNvbmRpdGlvbjtcbiAgICAgICAgICBpZiAoIXNraXBEaXNwYXRjaCkge1xuICAgICAgICAgICAgZGlzcGF0Y2goZmluYWxBY3Rpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmluYWxBY3Rpb247XG4gICAgICAgIH0pKCk7XG4gICAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHByb21pc2UsIHtcbiAgICAgICAgICBhYm9ydCxcbiAgICAgICAgICByZXF1ZXN0SWQsXG4gICAgICAgICAgYXJnLFxuICAgICAgICAgIHVud3JhcCgpIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9taXNlLnRoZW4odW53cmFwUmVzdWx0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oYWN0aW9uQ3JlYXRvciwge1xuICAgICAgcGVuZGluZyxcbiAgICAgIHJlamVjdGVkLFxuICAgICAgZnVsZmlsbGVkLFxuICAgICAgc2V0dGxlZDogaXNBbnlPZihyZWplY3RlZCwgZnVsZmlsbGVkKSxcbiAgICAgIHR5cGVQcmVmaXhcbiAgICB9KTtcbiAgfVxuICBjcmVhdGVBc3luY1RodW5rMi53aXRoVHlwZXMgPSAoKSA9PiBjcmVhdGVBc3luY1RodW5rMjtcbiAgcmV0dXJuIGNyZWF0ZUFzeW5jVGh1bmsyO1xufSkoKTtcbmZ1bmN0aW9uIHVud3JhcFJlc3VsdChhY3Rpb24pIHtcbiAgaWYgKGFjdGlvbi5tZXRhICYmIGFjdGlvbi5tZXRhLnJlamVjdGVkV2l0aFZhbHVlKSB7XG4gICAgdGhyb3cgYWN0aW9uLnBheWxvYWQ7XG4gIH1cbiAgaWYgKGFjdGlvbi5lcnJvcikge1xuICAgIHRocm93IGFjdGlvbi5lcnJvcjtcbiAgfVxuICByZXR1cm4gYWN0aW9uLnBheWxvYWQ7XG59XG5mdW5jdGlvbiBpc1RoZW5hYmxlKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09IFwiZnVuY3Rpb25cIjtcbn1cblxuLy8gc3JjL2NyZWF0ZVNsaWNlLnRzXG52YXIgYXN5bmNUaHVua1N5bWJvbCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwicnRrLXNsaWNlLWNyZWF0ZWFzeW5jdGh1bmtcIik7XG52YXIgYXN5bmNUaHVua0NyZWF0b3IgPSB7XG4gIFthc3luY1RodW5rU3ltYm9sXTogY3JlYXRlQXN5bmNUaHVua1xufTtcbnZhciBSZWR1Y2VyVHlwZSA9IC8qIEBfX1BVUkVfXyAqLyAoKFJlZHVjZXJUeXBlMikgPT4ge1xuICBSZWR1Y2VyVHlwZTJbXCJyZWR1Y2VyXCJdID0gXCJyZWR1Y2VyXCI7XG4gIFJlZHVjZXJUeXBlMltcInJlZHVjZXJXaXRoUHJlcGFyZVwiXSA9IFwicmVkdWNlcldpdGhQcmVwYXJlXCI7XG4gIFJlZHVjZXJUeXBlMltcImFzeW5jVGh1bmtcIl0gPSBcImFzeW5jVGh1bmtcIjtcbiAgcmV0dXJuIFJlZHVjZXJUeXBlMjtcbn0pKFJlZHVjZXJUeXBlIHx8IHt9KTtcbmZ1bmN0aW9uIGdldFR5cGUoc2xpY2UsIGFjdGlvbktleSkge1xuICByZXR1cm4gYCR7c2xpY2V9LyR7YWN0aW9uS2V5fWA7XG59XG5mdW5jdGlvbiBidWlsZENyZWF0ZVNsaWNlKHtcbiAgY3JlYXRvcnNcbn0gPSB7fSkge1xuICBjb25zdCBjQVQgPSBjcmVhdG9ycz8uYXN5bmNUaHVuaz8uW2FzeW5jVGh1bmtTeW1ib2xdO1xuICByZXR1cm4gZnVuY3Rpb24gY3JlYXRlU2xpY2UyKG9wdGlvbnMpIHtcbiAgICBjb25zdCB7XG4gICAgICBuYW1lLFxuICAgICAgcmVkdWNlclBhdGggPSBuYW1lXG4gICAgfSA9IG9wdGlvbnM7XG4gICAgaWYgKCFuYW1lKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxMSkgOiBcImBuYW1lYCBpcyBhIHJlcXVpcmVkIG9wdGlvbiBmb3IgY3JlYXRlU2xpY2VcIik7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgcHJvY2VzcyAhPT0gXCJ1bmRlZmluZWRcIiAmJiBwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJkZXZlbG9wbWVudFwiKSB7XG4gICAgICBpZiAob3B0aW9ucy5pbml0aWFsU3RhdGUgPT09IHZvaWQgMCkge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiWW91IG11c3QgcHJvdmlkZSBhbiBgaW5pdGlhbFN0YXRlYCB2YWx1ZSB0aGF0IGlzIG5vdCBgdW5kZWZpbmVkYC4gWW91IG1heSBoYXZlIG1pc3NwZWxsZWQgYGluaXRpYWxTdGF0ZWBcIik7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHJlZHVjZXJzID0gKHR5cGVvZiBvcHRpb25zLnJlZHVjZXJzID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLnJlZHVjZXJzKGJ1aWxkUmVkdWNlckNyZWF0b3JzKCkpIDogb3B0aW9ucy5yZWR1Y2VycykgfHwge307XG4gICAgY29uc3QgcmVkdWNlck5hbWVzID0gT2JqZWN0LmtleXMocmVkdWNlcnMpO1xuICAgIGNvbnN0IGNvbnRleHQgPSB7XG4gICAgICBzbGljZUNhc2VSZWR1Y2Vyc0J5TmFtZToge30sXG4gICAgICBzbGljZUNhc2VSZWR1Y2Vyc0J5VHlwZToge30sXG4gICAgICBhY3Rpb25DcmVhdG9yczoge30sXG4gICAgICBzbGljZU1hdGNoZXJzOiBbXVxuICAgIH07XG4gICAgY29uc3QgY29udGV4dE1ldGhvZHMgPSB7XG4gICAgICBhZGRDYXNlKHR5cGVPckFjdGlvbkNyZWF0b3IsIHJlZHVjZXIyKSB7XG4gICAgICAgIGNvbnN0IHR5cGUgPSB0eXBlb2YgdHlwZU9yQWN0aW9uQ3JlYXRvciA9PT0gXCJzdHJpbmdcIiA/IHR5cGVPckFjdGlvbkNyZWF0b3IgOiB0eXBlT3JBY3Rpb25DcmVhdG9yLnR5cGU7XG4gICAgICAgIGlmICghdHlwZSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEyKSA6IFwiYGNvbnRleHQuYWRkQ2FzZWAgY2Fubm90IGJlIGNhbGxlZCB3aXRoIGFuIGVtcHR5IGFjdGlvbiB0eXBlXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlIGluIGNvbnRleHQuc2xpY2VDYXNlUmVkdWNlcnNCeVR5cGUpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxMykgOiBcImBjb250ZXh0LmFkZENhc2VgIGNhbm5vdCBiZSBjYWxsZWQgd2l0aCB0d28gcmVkdWNlcnMgZm9yIHRoZSBzYW1lIGFjdGlvbiB0eXBlOiBcIiArIHR5cGUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQuc2xpY2VDYXNlUmVkdWNlcnNCeVR5cGVbdHlwZV0gPSByZWR1Y2VyMjtcbiAgICAgICAgcmV0dXJuIGNvbnRleHRNZXRob2RzO1xuICAgICAgfSxcbiAgICAgIGFkZE1hdGNoZXIobWF0Y2hlciwgcmVkdWNlcjIpIHtcbiAgICAgICAgY29udGV4dC5zbGljZU1hdGNoZXJzLnB1c2goe1xuICAgICAgICAgIG1hdGNoZXIsXG4gICAgICAgICAgcmVkdWNlcjogcmVkdWNlcjJcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBjb250ZXh0TWV0aG9kcztcbiAgICAgIH0sXG4gICAgICBleHBvc2VBY3Rpb24obmFtZTIsIGFjdGlvbkNyZWF0b3IpIHtcbiAgICAgICAgY29udGV4dC5hY3Rpb25DcmVhdG9yc1tuYW1lMl0gPSBhY3Rpb25DcmVhdG9yO1xuICAgICAgICByZXR1cm4gY29udGV4dE1ldGhvZHM7XG4gICAgICB9LFxuICAgICAgZXhwb3NlQ2FzZVJlZHVjZXIobmFtZTIsIHJlZHVjZXIyKSB7XG4gICAgICAgIGNvbnRleHQuc2xpY2VDYXNlUmVkdWNlcnNCeU5hbWVbbmFtZTJdID0gcmVkdWNlcjI7XG4gICAgICAgIHJldHVybiBjb250ZXh0TWV0aG9kcztcbiAgICAgIH1cbiAgICB9O1xuICAgIHJlZHVjZXJOYW1lcy5mb3JFYWNoKChyZWR1Y2VyTmFtZSkgPT4ge1xuICAgICAgY29uc3QgcmVkdWNlckRlZmluaXRpb24gPSByZWR1Y2Vyc1tyZWR1Y2VyTmFtZV07XG4gICAgICBjb25zdCByZWR1Y2VyRGV0YWlscyA9IHtcbiAgICAgICAgcmVkdWNlck5hbWUsXG4gICAgICAgIHR5cGU6IGdldFR5cGUobmFtZSwgcmVkdWNlck5hbWUpLFxuICAgICAgICBjcmVhdGVOb3RhdGlvbjogdHlwZW9mIG9wdGlvbnMucmVkdWNlcnMgPT09IFwiZnVuY3Rpb25cIlxuICAgICAgfTtcbiAgICAgIGlmIChpc0FzeW5jVGh1bmtTbGljZVJlZHVjZXJEZWZpbml0aW9uKHJlZHVjZXJEZWZpbml0aW9uKSkge1xuICAgICAgICBoYW5kbGVUaHVua0Nhc2VSZWR1Y2VyRGVmaW5pdGlvbihyZWR1Y2VyRGV0YWlscywgcmVkdWNlckRlZmluaXRpb24sIGNvbnRleHRNZXRob2RzLCBjQVQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaGFuZGxlTm9ybWFsUmVkdWNlckRlZmluaXRpb24ocmVkdWNlckRldGFpbHMsIHJlZHVjZXJEZWZpbml0aW9uLCBjb250ZXh0TWV0aG9kcyk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgZnVuY3Rpb24gYnVpbGRSZWR1Y2VyKCkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICBpZiAodHlwZW9mIG9wdGlvbnMuZXh0cmFSZWR1Y2VycyA9PT0gXCJvYmplY3RcIikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDE0KSA6IFwiVGhlIG9iamVjdCBub3RhdGlvbiBmb3IgYGNyZWF0ZVNsaWNlLmV4dHJhUmVkdWNlcnNgIGhhcyBiZWVuIHJlbW92ZWQuIFBsZWFzZSB1c2UgdGhlICdidWlsZGVyIGNhbGxiYWNrJyBub3RhdGlvbiBpbnN0ZWFkOiBodHRwczovL3JlZHV4LXRvb2xraXQuanMub3JnL2FwaS9jcmVhdGVTbGljZVwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3QgW2V4dHJhUmVkdWNlcnMgPSB7fSwgYWN0aW9uTWF0Y2hlcnMgPSBbXSwgZGVmYXVsdENhc2VSZWR1Y2VyID0gdm9pZCAwXSA9IHR5cGVvZiBvcHRpb25zLmV4dHJhUmVkdWNlcnMgPT09IFwiZnVuY3Rpb25cIiA/IGV4ZWN1dGVSZWR1Y2VyQnVpbGRlckNhbGxiYWNrKG9wdGlvbnMuZXh0cmFSZWR1Y2VycykgOiBbb3B0aW9ucy5leHRyYVJlZHVjZXJzXTtcbiAgICAgIGNvbnN0IGZpbmFsQ2FzZVJlZHVjZXJzID0ge1xuICAgICAgICAuLi5leHRyYVJlZHVjZXJzLFxuICAgICAgICAuLi5jb250ZXh0LnNsaWNlQ2FzZVJlZHVjZXJzQnlUeXBlXG4gICAgICB9O1xuICAgICAgcmV0dXJuIGNyZWF0ZVJlZHVjZXIob3B0aW9ucy5pbml0aWFsU3RhdGUsIChidWlsZGVyKSA9PiB7XG4gICAgICAgIGZvciAobGV0IGtleSBpbiBmaW5hbENhc2VSZWR1Y2Vycykge1xuICAgICAgICAgIGJ1aWxkZXIuYWRkQ2FzZShrZXksIGZpbmFsQ2FzZVJlZHVjZXJzW2tleV0pO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IHNNIG9mIGNvbnRleHQuc2xpY2VNYXRjaGVycykge1xuICAgICAgICAgIGJ1aWxkZXIuYWRkTWF0Y2hlcihzTS5tYXRjaGVyLCBzTS5yZWR1Y2VyKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBtIG9mIGFjdGlvbk1hdGNoZXJzKSB7XG4gICAgICAgICAgYnVpbGRlci5hZGRNYXRjaGVyKG0ubWF0Y2hlciwgbS5yZWR1Y2VyKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZGVmYXVsdENhc2VSZWR1Y2VyKSB7XG4gICAgICAgICAgYnVpbGRlci5hZGREZWZhdWx0Q2FzZShkZWZhdWx0Q2FzZVJlZHVjZXIpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgY29uc3Qgc2VsZWN0U2VsZiA9IChzdGF0ZSkgPT4gc3RhdGU7XG4gICAgY29uc3QgaW5qZWN0ZWRTZWxlY3RvckNhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICBjb25zdCBpbmplY3RlZFN0YXRlQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbiAgICBsZXQgX3JlZHVjZXI7XG4gICAgZnVuY3Rpb24gcmVkdWNlcihzdGF0ZSwgYWN0aW9uKSB7XG4gICAgICBpZiAoIV9yZWR1Y2VyKSBfcmVkdWNlciA9IGJ1aWxkUmVkdWNlcigpO1xuICAgICAgcmV0dXJuIF9yZWR1Y2VyKHN0YXRlLCBhY3Rpb24pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRJbml0aWFsU3RhdGUoKSB7XG4gICAgICBpZiAoIV9yZWR1Y2VyKSBfcmVkdWNlciA9IGJ1aWxkUmVkdWNlcigpO1xuICAgICAgcmV0dXJuIF9yZWR1Y2VyLmdldEluaXRpYWxTdGF0ZSgpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBtYWtlU2VsZWN0b3JQcm9wcyhyZWR1Y2VyUGF0aDIsIGluamVjdGVkID0gZmFsc2UpIHtcbiAgICAgIGZ1bmN0aW9uIHNlbGVjdFNsaWNlKHN0YXRlKSB7XG4gICAgICAgIGxldCBzbGljZVN0YXRlID0gc3RhdGVbcmVkdWNlclBhdGgyXTtcbiAgICAgICAgaWYgKHR5cGVvZiBzbGljZVN0YXRlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgaWYgKGluamVjdGVkKSB7XG4gICAgICAgICAgICBzbGljZVN0YXRlID0gZ2V0T3JJbnNlcnRDb21wdXRlZChpbmplY3RlZFN0YXRlQ2FjaGUsIHNlbGVjdFNsaWNlLCBnZXRJbml0aWFsU3RhdGUpO1xuICAgICAgICAgIH0gZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxNSkgOiBcInNlbGVjdFNsaWNlIHJldHVybmVkIHVuZGVmaW5lZCBmb3IgYW4gdW5pbmplY3RlZCBzbGljZSByZWR1Y2VyXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2xpY2VTdGF0ZTtcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIGdldFNlbGVjdG9ycyhzZWxlY3RTdGF0ZSA9IHNlbGVjdFNlbGYpIHtcbiAgICAgICAgY29uc3Qgc2VsZWN0b3JDYWNoZSA9IGdldE9ySW5zZXJ0Q29tcHV0ZWQoaW5qZWN0ZWRTZWxlY3RvckNhY2hlLCBpbmplY3RlZCwgKCkgPT4gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCkpO1xuICAgICAgICByZXR1cm4gZ2V0T3JJbnNlcnRDb21wdXRlZChzZWxlY3RvckNhY2hlLCBzZWxlY3RTdGF0ZSwgKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IG1hcCA9IHt9O1xuICAgICAgICAgIGZvciAoY29uc3QgW25hbWUyLCBzZWxlY3Rvcl0gb2YgT2JqZWN0LmVudHJpZXMob3B0aW9ucy5zZWxlY3RvcnMgPz8ge30pKSB7XG4gICAgICAgICAgICBtYXBbbmFtZTJdID0gd3JhcFNlbGVjdG9yKHNlbGVjdG9yLCBzZWxlY3RTdGF0ZSwgKCkgPT4gZ2V0T3JJbnNlcnRDb21wdXRlZChpbmplY3RlZFN0YXRlQ2FjaGUsIHNlbGVjdFN0YXRlLCBnZXRJbml0aWFsU3RhdGUpLCBpbmplY3RlZCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBtYXA7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcmVkdWNlclBhdGg6IHJlZHVjZXJQYXRoMixcbiAgICAgICAgZ2V0U2VsZWN0b3JzLFxuICAgICAgICBnZXQgc2VsZWN0b3JzKCkge1xuICAgICAgICAgIHJldHVybiBnZXRTZWxlY3RvcnMoc2VsZWN0U2xpY2UpO1xuICAgICAgICB9LFxuICAgICAgICBzZWxlY3RTbGljZVxuICAgICAgfTtcbiAgICB9XG4gICAgY29uc3Qgc2xpY2UgPSB7XG4gICAgICBuYW1lLFxuICAgICAgcmVkdWNlcixcbiAgICAgIGFjdGlvbnM6IGNvbnRleHQuYWN0aW9uQ3JlYXRvcnMsXG4gICAgICBjYXNlUmVkdWNlcnM6IGNvbnRleHQuc2xpY2VDYXNlUmVkdWNlcnNCeU5hbWUsXG4gICAgICBnZXRJbml0aWFsU3RhdGUsXG4gICAgICAuLi5tYWtlU2VsZWN0b3JQcm9wcyhyZWR1Y2VyUGF0aCksXG4gICAgICBpbmplY3RJbnRvKGluamVjdGFibGUsIHtcbiAgICAgICAgcmVkdWNlclBhdGg6IHBhdGhPcHQsXG4gICAgICAgIC4uLmNvbmZpZ1xuICAgICAgfSA9IHt9KSB7XG4gICAgICAgIGNvbnN0IG5ld1JlZHVjZXJQYXRoID0gcGF0aE9wdCA/PyByZWR1Y2VyUGF0aDtcbiAgICAgICAgaW5qZWN0YWJsZS5pbmplY3Qoe1xuICAgICAgICAgIHJlZHVjZXJQYXRoOiBuZXdSZWR1Y2VyUGF0aCxcbiAgICAgICAgICByZWR1Y2VyXG4gICAgICAgIH0sIGNvbmZpZyk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4uc2xpY2UsXG4gICAgICAgICAgLi4ubWFrZVNlbGVjdG9yUHJvcHMobmV3UmVkdWNlclBhdGgsIHRydWUpXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gc2xpY2U7XG4gIH07XG59XG5mdW5jdGlvbiB3cmFwU2VsZWN0b3Ioc2VsZWN0b3IsIHNlbGVjdFN0YXRlLCBnZXRJbml0aWFsU3RhdGUsIGluamVjdGVkKSB7XG4gIGZ1bmN0aW9uIHdyYXBwZXIocm9vdFN0YXRlLCAuLi5hcmdzKSB7XG4gICAgbGV0IHNsaWNlU3RhdGUgPSBzZWxlY3RTdGF0ZShyb290U3RhdGUpO1xuICAgIGlmICh0eXBlb2Ygc2xpY2VTdGF0ZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgaWYgKGluamVjdGVkKSB7XG4gICAgICAgIHNsaWNlU3RhdGUgPSBnZXRJbml0aWFsU3RhdGUoKTtcbiAgICAgIH0gZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDE2KSA6IFwic2VsZWN0U3RhdGUgcmV0dXJuZWQgdW5kZWZpbmVkIGZvciBhbiB1bmluamVjdGVkIHNsaWNlIHJlZHVjZXJcIik7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzZWxlY3RvcihzbGljZVN0YXRlLCAuLi5hcmdzKTtcbiAgfVxuICB3cmFwcGVyLnVud3JhcHBlZCA9IHNlbGVjdG9yO1xuICByZXR1cm4gd3JhcHBlcjtcbn1cbnZhciBjcmVhdGVTbGljZSA9IC8qIEBfX1BVUkVfXyAqLyBidWlsZENyZWF0ZVNsaWNlKCk7XG5mdW5jdGlvbiBidWlsZFJlZHVjZXJDcmVhdG9ycygpIHtcbiAgZnVuY3Rpb24gYXN5bmNUaHVuayhwYXlsb2FkQ3JlYXRvciwgY29uZmlnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIF9yZWR1Y2VyRGVmaW5pdGlvblR5cGU6IFwiYXN5bmNUaHVua1wiIC8qIGFzeW5jVGh1bmsgKi8sXG4gICAgICBwYXlsb2FkQ3JlYXRvcixcbiAgICAgIC4uLmNvbmZpZ1xuICAgIH07XG4gIH1cbiAgYXN5bmNUaHVuay53aXRoVHlwZXMgPSAoKSA9PiBhc3luY1RodW5rO1xuICByZXR1cm4ge1xuICAgIHJlZHVjZXIoY2FzZVJlZHVjZXIpIHtcbiAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgLy8gaGFjayBzbyB0aGUgd3JhcHBpbmcgZnVuY3Rpb24gaGFzIHRoZSBzYW1lIG5hbWUgYXMgdGhlIG9yaWdpbmFsXG4gICAgICAgIC8vIHdlIG5lZWQgdG8gY3JlYXRlIGEgd3JhcHBlciBzbyB0aGUgYHJlZHVjZXJEZWZpbml0aW9uVHlwZWAgaXMgbm90IGFzc2lnbmVkIHRvIHRoZSBvcmlnaW5hbFxuICAgICAgICBbY2FzZVJlZHVjZXIubmFtZV0oLi4uYXJncykge1xuICAgICAgICAgIHJldHVybiBjYXNlUmVkdWNlciguLi5hcmdzKTtcbiAgICAgICAgfVxuICAgICAgfVtjYXNlUmVkdWNlci5uYW1lXSwge1xuICAgICAgICBfcmVkdWNlckRlZmluaXRpb25UeXBlOiBcInJlZHVjZXJcIiAvKiByZWR1Y2VyICovXG4gICAgICB9KTtcbiAgICB9LFxuICAgIHByZXBhcmVkUmVkdWNlcihwcmVwYXJlLCByZWR1Y2VyKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBfcmVkdWNlckRlZmluaXRpb25UeXBlOiBcInJlZHVjZXJXaXRoUHJlcGFyZVwiIC8qIHJlZHVjZXJXaXRoUHJlcGFyZSAqLyxcbiAgICAgICAgcHJlcGFyZSxcbiAgICAgICAgcmVkdWNlclxuICAgICAgfTtcbiAgICB9LFxuICAgIGFzeW5jVGh1bmtcbiAgfTtcbn1cbmZ1bmN0aW9uIGhhbmRsZU5vcm1hbFJlZHVjZXJEZWZpbml0aW9uKHtcbiAgdHlwZSxcbiAgcmVkdWNlck5hbWUsXG4gIGNyZWF0ZU5vdGF0aW9uXG59LCBtYXliZVJlZHVjZXJXaXRoUHJlcGFyZSwgY29udGV4dCkge1xuICBsZXQgY2FzZVJlZHVjZXI7XG4gIGxldCBwcmVwYXJlQ2FsbGJhY2s7XG4gIGlmIChcInJlZHVjZXJcIiBpbiBtYXliZVJlZHVjZXJXaXRoUHJlcGFyZSkge1xuICAgIGlmIChjcmVhdGVOb3RhdGlvbiAmJiAhaXNDYXNlUmVkdWNlcldpdGhQcmVwYXJlRGVmaW5pdGlvbihtYXliZVJlZHVjZXJXaXRoUHJlcGFyZSkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDE3KSA6IFwiUGxlYXNlIHVzZSB0aGUgYGNyZWF0ZS5wcmVwYXJlZFJlZHVjZXJgIG5vdGF0aW9uIGZvciBwcmVwYXJlZCBhY3Rpb24gY3JlYXRvcnMgd2l0aCB0aGUgYGNyZWF0ZWAgbm90YXRpb24uXCIpO1xuICAgIH1cbiAgICBjYXNlUmVkdWNlciA9IG1heWJlUmVkdWNlcldpdGhQcmVwYXJlLnJlZHVjZXI7XG4gICAgcHJlcGFyZUNhbGxiYWNrID0gbWF5YmVSZWR1Y2VyV2l0aFByZXBhcmUucHJlcGFyZTtcbiAgfSBlbHNlIHtcbiAgICBjYXNlUmVkdWNlciA9IG1heWJlUmVkdWNlcldpdGhQcmVwYXJlO1xuICB9XG4gIGNvbnRleHQuYWRkQ2FzZSh0eXBlLCBjYXNlUmVkdWNlcikuZXhwb3NlQ2FzZVJlZHVjZXIocmVkdWNlck5hbWUsIGNhc2VSZWR1Y2VyKS5leHBvc2VBY3Rpb24ocmVkdWNlck5hbWUsIHByZXBhcmVDYWxsYmFjayA/IGNyZWF0ZUFjdGlvbih0eXBlLCBwcmVwYXJlQ2FsbGJhY2spIDogY3JlYXRlQWN0aW9uKHR5cGUpKTtcbn1cbmZ1bmN0aW9uIGlzQXN5bmNUaHVua1NsaWNlUmVkdWNlckRlZmluaXRpb24ocmVkdWNlckRlZmluaXRpb24pIHtcbiAgcmV0dXJuIHJlZHVjZXJEZWZpbml0aW9uLl9yZWR1Y2VyRGVmaW5pdGlvblR5cGUgPT09IFwiYXN5bmNUaHVua1wiIC8qIGFzeW5jVGh1bmsgKi87XG59XG5mdW5jdGlvbiBpc0Nhc2VSZWR1Y2VyV2l0aFByZXBhcmVEZWZpbml0aW9uKHJlZHVjZXJEZWZpbml0aW9uKSB7XG4gIHJldHVybiByZWR1Y2VyRGVmaW5pdGlvbi5fcmVkdWNlckRlZmluaXRpb25UeXBlID09PSBcInJlZHVjZXJXaXRoUHJlcGFyZVwiIC8qIHJlZHVjZXJXaXRoUHJlcGFyZSAqLztcbn1cbmZ1bmN0aW9uIGhhbmRsZVRodW5rQ2FzZVJlZHVjZXJEZWZpbml0aW9uKHtcbiAgdHlwZSxcbiAgcmVkdWNlck5hbWVcbn0sIHJlZHVjZXJEZWZpbml0aW9uLCBjb250ZXh0LCBjQVQpIHtcbiAgaWYgKCFjQVQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxOCkgOiBcIkNhbm5vdCB1c2UgYGNyZWF0ZS5hc3luY1RodW5rYCBpbiB0aGUgYnVpbHQtaW4gYGNyZWF0ZVNsaWNlYC4gVXNlIGBidWlsZENyZWF0ZVNsaWNlKHsgY3JlYXRvcnM6IHsgYXN5bmNUaHVuazogYXN5bmNUaHVua0NyZWF0b3IgfSB9KWAgdG8gY3JlYXRlIGEgY3VzdG9taXNlZCB2ZXJzaW9uIG9mIGBjcmVhdGVTbGljZWAuXCIpO1xuICB9XG4gIGNvbnN0IHtcbiAgICBwYXlsb2FkQ3JlYXRvcixcbiAgICBmdWxmaWxsZWQsXG4gICAgcGVuZGluZyxcbiAgICByZWplY3RlZCxcbiAgICBzZXR0bGVkLFxuICAgIG9wdGlvbnNcbiAgfSA9IHJlZHVjZXJEZWZpbml0aW9uO1xuICBjb25zdCB0aHVuayA9IGNBVCh0eXBlLCBwYXlsb2FkQ3JlYXRvciwgb3B0aW9ucyk7XG4gIGNvbnRleHQuZXhwb3NlQWN0aW9uKHJlZHVjZXJOYW1lLCB0aHVuayk7XG4gIGlmIChmdWxmaWxsZWQpIHtcbiAgICBjb250ZXh0LmFkZENhc2UodGh1bmsuZnVsZmlsbGVkLCBmdWxmaWxsZWQpO1xuICB9XG4gIGlmIChwZW5kaW5nKSB7XG4gICAgY29udGV4dC5hZGRDYXNlKHRodW5rLnBlbmRpbmcsIHBlbmRpbmcpO1xuICB9XG4gIGlmIChyZWplY3RlZCkge1xuICAgIGNvbnRleHQuYWRkQ2FzZSh0aHVuay5yZWplY3RlZCwgcmVqZWN0ZWQpO1xuICB9XG4gIGlmIChzZXR0bGVkKSB7XG4gICAgY29udGV4dC5hZGRNYXRjaGVyKHRodW5rLnNldHRsZWQsIHNldHRsZWQpO1xuICB9XG4gIGNvbnRleHQuZXhwb3NlQ2FzZVJlZHVjZXIocmVkdWNlck5hbWUsIHtcbiAgICBmdWxmaWxsZWQ6IGZ1bGZpbGxlZCB8fCBub29wLFxuICAgIHBlbmRpbmc6IHBlbmRpbmcgfHwgbm9vcCxcbiAgICByZWplY3RlZDogcmVqZWN0ZWQgfHwgbm9vcCxcbiAgICBzZXR0bGVkOiBzZXR0bGVkIHx8IG5vb3BcbiAgfSk7XG59XG5mdW5jdGlvbiBub29wKCkge1xufVxuXG4vLyBzcmMvZW50aXRpZXMvZW50aXR5X3N0YXRlLnRzXG5mdW5jdGlvbiBnZXRJbml0aWFsRW50aXR5U3RhdGUoKSB7XG4gIHJldHVybiB7XG4gICAgaWRzOiBbXSxcbiAgICBlbnRpdGllczoge31cbiAgfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxTdGF0ZUZhY3Rvcnkoc3RhdGVBZGFwdGVyKSB7XG4gIGZ1bmN0aW9uIGdldEluaXRpYWxTdGF0ZShhZGRpdGlvbmFsU3RhdGUgPSB7fSwgZW50aXRpZXMpIHtcbiAgICBjb25zdCBzdGF0ZSA9IE9iamVjdC5hc3NpZ24oZ2V0SW5pdGlhbEVudGl0eVN0YXRlKCksIGFkZGl0aW9uYWxTdGF0ZSk7XG4gICAgcmV0dXJuIGVudGl0aWVzID8gc3RhdGVBZGFwdGVyLnNldEFsbChzdGF0ZSwgZW50aXRpZXMpIDogc3RhdGU7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBnZXRJbml0aWFsU3RhdGVcbiAgfTtcbn1cblxuLy8gc3JjL2VudGl0aWVzL3N0YXRlX3NlbGVjdG9ycy50c1xuZnVuY3Rpb24gY3JlYXRlU2VsZWN0b3JzRmFjdG9yeSgpIHtcbiAgZnVuY3Rpb24gZ2V0U2VsZWN0b3JzKHNlbGVjdFN0YXRlLCBvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCB7XG4gICAgICBjcmVhdGVTZWxlY3RvcjogY3JlYXRlU2VsZWN0b3IyID0gY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3JcbiAgICB9ID0gb3B0aW9ucztcbiAgICBjb25zdCBzZWxlY3RJZHMgPSAoc3RhdGUpID0+IHN0YXRlLmlkcztcbiAgICBjb25zdCBzZWxlY3RFbnRpdGllcyA9IChzdGF0ZSkgPT4gc3RhdGUuZW50aXRpZXM7XG4gICAgY29uc3Qgc2VsZWN0QWxsID0gY3JlYXRlU2VsZWN0b3IyKHNlbGVjdElkcywgc2VsZWN0RW50aXRpZXMsIChpZHMsIGVudGl0aWVzKSA9PiBpZHMubWFwKChpZCkgPT4gZW50aXRpZXNbaWRdKSk7XG4gICAgY29uc3Qgc2VsZWN0SWQgPSAoXywgaWQpID0+IGlkO1xuICAgIGNvbnN0IHNlbGVjdEJ5SWQgPSAoZW50aXRpZXMsIGlkKSA9PiBlbnRpdGllc1tpZF07XG4gICAgY29uc3Qgc2VsZWN0VG90YWwgPSBjcmVhdGVTZWxlY3RvcjIoc2VsZWN0SWRzLCAoaWRzKSA9PiBpZHMubGVuZ3RoKTtcbiAgICBpZiAoIXNlbGVjdFN0YXRlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzZWxlY3RJZHMsXG4gICAgICAgIHNlbGVjdEVudGl0aWVzLFxuICAgICAgICBzZWxlY3RBbGwsXG4gICAgICAgIHNlbGVjdFRvdGFsLFxuICAgICAgICBzZWxlY3RCeUlkOiBjcmVhdGVTZWxlY3RvcjIoc2VsZWN0RW50aXRpZXMsIHNlbGVjdElkLCBzZWxlY3RCeUlkKVxuICAgICAgfTtcbiAgICB9XG4gICAgY29uc3Qgc2VsZWN0R2xvYmFsaXplZEVudGl0aWVzID0gY3JlYXRlU2VsZWN0b3IyKHNlbGVjdFN0YXRlLCBzZWxlY3RFbnRpdGllcyk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHNlbGVjdElkczogY3JlYXRlU2VsZWN0b3IyKHNlbGVjdFN0YXRlLCBzZWxlY3RJZHMpLFxuICAgICAgc2VsZWN0RW50aXRpZXM6IHNlbGVjdEdsb2JhbGl6ZWRFbnRpdGllcyxcbiAgICAgIHNlbGVjdEFsbDogY3JlYXRlU2VsZWN0b3IyKHNlbGVjdFN0YXRlLCBzZWxlY3RBbGwpLFxuICAgICAgc2VsZWN0VG90YWw6IGNyZWF0ZVNlbGVjdG9yMihzZWxlY3RTdGF0ZSwgc2VsZWN0VG90YWwpLFxuICAgICAgc2VsZWN0QnlJZDogY3JlYXRlU2VsZWN0b3IyKHNlbGVjdEdsb2JhbGl6ZWRFbnRpdGllcywgc2VsZWN0SWQsIHNlbGVjdEJ5SWQpXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGdldFNlbGVjdG9yc1xuICB9O1xufVxuXG4vLyBzcmMvZW50aXRpZXMvc3RhdGVfYWRhcHRlci50c1xudmFyIGlzRHJhZnRUeXBlZCA9IGlzRHJhZnQ7XG5mdW5jdGlvbiBjcmVhdGVTaW5nbGVBcmd1bWVudFN0YXRlT3BlcmF0b3IobXV0YXRvcikge1xuICBjb25zdCBvcGVyYXRvciA9IGNyZWF0ZVN0YXRlT3BlcmF0b3IoKF8sIHN0YXRlKSA9PiBtdXRhdG9yKHN0YXRlKSk7XG4gIHJldHVybiBmdW5jdGlvbiBvcGVyYXRpb24oc3RhdGUpIHtcbiAgICByZXR1cm4gb3BlcmF0b3Ioc3RhdGUsIHZvaWQgMCk7XG4gIH07XG59XG5mdW5jdGlvbiBjcmVhdGVTdGF0ZU9wZXJhdG9yKG11dGF0b3IpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIG9wZXJhdGlvbihzdGF0ZSwgYXJnKSB7XG4gICAgZnVuY3Rpb24gaXNQYXlsb2FkQWN0aW9uQXJndW1lbnQoYXJnMikge1xuICAgICAgcmV0dXJuIGlzRlNBKGFyZzIpO1xuICAgIH1cbiAgICBjb25zdCBydW5NdXRhdG9yID0gKGRyYWZ0KSA9PiB7XG4gICAgICBpZiAoaXNQYXlsb2FkQWN0aW9uQXJndW1lbnQoYXJnKSkge1xuICAgICAgICBtdXRhdG9yKGFyZy5wYXlsb2FkLCBkcmFmdCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBtdXRhdG9yKGFyZywgZHJhZnQpO1xuICAgICAgfVxuICAgIH07XG4gICAgaWYgKGlzRHJhZnRUeXBlZChzdGF0ZSkpIHtcbiAgICAgIHJ1bk11dGF0b3Ioc3RhdGUpO1xuICAgICAgcmV0dXJuIHN0YXRlO1xuICAgIH1cbiAgICByZXR1cm4gcHJvZHVjZShzdGF0ZSwgcnVuTXV0YXRvcik7XG4gIH07XG59XG5cbi8vIHNyYy9lbnRpdGllcy91dGlscy50c1xuZnVuY3Rpb24gc2VsZWN0SWRWYWx1ZShlbnRpdHksIHNlbGVjdElkKSB7XG4gIGNvbnN0IGtleSA9IHNlbGVjdElkKGVudGl0eSk7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYga2V5ID09PSB2b2lkIDApIHtcbiAgICBjb25zb2xlLndhcm4oXCJUaGUgZW50aXR5IHBhc3NlZCB0byB0aGUgYHNlbGVjdElkYCBpbXBsZW1lbnRhdGlvbiByZXR1cm5lZCB1bmRlZmluZWQuXCIsIFwiWW91IHNob3VsZCBwcm9iYWJseSBwcm92aWRlIHlvdXIgb3duIGBzZWxlY3RJZGAgaW1wbGVtZW50YXRpb24uXCIsIFwiVGhlIGVudGl0eSB0aGF0IHdhcyBwYXNzZWQ6XCIsIGVudGl0eSwgXCJUaGUgYHNlbGVjdElkYCBpbXBsZW1lbnRhdGlvbjpcIiwgc2VsZWN0SWQudG9TdHJpbmcoKSk7XG4gIH1cbiAgcmV0dXJuIGtleTtcbn1cbmZ1bmN0aW9uIGVuc3VyZUVudGl0aWVzQXJyYXkoZW50aXRpZXMpIHtcbiAgaWYgKCFBcnJheS5pc0FycmF5KGVudGl0aWVzKSkge1xuICAgIGVudGl0aWVzID0gT2JqZWN0LnZhbHVlcyhlbnRpdGllcyk7XG4gIH1cbiAgcmV0dXJuIGVudGl0aWVzO1xufVxuZnVuY3Rpb24gZ2V0Q3VycmVudCh2YWx1ZSkge1xuICByZXR1cm4gaXNEcmFmdCh2YWx1ZSkgPyBjdXJyZW50KHZhbHVlKSA6IHZhbHVlO1xufVxuZnVuY3Rpb24gc3BsaXRBZGRlZFVwZGF0ZWRFbnRpdGllcyhuZXdFbnRpdGllcywgc2VsZWN0SWQsIHN0YXRlKSB7XG4gIG5ld0VudGl0aWVzID0gZW5zdXJlRW50aXRpZXNBcnJheShuZXdFbnRpdGllcyk7XG4gIGNvbnN0IGV4aXN0aW5nSWRzQXJyYXkgPSBnZXRDdXJyZW50KHN0YXRlLmlkcyk7XG4gIGNvbnN0IGV4aXN0aW5nSWRzID0gbmV3IFNldChleGlzdGluZ0lkc0FycmF5KTtcbiAgY29uc3QgYWRkZWQgPSBbXTtcbiAgY29uc3QgYWRkZWRJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbXSk7XG4gIGNvbnN0IHVwZGF0ZWQgPSBbXTtcbiAgZm9yIChjb25zdCBlbnRpdHkgb2YgbmV3RW50aXRpZXMpIHtcbiAgICBjb25zdCBpZCA9IHNlbGVjdElkVmFsdWUoZW50aXR5LCBzZWxlY3RJZCk7XG4gICAgaWYgKGV4aXN0aW5nSWRzLmhhcyhpZCkgfHwgYWRkZWRJZHMuaGFzKGlkKSkge1xuICAgICAgdXBkYXRlZC5wdXNoKHtcbiAgICAgICAgaWQsXG4gICAgICAgIGNoYW5nZXM6IGVudGl0eVxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFkZGVkSWRzLmFkZChpZCk7XG4gICAgICBhZGRlZC5wdXNoKGVudGl0eSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBbYWRkZWQsIHVwZGF0ZWQsIGV4aXN0aW5nSWRzQXJyYXldO1xufVxuXG4vLyBzcmMvZW50aXRpZXMvdW5zb3J0ZWRfc3RhdGVfYWRhcHRlci50c1xuZnVuY3Rpb24gY3JlYXRlVW5zb3J0ZWRTdGF0ZUFkYXB0ZXIoc2VsZWN0SWQpIHtcbiAgZnVuY3Rpb24gYWRkT25lTXV0YWJseShlbnRpdHksIHN0YXRlKSB7XG4gICAgY29uc3Qga2V5ID0gc2VsZWN0SWRWYWx1ZShlbnRpdHksIHNlbGVjdElkKTtcbiAgICBpZiAoa2V5IGluIHN0YXRlLmVudGl0aWVzKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHN0YXRlLmlkcy5wdXNoKGtleSk7XG4gICAgc3RhdGUuZW50aXRpZXNba2V5XSA9IGVudGl0eTtcbiAgfVxuICBmdW5jdGlvbiBhZGRNYW55TXV0YWJseShuZXdFbnRpdGllcywgc3RhdGUpIHtcbiAgICBuZXdFbnRpdGllcyA9IGVuc3VyZUVudGl0aWVzQXJyYXkobmV3RW50aXRpZXMpO1xuICAgIGZvciAoY29uc3QgZW50aXR5IG9mIG5ld0VudGl0aWVzKSB7XG4gICAgICBhZGRPbmVNdXRhYmx5KGVudGl0eSwgc3RhdGUpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBzZXRPbmVNdXRhYmx5KGVudGl0eSwgc3RhdGUpIHtcbiAgICBjb25zdCBrZXkgPSBzZWxlY3RJZFZhbHVlKGVudGl0eSwgc2VsZWN0SWQpO1xuICAgIGlmICghKGtleSBpbiBzdGF0ZS5lbnRpdGllcykpIHtcbiAgICAgIHN0YXRlLmlkcy5wdXNoKGtleSk7XG4gICAgfVxuICAgIDtcbiAgICBzdGF0ZS5lbnRpdGllc1trZXldID0gZW50aXR5O1xuICB9XG4gIGZ1bmN0aW9uIHNldE1hbnlNdXRhYmx5KG5ld0VudGl0aWVzLCBzdGF0ZSkge1xuICAgIG5ld0VudGl0aWVzID0gZW5zdXJlRW50aXRpZXNBcnJheShuZXdFbnRpdGllcyk7XG4gICAgZm9yIChjb25zdCBlbnRpdHkgb2YgbmV3RW50aXRpZXMpIHtcbiAgICAgIHNldE9uZU11dGFibHkoZW50aXR5LCBzdGF0ZSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHNldEFsbE11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlKSB7XG4gICAgbmV3RW50aXRpZXMgPSBlbnN1cmVFbnRpdGllc0FycmF5KG5ld0VudGl0aWVzKTtcbiAgICBzdGF0ZS5pZHMgPSBbXTtcbiAgICBzdGF0ZS5lbnRpdGllcyA9IHt9O1xuICAgIGFkZE1hbnlNdXRhYmx5KG5ld0VudGl0aWVzLCBzdGF0ZSk7XG4gIH1cbiAgZnVuY3Rpb24gcmVtb3ZlT25lTXV0YWJseShrZXksIHN0YXRlKSB7XG4gICAgcmV0dXJuIHJlbW92ZU1hbnlNdXRhYmx5KFtrZXldLCBzdGF0ZSk7XG4gIH1cbiAgZnVuY3Rpb24gcmVtb3ZlTWFueU11dGFibHkoa2V5cywgc3RhdGUpIHtcbiAgICBsZXQgZGlkTXV0YXRlID0gZmFsc2U7XG4gICAga2V5cy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGlmIChrZXkgaW4gc3RhdGUuZW50aXRpZXMpIHtcbiAgICAgICAgZGVsZXRlIHN0YXRlLmVudGl0aWVzW2tleV07XG4gICAgICAgIGRpZE11dGF0ZSA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gICAgaWYgKGRpZE11dGF0ZSkge1xuICAgICAgc3RhdGUuaWRzID0gc3RhdGUuaWRzLmZpbHRlcigoaWQpID0+IGlkIGluIHN0YXRlLmVudGl0aWVzKTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gcmVtb3ZlQWxsTXV0YWJseShzdGF0ZSkge1xuICAgIE9iamVjdC5hc3NpZ24oc3RhdGUsIHtcbiAgICAgIGlkczogW10sXG4gICAgICBlbnRpdGllczoge31cbiAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiB0YWtlTmV3S2V5KGtleXMsIHVwZGF0ZSwgc3RhdGUpIHtcbiAgICBjb25zdCBvcmlnaW5hbDMgPSBzdGF0ZS5lbnRpdGllc1t1cGRhdGUuaWRdO1xuICAgIGlmIChvcmlnaW5hbDMgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCB1cGRhdGVkID0gT2JqZWN0LmFzc2lnbih7fSwgb3JpZ2luYWwzLCB1cGRhdGUuY2hhbmdlcyk7XG4gICAgY29uc3QgbmV3S2V5ID0gc2VsZWN0SWRWYWx1ZSh1cGRhdGVkLCBzZWxlY3RJZCk7XG4gICAgY29uc3QgaGFzTmV3S2V5ID0gbmV3S2V5ICE9PSB1cGRhdGUuaWQ7XG4gICAgaWYgKGhhc05ld0tleSkge1xuICAgICAga2V5c1t1cGRhdGUuaWRdID0gbmV3S2V5O1xuICAgICAgZGVsZXRlIHN0YXRlLmVudGl0aWVzW3VwZGF0ZS5pZF07XG4gICAgfVxuICAgIDtcbiAgICBzdGF0ZS5lbnRpdGllc1tuZXdLZXldID0gdXBkYXRlZDtcbiAgICByZXR1cm4gaGFzTmV3S2V5O1xuICB9XG4gIGZ1bmN0aW9uIHVwZGF0ZU9uZU11dGFibHkodXBkYXRlLCBzdGF0ZSkge1xuICAgIHJldHVybiB1cGRhdGVNYW55TXV0YWJseShbdXBkYXRlXSwgc3RhdGUpO1xuICB9XG4gIGZ1bmN0aW9uIHVwZGF0ZU1hbnlNdXRhYmx5KHVwZGF0ZXMsIHN0YXRlKSB7XG4gICAgY29uc3QgbmV3S2V5cyA9IHt9O1xuICAgIGNvbnN0IHVwZGF0ZXNQZXJFbnRpdHkgPSB7fTtcbiAgICB1cGRhdGVzLmZvckVhY2goKHVwZGF0ZSkgPT4ge1xuICAgICAgaWYgKHVwZGF0ZS5pZCBpbiBzdGF0ZS5lbnRpdGllcykge1xuICAgICAgICB1cGRhdGVzUGVyRW50aXR5W3VwZGF0ZS5pZF0gPSB7XG4gICAgICAgICAgaWQ6IHVwZGF0ZS5pZCxcbiAgICAgICAgICAvLyBTcHJlYWRzIGlnbm9yZSBmYWxzeSB2YWx1ZXMsIHNvIHRoaXMgd29ya3MgZXZlbiBpZiB0aGVyZSBpc24ndFxuICAgICAgICAgIC8vIGFuIGV4aXN0aW5nIHVwZGF0ZSBhbHJlYWR5IGF0IHRoaXMga2V5XG4gICAgICAgICAgY2hhbmdlczoge1xuICAgICAgICAgICAgLi4udXBkYXRlc1BlckVudGl0eVt1cGRhdGUuaWRdPy5jaGFuZ2VzLFxuICAgICAgICAgICAgLi4udXBkYXRlLmNoYW5nZXNcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSk7XG4gICAgdXBkYXRlcyA9IE9iamVjdC52YWx1ZXModXBkYXRlc1BlckVudGl0eSk7XG4gICAgY29uc3QgZGlkTXV0YXRlRW50aXRpZXMgPSB1cGRhdGVzLmxlbmd0aCA+IDA7XG4gICAgaWYgKGRpZE11dGF0ZUVudGl0aWVzKSB7XG4gICAgICBjb25zdCBkaWRNdXRhdGVJZHMgPSB1cGRhdGVzLmZpbHRlcigodXBkYXRlKSA9PiB0YWtlTmV3S2V5KG5ld0tleXMsIHVwZGF0ZSwgc3RhdGUpKS5sZW5ndGggPiAwO1xuICAgICAgaWYgKGRpZE11dGF0ZUlkcykge1xuICAgICAgICBzdGF0ZS5pZHMgPSBPYmplY3QudmFsdWVzKHN0YXRlLmVudGl0aWVzKS5tYXAoKGUpID0+IHNlbGVjdElkVmFsdWUoZSwgc2VsZWN0SWQpKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gdXBzZXJ0T25lTXV0YWJseShlbnRpdHksIHN0YXRlKSB7XG4gICAgcmV0dXJuIHVwc2VydE1hbnlNdXRhYmx5KFtlbnRpdHldLCBzdGF0ZSk7XG4gIH1cbiAgZnVuY3Rpb24gdXBzZXJ0TWFueU11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlKSB7XG4gICAgY29uc3QgW2FkZGVkLCB1cGRhdGVkXSA9IHNwbGl0QWRkZWRVcGRhdGVkRW50aXRpZXMobmV3RW50aXRpZXMsIHNlbGVjdElkLCBzdGF0ZSk7XG4gICAgYWRkTWFueU11dGFibHkoYWRkZWQsIHN0YXRlKTtcbiAgICB1cGRhdGVNYW55TXV0YWJseSh1cGRhdGVkLCBzdGF0ZSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICByZW1vdmVBbGw6IGNyZWF0ZVNpbmdsZUFyZ3VtZW50U3RhdGVPcGVyYXRvcihyZW1vdmVBbGxNdXRhYmx5KSxcbiAgICBhZGRPbmU6IGNyZWF0ZVN0YXRlT3BlcmF0b3IoYWRkT25lTXV0YWJseSksXG4gICAgYWRkTWFueTogY3JlYXRlU3RhdGVPcGVyYXRvcihhZGRNYW55TXV0YWJseSksXG4gICAgc2V0T25lOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHNldE9uZU11dGFibHkpLFxuICAgIHNldE1hbnk6IGNyZWF0ZVN0YXRlT3BlcmF0b3Ioc2V0TWFueU11dGFibHkpLFxuICAgIHNldEFsbDogY3JlYXRlU3RhdGVPcGVyYXRvcihzZXRBbGxNdXRhYmx5KSxcbiAgICB1cGRhdGVPbmU6IGNyZWF0ZVN0YXRlT3BlcmF0b3IodXBkYXRlT25lTXV0YWJseSksXG4gICAgdXBkYXRlTWFueTogY3JlYXRlU3RhdGVPcGVyYXRvcih1cGRhdGVNYW55TXV0YWJseSksXG4gICAgdXBzZXJ0T25lOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHVwc2VydE9uZU11dGFibHkpLFxuICAgIHVwc2VydE1hbnk6IGNyZWF0ZVN0YXRlT3BlcmF0b3IodXBzZXJ0TWFueU11dGFibHkpLFxuICAgIHJlbW92ZU9uZTogY3JlYXRlU3RhdGVPcGVyYXRvcihyZW1vdmVPbmVNdXRhYmx5KSxcbiAgICByZW1vdmVNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHJlbW92ZU1hbnlNdXRhYmx5KVxuICB9O1xufVxuXG4vLyBzcmMvZW50aXRpZXMvc29ydGVkX3N0YXRlX2FkYXB0ZXIudHNcbmZ1bmN0aW9uIGZpbmRJbnNlcnRJbmRleChzb3J0ZWRJdGVtcywgaXRlbSwgY29tcGFyaXNvbkZ1bmN0aW9uKSB7XG4gIGxldCBsb3dJbmRleCA9IDA7XG4gIGxldCBoaWdoSW5kZXggPSBzb3J0ZWRJdGVtcy5sZW5ndGg7XG4gIHdoaWxlIChsb3dJbmRleCA8IGhpZ2hJbmRleCkge1xuICAgIGxldCBtaWRkbGVJbmRleCA9IGxvd0luZGV4ICsgaGlnaEluZGV4ID4+PiAxO1xuICAgIGNvbnN0IGN1cnJlbnRJdGVtID0gc29ydGVkSXRlbXNbbWlkZGxlSW5kZXhdO1xuICAgIGNvbnN0IHJlcyA9IGNvbXBhcmlzb25GdW5jdGlvbihpdGVtLCBjdXJyZW50SXRlbSk7XG4gICAgaWYgKHJlcyA+PSAwKSB7XG4gICAgICBsb3dJbmRleCA9IG1pZGRsZUluZGV4ICsgMTtcbiAgICB9IGVsc2Uge1xuICAgICAgaGlnaEluZGV4ID0gbWlkZGxlSW5kZXg7XG4gICAgfVxuICB9XG4gIHJldHVybiBsb3dJbmRleDtcbn1cbmZ1bmN0aW9uIGluc2VydChzb3J0ZWRJdGVtcywgaXRlbSwgY29tcGFyaXNvbkZ1bmN0aW9uKSB7XG4gIGNvbnN0IGluc2VydEF0SW5kZXggPSBmaW5kSW5zZXJ0SW5kZXgoc29ydGVkSXRlbXMsIGl0ZW0sIGNvbXBhcmlzb25GdW5jdGlvbik7XG4gIHNvcnRlZEl0ZW1zLnNwbGljZShpbnNlcnRBdEluZGV4LCAwLCBpdGVtKTtcbiAgcmV0dXJuIHNvcnRlZEl0ZW1zO1xufVxuZnVuY3Rpb24gY3JlYXRlU29ydGVkU3RhdGVBZGFwdGVyKHNlbGVjdElkLCBjb21wYXJlcikge1xuICBjb25zdCB7XG4gICAgcmVtb3ZlT25lLFxuICAgIHJlbW92ZU1hbnksXG4gICAgcmVtb3ZlQWxsXG4gIH0gPSBjcmVhdGVVbnNvcnRlZFN0YXRlQWRhcHRlcihzZWxlY3RJZCk7XG4gIGZ1bmN0aW9uIGFkZE9uZU11dGFibHkoZW50aXR5LCBzdGF0ZSkge1xuICAgIHJldHVybiBhZGRNYW55TXV0YWJseShbZW50aXR5XSwgc3RhdGUpO1xuICB9XG4gIGZ1bmN0aW9uIGFkZE1hbnlNdXRhYmx5KG5ld0VudGl0aWVzLCBzdGF0ZSwgZXhpc3RpbmdJZHMpIHtcbiAgICBuZXdFbnRpdGllcyA9IGVuc3VyZUVudGl0aWVzQXJyYXkobmV3RW50aXRpZXMpO1xuICAgIGNvbnN0IGV4aXN0aW5nS2V5cyA9IG5ldyBTZXQoZXhpc3RpbmdJZHMgPz8gZ2V0Q3VycmVudChzdGF0ZS5pZHMpKTtcbiAgICBjb25zdCBhZGRlZEtleXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgIGNvbnN0IG1vZGVscyA9IG5ld0VudGl0aWVzLmZpbHRlcigobW9kZWwpID0+IHtcbiAgICAgIGNvbnN0IG1vZGVsSWQgPSBzZWxlY3RJZFZhbHVlKG1vZGVsLCBzZWxlY3RJZCk7XG4gICAgICBjb25zdCBub3RBZGRlZCA9ICFhZGRlZEtleXMuaGFzKG1vZGVsSWQpO1xuICAgICAgaWYgKG5vdEFkZGVkKSBhZGRlZEtleXMuYWRkKG1vZGVsSWQpO1xuICAgICAgcmV0dXJuICFleGlzdGluZ0tleXMuaGFzKG1vZGVsSWQpICYmIG5vdEFkZGVkO1xuICAgIH0pO1xuICAgIGlmIChtb2RlbHMubGVuZ3RoICE9PSAwKSB7XG4gICAgICBtZXJnZUZ1bmN0aW9uKHN0YXRlLCBtb2RlbHMpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBzZXRPbmVNdXRhYmx5KGVudGl0eSwgc3RhdGUpIHtcbiAgICByZXR1cm4gc2V0TWFueU11dGFibHkoW2VudGl0eV0sIHN0YXRlKTtcbiAgfVxuICBmdW5jdGlvbiBzZXRNYW55TXV0YWJseShuZXdFbnRpdGllcywgc3RhdGUpIHtcbiAgICBsZXQgZGVkdXBsaWNhdGVkRW50aXRpZXMgPSB7fTtcbiAgICBuZXdFbnRpdGllcyA9IGVuc3VyZUVudGl0aWVzQXJyYXkobmV3RW50aXRpZXMpO1xuICAgIGlmIChuZXdFbnRpdGllcy5sZW5ndGggIT09IDApIHtcbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBuZXdFbnRpdGllcykge1xuICAgICAgICBjb25zdCBlbnRpdHlJZCA9IHNlbGVjdElkKGl0ZW0pO1xuICAgICAgICBkZWR1cGxpY2F0ZWRFbnRpdGllc1tlbnRpdHlJZF0gPSBpdGVtO1xuICAgICAgICBkZWxldGUgc3RhdGUuZW50aXRpZXNbZW50aXR5SWRdO1xuICAgICAgfVxuICAgICAgbmV3RW50aXRpZXMgPSBlbnN1cmVFbnRpdGllc0FycmF5KGRlZHVwbGljYXRlZEVudGl0aWVzKTtcbiAgICAgIG1lcmdlRnVuY3Rpb24oc3RhdGUsIG5ld0VudGl0aWVzKTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gc2V0QWxsTXV0YWJseShuZXdFbnRpdGllcywgc3RhdGUpIHtcbiAgICBuZXdFbnRpdGllcyA9IGVuc3VyZUVudGl0aWVzQXJyYXkobmV3RW50aXRpZXMpO1xuICAgIHN0YXRlLmVudGl0aWVzID0ge307XG4gICAgc3RhdGUuaWRzID0gW107XG4gICAgYWRkTWFueU11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlLCBbXSk7XG4gIH1cbiAgZnVuY3Rpb24gdXBkYXRlT25lTXV0YWJseSh1cGRhdGUsIHN0YXRlKSB7XG4gICAgcmV0dXJuIHVwZGF0ZU1hbnlNdXRhYmx5KFt1cGRhdGVdLCBzdGF0ZSk7XG4gIH1cbiAgZnVuY3Rpb24gdXBkYXRlTWFueU11dGFibHkodXBkYXRlcywgc3RhdGUpIHtcbiAgICBsZXQgYXBwbGllZFVwZGF0ZXMgPSBmYWxzZTtcbiAgICBsZXQgcmVwbGFjZWRJZHMgPSBmYWxzZTtcbiAgICBmb3IgKGxldCB1cGRhdGUgb2YgdXBkYXRlcykge1xuICAgICAgY29uc3QgZW50aXR5ID0gc3RhdGUuZW50aXRpZXNbdXBkYXRlLmlkXTtcbiAgICAgIGlmICghZW50aXR5KSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgYXBwbGllZFVwZGF0ZXMgPSB0cnVlO1xuICAgICAgT2JqZWN0LmFzc2lnbihlbnRpdHksIHVwZGF0ZS5jaGFuZ2VzKTtcbiAgICAgIGNvbnN0IG5ld0lkID0gc2VsZWN0SWQoZW50aXR5KTtcbiAgICAgIGlmICh1cGRhdGUuaWQgIT09IG5ld0lkKSB7XG4gICAgICAgIHJlcGxhY2VkSWRzID0gdHJ1ZTtcbiAgICAgICAgZGVsZXRlIHN0YXRlLmVudGl0aWVzW3VwZGF0ZS5pZF07XG4gICAgICAgIGNvbnN0IG9sZEluZGV4ID0gc3RhdGUuaWRzLmluZGV4T2YodXBkYXRlLmlkKTtcbiAgICAgICAgc3RhdGUuaWRzW29sZEluZGV4XSA9IG5ld0lkO1xuICAgICAgICBzdGF0ZS5lbnRpdGllc1tuZXdJZF0gPSBlbnRpdHk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChhcHBsaWVkVXBkYXRlcykge1xuICAgICAgbWVyZ2VGdW5jdGlvbihzdGF0ZSwgW10sIGFwcGxpZWRVcGRhdGVzLCByZXBsYWNlZElkcyk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHVwc2VydE9uZU11dGFibHkoZW50aXR5LCBzdGF0ZSkge1xuICAgIHJldHVybiB1cHNlcnRNYW55TXV0YWJseShbZW50aXR5XSwgc3RhdGUpO1xuICB9XG4gIGZ1bmN0aW9uIHVwc2VydE1hbnlNdXRhYmx5KG5ld0VudGl0aWVzLCBzdGF0ZSkge1xuICAgIGNvbnN0IFthZGRlZCwgdXBkYXRlZCwgZXhpc3RpbmdJZHNBcnJheV0gPSBzcGxpdEFkZGVkVXBkYXRlZEVudGl0aWVzKG5ld0VudGl0aWVzLCBzZWxlY3RJZCwgc3RhdGUpO1xuICAgIGlmIChhZGRlZC5sZW5ndGgpIHtcbiAgICAgIGFkZE1hbnlNdXRhYmx5KGFkZGVkLCBzdGF0ZSwgZXhpc3RpbmdJZHNBcnJheSk7XG4gICAgfVxuICAgIGlmICh1cGRhdGVkLmxlbmd0aCkge1xuICAgICAgdXBkYXRlTWFueU11dGFibHkodXBkYXRlZCwgc3RhdGUpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBhcmVBcnJheXNFcXVhbChhLCBiKSB7XG4gICAgaWYgKGEubGVuZ3RoICE9PSBiLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGEubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChhW2ldID09PSBiW2ldKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBjb25zdCBtZXJnZUZ1bmN0aW9uID0gKHN0YXRlLCBhZGRlZEl0ZW1zLCBhcHBsaWVkVXBkYXRlcywgcmVwbGFjZWRJZHMpID0+IHtcbiAgICBjb25zdCBjdXJyZW50RW50aXRpZXMgPSBnZXRDdXJyZW50KHN0YXRlLmVudGl0aWVzKTtcbiAgICBjb25zdCBjdXJyZW50SWRzID0gZ2V0Q3VycmVudChzdGF0ZS5pZHMpO1xuICAgIGNvbnN0IHN0YXRlRW50aXRpZXMgPSBzdGF0ZS5lbnRpdGllcztcbiAgICBsZXQgaWRzID0gY3VycmVudElkcztcbiAgICBpZiAocmVwbGFjZWRJZHMpIHtcbiAgICAgIGlkcyA9IG5ldyBTZXQoY3VycmVudElkcyk7XG4gICAgfVxuICAgIGxldCBzb3J0ZWRFbnRpdGllcyA9IFtdO1xuICAgIGZvciAoY29uc3QgaWQgb2YgaWRzKSB7XG4gICAgICBjb25zdCBlbnRpdHkgPSBjdXJyZW50RW50aXRpZXNbaWRdO1xuICAgICAgaWYgKGVudGl0eSkge1xuICAgICAgICBzb3J0ZWRFbnRpdGllcy5wdXNoKGVudGl0eSk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHdhc1ByZXZpb3VzbHlFbXB0eSA9IHNvcnRlZEVudGl0aWVzLmxlbmd0aCA9PT0gMDtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgYWRkZWRJdGVtcykge1xuICAgICAgc3RhdGVFbnRpdGllc1tzZWxlY3RJZChpdGVtKV0gPSBpdGVtO1xuICAgICAgaWYgKCF3YXNQcmV2aW91c2x5RW1wdHkpIHtcbiAgICAgICAgaW5zZXJ0KHNvcnRlZEVudGl0aWVzLCBpdGVtLCBjb21wYXJlcik7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh3YXNQcmV2aW91c2x5RW1wdHkpIHtcbiAgICAgIHNvcnRlZEVudGl0aWVzID0gYWRkZWRJdGVtcy5zbGljZSgpLnNvcnQoY29tcGFyZXIpO1xuICAgIH0gZWxzZSBpZiAoYXBwbGllZFVwZGF0ZXMpIHtcbiAgICAgIHNvcnRlZEVudGl0aWVzLnNvcnQoY29tcGFyZXIpO1xuICAgIH1cbiAgICBjb25zdCBuZXdTb3J0ZWRJZHMgPSBzb3J0ZWRFbnRpdGllcy5tYXAoc2VsZWN0SWQpO1xuICAgIGlmICghYXJlQXJyYXlzRXF1YWwoY3VycmVudElkcywgbmV3U29ydGVkSWRzKSkge1xuICAgICAgc3RhdGUuaWRzID0gbmV3U29ydGVkSWRzO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIHtcbiAgICByZW1vdmVPbmUsXG4gICAgcmVtb3ZlTWFueSxcbiAgICByZW1vdmVBbGwsXG4gICAgYWRkT25lOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKGFkZE9uZU11dGFibHkpLFxuICAgIHVwZGF0ZU9uZTogY3JlYXRlU3RhdGVPcGVyYXRvcih1cGRhdGVPbmVNdXRhYmx5KSxcbiAgICB1cHNlcnRPbmU6IGNyZWF0ZVN0YXRlT3BlcmF0b3IodXBzZXJ0T25lTXV0YWJseSksXG4gICAgc2V0T25lOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHNldE9uZU11dGFibHkpLFxuICAgIHNldE1hbnk6IGNyZWF0ZVN0YXRlT3BlcmF0b3Ioc2V0TWFueU11dGFibHkpLFxuICAgIHNldEFsbDogY3JlYXRlU3RhdGVPcGVyYXRvcihzZXRBbGxNdXRhYmx5KSxcbiAgICBhZGRNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKGFkZE1hbnlNdXRhYmx5KSxcbiAgICB1cGRhdGVNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHVwZGF0ZU1hbnlNdXRhYmx5KSxcbiAgICB1cHNlcnRNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHVwc2VydE1hbnlNdXRhYmx5KVxuICB9O1xufVxuXG4vLyBzcmMvZW50aXRpZXMvY3JlYXRlX2FkYXB0ZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZUVudGl0eUFkYXB0ZXIob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBzZWxlY3RJZCxcbiAgICBzb3J0Q29tcGFyZXJcbiAgfSA9IHtcbiAgICBzb3J0Q29tcGFyZXI6IGZhbHNlLFxuICAgIHNlbGVjdElkOiAoaW5zdGFuY2UpID0+IGluc3RhbmNlLmlkLFxuICAgIC4uLm9wdGlvbnNcbiAgfTtcbiAgY29uc3Qgc3RhdGVBZGFwdGVyID0gc29ydENvbXBhcmVyID8gY3JlYXRlU29ydGVkU3RhdGVBZGFwdGVyKHNlbGVjdElkLCBzb3J0Q29tcGFyZXIpIDogY3JlYXRlVW5zb3J0ZWRTdGF0ZUFkYXB0ZXIoc2VsZWN0SWQpO1xuICBjb25zdCBzdGF0ZUZhY3RvcnkgPSBjcmVhdGVJbml0aWFsU3RhdGVGYWN0b3J5KHN0YXRlQWRhcHRlcik7XG4gIGNvbnN0IHNlbGVjdG9yc0ZhY3RvcnkgPSBjcmVhdGVTZWxlY3RvcnNGYWN0b3J5KCk7XG4gIHJldHVybiB7XG4gICAgc2VsZWN0SWQsXG4gICAgc29ydENvbXBhcmVyLFxuICAgIC4uLnN0YXRlRmFjdG9yeSxcbiAgICAuLi5zZWxlY3RvcnNGYWN0b3J5LFxuICAgIC4uLnN0YXRlQWRhcHRlclxuICB9O1xufVxuXG4vLyBzcmMvbGlzdGVuZXJNaWRkbGV3YXJlL2V4Y2VwdGlvbnMudHNcbnZhciB0YXNrID0gXCJ0YXNrXCI7XG52YXIgbGlzdGVuZXIgPSBcImxpc3RlbmVyXCI7XG52YXIgY29tcGxldGVkID0gXCJjb21wbGV0ZWRcIjtcbnZhciBjYW5jZWxsZWQgPSBcImNhbmNlbGxlZFwiO1xudmFyIHRhc2tDYW5jZWxsZWQgPSBgdGFzay0ke2NhbmNlbGxlZH1gO1xudmFyIHRhc2tDb21wbGV0ZWQgPSBgdGFzay0ke2NvbXBsZXRlZH1gO1xudmFyIGxpc3RlbmVyQ2FuY2VsbGVkID0gYCR7bGlzdGVuZXJ9LSR7Y2FuY2VsbGVkfWA7XG52YXIgbGlzdGVuZXJDb21wbGV0ZWQgPSBgJHtsaXN0ZW5lcn0tJHtjb21wbGV0ZWR9YDtcbnZhciBUYXNrQWJvcnRFcnJvciA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IoY29kZSkge1xuICAgIHRoaXMuY29kZSA9IGNvZGU7XG4gICAgdGhpcy5tZXNzYWdlID0gYCR7dGFza30gJHtjYW5jZWxsZWR9IChyZWFzb246ICR7Y29kZX0pYDtcbiAgfVxuICBjb2RlO1xuICBuYW1lID0gXCJUYXNrQWJvcnRFcnJvclwiO1xuICBtZXNzYWdlO1xufTtcblxuLy8gc3JjL2xpc3RlbmVyTWlkZGxld2FyZS91dGlscy50c1xudmFyIGFzc2VydEZ1bmN0aW9uID0gKGZ1bmMsIGV4cGVjdGVkKSA9PiB7XG4gIGlmICh0eXBlb2YgZnVuYyAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDMyKSA6IGAke2V4cGVjdGVkfSBpcyBub3QgYSBmdW5jdGlvbmApO1xuICB9XG59O1xudmFyIG5vb3AyID0gKCkgPT4ge1xufTtcbnZhciBjYXRjaFJlamVjdGlvbiA9IChwcm9taXNlLCBvbkVycm9yID0gbm9vcDIpID0+IHtcbiAgcHJvbWlzZS5jYXRjaChvbkVycm9yKTtcbiAgcmV0dXJuIHByb21pc2U7XG59O1xudmFyIGFkZEFib3J0U2lnbmFsTGlzdGVuZXIgPSAoYWJvcnRTaWduYWwsIGNhbGxiYWNrKSA9PiB7XG4gIGFib3J0U2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBjYWxsYmFjaywge1xuICAgIG9uY2U6IHRydWVcbiAgfSk7XG4gIHJldHVybiAoKSA9PiBhYm9ydFNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgY2FsbGJhY2spO1xufTtcblxuLy8gc3JjL2xpc3RlbmVyTWlkZGxld2FyZS90YXNrLnRzXG52YXIgdmFsaWRhdGVBY3RpdmUgPSAoc2lnbmFsKSA9PiB7XG4gIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgIHRocm93IG5ldyBUYXNrQWJvcnRFcnJvcihzaWduYWwucmVhc29uKTtcbiAgfVxufTtcbmZ1bmN0aW9uIHJhY2VXaXRoU2lnbmFsKHNpZ25hbCwgcHJvbWlzZSkge1xuICBsZXQgY2xlYW51cCA9IG5vb3AyO1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IG5vdGlmeVJlamVjdGlvbiA9ICgpID0+IHJlamVjdChuZXcgVGFza0Fib3J0RXJyb3Ioc2lnbmFsLnJlYXNvbikpO1xuICAgIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgICAgbm90aWZ5UmVqZWN0aW9uKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNsZWFudXAgPSBhZGRBYm9ydFNpZ25hbExpc3RlbmVyKHNpZ25hbCwgbm90aWZ5UmVqZWN0aW9uKTtcbiAgICBwcm9taXNlLmZpbmFsbHkoKCkgPT4gY2xlYW51cCgpKS50aGVuKHJlc29sdmUsIHJlamVjdCk7XG4gIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIGNsZWFudXAgPSBub29wMjtcbiAgfSk7XG59XG52YXIgcnVuVGFzayA9IGFzeW5jICh0YXNrMiwgY2xlYW5VcCkgPT4ge1xuICB0cnkge1xuICAgIGF3YWl0IFByb21pc2UucmVzb2x2ZSgpO1xuICAgIGNvbnN0IHZhbHVlID0gYXdhaXQgdGFzazIoKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzOiBcIm9rXCIsXG4gICAgICB2YWx1ZVxuICAgIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXR1czogZXJyb3IgaW5zdGFuY2VvZiBUYXNrQWJvcnRFcnJvciA/IFwiY2FuY2VsbGVkXCIgOiBcInJlamVjdGVkXCIsXG4gICAgICBlcnJvclxuICAgIH07XG4gIH0gZmluYWxseSB7XG4gICAgY2xlYW5VcD8uKCk7XG4gIH1cbn07XG52YXIgY3JlYXRlUGF1c2UgPSAoc2lnbmFsKSA9PiB7XG4gIHJldHVybiAocHJvbWlzZSkgPT4ge1xuICAgIHJldHVybiBjYXRjaFJlamVjdGlvbihyYWNlV2l0aFNpZ25hbChzaWduYWwsIHByb21pc2UpLnRoZW4oKG91dHB1dCkgPT4ge1xuICAgICAgdmFsaWRhdGVBY3RpdmUoc2lnbmFsKTtcbiAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfSkpO1xuICB9O1xufTtcbnZhciBjcmVhdGVEZWxheSA9IChzaWduYWwpID0+IHtcbiAgY29uc3QgcGF1c2UgPSBjcmVhdGVQYXVzZShzaWduYWwpO1xuICByZXR1cm4gKHRpbWVvdXRNcykgPT4ge1xuICAgIHJldHVybiBwYXVzZShuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCB0aW1lb3V0TXMpKSk7XG4gIH07XG59O1xuXG4vLyBzcmMvbGlzdGVuZXJNaWRkbGV3YXJlL2luZGV4LnRzXG52YXIge1xuICBhc3NpZ25cbn0gPSBPYmplY3Q7XG52YXIgSU5URVJOQUxfTklMX1RPS0VOID0ge307XG52YXIgYWxtID0gXCJsaXN0ZW5lck1pZGRsZXdhcmVcIjtcbnZhciBjcmVhdGVGb3JrID0gKHBhcmVudEFib3J0U2lnbmFsLCBwYXJlbnRCbG9ja2luZ1Byb21pc2VzKSA9PiB7XG4gIGNvbnN0IGxpbmtDb250cm9sbGVycyA9IChjb250cm9sbGVyKSA9PiBhZGRBYm9ydFNpZ25hbExpc3RlbmVyKHBhcmVudEFib3J0U2lnbmFsLCAoKSA9PiBjb250cm9sbGVyLmFib3J0KHBhcmVudEFib3J0U2lnbmFsLnJlYXNvbikpO1xuICByZXR1cm4gKHRhc2tFeGVjdXRvciwgb3B0cykgPT4ge1xuICAgIGFzc2VydEZ1bmN0aW9uKHRhc2tFeGVjdXRvciwgXCJ0YXNrRXhlY3V0b3JcIik7XG4gICAgY29uc3QgY2hpbGRBYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgbGlua0NvbnRyb2xsZXJzKGNoaWxkQWJvcnRDb250cm9sbGVyKTtcbiAgICBjb25zdCByZXN1bHQgPSBydW5UYXNrKGFzeW5jICgpID0+IHtcbiAgICAgIHZhbGlkYXRlQWN0aXZlKHBhcmVudEFib3J0U2lnbmFsKTtcbiAgICAgIHZhbGlkYXRlQWN0aXZlKGNoaWxkQWJvcnRDb250cm9sbGVyLnNpZ25hbCk7XG4gICAgICBjb25zdCByZXN1bHQyID0gYXdhaXQgdGFza0V4ZWN1dG9yKHtcbiAgICAgICAgcGF1c2U6IGNyZWF0ZVBhdXNlKGNoaWxkQWJvcnRDb250cm9sbGVyLnNpZ25hbCksXG4gICAgICAgIGRlbGF5OiBjcmVhdGVEZWxheShjaGlsZEFib3J0Q29udHJvbGxlci5zaWduYWwpLFxuICAgICAgICBzaWduYWw6IGNoaWxkQWJvcnRDb250cm9sbGVyLnNpZ25hbFxuICAgICAgfSk7XG4gICAgICB2YWxpZGF0ZUFjdGl2ZShjaGlsZEFib3J0Q29udHJvbGxlci5zaWduYWwpO1xuICAgICAgcmV0dXJuIHJlc3VsdDI7XG4gICAgfSwgKCkgPT4gY2hpbGRBYm9ydENvbnRyb2xsZXIuYWJvcnQodGFza0NvbXBsZXRlZCkpO1xuICAgIGlmIChvcHRzPy5hdXRvSm9pbikge1xuICAgICAgcGFyZW50QmxvY2tpbmdQcm9taXNlcy5wdXNoKHJlc3VsdC5jYXRjaChub29wMikpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgcmVzdWx0OiBjcmVhdGVQYXVzZShwYXJlbnRBYm9ydFNpZ25hbCkocmVzdWx0KSxcbiAgICAgIGNhbmNlbCgpIHtcbiAgICAgICAgY2hpbGRBYm9ydENvbnRyb2xsZXIuYWJvcnQodGFza0NhbmNlbGxlZCk7XG4gICAgICB9XG4gICAgfTtcbiAgfTtcbn07XG52YXIgY3JlYXRlVGFrZVBhdHRlcm4gPSAoc3RhcnRMaXN0ZW5pbmcsIHNpZ25hbCkgPT4ge1xuICBjb25zdCB0YWtlID0gYXN5bmMgKHByZWRpY2F0ZSwgdGltZW91dCkgPT4ge1xuICAgIHZhbGlkYXRlQWN0aXZlKHNpZ25hbCk7XG4gICAgbGV0IHVuc3Vic2NyaWJlID0gKCkgPT4ge1xuICAgIH07XG4gICAgY29uc3QgdHVwbGVQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgbGV0IHN0b3BMaXN0ZW5pbmcgPSBzdGFydExpc3RlbmluZyh7XG4gICAgICAgIHByZWRpY2F0ZSxcbiAgICAgICAgZWZmZWN0OiAoYWN0aW9uLCBsaXN0ZW5lckFwaSkgPT4ge1xuICAgICAgICAgIGxpc3RlbmVyQXBpLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgcmVzb2x2ZShbYWN0aW9uLCBsaXN0ZW5lckFwaS5nZXRTdGF0ZSgpLCBsaXN0ZW5lckFwaS5nZXRPcmlnaW5hbFN0YXRlKCldKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICB1bnN1YnNjcmliZSA9ICgpID0+IHtcbiAgICAgICAgc3RvcExpc3RlbmluZygpO1xuICAgICAgICByZWplY3QoKTtcbiAgICAgIH07XG4gICAgfSk7XG4gICAgY29uc3QgcHJvbWlzZXMgPSBbdHVwbGVQcm9taXNlXTtcbiAgICBpZiAodGltZW91dCAhPSBudWxsKSB7XG4gICAgICBwcm9taXNlcy5wdXNoKG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVvdXQsIG51bGwpKSk7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBvdXRwdXQgPSBhd2FpdCByYWNlV2l0aFNpZ25hbChzaWduYWwsIFByb21pc2UucmFjZShwcm9taXNlcykpO1xuICAgICAgdmFsaWRhdGVBY3RpdmUoc2lnbmFsKTtcbiAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgfVxuICB9O1xuICByZXR1cm4gKChwcmVkaWNhdGUsIHRpbWVvdXQpID0+IGNhdGNoUmVqZWN0aW9uKHRha2UocHJlZGljYXRlLCB0aW1lb3V0KSkpO1xufTtcbnZhciBnZXRMaXN0ZW5lckVudHJ5UHJvcHNGcm9tID0gKG9wdGlvbnMpID0+IHtcbiAgbGV0IHtcbiAgICB0eXBlLFxuICAgIGFjdGlvbkNyZWF0b3IsXG4gICAgbWF0Y2hlcixcbiAgICBwcmVkaWNhdGUsXG4gICAgZWZmZWN0XG4gIH0gPSBvcHRpb25zO1xuICBpZiAodHlwZSkge1xuICAgIHByZWRpY2F0ZSA9IGNyZWF0ZUFjdGlvbih0eXBlKS5tYXRjaDtcbiAgfSBlbHNlIGlmIChhY3Rpb25DcmVhdG9yKSB7XG4gICAgdHlwZSA9IGFjdGlvbkNyZWF0b3IudHlwZTtcbiAgICBwcmVkaWNhdGUgPSBhY3Rpb25DcmVhdG9yLm1hdGNoO1xuICB9IGVsc2UgaWYgKG1hdGNoZXIpIHtcbiAgICBwcmVkaWNhdGUgPSBtYXRjaGVyO1xuICB9IGVsc2UgaWYgKHByZWRpY2F0ZSkge1xuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDIxKSA6IFwiQ3JlYXRpbmcgb3IgcmVtb3ZpbmcgYSBsaXN0ZW5lciByZXF1aXJlcyBvbmUgb2YgdGhlIGtub3duIGZpZWxkcyBmb3IgbWF0Y2hpbmcgYW4gYWN0aW9uXCIpO1xuICB9XG4gIGFzc2VydEZ1bmN0aW9uKGVmZmVjdCwgXCJvcHRpb25zLmxpc3RlbmVyXCIpO1xuICByZXR1cm4ge1xuICAgIHByZWRpY2F0ZSxcbiAgICB0eXBlLFxuICAgIGVmZmVjdFxuICB9O1xufTtcbnZhciBjcmVhdGVMaXN0ZW5lckVudHJ5ID0gLyogQF9fUFVSRV9fICovIGFzc2lnbigob3B0aW9ucykgPT4ge1xuICBjb25zdCB7XG4gICAgdHlwZSxcbiAgICBwcmVkaWNhdGUsXG4gICAgZWZmZWN0XG4gIH0gPSBnZXRMaXN0ZW5lckVudHJ5UHJvcHNGcm9tKG9wdGlvbnMpO1xuICBjb25zdCBlbnRyeSA9IHtcbiAgICBpZDogbmFub2lkKCksXG4gICAgZWZmZWN0LFxuICAgIHR5cGUsXG4gICAgcHJlZGljYXRlLFxuICAgIHBlbmRpbmc6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG4gICAgdW5zdWJzY3JpYmU6ICgpID0+IHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDIyKSA6IFwiVW5zdWJzY3JpYmUgbm90IGluaXRpYWxpemVkXCIpO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIGVudHJ5O1xufSwge1xuICB3aXRoVHlwZXM6ICgpID0+IGNyZWF0ZUxpc3RlbmVyRW50cnlcbn0pO1xudmFyIGZpbmRMaXN0ZW5lckVudHJ5ID0gKGxpc3RlbmVyTWFwLCBvcHRpb25zKSA9PiB7XG4gIGNvbnN0IHtcbiAgICB0eXBlLFxuICAgIGVmZmVjdCxcbiAgICBwcmVkaWNhdGVcbiAgfSA9IGdldExpc3RlbmVyRW50cnlQcm9wc0Zyb20ob3B0aW9ucyk7XG4gIHJldHVybiBBcnJheS5mcm9tKGxpc3RlbmVyTWFwLnZhbHVlcygpKS5maW5kKChlbnRyeSkgPT4ge1xuICAgIGNvbnN0IG1hdGNoUHJlZGljYXRlT3JUeXBlID0gdHlwZW9mIHR5cGUgPT09IFwic3RyaW5nXCIgPyBlbnRyeS50eXBlID09PSB0eXBlIDogZW50cnkucHJlZGljYXRlID09PSBwcmVkaWNhdGU7XG4gICAgcmV0dXJuIG1hdGNoUHJlZGljYXRlT3JUeXBlICYmIGVudHJ5LmVmZmVjdCA9PT0gZWZmZWN0O1xuICB9KTtcbn07XG52YXIgY2FuY2VsQWN0aXZlTGlzdGVuZXJzID0gKGVudHJ5KSA9PiB7XG4gIGVudHJ5LnBlbmRpbmcuZm9yRWFjaCgoY29udHJvbGxlcikgPT4ge1xuICAgIGNvbnRyb2xsZXIuYWJvcnQobGlzdGVuZXJDYW5jZWxsZWQpO1xuICB9KTtcbn07XG52YXIgY3JlYXRlQ2xlYXJMaXN0ZW5lck1pZGRsZXdhcmUgPSAobGlzdGVuZXJNYXAsIGV4ZWN1dGluZ0xpc3RlbmVycykgPT4ge1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGZvciAoY29uc3QgbGlzdGVuZXIyIG9mIGV4ZWN1dGluZ0xpc3RlbmVycy5rZXlzKCkpIHtcbiAgICAgIGNhbmNlbEFjdGl2ZUxpc3RlbmVycyhsaXN0ZW5lcjIpO1xuICAgIH1cbiAgICBsaXN0ZW5lck1hcC5jbGVhcigpO1xuICB9O1xufTtcbnZhciBzYWZlbHlOb3RpZnlFcnJvciA9IChlcnJvckhhbmRsZXIsIGVycm9yVG9Ob3RpZnksIGVycm9ySW5mbykgPT4ge1xuICB0cnkge1xuICAgIGVycm9ySGFuZGxlcihlcnJvclRvTm90aWZ5LCBlcnJvckluZm8pO1xuICB9IGNhdGNoIChlcnJvckhhbmRsZXJFcnJvcikge1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhyb3cgZXJyb3JIYW5kbGVyRXJyb3I7XG4gICAgfSwgMCk7XG4gIH1cbn07XG52YXIgYWRkTGlzdGVuZXIgPSAvKiBAX19QVVJFX18gKi8gYXNzaWduKC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVBY3Rpb24oYCR7YWxtfS9hZGRgKSwge1xuICB3aXRoVHlwZXM6ICgpID0+IGFkZExpc3RlbmVyXG59KTtcbnZhciBjbGVhckFsbExpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVBY3Rpb24oYCR7YWxtfS9yZW1vdmVBbGxgKTtcbnZhciByZW1vdmVMaXN0ZW5lciA9IC8qIEBfX1BVUkVfXyAqLyBhc3NpZ24oLyogQF9fUFVSRV9fICovIGNyZWF0ZUFjdGlvbihgJHthbG19L3JlbW92ZWApLCB7XG4gIHdpdGhUeXBlczogKCkgPT4gcmVtb3ZlTGlzdGVuZXJcbn0pO1xudmFyIGRlZmF1bHRFcnJvckhhbmRsZXIgPSAoLi4uYXJncykgPT4ge1xuICBjb25zb2xlLmVycm9yKGAke2FsbX0vZXJyb3JgLCAuLi5hcmdzKTtcbn07XG52YXIgY3JlYXRlTGlzdGVuZXJNaWRkbGV3YXJlID0gKG1pZGRsZXdhcmVPcHRpb25zID0ge30pID0+IHtcbiAgY29uc3QgbGlzdGVuZXJNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBjb25zdCBleGVjdXRpbmdMaXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBjb25zdCB0cmFja0V4ZWN1dGluZ0xpc3RlbmVyID0gKGVudHJ5KSA9PiB7XG4gICAgY29uc3QgY291bnQgPSBleGVjdXRpbmdMaXN0ZW5lcnMuZ2V0KGVudHJ5KSA/PyAwO1xuICAgIGV4ZWN1dGluZ0xpc3RlbmVycy5zZXQoZW50cnksIGNvdW50ICsgMSk7XG4gIH07XG4gIGNvbnN0IHVudHJhY2tFeGVjdXRpbmdMaXN0ZW5lciA9IChlbnRyeSkgPT4ge1xuICAgIGNvbnN0IGNvdW50ID0gZXhlY3V0aW5nTGlzdGVuZXJzLmdldChlbnRyeSkgPz8gMTtcbiAgICBpZiAoY291bnQgPT09IDEpIHtcbiAgICAgIGV4ZWN1dGluZ0xpc3RlbmVycy5kZWxldGUoZW50cnkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBleGVjdXRpbmdMaXN0ZW5lcnMuc2V0KGVudHJ5LCBjb3VudCAtIDEpO1xuICAgIH1cbiAgfTtcbiAgY29uc3Qge1xuICAgIGV4dHJhLFxuICAgIG9uRXJyb3IgPSBkZWZhdWx0RXJyb3JIYW5kbGVyXG4gIH0gPSBtaWRkbGV3YXJlT3B0aW9ucztcbiAgYXNzZXJ0RnVuY3Rpb24ob25FcnJvciwgXCJvbkVycm9yXCIpO1xuICBjb25zdCBpbnNlcnRFbnRyeSA9IChlbnRyeSkgPT4ge1xuICAgIGVudHJ5LnVuc3Vic2NyaWJlID0gKCkgPT4gbGlzdGVuZXJNYXAuZGVsZXRlKGVudHJ5LmlkKTtcbiAgICBsaXN0ZW5lck1hcC5zZXQoZW50cnkuaWQsIGVudHJ5KTtcbiAgICByZXR1cm4gKGNhbmNlbE9wdGlvbnMpID0+IHtcbiAgICAgIGVudHJ5LnVuc3Vic2NyaWJlKCk7XG4gICAgICBpZiAoY2FuY2VsT3B0aW9ucz8uY2FuY2VsQWN0aXZlKSB7XG4gICAgICAgIGNhbmNlbEFjdGl2ZUxpc3RlbmVycyhlbnRyeSk7XG4gICAgICB9XG4gICAgfTtcbiAgfTtcbiAgY29uc3Qgc3RhcnRMaXN0ZW5pbmcgPSAoKG9wdGlvbnMpID0+IHtcbiAgICBjb25zdCBlbnRyeSA9IGZpbmRMaXN0ZW5lckVudHJ5KGxpc3RlbmVyTWFwLCBvcHRpb25zKSA/PyBjcmVhdGVMaXN0ZW5lckVudHJ5KG9wdGlvbnMpO1xuICAgIHJldHVybiBpbnNlcnRFbnRyeShlbnRyeSk7XG4gIH0pO1xuICBhc3NpZ24oc3RhcnRMaXN0ZW5pbmcsIHtcbiAgICB3aXRoVHlwZXM6ICgpID0+IHN0YXJ0TGlzdGVuaW5nXG4gIH0pO1xuICBjb25zdCBzdG9wTGlzdGVuaW5nID0gKG9wdGlvbnMpID0+IHtcbiAgICBjb25zdCBlbnRyeSA9IGZpbmRMaXN0ZW5lckVudHJ5KGxpc3RlbmVyTWFwLCBvcHRpb25zKTtcbiAgICBpZiAoZW50cnkpIHtcbiAgICAgIGVudHJ5LnVuc3Vic2NyaWJlKCk7XG4gICAgICBpZiAob3B0aW9ucy5jYW5jZWxBY3RpdmUpIHtcbiAgICAgICAgY2FuY2VsQWN0aXZlTGlzdGVuZXJzKGVudHJ5KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuICEhZW50cnk7XG4gIH07XG4gIGFzc2lnbihzdG9wTGlzdGVuaW5nLCB7XG4gICAgd2l0aFR5cGVzOiAoKSA9PiBzdG9wTGlzdGVuaW5nXG4gIH0pO1xuICBjb25zdCBub3RpZnlMaXN0ZW5lciA9IGFzeW5jIChlbnRyeSwgYWN0aW9uLCBhcGksIGdldE9yaWdpbmFsU3RhdGUpID0+IHtcbiAgICBjb25zdCBpbnRlcm5hbFRhc2tDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGNvbnN0IHRha2UgPSBjcmVhdGVUYWtlUGF0dGVybihzdGFydExpc3RlbmluZywgaW50ZXJuYWxUYXNrQ29udHJvbGxlci5zaWduYWwpO1xuICAgIGNvbnN0IGF1dG9Kb2luUHJvbWlzZXMgPSBbXTtcbiAgICB0cnkge1xuICAgICAgZW50cnkucGVuZGluZy5hZGQoaW50ZXJuYWxUYXNrQ29udHJvbGxlcik7XG4gICAgICB0cmFja0V4ZWN1dGluZ0xpc3RlbmVyKGVudHJ5KTtcbiAgICAgIGF3YWl0IFByb21pc2UucmVzb2x2ZShlbnRyeS5lZmZlY3QoXG4gICAgICAgIGFjdGlvbixcbiAgICAgICAgLy8gVXNlIGFzc2lnbigpIHJhdGhlciB0aGFuIC4uLiB0byBhdm9pZCBleHRyYSBoZWxwZXIgZnVuY3Rpb25zIGFkZGVkIHRvIGJ1bmRsZVxuICAgICAgICBhc3NpZ24oe30sIGFwaSwge1xuICAgICAgICAgIGdldE9yaWdpbmFsU3RhdGUsXG4gICAgICAgICAgY29uZGl0aW9uOiAocHJlZGljYXRlLCB0aW1lb3V0KSA9PiB0YWtlKHByZWRpY2F0ZSwgdGltZW91dCkudGhlbihCb29sZWFuKSxcbiAgICAgICAgICB0YWtlLFxuICAgICAgICAgIGRlbGF5OiBjcmVhdGVEZWxheShpbnRlcm5hbFRhc2tDb250cm9sbGVyLnNpZ25hbCksXG4gICAgICAgICAgcGF1c2U6IGNyZWF0ZVBhdXNlKGludGVybmFsVGFza0NvbnRyb2xsZXIuc2lnbmFsKSxcbiAgICAgICAgICBleHRyYSxcbiAgICAgICAgICBzaWduYWw6IGludGVybmFsVGFza0NvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAgIGZvcms6IGNyZWF0ZUZvcmsoaW50ZXJuYWxUYXNrQ29udHJvbGxlci5zaWduYWwsIGF1dG9Kb2luUHJvbWlzZXMpLFxuICAgICAgICAgIHVuc3Vic2NyaWJlOiBlbnRyeS51bnN1YnNjcmliZSxcbiAgICAgICAgICBzdWJzY3JpYmU6ICgpID0+IHtcbiAgICAgICAgICAgIGxpc3RlbmVyTWFwLnNldChlbnRyeS5pZCwgZW50cnkpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgY2FuY2VsQWN0aXZlTGlzdGVuZXJzOiAoKSA9PiB7XG4gICAgICAgICAgICBlbnRyeS5wZW5kaW5nLmZvckVhY2goKGNvbnRyb2xsZXIsIF8sIHNldCkgPT4ge1xuICAgICAgICAgICAgICBpZiAoY29udHJvbGxlciAhPT0gaW50ZXJuYWxUYXNrQ29udHJvbGxlcikge1xuICAgICAgICAgICAgICAgIGNvbnRyb2xsZXIuYWJvcnQobGlzdGVuZXJDYW5jZWxsZWQpO1xuICAgICAgICAgICAgICAgIHNldC5kZWxldGUoY29udHJvbGxlcik7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgY2FuY2VsOiAoKSA9PiB7XG4gICAgICAgICAgICBpbnRlcm5hbFRhc2tDb250cm9sbGVyLmFib3J0KGxpc3RlbmVyQ2FuY2VsbGVkKTtcbiAgICAgICAgICAgIGVudHJ5LnBlbmRpbmcuZGVsZXRlKGludGVybmFsVGFza0NvbnRyb2xsZXIpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgdGhyb3dJZkNhbmNlbGxlZDogKCkgPT4ge1xuICAgICAgICAgICAgdmFsaWRhdGVBY3RpdmUoaW50ZXJuYWxUYXNrQ29udHJvbGxlci5zaWduYWwpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICkpO1xuICAgIH0gY2F0Y2ggKGxpc3RlbmVyRXJyb3IpIHtcbiAgICAgIGlmICghKGxpc3RlbmVyRXJyb3IgaW5zdGFuY2VvZiBUYXNrQWJvcnRFcnJvcikpIHtcbiAgICAgICAgc2FmZWx5Tm90aWZ5RXJyb3Iob25FcnJvciwgbGlzdGVuZXJFcnJvciwge1xuICAgICAgICAgIHJhaXNlZEJ5OiBcImVmZmVjdFwiXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICBhd2FpdCBQcm9taXNlLmFsbChhdXRvSm9pblByb21pc2VzKTtcbiAgICAgIGludGVybmFsVGFza0NvbnRyb2xsZXIuYWJvcnQobGlzdGVuZXJDb21wbGV0ZWQpO1xuICAgICAgdW50cmFja0V4ZWN1dGluZ0xpc3RlbmVyKGVudHJ5KTtcbiAgICAgIGVudHJ5LnBlbmRpbmcuZGVsZXRlKGludGVybmFsVGFza0NvbnRyb2xsZXIpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgY2xlYXJMaXN0ZW5lck1pZGRsZXdhcmUgPSBjcmVhdGVDbGVhckxpc3RlbmVyTWlkZGxld2FyZShsaXN0ZW5lck1hcCwgZXhlY3V0aW5nTGlzdGVuZXJzKTtcbiAgY29uc3QgbWlkZGxld2FyZSA9IChhcGkpID0+IChuZXh0KSA9PiAoYWN0aW9uKSA9PiB7XG4gICAgaWYgKCFpc0FjdGlvbihhY3Rpb24pKSB7XG4gICAgICByZXR1cm4gbmV4dChhY3Rpb24pO1xuICAgIH1cbiAgICBpZiAoYWRkTGlzdGVuZXIubWF0Y2goYWN0aW9uKSkge1xuICAgICAgcmV0dXJuIHN0YXJ0TGlzdGVuaW5nKGFjdGlvbi5wYXlsb2FkKTtcbiAgICB9XG4gICAgaWYgKGNsZWFyQWxsTGlzdGVuZXJzLm1hdGNoKGFjdGlvbikpIHtcbiAgICAgIGNsZWFyTGlzdGVuZXJNaWRkbGV3YXJlKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChyZW1vdmVMaXN0ZW5lci5tYXRjaChhY3Rpb24pKSB7XG4gICAgICByZXR1cm4gc3RvcExpc3RlbmluZyhhY3Rpb24ucGF5bG9hZCk7XG4gICAgfVxuICAgIGxldCBvcmlnaW5hbFN0YXRlID0gYXBpLmdldFN0YXRlKCk7XG4gICAgY29uc3QgZ2V0T3JpZ2luYWxTdGF0ZSA9ICgpID0+IHtcbiAgICAgIGlmIChvcmlnaW5hbFN0YXRlID09PSBJTlRFUk5BTF9OSUxfVE9LRU4pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMjMpIDogYCR7YWxtfTogZ2V0T3JpZ2luYWxTdGF0ZSBjYW4gb25seSBiZSBjYWxsZWQgc3luY2hyb25vdXNseWApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG9yaWdpbmFsU3RhdGU7XG4gICAgfTtcbiAgICBsZXQgcmVzdWx0O1xuICAgIHRyeSB7XG4gICAgICByZXN1bHQgPSBuZXh0KGFjdGlvbik7XG4gICAgICBpZiAobGlzdGVuZXJNYXAuc2l6ZSA+IDApIHtcbiAgICAgICAgY29uc3QgY3VycmVudFN0YXRlID0gYXBpLmdldFN0YXRlKCk7XG4gICAgICAgIGNvbnN0IGxpc3RlbmVyRW50cmllcyA9IEFycmF5LmZyb20obGlzdGVuZXJNYXAudmFsdWVzKCkpO1xuICAgICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGxpc3RlbmVyRW50cmllcykge1xuICAgICAgICAgIGxldCBydW5MaXN0ZW5lciA9IGZhbHNlO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBydW5MaXN0ZW5lciA9IGVudHJ5LnByZWRpY2F0ZShhY3Rpb24sIGN1cnJlbnRTdGF0ZSwgb3JpZ2luYWxTdGF0ZSk7XG4gICAgICAgICAgfSBjYXRjaCAocHJlZGljYXRlRXJyb3IpIHtcbiAgICAgICAgICAgIHJ1bkxpc3RlbmVyID0gZmFsc2U7XG4gICAgICAgICAgICBzYWZlbHlOb3RpZnlFcnJvcihvbkVycm9yLCBwcmVkaWNhdGVFcnJvciwge1xuICAgICAgICAgICAgICByYWlzZWRCeTogXCJwcmVkaWNhdGVcIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghcnVuTGlzdGVuZXIpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBub3RpZnlMaXN0ZW5lcihlbnRyeSwgYWN0aW9uLCBhcGksIGdldE9yaWdpbmFsU3RhdGUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIG9yaWdpbmFsU3RhdGUgPSBJTlRFUk5BTF9OSUxfVE9LRU47XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG4gIHJldHVybiB7XG4gICAgbWlkZGxld2FyZSxcbiAgICBzdGFydExpc3RlbmluZyxcbiAgICBzdG9wTGlzdGVuaW5nLFxuICAgIGNsZWFyTGlzdGVuZXJzOiBjbGVhckxpc3RlbmVyTWlkZGxld2FyZVxuICB9O1xufTtcblxuLy8gc3JjL2R5bmFtaWNNaWRkbGV3YXJlL2luZGV4LnRzXG52YXIgY3JlYXRlTWlkZGxld2FyZUVudHJ5ID0gKG1pZGRsZXdhcmUpID0+ICh7XG4gIG1pZGRsZXdhcmUsXG4gIGFwcGxpZWQ6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKClcbn0pO1xudmFyIG1hdGNoSW5zdGFuY2UgPSAoaW5zdGFuY2VJZCkgPT4gKGFjdGlvbikgPT4gYWN0aW9uPy5tZXRhPy5pbnN0YW5jZUlkID09PSBpbnN0YW5jZUlkO1xudmFyIGNyZWF0ZUR5bmFtaWNNaWRkbGV3YXJlID0gKCkgPT4ge1xuICBjb25zdCBpbnN0YW5jZUlkID0gbmFub2lkKCk7XG4gIGNvbnN0IG1pZGRsZXdhcmVNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBjb25zdCB3aXRoTWlkZGxld2FyZSA9IE9iamVjdC5hc3NpZ24oY3JlYXRlQWN0aW9uKFwiZHluYW1pY01pZGRsZXdhcmUvYWRkXCIsICguLi5taWRkbGV3YXJlcykgPT4gKHtcbiAgICBwYXlsb2FkOiBtaWRkbGV3YXJlcyxcbiAgICBtZXRhOiB7XG4gICAgICBpbnN0YW5jZUlkXG4gICAgfVxuICB9KSksIHtcbiAgICB3aXRoVHlwZXM6ICgpID0+IHdpdGhNaWRkbGV3YXJlXG4gIH0pO1xuICBjb25zdCBhZGRNaWRkbGV3YXJlID0gT2JqZWN0LmFzc2lnbihmdW5jdGlvbiBhZGRNaWRkbGV3YXJlMiguLi5taWRkbGV3YXJlcykge1xuICAgIG1pZGRsZXdhcmVzLmZvckVhY2goKG1pZGRsZXdhcmUyKSA9PiB7XG4gICAgICBnZXRPckluc2VydENvbXB1dGVkKG1pZGRsZXdhcmVNYXAsIG1pZGRsZXdhcmUyLCBjcmVhdGVNaWRkbGV3YXJlRW50cnkpO1xuICAgIH0pO1xuICB9LCB7XG4gICAgd2l0aFR5cGVzOiAoKSA9PiBhZGRNaWRkbGV3YXJlXG4gIH0pO1xuICBjb25zdCBnZXRGaW5hbE1pZGRsZXdhcmUgPSAoYXBpKSA9PiB7XG4gICAgY29uc3QgYXBwbGllZE1pZGRsZXdhcmUgPSBBcnJheS5mcm9tKG1pZGRsZXdhcmVNYXAudmFsdWVzKCkpLm1hcCgoZW50cnkpID0+IGdldE9ySW5zZXJ0Q29tcHV0ZWQoZW50cnkuYXBwbGllZCwgYXBpLCBlbnRyeS5taWRkbGV3YXJlKSk7XG4gICAgcmV0dXJuIGNvbXBvc2UoLi4uYXBwbGllZE1pZGRsZXdhcmUpO1xuICB9O1xuICBjb25zdCBpc1dpdGhNaWRkbGV3YXJlID0gaXNBbGxPZih3aXRoTWlkZGxld2FyZSwgbWF0Y2hJbnN0YW5jZShpbnN0YW5jZUlkKSk7XG4gIGNvbnN0IG1pZGRsZXdhcmUgPSAoYXBpKSA9PiAobmV4dCkgPT4gKGFjdGlvbikgPT4ge1xuICAgIGlmIChpc1dpdGhNaWRkbGV3YXJlKGFjdGlvbikpIHtcbiAgICAgIGFkZE1pZGRsZXdhcmUoLi4uYWN0aW9uLnBheWxvYWQpO1xuICAgICAgcmV0dXJuIGFwaS5kaXNwYXRjaDtcbiAgICB9XG4gICAgcmV0dXJuIGdldEZpbmFsTWlkZGxld2FyZShhcGkpKG5leHQpKGFjdGlvbik7XG4gIH07XG4gIHJldHVybiB7XG4gICAgbWlkZGxld2FyZSxcbiAgICBhZGRNaWRkbGV3YXJlLFxuICAgIHdpdGhNaWRkbGV3YXJlLFxuICAgIGluc3RhbmNlSWRcbiAgfTtcbn07XG5cbi8vIHNyYy9jb21iaW5lU2xpY2VzLnRzXG5pbXBvcnQgeyBjb21iaW5lUmVkdWNlcnMgYXMgY29tYmluZVJlZHVjZXJzMiB9IGZyb20gXCJyZWR1eFwiO1xudmFyIGlzU2xpY2VMaWtlID0gKG1heWJlU2xpY2VMaWtlKSA9PiBcInJlZHVjZXJQYXRoXCIgaW4gbWF5YmVTbGljZUxpa2UgJiYgdHlwZW9mIG1heWJlU2xpY2VMaWtlLnJlZHVjZXJQYXRoID09PSBcInN0cmluZ1wiO1xudmFyIGdldFJlZHVjZXJzID0gKHNsaWNlcykgPT4gc2xpY2VzLmZsYXRNYXAoKHNsaWNlT3JNYXApID0+IGlzU2xpY2VMaWtlKHNsaWNlT3JNYXApID8gW1tzbGljZU9yTWFwLnJlZHVjZXJQYXRoLCBzbGljZU9yTWFwLnJlZHVjZXJdXSA6IE9iamVjdC5lbnRyaWVzKHNsaWNlT3JNYXApKTtcbnZhciBPUklHSU5BTF9TVEFURSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwicnRrLXN0YXRlLXByb3h5LW9yaWdpbmFsXCIpO1xudmFyIGlzU3RhdGVQcm94eSA9ICh2YWx1ZSkgPT4gISF2YWx1ZSAmJiAhIXZhbHVlW09SSUdJTkFMX1NUQVRFXTtcbnZhciBzdGF0ZVByb3h5TWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG52YXIgY3JlYXRlU3RhdGVQcm94eSA9IChzdGF0ZSwgcmVkdWNlck1hcCwgaW5pdGlhbFN0YXRlQ2FjaGUpID0+IGdldE9ySW5zZXJ0Q29tcHV0ZWQoc3RhdGVQcm94eU1hcCwgc3RhdGUsICgpID0+IG5ldyBQcm94eShzdGF0ZSwge1xuICBnZXQ6ICh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSA9PiB7XG4gICAgaWYgKHByb3AgPT09IE9SSUdJTkFMX1NUQVRFKSByZXR1cm4gdGFyZ2V0O1xuICAgIGNvbnN0IHJlc3VsdCA9IFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpO1xuICAgIGlmICh0eXBlb2YgcmVzdWx0ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBjb25zdCBjYWNoZWQgPSBpbml0aWFsU3RhdGVDYWNoZVtwcm9wXTtcbiAgICAgIGlmICh0eXBlb2YgY2FjaGVkICE9PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gY2FjaGVkO1xuICAgICAgY29uc3QgcmVkdWNlciA9IHJlZHVjZXJNYXBbcHJvcF07XG4gICAgICBpZiAocmVkdWNlcikge1xuICAgICAgICBjb25zdCByZWR1Y2VyUmVzdWx0ID0gcmVkdWNlcih2b2lkIDAsIHtcbiAgICAgICAgICB0eXBlOiBuYW5vaWQoKVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKHR5cGVvZiByZWR1Y2VyUmVzdWx0ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMjQpIDogYFRoZSBzbGljZSByZWR1Y2VyIGZvciBrZXkgXCIke3Byb3AudG9TdHJpbmcoKX1cIiByZXR1cm5lZCB1bmRlZmluZWQgd2hlbiBjYWxsZWQgZm9yIHNlbGVjdG9yKCkuIElmIHRoZSBzdGF0ZSBwYXNzZWQgdG8gdGhlIHJlZHVjZXIgaXMgdW5kZWZpbmVkLCB5b3UgbXVzdCBleHBsaWNpdGx5IHJldHVybiB0aGUgaW5pdGlhbCBzdGF0ZS4gVGhlIGluaXRpYWwgc3RhdGUgbWF5IG5vdCBiZSB1bmRlZmluZWQuIElmIHlvdSBkb24ndCB3YW50IHRvIHNldCBhIHZhbHVlIGZvciB0aGlzIHJlZHVjZXIsIHlvdSBjYW4gdXNlIG51bGwgaW5zdGVhZCBvZiB1bmRlZmluZWQuYCk7XG4gICAgICAgIH1cbiAgICAgICAgaW5pdGlhbFN0YXRlQ2FjaGVbcHJvcF0gPSByZWR1Y2VyUmVzdWx0O1xuICAgICAgICByZXR1cm4gcmVkdWNlclJlc3VsdDtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxufSkpO1xudmFyIG9yaWdpbmFsID0gKHN0YXRlKSA9PiB7XG4gIGlmICghaXNTdGF0ZVByb3h5KHN0YXRlKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDI1KSA6IFwib3JpZ2luYWwgbXVzdCBiZSB1c2VkIG9uIHN0YXRlIFByb3h5XCIpO1xuICB9XG4gIHJldHVybiBzdGF0ZVtPUklHSU5BTF9TVEFURV07XG59O1xudmFyIGVtcHR5T2JqZWN0ID0ge307XG52YXIgbm9vcFJlZHVjZXIgPSAoc3RhdGUgPSBlbXB0eU9iamVjdCkgPT4gc3RhdGU7XG5mdW5jdGlvbiBjb21iaW5lU2xpY2VzKC4uLnNsaWNlcykge1xuICBjb25zdCByZWR1Y2VyTWFwID0gT2JqZWN0LmZyb21FbnRyaWVzKGdldFJlZHVjZXJzKHNsaWNlcykpO1xuICBjb25zdCBnZXRSZWR1Y2VyID0gKCkgPT4gT2JqZWN0LmtleXMocmVkdWNlck1hcCkubGVuZ3RoID8gY29tYmluZVJlZHVjZXJzMihyZWR1Y2VyTWFwKSA6IG5vb3BSZWR1Y2VyO1xuICBsZXQgcmVkdWNlciA9IGdldFJlZHVjZXIoKTtcbiAgZnVuY3Rpb24gY29tYmluZWRSZWR1Y2VyKHN0YXRlLCBhY3Rpb24pIHtcbiAgICByZXR1cm4gcmVkdWNlcihzdGF0ZSwgYWN0aW9uKTtcbiAgfVxuICBjb21iaW5lZFJlZHVjZXIud2l0aExhenlMb2FkZWRTbGljZXMgPSAoKSA9PiBjb21iaW5lZFJlZHVjZXI7XG4gIGNvbnN0IGluaXRpYWxTdGF0ZUNhY2hlID0ge307XG4gIGNvbnN0IGluamVjdCA9IChzbGljZSwgY29uZmlnID0ge30pID0+IHtcbiAgICBjb25zdCB7XG4gICAgICByZWR1Y2VyUGF0aCxcbiAgICAgIHJlZHVjZXI6IHJlZHVjZXJUb0luamVjdFxuICAgIH0gPSBzbGljZTtcbiAgICBjb25zdCBjdXJyZW50UmVkdWNlciA9IHJlZHVjZXJNYXBbcmVkdWNlclBhdGhdO1xuICAgIGlmICghY29uZmlnLm92ZXJyaWRlRXhpc3RpbmcgJiYgY3VycmVudFJlZHVjZXIgJiYgY3VycmVudFJlZHVjZXIgIT09IHJlZHVjZXJUb0luamVjdCkge1xuICAgICAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSBcInVuZGVmaW5lZFwiICYmIHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcImRldmVsb3BtZW50XCIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgY2FsbGVkIFxcYGluamVjdFxcYCB0byBvdmVycmlkZSBhbHJlYWR5LWV4aXN0aW5nIHJlZHVjZXIgJHtyZWR1Y2VyUGF0aH0gd2l0aG91dCBzcGVjaWZ5aW5nIFxcYG92ZXJyaWRlRXhpc3Rpbmc6IHRydWVcXGBgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjb21iaW5lZFJlZHVjZXI7XG4gICAgfVxuICAgIGlmIChjb25maWcub3ZlcnJpZGVFeGlzdGluZyAmJiBjdXJyZW50UmVkdWNlciAhPT0gcmVkdWNlclRvSW5qZWN0KSB7XG4gICAgICBkZWxldGUgaW5pdGlhbFN0YXRlQ2FjaGVbcmVkdWNlclBhdGhdO1xuICAgIH1cbiAgICByZWR1Y2VyTWFwW3JlZHVjZXJQYXRoXSA9IHJlZHVjZXJUb0luamVjdDtcbiAgICByZWR1Y2VyID0gZ2V0UmVkdWNlcigpO1xuICAgIHJldHVybiBjb21iaW5lZFJlZHVjZXI7XG4gIH07XG4gIGNvbnN0IHNlbGVjdG9yID0gT2JqZWN0LmFzc2lnbihmdW5jdGlvbiBtYWtlU2VsZWN0b3Ioc2VsZWN0b3JGbiwgc2VsZWN0U3RhdGUpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gc2VsZWN0b3IyKHN0YXRlLCAuLi5hcmdzKSB7XG4gICAgICByZXR1cm4gc2VsZWN0b3JGbihjcmVhdGVTdGF0ZVByb3h5KHNlbGVjdFN0YXRlID8gc2VsZWN0U3RhdGUoc3RhdGUsIC4uLmFyZ3MpIDogc3RhdGUsIHJlZHVjZXJNYXAsIGluaXRpYWxTdGF0ZUNhY2hlKSwgLi4uYXJncyk7XG4gICAgfTtcbiAgfSwge1xuICAgIG9yaWdpbmFsXG4gIH0pO1xuICByZXR1cm4gT2JqZWN0LmFzc2lnbihjb21iaW5lZFJlZHVjZXIsIHtcbiAgICBpbmplY3QsXG4gICAgc2VsZWN0b3JcbiAgfSk7XG59XG5cbi8vIHNyYy9mb3JtYXRQcm9kRXJyb3JNZXNzYWdlLnRzXG5mdW5jdGlvbiBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKGNvZGUpIHtcbiAgcmV0dXJuIGBNaW5pZmllZCBSZWR1eCBUb29sa2l0IGVycm9yICMke2NvZGV9OyB2aXNpdCBodHRwczovL3JlZHV4LXRvb2xraXQuanMub3JnL0Vycm9ycz9jb2RlPSR7Y29kZX0gZm9yIHRoZSBmdWxsIG1lc3NhZ2Ugb3IgdXNlIHRoZSBub24tbWluaWZpZWQgZGV2IGVudmlyb25tZW50IGZvciBmdWxsIGVycm9ycy4gYDtcbn1cbmV4cG9ydCB7XG4gIFJlZHVjZXJUeXBlLFxuICBTSE9VTERfQVVUT0JBVENILFxuICBUYXNrQWJvcnRFcnJvcixcbiAgVHVwbGUsXG4gIGFkZExpc3RlbmVyLFxuICBhc3luY1RodW5rQ3JlYXRvcixcbiAgYXV0b0JhdGNoRW5oYW5jZXIsXG4gIGJ1aWxkQ3JlYXRlU2xpY2UsXG4gIGNsZWFyQWxsTGlzdGVuZXJzLFxuICBjb21iaW5lU2xpY2VzLFxuICBjb25maWd1cmVTdG9yZSxcbiAgY3JlYXRlQWN0aW9uLFxuICBjcmVhdGVBY3Rpb25DcmVhdG9ySW52YXJpYW50TWlkZGxld2FyZSxcbiAgY3JlYXRlQXN5bmNUaHVuayxcbiAgY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3IsXG4gIGNyZWF0ZURyYWZ0U2FmZVNlbGVjdG9yQ3JlYXRvcixcbiAgY3JlYXRlRHluYW1pY01pZGRsZXdhcmUsXG4gIGNyZWF0ZUVudGl0eUFkYXB0ZXIsXG4gIGNyZWF0ZUltbXV0YWJsZVN0YXRlSW52YXJpYW50TWlkZGxld2FyZSxcbiAgY3JlYXRlTGlzdGVuZXJNaWRkbGV3YXJlLFxuICBwcm9kdWNlIGFzIGNyZWF0ZU5leHRTdGF0ZSxcbiAgY3JlYXRlUmVkdWNlcixcbiAgY3JlYXRlU2VsZWN0b3IsXG4gIGNyZWF0ZVNlbGVjdG9yQ3JlYXRvcixcbiAgY3JlYXRlU2VyaWFsaXphYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlLFxuICBjcmVhdGVTbGljZSxcbiAgY3VycmVudCxcbiAgZmluZE5vblNlcmlhbGl6YWJsZVZhbHVlLFxuICBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlLFxuICBmcmVlemUsXG4gIGlzQWN0aW9uQ3JlYXRvcixcbiAgaXNBbGxPZixcbiAgaXNBbnlPZixcbiAgaXNBc3luY1RodW5rQWN0aW9uLFxuICBpc0RyYWZ0LFxuICBpc0ZTQSBhcyBpc0ZsdXhTdGFuZGFyZEFjdGlvbixcbiAgaXNGdWxmaWxsZWQsXG4gIGlzSW1tdXRhYmxlRGVmYXVsdCxcbiAgaXNQZW5kaW5nLFxuICBpc1BsYWluLFxuICBpc1JlamVjdGVkLFxuICBpc1JlamVjdGVkV2l0aFZhbHVlLFxuICBscnVNZW1vaXplLFxuICBtaW5pU2VyaWFsaXplRXJyb3IsXG4gIG5hbm9pZCxcbiAgb3JpZ2luYWwyIGFzIG9yaWdpbmFsLFxuICBwcmVwYXJlQXV0b0JhdGNoZWQsXG4gIHJlbW92ZUxpc3RlbmVyLFxuICB1bndyYXBSZXN1bHQsXG4gIHdlYWtNYXBNZW1vaXplXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVkdXgtdG9vbGtpdC5tb2Rlcm4ubWpzLm1hcCJdLCJtYXBwaW5ncyI6IjtBQUNBLElBQUksNkJBQTZCO0FBQ2pDLElBQUkscUJBQXFCLFdBQVcsYUFBYTtDQUMvQyxJQUFJLFFBQVEsS0FBSztDQUNqQixJQUFJO0VBQ0YsTUFBTSxJQUFJLE1BQU07Q0FDbEIsU0FBUyxHQUFHO0VBRVYsQ0FBQyxDQUFFLFNBQVU7Q0FDZjtDQUNBLFFBQVEsS0FDTiwwQ0FBMEMsV0FBVyxPQUFPLFNBQVMsT0FBTyxHQUFHLGlCQUFpQixVQUFVOzs7c0ZBSTFHLEVBQUUsTUFBTSxDQUNWO0FBQ0Y7QUFHQSxJQUFJLHNCQUFzQjtDQUN4QixxQkFBcUI7Q0FDckIsdUJBQXVCO0NBQ3ZCLGdCQUFnQjtBQUNsQjtBQU1BLElBQUksWUFBWSxNQUFNO0NBQ3BCLFlBQVksT0FBTztFQUNqQixLQUFLLFFBQVE7Q0FDZjtDQUNBLFFBQVE7RUFDTixPQUFPLEtBQUs7Q0FDZDtBQUNGO0FBQ0EsSUFBSSxtQkFBbUIsT0FBTyxZQUFZLGNBQWMsWUFBWTtBQUNwRSxJQUFJLE1BQXNCLDJCQUFXO0FBQ3JDLElBQUksZUFBZTtBQUNuQixJQUFJLGFBQWE7QUFDakIsU0FBUyxrQkFBa0I7Q0FDekIsT0FBTztFQUNMLEdBQUc7RUFDSCxHQUFHLEtBQUs7RUFDUixHQUFHO0VBQ0gsR0FBRztDQUNMO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsR0FBRztDQUNyQixJQUFJLGFBQWEsS0FDZixPQUFPLEVBQUUsTUFBTTtDQUVqQixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsTUFBTSxVQUFVLENBQUMsR0FBRztDQUMxQyxJQUFJLFNBQVMsZ0JBQWdCO0NBQzdCLE1BQU0sRUFBRSxxQkFBcUIsWUFBWTtDQUN6QyxNQUFNLGlCQUFpQixZQUFZLEtBQUs7Q0FDeEMsSUFBSSxtQkFBbUIsQ0FBQyxPQUFPLFVBQVUsT0FBTyxLQUFLLFVBQVUsSUFDN0QsTUFBTSxJQUFJLFVBQ1IsaURBQWlELFNBQ25EO0NBRUYsSUFBSSxXQUFXO0NBQ2YsSUFBSSxpQkFBaUI7Q0FDckIsSUFBSTtDQUNKLElBQUksZUFBZTtDQUNuQixJQUFJLDBCQUEwQjtDQUM5QixTQUFTLHVCQUF1QjtFQUM5QixJQUFJLGtCQUFrQixTQUFTO0dBQzdCLFdBQVc7R0FDWCxTQUFTLGdCQUFnQjtHQUN6QixpQkFBaUI7RUFDbkI7Q0FDRjtDQUNBLFNBQVMsV0FBVztFQUNsQixJQUFJLFlBQVk7RUFDaEIsTUFBTSxFQUFFLFdBQVc7RUFDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsSUFBSSxHQUFHLEtBQUs7R0FDdEMsTUFBTSxNQUFNLFVBQVU7R0FDdEIsSUFBSSxPQUFPLFFBQVEsY0FBYyxPQUFPLFFBQVEsWUFBWSxRQUFRLE1BQU07SUFDeEUsSUFBSSxjQUFjLFVBQVU7SUFDNUIsSUFBSSxnQkFBZ0IsTUFDbEIsVUFBVSxJQUFJLDhCQUE4QixJQUFJLFFBQVE7SUFFMUQsTUFBTSxhQUFhLFlBQVksSUFBSSxHQUFHO0lBQ3RDLElBQUksZUFBZSxLQUFLLEdBQUc7S0FDekIsWUFBWSxnQkFBZ0I7S0FDNUIsWUFBWSxJQUFJLEtBQUssU0FBUztJQUNoQyxPQUNFLFlBQVk7R0FFaEIsT0FBTztJQUNMLElBQUksaUJBQWlCLFVBQVU7SUFDL0IsSUFBSSxtQkFBbUIsTUFDckIsVUFBVSxJQUFJLGlDQUFpQyxJQUFJLElBQUk7SUFFekQsTUFBTSxnQkFBZ0IsZUFBZSxJQUFJLEdBQUc7SUFDNUMsSUFBSSxrQkFBa0IsS0FBSyxHQUFHO0tBQzVCLFlBQVksZ0JBQWdCO0tBQzVCLGVBQWUsSUFBSSxLQUFLLFNBQVM7S0FDakM7S0FFRSxJQUFJLGVBQWUsT0FBTyw0QkFBNEI7TUFDcEQsTUFBTSxFQUFFLG1CQUFtQjtNQUMzQixJQUFJLG1CQUFtQixZQUFZLG1CQUFtQixVQUFVLENBQUMseUJBQXlCO09BQ3hGLDBCQUEwQjtPQUMxQixrQkFBa0IsZUFBZSxNQUFNLEtBQUssSUFBSTtNQUNsRDtLQUNGO0lBRUosT0FDRSxZQUFZO0dBRWhCO0VBQ0Y7RUFDQSxJQUFJLFVBQVUsTUFBTSxZQUNsQixPQUFPLFVBQVU7RUFFbkIsSUFBSSxhQUFhLE1BQU07R0FDckIsSUFBSSxnQkFBZ0I7R0FDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsSUFBSSxHQUFHLEtBQUs7SUFDdEMsTUFBTSxNQUFNLFVBQVU7SUFDdEIsSUFBSTtJQUNKLElBQUksT0FBTyxRQUFRLGNBQWMsT0FBTyxRQUFRLFlBQVksUUFBUSxNQUFNO0tBQ3hFLE1BQU0sa0JBQWtCLGNBQWM7S0FDdEMsT0FBTyxvQkFBb0IsT0FBTyxnQkFBZ0IsSUFBSSxHQUFHLElBQUksS0FBSztJQUNwRSxPQUFPO0tBQ0wsTUFBTSxxQkFBcUIsY0FBYztLQUN6QyxPQUFPLHVCQUF1QixPQUFPLG1CQUFtQixJQUFJLEdBQUcsSUFBSSxLQUFLO0lBQzFFO0lBQ0EsSUFBSSxTQUFTLEtBQUssR0FBRztLQUNuQixnQkFBZ0I7S0FDaEI7SUFDRjtJQUNBLGdCQUFnQjtHQUNsQjtHQUNBLElBQUksa0JBQWtCLFFBQVEsY0FBYyxNQUFNLFlBQVk7SUFDNUQsTUFBTSxlQUFlO0lBQ3JCLGFBQWEsSUFBSTtJQUNqQixhQUFhLElBQUksY0FBYztJQUMvQixxQkFBcUI7SUFDckIsT0FBTyxjQUFjO0dBQ3ZCO0VBQ0Y7RUFDQSxNQUFNLGlCQUFpQjtFQUN2QixJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sU0FBUztFQUN2QztFQUNBLElBQUkscUJBQXFCO0dBQ3ZCLE1BQU0sa0JBQWtCLFdBQVcsVUFBVTtHQUM3QyxJQUFJLG1CQUFtQixRQUFRLG9CQUFvQixpQkFBaUIsTUFBTSxHQUFHO0lBQzNFLFNBQVM7SUFDVCxpQkFBaUIsS0FBSztHQUN4QjtHQUVBLGFBRHFCLE9BQU8sV0FBVyxZQUFZLFdBQVcsUUFBUSxPQUFPLFdBQVcsNkJBQzVDLElBQUksSUFBSSxNQUFNLElBQUk7RUFDaEU7RUFDQSxlQUFlLElBQUk7RUFDbkIsZUFBZSxJQUFJO0VBQ25CLElBQUksZ0JBQ0YscUJBQXFCO0VBRXZCLE9BQU87Q0FDVDtDQUNBLFNBQVMsbUJBQW1CO0VBQzFCLFNBQVMsZ0JBQWdCO0VBQ3pCLFdBQVc7RUFDWCxpQkFBaUI7RUFDakIsU0FBUyxrQkFBa0I7RUFFekIsMEJBQTBCO0NBRTlCO0NBQ0EsU0FBUyxxQkFBcUI7Q0FDOUIsU0FBUywwQkFBMEI7RUFDakMsZUFBZTtDQUNqQjtDQUNBLE9BQU87QUFDVDtBQUdBLElBQUksNEJBQTRCLFlBQVksdUJBQXVCLHlCQUF5QjtDQUMxRixJQUFJLHNCQUFzQixXQUFXLEtBQUssc0JBQXNCLE9BQU8sc0JBQXNCO0VBQzNGLElBQUksc0JBQXNCO0VBQzFCLElBQUk7R0FDRixNQUFNLGNBQWMsQ0FBQztHQUNyQixJQUFJLFdBQVcsV0FBVyxNQUFNLGFBQWEsc0JBQXNCO0VBQ3JFLFFBQVEsQ0FDUjtFQUNBLElBQUkscUJBQXFCO0dBQ3ZCLElBQUksUUFBUSxLQUFLO0dBQ2pCLElBQUk7SUFDRixNQUFNLElBQUksTUFBTTtHQUNsQixTQUFTLEdBQUc7SUFFVixDQUFDLENBQUUsU0FBVTtHQUNmO0dBQ0EsUUFBUSxLQUNOLG1UQUNBLEVBQUUsTUFBTSxDQUNWO0VBQ0Y7Q0FDRjtBQUNGO0FBR0EsSUFBSSw4QkFBOEIsV0FBVztDQUMzQyxJQUFJLFdBQVcsUUFBUSxPQUFPLFdBQVcsWUFBWSxFQUFFLHlCQUF5QixTQUM5RSxPQUFPO0NBRVQsTUFBTSxhQUFhLEVBQUUsR0FBRyxPQUFPO0NBQy9CLE9BQU8sV0FBVztDQUNsQixPQUFPO0FBQ1Q7QUFDQSxJQUFJLDBCQUEwQiw0QkFBNEIsU0FBUyxzQkFBc0I7Q0FDdkYsTUFBTSxFQUFFLFNBQVMsbUJBQW1CO0NBQ3BDLE1BQU0sRUFBRSxzQkFBc0IsNkJBQTZCO0NBQzNELE1BQU0sc0JBQXNCLENBQUM7Q0FDN0IsTUFBTSxFQUFFLFdBQVc7Q0FDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDMUIsb0JBQW9CLEtBQUssMkJBQTJCLGVBQWUsRUFBRSxDQUFDO0NBRXhFLE1BQU0sc0JBQXNCLGVBQWUsQ0FBQyxJQUFJLEdBQUcsbUJBQW1CO0NBRXRFLElBQUksRUFEaUMsb0JBQW9CLE1BQU0sTUFBTSxvQkFBb0IsTUFBTSxvQkFBb0IsTUFBTSxNQUFNLHdCQUF3QixJQUNwSDtFQUNqQyxJQUFJLFFBQVEsS0FBSztFQUNqQixJQUFJO0dBQ0YsTUFBTSxJQUFJLE1BQU07RUFDbEIsU0FBUyxHQUFHO0dBRVYsQ0FBQyxDQUFFLFNBQVU7RUFDZjtFQUNBLFFBQVEsS0FDTix5VEFDQTtHQUNFLFdBQVc7R0FDWCxhQUFhO0dBQ2IsY0FBYztHQUNkO0VBQ0YsQ0FDRjtDQUNGO0FBQ0Y7QUFHQSxJQUFJLFlBQTRCLHVCQUFPLFdBQVc7QUFDbEQsU0FBUyxpQkFBaUIsTUFBTSxlQUFlLHlDQUF5QyxPQUFPLFFBQVE7Q0FDckcsSUFBSSxPQUFPLFNBQVMsWUFDbEIsTUFBTSxJQUFJLFVBQVUsWUFBWTtBQUVwQztBQU1BLFNBQVMseUJBQXlCLE9BQU8sZUFBZSw4RUFBOEU7Q0FDcEksSUFBSSxDQUFDLE1BQU0sT0FBTyxTQUFTLE9BQU8sU0FBUyxVQUFVLEdBQUc7RUFDdEQsTUFBTSxZQUFZLE1BQU0sS0FDckIsU0FBUyxPQUFPLFNBQVMsYUFBYSxZQUFZLEtBQUssUUFBUSxVQUFVLE1BQU0sT0FBTyxJQUN6RixDQUFDLENBQUMsS0FBSyxJQUFJO0VBQ1gsTUFBTSxJQUFJLFVBQVUsR0FBRyxhQUFhLEdBQUcsVUFBVSxFQUFFO0NBQ3JEO0FBQ0Y7QUFDQSxJQUFJLGlCQUFpQixTQUFTO0NBQzVCLE9BQU8sTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPLENBQUMsSUFBSTtBQUMzQztBQUNBLFNBQVMsZ0JBQWdCLG9CQUFvQjtDQUMzQyxNQUFNLGVBQWUsTUFBTSxRQUFRLG1CQUFtQixFQUFFLElBQUksbUJBQW1CLEtBQUs7Q0FDcEYseUJBQ0UsY0FDQSxnR0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsNEJBQTRCLGNBQWMsbUJBQW1CO0NBQ3BFLE1BQU0sdUJBQXVCLENBQUM7Q0FDOUIsTUFBTSxFQUFFLFdBQVc7Q0FDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDMUIscUJBQXFCLEtBQUssYUFBYSxFQUFFLENBQUMsTUFBTSxNQUFNLGlCQUFpQixDQUFDO0NBRTFFLE9BQU87QUFDVDtBQUdBLFNBQVMsc0JBQXNCLGtCQUFrQixHQUFHLHdCQUF3QjtDQUMxRSxNQUFNLCtCQUErQixPQUFPLHFCQUFxQixhQUFhO0VBQzVFLFNBQVM7RUFDVCxnQkFBZ0I7Q0FDbEIsSUFBSTtDQUNKLE1BQU0sbUJBQW1CLEdBQUcsdUJBQXVCO0VBQ2pELElBQUksaUJBQWlCO0VBQ3JCLElBQUksMkJBQTJCO0VBQy9CLElBQUk7RUFDSixJQUFJLHdCQUF3QixDQUFDO0VBQzdCLElBQUksYUFBYSxtQkFBbUIsSUFBSTtFQUN4QyxJQUFJLE9BQU8sZUFBZSxVQUFVO0dBQ2xDLHdCQUF3QjtHQUN4QixhQUFhLG1CQUFtQixJQUFJO0VBQ3RDO0VBQ0EsaUJBQ0UsWUFDQSw4RUFBOEUsT0FBTyxXQUFXLEVBQ2xHO0VBQ0EsTUFBTSxrQkFBa0I7R0FDdEIsR0FBRztHQUNILEdBQUc7RUFDTDtFQUNBLE1BQU0sRUFDSixTQUNBLGlCQUFpQixDQUFDLEdBQ2xCLGNBQWMsZ0JBQ2QscUJBQXFCLENBQUMsTUFDcEI7RUFDSixNQUFNLHNCQUFzQixjQUFjLGNBQWM7RUFDeEQsTUFBTSwwQkFBMEIsY0FBYyxrQkFBa0I7RUFDaEUsTUFBTSxlQUFlLGdCQUFnQixrQkFBa0I7RUFDdkQsTUFBTSxxQkFBcUIsUUFBUSxTQUFTLHVCQUF1QjtHQUNqRTtHQUNBLE9BQU8sV0FBVyxNQUNoQixNQUNBLFNBQ0Y7RUFDRixHQUFHLEdBQUcsbUJBQW1CO0VBQ3pCLElBQUksV0FBVztFQUNmLE1BQU0sV0FBVyxZQUFZLFNBQVMsc0JBQXNCO0dBQzFEO0dBQ0EsTUFBTSxFQUFFLFdBQVc7R0FDbkIsTUFBTSx1QkFBdUIsSUFBSSxNQUFNLE1BQU07R0FDN0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDMUIscUJBQXFCLEtBQUssYUFBYSxFQUFFLENBQUMsTUFBTSxNQUFNLFNBQVM7R0FFakUsYUFBYSxtQkFBbUIsTUFBTSxNQUFNLG9CQUFvQjtHQUNyQjtJQUN6QyxNQUFNLEVBQUUsa0JBQWtCO0lBQzFCLE1BQU0sd0JBQXdCLGtCQUFrQixLQUFLLEtBQUssT0FBTyxVQUFVLGVBQWUsS0FDeEYsZUFDQSx1QkFDRixJQUFJLGNBQWMsd0JBQXdCLG9CQUFvQjtJQUM5RCxNQUFNLHNCQUFzQixrQkFBa0IsS0FBSyxLQUFLLE9BQU8sVUFBVSxlQUFlLEtBQ3RGLGVBQ0EscUJBQ0YsSUFBSSxjQUFjLHNCQUFzQixvQkFBb0I7SUFDNUQsSUFBSSwwQkFBMEIsWUFBWSwwQkFBMEIsVUFBVSxVQUM1RSx5QkFDRSxZQUNBLHNCQUNBLFVBQ0Y7SUFFRixJQUFJLHdCQUF3QixZQUFZLHdCQUF3QixVQUFVLFVBS3hFLHVCQUNFO0tBQUU7S0FBc0IsMEJBTE8sNEJBQy9CLGNBQ0EsU0FHK0M7SUFBRSxHQUNqRDtLQUFFO0tBQVMsZ0JBQWdCO0lBQW9CLEdBQy9DLFNBQ0Y7SUFFRixJQUFJLFVBQVUsV0FBVztHQUMzQjtHQUNBLE9BQU87RUFDVCxHQUFHLEdBQUcsdUJBQXVCO0VBQzdCLE9BQU8sT0FBTyxPQUFPLFVBQVU7R0FDN0I7R0FDQTtHQUNBO0dBQ0EsZ0NBQWdDO0dBQ2hDLHFDQUFxQztJQUNuQywyQkFBMkI7R0FDN0I7R0FDQSxrQkFBa0I7R0FDbEIsc0JBQXNCO0dBQ3RCLDJCQUEyQjtJQUN6QixpQkFBaUI7R0FDbkI7R0FDQTtHQUNBO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsT0FBTyxPQUFPLGlCQUFpQixFQUM3QixpQkFBaUIsZ0JBQ25CLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxJQUFJLGlCQUFpQyxzQ0FBc0IsY0FBYztBQTRCekUsU0FBUyxxQkFBcUIsUUFBUTtDQUNwQyxJQUFJO0NBQ0osT0FBTztFQUNMLElBQUksS0FBSztHQUNQLElBQUksU0FBUyxPQUFPLE1BQU0sS0FBSyxHQUFHLEdBQ2hDLE9BQU8sTUFBTTtHQUVmLE9BQU87RUFDVDtFQUNBLElBQUksS0FBSyxPQUFPO0dBQ2QsUUFBUTtJQUFFO0lBQUs7R0FBTTtFQUN2QjtFQUNBLGtCQUFrQixPQUFPLHFCQUFxQjtHQUM1QyxNQUFNLFVBQVU7R0FDaEIsT0FBTyxZQUFZLEtBQUssS0FBSyxvQkFBb0IsUUFBUSxPQUFPLEtBQUssSUFBSSxVQUFVLEtBQUs7RUFDMUY7RUFDQSxRQUFRO0dBQ04sUUFBUSxLQUFLO0VBQ2Y7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxlQUFlLFNBQVMsUUFBUTtDQUN2QyxJQUFJLFVBQVUsQ0FBQztDQUNmLFNBQVMsSUFBSSxLQUFLO0VBQ2hCLE1BQU0sYUFBYSxRQUFRLFdBQVcsVUFBVSxPQUFPLE1BQU0sS0FBSyxHQUFHLENBQUM7RUFDdEUsSUFBSSxhQUFhLElBQUk7R0FDbkIsTUFBTSxRQUFRLFFBQVE7R0FDdEIsSUFBSSxhQUFhLEdBQUc7SUFDbEIsUUFBUSxPQUFPLFlBQVksQ0FBQztJQUM1QixRQUFRLFFBQVEsS0FBSztHQUN2QjtHQUNBLE9BQU8sTUFBTTtFQUNmO0VBQ0EsT0FBTztDQUNUO0NBQ0EsU0FBUyxJQUFJLEtBQUssT0FBTztFQUN2QixRQUFRLFFBQVE7R0FBRTtHQUFLO0VBQU0sQ0FBQztFQUM5QixJQUFJLFFBQVEsU0FBUyxTQUNuQixRQUFRLElBQUk7Q0FFaEI7Q0FDQSxTQUFTLGtCQUFrQixPQUFPLHFCQUFxQjtFQUNyRCxNQUFNLGlCQUFpQjtFQUN2QixNQUFNLEVBQUUsV0FBVztFQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO0dBQy9CLE1BQU0sUUFBUSxlQUFlO0dBQzdCLElBQUksb0JBQW9CLE1BQU0sT0FBTyxLQUFLLEdBQ3hDLE9BQU87RUFFWDtDQUVGO0NBQ0EsU0FBUyxRQUFRO0VBQ2YsVUFBVSxDQUFDO0NBQ2I7Q0FDQSxPQUFPO0VBQUU7RUFBSztFQUFLO0VBQW1CO0NBQU07QUFDOUM7QUFDQSxJQUFJLDBCQUEwQixHQUFHLE1BQU0sTUFBTTtBQUM3QyxTQUFTLHlCQUF5QixlQUFlO0NBQy9DLE9BQU8sU0FBUywyQkFBMkIsTUFBTSxNQUFNO0VBQ3JELElBQUksU0FBUyxRQUFRLFNBQVMsUUFBUSxLQUFLLFdBQVcsS0FBSyxRQUN6RCxPQUFPO0VBRVQsTUFBTSxFQUFFLFdBQVc7RUFDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDMUIsSUFBSSxDQUFDLGNBQWMsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUNqQyxPQUFPO0VBR1gsT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsTUFBTSx3QkFBd0I7Q0FFaEQsTUFBTSxFQUNKLGdCQUFnQix3QkFDaEIsVUFBVSxHQUNWLHdCQUpzQixPQUFPLDJCQUEyQixXQUFXLHlCQUF5QixFQUFFLGVBQWUsdUJBQXVCO0NBTXRJLE1BQU0sYUFBYSx5QkFBeUIsYUFBYTtDQUN6RCxJQUFJLGVBQWU7Q0FDbkIsTUFBTSxRQUFRLFdBQVcsSUFBSSxxQkFBcUIsVUFBVSxJQUFJLGVBQWUsU0FBUyxVQUFVO0NBQ2xHLFNBQVMsV0FBVztFQUNsQixJQUFJLFFBQVEsTUFBTSxJQUFJLFNBQVM7RUFDL0IsSUFBSSxVQUFVLFdBQVc7R0FDdkIsUUFBUSxLQUFLLE1BQU0sTUFBTSxTQUFTO0dBQ2xDO0dBQ0EsSUFBSSxxQkFBcUI7SUFDdkIsTUFBTSxnQkFBZ0IsTUFBTSxrQkFDMUIsT0FDQSxtQkFDRjtJQUNBLElBQUksZUFBZTtLQUNqQixRQUFRLGNBQWM7S0FDdEIsaUJBQWlCLEtBQUs7SUFDeEI7R0FDRjtHQUNBLE1BQU0sSUFBSSxXQUFXLEtBQUs7RUFDNUI7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLG1CQUFtQjtFQUMxQixNQUFNLE1BQU07RUFDWixTQUFTLGtCQUFrQjtDQUM3QjtDQUNBLFNBQVMscUJBQXFCO0NBQzlCLFNBQVMsMEJBQTBCO0VBQ2pDLGVBQWU7Q0FDakI7Q0FDQSxPQUFPO0FBQ1Q7OztBQ3hnQkEsSUFBSSw0QkFBNEIsdUJBRFUsT0FBTyxXQUFXLGNBQWMsT0FBTyxjQUFjLGVBQUEsQ0FDcEQ7QUFHM0MsSUFBSSxxQkFBcUIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFNbkYsSUFBSSxzQkFBc0I7Q0FKeEIsTUFBTSxlQUErQiw2QkFBYTtDQUNsRCxTQUFTLGtCQUFrQyw2QkFBYTtDQUN4RCw0QkFBNEIsK0JBQStCLGFBQWE7QUFFdEM7QUFHcEMsU0FBUyxjQUFjLEtBQUs7Q0FDMUIsSUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLE1BQ3JDLE9BQU87Q0FDVCxJQUFJLFFBQVE7Q0FDWixPQUFPLE9BQU8sZUFBZSxLQUFLLE1BQU0sTUFDdEMsUUFBUSxPQUFPLGVBQWUsS0FBSztDQUVyQyxPQUFPLE9BQU8sZUFBZSxHQUFHLE1BQU0sU0FBUyxPQUFPLGVBQWUsR0FBRyxNQUFNO0FBQ2hGO0FBR0EsU0FBUyxXQUFXLEtBQUs7Q0FDdkIsSUFBSSxRQUFRLEtBQUssR0FDZixPQUFPO0NBQ1QsSUFBSSxRQUFRLE1BQ1YsT0FBTztDQUNULE1BQU0sT0FBTyxPQUFPO0NBQ3BCLFFBQVEsTUFBUjtFQUNFLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLLFlBQ0gsT0FBTztDQUVYO0NBQ0EsSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUNuQixPQUFPO0NBQ1QsSUFBSSxPQUFPLEdBQUcsR0FDWixPQUFPO0NBQ1QsSUFBSSxRQUFRLEdBQUcsR0FDYixPQUFPO0NBQ1QsTUFBTSxrQkFBa0IsU0FBUyxHQUFHO0NBQ3BDLFFBQVEsaUJBQVI7RUFDRSxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUssT0FDSCxPQUFPO0NBQ1g7Q0FDQSxPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsT0FBTyxFQUFFO0FBQ3pGO0FBQ0EsU0FBUyxTQUFTLEtBQUs7Q0FDckIsT0FBTyxPQUFPLElBQUksZ0JBQWdCLGFBQWEsSUFBSSxZQUFZLE9BQU87QUFDeEU7QUFDQSxTQUFTLFFBQVEsS0FBSztDQUNwQixPQUFPLGVBQWUsU0FBUyxPQUFPLElBQUksWUFBWSxZQUFZLElBQUksZUFBZSxPQUFPLElBQUksWUFBWSxvQkFBb0I7QUFDbEk7QUFDQSxTQUFTLE9BQU8sS0FBSztDQUNuQixJQUFJLGVBQWUsTUFDakIsT0FBTztDQUNULE9BQU8sT0FBTyxJQUFJLGlCQUFpQixjQUFjLE9BQU8sSUFBSSxZQUFZLGNBQWMsT0FBTyxJQUFJLFlBQVk7QUFDL0c7QUFDQSxTQUFTLE9BQU8sS0FBSztDQUNuQixJQUFJLFlBQVksT0FBTztDQUVyQixZQUFZLFdBQVcsR0FBRztDQUU1QixPQUFPO0FBQ1Q7QUFHQSxTQUFTLFlBQVksU0FBUyxnQkFBZ0IsVUFBVTtDQUN0RCxJQUFJLE9BQU8sWUFBWSxZQUNyQixNQUFNLElBQUksTUFBMEUsbUVBQW1FLE9BQU8sT0FBTyxFQUFFLEVBQUU7Q0FFM0ssSUFBSSxPQUFPLG1CQUFtQixjQUFjLE9BQU8sYUFBYSxjQUFjLE9BQU8sYUFBYSxjQUFjLE9BQU8sVUFBVSxPQUFPLFlBQ3RJLE1BQU0sSUFBSSxNQUEwRSxrUUFBa1E7Q0FFeFYsSUFBSSxPQUFPLG1CQUFtQixjQUFjLE9BQU8sYUFBYSxhQUFhO0VBQzNFLFdBQVc7RUFDWCxpQkFBaUIsS0FBSztDQUN4QjtDQUNBLElBQUksT0FBTyxhQUFhLGFBQWE7RUFDbkMsSUFBSSxPQUFPLGFBQWEsWUFDdEIsTUFBTSxJQUFJLE1BQTBFLCtEQUErRCxPQUFPLFFBQVEsRUFBRSxFQUFFO0VBRXhLLE9BQU8sU0FBUyxXQUFXLENBQUMsQ0FBQyxTQUFTLGNBQWM7Q0FDdEQ7Q0FDQSxJQUFJLGlCQUFpQjtDQUNyQixJQUFJLGVBQWU7Q0FDbkIsSUFBSSxtQ0FBbUMsSUFBSSxJQUFJO0NBQy9DLElBQUksZ0JBQWdCO0NBQ3BCLElBQUksb0JBQW9CO0NBQ3hCLElBQUksZ0JBQWdCO0NBQ3BCLFNBQVMsK0JBQStCO0VBQ3RDLElBQUksa0JBQWtCLGtCQUFrQjtHQUN0QyxnQ0FBZ0MsSUFBSSxJQUFJO0dBQ3hDLGlCQUFpQixTQUFTLFVBQVUsUUFBUTtJQUMxQyxjQUFjLElBQUksS0FBSyxRQUFRO0dBQ2pDLENBQUM7RUFDSDtDQUNGO0NBQ0EsU0FBUyxXQUFXO0VBQ2xCLElBQUksZUFDRixNQUFNLElBQUksTUFBMEUsc01BQXNNO0VBRTVSLE9BQU87Q0FDVDtDQUNBLFNBQVMsVUFBVSxVQUFVO0VBQzNCLElBQUksT0FBTyxhQUFhLFlBQ3RCLE1BQU0sSUFBSSxNQUEwRSwrREFBK0QsT0FBTyxRQUFRLEVBQUUsRUFBRTtFQUV4SyxJQUFJLGVBQ0YsTUFBTSxJQUFJLE1BQTBFLGlUQUFpVDtFQUV2WSxJQUFJLGVBQWU7RUFDbkIsNkJBQTZCO0VBQzdCLE1BQU0sYUFBYTtFQUNuQixjQUFjLElBQUksWUFBWSxRQUFRO0VBQ3RDLE9BQU8sU0FBUyxjQUFjO0dBQzVCLElBQUksQ0FBQyxjQUNIO0dBRUYsSUFBSSxlQUNGLE1BQU0sSUFBSSxNQUEwRSxzSkFBc0o7R0FFNU8sZUFBZTtHQUNmLDZCQUE2QjtHQUM3QixjQUFjLE9BQU8sVUFBVTtHQUMvQixtQkFBbUI7RUFDckI7Q0FDRjtDQUNBLFNBQVMsU0FBUyxRQUFRO0VBQ3hCLElBQUksQ0FBQyxjQUFjLE1BQU0sR0FDdkIsTUFBTSxJQUFJLE1BQTBFLGlFQUFpRSxPQUFPLE1BQU0sRUFBRSwyVUFBMlU7RUFFamYsSUFBSSxPQUFPLE9BQU8sU0FBUyxhQUN6QixNQUFNLElBQUksTUFBMEUsOEdBQTRHO0VBRWxNLElBQUksT0FBTyxPQUFPLFNBQVMsVUFDekIsTUFBTSxJQUFJLE1BQTJFLDJFQUEyRSxPQUFPLE9BQU8sSUFBSSxFQUFFLGlCQUFpQixPQUFPLEtBQUssZ0JBQWdCO0VBRW5PLElBQUksZUFDRixNQUFNLElBQUksTUFBMEUsb0NBQW9DO0VBRTFILElBQUk7R0FDRixnQkFBZ0I7R0FDaEIsZUFBZSxlQUFlLGNBQWMsTUFBTTtFQUNwRCxVQUFVO0dBQ1IsZ0JBQWdCO0VBQ2xCO0VBRUEsQ0FEa0IsbUJBQW1CLGNBQUEsQ0FDM0IsU0FBUyxhQUFhO0dBQzlCLFNBQVM7RUFDWCxDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsU0FBUyxlQUFlLGFBQWE7RUFDbkMsSUFBSSxPQUFPLGdCQUFnQixZQUN6QixNQUFNLElBQUksTUFBMkUsa0VBQWtFLE9BQU8sV0FBVyxHQUFHO0VBRTlLLGlCQUFpQjtFQUNqQixTQUFTLEVBQ1AsTUFBTSxvQkFBb0IsUUFDNUIsQ0FBQztDQUNIO0NBQ0EsU0FBUyxhQUFhO0VBQ3BCLE1BQU0saUJBQWlCO0VBQ3ZCLE9BQU87Ozs7Ozs7OztHQVNMLFVBQVUsVUFBVTtJQUNsQixJQUFJLE9BQU8sYUFBYSxZQUFZLGFBQWEsTUFDL0MsTUFBTSxJQUFJLE1BQTJFLDhEQUE4RCxPQUFPLFFBQVEsRUFBRSxFQUFFO0lBRXhLLFNBQVMsZUFBZTtLQUN0QixNQUFNLHFCQUFxQjtLQUMzQixJQUFJLG1CQUFtQixNQUNyQixtQkFBbUIsS0FBSyxTQUFTLENBQUM7SUFFdEM7SUFDQSxhQUFhO0lBRWIsT0FBTyxFQUNMLGFBRmtCLGVBQWUsWUFFdkIsRUFDWjtHQUNGO0dBQ0EsQ0FBQyw2QkFBNkI7SUFDNUIsT0FBTztHQUNUO0VBQ0Y7Q0FDRjtDQUNBLFNBQVMsRUFDUCxNQUFNLG9CQUFvQixLQUM1QixDQUFDO0NBUUQsT0FBTztFQU5MO0VBQ0E7RUFDQTtFQUNBO0dBQ0MsNEJBQTRCO0NBRXBCO0FBQ2I7QUFDQSxTQUFTLG1CQUFtQixTQUFTLGdCQUFnQixVQUFVO0NBQzdELE9BQU8sWUFBWSxTQUFTLGdCQUFnQixRQUFRO0FBQ3REO0FBR0EsU0FBUyxRQUFRLFNBQVM7Q0FDeEIsSUFBSSxPQUFPLFlBQVksZUFBZSxPQUFPLFFBQVEsVUFBVSxZQUM3RCxRQUFRLE1BQU0sT0FBTztDQUV2QixJQUFJO0VBQ0YsTUFBTSxJQUFJLE1BQU0sT0FBTztDQUN6QixTQUFTLEdBQUcsQ0FDWjtBQUNGO0FBR0EsU0FBUyxzQ0FBc0MsWUFBWSxVQUFVLFFBQVEsb0JBQW9CO0NBQy9GLE1BQU0sY0FBYyxPQUFPLEtBQUssUUFBUTtDQUN4QyxNQUFNLGVBQWUsVUFBVSxPQUFPLFNBQVMsb0JBQW9CLE9BQU8sa0RBQWtEO0NBQzVILElBQUksWUFBWSxXQUFXLEdBQ3pCLE9BQU87Q0FFVCxJQUFJLENBQUMsY0FBYyxVQUFVLEdBQzNCLE9BQU8sT0FBTyxhQUFhLDJCQUEyQixPQUFPLFVBQVUsRUFBRSxpRUFBaUUsWUFBWSxLQUFLLFFBQU0sRUFBRTtDQUVySyxNQUFNLGlCQUFpQixPQUFPLEtBQUssVUFBVSxDQUFDLENBQUMsUUFBUSxRQUFRLENBQUMsU0FBUyxlQUFlLEdBQUcsS0FBSyxDQUFDLG1CQUFtQixJQUFJO0NBQ3hILGVBQWUsU0FBUyxRQUFRO0VBQzlCLG1CQUFtQixPQUFPO0NBQzVCLENBQUM7Q0FDRCxJQUFJLFVBQVUsT0FBTyxTQUFTLG9CQUFvQixTQUNoRDtDQUNGLElBQUksZUFBZSxTQUFTLEdBQzFCLE9BQU8sY0FBYyxlQUFlLFNBQVMsSUFBSSxTQUFTLE1BQU0sSUFBSSxlQUFlLEtBQUssUUFBTSxFQUFFLGFBQWEsYUFBYSw2REFBNkQsWUFBWSxLQUFLLFFBQU0sRUFBRTtBQUVwTjtBQUNBLFNBQVMsbUJBQW1CLFVBQVU7Q0FDcEMsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLFNBQVMsUUFBUTtFQUNyQyxNQUFNLFVBQVUsU0FBUztFQUl6QixJQUFJLE9BSGlCLFFBQVEsS0FBSyxHQUFHLEVBQ25DLE1BQU0sb0JBQW9CLEtBQzVCLENBQ3NCLE1BQU0sYUFDMUIsTUFBTSxJQUFJLE1BQTJFLDhCQUE4QixJQUFJLDZRQUE2UTtFQUV0WSxJQUFJLE9BQU8sUUFBUSxLQUFLLEdBQUcsRUFDekIsTUFBTSxvQkFBb0IscUJBQXFCLEVBQ2pELENBQUMsTUFBTSxhQUNMLE1BQU0sSUFBSSxNQUEyRSw4QkFBOEIsSUFBSSw0RUFBNEUsb0JBQW9CLEtBQUssNlNBQTZTO0NBRTdnQixDQUFDO0FBQ0g7QUFDQSxTQUFTLGdCQUFnQixVQUFVO0NBQ2pDLE1BQU0sY0FBYyxPQUFPLEtBQUssUUFBUTtDQUN4QyxNQUFNLGdCQUFnQixDQUFDO0NBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsS0FBSztFQUMzQyxNQUFNLE1BQU0sWUFBWTtFQUV0QixJQUFJLE9BQU8sU0FBUyxTQUFTLGFBQzNCLFFBQVEsZ0NBQWdDLElBQUksRUFBRTtFQUdsRCxJQUFJLE9BQU8sU0FBUyxTQUFTLFlBQzNCLGNBQWMsT0FBTyxTQUFTO0NBRWxDO0NBQ0EsTUFBTSxtQkFBbUIsT0FBTyxLQUFLLGFBQWE7Q0FDbEQsSUFBSSxxQkFFbUIsQ0FBQztDQUV4QixJQUFJO0NBQ0osSUFBSTtFQUNGLG1CQUFtQixhQUFhO0NBQ2xDLFNBQVMsR0FBRztFQUNWLHNCQUFzQjtDQUN4QjtDQUNBLE9BQU8sU0FBUyxZQUFZLFFBQVEsQ0FBQyxHQUFHLFFBQVE7RUFDOUMsSUFBSSxxQkFDRixNQUFNO0VBRW1DO0dBQ3pDLE1BQU0saUJBQWlCLHNDQUFzQyxPQUFPLGVBQWUsUUFBUSxrQkFBa0I7R0FDN0csSUFBSSxnQkFDRixRQUFRLGNBQWM7RUFFMUI7RUFDQSxJQUFJLGFBQWE7RUFDakIsTUFBTSxZQUFZLENBQUM7RUFDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGlCQUFpQixRQUFRLEtBQUs7R0FDaEQsTUFBTSxNQUFNLGlCQUFpQjtHQUM3QixNQUFNLFVBQVUsY0FBYztHQUM5QixNQUFNLHNCQUFzQixNQUFNO0dBQ2xDLE1BQU0sa0JBQWtCLFFBQVEscUJBQXFCLE1BQU07R0FDM0QsSUFBSSxPQUFPLG9CQUFvQixhQUFhO0lBQzFDLE1BQU0sYUFBYSxVQUFVLE9BQU87SUFDcEMsTUFBTSxJQUFJLE1BQTJFLHNDQUFzQyxhQUFhLElBQUksT0FBTyxVQUFVLEVBQUUsS0FBSyxpQkFBaUIsK0JBQStCLElBQUksK0tBQStLO0dBQ3pZO0dBQ0EsVUFBVSxPQUFPO0dBQ2pCLGFBQWEsY0FBYyxvQkFBb0I7RUFDakQ7RUFDQSxhQUFhLGNBQWMsaUJBQWlCLFdBQVcsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0VBQzFFLE9BQU8sYUFBYSxZQUFZO0NBQ2xDO0FBQ0Y7QUFHQSxTQUFTLGtCQUFrQixlQUFlLFVBQVU7Q0FDbEQsT0FBTyxTQUFTLEdBQUcsTUFBTTtFQUN2QixPQUFPLFNBQVMsY0FBYyxNQUFNLE1BQU0sSUFBSSxDQUFDO0NBQ2pEO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixnQkFBZ0IsVUFBVTtDQUNwRCxJQUFJLE9BQU8sbUJBQW1CLFlBQzVCLE9BQU8sa0JBQWtCLGdCQUFnQixRQUFRO0NBRW5ELElBQUksT0FBTyxtQkFBbUIsWUFBWSxtQkFBbUIsTUFDM0QsTUFBTSxJQUFJLE1BQTJFLCtFQUErRSxPQUFPLGNBQWMsRUFBRSw0RkFBNEY7Q0FFelIsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixLQUFLLE1BQU0sT0FBTyxnQkFBZ0I7RUFDaEMsTUFBTSxnQkFBZ0IsZUFBZTtFQUNyQyxJQUFJLE9BQU8sa0JBQWtCLFlBQzNCLG9CQUFvQixPQUFPLGtCQUFrQixlQUFlLFFBQVE7Q0FFeEU7Q0FDQSxPQUFPO0FBQ1Q7QUFHQSxTQUFTLFFBQVEsR0FBRyxPQUFPO0NBQ3pCLElBQUksTUFBTSxXQUFXLEdBQ25CLFFBQVEsUUFBUTtDQUVsQixJQUFJLE1BQU0sV0FBVyxHQUNuQixPQUFPLE1BQU07Q0FFZixPQUFPLE1BQU0sUUFBUSxHQUFHLE9BQU8sR0FBRyxTQUFTLEVBQUUsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDO0FBQzFEO0FBR0EsU0FBUyxnQkFBZ0IsR0FBRyxhQUFhO0NBQ3ZDLFFBQVEsa0JBQWtCLFNBQVMsbUJBQW1CO0VBQ3BELE1BQU0sUUFBUSxhQUFhLFNBQVMsY0FBYztFQUNsRCxJQUFJLGlCQUFpQjtHQUNuQixNQUFNLElBQUksTUFBMkUsd0hBQXdIO0VBQy9NO0VBQ0EsTUFBTSxnQkFBZ0I7R0FDcEIsVUFBVSxNQUFNO0dBQ2hCLFdBQVcsUUFBUSxHQUFHLFNBQVMsU0FBUyxRQUFRLEdBQUcsSUFBSTtFQUN6RDtFQUVBLFdBQVcsUUFBUSxHQURMLFlBQVksS0FBSyxlQUFlLFdBQVcsYUFBYSxDQUM1QyxDQUFDLENBQUMsQ0FBQyxNQUFNLFFBQVE7RUFDM0MsT0FBTztHQUNMLEdBQUc7R0FDSDtFQUNGO0NBQ0Y7QUFDRjtBQUdBLFNBQVMsU0FBUyxRQUFRO0NBQ3hCLE9BQU8sY0FBYyxNQUFNLEtBQUssVUFBVSxVQUFVLE9BQU8sT0FBTyxTQUFTO0FBQzdFOzs7QUMvWEEsSUFBSSxVQUFVLE9BQU8sSUFBSSxlQUFlO0FBQ3hDLElBQUksWUFBWSxPQUFPLElBQUksaUJBQWlCO0FBQzVDLElBQUksY0FBYyxPQUFPLElBQUksYUFBYTtBQUcxQyxJQUFJLFNBQWlEO0NBRW5ELFNBQVMsUUFBUTtFQUNmLE9BQU8sbUJBQW1CLE9BQU8sa0ZBQWtGLE9BQU87Q0FDNUg7Q0FDQSxTQUFTLE9BQU87RUFDZCxPQUFPLHNKQUFzSixNQUFNO0NBQ3JLO0NBQ0E7Q0FDQSxTQUFTLE1BQU07RUFDYixPQUFPLHlIQUF5SDtDQUNsSTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFNBQVMsT0FBTztFQUNkLE9BQU8sbUNBQW1DO0NBQzVDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxTQUFTLE9BQU87RUFDZCxPQUFPLG9DQUFvQztDQUM3QztBQUdGO0FBQ0EsU0FBUyxJQUFJLE9BQU8sR0FBRyxNQUFNO0NBQ2dCO0VBQ3pDLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sTUFBTSxXQUFXLENBQUMsSUFBSSxFQUFFLE1BQU0sTUFBTSxJQUFJLElBQUk7RUFDbEQsTUFBTSxJQUFJLE1BQU0sV0FBVyxLQUFLO0NBQ2xDO0FBSUY7QUFHQSxJQUFJLElBQUk7QUFDUixJQUFJLGlCQUFpQixFQUFFO0FBQ3ZCLElBQUksY0FBYztBQUNsQixJQUFJLFlBQVk7QUFDaEIsSUFBSSxlQUFlO0FBQ25CLElBQUksYUFBYTtBQUNqQixJQUFJLFdBQVc7QUFDZixJQUFJLFFBQVE7QUFDWixJQUFJLFdBQVcsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUM1QyxTQUFTLFlBQVksT0FBTztDQUMxQixJQUFJLENBQUMsT0FDSCxPQUFPO0NBQ1QsT0FBT0EsZ0JBQWMsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLLENBQUMsQ0FBQyxNQUFNLGNBQWMsQ0FBQyxDQUFDLE1BQU0sWUFBWSxHQUFHLGNBQWMsTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLO0FBQ3pJO0FBQ0EsSUFBSSxtQkFBbUIsRUFBRSxVQUFVLENBQUMsWUFBWSxDQUFDLFNBQVM7QUFDMUQsSUFBSSxvQ0FBb0MsSUFBSSxRQUFRO0FBQ3BELFNBQVNBLGdCQUFjLE9BQU87Q0FDNUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEtBQUssR0FDOUIsT0FBTztDQUNULE1BQU0sUUFBUSxlQUFlLEtBQUs7Q0FDbEMsSUFBSSxVQUFVLFFBQVEsVUFBVSxFQUFFLFlBQ2hDLE9BQU87Q0FDVCxNQUFNLE9BQU8sRUFBRSxlQUFlLEtBQUssT0FBTyxXQUFXLEtBQUssTUFBTTtDQUNoRSxJQUFJLFNBQVMsUUFDWCxPQUFPO0NBQ1QsSUFBSSxDQUFDLFdBQVcsSUFBSSxHQUNsQixPQUFPO0NBQ1QsSUFBSSxhQUFhLGtCQUFrQixJQUFJLElBQUk7Q0FDM0MsSUFBSSxlQUFlLEtBQUssR0FBRztFQUN6QixhQUFhLFNBQVMsU0FBUyxLQUFLLElBQUk7RUFDeEMsa0JBQWtCLElBQUksTUFBTSxVQUFVO0NBQ3hDO0NBQ0EsT0FBTyxlQUFlO0FBQ3hCO0FBQ0EsU0FBUyxTQUFTLE9BQU87Q0FDdkIsSUFBSSxDQUFDLFFBQVEsS0FBSyxHQUNoQixJQUFJLElBQUksS0FBSztDQUNmLE9BQU8sTUFBTSxZQUFZLENBQUM7QUFDNUI7QUFDQSxTQUFTLEtBQUssS0FBSyxNQUFNLFNBQVMsTUFBTTtDQUN0QyxJQUFJLFlBQVksR0FBRyxNQUFNLEdBRXZCLENBRGEsU0FBUyxRQUFRLFFBQVEsR0FBRyxJQUFJLEVBQUUsS0FBSyxHQUFHLEVBQUEsQ0FDbEQsU0FBUyxRQUFRO0VBQ3BCLEtBQUssS0FBSyxJQUFJLE1BQU0sR0FBRztDQUN6QixDQUFDO01BRUQsSUFBSSxTQUFTLE9BQU8sVUFBVSxLQUFLLE9BQU8sT0FBTyxHQUFHLENBQUM7QUFFekQ7QUFDQSxTQUFTLFlBQVksT0FBTztDQUMxQixNQUFNLFFBQVEsTUFBTTtDQUNwQixPQUFPLFFBQVEsTUFBTSxRQUFRLFFBQVEsS0FBSyxJQUFJLElBQWdCLE1BQU0sS0FBSyxJQUFJLElBQWMsTUFBTSxLQUFLLElBQUksSUFBYztBQUMxSDtBQUNBLElBQUksT0FBTyxPQUFPLE1BQU0sT0FBTyxZQUFZLEtBQUssTUFBTSxTQUFTLElBQWMsTUFBTSxJQUFJLElBQUksSUFBSSxFQUFFLFVBQVUsQ0FBQyxlQUFlLEtBQUssT0FBTyxJQUFJO0FBQzNJLElBQUksT0FBTyxPQUFPLE1BQU0sT0FBTyxZQUFZLEtBQUssTUFFOUMsU0FBUyxJQUFjLE1BQU0sSUFBSSxJQUFJLElBQUksTUFBTTtBQUVqRCxJQUFJLE9BQU8sT0FBTyxnQkFBZ0IsT0FBTyxPQUFPLFlBQVksS0FBSyxNQUFNO0NBQ3JFLElBQUksU0FBUyxHQUNYLE1BQU0sSUFBSSxnQkFBZ0IsS0FBSztNQUM1QixJQUFJLFNBQVMsR0FDaEIsTUFBTSxJQUFJLEtBQUs7TUFFZixNQUFNLGtCQUFrQjtBQUM1QjtBQUNBLFNBQVMsR0FBRyxHQUFHLEdBQUc7Q0FDaEIsSUFBSSxNQUFNLEdBQ1IsT0FBTyxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUk7TUFFaEMsT0FBTyxNQUFNLEtBQUssTUFBTTtBQUU1QjtBQUNBLElBQUksVUFBVSxNQUFNO0FBQ3BCLElBQUksU0FBUyxXQUFXLGtCQUFrQjtBQUMxQyxJQUFJLFNBQVMsV0FBVyxrQkFBa0I7QUFDMUMsSUFBSSxlQUFlLFdBQVcsT0FBTyxXQUFXO0FBQ2hELElBQUksY0FBYyxXQUFXLE9BQU8sV0FBVztBQUMvQyxJQUFJQyxlQUFhLFdBQVcsT0FBTyxXQUFXO0FBQzlDLFNBQVMsYUFBYSxPQUFPO0NBQzNCLE1BQU0sSUFBSSxDQUFDO0NBQ1gsT0FBTyxPQUFPLFVBQVUsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxNQUFNO0FBQzlDO0FBTUEsSUFBSSxVQUFVLFVBQVUsTUFBTSxTQUFTLE1BQU07QUFLN0MsSUFBSSxpQkFBaUIsVUFBVSxNQUFNLFlBQVksTUFBTSxRQUFRLE1BQU07QUFDckUsU0FBUyxZQUFZLE1BQU0sUUFBUTtDQUNqQyxJQUFJLE1BQU0sSUFBSSxHQUNaLE9BQU8sSUFBSSxJQUFJLElBQUk7Q0FFckIsSUFBSSxNQUFNLElBQUksR0FDWixPQUFPLElBQUksSUFBSSxJQUFJO0NBRXJCLElBQUksUUFBUSxJQUFJLEdBQ2QsT0FBTyxNQUFNLFVBQVUsQ0FBQyxNQUFNLEtBQUssSUFBSTtDQUN6QyxNQUFNLFVBQVVELGdCQUFjLElBQUk7Q0FDbEMsSUFBSSxXQUFXLFFBQVEsV0FBVyxnQkFBZ0IsQ0FBQyxTQUFTO0VBQzFELE1BQU0sY0FBYyxFQUFFLDBCQUEwQixJQUFJO0VBQ3BELE9BQU8sWUFBWTtFQUNuQixJQUFJLE9BQU8sUUFBUSxRQUFRLFdBQVc7RUFDdEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0dBQ3BDLE1BQU0sTUFBTSxLQUFLO0dBQ2pCLE1BQU0sT0FBTyxZQUFZO0dBQ3pCLElBQUksS0FBSyxjQUFjLE9BQU87SUFDNUIsS0FBSyxZQUFZO0lBQ2pCLEtBQUssZ0JBQWdCO0dBQ3ZCO0dBQ0EsSUFBSSxLQUFLLE9BQU8sS0FBSyxLQUNuQixZQUFZLE9BQU87S0FDaEIsZUFBZTtLQUNmLFdBQVc7S0FFWCxhQUFhLEtBQUs7S0FDbEIsUUFBUSxLQUFLO0dBQ2hCO0VBQ0o7RUFDQSxPQUFPLEVBQUUsT0FBTyxlQUFlLElBQUksR0FBRyxXQUFXO0NBQ25ELE9BQU87RUFDTCxNQUFNLFFBQVEsZUFBZSxJQUFJO0VBQ2pDLElBQUksVUFBVSxRQUFRLFNBQ3BCLE9BQU8sRUFBRSxHQUFHLEtBQUs7RUFFbkIsTUFBTSxNQUFNLEVBQUUsT0FBTyxLQUFLO0VBQzFCLE9BQU8sRUFBRSxPQUFPLEtBQUssSUFBSTtDQUMzQjtBQUNGO0FBQ0EsU0FBUyxPQUFPLEtBQUssT0FBTyxPQUFPO0NBQ2pDLElBQUksU0FBUyxHQUFHLEtBQUssUUFBUSxHQUFHLEtBQUssQ0FBQyxZQUFZLEdBQUcsR0FDbkQsT0FBTztDQUNULElBQUksWUFBWSxHQUFHLElBQUksR0FDckIsRUFBRSxpQkFBaUIsS0FBSztFQUN0QixLQUFLO0VBQ0wsS0FBSztFQUNMLE9BQU87RUFDUCxRQUFRO0NBQ1YsQ0FBQztDQUVILEVBQUUsT0FBTyxHQUFHO0NBQ1osSUFBSSxNQUNGLEtBQ0UsTUFDQyxNQUFNLFVBQVU7RUFDZixPQUFPLE9BQU8sSUFBSTtDQUNwQixHQUNBLEtBQ0Y7Q0FDRixPQUFPO0FBQ1Q7QUFDQSxTQUFTLDhCQUE4QjtDQUNyQyxJQUFJLENBQUM7QUFDUDtBQUNBLElBQUksMkJBQTJCLEdBQzVCLFFBQVEsNEJBQ1g7QUFDQSxTQUFTLFNBQVMsS0FBSztDQUNyQixJQUFJLFFBQVEsUUFBUSxDQUFDLFlBQVksR0FBRyxHQUNsQyxPQUFPO0NBQ1QsT0FBTyxFQUFFLFNBQVMsR0FBRztBQUN2QjtBQUdBLElBQUksZUFBZTtBQUNuQixJQUFJLGdCQUFnQjtBQUNwQixJQUFJLHFCQUFxQjtBQUN6QixJQUFJLFVBQVUsQ0FBQztBQUNmLFNBQVMsVUFBVSxXQUFXO0NBQzVCLE1BQU0sU0FBUyxRQUFRO0NBQ3ZCLElBQUksQ0FBQyxRQUNILElBQUksR0FBRyxTQUFTO0NBRWxCLE9BQU87QUFDVDtBQUNBLElBQUksa0JBQWtCLGNBQWMsQ0FBQyxDQUFDLFFBQVE7QUFPOUMsSUFBSTtBQUNKLElBQUksd0JBQXdCO0FBQzVCLElBQUksZUFBZSxTQUFTLFlBQVk7Q0FDdEMsU0FBUyxDQUFDO0NBQ1Y7Q0FDQTtDQUdBLGdCQUFnQjtDQUNoQixvQkFBb0I7Q0FDcEIsNkJBQTZCLElBQUksSUFBSTtDQUNyQyxzQ0FBc0MsSUFBSSxJQUFJO0NBQzlDLGVBQWUsZUFBZSxZQUFZLElBQUksVUFBVSxZQUFZLElBQUksS0FBSztDQUM3RSxxQkFBcUIsZUFBZSxrQkFBa0IsSUFBSSxVQUFVLGtCQUFrQixJQUFJLEtBQUs7QUFDakc7QUFDQSxTQUFTLGtCQUFrQixPQUFPLGVBQWU7Q0FDL0MsSUFBSSxlQUFlO0VBQ2pCLE1BQU0sZUFBZSxVQUFVLGFBQWE7RUFDNUMsTUFBTSxXQUFXLENBQUM7RUFDbEIsTUFBTSxrQkFBa0IsQ0FBQztFQUN6QixNQUFNLGlCQUFpQjtDQUN6QjtBQUNGO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsV0FBVyxLQUFLO0NBQ2hCLE1BQU0sUUFBUSxRQUFRLFdBQVc7Q0FDakMsTUFBTSxVQUFVO0FBQ2xCO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDekIsSUFBSSxVQUFVLGNBQ1osZUFBZSxNQUFNO0FBRXpCO0FBQ0EsSUFBSSxjQUFjLFdBQVcsZUFBZSxZQUFZLGNBQWMsTUFBTTtBQUM1RSxTQUFTLFlBQVksT0FBTztDQUMxQixNQUFNLFFBQVEsTUFBTTtDQUNwQixJQUFJLE1BQU0sVUFBVSxLQUFrQixNQUFNLFVBQVUsR0FDcEQsTUFBTSxRQUFRO01BRWQsTUFBTSxXQUFXO0FBQ3JCO0FBR0EsU0FBUyxjQUFjLFFBQVEsT0FBTztDQUNwQyxNQUFNLHFCQUFxQixNQUFNLFFBQVE7Q0FDekMsTUFBTSxZQUFZLE1BQU0sUUFBUTtDQUVoQyxJQURtQixXQUFXLEtBQUssS0FBSyxXQUFXLFdBQ25DO0VBQ2QsSUFBSSxVQUFVLFlBQVksQ0FBQyxXQUFXO0dBQ3BDLFlBQVksS0FBSztHQUNqQixJQUFJLENBQUM7RUFDUDtFQUNBLElBQUksWUFBWSxNQUFNLEdBQ3BCLFNBQVMsU0FBUyxPQUFPLE1BQU07RUFFakMsTUFBTSxFQUFFLGlCQUFpQjtFQUN6QixJQUFJLGNBQ0YsYUFBYSw0QkFDWCxVQUFVLFlBQVksQ0FBQyxPQUN2QixRQUNBLEtBQ0Y7Q0FFSixPQUNFLFNBQVMsU0FBUyxPQUFPLFNBQVM7Q0FFcEMsWUFBWSxPQUFPLFFBQVEsSUFBSTtDQUMvQixZQUFZLEtBQUs7Q0FDakIsSUFBSSxNQUFNLFVBQ1IsTUFBTSxlQUFlLE1BQU0sVUFBVSxNQUFNLGVBQWU7Q0FFNUQsT0FBTyxXQUFXLFVBQVUsU0FBUyxLQUFLO0FBQzVDO0FBQ0EsU0FBUyxTQUFTLFdBQVcsT0FBTztDQUNsQyxJQUFJLFNBQVMsS0FBSyxHQUNoQixPQUFPO0NBQ1QsTUFBTSxRQUFRLE1BQU07Q0FDcEIsSUFBSSxDQUFDLE9BRUgsT0FEbUIsWUFBWSxPQUFPLFVBQVUsYUFBYSxTQUM3QztDQUVsQixJQUFJLENBQUMsWUFBWSxPQUFPLFNBQVMsR0FDL0IsT0FBTztDQUVULElBQUksQ0FBQyxNQUFNLFdBQ1QsT0FBTyxNQUFNO0NBRWYsSUFBSSxDQUFDLE1BQU0sWUFBWTtFQUNyQixNQUFNLEVBQUUsZUFBZTtFQUN2QixJQUFJLFlBQ0YsT0FBTyxXQUFXLFNBQVMsR0FFekIsV0FENEIsSUFDckIsQ0FBQyxDQUFDLFNBQVM7RUFHdEIsMkJBQTJCLE9BQU8sU0FBUztDQUM3QztDQUNBLE9BQU8sTUFBTTtBQUNmO0FBQ0EsU0FBUyxZQUFZLE9BQU8sT0FBTyxPQUFPLE9BQU87Q0FDL0MsSUFBSSxDQUFDLE1BQU0sV0FBVyxNQUFNLE9BQU8sZUFBZSxNQUFNLGdCQUN0RCxPQUFPLE9BQU8sSUFBSTtBQUV0QjtBQUNBLFNBQVMsbUJBQW1CLE9BQU87Q0FDakMsTUFBTSxhQUFhO0NBQ25CLE1BQU0sT0FBTztBQUNmO0FBQ0EsSUFBSSxlQUFlLE9BQU8sY0FBYyxNQUFNLFdBQVc7QUFDekQsSUFBSSx5QkFBeUIsQ0FBQztBQUM5QixTQUFTLG9CQUFvQixRQUFRLFlBQVksZ0JBQWdCLGFBQWE7Q0FDNUUsTUFBTSxhQUFhLE9BQU8sTUFBTTtDQUNoQyxNQUFNLGFBQWEsT0FBTztDQUMxQixJQUFJLGdCQUFnQixLQUFLLEdBQ0Y7TUFBQSxJQUFJLFlBQVksYUFBYSxVQUNuQyxNQUFNLFlBQVk7R0FDL0IsSUFBSSxZQUFZLGFBQWEsZ0JBQWdCLFVBQVU7R0FDdkQ7RUFDRjs7Q0FFRixJQUFJLENBQUMsT0FBTyxpQkFBaUI7RUFDM0IsTUFBTSxpQkFBaUIsT0FBTyxrQ0FBa0MsSUFBSSxJQUFJO0VBQ3hFLEtBQUssYUFBYSxLQUFLLFVBQVU7R0FDL0IsSUFBSSxRQUFRLEtBQUssR0FBRztJQUNsQixNQUFNLE9BQU8sZUFBZSxJQUFJLEtBQUssS0FBSyxDQUFDO0lBQzNDLEtBQUssS0FBSyxHQUFHO0lBQ2IsZUFBZSxJQUFJLE9BQU8sSUFBSTtHQUNoQztFQUNGLENBQUM7Q0FDSDtDQUNBLE1BQU0sWUFBWSxPQUFPLGdCQUFnQixJQUFJLFVBQVUsS0FBSztDQUM1RCxLQUFLLE1BQU0sWUFBWSxXQUNyQixJQUFJLFlBQVksVUFBVSxnQkFBZ0IsVUFBVTtBQUV4RDtBQUNBLFNBQVMsa0NBQWtDLFFBQVEsT0FBTyxLQUFLO0NBQzdELE9BQU8sV0FBVyxLQUFLLFNBQVMsYUFBYSxXQUFXO0VBQ3RELE1BQU0sUUFBUTtFQUNkLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxPQUFPLFNBQVMsR0FDekM7RUFFRixVQUFVLGVBQWUsZUFBZSxLQUFLO0VBQzdDLE1BQU0saUJBQWlCLGNBQWMsS0FBSztFQUMxQyxvQkFBb0IsUUFBUSxNQUFNLFVBQVUsT0FBTyxnQkFBZ0IsR0FBRztFQUN0RSwyQkFBMkIsT0FBTyxTQUFTO0NBQzdDLENBQUM7QUFDSDtBQUNBLFNBQVMsMkJBQTJCLE9BQU8sV0FBVztDQUVwRCxJQUR1QixNQUFNLGFBQWEsQ0FBQyxNQUFNLGVBQWUsTUFBTSxVQUFVLEtBQWUsTUFBTSxVQUFVLEtBQWlCLE1BQU0sMEJBQTBCLE1BQU0sV0FBVyxRQUFRLEtBQUssSUFDMUs7RUFDbEIsTUFBTSxFQUFFLGlCQUFpQjtFQUN6QixJQUFJLGNBQWM7R0FDaEIsTUFBTSxXQUFXLGFBQWEsUUFBUSxLQUFLO0dBQzNDLElBQUksVUFDRixhQUFhLGlCQUFpQixPQUFPLFVBQVUsU0FBUztFQUU1RDtFQUNBLG1CQUFtQixLQUFLO0NBQzFCO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixRQUFRLEtBQUssT0FBTztDQUNoRCxNQUFNLEVBQUUsV0FBVztDQUNuQixJQUFJLFFBQVEsS0FBSyxHQUFHO0VBQ2xCLE1BQU0sUUFBUSxNQUFNO0VBQ3BCLElBQUksWUFBWSxPQUFPLE1BQU0sR0FDM0IsTUFBTSxXQUFXLEtBQUssU0FBUyx3QkFBd0I7R0FDckQsWUFBWSxNQUFNO0dBRWxCLG9CQUFvQixRQUFRLE9BREwsY0FBYyxLQUNXLEdBQUcsR0FBRztFQUN4RCxDQUFDO0NBRUwsT0FBTyxJQUFJLFlBQVksS0FBSyxHQUMxQixPQUFPLFdBQVcsS0FBSyxTQUFTLHFCQUFxQjtFQUNuRCxNQUFNLGFBQWEsT0FBTyxNQUFNO0VBQ2hDLElBQUksT0FBTyxVQUFVLEdBQ2Y7T0FBQSxXQUFXLElBQUksS0FBSyxHQUN0QixZQUFZLE9BQU8sT0FBTyxhQUFhLE1BQU07RUFBQSxPQUcvQyxJQUFJLElBQUksWUFBWSxLQUFLLE9BQU8sS0FBSyxNQUFNLE9BQ3JDO09BQUEsT0FBTyxRQUFRLFNBQVMsTUFBTSxPQUFPLFVBQVUsSUFBSSxHQUFHLEtBQUssV0FBVyxRQUFRLE9BQU8sT0FDdkYsWUFDRSxJQUFJLE9BQU8sT0FBTyxLQUFLLE9BQU8sS0FBSyxHQUNuQyxPQUFPLGFBQ1AsTUFDRjtFQUFBO0NBSVIsQ0FBQztBQUVMO0FBQ0EsU0FBUyxZQUFZLFFBQVEsWUFBWSxXQUFXO0NBQ2xELElBQUksQ0FBQyxVQUFVLE9BQU8sZUFBZSxVQUFVLHFCQUFxQixHQUNsRSxPQUFPO0NBRVQsSUFBSSxRQUFRLE1BQU0sS0FBSyxXQUFXLElBQUksTUFBTSxLQUFLLENBQUMsWUFBWSxNQUFNLEtBQUssU0FBUyxNQUFNLEdBQ3RGLE9BQU87Q0FFVCxXQUFXLElBQUksTUFBTTtDQUNyQixLQUFLLFNBQVMsS0FBSyxVQUFVO0VBQzNCLElBQUksUUFBUSxLQUFLLEdBQUc7R0FDbEIsTUFBTSxRQUFRLE1BQU07R0FDcEIsSUFBSSxZQUFZLE9BQU8sU0FBUyxHQUFHO0lBRWpDLElBQUksUUFBUSxLQURTLGNBQWMsS0FDUCxHQUFHLE9BQU8sS0FBSztJQUMzQyxtQkFBbUIsS0FBSztHQUMxQjtFQUNGLE9BQU8sSUFBSSxZQUFZLEtBQUssR0FDMUIsWUFBWSxPQUFPLFlBQVksU0FBUztDQUU1QyxDQUFDO0NBQ0QsT0FBTztBQUNUO0FBR0EsU0FBUyxpQkFBaUIsTUFBTSxRQUFRO0NBQ3RDLE1BQU0sY0FBYyxRQUFRLElBQUk7Q0FDaEMsTUFBTSxRQUFRO0VBQ1osT0FBTyxjQUFjLElBQWdCO0VBRXJDLFFBQVEsU0FBUyxPQUFPLFNBQVMsZ0JBQWdCO0VBRWpELFdBQVc7RUFFWCxZQUFZO0VBR1osV0FBVyxLQUFLO0VBRWhCLFNBQVM7RUFFVCxPQUFPO0VBRVAsUUFBUTtFQUdSLE9BQU87RUFFUCxTQUFTO0VBQ1QsV0FBVztFQUVYLFlBQVksS0FBSztDQUNuQjtDQUNBLElBQUksU0FBUztDQUNiLElBQUksUUFBUTtDQUNaLElBQUksYUFBYTtFQUNmLFNBQVMsQ0FBQyxLQUFLO0VBQ2YsUUFBUTtDQUNWO0NBQ0EsTUFBTSxFQUFFLFFBQVEsVUFBVSxNQUFNLFVBQVUsUUFBUSxLQUFLO0NBQ3ZELE1BQU0sU0FBUztDQUNmLE1BQU0sVUFBVTtDQUNoQixPQUFPLENBQUMsT0FBTyxLQUFLO0FBQ3RCO0FBQ0EsSUFBSSxjQUFjO0NBQ2hCLElBQUksT0FBTyxNQUFNO0VBQ2YsSUFBSSxTQUFTLGFBQ1gsT0FBTztFQUNULElBQUksY0FBYyxNQUFNLE9BQU87RUFDL0IsTUFBTSx3QkFBd0IsTUFBTSxVQUFVLEtBQWlCLE9BQU8sU0FBUztFQUMvRSxJQUFJLHVCQUNFO09BQUEsYUFBYSx1QkFBdUIsSUFBSSxHQUMxQyxPQUFPLFlBQVksd0JBQXdCLE9BQU8sSUFBSTtFQUFBO0VBRzFELE1BQU0sU0FBUyxPQUFPLEtBQUs7RUFDM0IsSUFBSSxDQUFDLElBQUksUUFBUSxNQUFNLE1BQU0sS0FBSyxHQUNoQyxPQUFPLGtCQUFrQixPQUFPLFFBQVEsSUFBSTtFQUU5QyxNQUFNLFFBQVEsT0FBTztFQUNyQixJQUFJLE1BQU0sY0FBYyxDQUFDLFlBQVksS0FBSyxHQUN4QyxPQUFPO0VBRVQsSUFBSSx5QkFBeUIsTUFBTSxtQkFBbUIsYUFBYSxzQkFDakUsTUFBTSxlQUNSLEtBQUssYUFBYSxJQUFJLEdBQ3BCLE9BQU87RUFFVCxJQUFJLFVBQVUsS0FBSyxNQUFNLE9BQU8sSUFBSSxLQUFLLG1CQUFtQixPQUFPLE1BQU0sS0FBSyxHQUFHO0dBQy9FLFlBQVksS0FBSztHQUNqQixNQUFNLFdBQVcsTUFBTSxVQUFVLElBQWdCLENBQUMsT0FBTztHQUN6RCxNQUFNLGFBQWEsWUFBWSxNQUFNLFFBQVEsT0FBTyxPQUFPLFFBQVE7R0FDbkUsT0FBTyxNQUFNLE1BQU0sWUFBWTtFQUNqQztFQUNBLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxNQUFNO0VBQ2YsT0FBTyxRQUFRLE9BQU8sS0FBSztDQUM3QjtDQUNBLFFBQVEsT0FBTztFQUNiLE9BQU8sUUFBUSxRQUFRLE9BQU8sS0FBSyxDQUFDO0NBQ3RDO0NBQ0EsSUFBSSxPQUFPLE1BQU0sT0FBTztFQUN0QixNQUFNLE9BQU8sdUJBQXVCLE9BQU8sS0FBSyxHQUFHLElBQUk7RUFDdkQsSUFBSSxNQUFNLEtBQUs7R0FDYixLQUFLLElBQUksS0FBSyxNQUFNLFFBQVEsS0FBSztHQUNqQyxPQUFPO0VBQ1Q7RUFDQSxJQUFJLENBQUMsTUFBTSxXQUFXO0dBQ3BCLE1BQU0sV0FBVyxLQUFLLE9BQU8sS0FBSyxHQUFHLElBQUk7R0FDekMsTUFBTSxlQUFlLFdBQVc7R0FDaEMsSUFBSSxnQkFBZ0IsYUFBYSxVQUFVLE9BQU87SUFDaEQsTUFBTSxNQUFNLFFBQVE7SUFDcEIsTUFBTSxVQUFVLElBQUksTUFBTSxLQUFLO0lBQy9CLE9BQU87R0FDVDtHQUNBLElBQUksR0FBRyxPQUFPLFFBQVEsTUFBTSxVQUFVLEtBQUssS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxJQUNoRixPQUFPO0dBQ1QsWUFBWSxLQUFLO0dBQ2pCLFlBQVksS0FBSztFQUNuQjtFQUNBLElBQUksTUFBTSxNQUFNLFVBQVUsVUFDekIsVUFBVSxLQUFLLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUssTUFDdkQsT0FBTyxNQUFNLEtBQUssS0FBSyxPQUFPLE1BQU0sTUFBTSxNQUFNLEtBQUssR0FDbkQsT0FBTztFQUNULE1BQU0sTUFBTSxRQUFRO0VBQ3BCLE1BQU0sVUFBVSxJQUFJLE1BQU0sSUFBSTtFQUM5QixxQkFBcUIsT0FBTyxNQUFNLEtBQUs7RUFDdkMsT0FBTztDQUNUO0NBQ0EsZUFBZSxPQUFPLE1BQU07RUFDMUIsWUFBWSxLQUFLO0VBQ2pCLElBQUksS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssS0FBSyxRQUFRLE1BQU0sT0FBTztHQUM3RCxNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUs7R0FDL0IsWUFBWSxLQUFLO0VBQ25CLE9BQ0UsTUFBTSxVQUFVLE9BQU8sSUFBSTtFQUU3QixJQUFJLE1BQU0sT0FDUixPQUFPLE1BQU0sTUFBTTtFQUVyQixPQUFPO0NBQ1Q7Q0FHQSx5QkFBeUIsT0FBTyxNQUFNO0VBQ3BDLE1BQU0sUUFBUSxPQUFPLEtBQUs7RUFDMUIsTUFBTSxPQUFPLFFBQVEseUJBQXlCLE9BQU8sSUFBSTtFQUN6RCxJQUFJLENBQUMsTUFDSCxPQUFPO0VBQ1QsT0FBTztJQUNKLFdBQVc7SUFDWCxlQUFlLE1BQU0sVUFBVSxLQUFpQixTQUFTO0lBQ3pELGFBQWEsS0FBSztJQUNsQixRQUFRLE1BQU07RUFDakI7Q0FDRjtDQUNBLGlCQUFpQjtFQUNmLElBQUksRUFBRTtDQUNSO0NBQ0EsZUFBZSxPQUFPO0VBQ3BCLE9BQU8sZUFBZSxNQUFNLEtBQUs7Q0FDbkM7Q0FDQSxpQkFBaUI7RUFDZixJQUFJLEVBQUU7Q0FDUjtBQUNGO0FBQ0EsSUFBSSxhQUFhLENBQUM7QUFDbEIsS0FBSyxJQUFJLE9BQU8sYUFBYTtDQUMzQixJQUFJLEtBQUssWUFBWTtDQUNyQixXQUFXLE9BQU8sV0FBVztFQUMzQixNQUFNLE9BQU87RUFDYixLQUFLLEtBQUssS0FBSyxFQUFFLENBQUM7RUFDbEIsT0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJO0NBQzVCO0FBQ0Y7QUFDQSxXQUFXLGlCQUFpQixTQUFTLE9BQU8sTUFBTTtDQUNoRCxJQUE2QyxNQUFNLFNBQVMsSUFBSSxDQUFDLEdBQy9ELElBQUksRUFBRTtDQUNSLE9BQU8sV0FBVyxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU0sS0FBSyxDQUFDO0FBQ3REO0FBQ0EsV0FBVyxNQUFNLFNBQVMsT0FBTyxNQUFNLE9BQU87Q0FDNUMsSUFBNkMsU0FBUyxZQUFZLE1BQU0sU0FBUyxJQUFJLENBQUMsR0FDcEYsSUFBSSxFQUFFO0NBQ1IsT0FBTyxZQUFZLElBQUksS0FBSyxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sTUFBTSxFQUFFO0FBQ25FO0FBQ0EsU0FBUyxLQUFLLE9BQU8sTUFBTTtDQUN6QixNQUFNLFFBQVEsTUFBTTtDQUVwQixRQURlLFFBQVEsT0FBTyxLQUFLLElBQUksTUFBQSxDQUN6QjtBQUNoQjtBQUNBLFNBQVMsbUJBQW1CLE9BQU8sTUFBTSxPQUFPO0NBQzlDLElBQUksTUFBTSxVQUFVLEtBQWlCLENBQUMsTUFBTSx5QkFBeUIsTUFBTSxXQUFXLElBQUksSUFBSSxLQUFLLENBQUMsWUFBWSxLQUFLLEtBQUssTUFBTSxjQUM5SCxPQUFPO0NBRVQsT0FBTyxNQUFNLFVBQVUsSUFBSSxLQUFLO0FBQ2xDO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxRQUFRLE1BQU07Q0FDOUMsTUFBTSxPQUFPLHVCQUF1QixRQUFRLElBQUk7Q0FDaEQsT0FBTyxPQUFPLFNBQVMsT0FBTyxLQUFLLFNBR2pDLEtBQUssS0FBSyxLQUFLLE1BQU0sTUFBTSxJQUN6QixLQUFLO0FBQ1g7QUFDQSxTQUFTLHVCQUF1QixRQUFRLE1BQU07Q0FDNUMsSUFBSSxFQUFFLFFBQVEsU0FDWixPQUFPLEtBQUs7Q0FDZCxJQUFJLFFBQVEsZUFBZSxNQUFNO0NBQ2pDLE9BQU8sT0FBTztFQUNaLE1BQU0sT0FBTyxPQUFPLHlCQUF5QixPQUFPLElBQUk7RUFDeEQsSUFBSSxNQUNGLE9BQU87RUFDVCxRQUFRLGVBQWUsS0FBSztDQUM5QjtBQUVGO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsSUFBSSxDQUFDLE1BQU0sV0FBVztFQUNwQixNQUFNLFlBQVk7RUFDbEIsSUFBSSxNQUFNLFNBQ1IsWUFBWSxNQUFNLE9BQU87Q0FFN0I7QUFDRjtBQUNBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLElBQUksQ0FBQyxNQUFNLE9BQU87RUFDaEIsTUFBTSw0QkFBNEIsSUFBSSxJQUFJO0VBQzFDLE1BQU0sUUFBUSxZQUNaLE1BQU0sT0FDTixNQUFNLE9BQU8sT0FBTyxxQkFDdEI7Q0FDRjtBQUNGO0FBR0EsSUFBSSxTQUFTLE1BQU07Q0FDakIsWUFBWSxRQUFRO0VBQ2xCLEtBQUssY0FBYztFQUNuQixLQUFLLHdCQUF3QjtFQUM3QixLQUFLLHNCQUFzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFvQjNCLEtBQUssV0FBVyxNQUFNLFFBQVEsa0JBQWtCO0dBQzlDLElBQUksV0FBVyxJQUFJLEtBQUssQ0FBQyxXQUFXLE1BQU0sR0FBRztJQUMzQyxNQUFNLGNBQWM7SUFDcEIsU0FBUztJQUNULE1BQU0sT0FBTztJQUNiLE9BQU8sU0FBUyxlQUFlLFFBQVEsYUFBYSxHQUFHLE1BQU07S0FDM0QsT0FBTyxLQUFLLFFBQVEsUUFBUSxVQUFVLE9BQU8sS0FBSyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUM7SUFDekU7R0FDRjtHQUNBLElBQUksQ0FBQyxXQUFXLE1BQU0sR0FDcEIsSUFBSSxDQUFDO0dBQ1AsSUFBSSxrQkFBa0IsS0FBSyxLQUFLLENBQUMsV0FBVyxhQUFhLEdBQ3ZELElBQUksQ0FBQztHQUNQLElBQUk7R0FDSixJQUFJLFlBQVksSUFBSSxHQUFHO0lBQ3JCLE1BQU0sUUFBUSxXQUFXLElBQUk7SUFDN0IsTUFBTSxRQUFRLFlBQVksT0FBTyxNQUFNLEtBQUssQ0FBQztJQUM3QyxJQUFJLFdBQVc7SUFDZixJQUFJO0tBQ0YsU0FBUyxPQUFPLEtBQUs7S0FDckIsV0FBVztJQUNiLFVBQVU7S0FDUixJQUFJLFVBQ0YsWUFBWSxLQUFLO1VBRWpCLFdBQVcsS0FBSztJQUNwQjtJQUNBLGtCQUFrQixPQUFPLGFBQWE7SUFDdEMsT0FBTyxjQUFjLFFBQVEsS0FBSztHQUNwQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxJQUFJLEdBQUc7SUFDdEMsU0FBUyxPQUFPLElBQUk7SUFDcEIsSUFBSSxXQUFXLEtBQUssR0FDbEIsU0FBUztJQUNYLElBQUksV0FBVyxTQUNiLFNBQVMsS0FBSztJQUNoQixJQUFJLEtBQUssYUFDUCxPQUFPLFFBQVEsSUFBSTtJQUNyQixJQUFJLGVBQWU7S0FDakIsTUFBTSxJQUFJLENBQUM7S0FDWCxNQUFNLEtBQUssQ0FBQztLQUNaLFVBQVUsYUFBYSxDQUFDLENBQUMsNEJBQTRCLE1BQU0sUUFBUTtNQUNqRSxVQUFVO01BQ1YsaUJBQWlCO0tBQ25CLENBQUM7S0FDRCxjQUFjLEdBQUcsRUFBRTtJQUNyQjtJQUNBLE9BQU87R0FDVCxPQUNFLElBQUksR0FBRyxJQUFJO0VBQ2Y7RUFDQSxLQUFLLHNCQUFzQixNQUFNLFdBQVc7R0FDMUMsSUFBSSxXQUFXLElBQUksR0FDakIsUUFBUSxPQUFPLEdBQUcsU0FBUyxLQUFLLG1CQUFtQixRQUFRLFVBQVUsS0FBSyxPQUFPLEdBQUcsSUFBSSxDQUFDO0dBRTNGLElBQUksU0FBUztHQUtiLE9BQU87SUFKUSxLQUFLLFFBQVEsTUFBTSxTQUFTLEdBQUcsT0FBTztLQUNuRCxVQUFVO0tBQ1YsaUJBQWlCO0lBQ25CLENBQ2E7SUFBRztJQUFTO0dBQWM7RUFDekM7RUFDQSxJQUFJQyxZQUFVLFFBQVEsVUFBVSxHQUM5QixLQUFLLGNBQWMsT0FBTyxVQUFVO0VBQ3RDLElBQUlBLFlBQVUsUUFBUSxvQkFBb0IsR0FDeEMsS0FBSyx3QkFBd0IsT0FBTyxvQkFBb0I7RUFDMUQsSUFBSUEsWUFBVSxRQUFRLGtCQUFrQixHQUN0QyxLQUFLLHNCQUFzQixPQUFPLGtCQUFrQjtDQUN4RDtDQUNBLFlBQVksTUFBTTtFQUNoQixJQUFJLENBQUMsWUFBWSxJQUFJLEdBQ25CLElBQUksQ0FBQztFQUNQLElBQUksUUFBUSxJQUFJLEdBQ2QsT0FBTyxRQUFRLElBQUk7RUFDckIsTUFBTSxRQUFRLFdBQVcsSUFBSTtFQUM3QixNQUFNLFFBQVEsWUFBWSxPQUFPLE1BQU0sS0FBSyxDQUFDO0VBQzdDLE1BQU0sWUFBWSxDQUFDLFlBQVk7RUFDL0IsV0FBVyxLQUFLO0VBQ2hCLE9BQU87Q0FDVDtDQUNBLFlBQVksT0FBTyxlQUFlO0VBQ2hDLE1BQU0sUUFBUSxTQUFTLE1BQU07RUFDN0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLFdBQ25CLElBQUksQ0FBQztFQUNQLE1BQU0sRUFBRSxRQUFRLFVBQVU7RUFDMUIsa0JBQWtCLE9BQU8sYUFBYTtFQUN0QyxPQUFPLGNBQWMsS0FBSyxHQUFHLEtBQUs7Q0FDcEM7Ozs7OztDQU1BLGNBQWMsT0FBTztFQUNuQixLQUFLLGNBQWM7Q0FDckI7Ozs7OztDQU1BLHdCQUF3QixPQUFPO0VBQzdCLEtBQUssd0JBQXdCO0NBQy9COzs7Ozs7O0NBT0Esc0JBQXNCLE9BQU87RUFDM0IsS0FBSyxzQkFBc0I7Q0FDN0I7Q0FDQSwyQkFBMkI7RUFDekIsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxhQUFhLE1BQU0sU0FBUztFQUMxQixJQUFJO0VBQ0osS0FBSyxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3hDLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLE9BQU8sV0FBVztJQUNyRCxPQUFPLE1BQU07SUFDYjtHQUNGO0VBQ0Y7RUFDQSxJQUFJLElBQUksSUFDTixVQUFVLFFBQVEsTUFBTSxJQUFJLENBQUM7RUFFL0IsTUFBTSxtQkFBbUIsVUFBVSxhQUFhLENBQUMsQ0FBQztFQUNsRCxJQUFJLFFBQVEsSUFBSSxHQUNkLE9BQU8saUJBQWlCLE1BQU0sT0FBTztFQUV2QyxPQUFPLEtBQUssUUFDVixPQUNDLFVBQVUsaUJBQWlCLE9BQU8sT0FBTyxDQUM1QztDQUNGO0FBQ0Y7QUFDQSxTQUFTLFlBQVksV0FBVyxPQUFPLFFBQVEsS0FBSztDQUNsRCxNQUFNLENBQUMsT0FBTyxTQUFTLE1BQU0sS0FBSyxJQUFJLFVBQVUsWUFBWSxDQUFDLENBQUMsVUFBVSxPQUFPLE1BQU0sSUFBSSxNQUFNLEtBQUssSUFBSSxVQUFVLFlBQVksQ0FBQyxDQUFDLFVBQVUsT0FBTyxNQUFNLElBQUksaUJBQWlCLE9BQU8sTUFBTTtDQUV6TCxDQURjLFFBQVEsVUFBVSxnQkFBZ0IsRUFBQSxDQUMxQyxRQUFRLEtBQUssS0FBSztDQUN4QixNQUFNLGFBQWEsUUFBUSxjQUFjLENBQUM7Q0FDMUMsTUFBTSxPQUFPO0NBQ2IsSUFBSSxVQUFVLFFBQVEsS0FBSyxHQUN6QixrQ0FBa0MsUUFBUSxPQUFPLEdBQUc7TUFFcEQsTUFBTSxXQUFXLEtBQUssU0FBUyxpQkFBaUIsWUFBWTtFQUMxRCxXQUFXLGVBQWUsZUFBZSxLQUFLO0VBQzlDLE1BQU0sRUFBRSxpQkFBaUI7RUFDekIsSUFBSSxNQUFNLGFBQWEsY0FDckIsYUFBYSxpQkFBaUIsT0FBTyxDQUFDLEdBQUcsVUFBVTtDQUV2RCxDQUFDO0NBRUgsT0FBTztBQUNUO0FBR0EsU0FBUyxRQUFRLE9BQU87Q0FDdEIsSUFBSSxDQUFDLFFBQVEsS0FBSyxHQUNoQixJQUFJLElBQUksS0FBSztDQUNmLE9BQU8sWUFBWSxLQUFLO0FBQzFCO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsSUFBSSxDQUFDLFlBQVksS0FBSyxLQUFLLFNBQVMsS0FBSyxHQUN2QyxPQUFPO0NBQ1QsTUFBTSxRQUFRLE1BQU07Q0FDcEIsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUksT0FBTztFQUNULElBQUksQ0FBQyxNQUFNLFdBQ1QsT0FBTyxNQUFNO0VBQ2YsTUFBTSxhQUFhO0VBQ25CLE9BQU8sWUFBWSxPQUFPLE1BQU0sT0FBTyxPQUFPLHFCQUFxQjtFQUNuRSxTQUFTLE1BQU0sT0FBTyxPQUFPLHlCQUF5QjtDQUN4RCxPQUNFLE9BQU8sWUFBWSxPQUFPLElBQUk7Q0FFaEMsS0FDRSxPQUNDLEtBQUssZUFBZTtFQUNuQixJQUFJLE1BQU0sS0FBSyxZQUFZLFVBQVUsQ0FBQztDQUN4QyxHQUNBLE1BQ0Y7Q0FDQSxJQUFJLE9BQ0YsTUFBTSxhQUFhO0NBRXJCLE9BQU87QUFDVDtBQXNUc0IsV0FBVyxVQUNhO0FBMGQ5QyxJQUFJLFVBQVUsSUFERSxPQUNGLENBQUEsQ0FBTTs7O0FDNW5EcEIsU0FBUyxzQkFBc0IsZUFBZTtDQUM1QyxNQUFNLGNBQWMsRUFBRSxVQUFVLGdCQUFnQixVQUFVLFdBQVc7RUFDbkUsSUFBSSxPQUFPLFdBQVcsWUFDcEIsT0FBTyxPQUFPLFVBQVUsVUFBVSxhQUFhO0VBRWpELE9BQU8sS0FBSyxNQUFNO0NBQ3BCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBSSxRQUFRLHNCQUFzQjtBQUNsQyxJQUFJLG9CQUFvQjs7O0FDR3hCLElBQUksa0NBQWtDLEdBQUcsU0FBUztDQUNoRCxNQUFNLGtCQUFrQixzQkFBc0IsR0FBRyxJQUFJO0NBQ3JELE1BQU0sMkJBQTJCLE9BQU8sUUFBUSxHQUFHLFVBQVU7RUFDM0QsTUFBTSxXQUFXLGdCQUFnQixHQUFHLEtBQUs7RUFDekMsTUFBTSxtQkFBbUIsT0FBTyxHQUFHLFNBQVMsU0FBUyxRQUFRLEtBQUssSUFBSSxRQUFRLEtBQUssSUFBSSxPQUFPLEdBQUcsSUFBSTtFQUNyRyxPQUFPLE9BQU8saUJBQWlCLFFBQVE7RUFDdkMsT0FBTztDQUNULEdBQUcsRUFDRCxpQkFBaUIseUJBQ25CLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxJQUFJLDBCQUEwQywrQ0FBK0IsY0FBYztBQU0zRixJQUFJLHNCQUFzQixPQUFPLFdBQVcsZUFBZSxPQUFPLHVDQUF1QyxPQUFPLHVDQUF1QyxXQUFXO0NBQ2hLLElBQUksVUFBVSxXQUFXLEdBQUcsT0FBTyxLQUFLO0NBQ3hDLElBQUksT0FBTyxVQUFVLE9BQU8sVUFBVSxPQUFPO0NBQzdDLE9BQU8sUUFBUSxNQUFNLE1BQU0sU0FBUztBQUN0QztBQUN1QixPQUFPLFdBQVcsZUFBZSxPQUFPLGdDQUErQixPQUFPO0FBVXJHLElBQUksb0JBQW9CLE1BQU07Q0FDNUIsT0FBTyxLQUFLLE9BQU8sRUFBRSxVQUFVO0FBQ2pDO0FBR0EsU0FBUyxhQUFhLE1BQU0sZUFBZTtDQUN6QyxTQUFTLGNBQWMsR0FBRyxNQUFNO0VBQzlCLElBQUksZUFBZTtHQUNqQixJQUFJLFdBQVcsY0FBYyxHQUFHLElBQUk7R0FDcEMsSUFBSSxDQUFDLFVBQ0gsTUFBTSxJQUFJLE1BQTBFLHdDQUF3QztHQUU5SCxPQUFPO0lBQ0w7SUFDQSxTQUFTLFNBQVM7SUFDbEIsR0FBRyxVQUFVLFlBQVksRUFDdkIsTUFBTSxTQUFTLEtBQ2pCO0lBQ0EsR0FBRyxXQUFXLFlBQVksRUFDeEIsT0FBTyxTQUFTLE1BQ2xCO0dBQ0Y7RUFDRjtFQUNBLE9BQU87R0FDTDtHQUNBLFNBQVMsS0FBSztFQUNoQjtDQUNGO0NBQ0EsY0FBYyxpQkFBaUIsR0FBRztDQUNsQyxjQUFjLE9BQU87Q0FDckIsY0FBYyxTQUFTLFdBQVcsU0FBUyxNQUFNLEtBQUssT0FBTyxTQUFTO0NBQ3RFLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDL0IsT0FBTyxPQUFPLFdBQVcsY0FBYyxVQUFVLFVBQ2pELGlCQUFpQixNQUFNO0FBQ3pCO0FBQ0EsU0FBUyxNQUFNLFFBQVE7Q0FDckIsT0FBTyxTQUFTLE1BQU0sS0FBSyxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsTUFBTSxVQUFVO0FBQ2pFO0FBQ0EsU0FBUyxXQUFXLEtBQUs7Q0FDdkIsT0FBTztFQUFDO0VBQVE7RUFBVztFQUFTO0NBQU0sQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQzdEO0FBR0EsU0FBUyxXQUFXLE1BQU07Q0FDeEIsTUFBTSxZQUFZLE9BQU8sR0FBRyxPQUFPLE1BQU0sR0FBRyxJQUFJLENBQUM7Q0FDakQsTUFBTSxhQUFhLFVBQVUsVUFBVSxTQUFTLE1BQU07Q0FDdEQsT0FBTyx5Q0FBeUMsUUFBUSxVQUFVO2tGQUNjLFdBQVcsOEJBQThCLFdBQVc7QUFDdEk7QUFDQSxTQUFTLHVDQUF1QyxVQUFVLENBQUMsR0FBRztDQUk1RCxNQUFNLEVBQ0osaUJBQWlCLG1CQUFtQixvQkFDbEM7Q0FDSixjQUFjLFVBQVUsV0FBVztFQUNqQyxJQUFJLGlCQUFpQixNQUFNLEdBQ3pCLFFBQVEsS0FBSyxXQUFXLE9BQU8sSUFBSSxDQUFDO0VBRXRDLE9BQU8sS0FBSyxNQUFNO0NBQ3BCO0FBQ0Y7QUFHQSxTQUFTLG9CQUFvQixVQUFVLFFBQVE7Q0FDN0MsSUFBSSxVQUFVO0NBQ2QsT0FBTztFQUNMLFlBQVksSUFBSTtHQUNkLE1BQU0sVUFBVSxLQUFLLElBQUk7R0FDekIsSUFBSTtJQUNGLE9BQU8sR0FBRztHQUNaLFVBQVU7SUFFUixXQURpQixLQUFLLElBQ0osSUFBSTtHQUN4QjtFQUNGO0VBQ0EsaUJBQWlCO0dBQ2YsSUFBSSxVQUFVLFVBQ1osUUFBUSxLQUFLLEdBQUcsT0FBTyxRQUFRLFFBQVEsa0RBQWtELFNBQVM7OzRFQUU5QjtFQUV4RTtDQUNGO0FBQ0Y7QUFDQSxJQUFJLFFBQVEsTUFBTSxlQUFlLE1BQU07Q0FDckMsWUFBWSxHQUFHLE9BQU87RUFDcEIsTUFBTSxHQUFHLEtBQUs7RUFDZCxPQUFPLGVBQWUsTUFBTSxPQUFPLFNBQVM7Q0FDOUM7Q0FDQSxZQUFZLE9BQU8sV0FBVztFQUM1QixPQUFPO0NBQ1Q7Q0FDQSxPQUFPLEdBQUcsS0FBSztFQUNiLE9BQU8sTUFBTSxPQUFPLE1BQU0sTUFBTSxHQUFHO0NBQ3JDO0NBQ0EsUUFBUSxHQUFHLEtBQUs7RUFDZCxJQUFJLElBQUksV0FBVyxLQUFLLE1BQU0sUUFBUSxJQUFJLEVBQUUsR0FDMUMsT0FBTyxJQUFJLE9BQU8sR0FBRyxJQUFJLEVBQUUsQ0FBQyxPQUFPLElBQUksQ0FBQztFQUUxQyxPQUFPLElBQUksT0FBTyxHQUFHLElBQUksT0FBTyxJQUFJLENBQUM7Q0FDdkM7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLEtBQUs7Q0FDNUIsT0FBTyxZQUFZLEdBQUcsSUFBSSxRQUFRLFdBQVcsQ0FDN0MsQ0FBQyxJQUFJO0FBQ1A7QUFDQSxTQUFTLG9CQUFvQixLQUFLLEtBQUssU0FBUztDQUM5QyxJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsT0FBTyxJQUFJLElBQUksR0FBRztDQUNwQyxPQUFPLElBQUksSUFBSSxLQUFLLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUc7QUFDM0M7QUFHQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2pDLE9BQU8sT0FBTyxVQUFVLFlBQVksU0FBUyxRQUFRLE9BQU8sU0FBUyxLQUFLO0FBQzVFO0FBQ0EsU0FBUyxrQkFBa0IsYUFBYSxjQUFjLEtBQUs7Q0FDekQsTUFBTSxvQkFBb0IsZ0JBQWdCLGFBQWEsY0FBYyxHQUFHO0NBQ3hFLE9BQU8sRUFDTCxrQkFBa0I7RUFDaEIsT0FBTyxnQkFBZ0IsYUFBYSxjQUFjLG1CQUFtQixHQUFHO0NBQzFFLEVBQ0Y7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLGFBQWEsZUFBZSxDQUFDLEdBQUcsS0FBSyxPQUFPLElBQUksaUNBQWlDLElBQUksSUFBSSxHQUFHO0NBQ25ILE1BQU0sVUFBVSxFQUNkLE9BQU8sSUFDVDtDQUNBLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDLGVBQWUsSUFBSSxHQUFHLEdBQUc7RUFDakQsZUFBZSxJQUFJLEdBQUc7RUFDdEIsUUFBUSxXQUFXLENBQUM7RUFDcEIsTUFBTSxrQkFBa0IsYUFBYSxTQUFTO0VBQzlDLEtBQUssTUFBTSxPQUFPLEtBQUs7R0FDckIsTUFBTSxhQUFhLE9BQU8sT0FBTyxNQUFNLE1BQU07R0FDN0MsSUFBSSxpQkFDaUI7UUFBQSxhQUFhLE1BQU0sWUFBWTtLQUNoRCxJQUFJLG1CQUFtQixRQUNyQixPQUFPLFFBQVEsS0FBSyxVQUFVO0tBRWhDLE9BQU8sZUFBZTtJQUN4QixDQUNhLEdBQ1g7R0FBQTtHQUdKLFFBQVEsU0FBUyxPQUFPLGdCQUFnQixhQUFhLGNBQWMsSUFBSSxNQUFNLFVBQVU7RUFDekY7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLGFBQWEsZUFBZSxDQUFDLEdBQUcsaUJBQWlCLEtBQUssZ0JBQWdCLE9BQU8sT0FBTyxJQUFJO0NBQy9HLE1BQU0sVUFBVSxrQkFBa0IsZ0JBQWdCLFFBQVEsS0FBSztDQUMvRCxNQUFNLFVBQVUsWUFBWTtDQUM1QixJQUFJLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxPQUFPLE1BQU0sR0FBRyxHQUNoRCxPQUFPO0VBQ0wsWUFBWTtFQUNaO0NBQ0Y7Q0FFRixJQUFJLFlBQVksT0FBTyxLQUFLLFlBQVksR0FBRyxHQUN6QyxPQUFPLEVBQ0wsWUFBWSxNQUNkO0NBRUYsTUFBTSxlQUFlLENBQUM7Q0FDdEIsS0FBSyxJQUFJLE9BQU8sZ0JBQWdCLFVBQzlCLGFBQWEsT0FBTztDQUV0QixLQUFLLElBQUksT0FBTyxLQUNkLGFBQWEsT0FBTztDQUV0QixNQUFNLGtCQUFrQixhQUFhLFNBQVM7Q0FDOUMsS0FBSyxJQUFJLE9BQU8sY0FBYztFQUM1QixNQUFNLGFBQWEsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUM3QyxJQUFJLGlCQUNpQjtPQUFBLGFBQWEsTUFBTSxZQUFZO0lBQ2hELElBQUksbUJBQW1CLFFBQ3JCLE9BQU8sUUFBUSxLQUFLLFVBQVU7SUFFaEMsT0FBTyxlQUFlO0dBQ3hCLENBQ2EsR0FDWDtFQUFBO0VBR0osTUFBTSxTQUFTLGdCQUFnQixhQUFhLGNBQWMsZ0JBQWdCLFNBQVMsTUFBTSxJQUFJLE1BQU0sU0FBUyxVQUFVO0VBQ3RILElBQUksT0FBTyxZQUNULE9BQU87Q0FFWDtDQUNBLE9BQU8sRUFDTCxZQUFZLE1BQ2Q7QUFDRjtBQUNBLFNBQVMsd0NBQXdDLFVBQVUsQ0FBQyxHQUFHO0NBR3REO0VBQ0wsSUFBSSxhQUFhLFNBQVMsS0FBSyxZQUFZLFFBQVEsVUFBVTtHQUMzRCxPQUFPLEtBQUssVUFBVSxLQUFLLGNBQWMsWUFBWSxRQUFRLEdBQUcsTUFBTTtFQUN4RSxHQUFHLGdCQUFnQixTQUFTLFlBQVksVUFBVTtHQUNoRCxJQUFJLFFBQVEsQ0FBQyxHQUFHLE9BQU8sQ0FBQztHQUN4QixJQUFJLENBQUMsVUFBVSxXQUFXLFNBQVMsR0FBRyxPQUFPO0lBQzNDLElBQUksTUFBTSxPQUFPLE9BQU8sT0FBTztJQUMvQixPQUFPLGlCQUFpQixLQUFLLE1BQU0sR0FBRyxNQUFNLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSTtHQUMxRTtHQUNBLE9BQU8sU0FBUyxLQUFLLE9BQU87SUFDMUIsSUFBSSxNQUFNLFNBQVMsR0FBRztLQUNwQixJQUFJLFVBQVUsTUFBTSxRQUFRLElBQUk7S0FDaEMsQ0FBQyxVQUFVLE1BQU0sT0FBTyxVQUFVLENBQUMsSUFBSSxNQUFNLEtBQUssSUFBSTtLQUN0RCxDQUFDLFVBQVUsS0FBSyxPQUFPLFNBQVMsVUFBVSxHQUFHLElBQUksS0FBSyxLQUFLLEdBQUc7S0FDOUQsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUcsUUFBUSxTQUFTLEtBQUssTUFBTSxLQUFLLEtBQUs7SUFDbkUsT0FBTyxNQUFNLEtBQUssS0FBSztJQUN2QixPQUFPLGNBQWMsT0FBTyxRQUFRLFdBQVcsS0FBSyxNQUFNLEtBQUssS0FBSztHQUN0RTtFQUNGO0VBRUEsSUFBSSxFQUNGLGNBQWMsb0JBQ2QsY0FDQSxZQUFZLE9BQ1Y7RUFDSixNQUFNLFFBQVEsa0JBQWtCLEtBQUssTUFBTSxhQUFhLFlBQVk7RUFDcEUsUUFBUSxFQUNOLGVBQ0k7R0FDSixJQUFJLFFBQVEsU0FBUztHQUNyQixJQUFJLFVBQVUsTUFBTSxLQUFLO0dBQ3pCLElBQUk7R0FDSixRQUFRLFVBQVUsV0FBVztJQUMzQixNQUFNLGVBQWUsb0JBQW9CLFdBQVcsbUNBQW1DO0lBQ3ZGLGFBQWEsa0JBQWtCO0tBQzdCLFFBQVEsU0FBUztLQUNqQixTQUFTLFFBQVEsZ0JBQWdCO0tBQ2pDLFVBQVUsTUFBTSxLQUFLO0tBQ3JCLElBQUksT0FBTyxZQUNULE1BQU0sSUFBSSxNQUEyRSxrRUFBa0UsT0FBTyxRQUFRLEdBQUcsMEdBQTBHO0lBRXZSLENBQUM7SUFDRCxNQUFNLG1CQUFtQixLQUFLLE1BQU07SUFDcEMsYUFBYSxrQkFBa0I7S0FDN0IsUUFBUSxTQUFTO0tBQ2pCLFNBQVMsUUFBUSxnQkFBZ0I7S0FDakMsVUFBVSxNQUFNLEtBQUs7S0FDckIsSUFBSSxPQUFPLFlBQ1QsTUFBTSxJQUFJLE1BQTJFLGlFQUFpRSxPQUFPLFFBQVEsR0FBRyxzREFBc0QsV0FBVyxNQUFNLEVBQUUscUVBQXFFO0lBRTFULENBQUM7SUFDRCxhQUFhLGVBQWU7SUFDNUIsT0FBTztHQUNUO0VBQ0Y7Q0FDRjtBQUNGO0FBR0EsU0FBUyxRQUFRLEtBQUs7Q0FDcEIsTUFBTSxPQUFPLE9BQU87Q0FDcEIsT0FBTyxPQUFPLFFBQVEsU0FBUyxZQUFZLFNBQVMsYUFBYSxTQUFTLFlBQVksTUFBTSxRQUFRLEdBQUcsS0FBSyxjQUFjLEdBQUc7QUFDL0g7QUFDQSxTQUFTLHlCQUF5QixPQUFPLE9BQU8sSUFBSSxpQkFBaUIsU0FBUyxZQUFZLGVBQWUsQ0FBQyxHQUFHLE9BQU87Q0FDbEgsSUFBSTtDQUNKLElBQUksQ0FBQyxlQUFlLEtBQUssR0FDdkIsT0FBTztFQUNMLFNBQVMsUUFBUTtFQUNqQjtDQUNGO0NBRUYsSUFBSSxPQUFPLFVBQVUsWUFBWSxVQUFVLE1BQ3pDLE9BQU87Q0FFVCxJQUFJLE9BQU8sSUFBSSxLQUFLLEdBQUcsT0FBTztDQUM5QixNQUFNLFVBQVUsY0FBYyxPQUFPLFdBQVcsS0FBSyxJQUFJLE9BQU8sUUFBUSxLQUFLO0NBQzdFLE1BQU0sa0JBQWtCLGFBQWEsU0FBUztDQUM5QyxLQUFLLE1BQU0sQ0FBQyxLQUFLLGdCQUFnQixTQUFTO0VBQ3hDLE1BQU0sYUFBYSxPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzdDLElBQUksaUJBQ2lCO09BQUEsYUFBYSxNQUFNLFlBQVk7SUFDaEQsSUFBSSxtQkFBbUIsUUFDckIsT0FBTyxRQUFRLEtBQUssVUFBVTtJQUVoQyxPQUFPLGVBQWU7R0FDeEIsQ0FDYSxHQUNYO0VBQUE7RUFHSixJQUFJLENBQUMsZUFBZSxXQUFXLEdBQzdCLE9BQU87R0FDTCxTQUFTO0dBQ1QsT0FBTztFQUNUO0VBRUYsSUFBSSxPQUFPLGdCQUFnQixVQUFVO0dBQ25DLDBCQUEwQix5QkFBeUIsYUFBYSxZQUFZLGdCQUFnQixZQUFZLGNBQWMsS0FBSztHQUMzSCxJQUFJLHlCQUNGLE9BQU87RUFFWDtDQUNGO0NBQ0EsSUFBSSxTQUFTLGVBQWUsS0FBSyxHQUFHLE1BQU0sSUFBSSxLQUFLO0NBQ25ELE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLElBQUksQ0FBQyxPQUFPLFNBQVMsS0FBSyxHQUFHLE9BQU87Q0FDcEMsS0FBSyxNQUFNLGVBQWUsT0FBTyxPQUFPLEtBQUssR0FBRztFQUM5QyxJQUFJLE9BQU8sZ0JBQWdCLFlBQVksZ0JBQWdCLE1BQU07RUFDN0QsSUFBSSxDQUFDLGVBQWUsV0FBVyxHQUFHLE9BQU87Q0FDM0M7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLDJDQUEyQyxVQUFVLENBQUMsR0FBRztDQUd6RDtFQUNMLE1BQU0sRUFDSixpQkFBaUIsU0FDakIsWUFDQSxpQkFBaUIsQ0FBQyxHQUNsQixxQkFBcUIsQ0FBQyxZQUFZLG9CQUFvQixHQUN0RCxlQUFlLENBQUMsR0FDaEIsWUFBWSxJQUNaLGNBQWMsT0FDZCxnQkFBZ0IsT0FDaEIsZUFBZSxVQUNiO0VBQ0osTUFBTSxRQUFRLENBQUMsZ0JBQWdCLDBCQUEwQixJQUFJLFFBQVEsSUFBSSxLQUFLO0VBQzlFLFFBQVEsY0FBYyxVQUFVLFdBQVc7R0FDekMsSUFBSSxDQUFDLFNBQVMsTUFBTSxHQUNsQixPQUFPLEtBQUssTUFBTTtHQUVwQixNQUFNLFNBQVMsS0FBSyxNQUFNO0dBQzFCLE1BQU0sZUFBZSxvQkFBb0IsV0FBVyxzQ0FBc0M7R0FDMUYsSUFBSSxDQUFDLGlCQUFpQixFQUFFLGVBQWUsVUFBVSxlQUFlLFFBQVEsT0FBTyxJQUFJLE1BQU0sS0FDdkYsYUFBYSxrQkFBa0I7SUFDN0IsTUFBTSxrQ0FBa0MseUJBQXlCLFFBQVEsSUFBSSxnQkFBZ0IsWUFBWSxvQkFBb0IsS0FBSztJQUNsSSxJQUFJLGlDQUFpQztLQUNuQyxNQUFNLEVBQ0osU0FDQSxVQUNFO0tBQ0osUUFBUSxNQUFNLHNFQUFzRSxRQUFRLGFBQWEsT0FBTyw0REFBNEQsUUFBUSx5SUFBeUksNkhBQTZIO0lBQzViO0dBQ0YsQ0FBQztHQUVILElBQUksQ0FBQyxhQUFhO0lBQ2hCLGFBQWEsa0JBQWtCO0tBRTdCLE1BQU0saUNBQWlDLHlCQUR6QixTQUFTLFNBQzZDLEdBQUcsSUFBSSxnQkFBZ0IsWUFBWSxjQUFjLEtBQUs7S0FDMUgsSUFBSSxnQ0FBZ0M7TUFDbEMsTUFBTSxFQUNKLFNBQ0EsVUFDRTtNQUNKLFFBQVEsTUFBTSxzRUFBc0UsUUFBUSxhQUFhLE9BQU87MkRBQ2pFLE9BQU8sS0FBSzsrSEFDd0Q7S0FDckg7SUFDRixDQUFDO0lBQ0QsYUFBYSxlQUFlO0dBQzlCO0dBQ0EsT0FBTztFQUNUO0NBQ0Y7QUFDRjtBQUdBLFNBQVMsVUFBVSxHQUFHO0NBQ3BCLE9BQU8sT0FBTyxNQUFNO0FBQ3RCO0FBQ0EsSUFBSSxrQ0FBa0MsU0FBUyxxQkFBcUIsU0FBUztDQUMzRSxNQUFNLEVBQ0osT0FBQSxVQUFRLE1BQ1IsaUJBQWlCLE1BQ2pCLG9CQUFvQixNQUNwQixxQkFBcUIsU0FDbkIsV0FBVyxDQUFDO0NBQ2hCLElBQUksa0JBQWtCLElBQUksTUFBTTtDQUNoQyxJQUFJQyxTQUFPO0VBQ1QsSUFBSSxVQUFVQSxPQUFLLEdBQ2pCLGdCQUFnQixLQUFLQyxLQUFlO09BRXBDLGdCQUFnQixLQUFLLGtCQUFrQkQsUUFBTSxhQUFhLENBQUM7Q0FFL0Q7Q0FFRSxJQUFJLGdCQUFnQjtFQUNsQixJQUFJLG1CQUFtQixDQUFDO0VBQ3hCLElBQUksQ0FBQyxVQUFVLGNBQWMsR0FDM0IsbUJBQW1CO0VBRXJCLGdCQUFnQixRQUFRLHdDQUF3QyxnQkFBZ0IsQ0FBQztDQUNuRjtDQUNBLElBQUksbUJBQW1CO0VBQ3JCLElBQUksc0JBQXNCLENBQUM7RUFDM0IsSUFBSSxDQUFDLFVBQVUsaUJBQWlCLEdBQzlCLHNCQUFzQjtFQUV4QixnQkFBZ0IsS0FBSywyQ0FBMkMsbUJBQW1CLENBQUM7Q0FDdEY7Q0FDQSxJQUFJLG9CQUFvQjtFQUN0QixJQUFJLHVCQUF1QixDQUFDO0VBQzVCLElBQUksQ0FBQyxVQUFVLGtCQUFrQixHQUMvQix1QkFBdUI7RUFFekIsZ0JBQWdCLFFBQVEsdUNBQXVDLG9CQUFvQixDQUFDO0NBQ3RGO0NBRUYsT0FBTztBQUNUO0FBR0EsSUFBSSxtQkFBbUI7QUFDdkIsSUFBSSw0QkFBNEIsYUFBYTtDQUMzQztDQUNBLE1BQU0sR0FDSCxtQkFBbUIsS0FDdEI7QUFDRjtBQUNBLElBQUksd0JBQXdCLFlBQVk7Q0FDdEMsUUFBUSxXQUFXO0VBQ2pCLFdBQVcsUUFBUSxPQUFPO0NBQzVCO0FBQ0Y7QUFDQSxJQUFJLDhCQUE4QixLQUFLLFlBQVk7Q0FDakQsUUFBUSxXQUFXO0VBQ2pCLElBQUksU0FBUztFQUNiLE1BQU0saUJBQWlCO0dBQ3JCLElBQUksUUFBUTtHQUNaLFNBQVM7R0FDVCxxQkFBcUIsS0FBSztHQUMxQixhQUFhLE9BQU87R0FDcEIsT0FBTztFQUNUO0VBQ0EsTUFBTSxRQUFRLElBQUksUUFBUTtFQUMxQixNQUFNLFVBQVUsV0FBVyxVQUFVLE9BQU87Q0FDOUM7QUFDRjtBQUNBLElBQUkscUJBQXFCLFVBQVUsRUFDakMsTUFBTSxNQUNSLE9BQU8sVUFBVSxHQUFHLFNBQVM7Q0FDM0IsTUFBTSxRQUFRLEtBQUssR0FBRyxJQUFJO0NBQzFCLElBQUksWUFBWTtDQUNoQixJQUFJLDBCQUEwQjtDQUM5QixJQUFJLHFCQUFxQjtDQUN6QixNQUFNLDRCQUE0QixJQUFJLElBQUk7Q0FDMUMsTUFBTSxnQkFBZ0IsUUFBUSxTQUFTLFNBQVMsaUJBQWlCLFFBQVEsU0FBUyxRQUVoRixPQUFPLFdBQVcsZUFBZSxPQUFPLHdCQUF3QiwyQkFBMkIsT0FBTyx1QkFBdUIsR0FBRyxJQUFJLHFCQUFxQixFQUFFLElBQ3JKLFFBQVEsU0FBUyxhQUFhLFFBQVEsb0JBQW9CLHFCQUFxQixRQUFRLE9BQU87Q0FDbEcsTUFBTSx3QkFBd0I7RUFDNUIscUJBQXFCO0VBQ3JCLElBQUkseUJBQXlCO0dBQzNCLDBCQUEwQjtHQUMxQixVQUFVLFNBQVMsTUFBTSxFQUFFLENBQUM7RUFDOUI7Q0FDRjtDQUNBLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxPQUFPO0VBRzlCLFVBQVUsV0FBVztHQUNuQixNQUFNLHdCQUF3QixhQUFhLFVBQVU7R0FDckQsTUFBTSxjQUFjLE1BQU0sVUFBVSxlQUFlO0dBQ25ELFVBQVUsSUFBSSxTQUFTO0dBQ3ZCLGFBQWE7SUFDWCxZQUFZO0lBQ1osVUFBVSxPQUFPLFNBQVM7R0FDNUI7RUFDRjtFQUdBLFNBQVMsUUFBUTtHQUNmLElBQUk7SUFDRixZQUFZLENBQUMsUUFBUSxPQUFPO0lBQzVCLDBCQUEwQixDQUFDO0lBQzNCLElBQUkseUJBQ0U7U0FBQSxDQUFDLG9CQUFvQjtNQUN2QixxQkFBcUI7TUFDckIsY0FBYyxlQUFlO0tBQy9COztJQUVGLE9BQU8sTUFBTSxTQUFTLE1BQU07R0FDOUIsVUFBVTtJQUNSLFlBQVk7R0FDZDtFQUNGO0NBQ0YsQ0FBQztBQUNIO0FBR0EsSUFBSSw0QkFBNEIsdUJBQXVCLFNBQVMsb0JBQW9CLFNBQVM7Q0FDM0YsTUFBTSxFQUNKLFlBQVksU0FDVixXQUFXLENBQUM7Q0FDaEIsSUFBSSxnQkFBZ0IsSUFBSSxNQUFNLGtCQUFrQjtDQUNoRCxJQUFJLFdBQ0YsY0FBYyxLQUFLLGtCQUFrQixPQUFPLGNBQWMsV0FBVyxZQUFZLEtBQUssQ0FBQyxDQUFDO0NBRTFGLE9BQU87QUFDVDtBQUdBLFNBQVMsZUFBZSxTQUFTO0NBQy9CLE1BQU0sdUJBQXVCLDBCQUEwQjtDQUN2RCxNQUFNLEVBQ0osVUFBVSxLQUFLLEdBQ2YsWUFDQSxXQUFXLE1BQ1gsMkJBQTJCLE1BQzNCLGlCQUFpQixLQUFLLEdBQ3RCLFlBQVksS0FBSyxNQUNmLFdBQVcsQ0FBQztDQUNoQixJQUFJO0NBQ0osSUFBSSxPQUFPLFlBQVksWUFDckIsY0FBYztNQUNULElBQUksY0FBYyxPQUFPLEdBQzlCLGNBQWMsZ0JBQWdCLE9BQU87TUFFckMsTUFBTSxJQUFJLE1BQTBFLDBIQUEwSDtDQUVoTixJQUE2QyxjQUFjLE9BQU8sZUFBZSxZQUMvRSxNQUFNLElBQUksTUFBMEUsdUNBQXVDO0NBRTdILElBQUk7Q0FDSixJQUFJLE9BQU8sZUFBZSxZQUFZO0VBQ3BDLGtCQUFrQixXQUFXLG9CQUFvQjtFQUNqRCxJQUE2QyxDQUFDLE1BQU0sUUFBUSxlQUFlLEdBQ3pFLE1BQU0sSUFBSSxNQUEwRSxtRkFBbUY7Q0FFM0ssT0FDRSxrQkFBa0IscUJBQXFCO0NBRXpDLElBQTZDLGdCQUFnQixNQUFNLFNBQVMsT0FBTyxTQUFTLFVBQVUsR0FDcEcsTUFBTSxJQUFJLE1BQTBFLCtEQUErRDtDQUVySixJQUE2QywwQkFBMEI7RUFDckUsSUFBSSx1Q0FBdUMsSUFBSSxJQUFJO0VBQ25ELGdCQUFnQixTQUFTLGdCQUFnQjtHQUN2QyxJQUFJLHFCQUFxQixJQUFJLFdBQVcsR0FDdEMsTUFBTSxJQUFJLE1BQTJFLG1IQUFtSDtHQUUxTSxxQkFBcUIsSUFBSSxXQUFXO0VBQ3RDLENBQUM7Q0FDSDtDQUNBLElBQUksZUFBZTtDQUNuQixJQUFJLFVBQ0YsZUFBZSxvQkFBb0I7RUFFakMsT0FBTztFQUNQLEdBQUcsT0FBTyxhQUFhLFlBQVk7Q0FDckMsQ0FBQztDQUVILE1BQU0scUJBQXFCLGdCQUFnQixHQUFHLGVBQWU7Q0FDN0QsTUFBTSxzQkFBc0IseUJBQXlCLGtCQUFrQjtDQUN2RSxJQUE2QyxhQUFhLE9BQU8sY0FBYyxZQUM3RSxNQUFNLElBQUksTUFBMEUsc0NBQXNDO0NBRTVILElBQUksaUJBQWlCLE9BQU8sY0FBYyxhQUFhLFVBQVUsbUJBQW1CLElBQUksb0JBQW9CO0NBQzVHLElBQTZDLENBQUMsTUFBTSxRQUFRLGNBQWMsR0FDeEUsTUFBTSxJQUFJLE1BQTBFLDJDQUEyQztDQUVqSSxJQUE2QyxlQUFlLE1BQU0sU0FBUyxPQUFPLFNBQVMsVUFBVSxHQUNuRyxNQUFNLElBQUksTUFBMEUsNkRBQTZEO0NBRW5KLElBQTZDLGdCQUFnQixVQUFVLENBQUMsZUFBZSxTQUFTLGtCQUFrQixHQUNoSCxRQUFRLE1BQU0sa0lBQWtJO0NBRWxKLE1BQU0sbUJBQW1CLGFBQWEsR0FBRyxjQUFjO0NBQ3ZELE9BQU8sWUFBWSxhQUFhLGdCQUFnQixnQkFBZ0I7QUFDbEU7QUFHQSxTQUFTLDhCQUE4QixpQkFBaUI7Q0FDdEQsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxpQkFBaUIsQ0FBQztDQUN4QixJQUFJO0NBQ0osTUFBTSxVQUFVO0VBQ2QsUUFBUSxxQkFBcUIsU0FBUztHQUVsQyxJQUFJLGVBQWUsU0FBUyxHQUMxQixNQUFNLElBQUksTUFBMkUsNkVBQTZFO0dBRXBLLElBQUksb0JBQ0YsTUFBTSxJQUFJLE1BQTJFLGlGQUFpRjtHQUcxSyxNQUFNLE9BQU8sT0FBTyx3QkFBd0IsV0FBVyxzQkFBc0Isb0JBQW9CO0dBQ2pHLElBQUksQ0FBQyxNQUNILE1BQU0sSUFBSSxNQUEyRSw4REFBOEQ7R0FFckosSUFBSSxRQUFRLFlBQ1YsTUFBTSxJQUFJLE1BQTJFLG9GQUFvRixLQUFLLEVBQUU7R0FFbEwsV0FBVyxRQUFRO0dBQ25CLE9BQU87RUFDVDtFQUNBLGNBQWMsWUFBWSxVQUFVO0dBRWhDLElBQUksb0JBQ0YsTUFBTSxJQUFJLE1BQTJFLHVGQUF1RjtHQUdoTCxJQUFJLFNBQVMsU0FBUyxXQUFXLFdBQVcsUUFBUSxRQUFRLFNBQVM7R0FDckUsSUFBSSxTQUFTLFVBQVUsV0FBVyxXQUFXLFNBQVMsUUFBUSxTQUFTO0dBQ3ZFLElBQUksU0FBUyxXQUFXLFdBQVcsV0FBVyxVQUFVLFFBQVEsU0FBUztHQUN6RSxJQUFJLFNBQVMsU0FBUyxlQUFlLEtBQUs7SUFDeEMsU0FBUyxXQUFXO0lBQ3BCLFNBQVMsU0FBUztHQUNwQixDQUFDO0dBQ0QsT0FBTztFQUNUO0VBQ0EsV0FBVyxTQUFTLFNBQVM7R0FFekIsSUFBSSxvQkFDRixNQUFNLElBQUksTUFBMkUsb0ZBQW9GO0dBRzdLLGVBQWUsS0FBSztJQUNsQjtJQUNBO0dBQ0YsQ0FBQztHQUNELE9BQU87RUFDVDtFQUNBLGVBQWUsU0FBUztHQUVwQixJQUFJLG9CQUNGLE1BQU0sSUFBSSxNQUEyRSxrREFBa0Q7R0FHM0kscUJBQXFCO0dBQ3JCLE9BQU87RUFDVDtDQUNGO0NBQ0EsZ0JBQWdCLE9BQU87Q0FDdkIsT0FBTztFQUFDO0VBQVk7RUFBZ0I7Q0FBa0I7QUFDeEQ7QUFHQSxTQUFTLGdCQUFnQixHQUFHO0NBQzFCLE9BQU8sT0FBTyxNQUFNO0FBQ3RCO0FBQ0EsU0FBUyxjQUFjLGNBQWMsc0JBQXNCO0NBRXZELElBQUksT0FBTyx5QkFBeUIsVUFDbEMsTUFBTSxJQUFJLE1BQTBFLDhKQUE4SjtDQUd0UCxJQUFJLENBQUMsWUFBWSxxQkFBcUIsMkJBQTJCLDhCQUE4QixvQkFBb0I7Q0FDbkgsSUFBSTtDQUNKLElBQUksZ0JBQWdCLFlBQVksR0FDOUIsd0JBQXdCLGdCQUFnQixhQUFhLENBQUM7TUFDakQ7RUFDTCxNQUFNLHFCQUFxQixnQkFBZ0IsWUFBWTtFQUN2RCx3QkFBd0I7Q0FDMUI7Q0FDQSxTQUFTLFFBQVEsUUFBUSxnQkFBZ0IsR0FBRyxRQUFRO0VBQ2xELElBQUksZUFBZSxDQUFDLFdBQVcsT0FBTyxPQUFPLEdBQUcsb0JBQW9CLFFBQVEsRUFDMUUsY0FDSSxRQUFRLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUMxQixTQUFTLGVBQ0wsUUFBUSxDQUFDO0VBQ2YsSUFBSSxhQUFhLFFBQVEsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxHQUMvQyxlQUFlLENBQUMsdUJBQXVCO0VBRXpDLE9BQU8sYUFBYSxRQUFRLGVBQWUsZ0JBQWdCO0dBQ3pELElBQUksYUFBYTtJQUNmLElBQUksUUFBUSxhQUFhLEdBQUc7S0FFMUIsTUFBTSxTQUFTLFlBQVlFLGVBQU8sTUFBTTtLQUN4QyxJQUFJLFdBQVcsS0FBSyxHQUNsQixPQUFPO0tBRVQsT0FBTztJQUNULE9BQU8sSUFBSSxDQUFDLFlBQVksYUFBYSxHQUFHO0tBQ3RDLE1BQU0sU0FBUyxZQUFZLGVBQWUsTUFBTTtLQUNoRCxJQUFJLFdBQVcsS0FBSyxHQUFHO01BQ3JCLElBQUksa0JBQWtCLE1BQ3BCLE9BQU87TUFFVCxNQUFNLE1BQU0sbUVBQW1FO0tBQ2pGO0tBQ0EsT0FBTztJQUNULE9BQ0UsT0FBTyxRQUFRLGdCQUFnQixVQUFVO0tBQ3ZDLE9BQU8sWUFBWSxPQUFPLE1BQU07SUFDbEMsQ0FBQztHQUVMO0dBQ0EsT0FBTztFQUNULEdBQUcsS0FBSztDQUNWO0NBQ0EsUUFBUSxrQkFBa0I7Q0FDMUIsT0FBTztBQUNUO0FBR0EsSUFBSSxXQUFXLFNBQVMsV0FBVztDQUNqQyxJQUFJLGlCQUFpQixPQUFPLEdBQzFCLE9BQU8sUUFBUSxNQUFNLE1BQU07TUFFM0IsT0FBTyxRQUFRLE1BQU07QUFFekI7QUFDQSxTQUFTLFFBQVEsR0FBRyxVQUFVO0NBQzVCLFFBQVEsV0FBVztFQUNqQixPQUFPLFNBQVMsTUFBTSxZQUFZLFFBQVEsU0FBUyxNQUFNLENBQUM7Q0FDNUQ7QUFDRjtBQUNBLFNBQVMsUUFBUSxHQUFHLFVBQVU7Q0FDNUIsUUFBUSxXQUFXO0VBQ2pCLE9BQU8sU0FBUyxPQUFPLFlBQVksUUFBUSxTQUFTLE1BQU0sQ0FBQztDQUM3RDtBQUNGO0FBQ0EsU0FBUywyQkFBMkIsUUFBUSxhQUFhO0NBQ3ZELElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxNQUFNLE9BQU87Q0FDcEMsTUFBTSxvQkFBb0IsT0FBTyxPQUFPLEtBQUssY0FBYztDQUMzRCxNQUFNLHdCQUF3QixZQUFZLFFBQVEsT0FBTyxLQUFLLGFBQWEsSUFBSTtDQUMvRSxPQUFPLHFCQUFxQjtBQUM5QjtBQUNBLFNBQVMsa0JBQWtCLEdBQUc7Q0FDNUIsT0FBTyxPQUFPLEVBQUUsT0FBTyxjQUFjLGFBQWEsRUFBRSxNQUFNLGVBQWUsRUFBRSxNQUFNLGNBQWMsRUFBRTtBQUNuRztBQUNBLFNBQVMsVUFBVSxHQUFHLGFBQWE7Q0FDakMsSUFBSSxZQUFZLFdBQVcsR0FDekIsUUFBUSxXQUFXLDJCQUEyQixRQUFRLENBQUMsU0FBUyxDQUFDO0NBRW5FLElBQUksQ0FBQyxrQkFBa0IsV0FBVyxHQUNoQyxPQUFPLFVBQVUsQ0FBQyxDQUFDLFlBQVksRUFBRTtDQUVuQyxPQUFPLFFBQVEsR0FBRyxZQUFZLEtBQUssZUFBZSxXQUFXLE9BQU8sQ0FBQztBQUN2RTtBQUNBLFNBQVMsV0FBVyxHQUFHLGFBQWE7Q0FDbEMsSUFBSSxZQUFZLFdBQVcsR0FDekIsUUFBUSxXQUFXLDJCQUEyQixRQUFRLENBQUMsVUFBVSxDQUFDO0NBRXBFLElBQUksQ0FBQyxrQkFBa0IsV0FBVyxHQUNoQyxPQUFPLFdBQVcsQ0FBQyxDQUFDLFlBQVksRUFBRTtDQUVwQyxPQUFPLFFBQVEsR0FBRyxZQUFZLEtBQUssZUFBZSxXQUFXLFFBQVEsQ0FBQztBQUN4RTtBQUNBLFNBQVMsb0JBQW9CLEdBQUcsYUFBYTtDQUMzQyxNQUFNLFdBQVcsV0FBVztFQUMxQixPQUFPLFVBQVUsT0FBTyxRQUFRLE9BQU8sS0FBSztDQUM5QztDQUNBLElBQUksWUFBWSxXQUFXLEdBQ3pCLE9BQU8sUUFBUSxXQUFXLEdBQUcsV0FBVyxHQUFHLE9BQU87Q0FFcEQsSUFBSSxDQUFDLGtCQUFrQixXQUFXLEdBQ2hDLE9BQU8sb0JBQW9CLENBQUMsQ0FBQyxZQUFZLEVBQUU7Q0FFN0MsT0FBTyxRQUFRLFdBQVcsR0FBRyxXQUFXLEdBQUcsT0FBTztBQUNwRDtBQUNBLFNBQVMsWUFBWSxHQUFHLGFBQWE7Q0FDbkMsSUFBSSxZQUFZLFdBQVcsR0FDekIsUUFBUSxXQUFXLDJCQUEyQixRQUFRLENBQUMsV0FBVyxDQUFDO0NBRXJFLElBQUksQ0FBQyxrQkFBa0IsV0FBVyxHQUNoQyxPQUFPLFlBQVksQ0FBQyxDQUFDLFlBQVksRUFBRTtDQUVyQyxPQUFPLFFBQVEsR0FBRyxZQUFZLEtBQUssZUFBZSxXQUFXLFNBQVMsQ0FBQztBQUN6RTtBQUNBLFNBQVMsbUJBQW1CLEdBQUcsYUFBYTtDQUMxQyxJQUFJLFlBQVksV0FBVyxHQUN6QixRQUFRLFdBQVcsMkJBQTJCLFFBQVE7RUFBQztFQUFXO0VBQWE7Q0FBVSxDQUFDO0NBRTVGLElBQUksQ0FBQyxrQkFBa0IsV0FBVyxHQUNoQyxPQUFPLG1CQUFtQixDQUFDLENBQUMsWUFBWSxFQUFFO0NBRTVDLE9BQU8sUUFBUSxHQUFHLFlBQVksU0FBUyxlQUFlO0VBQUMsV0FBVztFQUFTLFdBQVc7RUFBVSxXQUFXO0NBQVMsQ0FBQyxDQUFDO0FBQ3hIO0FBR0EsSUFBSSxjQUFjO0FBQ2xCLElBQUksVUFBVSxPQUFPLE9BQU87Q0FDMUIsSUFBSSxLQUFLO0NBQ1QsSUFBSSxJQUFJO0NBQ1IsT0FBTyxLQUNMLE1BQU0sWUFBWSxLQUFLLE9BQU8sSUFBSSxLQUFLO0NBRXpDLE9BQU87QUFDVDtBQUdBLElBQUksbUJBQW1CO0NBQUM7Q0FBUTtDQUFXO0NBQVM7QUFBTTtBQUMxRCxJQUFJLGtCQUFrQixNQUFNO0NBQzFCLFlBQVksU0FBUyxNQUFNO0VBQ3pCLEtBQUssVUFBVTtFQUNmLEtBQUssT0FBTztDQUNkO0NBQ0E7Q0FDQTtDQUtBO0FBQ0Y7QUFDQSxJQUFJLGtCQUFrQixNQUFNO0NBQzFCLFlBQVksU0FBUyxNQUFNO0VBQ3pCLEtBQUssVUFBVTtFQUNmLEtBQUssT0FBTztDQUNkO0NBQ0E7Q0FDQTtDQUtBO0FBQ0Y7QUFDQSxJQUFJLHNCQUFzQixVQUFVO0NBQ2xDLElBQUksT0FBTyxVQUFVLFlBQVksVUFBVSxNQUFNO0VBQy9DLE1BQU0sY0FBYyxDQUFDO0VBQ3JCLEtBQUssTUFBTSxZQUFZLGtCQUNyQixJQUFJLE9BQU8sTUFBTSxjQUFjLFVBQzdCLFlBQVksWUFBWSxNQUFNO0VBR2xDLE9BQU87Q0FDVDtDQUNBLE9BQU8sRUFDTCxTQUFTLE9BQU8sS0FBSyxFQUN2QjtBQUNGO0FBQ0EsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxtQkFBbUMsdUJBQU87Q0FDNUMsU0FBUyxrQkFBa0IsWUFBWSxnQkFBZ0IsU0FBUztFQUM5RCxNQUFNLFlBQVksYUFBYSxhQUFhLGVBQWUsU0FBUyxXQUFXLEtBQUssVUFBVTtHQUM1RjtHQUNBLE1BQU07SUFDSixHQUFHLFFBQVEsQ0FBQztJQUNaO0lBQ0E7SUFDQSxlQUFlO0dBQ2pCO0VBQ0YsRUFBRTtFQUNGLE1BQU0sVUFBVSxhQUFhLGFBQWEsYUFBYSxXQUFXLEtBQUssVUFBVTtHQUMvRSxTQUFTLEtBQUs7R0FDZCxNQUFNO0lBQ0osR0FBRyxRQUFRLENBQUM7SUFDWjtJQUNBO0lBQ0EsZUFBZTtHQUNqQjtFQUNGLEVBQUU7RUFDRixNQUFNLFdBQVcsYUFBYSxhQUFhLGNBQWMsT0FBTyxXQUFXLEtBQUssU0FBUyxVQUFVO0dBQ2pHO0dBQ0EsUUFBUSxXQUFXLFFBQVEsa0JBQWtCLG1CQUFBLENBQW9CLFNBQVMsVUFBVTtHQUNwRixNQUFNO0lBQ0osR0FBRyxRQUFRLENBQUM7SUFDWjtJQUNBO0lBQ0EsbUJBQW1CLENBQUMsQ0FBQztJQUNyQixlQUFlO0lBQ2YsU0FBUyxPQUFPLFNBQVM7SUFDekIsV0FBVyxPQUFPLFNBQVM7R0FDN0I7RUFDRixFQUFFO0VBQ0YsU0FBUyxjQUFjLEtBQUssRUFDMUIsV0FDRSxDQUFDLEdBQUc7R0FDTixRQUFRLFVBQVUsVUFBVSxVQUFVO0lBQ3BDLE1BQU0sWUFBWSxTQUFTLGNBQWMsUUFBUSxZQUFZLEdBQUcsSUFBSSxPQUFPO0lBQzNFLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0lBQzVDLElBQUk7SUFDSixJQUFJO0lBQ0osU0FBUyxNQUFNLFFBQVE7S0FDckIsY0FBYztLQUNkLGdCQUFnQixNQUFNO0lBQ3hCO0lBQ0EsSUFBSSxRQUFRO0tBQ1YsSUFBSSxPQUFPLFNBQ1QsTUFBTSxvQkFBb0I7VUFFMUIsT0FBTyxpQkFBaUIsZUFBZSxNQUFNLG9CQUFvQixHQUFHLEVBQ2xFLE1BQU0sS0FDUixDQUFDO0lBRUw7SUFDQSxNQUFNLFdBQVcsaUJBQWlCO0tBQ2hDLElBQUk7S0FDSixJQUFJO01BQ0YsSUFBSSxrQkFBa0IsU0FBUyxZQUFZLEtBQUs7T0FDOUM7T0FDQTtNQUNGLENBQUM7TUFDRCxJQUFJLFdBQVcsZUFBZSxHQUM1QixrQkFBa0IsTUFBTTtNQUUxQixJQUFJLG9CQUFvQixTQUFTLGdCQUFnQixPQUFPLFNBQ3RELE1BQU07T0FDSixNQUFNO09BQ04sU0FBUztNQUNYO01BRUYsTUFBTSxpQkFBaUIsSUFBSSxTQUFTLEdBQUcsV0FBVztPQUNoRCxxQkFBcUI7UUFDbkIsT0FBTztTQUNMLE1BQU07U0FDTixTQUFTLGVBQWU7UUFDMUIsQ0FBQztPQUNIO09BQ0EsZ0JBQWdCLE9BQU8saUJBQWlCLFNBQVMsY0FBYyxFQUM3RCxNQUFNLEtBQ1IsQ0FBQztNQUNILENBQUM7TUFDRCxTQUFTLFFBQVEsV0FBVyxLQUFLLFNBQVMsaUJBQWlCO09BQ3pEO09BQ0E7TUFDRixHQUFHO09BQ0Q7T0FDQTtNQUNGLENBQUMsQ0FBQyxDQUFDO01BQ0gsY0FBYyxNQUFNLFFBQVEsS0FBSyxDQUFDLGdCQUFnQixRQUFRLFFBQVEsZUFBZSxLQUFLO09BQ3BGO09BQ0E7T0FDQTtPQUNBO09BQ0EsUUFBUSxnQkFBZ0I7T0FDeEI7T0FDQSxtQkFBbUIsT0FBTyxTQUFTO1FBQ2pDLE9BQU8sSUFBSSxnQkFBZ0IsT0FBTyxJQUFJO09BQ3hDO09BQ0Esb0JBQW9CLE9BQU8sU0FBUztRQUNsQyxPQUFPLElBQUksZ0JBQWdCLE9BQU8sSUFBSTtPQUN4QztNQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXO09BQ25CLElBQUksa0JBQWtCLGlCQUNwQixNQUFNO09BRVIsSUFBSSxrQkFBa0IsaUJBQ3BCLE9BQU8sVUFBVSxPQUFPLFNBQVMsV0FBVyxLQUFLLE9BQU8sSUFBSTtPQUU5RCxPQUFPLFVBQVUsUUFBUSxXQUFXLEdBQUc7TUFDekMsQ0FBQyxDQUFDLENBQUM7S0FDTCxTQUFTLEtBQUs7TUFDWixjQUFjLGVBQWUsa0JBQWtCLFNBQVMsTUFBTSxXQUFXLEtBQUssSUFBSSxTQUFTLElBQUksSUFBSSxJQUFJLFNBQVMsS0FBSyxXQUFXLEdBQUc7S0FDckksVUFBVTtNQUNSLElBQUksY0FDRixnQkFBZ0IsT0FBTyxvQkFBb0IsU0FBUyxZQUFZO0tBRXBFO0tBRUEsSUFBSSxFQURpQixXQUFXLENBQUMsUUFBUSw4QkFBOEIsU0FBUyxNQUFNLFdBQVcsS0FBSyxZQUFZLEtBQUssWUFFckgsU0FBUyxXQUFXO0tBRXRCLE9BQU87SUFDVCxFQUFBLENBQUc7SUFDSCxPQUFPLE9BQU8sT0FBTyxTQUFTO0tBQzVCO0tBQ0E7S0FDQTtLQUNBLFNBQVM7TUFDUCxPQUFPLFFBQVEsS0FBSyxZQUFZO0tBQ2xDO0lBQ0YsQ0FBQztHQUNIO0VBQ0Y7RUFDQSxPQUFPLE9BQU8sT0FBTyxlQUFlO0dBQ2xDO0dBQ0E7R0FDQTtHQUNBLFNBQVMsUUFBUSxVQUFVLFNBQVM7R0FDcEM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxrQkFBa0Isa0JBQWtCO0NBQ3BDLE9BQU87QUFDVCxFQUFBLENBQUc7QUFDSCxTQUFTLGFBQWEsUUFBUTtDQUM1QixJQUFJLE9BQU8sUUFBUSxPQUFPLEtBQUssbUJBQzdCLE1BQU0sT0FBTztDQUVmLElBQUksT0FBTyxPQUNULE1BQU0sT0FBTztDQUVmLE9BQU8sT0FBTztBQUNoQjtBQUNBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLE9BQU8sVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLE9BQU8sTUFBTSxTQUFTO0FBQzlFO0FBR0EsSUFBSSxtQkFBbUMsdUJBQU8sSUFBSSw0QkFBNEI7QUFDOUUsSUFBSSxvQkFBb0IsR0FDckIsbUJBQW1CLGlCQUN0QjtBQUNBLElBQUksY0FBOEIsa0JBQUUsaUJBQWlCO0NBQ25ELGFBQWEsYUFBYTtDQUMxQixhQUFhLHdCQUF3QjtDQUNyQyxhQUFhLGdCQUFnQjtDQUM3QixPQUFPO0FBQ1QsRUFBQSxDQUFHLGVBQWUsQ0FBQyxDQUFDO0FBQ3BCLFNBQVMsUUFBUSxPQUFPLFdBQVc7Q0FDakMsT0FBTyxHQUFHLE1BQU0sR0FBRztBQUNyQjtBQUNBLFNBQVMsaUJBQWlCLEVBQ3hCLGFBQ0UsQ0FBQyxHQUFHO0NBQ04sTUFBTSxNQUFNLFVBQVUsYUFBYTtDQUNuQyxPQUFPLFNBQVMsYUFBYSxTQUFTO0VBQ3BDLE1BQU0sRUFDSixNQUNBLGNBQWMsU0FDWjtFQUNKLElBQUksQ0FBQyxNQUNILE1BQU0sSUFBSSxNQUEyRSw2Q0FBNkM7RUFFcEksSUFBSSxPQUFPLFlBQVksZUFBZSxNQUNoQztPQUFBLFFBQVEsaUJBQWlCLEtBQUssR0FDaEMsUUFBUSxNQUFNLDBHQUEwRztFQUFBO0VBRzVILE1BQU0sWUFBWSxPQUFPLFFBQVEsYUFBYSxhQUFhLFFBQVEsU0FBUyxxQkFBcUIsQ0FBQyxJQUFJLFFBQVEsYUFBYSxDQUFDO0VBQzVILE1BQU0sZUFBZSxPQUFPLEtBQUssUUFBUTtFQUN6QyxNQUFNLFVBQVU7R0FDZCx5QkFBeUIsQ0FBQztHQUMxQix5QkFBeUIsQ0FBQztHQUMxQixnQkFBZ0IsQ0FBQztHQUNqQixlQUFlLENBQUM7RUFDbEI7RUFDQSxNQUFNLGlCQUFpQjtHQUNyQixRQUFRLHFCQUFxQixVQUFVO0lBQ3JDLE1BQU0sT0FBTyxPQUFPLHdCQUF3QixXQUFXLHNCQUFzQixvQkFBb0I7SUFDakcsSUFBSSxDQUFDLE1BQ0gsTUFBTSxJQUFJLE1BQTJFLDhEQUE4RDtJQUVySixJQUFJLFFBQVEsUUFBUSx5QkFDbEIsTUFBTSxJQUFJLE1BQTJFLG9GQUFvRixJQUFJO0lBRS9LLFFBQVEsd0JBQXdCLFFBQVE7SUFDeEMsT0FBTztHQUNUO0dBQ0EsV0FBVyxTQUFTLFVBQVU7SUFDNUIsUUFBUSxjQUFjLEtBQUs7S0FDekI7S0FDQSxTQUFTO0lBQ1gsQ0FBQztJQUNELE9BQU87R0FDVDtHQUNBLGFBQWEsT0FBTyxlQUFlO0lBQ2pDLFFBQVEsZUFBZSxTQUFTO0lBQ2hDLE9BQU87R0FDVDtHQUNBLGtCQUFrQixPQUFPLFVBQVU7SUFDakMsUUFBUSx3QkFBd0IsU0FBUztJQUN6QyxPQUFPO0dBQ1Q7RUFDRjtFQUNBLGFBQWEsU0FBUyxnQkFBZ0I7R0FDcEMsTUFBTSxvQkFBb0IsU0FBUztHQUNuQyxNQUFNLGlCQUFpQjtJQUNyQjtJQUNBLE1BQU0sUUFBUSxNQUFNLFdBQVc7SUFDL0IsZ0JBQWdCLE9BQU8sUUFBUSxhQUFhO0dBQzlDO0dBQ0EsSUFBSSxtQ0FBbUMsaUJBQWlCLEdBQ3RELGlDQUFpQyxnQkFBZ0IsbUJBQW1CLGdCQUFnQixHQUFHO1FBRXZGLDhCQUE4QixnQkFBZ0IsbUJBQW1CLGNBQWM7RUFFbkYsQ0FBQztFQUNELFNBQVMsZUFBZTtHQUVwQixJQUFJLE9BQU8sUUFBUSxrQkFBa0IsVUFDbkMsTUFBTSxJQUFJLE1BQTJFLHdLQUF3SztHQUdqUSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLHFCQUFxQixLQUFLLEtBQUssT0FBTyxRQUFRLGtCQUFrQixhQUFhLDhCQUE4QixRQUFRLGFBQWEsSUFBSSxDQUFDLFFBQVEsYUFBYTtHQUMxTSxNQUFNLG9CQUFvQjtJQUN4QixHQUFHO0lBQ0gsR0FBRyxRQUFRO0dBQ2I7R0FDQSxPQUFPLGNBQWMsUUFBUSxlQUFlLFlBQVk7SUFDdEQsS0FBSyxJQUFJLE9BQU8sbUJBQ2QsUUFBUSxRQUFRLEtBQUssa0JBQWtCLElBQUk7SUFFN0MsS0FBSyxJQUFJLE1BQU0sUUFBUSxlQUNyQixRQUFRLFdBQVcsR0FBRyxTQUFTLEdBQUcsT0FBTztJQUUzQyxLQUFLLElBQUksS0FBSyxnQkFDWixRQUFRLFdBQVcsRUFBRSxTQUFTLEVBQUUsT0FBTztJQUV6QyxJQUFJLG9CQUNGLFFBQVEsZUFBZSxrQkFBa0I7R0FFN0MsQ0FBQztFQUNIO0VBQ0EsTUFBTSxjQUFjLFVBQVU7RUFDOUIsTUFBTSx3Q0FBd0MsSUFBSSxJQUFJO0VBQ3RELE1BQU0scUNBQXFDLElBQUksUUFBUTtFQUN2RCxJQUFJO0VBQ0osU0FBUyxRQUFRLE9BQU8sUUFBUTtHQUM5QixJQUFJLENBQUMsVUFBVSxXQUFXLGFBQWE7R0FDdkMsT0FBTyxTQUFTLE9BQU8sTUFBTTtFQUMvQjtFQUNBLFNBQVMsa0JBQWtCO0dBQ3pCLElBQUksQ0FBQyxVQUFVLFdBQVcsYUFBYTtHQUN2QyxPQUFPLFNBQVMsZ0JBQWdCO0VBQ2xDO0VBQ0EsU0FBUyxrQkFBa0IsY0FBYyxXQUFXLE9BQU87R0FDekQsU0FBUyxZQUFZLE9BQU87SUFDMUIsSUFBSSxhQUFhLE1BQU07SUFDdkIsSUFBSSxPQUFPLGVBQWUsYUFBYTtLQUNyQyxJQUFJLFVBQ0YsYUFBYSxvQkFBb0Isb0JBQW9CLGFBQWEsZUFBZTtVQUVqRixNQUFNLElBQUksTUFBMkUsZ0VBQWdFO0lBRXpKO0lBQ0EsT0FBTztHQUNUO0dBQ0EsU0FBUyxhQUFhLGNBQWMsWUFBWTtJQUU5QyxPQUFPLG9CQURlLG9CQUFvQix1QkFBdUIsZ0NBQWdDLElBQUksUUFBUSxDQUN0RSxHQUFHLG1CQUFtQjtLQUMzRCxNQUFNLE1BQU0sQ0FBQztLQUNiLEtBQUssTUFBTSxDQUFDLE9BQU8sYUFBYSxPQUFPLFFBQVEsUUFBUSxhQUFhLENBQUMsQ0FBQyxHQUNwRSxJQUFJLFNBQVMsYUFBYSxVQUFVLG1CQUFtQixvQkFBb0Isb0JBQW9CLGFBQWEsZUFBZSxHQUFHLFFBQVE7S0FFeEksT0FBTztJQUNULENBQUM7R0FDSDtHQUNBLE9BQU87SUFDTCxhQUFhO0lBQ2I7SUFDQSxJQUFJLFlBQVk7S0FDZCxPQUFPLGFBQWEsV0FBVztJQUNqQztJQUNBO0dBQ0Y7RUFDRjtFQUNBLE1BQU0sUUFBUTtHQUNaO0dBQ0E7R0FDQSxTQUFTLFFBQVE7R0FDakIsY0FBYyxRQUFRO0dBQ3RCO0dBQ0EsR0FBRyxrQkFBa0IsV0FBVztHQUNoQyxXQUFXLFlBQVksRUFDckIsYUFBYSxTQUNiLEdBQUcsV0FDRCxDQUFDLEdBQUc7SUFDTixNQUFNLGlCQUFpQixXQUFXO0lBQ2xDLFdBQVcsT0FBTztLQUNoQixhQUFhO0tBQ2I7SUFDRixHQUFHLE1BQU07SUFDVCxPQUFPO0tBQ0wsR0FBRztLQUNILEdBQUcsa0JBQWtCLGdCQUFnQixJQUFJO0lBQzNDO0dBQ0Y7RUFDRjtFQUNBLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxhQUFhLFVBQVUsYUFBYSxpQkFBaUIsVUFBVTtDQUN0RSxTQUFTLFFBQVEsV0FBVyxHQUFHLE1BQU07RUFDbkMsSUFBSSxhQUFhLFlBQVksU0FBUztFQUN0QyxJQUFJLE9BQU8sZUFBZSxhQUFhO0dBQ3JDLElBQUksVUFDRixhQUFhLGdCQUFnQjtRQUU3QixNQUFNLElBQUksTUFBMkUsZ0VBQWdFO0VBRXpKO0VBQ0EsT0FBTyxTQUFTLFlBQVksR0FBRyxJQUFJO0NBQ3JDO0NBQ0EsUUFBUSxZQUFZO0NBQ3BCLE9BQU87QUFDVDtBQUNBLElBQUksY0FBOEIsaUNBQWlCO0FBQ25ELFNBQVMsdUJBQXVCO0NBQzlCLFNBQVMsV0FBVyxnQkFBZ0IsUUFBUTtFQUMxQyxPQUFPO0dBQ0wsd0JBQXdCO0dBQ3hCO0dBQ0EsR0FBRztFQUNMO0NBQ0Y7Q0FDQSxXQUFXLGtCQUFrQjtDQUM3QixPQUFPO0VBQ0wsUUFBUSxhQUFhO0dBQ25CLE9BQU8sT0FBTyxPQUFPLEVBR25CLENBQUMsWUFBWSxNQUFNLEdBQUcsTUFBTTtJQUMxQixPQUFPLFlBQVksR0FBRyxJQUFJO0dBQzVCLEVBQ0YsRUFBRSxZQUFZLE9BQU8sRUFDbkIsd0JBQXdCLFVBQzFCLENBQUM7RUFDSDtFQUNBLGdCQUFnQixTQUFTLFNBQVM7R0FDaEMsT0FBTztJQUNMLHdCQUF3QjtJQUN4QjtJQUNBO0dBQ0Y7RUFDRjtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsOEJBQThCLEVBQ3JDLE1BQ0EsYUFDQSxrQkFDQyx5QkFBeUIsU0FBUztDQUNuQyxJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksYUFBYSx5QkFBeUI7RUFDeEMsSUFBSSxrQkFBa0IsQ0FBQyxtQ0FBbUMsdUJBQXVCLEdBQy9FLE1BQU0sSUFBSSxNQUEyRSwyR0FBMkc7RUFFbE0sY0FBYyx3QkFBd0I7RUFDdEMsa0JBQWtCLHdCQUF3QjtDQUM1QyxPQUNFLGNBQWM7Q0FFaEIsUUFBUSxRQUFRLE1BQU0sV0FBVyxDQUFDLENBQUMsa0JBQWtCLGFBQWEsV0FBVyxDQUFDLENBQUMsYUFBYSxhQUFhLGtCQUFrQixhQUFhLE1BQU0sZUFBZSxJQUFJLGFBQWEsSUFBSSxDQUFDO0FBQ3JMO0FBQ0EsU0FBUyxtQ0FBbUMsbUJBQW1CO0NBQzdELE9BQU8sa0JBQWtCLDJCQUEyQjtBQUN0RDtBQUNBLFNBQVMsbUNBQW1DLG1CQUFtQjtDQUM3RCxPQUFPLGtCQUFrQiwyQkFBMkI7QUFDdEQ7QUFDQSxTQUFTLGlDQUFpQyxFQUN4QyxNQUNBLGVBQ0MsbUJBQW1CLFNBQVMsS0FBSztDQUNsQyxJQUFJLENBQUMsS0FDSCxNQUFNLElBQUksTUFBMkUsd0xBQXdMO0NBRS9RLE1BQU0sRUFDSixnQkFDQSxXQUNBLFNBQ0EsVUFDQSxTQUNBLFlBQ0U7Q0FDSixNQUFNLFFBQVEsSUFBSSxNQUFNLGdCQUFnQixPQUFPO0NBQy9DLFFBQVEsYUFBYSxhQUFhLEtBQUs7Q0FDdkMsSUFBSSxXQUNGLFFBQVEsUUFBUSxNQUFNLFdBQVcsU0FBUztDQUU1QyxJQUFJLFNBQ0YsUUFBUSxRQUFRLE1BQU0sU0FBUyxPQUFPO0NBRXhDLElBQUksVUFDRixRQUFRLFFBQVEsTUFBTSxVQUFVLFFBQVE7Q0FFMUMsSUFBSSxTQUNGLFFBQVEsV0FBVyxNQUFNLFNBQVMsT0FBTztDQUUzQyxRQUFRLGtCQUFrQixhQUFhO0VBQ3JDLFdBQVcsYUFBYTtFQUN4QixTQUFTLFdBQVc7RUFDcEIsVUFBVSxZQUFZO0VBQ3RCLFNBQVMsV0FBVztDQUN0QixDQUFDO0FBQ0g7QUFDQSxTQUFTLE9BQU8sQ0FDaEI7QUFHQSxTQUFTLHdCQUF3QjtDQUMvQixPQUFPO0VBQ0wsS0FBSyxDQUFDO0VBQ04sVUFBVSxDQUFDO0NBQ2I7QUFDRjtBQUNBLFNBQVMsMEJBQTBCLGNBQWM7Q0FDL0MsU0FBUyxnQkFBZ0Isa0JBQWtCLENBQUMsR0FBRyxVQUFVO0VBQ3ZELE1BQU0sUUFBUSxPQUFPLE9BQU8sc0JBQXNCLEdBQUcsZUFBZTtFQUNwRSxPQUFPLFdBQVcsYUFBYSxPQUFPLE9BQU8sUUFBUSxJQUFJO0NBQzNEO0NBQ0EsT0FBTyxFQUNMLGdCQUNGO0FBQ0Y7QUFHQSxTQUFTLHlCQUF5QjtDQUNoQyxTQUFTLGFBQWEsYUFBYSxVQUFVLENBQUMsR0FBRztFQUMvQyxNQUFNLEVBQ0osZ0JBQWdCLGtCQUFrQiw0QkFDaEM7RUFDSixNQUFNLGFBQWEsVUFBVSxNQUFNO0VBQ25DLE1BQU0sa0JBQWtCLFVBQVUsTUFBTTtFQUN4QyxNQUFNLFlBQVksZ0JBQWdCLFdBQVcsaUJBQWlCLEtBQUssYUFBYSxJQUFJLEtBQUssT0FBTyxTQUFTLEdBQUcsQ0FBQztFQUM3RyxNQUFNLFlBQVksR0FBRyxPQUFPO0VBQzVCLE1BQU0sY0FBYyxVQUFVLE9BQU8sU0FBUztFQUM5QyxNQUFNLGNBQWMsZ0JBQWdCLFlBQVksUUFBUSxJQUFJLE1BQU07RUFDbEUsSUFBSSxDQUFDLGFBQ0gsT0FBTztHQUNMO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsWUFBWSxnQkFBZ0IsZ0JBQWdCLFVBQVUsVUFBVTtFQUNsRTtFQUVGLE1BQU0sMkJBQTJCLGdCQUFnQixhQUFhLGNBQWM7RUFDNUUsT0FBTztHQUNMLFdBQVcsZ0JBQWdCLGFBQWEsU0FBUztHQUNqRCxnQkFBZ0I7R0FDaEIsV0FBVyxnQkFBZ0IsYUFBYSxTQUFTO0dBQ2pELGFBQWEsZ0JBQWdCLGFBQWEsV0FBVztHQUNyRCxZQUFZLGdCQUFnQiwwQkFBMEIsVUFBVSxVQUFVO0VBQzVFO0NBQ0Y7Q0FDQSxPQUFPLEVBQ0wsYUFDRjtBQUNGO0FBR0EsSUFBSSxlQUFlO0FBQ25CLFNBQVMsa0NBQWtDLFNBQVM7Q0FDbEQsTUFBTSxXQUFXLHFCQUFxQixHQUFHLFVBQVUsUUFBUSxLQUFLLENBQUM7Q0FDakUsT0FBTyxTQUFTLFVBQVUsT0FBTztFQUMvQixPQUFPLFNBQVMsT0FBTyxLQUFLLENBQUM7Q0FDL0I7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLFNBQVM7Q0FDcEMsT0FBTyxTQUFTLFVBQVUsT0FBTyxLQUFLO0VBQ3BDLFNBQVMsd0JBQXdCLE1BQU07R0FDckMsT0FBTyxNQUFNLElBQUk7RUFDbkI7RUFDQSxNQUFNLGNBQWMsVUFBVTtHQUM1QixJQUFJLHdCQUF3QixHQUFHLEdBQzdCLFFBQVEsSUFBSSxTQUFTLEtBQUs7UUFFMUIsUUFBUSxLQUFLLEtBQUs7RUFFdEI7RUFDQSxJQUFJLGFBQWEsS0FBSyxHQUFHO0dBQ3ZCLFdBQVcsS0FBSztHQUNoQixPQUFPO0VBQ1Q7RUFDQSxPQUFPLFFBQVEsT0FBTyxVQUFVO0NBQ2xDO0FBQ0Y7QUFHQSxTQUFTLGNBQWMsUUFBUSxVQUFVO0NBQ3ZDLE1BQU0sTUFBTSxTQUFTLE1BQU07Q0FDM0IsSUFBNkMsUUFBUSxLQUFLLEdBQ3hELFFBQVEsS0FBSywwRUFBMEUsbUVBQW1FLCtCQUErQixRQUFRLGtDQUFrQyxTQUFTLFNBQVMsQ0FBQztDQUV4UCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG9CQUFvQixVQUFVO0NBQ3JDLElBQUksQ0FBQyxNQUFNLFFBQVEsUUFBUSxHQUN6QixXQUFXLE9BQU8sT0FBTyxRQUFRO0NBRW5DLE9BQU87QUFDVDtBQUNBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLE9BQU8sUUFBUSxLQUFLLElBQUksUUFBUSxLQUFLLElBQUk7QUFDM0M7QUFDQSxTQUFTLDBCQUEwQixhQUFhLFVBQVUsT0FBTztDQUMvRCxjQUFjLG9CQUFvQixXQUFXO0NBQzdDLE1BQU0sbUJBQW1CLFdBQVcsTUFBTSxHQUFHO0NBQzdDLE1BQU0sY0FBYyxJQUFJLElBQUksZ0JBQWdCO0NBQzVDLE1BQU0sUUFBUSxDQUFDO0NBQ2YsTUFBTSwyQkFBMkIsSUFBSSxJQUFJLENBQUMsQ0FBQztDQUMzQyxNQUFNLFVBQVUsQ0FBQztDQUNqQixLQUFLLE1BQU0sVUFBVSxhQUFhO0VBQ2hDLE1BQU0sS0FBSyxjQUFjLFFBQVEsUUFBUTtFQUN6QyxJQUFJLFlBQVksSUFBSSxFQUFFLEtBQUssU0FBUyxJQUFJLEVBQUUsR0FDeEMsUUFBUSxLQUFLO0dBQ1g7R0FDQSxTQUFTO0VBQ1gsQ0FBQztPQUNJO0dBQ0wsU0FBUyxJQUFJLEVBQUU7R0FDZixNQUFNLEtBQUssTUFBTTtFQUNuQjtDQUNGO0NBQ0EsT0FBTztFQUFDO0VBQU87RUFBUztDQUFnQjtBQUMxQztBQUdBLFNBQVMsMkJBQTJCLFVBQVU7Q0FDNUMsU0FBUyxjQUFjLFFBQVEsT0FBTztFQUNwQyxNQUFNLE1BQU0sY0FBYyxRQUFRLFFBQVE7RUFDMUMsSUFBSSxPQUFPLE1BQU0sVUFDZjtFQUVGLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDbEIsTUFBTSxTQUFTLE9BQU87Q0FDeEI7Q0FDQSxTQUFTLGVBQWUsYUFBYSxPQUFPO0VBQzFDLGNBQWMsb0JBQW9CLFdBQVc7RUFDN0MsS0FBSyxNQUFNLFVBQVUsYUFDbkIsY0FBYyxRQUFRLEtBQUs7Q0FFL0I7Q0FDQSxTQUFTLGNBQWMsUUFBUSxPQUFPO0VBQ3BDLE1BQU0sTUFBTSxjQUFjLFFBQVEsUUFBUTtFQUMxQyxJQUFJLEVBQUUsT0FBTyxNQUFNLFdBQ2pCLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFHcEIsTUFBTSxTQUFTLE9BQU87Q0FDeEI7Q0FDQSxTQUFTLGVBQWUsYUFBYSxPQUFPO0VBQzFDLGNBQWMsb0JBQW9CLFdBQVc7RUFDN0MsS0FBSyxNQUFNLFVBQVUsYUFDbkIsY0FBYyxRQUFRLEtBQUs7Q0FFL0I7Q0FDQSxTQUFTLGNBQWMsYUFBYSxPQUFPO0VBQ3pDLGNBQWMsb0JBQW9CLFdBQVc7RUFDN0MsTUFBTSxNQUFNLENBQUM7RUFDYixNQUFNLFdBQVcsQ0FBQztFQUNsQixlQUFlLGFBQWEsS0FBSztDQUNuQztDQUNBLFNBQVMsaUJBQWlCLEtBQUssT0FBTztFQUNwQyxPQUFPLGtCQUFrQixDQUFDLEdBQUcsR0FBRyxLQUFLO0NBQ3ZDO0NBQ0EsU0FBUyxrQkFBa0IsTUFBTSxPQUFPO0VBQ3RDLElBQUksWUFBWTtFQUNoQixLQUFLLFNBQVMsUUFBUTtHQUNwQixJQUFJLE9BQU8sTUFBTSxVQUFVO0lBQ3pCLE9BQU8sTUFBTSxTQUFTO0lBQ3RCLFlBQVk7R0FDZDtFQUNGLENBQUM7RUFDRCxJQUFJLFdBQ0YsTUFBTSxNQUFNLE1BQU0sSUFBSSxRQUFRLE9BQU8sTUFBTSxNQUFNLFFBQVE7Q0FFN0Q7Q0FDQSxTQUFTLGlCQUFpQixPQUFPO0VBQy9CLE9BQU8sT0FBTyxPQUFPO0dBQ25CLEtBQUssQ0FBQztHQUNOLFVBQVUsQ0FBQztFQUNiLENBQUM7Q0FDSDtDQUNBLFNBQVMsV0FBVyxNQUFNLFFBQVEsT0FBTztFQUN2QyxNQUFNLFlBQVksTUFBTSxTQUFTLE9BQU87RUFDeEMsSUFBSSxjQUFjLEtBQUssR0FDckIsT0FBTztFQUVULE1BQU0sVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLFdBQVcsT0FBTyxPQUFPO0VBQzNELE1BQU0sU0FBUyxjQUFjLFNBQVMsUUFBUTtFQUM5QyxNQUFNLFlBQVksV0FBVyxPQUFPO0VBQ3BDLElBQUksV0FBVztHQUNiLEtBQUssT0FBTyxNQUFNO0dBQ2xCLE9BQU8sTUFBTSxTQUFTLE9BQU87RUFDL0I7RUFFQSxNQUFNLFNBQVMsVUFBVTtFQUN6QixPQUFPO0NBQ1Q7Q0FDQSxTQUFTLGlCQUFpQixRQUFRLE9BQU87RUFDdkMsT0FBTyxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUMxQztDQUNBLFNBQVMsa0JBQWtCLFNBQVMsT0FBTztFQUN6QyxNQUFNLFVBQVUsQ0FBQztFQUNqQixNQUFNLG1CQUFtQixDQUFDO0VBQzFCLFFBQVEsU0FBUyxXQUFXO0dBQzFCLElBQUksT0FBTyxNQUFNLE1BQU0sVUFDckIsaUJBQWlCLE9BQU8sTUFBTTtJQUM1QixJQUFJLE9BQU87SUFHWCxTQUFTO0tBQ1AsR0FBRyxpQkFBaUIsT0FBTyxHQUFHLEVBQUU7S0FDaEMsR0FBRyxPQUFPO0lBQ1o7R0FDRjtFQUVKLENBQUM7RUFDRCxVQUFVLE9BQU8sT0FBTyxnQkFBZ0I7RUFFeEMsSUFEMEIsUUFBUSxTQUFTLEdBRXBCO09BQUEsUUFBUSxRQUFRLFdBQVcsV0FBVyxTQUFTLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBRTNGLE1BQU0sTUFBTSxPQUFPLE9BQU8sTUFBTSxRQUFRLENBQUMsQ0FBQyxLQUFLLE1BQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQztFQUFBO0NBR3JGO0NBQ0EsU0FBUyxpQkFBaUIsUUFBUSxPQUFPO0VBQ3ZDLE9BQU8sa0JBQWtCLENBQUMsTUFBTSxHQUFHLEtBQUs7Q0FDMUM7Q0FDQSxTQUFTLGtCQUFrQixhQUFhLE9BQU87RUFDN0MsTUFBTSxDQUFDLE9BQU8sV0FBVywwQkFBMEIsYUFBYSxVQUFVLEtBQUs7RUFDL0UsZUFBZSxPQUFPLEtBQUs7RUFDM0Isa0JBQWtCLFNBQVMsS0FBSztDQUNsQztDQUNBLE9BQU87RUFDTCxXQUFXLGtDQUFrQyxnQkFBZ0I7RUFDN0QsUUFBUSxvQkFBb0IsYUFBYTtFQUN6QyxTQUFTLG9CQUFvQixjQUFjO0VBQzNDLFFBQVEsb0JBQW9CLGFBQWE7RUFDekMsU0FBUyxvQkFBb0IsY0FBYztFQUMzQyxRQUFRLG9CQUFvQixhQUFhO0VBQ3pDLFdBQVcsb0JBQW9CLGdCQUFnQjtFQUMvQyxZQUFZLG9CQUFvQixpQkFBaUI7RUFDakQsV0FBVyxvQkFBb0IsZ0JBQWdCO0VBQy9DLFlBQVksb0JBQW9CLGlCQUFpQjtFQUNqRCxXQUFXLG9CQUFvQixnQkFBZ0I7RUFDL0MsWUFBWSxvQkFBb0IsaUJBQWlCO0NBQ25EO0FBQ0Y7QUFHQSxTQUFTLGdCQUFnQixhQUFhLE1BQU0sb0JBQW9CO0NBQzlELElBQUksV0FBVztDQUNmLElBQUksWUFBWSxZQUFZO0NBQzVCLE9BQU8sV0FBVyxXQUFXO0VBQzNCLElBQUksY0FBYyxXQUFXLGNBQWM7RUFDM0MsTUFBTSxjQUFjLFlBQVk7RUFFaEMsSUFEWSxtQkFBbUIsTUFBTSxXQUMvQixLQUFLLEdBQ1QsV0FBVyxjQUFjO09BRXpCLFlBQVk7Q0FFaEI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLE9BQU8sYUFBYSxNQUFNLG9CQUFvQjtDQUNyRCxNQUFNLGdCQUFnQixnQkFBZ0IsYUFBYSxNQUFNLGtCQUFrQjtDQUMzRSxZQUFZLE9BQU8sZUFBZSxHQUFHLElBQUk7Q0FDekMsT0FBTztBQUNUO0FBQ0EsU0FBUyx5QkFBeUIsVUFBVSxVQUFVO0NBQ3BELE1BQU0sRUFDSixXQUNBLFlBQ0EsY0FDRSwyQkFBMkIsUUFBUTtDQUN2QyxTQUFTLGNBQWMsUUFBUSxPQUFPO0VBQ3BDLE9BQU8sZUFBZSxDQUFDLE1BQU0sR0FBRyxLQUFLO0NBQ3ZDO0NBQ0EsU0FBUyxlQUFlLGFBQWEsT0FBTyxhQUFhO0VBQ3ZELGNBQWMsb0JBQW9CLFdBQVc7RUFDN0MsTUFBTSxlQUFlLElBQUksSUFBSSxlQUFlLFdBQVcsTUFBTSxHQUFHLENBQUM7RUFDakUsTUFBTSw0QkFBNEIsSUFBSSxJQUFJO0VBQzFDLE1BQU0sU0FBUyxZQUFZLFFBQVEsVUFBVTtHQUMzQyxNQUFNLFVBQVUsY0FBYyxPQUFPLFFBQVE7R0FDN0MsTUFBTSxXQUFXLENBQUMsVUFBVSxJQUFJLE9BQU87R0FDdkMsSUFBSSxVQUFVLFVBQVUsSUFBSSxPQUFPO0dBQ25DLE9BQU8sQ0FBQyxhQUFhLElBQUksT0FBTyxLQUFLO0VBQ3ZDLENBQUM7RUFDRCxJQUFJLE9BQU8sV0FBVyxHQUNwQixjQUFjLE9BQU8sTUFBTTtDQUUvQjtDQUNBLFNBQVMsY0FBYyxRQUFRLE9BQU87RUFDcEMsT0FBTyxlQUFlLENBQUMsTUFBTSxHQUFHLEtBQUs7Q0FDdkM7Q0FDQSxTQUFTLGVBQWUsYUFBYSxPQUFPO0VBQzFDLElBQUksdUJBQXVCLENBQUM7RUFDNUIsY0FBYyxvQkFBb0IsV0FBVztFQUM3QyxJQUFJLFlBQVksV0FBVyxHQUFHO0dBQzVCLEtBQUssTUFBTSxRQUFRLGFBQWE7SUFDOUIsTUFBTSxXQUFXLFNBQVMsSUFBSTtJQUM5QixxQkFBcUIsWUFBWTtJQUNqQyxPQUFPLE1BQU0sU0FBUztHQUN4QjtHQUNBLGNBQWMsb0JBQW9CLG9CQUFvQjtHQUN0RCxjQUFjLE9BQU8sV0FBVztFQUNsQztDQUNGO0NBQ0EsU0FBUyxjQUFjLGFBQWEsT0FBTztFQUN6QyxjQUFjLG9CQUFvQixXQUFXO0VBQzdDLE1BQU0sV0FBVyxDQUFDO0VBQ2xCLE1BQU0sTUFBTSxDQUFDO0VBQ2IsZUFBZSxhQUFhLE9BQU8sQ0FBQyxDQUFDO0NBQ3ZDO0NBQ0EsU0FBUyxpQkFBaUIsUUFBUSxPQUFPO0VBQ3ZDLE9BQU8sa0JBQWtCLENBQUMsTUFBTSxHQUFHLEtBQUs7Q0FDMUM7Q0FDQSxTQUFTLGtCQUFrQixTQUFTLE9BQU87RUFDekMsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxjQUFjO0VBQ2xCLEtBQUssSUFBSSxVQUFVLFNBQVM7R0FDMUIsTUFBTSxTQUFTLE1BQU0sU0FBUyxPQUFPO0dBQ3JDLElBQUksQ0FBQyxRQUNIO0dBRUYsaUJBQWlCO0dBQ2pCLE9BQU8sT0FBTyxRQUFRLE9BQU8sT0FBTztHQUNwQyxNQUFNLFFBQVEsU0FBUyxNQUFNO0dBQzdCLElBQUksT0FBTyxPQUFPLE9BQU87SUFDdkIsY0FBYztJQUNkLE9BQU8sTUFBTSxTQUFTLE9BQU87SUFDN0IsTUFBTSxXQUFXLE1BQU0sSUFBSSxRQUFRLE9BQU8sRUFBRTtJQUM1QyxNQUFNLElBQUksWUFBWTtJQUN0QixNQUFNLFNBQVMsU0FBUztHQUMxQjtFQUNGO0VBQ0EsSUFBSSxnQkFDRixjQUFjLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQixXQUFXO0NBRXhEO0NBQ0EsU0FBUyxpQkFBaUIsUUFBUSxPQUFPO0VBQ3ZDLE9BQU8sa0JBQWtCLENBQUMsTUFBTSxHQUFHLEtBQUs7Q0FDMUM7Q0FDQSxTQUFTLGtCQUFrQixhQUFhLE9BQU87RUFDN0MsTUFBTSxDQUFDLE9BQU8sU0FBUyxvQkFBb0IsMEJBQTBCLGFBQWEsVUFBVSxLQUFLO0VBQ2pHLElBQUksTUFBTSxRQUNSLGVBQWUsT0FBTyxPQUFPLGdCQUFnQjtFQUUvQyxJQUFJLFFBQVEsUUFDVixrQkFBa0IsU0FBUyxLQUFLO0NBRXBDO0NBQ0EsU0FBUyxlQUFlLEdBQUcsR0FBRztFQUM1QixJQUFJLEVBQUUsV0FBVyxFQUFFLFFBQ2pCLE9BQU87RUFFVCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7R0FDakMsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUNiO0dBRUYsT0FBTztFQUNUO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSxpQkFBaUIsT0FBTyxZQUFZLGdCQUFnQixnQkFBZ0I7RUFDeEUsTUFBTSxrQkFBa0IsV0FBVyxNQUFNLFFBQVE7RUFDakQsTUFBTSxhQUFhLFdBQVcsTUFBTSxHQUFHO0VBQ3ZDLE1BQU0sZ0JBQWdCLE1BQU07RUFDNUIsSUFBSSxNQUFNO0VBQ1YsSUFBSSxhQUNGLE1BQU0sSUFBSSxJQUFJLFVBQVU7RUFFMUIsSUFBSSxpQkFBaUIsQ0FBQztFQUN0QixLQUFLLE1BQU0sTUFBTSxLQUFLO0dBQ3BCLE1BQU0sU0FBUyxnQkFBZ0I7R0FDL0IsSUFBSSxRQUNGLGVBQWUsS0FBSyxNQUFNO0VBRTlCO0VBQ0EsTUFBTSxxQkFBcUIsZUFBZSxXQUFXO0VBQ3JELEtBQUssTUFBTSxRQUFRLFlBQVk7R0FDN0IsY0FBYyxTQUFTLElBQUksS0FBSztHQUNoQyxJQUFJLENBQUMsb0JBQ0gsT0FBTyxnQkFBZ0IsTUFBTSxRQUFRO0VBRXpDO0VBQ0EsSUFBSSxvQkFDRixpQkFBaUIsV0FBVyxNQUFNLENBQUMsQ0FBQyxLQUFLLFFBQVE7T0FDNUMsSUFBSSxnQkFDVCxlQUFlLEtBQUssUUFBUTtFQUU5QixNQUFNLGVBQWUsZUFBZSxJQUFJLFFBQVE7RUFDaEQsSUFBSSxDQUFDLGVBQWUsWUFBWSxZQUFZLEdBQzFDLE1BQU0sTUFBTTtDQUVoQjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQSxRQUFRLG9CQUFvQixhQUFhO0VBQ3pDLFdBQVcsb0JBQW9CLGdCQUFnQjtFQUMvQyxXQUFXLG9CQUFvQixnQkFBZ0I7RUFDL0MsUUFBUSxvQkFBb0IsYUFBYTtFQUN6QyxTQUFTLG9CQUFvQixjQUFjO0VBQzNDLFFBQVEsb0JBQW9CLGFBQWE7RUFDekMsU0FBUyxvQkFBb0IsY0FBYztFQUMzQyxZQUFZLG9CQUFvQixpQkFBaUI7RUFDakQsWUFBWSxvQkFBb0IsaUJBQWlCO0NBQ25EO0FBQ0Y7QUFHQSxTQUFTLG9CQUFvQixVQUFVLENBQUMsR0FBRztDQUN6QyxNQUFNLEVBQ0osVUFDQSxpQkFDRTtFQUNGLGNBQWM7RUFDZCxXQUFXLGFBQWEsU0FBUztFQUNqQyxHQUFHO0NBQ0w7Q0FDQSxNQUFNLGVBQWUsZUFBZSx5QkFBeUIsVUFBVSxZQUFZLElBQUksMkJBQTJCLFFBQVE7Q0FDMUgsTUFBTSxlQUFlLDBCQUEwQixZQUFZO0NBQzNELE1BQU0sbUJBQW1CLHVCQUF1QjtDQUNoRCxPQUFPO0VBQ0w7RUFDQTtFQUNBLEdBQUc7RUFDSCxHQUFHO0VBQ0gsR0FBRztDQUNMO0FBQ0Y7QUFHQSxJQUFJLE9BQU87QUFDWCxJQUFJLFdBQVc7QUFDZixJQUFJLFlBQVk7QUFDaEIsSUFBSSxZQUFZO0FBQ2hCLElBQUksZ0JBQWdCLFFBQVE7QUFDNUIsSUFBSSxnQkFBZ0IsUUFBUTtBQUM1QixJQUFJLG9CQUFvQixHQUFHLFNBQVMsR0FBRztBQUN2QyxJQUFJLG9CQUFvQixHQUFHLFNBQVMsR0FBRztBQUN2QyxJQUFJLGlCQUFpQixNQUFNO0NBQ3pCLFlBQVksTUFBTTtFQUNoQixLQUFLLE9BQU87RUFDWixLQUFLLFVBQVUsR0FBRyxLQUFLLEdBQUcsVUFBVSxZQUFZLEtBQUs7Q0FDdkQ7Q0FDQTtDQUNBLE9BQU87Q0FDUDtBQUNGO0FBR0EsSUFBSSxrQkFBa0IsTUFBTSxhQUFhO0NBQ3ZDLElBQUksT0FBTyxTQUFTLFlBQ2xCLE1BQU0sSUFBSSxVQUErRSxHQUFHLFNBQVMsbUJBQW1CO0FBRTVIO0FBQ0EsSUFBSSxjQUFjLENBQ2xCO0FBQ0EsSUFBSSxrQkFBa0IsU0FBUyxVQUFVLFVBQVU7Q0FDakQsUUFBUSxNQUFNLE9BQU87Q0FDckIsT0FBTztBQUNUO0FBQ0EsSUFBSSwwQkFBMEIsYUFBYSxhQUFhO0NBQ3RELFlBQVksaUJBQWlCLFNBQVMsVUFBVSxFQUM5QyxNQUFNLEtBQ1IsQ0FBQztDQUNELGFBQWEsWUFBWSxvQkFBb0IsU0FBUyxRQUFRO0FBQ2hFO0FBR0EsSUFBSSxrQkFBa0IsV0FBVztDQUMvQixJQUFJLE9BQU8sU0FDVCxNQUFNLElBQUksZUFBZSxPQUFPLE1BQU07QUFFMUM7QUFDQSxTQUFTLGVBQWUsUUFBUSxTQUFTO0NBQ3ZDLElBQUksVUFBVTtDQUNkLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN0QyxNQUFNLHdCQUF3QixPQUFPLElBQUksZUFBZSxPQUFPLE1BQU0sQ0FBQztFQUN0RSxJQUFJLE9BQU8sU0FBUztHQUNsQixnQkFBZ0I7R0FDaEI7RUFDRjtFQUNBLFVBQVUsdUJBQXVCLFFBQVEsZUFBZTtFQUN4RCxRQUFRLGNBQWMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsTUFBTTtDQUN2RCxDQUFDLENBQUMsQ0FBQyxjQUFjO0VBQ2YsVUFBVTtDQUNaLENBQUM7QUFDSDtBQUNBLElBQUksVUFBVSxPQUFPLE9BQU8sWUFBWTtDQUN0QyxJQUFJO0VBQ0YsTUFBTSxRQUFRLFFBQVE7RUFFdEIsT0FBTztHQUNMLFFBQVE7R0FDUixPQUFBLE1BSGtCLE1BQU07RUFJMUI7Q0FDRixTQUFTLE9BQU87RUFDZCxPQUFPO0dBQ0wsUUFBUSxpQkFBaUIsaUJBQWlCLGNBQWM7R0FDeEQ7RUFDRjtDQUNGLFVBQVU7RUFDUixVQUFVO0NBQ1o7QUFDRjtBQUNBLElBQUksZUFBZSxXQUFXO0NBQzVCLFFBQVEsWUFBWTtFQUNsQixPQUFPLGVBQWUsZUFBZSxRQUFRLE9BQU8sQ0FBQyxDQUFDLE1BQU0sV0FBVztHQUNyRSxlQUFlLE1BQU07R0FDckIsT0FBTztFQUNULENBQUMsQ0FBQztDQUNKO0FBQ0Y7QUFDQSxJQUFJLGVBQWUsV0FBVztDQUM1QixNQUFNLFFBQVEsWUFBWSxNQUFNO0NBQ2hDLFFBQVEsY0FBYztFQUNwQixPQUFPLE1BQU0sSUFBSSxTQUFTLFlBQVksV0FBVyxTQUFTLFNBQVMsQ0FBQyxDQUFDO0NBQ3ZFO0FBQ0Y7QUFHQSxJQUFJLEVBQ0YsV0FDRTtBQUNKLElBQUkscUJBQXFCLENBQUM7QUFDMUIsSUFBSSxNQUFNO0FBQ1YsSUFBSSxjQUFjLG1CQUFtQiwyQkFBMkI7Q0FDOUQsTUFBTSxtQkFBbUIsZUFBZSx1QkFBdUIseUJBQXlCLFdBQVcsTUFBTSxrQkFBa0IsTUFBTSxDQUFDO0NBQ2xJLFFBQVEsY0FBYyxTQUFTO0VBQzdCLGVBQWUsY0FBYyxjQUFjO0VBQzNDLE1BQU0sdUJBQXVCLElBQUksZ0JBQWdCO0VBQ2pELGdCQUFnQixvQkFBb0I7RUFDcEMsTUFBTSxTQUFTLFFBQVEsWUFBWTtHQUNqQyxlQUFlLGlCQUFpQjtHQUNoQyxlQUFlLHFCQUFxQixNQUFNO0dBQzFDLE1BQU0sVUFBVSxNQUFNLGFBQWE7SUFDakMsT0FBTyxZQUFZLHFCQUFxQixNQUFNO0lBQzlDLE9BQU8sWUFBWSxxQkFBcUIsTUFBTTtJQUM5QyxRQUFRLHFCQUFxQjtHQUMvQixDQUFDO0dBQ0QsZUFBZSxxQkFBcUIsTUFBTTtHQUMxQyxPQUFPO0VBQ1QsU0FBUyxxQkFBcUIsTUFBTSxhQUFhLENBQUM7RUFDbEQsSUFBSSxNQUFNLFVBQ1IsdUJBQXVCLEtBQUssT0FBTyxNQUFNLEtBQUssQ0FBQztFQUVqRCxPQUFPO0dBQ0wsUUFBUSxZQUFZLGlCQUFpQixDQUFDLENBQUMsTUFBTTtHQUM3QyxTQUFTO0lBQ1AscUJBQXFCLE1BQU0sYUFBYTtHQUMxQztFQUNGO0NBQ0Y7QUFDRjtBQUNBLElBQUkscUJBQXFCLGdCQUFnQixXQUFXO0NBQ2xELE1BQU0sT0FBTyxPQUFPLFdBQVcsWUFBWTtFQUN6QyxlQUFlLE1BQU07RUFDckIsSUFBSSxvQkFBb0IsQ0FDeEI7RUFjQSxNQUFNLFdBQVcsQ0FBQyxJQWJPLFNBQVMsU0FBUyxXQUFXO0dBQ3BELElBQUksZ0JBQWdCLGVBQWU7SUFDakM7SUFDQSxTQUFTLFFBQVEsZ0JBQWdCO0tBQy9CLFlBQVksWUFBWTtLQUN4QixRQUFRO01BQUM7TUFBUSxZQUFZLFNBQVM7TUFBRyxZQUFZLGlCQUFpQjtLQUFDLENBQUM7SUFDMUU7R0FDRixDQUFDO0dBQ0Qsb0JBQW9CO0lBQ2xCLGNBQWM7SUFDZCxPQUFPO0dBQ1Q7RUFDRixDQUM2QixDQUFDO0VBQzlCLElBQUksV0FBVyxNQUNiLFNBQVMsS0FBSyxJQUFJLFNBQVMsWUFBWSxXQUFXLFNBQVMsU0FBUyxJQUFJLENBQUMsQ0FBQztFQUU1RSxJQUFJO0dBQ0YsTUFBTSxTQUFTLE1BQU0sZUFBZSxRQUFRLFFBQVEsS0FBSyxRQUFRLENBQUM7R0FDbEUsZUFBZSxNQUFNO0dBQ3JCLE9BQU87RUFDVCxVQUFVO0dBQ1IsWUFBWTtFQUNkO0NBQ0Y7Q0FDQSxTQUFTLFdBQVcsWUFBWSxlQUFlLEtBQUssV0FBVyxPQUFPLENBQUM7QUFDekU7QUFDQSxJQUFJLDZCQUE2QixZQUFZO0NBQzNDLElBQUksRUFDRixNQUNBLGVBQ0EsU0FDQSxXQUNBLFdBQ0U7Q0FDSixJQUFJLE1BQ0YsWUFBWSxhQUFhLElBQUksQ0FBQyxDQUFDO01BQzFCLElBQUksZUFBZTtFQUN4QixPQUFPLGNBQWM7RUFDckIsWUFBWSxjQUFjO0NBQzVCLE9BQU8sSUFBSSxTQUNULFlBQVk7TUFDUCxJQUFJLFdBQVcsQ0FDdEIsT0FDRSxNQUFNLElBQUksTUFBMkUseUZBQXlGO0NBRWhMLGVBQWUsUUFBUSxrQkFBa0I7Q0FDekMsT0FBTztFQUNMO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFDQSxJQUFJLHNCQUFzQyx3QkFBUSxZQUFZO0NBQzVELE1BQU0sRUFDSixNQUNBLFdBQ0EsV0FDRSwwQkFBMEIsT0FBTztDQVdyQyxPQUFPO0VBVEwsSUFBSSxPQUFPO0VBQ1g7RUFDQTtFQUNBO0VBQ0EseUJBQXlCLElBQUksSUFBSTtFQUNqQyxtQkFBbUI7R0FDakIsTUFBTSxJQUFJLE1BQTJFLDZCQUE2QjtFQUNwSDtDQUVTO0FBQ2IsR0FBRyxFQUNELGlCQUFpQixvQkFDbkIsQ0FBQztBQUNELElBQUkscUJBQXFCLGFBQWEsWUFBWTtDQUNoRCxNQUFNLEVBQ0osTUFDQSxRQUNBLGNBQ0UsMEJBQTBCLE9BQU87Q0FDckMsT0FBTyxNQUFNLEtBQUssWUFBWSxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sVUFBVTtFQUV0RCxRQUQ2QixPQUFPLFNBQVMsV0FBVyxNQUFNLFNBQVMsT0FBTyxNQUFNLGNBQWMsY0FDbkUsTUFBTSxXQUFXO0NBQ2xELENBQUM7QUFDSDtBQUNBLElBQUkseUJBQXlCLFVBQVU7Q0FDckMsTUFBTSxRQUFRLFNBQVMsZUFBZTtFQUNwQyxXQUFXLE1BQU0saUJBQWlCO0NBQ3BDLENBQUM7QUFDSDtBQUNBLElBQUksaUNBQWlDLGFBQWEsdUJBQXVCO0NBQ3ZFLGFBQWE7RUFDWCxLQUFLLE1BQU0sYUFBYSxtQkFBbUIsS0FBSyxHQUM5QyxzQkFBc0IsU0FBUztFQUVqQyxZQUFZLE1BQU07Q0FDcEI7QUFDRjtBQUNBLElBQUkscUJBQXFCLGNBQWMsZUFBZSxjQUFjO0NBQ2xFLElBQUk7RUFDRixhQUFhLGVBQWUsU0FBUztDQUN2QyxTQUFTLG1CQUFtQjtFQUMxQixpQkFBaUI7R0FDZixNQUFNO0VBQ1IsR0FBRyxDQUFDO0NBQ047QUFDRjtBQUNBLElBQUksY0FBOEIsdUJBQXVCLDZCQUFhLEdBQUcsSUFBSSxLQUFLLEdBQUcsRUFDbkYsaUJBQWlCLFlBQ25CLENBQUM7QUFDRCxJQUFJLG9CQUFvQyw2QkFBYSxHQUFHLElBQUksV0FBVztBQUN2RSxJQUFJLGlCQUFpQyx1QkFBdUIsNkJBQWEsR0FBRyxJQUFJLFFBQVEsR0FBRyxFQUN6RixpQkFBaUIsZUFDbkIsQ0FBQztBQUNELElBQUksdUJBQXVCLEdBQUcsU0FBUztDQUNyQyxRQUFRLE1BQU0sR0FBRyxJQUFJLFNBQVMsR0FBRyxJQUFJO0FBQ3ZDO0FBQ0EsSUFBSSw0QkFBNEIsb0JBQW9CLENBQUMsTUFBTTtDQUN6RCxNQUFNLDhCQUE4QixJQUFJLElBQUk7Q0FDNUMsTUFBTSxxQ0FBcUMsSUFBSSxJQUFJO0NBQ25ELE1BQU0sMEJBQTBCLFVBQVU7RUFDeEMsTUFBTSxRQUFRLG1CQUFtQixJQUFJLEtBQUssS0FBSztFQUMvQyxtQkFBbUIsSUFBSSxPQUFPLFFBQVEsQ0FBQztDQUN6QztDQUNBLE1BQU0sNEJBQTRCLFVBQVU7RUFDMUMsTUFBTSxRQUFRLG1CQUFtQixJQUFJLEtBQUssS0FBSztFQUMvQyxJQUFJLFVBQVUsR0FDWixtQkFBbUIsT0FBTyxLQUFLO09BRS9CLG1CQUFtQixJQUFJLE9BQU8sUUFBUSxDQUFDO0NBRTNDO0NBQ0EsTUFBTSxFQUNKLE9BQ0EsVUFBVSx3QkFDUjtDQUNKLGVBQWUsU0FBUyxTQUFTO0NBQ2pDLE1BQU0sZUFBZSxVQUFVO0VBQzdCLE1BQU0sb0JBQW9CLFlBQVksT0FBTyxNQUFNLEVBQUU7RUFDckQsWUFBWSxJQUFJLE1BQU0sSUFBSSxLQUFLO0VBQy9CLFFBQVEsa0JBQWtCO0dBQ3hCLE1BQU0sWUFBWTtHQUNsQixJQUFJLGVBQWUsY0FDakIsc0JBQXNCLEtBQUs7RUFFL0I7Q0FDRjtDQUNBLE1BQU0sbUJBQW1CLFlBQVk7RUFDbkMsTUFBTSxRQUFRLGtCQUFrQixhQUFhLE9BQU8sS0FBSyxvQkFBb0IsT0FBTztFQUNwRixPQUFPLFlBQVksS0FBSztDQUMxQjtDQUNBLE9BQU8sZ0JBQWdCLEVBQ3JCLGlCQUFpQixlQUNuQixDQUFDO0NBQ0QsTUFBTSxpQkFBaUIsWUFBWTtFQUNqQyxNQUFNLFFBQVEsa0JBQWtCLGFBQWEsT0FBTztFQUNwRCxJQUFJLE9BQU87R0FDVCxNQUFNLFlBQVk7R0FDbEIsSUFBSSxRQUFRLGNBQ1Ysc0JBQXNCLEtBQUs7RUFFL0I7RUFDQSxPQUFPLENBQUMsQ0FBQztDQUNYO0NBQ0EsT0FBTyxlQUFlLEVBQ3BCLGlCQUFpQixjQUNuQixDQUFDO0NBQ0QsTUFBTSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsS0FBSyxxQkFBcUI7RUFDckUsTUFBTSx5QkFBeUIsSUFBSSxnQkFBZ0I7RUFDbkQsTUFBTSxPQUFPLGtCQUFrQixnQkFBZ0IsdUJBQXVCLE1BQU07RUFDNUUsTUFBTSxtQkFBbUIsQ0FBQztFQUMxQixJQUFJO0dBQ0YsTUFBTSxRQUFRLElBQUksc0JBQXNCO0dBQ3hDLHVCQUF1QixLQUFLO0dBQzVCLE1BQU0sUUFBUSxRQUFRLE1BQU0sT0FDMUIsUUFFQSxPQUFPLENBQUMsR0FBRyxLQUFLO0lBQ2Q7SUFDQSxZQUFZLFdBQVcsWUFBWSxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPO0lBQ3hFO0lBQ0EsT0FBTyxZQUFZLHVCQUF1QixNQUFNO0lBQ2hELE9BQU8sWUFBWSx1QkFBdUIsTUFBTTtJQUNoRDtJQUNBLFFBQVEsdUJBQXVCO0lBQy9CLE1BQU0sV0FBVyx1QkFBdUIsUUFBUSxnQkFBZ0I7SUFDaEUsYUFBYSxNQUFNO0lBQ25CLGlCQUFpQjtLQUNmLFlBQVksSUFBSSxNQUFNLElBQUksS0FBSztJQUNqQztJQUNBLDZCQUE2QjtLQUMzQixNQUFNLFFBQVEsU0FBUyxZQUFZLEdBQUcsUUFBUTtNQUM1QyxJQUFJLGVBQWUsd0JBQXdCO09BQ3pDLFdBQVcsTUFBTSxpQkFBaUI7T0FDbEMsSUFBSSxPQUFPLFVBQVU7TUFDdkI7S0FDRixDQUFDO0lBQ0g7SUFDQSxjQUFjO0tBQ1osdUJBQXVCLE1BQU0saUJBQWlCO0tBQzlDLE1BQU0sUUFBUSxPQUFPLHNCQUFzQjtJQUM3QztJQUNBLHdCQUF3QjtLQUN0QixlQUFlLHVCQUF1QixNQUFNO0lBQzlDO0dBQ0YsQ0FBQyxDQUNILENBQUM7RUFDSCxTQUFTLGVBQWU7R0FDdEIsSUFBSSxFQUFFLHlCQUF5QixpQkFDN0Isa0JBQWtCLFNBQVMsZUFBZSxFQUN4QyxVQUFVLFNBQ1osQ0FBQztFQUVMLFVBQVU7R0FDUixNQUFNLFFBQVEsSUFBSSxnQkFBZ0I7R0FDbEMsdUJBQXVCLE1BQU0saUJBQWlCO0dBQzlDLHlCQUF5QixLQUFLO0dBQzlCLE1BQU0sUUFBUSxPQUFPLHNCQUFzQjtFQUM3QztDQUNGO0NBQ0EsTUFBTSwwQkFBMEIsOEJBQThCLGFBQWEsa0JBQWtCO0NBQzdGLE1BQU0sY0FBYyxTQUFTLFVBQVUsV0FBVztFQUNoRCxJQUFJLENBQUMsU0FBUyxNQUFNLEdBQ2xCLE9BQU8sS0FBSyxNQUFNO0VBRXBCLElBQUksWUFBWSxNQUFNLE1BQU0sR0FDMUIsT0FBTyxlQUFlLE9BQU8sT0FBTztFQUV0QyxJQUFJLGtCQUFrQixNQUFNLE1BQU0sR0FBRztHQUNuQyx3QkFBd0I7R0FDeEI7RUFDRjtFQUNBLElBQUksZUFBZSxNQUFNLE1BQU0sR0FDN0IsT0FBTyxjQUFjLE9BQU8sT0FBTztFQUVyQyxJQUFJLGdCQUFnQixJQUFJLFNBQVM7RUFDakMsTUFBTSx5QkFBeUI7R0FDN0IsSUFBSSxrQkFBa0Isb0JBQ3BCLE1BQU0sSUFBSSxNQUEyRSxHQUFHLElBQUksb0RBQW9EO0dBRWxKLE9BQU87RUFDVDtFQUNBLElBQUk7RUFDSixJQUFJO0dBQ0YsU0FBUyxLQUFLLE1BQU07R0FDcEIsSUFBSSxZQUFZLE9BQU8sR0FBRztJQUN4QixNQUFNLGVBQWUsSUFBSSxTQUFTO0lBQ2xDLE1BQU0sa0JBQWtCLE1BQU0sS0FBSyxZQUFZLE9BQU8sQ0FBQztJQUN2RCxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7S0FDbkMsSUFBSSxjQUFjO0tBQ2xCLElBQUk7TUFDRixjQUFjLE1BQU0sVUFBVSxRQUFRLGNBQWMsYUFBYTtLQUNuRSxTQUFTLGdCQUFnQjtNQUN2QixjQUFjO01BQ2Qsa0JBQWtCLFNBQVMsZ0JBQWdCLEVBQ3pDLFVBQVUsWUFDWixDQUFDO0tBQ0g7S0FDQSxJQUFJLENBQUMsYUFDSDtLQUVGLGVBQWUsT0FBTyxRQUFRLEtBQUssZ0JBQWdCO0lBQ3JEO0dBQ0Y7RUFDRixVQUFVO0dBQ1IsZ0JBQWdCO0VBQ2xCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBLGdCQUFnQjtDQUNsQjtBQUNGO0FBR0EsSUFBSSx5QkFBeUIsZ0JBQWdCO0NBQzNDO0NBQ0EseUJBQXlCLElBQUksSUFBSTtBQUNuQztBQUNBLElBQUksaUJBQWlCLGdCQUFnQixXQUFXLFFBQVEsTUFBTSxlQUFlO0FBQzdFLElBQUksZ0NBQWdDO0NBQ2xDLE1BQU0sYUFBYSxPQUFPO0NBQzFCLE1BQU0sZ0NBQWdDLElBQUksSUFBSTtDQUM5QyxNQUFNLGlCQUFpQixPQUFPLE9BQU8sYUFBYSwwQkFBMEIsR0FBRyxpQkFBaUI7RUFDOUYsU0FBUztFQUNULE1BQU0sRUFDSixXQUNGO0NBQ0YsRUFBRSxHQUFHLEVBQ0gsaUJBQWlCLGVBQ25CLENBQUM7Q0FDRCxNQUFNLGdCQUFnQixPQUFPLE9BQU8sU0FBUyxlQUFlLEdBQUcsYUFBYTtFQUMxRSxZQUFZLFNBQVMsZ0JBQWdCO0dBQ25DLG9CQUFvQixlQUFlLGFBQWEscUJBQXFCO0VBQ3ZFLENBQUM7Q0FDSCxHQUFHLEVBQ0QsaUJBQWlCLGNBQ25CLENBQUM7Q0FDRCxNQUFNLHNCQUFzQixRQUFRO0VBRWxDLE9BQU8sUUFBUSxHQURXLE1BQU0sS0FBSyxjQUFjLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVLG9CQUFvQixNQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVUsQ0FDbEgsQ0FBaUI7Q0FDckM7Q0FDQSxNQUFNLG1CQUFtQixRQUFRLGdCQUFnQixjQUFjLFVBQVUsQ0FBQztDQUMxRSxNQUFNLGNBQWMsU0FBUyxVQUFVLFdBQVc7RUFDaEQsSUFBSSxpQkFBaUIsTUFBTSxHQUFHO0dBQzVCLGNBQWMsR0FBRyxPQUFPLE9BQU87R0FDL0IsT0FBTyxJQUFJO0VBQ2I7RUFDQSxPQUFPLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0NBQzdDO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUlBLElBQUksZUFBZSxtQkFBbUIsaUJBQWlCLGtCQUFrQixPQUFPLGVBQWUsZ0JBQWdCO0FBQy9HLElBQUksZUFBZSxXQUFXLE9BQU8sU0FBUyxlQUFlLFlBQVksVUFBVSxJQUFJLENBQUMsQ0FBQyxXQUFXLGFBQWEsV0FBVyxPQUFPLENBQUMsSUFBSSxPQUFPLFFBQVEsVUFBVSxDQUFDO0FBQ2xLLElBQUksaUJBQWlDLHVCQUFPLElBQUksMEJBQTBCO0FBQzFFLElBQUksZ0JBQWdCLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDakQsSUFBSSxnQ0FBZ0MsSUFBSSxRQUFRO0FBQ2hELElBQUksb0JBQW9CLE9BQU8sWUFBWSxzQkFBc0Isb0JBQW9CLGVBQWUsYUFBYSxJQUFJLE1BQU0sT0FBTyxFQUNoSSxNQUFNLFFBQVEsTUFBTSxhQUFhO0NBQy9CLElBQUksU0FBUyxnQkFBZ0IsT0FBTztDQUNwQyxNQUFNLFNBQVMsUUFBUSxJQUFJLFFBQVEsTUFBTSxRQUFRO0NBQ2pELElBQUksT0FBTyxXQUFXLGFBQWE7RUFDakMsTUFBTSxTQUFTLGtCQUFrQjtFQUNqQyxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87RUFDMUMsTUFBTSxVQUFVLFdBQVc7RUFDM0IsSUFBSSxTQUFTO0dBQ1gsTUFBTSxnQkFBZ0IsUUFBUSxLQUFLLEdBQUcsRUFDcEMsTUFBTSxPQUFPLEVBQ2YsQ0FBQztHQUNELElBQUksT0FBTyxrQkFBa0IsYUFDM0IsTUFBTSxJQUFJLE1BQTJFLDhCQUE4QixLQUFLLFNBQVMsRUFBRSxrUkFBa1I7R0FFdlosa0JBQWtCLFFBQVE7R0FDMUIsT0FBTztFQUNUO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1QsRUFDRixDQUFDLENBQUM7QUFDRixJQUFJQyxjQUFZLFVBQVU7Q0FDeEIsSUFBSSxDQUFDLGFBQWEsS0FBSyxHQUNyQixNQUFNLElBQUksTUFBMkUsc0NBQXNDO0NBRTdILE9BQU8sTUFBTTtBQUNmO0FBQ0EsSUFBSSxjQUFjLENBQUM7QUFDbkIsSUFBSSxlQUFlLFFBQVEsZ0JBQWdCO0FBQzNDLFNBQVMsY0FBYyxHQUFHLFFBQVE7Q0FDaEMsTUFBTSxhQUFhLE9BQU8sWUFBWSxZQUFZLE1BQU0sQ0FBQztDQUN6RCxNQUFNLG1CQUFtQixPQUFPLEtBQUssVUFBVSxDQUFDLENBQUMsU0FBU0MsZ0JBQWlCLFVBQVUsSUFBSTtDQUN6RixJQUFJLFVBQVUsV0FBVztDQUN6QixTQUFTLGdCQUFnQixPQUFPLFFBQVE7RUFDdEMsT0FBTyxRQUFRLE9BQU8sTUFBTTtDQUM5QjtDQUNBLGdCQUFnQiw2QkFBNkI7Q0FDN0MsTUFBTSxvQkFBb0IsQ0FBQztDQUMzQixNQUFNLFVBQVUsT0FBTyxTQUFTLENBQUMsTUFBTTtFQUNyQyxNQUFNLEVBQ0osYUFDQSxTQUFTLG9CQUNQO0VBQ0osTUFBTSxpQkFBaUIsV0FBVztFQUNsQyxJQUFJLENBQUMsT0FBTyxvQkFBb0Isa0JBQWtCLG1CQUFtQixpQkFBaUI7R0FDcEYsSUFBSSxPQUFPLFlBQVksZUFBZSxNQUNwQyxRQUFRLE1BQU0sMERBQTBELFlBQVksK0NBQStDO0dBRXJJLE9BQU87RUFDVDtFQUNBLElBQUksT0FBTyxvQkFBb0IsbUJBQW1CLGlCQUNoRCxPQUFPLGtCQUFrQjtFQUUzQixXQUFXLGVBQWU7RUFDMUIsVUFBVSxXQUFXO0VBQ3JCLE9BQU87Q0FDVDtDQUNBLE1BQU0sV0FBVyxPQUFPLE9BQU8sU0FBUyxhQUFhLFlBQVksYUFBYTtFQUM1RSxPQUFPLFNBQVMsVUFBVSxPQUFPLEdBQUcsTUFBTTtHQUN4QyxPQUFPLFdBQVcsaUJBQWlCLGNBQWMsWUFBWSxPQUFPLEdBQUcsSUFBSSxJQUFJLE9BQU8sWUFBWSxpQkFBaUIsR0FBRyxHQUFHLElBQUk7RUFDL0g7Q0FDRixHQUFHLEVBQ0QsVUFBQSxXQUNGLENBQUM7Q0FDRCxPQUFPLE9BQU8sT0FBTyxpQkFBaUI7RUFDcEM7RUFDQTtDQUNGLENBQUM7QUFDSDtBQUdBLFNBQVMsdUJBQXVCLE1BQU07Q0FDcEMsT0FBTyxpQ0FBaUMsS0FBSyxtREFBbUQsS0FBSztBQUN2RyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDRdfQ==