"use client";
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=076f3cfd";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=cdd924ad";
//#region node_modules/next-themes/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var M = (e, i, s, u, m, a, l, h) => {
	let d = document.documentElement, w = ["light", "dark"];
	function p(n) {
		(Array.isArray(e) ? e : [e]).forEach((y) => {
			let k = y === "class", S = k && a ? m.map((f) => a[f] || f) : m;
			k ? (d.classList.remove(...S), d.classList.add(a && a[n] ? a[n] : n)) : d.setAttribute(y, n);
		}), R(n);
	}
	function R(n) {
		h && w.includes(n) && (d.style.colorScheme = n);
	}
	function c() {
		return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
	}
	if (u) p(u);
	else try {
		let n = localStorage.getItem(i) || s;
		p(l && n === "system" ? c() : n);
	} catch (n) {}
};
var b = ["light", "dark"];
var I = "(prefers-color-scheme: dark)";
var O = typeof window == "undefined";
var x = import_react.createContext(void 0);
var U = {
	setTheme: (e) => {},
	themes: []
};
var z = () => {
	var e;
	return (e = import_react.useContext(x)) != null ? e : U;
};
var J = (e) => import_react.useContext(x) ? import_react.createElement(import_react.Fragment, null, e.children) : import_react.createElement(V, { ...e });
var N = ["light", "dark"];
var V = ({ forcedTheme: e, disableTransitionOnChange: i = !1, enableSystem: s = !0, enableColorScheme: u = !0, storageKey: m = "theme", themes: a = N, defaultTheme: l = s ? "system" : "light", attribute: h = "data-theme", value: d, children: w, nonce: p, scriptProps: R }) => {
	let [c, n] = import_react.useState(() => H(m, l)), [T, y] = import_react.useState(() => c === "system" ? E() : c), k = d ? Object.values(d) : a, S = import_react.useCallback((o) => {
		let r = o;
		if (!r) return;
		o === "system" && s && (r = E());
		let v = d ? d[r] : r, C = i ? W(p) : null, P = document.documentElement, L = (g) => {
			g === "class" ? (P.classList.remove(...k), v && P.classList.add(v)) : g.startsWith("data-") && (v ? P.setAttribute(g, v) : P.removeAttribute(g));
		};
		if (Array.isArray(h) ? h.forEach(L) : L(h), u) {
			let g = b.includes(l) ? l : null, D = b.includes(r) ? r : g;
			P.style.colorScheme = D;
		}
		C?.();
	}, [p]), f = import_react.useCallback((o) => {
		let r = typeof o == "function" ? o(c) : o;
		n(r);
		try {
			localStorage.setItem(m, r);
		} catch (v) {}
	}, [c]), A = import_react.useCallback((o) => {
		let r = E(o);
		y(r), c === "system" && s && !e && S("system");
	}, [c, e]);
	import_react.useEffect(() => {
		let o = window.matchMedia(I);
		return o.addListener(A), A(o), () => o.removeListener(A);
	}, [A]), import_react.useEffect(() => {
		let o = (r) => {
			r.key === m && (r.newValue ? n(r.newValue) : f(l));
		};
		return window.addEventListener("storage", o), () => window.removeEventListener("storage", o);
	}, [f]), import_react.useEffect(() => {
		S(e != null ? e : c);
	}, [e, c]);
	let Q = import_react.useMemo(() => ({
		theme: c,
		setTheme: f,
		forcedTheme: e,
		resolvedTheme: c === "system" ? T : c,
		themes: s ? [...a, "system"] : a,
		systemTheme: s ? T : void 0
	}), [
		c,
		f,
		e,
		T,
		s,
		a
	]);
	return import_react.createElement(x.Provider, { value: Q }, import_react.createElement(_, {
		forcedTheme: e,
		storageKey: m,
		attribute: h,
		enableSystem: s,
		enableColorScheme: u,
		defaultTheme: l,
		value: d,
		themes: a,
		nonce: p,
		scriptProps: R
	}), w);
};
var _ = import_react.memo(({ forcedTheme: e, storageKey: i, attribute: s, enableSystem: u, enableColorScheme: m, defaultTheme: a, value: l, themes: h, nonce: d, scriptProps: w }) => {
	let p = JSON.stringify([
		s,
		i,
		a,
		e,
		h,
		l,
		u,
		m
	]).slice(1, -1);
	return import_react.createElement("script", {
		...w,
		suppressHydrationWarning: !0,
		nonce: typeof window == "undefined" ? d : "",
		dangerouslySetInnerHTML: { __html: `(${M.toString()})(${p})` }
	});
});
var H = (e, i) => {
	if (O) return;
	let s;
	try {
		s = localStorage.getItem(e) || void 0;
	} catch (u) {}
	return s || i;
};
var W = (e) => {
	let i = document.createElement("style");
	return e && i.setAttribute("nonce", e), i.appendChild(document.createTextNode("*,*::before,*::after{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}")), document.head.appendChild(i), () => {
		window.getComputedStyle(document.body), setTimeout(() => {
			document.head.removeChild(i);
		}, 1);
	};
};
var E = (e) => (e || (e = window.matchMedia(I)), e.matches ? "dark" : "light");
//#endregion
export { J as ThemeProvider, z as useTheme };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmV4dC10aGVtZXMuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vbmV4dC10aGVtZXMvZGlzdC9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCI7aW1wb3J0KmFzIHQgZnJvbVwicmVhY3RcIjt2YXIgTT0oZSxpLHMsdSxtLGEsbCxoKT0+e2xldCBkPWRvY3VtZW50LmRvY3VtZW50RWxlbWVudCx3PVtcImxpZ2h0XCIsXCJkYXJrXCJdO2Z1bmN0aW9uIHAobil7KEFycmF5LmlzQXJyYXkoZSk/ZTpbZV0pLmZvckVhY2goeT0+e2xldCBrPXk9PT1cImNsYXNzXCIsUz1rJiZhP20ubWFwKGY9PmFbZl18fGYpOm07az8oZC5jbGFzc0xpc3QucmVtb3ZlKC4uLlMpLGQuY2xhc3NMaXN0LmFkZChhJiZhW25dP2Fbbl06bikpOmQuc2V0QXR0cmlidXRlKHksbil9KSxSKG4pfWZ1bmN0aW9uIFIobil7aCYmdy5pbmNsdWRlcyhuKSYmKGQuc3R5bGUuY29sb3JTY2hlbWU9bil9ZnVuY3Rpb24gYygpe3JldHVybiB3aW5kb3cubWF0Y2hNZWRpYShcIihwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaylcIikubWF0Y2hlcz9cImRhcmtcIjpcImxpZ2h0XCJ9aWYodSlwKHUpO2Vsc2UgdHJ5e2xldCBuPWxvY2FsU3RvcmFnZS5nZXRJdGVtKGkpfHxzLHk9bCYmbj09PVwic3lzdGVtXCI/YygpOm47cCh5KX1jYXRjaChuKXt9fTt2YXIgYj1bXCJsaWdodFwiLFwiZGFya1wiXSxJPVwiKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKVwiLE89dHlwZW9mIHdpbmRvdz09XCJ1bmRlZmluZWRcIix4PXQuY3JlYXRlQ29udGV4dCh2b2lkIDApLFU9e3NldFRoZW1lOmU9Pnt9LHRoZW1lczpbXX0sej0oKT0+e3ZhciBlO3JldHVybihlPXQudXNlQ29udGV4dCh4KSkhPW51bGw/ZTpVfSxKPWU9PnQudXNlQ29udGV4dCh4KT90LmNyZWF0ZUVsZW1lbnQodC5GcmFnbWVudCxudWxsLGUuY2hpbGRyZW4pOnQuY3JlYXRlRWxlbWVudChWLHsuLi5lfSksTj1bXCJsaWdodFwiLFwiZGFya1wiXSxWPSh7Zm9yY2VkVGhlbWU6ZSxkaXNhYmxlVHJhbnNpdGlvbk9uQ2hhbmdlOmk9ITEsZW5hYmxlU3lzdGVtOnM9ITAsZW5hYmxlQ29sb3JTY2hlbWU6dT0hMCxzdG9yYWdlS2V5Om09XCJ0aGVtZVwiLHRoZW1lczphPU4sZGVmYXVsdFRoZW1lOmw9cz9cInN5c3RlbVwiOlwibGlnaHRcIixhdHRyaWJ1dGU6aD1cImRhdGEtdGhlbWVcIix2YWx1ZTpkLGNoaWxkcmVuOncsbm9uY2U6cCxzY3JpcHRQcm9wczpSfSk9PntsZXRbYyxuXT10LnVzZVN0YXRlKCgpPT5IKG0sbCkpLFtULHldPXQudXNlU3RhdGUoKCk9PmM9PT1cInN5c3RlbVwiP0UoKTpjKSxrPWQ/T2JqZWN0LnZhbHVlcyhkKTphLFM9dC51c2VDYWxsYmFjayhvPT57bGV0IHI9bztpZighcilyZXR1cm47bz09PVwic3lzdGVtXCImJnMmJihyPUUoKSk7bGV0IHY9ZD9kW3JdOnIsQz1pP1cocCk6bnVsbCxQPWRvY3VtZW50LmRvY3VtZW50RWxlbWVudCxMPWc9PntnPT09XCJjbGFzc1wiPyhQLmNsYXNzTGlzdC5yZW1vdmUoLi4uayksdiYmUC5jbGFzc0xpc3QuYWRkKHYpKTpnLnN0YXJ0c1dpdGgoXCJkYXRhLVwiKSYmKHY/UC5zZXRBdHRyaWJ1dGUoZyx2KTpQLnJlbW92ZUF0dHJpYnV0ZShnKSl9O2lmKEFycmF5LmlzQXJyYXkoaCk/aC5mb3JFYWNoKEwpOkwoaCksdSl7bGV0IGc9Yi5pbmNsdWRlcyhsKT9sOm51bGwsRD1iLmluY2x1ZGVzKHIpP3I6ZztQLnN0eWxlLmNvbG9yU2NoZW1lPUR9Qz09bnVsbHx8QygpfSxbcF0pLGY9dC51c2VDYWxsYmFjayhvPT57bGV0IHI9dHlwZW9mIG89PVwiZnVuY3Rpb25cIj9vKGMpOm87bihyKTt0cnl7bG9jYWxTdG9yYWdlLnNldEl0ZW0obSxyKX1jYXRjaCh2KXt9fSxbY10pLEE9dC51c2VDYWxsYmFjayhvPT57bGV0IHI9RShvKTt5KHIpLGM9PT1cInN5c3RlbVwiJiZzJiYhZSYmUyhcInN5c3RlbVwiKX0sW2MsZV0pO3QudXNlRWZmZWN0KCgpPT57bGV0IG89d2luZG93Lm1hdGNoTWVkaWEoSSk7cmV0dXJuIG8uYWRkTGlzdGVuZXIoQSksQShvKSwoKT0+by5yZW1vdmVMaXN0ZW5lcihBKX0sW0FdKSx0LnVzZUVmZmVjdCgoKT0+e2xldCBvPXI9PntyLmtleT09PW0mJihyLm5ld1ZhbHVlP24oci5uZXdWYWx1ZSk6ZihsKSl9O3JldHVybiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInN0b3JhZ2VcIixvKSwoKT0+d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJzdG9yYWdlXCIsbyl9LFtmXSksdC51c2VFZmZlY3QoKCk9PntTKGUhPW51bGw/ZTpjKX0sW2UsY10pO2xldCBRPXQudXNlTWVtbygoKT0+KHt0aGVtZTpjLHNldFRoZW1lOmYsZm9yY2VkVGhlbWU6ZSxyZXNvbHZlZFRoZW1lOmM9PT1cInN5c3RlbVwiP1Q6Yyx0aGVtZXM6cz9bLi4uYSxcInN5c3RlbVwiXTphLHN5c3RlbVRoZW1lOnM/VDp2b2lkIDB9KSxbYyxmLGUsVCxzLGFdKTtyZXR1cm4gdC5jcmVhdGVFbGVtZW50KHguUHJvdmlkZXIse3ZhbHVlOlF9LHQuY3JlYXRlRWxlbWVudChfLHtmb3JjZWRUaGVtZTplLHN0b3JhZ2VLZXk6bSxhdHRyaWJ1dGU6aCxlbmFibGVTeXN0ZW06cyxlbmFibGVDb2xvclNjaGVtZTp1LGRlZmF1bHRUaGVtZTpsLHZhbHVlOmQsdGhlbWVzOmEsbm9uY2U6cCxzY3JpcHRQcm9wczpSfSksdyl9LF89dC5tZW1vKCh7Zm9yY2VkVGhlbWU6ZSxzdG9yYWdlS2V5OmksYXR0cmlidXRlOnMsZW5hYmxlU3lzdGVtOnUsZW5hYmxlQ29sb3JTY2hlbWU6bSxkZWZhdWx0VGhlbWU6YSx2YWx1ZTpsLHRoZW1lczpoLG5vbmNlOmQsc2NyaXB0UHJvcHM6d30pPT57bGV0IHA9SlNPTi5zdHJpbmdpZnkoW3MsaSxhLGUsaCxsLHUsbV0pLnNsaWNlKDEsLTEpO3JldHVybiB0LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIix7Li4udyxzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6ITAsbm9uY2U6dHlwZW9mIHdpbmRvdz09XCJ1bmRlZmluZWRcIj9kOlwiXCIsZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6e19faHRtbDpgKCR7TS50b1N0cmluZygpfSkoJHtwfSlgfX0pfSksSD0oZSxpKT0+e2lmKE8pcmV0dXJuO2xldCBzO3RyeXtzPWxvY2FsU3RvcmFnZS5nZXRJdGVtKGUpfHx2b2lkIDB9Y2F0Y2godSl7fXJldHVybiBzfHxpfSxXPWU9PntsZXQgaT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7cmV0dXJuIGUmJmkuc2V0QXR0cmlidXRlKFwibm9uY2VcIixlKSxpLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKFwiKiwqOjpiZWZvcmUsKjo6YWZ0ZXJ7LXdlYmtpdC10cmFuc2l0aW9uOm5vbmUhaW1wb3J0YW50Oy1tb3otdHJhbnNpdGlvbjpub25lIWltcG9ydGFudDstby10cmFuc2l0aW9uOm5vbmUhaW1wb3J0YW50Oy1tcy10cmFuc2l0aW9uOm5vbmUhaW1wb3J0YW50O3RyYW5zaXRpb246bm9uZSFpbXBvcnRhbnR9XCIpKSxkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGkpLCgpPT57d2luZG93LmdldENvbXB1dGVkU3R5bGUoZG9jdW1lbnQuYm9keSksc2V0VGltZW91dCgoKT0+e2RvY3VtZW50LmhlYWQucmVtb3ZlQ2hpbGQoaSl9LDEpfX0sRT1lPT4oZXx8KGU9d2luZG93Lm1hdGNoTWVkaWEoSSkpLGUubWF0Y2hlcz9cImRhcmtcIjpcImxpZ2h0XCIpO2V4cG9ydHtKIGFzIFRoZW1lUHJvdmlkZXIseiBhcyB1c2VUaGVtZX07XG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBQXFDLElBQUksS0FBRyxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLE1BQUk7Q0FBQyxJQUFJLElBQUUsU0FBUyxpQkFBZ0IsSUFBRSxDQUFDLFNBQVEsTUFBTTtDQUFFLFNBQVMsRUFBRSxHQUFFO0VBQUMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFFLElBQUUsQ0FBQyxDQUFDLEVBQUEsQ0FBRyxTQUFRLE1BQUc7R0FBQyxJQUFJLElBQUUsTUFBSSxTQUFRLElBQUUsS0FBRyxJQUFFLEVBQUUsS0FBSSxNQUFHLEVBQUUsTUFBSSxDQUFDLElBQUU7R0FBRSxLQUFHLEVBQUUsVUFBVSxPQUFPLEdBQUcsQ0FBQyxHQUFFLEVBQUUsVUFBVSxJQUFJLEtBQUcsRUFBRSxLQUFHLEVBQUUsS0FBRyxDQUFDLEtBQUcsRUFBRSxhQUFhLEdBQUUsQ0FBQztFQUFDLENBQUMsR0FBRSxFQUFFLENBQUM7Q0FBQztDQUFDLFNBQVMsRUFBRSxHQUFFO0VBQUMsS0FBRyxFQUFFLFNBQVMsQ0FBQyxNQUFJLEVBQUUsTUFBTSxjQUFZO0NBQUU7Q0FBQyxTQUFTLElBQUc7RUFBQyxPQUFPLE9BQU8sV0FBVyw4QkFBOEIsQ0FBQyxDQUFDLFVBQVEsU0FBTztDQUFPO0NBQUMsSUFBRyxHQUFFLEVBQUUsQ0FBQztNQUFPLElBQUc7RUFBQyxJQUFJLElBQUUsYUFBYSxRQUFRLENBQUMsS0FBRztFQUEwQixFQUF0QixLQUFHLE1BQUksV0FBUyxFQUFFLElBQUUsQ0FBSztDQUFDLFNBQU8sR0FBRSxDQUFDO0FBQUM7QUFBRSxJQUFJLElBQUUsQ0FBQyxTQUFRLE1BQU07QUFBRSxJQUFBLElBQUU7QUFBK0IsSUFBQSxJQUFFLE9BQU8sVUFBUTtBQUFZLElBQUEsSUFBQSxhQUFJLGNBQWMsS0FBSyxDQUFDO0FBQUUsSUFBQSxJQUFFO0NBQUMsV0FBUyxNQUFHLENBQUM7Q0FBRSxRQUFPLENBQUM7QUFBQztBQUFFLElBQUEsVUFBTTtDQUFDLElBQUk7Q0FBRSxRQUFPLElBQUEsYUFBSSxXQUFXLENBQUMsTUFBSSxPQUFLLElBQUU7QUFBQztBQUFFLElBQUEsS0FBRSxNQUFBLGFBQUssV0FBVyxDQUFDLElBQUEsYUFBSSxjQUFBLGFBQWdCLFVBQVMsTUFBSyxFQUFFLFFBQVEsSUFBQSxhQUFJLGNBQWMsR0FBRSxFQUFDLEdBQUcsRUFBQyxDQUFDO0FBQUUsSUFBQSxJQUFFLENBQUMsU0FBUSxNQUFNO0FBQUUsSUFBQSxLQUFHLEVBQUMsYUFBWSxHQUFFLDJCQUEwQixJQUFFLENBQUMsR0FBRSxjQUFhLElBQUUsQ0FBQyxHQUFFLG1CQUFrQixJQUFFLENBQUMsR0FBRSxZQUFXLElBQUUsU0FBUSxRQUFPLElBQUUsR0FBRSxjQUFhLElBQUUsSUFBRSxXQUFTLFNBQVEsV0FBVSxJQUFFLGNBQWEsT0FBTSxHQUFFLFVBQVMsR0FBRSxPQUFNLEdBQUUsYUFBWSxRQUFLO0NBQUMsSUFBRyxDQUFDLEdBQUUsS0FBQSxhQUFLLGVBQWEsRUFBRSxHQUFFLENBQUMsQ0FBQyxHQUFFLENBQUMsR0FBRSxLQUFBLGFBQUssZUFBYSxNQUFJLFdBQVMsRUFBRSxJQUFFLENBQUMsR0FBRSxJQUFFLElBQUUsT0FBTyxPQUFPLENBQUMsSUFBRSxHQUFFLElBQUEsYUFBSSxhQUFZLE1BQUc7RUFBQyxJQUFJLElBQUU7RUFBRSxJQUFHLENBQUMsR0FBRTtFQUFPLE1BQUksWUFBVSxNQUFJLElBQUUsRUFBRTtFQUFHLElBQUksSUFBRSxJQUFFLEVBQUUsS0FBRyxHQUFFLElBQUUsSUFBRSxFQUFFLENBQUMsSUFBRSxNQUFLLElBQUUsU0FBUyxpQkFBZ0IsS0FBRSxNQUFHO0dBQUMsTUFBSSxXQUFTLEVBQUUsVUFBVSxPQUFPLEdBQUcsQ0FBQyxHQUFFLEtBQUcsRUFBRSxVQUFVLElBQUksQ0FBQyxLQUFHLEVBQUUsV0FBVyxPQUFPLE1BQUksSUFBRSxFQUFFLGFBQWEsR0FBRSxDQUFDLElBQUUsRUFBRSxnQkFBZ0IsQ0FBQztFQUFFO0VBQUUsSUFBRyxNQUFNLFFBQVEsQ0FBQyxJQUFFLEVBQUUsUUFBUSxDQUFDLElBQUUsRUFBRSxDQUFDLEdBQUUsR0FBRTtHQUFDLElBQUksSUFBRSxFQUFFLFNBQVMsQ0FBQyxJQUFFLElBQUUsTUFBSyxJQUFFLEVBQUUsU0FBUyxDQUFDLElBQUUsSUFBRTtHQUFFLEVBQUUsTUFBTSxjQUFZO0VBQUM7RUFBQyxJQUFXO0NBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxHQUFFLElBQUEsYUFBSSxhQUFZLE1BQUc7RUFBQyxJQUFJLElBQUUsT0FBTyxLQUFHLGFBQVcsRUFBRSxDQUFDLElBQUU7RUFBRSxFQUFFLENBQUM7RUFBRSxJQUFHO0dBQUMsYUFBYSxRQUFRLEdBQUUsQ0FBQztFQUFDLFNBQU8sR0FBRSxDQUFDO0NBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxHQUFFLElBQUEsYUFBSSxhQUFZLE1BQUc7RUFBQyxJQUFJLElBQUUsRUFBRSxDQUFDO0VBQUUsRUFBRSxDQUFDLEdBQUUsTUFBSSxZQUFVLEtBQUcsQ0FBQyxLQUFHLEVBQUUsUUFBUTtDQUFDLEdBQUUsQ0FBQyxHQUFFLENBQUMsQ0FBQztDQUFFLGFBQUUsZ0JBQWM7RUFBQyxJQUFJLElBQUUsT0FBTyxXQUFXLENBQUM7RUFBRSxPQUFPLEVBQUUsWUFBWSxDQUFDLEdBQUUsRUFBRSxDQUFDLFNBQU0sRUFBRSxlQUFlLENBQUM7Q0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUEsYUFBSSxnQkFBYztFQUFDLElBQUksS0FBRSxNQUFHO0dBQUMsRUFBRSxRQUFNLE1BQUksRUFBRSxXQUFTLEVBQUUsRUFBRSxRQUFRLElBQUUsRUFBRSxDQUFDO0VBQUU7RUFBRSxPQUFPLE9BQU8saUJBQWlCLFdBQVUsQ0FBQyxTQUFNLE9BQU8sb0JBQW9CLFdBQVUsQ0FBQztDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsR0FBQSxhQUFJLGdCQUFjO0VBQUMsRUFBRSxLQUFHLE9BQUssSUFBRSxDQUFDO0NBQUMsR0FBRSxDQUFDLEdBQUUsQ0FBQyxDQUFDO0NBQUUsSUFBSSxJQUFBLGFBQUksZUFBYTtFQUFDLE9BQU07RUFBRSxVQUFTO0VBQUUsYUFBWTtFQUFFLGVBQWMsTUFBSSxXQUFTLElBQUU7RUFBRSxRQUFPLElBQUUsQ0FBQyxHQUFHLEdBQUUsUUFBUSxJQUFFO0VBQUUsYUFBWSxJQUFFLElBQUUsS0FBSztDQUFDLElBQUc7RUFBQztFQUFFO0VBQUU7RUFBRTtFQUFFO0VBQUU7Q0FBQyxDQUFDO0NBQUUsT0FBQSxhQUFTLGNBQWMsRUFBRSxVQUFTLEVBQUMsT0FBTSxFQUFDLEdBQUEsYUFBSSxjQUFjLEdBQUU7RUFBQyxhQUFZO0VBQUUsWUFBVztFQUFFLFdBQVU7RUFBRSxjQUFhO0VBQUUsbUJBQWtCO0VBQUUsY0FBYTtFQUFFLE9BQU07RUFBRSxRQUFPO0VBQUUsT0FBTTtFQUFFLGFBQVk7Q0FBQyxDQUFDLEdBQUUsQ0FBQztBQUFDO0FBQUUsSUFBQSxJQUFBLGFBQUksTUFBTSxFQUFDLGFBQVksR0FBRSxZQUFXLEdBQUUsV0FBVSxHQUFFLGNBQWEsR0FBRSxtQkFBa0IsR0FBRSxjQUFhLEdBQUUsT0FBTSxHQUFFLFFBQU8sR0FBRSxPQUFNLEdBQUUsYUFBWSxRQUFLO0NBQUMsSUFBSSxJQUFFLEtBQUssVUFBVTtFQUFDO0VBQUU7RUFBRTtFQUFFO0VBQUU7RUFBRTtFQUFFO0VBQUU7Q0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUUsRUFBRTtDQUFFLE9BQUEsYUFBUyxjQUFjLFVBQVM7RUFBQyxHQUFHO0VBQUUsMEJBQXlCLENBQUM7RUFBRSxPQUFNLE9BQU8sVUFBUSxjQUFZLElBQUU7RUFBRyx5QkFBd0IsRUFBQyxRQUFPLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEdBQUU7Q0FBQyxDQUFDO0FBQUMsQ0FBQztBQUFFLElBQUEsS0FBRyxHQUFFLE1BQUk7Q0FBQyxJQUFHLEdBQUU7Q0FBTyxJQUFJO0NBQUUsSUFBRztFQUFDLElBQUUsYUFBYSxRQUFRLENBQUMsS0FBRyxLQUFLO0NBQUMsU0FBTyxHQUFFLENBQUM7Q0FBQyxPQUFPLEtBQUc7QUFBQztBQUFFLElBQUEsS0FBRSxNQUFHO0NBQUMsSUFBSSxJQUFFLFNBQVMsY0FBYyxPQUFPO0NBQUUsT0FBTyxLQUFHLEVBQUUsYUFBYSxTQUFRLENBQUMsR0FBRSxFQUFFLFlBQVksU0FBUyxlQUFlLDZLQUE2SyxDQUFDLEdBQUUsU0FBUyxLQUFLLFlBQVksQ0FBQyxTQUFNO0VBQUMsT0FBTyxpQkFBaUIsU0FBUyxJQUFJLEdBQUUsaUJBQWU7R0FBQyxTQUFTLEtBQUssWUFBWSxDQUFDO0VBQUMsR0FBRSxDQUFDO0NBQUM7QUFBQztBQUFFLElBQUEsS0FBRSxPQUFJLE1BQUksSUFBRSxPQUFPLFdBQVcsQ0FBQyxJQUFHLEVBQUUsVUFBUSxTQUFPIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==