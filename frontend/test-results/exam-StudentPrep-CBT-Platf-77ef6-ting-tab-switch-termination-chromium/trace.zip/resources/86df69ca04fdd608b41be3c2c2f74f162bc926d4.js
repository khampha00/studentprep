import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/sonner.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { useTheme } from "/node_modules/.vite/deps/next-themes.js?v=4066a8f3";
import { Toaster as Sonner } from "/node_modules/.vite/deps/sonner.js?v=8dd6803b";
import { RiCheckboxCircleLine, RiInformationLine, RiErrorWarningLine, RiCloseCircleLine, RiLoaderLine } from "/node_modules/.vite/deps/@remixicon_react.js?v=74eacaa8";
var _jsxFileName = "C:/Users/User/Desktop/studentprep/frontend/src/components/ui/sonner.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cdd924ad";
var _s = $RefreshSig$();
const Toaster = ({ ...props }) => {
	_s();
	const { theme = "system" } = useTheme();
	return /* @__PURE__ */ _jsxDEV(Sonner, {
		theme,
		className: "toaster group",
		icons: {
			success: /* @__PURE__ */ _jsxDEV(RiCheckboxCircleLine, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 11
			}, this),
			info: /* @__PURE__ */ _jsxDEV(RiInformationLine, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 11
			}, this),
			warning: /* @__PURE__ */ _jsxDEV(RiErrorWarningLine, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 11
			}, this),
			error: /* @__PURE__ */ _jsxDEV(RiCloseCircleLine, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 11
			}, this),
			loading: /* @__PURE__ */ _jsxDEV(RiLoaderLine, { className: "size-4 animate-spin" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 11
			}, this)
		},
		style: {
			"--normal-bg": "var(--popover)",
			"--normal-text": "var(--popover-foreground)",
			"--normal-border": "var(--border)",
			"--border-radius": "var(--radius)"
		},
		toastOptions: { classNames: { toast: "cn-toast" } },
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
};
_s(Toaster, "EriOrahfenYKDCErPq+L6926Dw4=", false, function() {
	return [useTheme];
});
_c = Toaster;
export { Toaster };
var _c;
$RefreshReg$(_c, "Toaster");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/sonner.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/User/Desktop/studentprep/frontend/src/components/ui/sonner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/User/Desktop/studentprep/frontend/src/components/ui/sonner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/User/Desktop/studentprep/frontend/src/components/ui/sonner.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxXQUFXLGNBQWlDO0FBQ3JELFNBQVMsc0JBQXNCLG1CQUFtQixvQkFBb0IsbUJBQW1CLG9CQUFvQjs7OztBQUU3RyxNQUFNLFdBQVcsRUFBRSxHQUFHLFlBQTBCOztDQUM5QyxNQUFNLEVBQUUsUUFBUSxhQUFhLFNBQVM7Q0FFdEMsT0FDRSx3QkFBQyxRQUFEO0VBQ1M7RUFDUCxXQUFVO0VBQ1YsT0FBTztHQUNMLFNBQ0Usd0JBQUMsc0JBQUQsRUFBc0IsV0FBVSxTQUFVOzs7OztHQUU1QyxNQUNFLHdCQUFDLG1CQUFELEVBQW1CLFdBQVUsU0FBVTs7Ozs7R0FFekMsU0FDRSx3QkFBQyxvQkFBRCxFQUFvQixXQUFVLFNBQVU7Ozs7O0dBRTFDLE9BQ0Usd0JBQUMsbUJBQUQsRUFBbUIsV0FBVSxTQUFVOzs7OztHQUV6QyxTQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHNCQUF1Qjs7Ozs7RUFFbkQ7RUFDQSxPQUNFO0dBQ0UsZUFBZTtHQUNmLGlCQUFpQjtHQUNqQixtQkFBbUI7R0FDbkIsbUJBQW1CO0VBQ3JCO0VBRUYsY0FBYyxFQUNaLFlBQVksRUFDVixPQUFPLFdBQ1QsRUFDRjtFQUNBLEdBQUk7Q0FDTDs7Ozs7QUFFTDs7Ozs7QUFFQSxTQUFTIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInNvbm5lci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tIFwibmV4dC10aGVtZXNcIlxuaW1wb3J0IHsgVG9hc3RlciBhcyBTb25uZXIsIHR5cGUgVG9hc3RlclByb3BzIH0gZnJvbSBcInNvbm5lclwiXG5pbXBvcnQgeyBSaUNoZWNrYm94Q2lyY2xlTGluZSwgUmlJbmZvcm1hdGlvbkxpbmUsIFJpRXJyb3JXYXJuaW5nTGluZSwgUmlDbG9zZUNpcmNsZUxpbmUsIFJpTG9hZGVyTGluZSB9IGZyb20gXCJAcmVtaXhpY29uL3JlYWN0XCJcblxuY29uc3QgVG9hc3RlciA9ICh7IC4uLnByb3BzIH06IFRvYXN0ZXJQcm9wcykgPT4ge1xuICBjb25zdCB7IHRoZW1lID0gXCJzeXN0ZW1cIiB9ID0gdXNlVGhlbWUoKVxuXG4gIHJldHVybiAoXG4gICAgPFNvbm5lclxuICAgICAgdGhlbWU9e3RoZW1lIGFzIFRvYXN0ZXJQcm9wc1tcInRoZW1lXCJdfVxuICAgICAgY2xhc3NOYW1lPVwidG9hc3RlciBncm91cFwiXG4gICAgICBpY29ucz17e1xuICAgICAgICBzdWNjZXNzOiAoXG4gICAgICAgICAgPFJpQ2hlY2tib3hDaXJjbGVMaW5lIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+XG4gICAgICAgICksXG4gICAgICAgIGluZm86IChcbiAgICAgICAgICA8UmlJbmZvcm1hdGlvbkxpbmUgY2xhc3NOYW1lPVwic2l6ZS00XCIgLz5cbiAgICAgICAgKSxcbiAgICAgICAgd2FybmluZzogKFxuICAgICAgICAgIDxSaUVycm9yV2FybmluZ0xpbmUgY2xhc3NOYW1lPVwic2l6ZS00XCIgLz5cbiAgICAgICAgKSxcbiAgICAgICAgZXJyb3I6IChcbiAgICAgICAgICA8UmlDbG9zZUNpcmNsZUxpbmUgY2xhc3NOYW1lPVwic2l6ZS00XCIgLz5cbiAgICAgICAgKSxcbiAgICAgICAgbG9hZGluZzogKFxuICAgICAgICAgIDxSaUxvYWRlckxpbmUgY2xhc3NOYW1lPVwic2l6ZS00IGFuaW1hdGUtc3BpblwiIC8+XG4gICAgICAgICksXG4gICAgICB9fVxuICAgICAgc3R5bGU9e1xuICAgICAgICB7XG4gICAgICAgICAgXCItLW5vcm1hbC1iZ1wiOiBcInZhcigtLXBvcG92ZXIpXCIsXG4gICAgICAgICAgXCItLW5vcm1hbC10ZXh0XCI6IFwidmFyKC0tcG9wb3Zlci1mb3JlZ3JvdW5kKVwiLFxuICAgICAgICAgIFwiLS1ub3JtYWwtYm9yZGVyXCI6IFwidmFyKC0tYm9yZGVyKVwiLFxuICAgICAgICAgIFwiLS1ib3JkZXItcmFkaXVzXCI6IFwidmFyKC0tcmFkaXVzKVwiLFxuICAgICAgICB9IGFzIFJlYWN0LkNTU1Byb3BlcnRpZXNcbiAgICAgIH1cbiAgICAgIHRvYXN0T3B0aW9ucz17e1xuICAgICAgICBjbGFzc05hbWVzOiB7XG4gICAgICAgICAgdG9hc3Q6IFwiY24tdG9hc3RcIixcbiAgICAgICAgfSxcbiAgICAgIH19XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQgeyBUb2FzdGVyIH1cbiJdfQ==