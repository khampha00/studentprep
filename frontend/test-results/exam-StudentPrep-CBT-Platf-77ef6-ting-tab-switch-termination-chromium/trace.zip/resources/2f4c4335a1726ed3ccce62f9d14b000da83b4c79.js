import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=076f3cfd";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=cdd924ad";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=cdd924ad";
import { T as useIsoLayoutEffect, c as useStableCallback, d as EMPTY_ARRAY, f as EMPTY_OBJECT, i as useRenderElement, m as useRefWithInit, n as useCompositeRootContext, p as NOOP, u as useMergedRefs, y as isElement } from "/node_modules/.vite/deps/CompositeRootContext-D1Svtiq7.js?v=076f3cfd";
import { c as createChangeEventDetails, i as useTransitionStatus, n as transitionStatusMapping, o as visuallyHidden, p as none, r as useOpenChangeComplete, s as visuallyHiddenInput } from "/node_modules/.vite/deps/stateAttributesMapping-Da3c5kE6.js?v=076f3cfd";
import { t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-B8kiyj7L.js?v=076f3cfd";
import { n as dispatchClickWithModifiers, t as useButton } from "/node_modules/.vite/deps/useButton-B5DKzZ8P.js?v=076f3cfd";
import { i as useFieldRootContext, l as fieldValidityMapping, n as useRadioGroupContext, o as useCompositeListContext, r as useLabelableContext, s as ACTIVE_COMPOSITE_ITEM } from "/node_modules/.vite/deps/RadioGroupContext-Cpb2051b.js?v=076f3cfd";
//#region node_modules/@base-ui/react/radio/utils/stateAttributesMapping.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var stateAttributesMapping = {
	checked(value) {
		if (value) return { "data-checked": "" };
		return { "data-unchecked": "" };
	},
	...transitionStatusMapping,
	...fieldValidityMapping
};
//#endregion
//#region node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs
/**
* Used to register a list item and its index (DOM position) in the `CompositeList`.
*/
function useCompositeListItem(params = {}) {
	const { guess, label, metadata, textRef, index: externalIndex } = params;
	const { register, unregister, subscribeMapChange, nextIndexRef } = useCompositeListContext();
	const indexRef = import_react.useRef(-1);
	const [internalIndex, setInternalIndex] = import_react.useState(externalIndex == null && guess ? () => {
		if (indexRef.current === -1) {
			const newIndex = nextIndexRef.current;
			nextIndexRef.current += 1;
			indexRef.current = newIndex;
		}
		return indexRef.current;
	} : -1);
	const index = externalIndex ?? internalIndex;
	const componentRef = import_react.useRef(null);
	const ref = import_react.useCallback((node) => {
		const previousNode = componentRef.current;
		if (previousNode) unregister(previousNode);
		componentRef.current = node;
		if (node) register(node, {
			metadata: metadata ?? null,
			index: externalIndex ?? null,
			label,
			textRef
		});
	}, [
		externalIndex,
		register,
		unregister,
		metadata,
		label,
		textRef
	]);
	useIsoLayoutEffect(() => {
		if (externalIndex != null) return;
		return subscribeMapChange((map) => {
			const i = componentRef.current ? map.get(componentRef.current)?.index : null;
			if (i != null) setInternalIndex(i);
		});
	}, [externalIndex, subscribeMapChange]);
	return {
		ref,
		index
	};
}
//#endregion
//#region node_modules/@base-ui/react/internals/composite/item/useCompositeItem.mjs
function useCompositeItem(params = {}) {
	const { highlightItemOnHover, highlightedIndex, onHighlightedIndexChange } = useCompositeRootContext();
	const { ref, index } = useCompositeListItem(params);
	const isHighlighted = highlightedIndex === index;
	const itemRef = import_react.useRef(null);
	const mergedRef = useMergedRefs(ref, itemRef);
	return {
		compositeProps: {
			tabIndex: isHighlighted ? 0 : -1,
			onFocus() {
				onHighlightedIndexChange(index);
			},
			onMouseMove() {
				const item = itemRef.current;
				if (!highlightItemOnHover || !item) return;
				const disabled = item.hasAttribute("disabled") || item.ariaDisabled === "true";
				if (!isHighlighted && !disabled) item.focus();
			}
		},
		compositeRef: mergedRef,
		index
	};
}
//#endregion
//#region node_modules/@base-ui/react/internals/composite/item/CompositeItem.mjs
function CompositeItem(componentProps) {
	const { render, className, style, state = EMPTY_OBJECT, props = EMPTY_ARRAY, refs = EMPTY_ARRAY, metadata, stateAttributesMapping, tag = "div", ...elementProps } = componentProps;
	const { compositeProps, compositeRef } = useCompositeItem({ metadata });
	return useRenderElement(tag, componentProps, {
		state,
		ref: [compositeRef, ...refs],
		props: [
			compositeProps,
			...props,
			elementProps
		],
		stateAttributesMapping
	});
}
//#endregion
//#region node_modules/@base-ui/react/field/item/FieldItemContext.mjs
var FieldItemContext = /*#__PURE__*/ import_react.createContext({ disabled: false });
FieldItemContext.displayName = "FieldItemContext";
function useFieldItemContext() {
	return import_react.useContext(FieldItemContext);
}
//#endregion
//#region node_modules/@base-ui/react/internals/labelable-provider/useAriaLabelledBy.mjs
function useAriaLabelledBy(explicitAriaLabelledBy, labelId, labelSourceRef, enableFallback = true, labelSourceId) {
	const [fallbackAriaLabelledBy, setFallbackAriaLabelledBy] = import_react.useState();
	const generatedLabelId = useBaseUiId(labelSourceId ? `${labelSourceId}-label` : void 0);
	const ariaLabelledBy = explicitAriaLabelledBy ?? labelId ?? fallbackAriaLabelledBy;
	useIsoLayoutEffect(() => {
		const nextAriaLabelledBy = explicitAriaLabelledBy || labelId || !enableFallback ? void 0 : getAriaLabelledBy(labelSourceRef.current, generatedLabelId);
		if (fallbackAriaLabelledBy !== nextAriaLabelledBy) setFallbackAriaLabelledBy(nextAriaLabelledBy);
	});
	return ariaLabelledBy;
}
function getAriaLabelledBy(labelSource, generatedLabelId) {
	const label = findAssociatedLabel(labelSource);
	if (!label) return;
	if (!label.id && generatedLabelId) label.id = generatedLabelId;
	return label.id || void 0;
}
function findAssociatedLabel(labelSource) {
	if (!labelSource) return;
	const parent = labelSource.parentElement;
	if (parent && parent.tagName === "LABEL") return parent;
	const controlId = labelSource.id;
	if (controlId) {
		const nextSibling = labelSource.nextElementSibling;
		if (nextSibling && nextSibling.htmlFor === controlId) return nextSibling;
	}
	const labels = labelSource.labels;
	return labels && labels[0];
}
//#endregion
//#region node_modules/@base-ui/react/internals/labelable-provider/useLabelableId.mjs
function useLabelableId(params = {}) {
	const { id, implicit = false, controlRef } = params;
	const { controlId, registerControlId } = useLabelableContext();
	const defaultId = useBaseUiId(id);
	const controlIdForEffect = implicit ? controlId : void 0;
	const controlSourceRef = useRefWithInit(() => Symbol());
	const hasRegisteredRef = import_react.useRef(false);
	const hadExplicitIdRef = import_react.useRef(id != null);
	const unregisterControlId = useStableCallback(() => {
		if (!hasRegisteredRef.current || registerControlId === NOOP) return;
		hasRegisteredRef.current = false;
		registerControlId(controlSourceRef.current, void 0);
	});
	useIsoLayoutEffect(() => {
		if (registerControlId === NOOP) return;
		let nextId;
		if (implicit) {
			const elem = controlRef?.current;
			if (isElement(elem) && elem.closest("label") != null) nextId = id ?? null;
			else nextId = controlIdForEffect ?? defaultId;
		} else if (id != null) {
			hadExplicitIdRef.current = true;
			nextId = id;
		} else if (hadExplicitIdRef.current) nextId = defaultId;
		else {
			unregisterControlId();
			return;
		}
		if (nextId === void 0) {
			unregisterControlId();
			return;
		}
		hasRegisteredRef.current = true;
		registerControlId(controlSourceRef.current, nextId);
	}, [
		id,
		controlRef,
		controlIdForEffect,
		registerControlId,
		implicit,
		defaultId,
		controlSourceRef,
		unregisterControlId
	]);
	import_react.useEffect(() => {
		return unregisterControlId;
	}, [unregisterControlId]);
	return controlId ?? defaultId;
}
//#endregion
//#region node_modules/@base-ui/react/internals/serializeValue.mjs
function serializeValue(value) {
	if (value == null) return "";
	if (typeof value === "string") return value;
	try {
		return JSON.stringify(value);
	} catch {
		return String(value);
	}
}
//#endregion
//#region node_modules/@base-ui/react/radio/root/RadioRootContext.mjs
var RadioRootContext = /*#__PURE__*/ import_react.createContext(void 0);
RadioRootContext.displayName = "RadioRootContext";
function useRadioRootContext() {
	const value = import_react.useContext(RadioRootContext);
	if (value === void 0) throw new Error("Base UI: RadioRootContext is missing. Radio parts must be placed within <Radio.Root>.");
	return value;
}
//#endregion
//#region node_modules/@base-ui/react/radio/root/RadioRoot.mjs
var import_jsx_runtime = require_jsx_runtime();
var RadioRoot = /*#__PURE__*/ import_react.forwardRef(function RadioRoot(componentProps, forwardedRef) {
	const { render, className, disabled: disabledProp = false, readOnly: readOnlyProp = false, required: requiredProp = false, "aria-labelledby": ariaLabelledByProp, value, inputRef: inputRefProp, nativeButton = false, id: idProp, style, ...elementProps } = componentProps;
	const groupContext = useRadioGroupContext();
	const { disabled: disabledGroup, readOnly: readOnlyGroup, required: requiredGroup, form: formGroup, checkedValue, touched = false, validation, name, setCheckedValue = NOOP, setTouched = NOOP, registerInputRef = NOOP } = groupContext ?? {};
	const { setTouched: setFieldTouched, setFilled, state: fieldState, disabled: fieldDisabled } = useFieldRootContext();
	const fieldItemContext = useFieldItemContext();
	const { labelId, getDescriptionProps } = useLabelableContext();
	const disabled = fieldDisabled || fieldItemContext.disabled || disabledGroup || disabledProp;
	const readOnly = readOnlyGroup || readOnlyProp;
	const required = requiredGroup || requiredProp;
	const form = formGroup;
	const checked = groupContext ? checkedValue === value : value === "";
	const radioRef = import_react.useRef(null);
	const inputRef = import_react.useRef(null);
	const registerFieldInput = validation?.registerInput;
	const registerInput = import_react.useCallback((element) => registerFieldInput?.(element, {
		controlRef: radioRef,
		value: void 0
	}), [registerFieldInput]);
	const mergedInputRef = useMergedRefs(inputRefProp, inputRef, registerInputRef, registerInput);
	useIsoLayoutEffect(() => {
		if (inputRef.current?.checked) setFilled(true);
	}, [setFilled]);
	useIsoLayoutEffect(() => {
		if (!inputRef.current) return;
		if (disabled && checked) {
			registerInputRef(null);
			return;
		}
		registerInputRef(inputRef.current);
	}, [
		checked,
		disabled,
		registerInputRef
	]);
	const id = useBaseUiId();
	const inputId = useLabelableId({
		id: idProp,
		implicit: false,
		controlRef: radioRef
	});
	const hiddenInputId = nativeButton ? void 0 : inputId;
	const rootProps = {
		role: "radio",
		"aria-checked": checked,
		"aria-labelledby": useAriaLabelledBy(ariaLabelledByProp, labelId, inputRef, !nativeButton, hiddenInputId),
		[ACTIVE_COMPOSITE_ITEM]: checked ? "" : void 0,
		id: nativeButton ? inputId : id,
		onKeyDown(event) {
			if (event.key === "Enter") event.preventDefault();
		},
		onClick(event) {
			if (event.defaultPrevented || disabled || readOnly) return;
			event.preventDefault();
			const input = inputRef.current;
			if (!input) return;
			dispatchClickWithModifiers(input, event);
		},
		onFocus(event) {
			if (event.defaultPrevented || disabled || readOnly || !touched) return;
			inputRef.current?.click();
			setTouched(false);
		}
	};
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton,
		composite: false
	});
	const inputProps = {
		type: "radio",
		ref: mergedInputRef,
		form,
		id: hiddenInputId,
		name,
		tabIndex: -1,
		style: name ? visuallyHiddenInput : visuallyHidden,
		"aria-hidden": true,
		...value !== void 0 ? { value: serializeValue(value) } : EMPTY_OBJECT,
		disabled,
		checked,
		required,
		readOnly,
		onChange(event) {
			if (event.nativeEvent.defaultPrevented) return;
			if (disabled || readOnly || value === void 0) return;
			const details = createChangeEventDetails(none, event.nativeEvent);
			setCheckedValue(value, details);
			if (details.isCanceled) return;
			setFieldTouched(true);
		},
		onClick(event) {
			event.stopPropagation();
		},
		onFocus() {
			radioRef.current?.focus();
		}
	};
	const state = import_react.useMemo(() => ({
		...fieldState,
		required,
		disabled,
		readOnly,
		checked
	}), [
		fieldState,
		disabled,
		readOnly,
		checked,
		required
	]);
	const contextValue = state;
	const isRadioGroup = groupContext !== void 0;
	const refs = [
		forwardedRef,
		radioRef,
		buttonRef
	];
	const props = [
		rootProps,
		elementProps,
		getButtonProps,
		getDescriptionProps,
		validation ? (validationProps) => validation.getValidationProps(disabled, validationProps) : EMPTY_OBJECT
	];
	const element = useRenderElement("span", componentProps, {
		enabled: !isRadioGroup,
		state,
		ref: refs,
		props,
		stateAttributesMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(RadioRootContext.Provider, {
		value: contextValue,
		children: [isRadioGroup ? /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeItem, {
			tag: "span",
			render,
			className,
			style,
			state,
			refs,
			props,
			stateAttributesMapping
		}) : element, /*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
			...inputProps,
			suppressHydrationWarning: true
		})]
	});
});
RadioRoot.displayName = "RadioRoot";
//#endregion
//#region node_modules/@base-ui/react/radio/indicator/RadioIndicator.mjs
/**
* Indicates whether the radio button is selected.
* Renders a `<span>` element.
*
* Documentation: [Base UI Radio](https://base-ui.com/react/components/radio)
*/
var RadioIndicator = /*#__PURE__*/ import_react.forwardRef(function RadioIndicator(componentProps, forwardedRef) {
	const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
	const rootState = useRadioRootContext();
	const rendered = rootState.checked;
	const { mounted, transitionStatus, setMounted } = useTransitionStatus(rendered);
	const state = {
		...rootState,
		transitionStatus
	};
	const indicatorRef = import_react.useRef(null);
	const shouldRender = keepMounted || mounted;
	const element = useRenderElement("span", componentProps, {
		ref: [forwardedRef, indicatorRef],
		state,
		props: elementProps,
		stateAttributesMapping
	});
	useOpenChangeComplete({
		open: rendered,
		ref: indicatorRef,
		onComplete() {
			if (!rendered) setMounted(false);
		}
	});
	if (!shouldRender) return null;
	return element;
});
RadioIndicator.displayName = "RadioIndicator";
//#endregion
//#region node_modules/@base-ui/react/radio/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Indicator: () => RadioIndicator,
	Root: () => RadioRoot
});
//#endregion
export { index_parts_exports as Radio };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGJhc2UtdWlfcmVhY3RfcmFkaW8uanMiLCJuYW1lcyI6WyJSRUFTT05TLm5vbmUiXSwic291cmNlcyI6WyIuLi8uLi9AYmFzZS11aS9yZWFjdC9yYWRpby91dGlscy9zdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy9jb21wb3NpdGUvbGlzdC91c2VDb21wb3NpdGVMaXN0SXRlbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvY29tcG9zaXRlL2l0ZW0vdXNlQ29tcG9zaXRlSXRlbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvY29tcG9zaXRlL2l0ZW0vQ29tcG9zaXRlSXRlbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9maWVsZC9pdGVtL0ZpZWxkSXRlbUNvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2xhYmVsYWJsZS1wcm92aWRlci91c2VBcmlhTGFiZWxsZWRCeS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvbGFiZWxhYmxlLXByb3ZpZGVyL3VzZUxhYmVsYWJsZUlkLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy9zZXJpYWxpemVWYWx1ZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9yYWRpby9yb290L1JhZGlvUm9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvcmFkaW8vcm9vdC9SYWRpb1Jvb3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvcmFkaW8vaW5kaWNhdG9yL1JhZGlvSW5kaWNhdG9yLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3JhZGlvL2luZGV4LnBhcnRzLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IGZpZWxkVmFsaWRpdHlNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9maWVsZC1jb25zdGFudHMvY29uc3RhbnRzLm1qc1wiO1xuZXhwb3J0IGNvbnN0IHN0YXRlQXR0cmlidXRlc01hcHBpbmcgPSB7XG4gIGNoZWNrZWQodmFsdWUpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgICdkYXRhLWNoZWNrZWQnOiAnJ1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICdkYXRhLXVuY2hlY2tlZCc6ICcnXG4gICAgfTtcbiAgfSxcbiAgLi4udHJhbnNpdGlvblN0YXR1c01hcHBpbmcsXG4gIC4uLmZpZWxkVmFsaWRpdHlNYXBwaW5nXG59OyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZUNvbXBvc2l0ZUxpc3RDb250ZXh0IH0gZnJvbSBcIi4vQ29tcG9zaXRlTGlzdENvbnRleHQubWpzXCI7XG4vKipcbiAqIFVzZWQgdG8gcmVnaXN0ZXIgYSBsaXN0IGl0ZW0gYW5kIGl0cyBpbmRleCAoRE9NIHBvc2l0aW9uKSBpbiB0aGUgYENvbXBvc2l0ZUxpc3RgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQ29tcG9zaXRlTGlzdEl0ZW0ocGFyYW1zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGd1ZXNzLFxuICAgIGxhYmVsLFxuICAgIG1ldGFkYXRhLFxuICAgIHRleHRSZWYsXG4gICAgaW5kZXg6IGV4dGVybmFsSW5kZXhcbiAgfSA9IHBhcmFtcztcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIHVucmVnaXN0ZXIsXG4gICAgc3Vic2NyaWJlTWFwQ2hhbmdlLFxuICAgIG5leHRJbmRleFJlZlxuICB9ID0gdXNlQ29tcG9zaXRlTGlzdENvbnRleHQoKTtcblxuICAvLyBHdWVzcyB0aGUgaW5kZXggZnJvbSB0aGUgcmVuZGVyIG9yZGVyLiBUaGlzIGF2b2lkcyBhIHJlLXJlbmRlciBhZnRlciBtb3VudCBmb3JcbiAgLy8gZmxhdCBsaXN0cyByZW5kZXJlZCBpbiBET00gb3JkZXI7IHdoZW4gdGhlIGd1ZXNzIGlzIHdyb25nIChncm91cGVkIG9yIG91dC1vZi1vcmRlclxuICAvLyByZW5kZXJpbmcpLCB0aGUgY29tbWl0IGZsdXNoIGNvcnJlY3RzIGl0IGJlZm9yZSBwYWludC5cbiAgY29uc3QgaW5kZXhSZWYgPSBSZWFjdC51c2VSZWYoLTEpO1xuICBjb25zdCBbaW50ZXJuYWxJbmRleCwgc2V0SW50ZXJuYWxJbmRleF0gPSBSZWFjdC51c2VTdGF0ZShleHRlcm5hbEluZGV4ID09IG51bGwgJiYgZ3Vlc3MgPyAoKSA9PiB7XG4gICAgaWYgKGluZGV4UmVmLmN1cnJlbnQgPT09IC0xKSB7XG4gICAgICBjb25zdCBuZXdJbmRleCA9IG5leHRJbmRleFJlZi5jdXJyZW50O1xuICAgICAgbmV4dEluZGV4UmVmLmN1cnJlbnQgKz0gMTtcbiAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBuZXdJbmRleDtcbiAgICB9XG4gICAgcmV0dXJuIGluZGV4UmVmLmN1cnJlbnQ7XG4gIH0gOiAtMSk7XG4gIGNvbnN0IGluZGV4ID0gZXh0ZXJuYWxJbmRleCA/PyBpbnRlcm5hbEluZGV4O1xuICBjb25zdCBjb21wb25lbnRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG5cbiAgLy8gRGVsaWJlcmF0ZWx5IGlkZW50aXR5LXNlbnNpdGl2ZTogbmVzdGVkIGl0ZW1zIHNoYXJpbmcgb25lIERPTSBub2RlIHJlbHkgb24gcmVmIGF0dGFjaG1lbnRcbiAgLy8gb3JkZXIgdG8gZGVjaWRlIHdoaWNoIHJlZ2lzdHJhdGlvbiB3aW5zLCBhbmQgcmVwdWJsaXNoaW5nIGZyb20gYW4gZWZmZWN0IGluc3RlYWQgd291bGQgbGV0XG4gIC8vIGFuIGlubmVyIGl0ZW0ncyBsYXRlciB1cGRhdGUgc2lsZW50bHkgdGFrZSBvd25lcnNoaXAgZnJvbSB0aGUgb3V0ZXIgb25lLlxuICBjb25zdCByZWYgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBjb25zdCBwcmV2aW91c05vZGUgPSBjb21wb25lbnRSZWYuY3VycmVudDtcbiAgICBpZiAocHJldmlvdXNOb2RlKSB7XG4gICAgICB1bnJlZ2lzdGVyKHByZXZpb3VzTm9kZSk7XG4gICAgfVxuICAgIGNvbXBvbmVudFJlZi5jdXJyZW50ID0gbm9kZTtcbiAgICBpZiAobm9kZSkge1xuICAgICAgcmVnaXN0ZXIobm9kZSwge1xuICAgICAgICBtZXRhZGF0YTogbWV0YWRhdGEgPz8gbnVsbCxcbiAgICAgICAgaW5kZXg6IGV4dGVybmFsSW5kZXggPz8gbnVsbCxcbiAgICAgICAgbGFiZWwsXG4gICAgICAgIHRleHRSZWZcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW2V4dGVybmFsSW5kZXgsIHJlZ2lzdGVyLCB1bnJlZ2lzdGVyLCBtZXRhZGF0YSwgbGFiZWwsIHRleHRSZWZdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZXh0ZXJuYWxJbmRleCAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICByZXR1cm4gc3Vic2NyaWJlTWFwQ2hhbmdlKG1hcCA9PiB7XG4gICAgICBjb25zdCBpID0gY29tcG9uZW50UmVmLmN1cnJlbnQgPyBtYXAuZ2V0KGNvbXBvbmVudFJlZi5jdXJyZW50KT8uaW5kZXggOiBudWxsO1xuICAgICAgaWYgKGkgIT0gbnVsbCkge1xuICAgICAgICBzZXRJbnRlcm5hbEluZGV4KGkpO1xuICAgICAgfVxuICAgIH0pO1xuICB9LCBbZXh0ZXJuYWxJbmRleCwgc3Vic2NyaWJlTWFwQ2hhbmdlXSk7XG4gIHJldHVybiB7XG4gICAgcmVmLFxuICAgIGluZGV4XG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZXJnZWRSZWZzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlTWVyZ2VkUmVmcyc7XG5pbXBvcnQgeyB1c2VDb21wb3NpdGVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L0NvbXBvc2l0ZVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQ29tcG9zaXRlTGlzdEl0ZW0gfSBmcm9tIFwiLi4vbGlzdC91c2VDb21wb3NpdGVMaXN0SXRlbS5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VDb21wb3NpdGVJdGVtKHBhcmFtcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBoaWdobGlnaHRJdGVtT25Ib3ZlcixcbiAgICBoaWdobGlnaHRlZEluZGV4LFxuICAgIG9uSGlnaGxpZ2h0ZWRJbmRleENoYW5nZVxuICB9ID0gdXNlQ29tcG9zaXRlUm9vdENvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIHJlZixcbiAgICBpbmRleFxuICB9ID0gdXNlQ29tcG9zaXRlTGlzdEl0ZW0ocGFyYW1zKTtcbiAgY29uc3QgaXNIaWdobGlnaHRlZCA9IGhpZ2hsaWdodGVkSW5kZXggPT09IGluZGV4O1xuICBjb25zdCBpdGVtUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBtZXJnZWRSZWYgPSB1c2VNZXJnZWRSZWZzKHJlZiwgaXRlbVJlZik7XG4gIGNvbnN0IGNvbXBvc2l0ZVByb3BzID0ge1xuICAgIHRhYkluZGV4OiBpc0hpZ2hsaWdodGVkID8gMCA6IC0xLFxuICAgIG9uRm9jdXMoKSB7XG4gICAgICBvbkhpZ2hsaWdodGVkSW5kZXhDaGFuZ2UoaW5kZXgpO1xuICAgIH0sXG4gICAgb25Nb3VzZU1vdmUoKSB7XG4gICAgICBjb25zdCBpdGVtID0gaXRlbVJlZi5jdXJyZW50O1xuICAgICAgaWYgKCFoaWdobGlnaHRJdGVtT25Ib3ZlciB8fCAhaXRlbSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBkaXNhYmxlZCA9IGl0ZW0uaGFzQXR0cmlidXRlKCdkaXNhYmxlZCcpIHx8IGl0ZW0uYXJpYURpc2FibGVkID09PSAndHJ1ZSc7XG4gICAgICBpZiAoIWlzSGlnaGxpZ2h0ZWQgJiYgIWRpc2FibGVkKSB7XG4gICAgICAgIGl0ZW0uZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIHJldHVybiB7XG4gICAgY29tcG9zaXRlUHJvcHMsXG4gICAgY29tcG9zaXRlUmVmOiBtZXJnZWRSZWYsXG4gICAgaW5kZXhcbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IEVNUFRZX09CSkVDVCwgRU1QVFlfQVJSQVkgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VDb21wb3NpdGVJdGVtIH0gZnJvbSBcIi4vdXNlQ29tcG9zaXRlSXRlbS5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBDb21wb3NpdGVJdGVtKGNvbXBvbmVudFByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIHN0YXRlID0gRU1QVFlfT0JKRUNULFxuICAgIHByb3BzID0gRU1QVFlfQVJSQVksXG4gICAgcmVmcyA9IEVNUFRZX0FSUkFZLFxuICAgIG1ldGFkYXRhLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmcsXG4gICAgdGFnID0gJ2RpdicsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIGNvbXBvc2l0ZVByb3BzLFxuICAgIGNvbXBvc2l0ZVJlZlxuICB9ID0gdXNlQ29tcG9zaXRlSXRlbSh7XG4gICAgbWV0YWRhdGFcbiAgfSk7XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KHRhZywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICAvLyBUaGUgY29tcG9zaXRlIHJlZiBhdHRhY2hlcyBmaXJzdCBzbyBhbiBvdXRlciBpdGVtIHdpbnMgd2hlbiBuZXN0ZWQgaXRlbXMgc2hhcmUgYSBET00gbm9kZS5cbiAgICByZWY6IFtjb21wb3NpdGVSZWYsIC4uLnJlZnNdLFxuICAgIHByb3BzOiBbY29tcG9zaXRlUHJvcHMsIC4uLnByb3BzLCBlbGVtZW50UHJvcHNdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmdcbiAgfSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgRmllbGRJdGVtQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHtcbiAgZGlzYWJsZWQ6IGZhbHNlXG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEZpZWxkSXRlbUNvbnRleHQuZGlzcGxheU5hbWUgPSBcIkZpZWxkSXRlbUNvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VGaWVsZEl0ZW1Db250ZXh0KCkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChGaWVsZEl0ZW1Db250ZXh0KTtcbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vdXNlQmFzZVVpSWQubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlQXJpYUxhYmVsbGVkQnkoZXhwbGljaXRBcmlhTGFiZWxsZWRCeSwgbGFiZWxJZCwgbGFiZWxTb3VyY2VSZWYsIGVuYWJsZUZhbGxiYWNrID0gdHJ1ZSwgbGFiZWxTb3VyY2VJZCkge1xuICBjb25zdCBbZmFsbGJhY2tBcmlhTGFiZWxsZWRCeSwgc2V0RmFsbGJhY2tBcmlhTGFiZWxsZWRCeV0gPSBSZWFjdC51c2VTdGF0ZSgpO1xuICBjb25zdCBnZW5lcmF0ZWRMYWJlbElkID0gdXNlQmFzZVVpSWQobGFiZWxTb3VyY2VJZCA/IGAke2xhYmVsU291cmNlSWR9LWxhYmVsYCA6IHVuZGVmaW5lZCk7XG4gIGNvbnN0IGFyaWFMYWJlbGxlZEJ5ID0gZXhwbGljaXRBcmlhTGFiZWxsZWRCeSA/PyBsYWJlbElkID8/IGZhbGxiYWNrQXJpYUxhYmVsbGVkQnk7XG5cbiAgLy8gRmFsbGJhY2sgZm9yIDxzcGFuPiBjb250cm9scyBsYWJlbGxlZCBieSB3cmFwcGluZy9zaWJsaW5nIG5hdGl2ZSA8bGFiZWw+LlxuICAvLyBSdW4gYWZ0ZXIgZXZlcnkgY29tbWl0IHNvIERPTSBhc3NvY2lhdGlvbiBjaGFuZ2VzIChlLmcuIGxhYmVsIG1vdW50L3VubW91bnQpXG4gIC8vIGFyZSByZWZsZWN0ZWQgZXZlbiB3aGVuIHByb3BzL3N0YXRlIGRlcHMgYXJlIHVuY2hhbmdlZC5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG5leHRBcmlhTGFiZWxsZWRCeSA9IGV4cGxpY2l0QXJpYUxhYmVsbGVkQnkgfHwgbGFiZWxJZCB8fCAhZW5hYmxlRmFsbGJhY2sgPyB1bmRlZmluZWQgOiBnZXRBcmlhTGFiZWxsZWRCeShsYWJlbFNvdXJjZVJlZi5jdXJyZW50LCBnZW5lcmF0ZWRMYWJlbElkKTtcbiAgICBpZiAoZmFsbGJhY2tBcmlhTGFiZWxsZWRCeSAhPT0gbmV4dEFyaWFMYWJlbGxlZEJ5KSB7XG4gICAgICBzZXRGYWxsYmFja0FyaWFMYWJlbGxlZEJ5KG5leHRBcmlhTGFiZWxsZWRCeSk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGFyaWFMYWJlbGxlZEJ5O1xufVxuZnVuY3Rpb24gZ2V0QXJpYUxhYmVsbGVkQnkobGFiZWxTb3VyY2UsIGdlbmVyYXRlZExhYmVsSWQpIHtcbiAgY29uc3QgbGFiZWwgPSBmaW5kQXNzb2NpYXRlZExhYmVsKGxhYmVsU291cmNlKTtcbiAgaWYgKCFsYWJlbCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgaWYgKCFsYWJlbC5pZCAmJiBnZW5lcmF0ZWRMYWJlbElkKSB7XG4gICAgbGFiZWwuaWQgPSBnZW5lcmF0ZWRMYWJlbElkO1xuICB9XG4gIHJldHVybiBsYWJlbC5pZCB8fCB1bmRlZmluZWQ7XG59XG5mdW5jdGlvbiBmaW5kQXNzb2NpYXRlZExhYmVsKGxhYmVsU291cmNlKSB7XG4gIGlmICghbGFiZWxTb3VyY2UpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG5cbiAgLy8gRmFzdCBwYXRoIGJlZm9yZSB0aGUgZXhwZW5zaXZlIGAubGFiZWxzYCByZWFkLlxuICBjb25zdCBwYXJlbnQgPSBsYWJlbFNvdXJjZS5wYXJlbnRFbGVtZW50O1xuICBpZiAocGFyZW50ICYmIHBhcmVudC50YWdOYW1lID09PSAnTEFCRUwnKSB7XG4gICAgcmV0dXJuIHBhcmVudDtcbiAgfVxuICBjb25zdCBjb250cm9sSWQgPSBsYWJlbFNvdXJjZS5pZDtcbiAgaWYgKGNvbnRyb2xJZCkge1xuICAgIGNvbnN0IG5leHRTaWJsaW5nID0gbGFiZWxTb3VyY2UubmV4dEVsZW1lbnRTaWJsaW5nO1xuICAgIGlmIChuZXh0U2libGluZyAmJiBuZXh0U2libGluZy5odG1sRm9yID09PSBjb250cm9sSWQpIHtcbiAgICAgIHJldHVybiBuZXh0U2libGluZztcbiAgICB9XG4gIH1cbiAgY29uc3QgbGFiZWxzID0gbGFiZWxTb3VyY2UubGFiZWxzO1xuICByZXR1cm4gbGFiZWxzICYmIGxhYmVsc1swXTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlUmVmV2l0aEluaXQnO1xuaW1wb3J0IHsgaXNFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBOT09QIH0gZnJvbSBcIi4uL25vb3AubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IHVzZUxhYmVsYWJsZUNvbnRleHQgfSBmcm9tIFwiLi9MYWJlbGFibGVDb250ZXh0Lm1qc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUxhYmVsYWJsZUlkKHBhcmFtcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBpZCxcbiAgICBpbXBsaWNpdCA9IGZhbHNlLFxuICAgIGNvbnRyb2xSZWZcbiAgfSA9IHBhcmFtcztcbiAgY29uc3Qge1xuICAgIGNvbnRyb2xJZCxcbiAgICByZWdpc3RlckNvbnRyb2xJZFxuICB9ID0gdXNlTGFiZWxhYmxlQ29udGV4dCgpO1xuICBjb25zdCBkZWZhdWx0SWQgPSB1c2VCYXNlVWlJZChpZCk7XG4gIGNvbnN0IGNvbnRyb2xJZEZvckVmZmVjdCA9IGltcGxpY2l0ID8gY29udHJvbElkIDogdW5kZWZpbmVkO1xuICBjb25zdCBjb250cm9sU291cmNlUmVmID0gdXNlUmVmV2l0aEluaXQoKCkgPT4gU3ltYm9sKCkpO1xuICBjb25zdCBoYXNSZWdpc3RlcmVkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgaGFkRXhwbGljaXRJZFJlZiA9IFJlYWN0LnVzZVJlZihpZCAhPSBudWxsKTtcbiAgY29uc3QgdW5yZWdpc3RlckNvbnRyb2xJZCA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAoIWhhc1JlZ2lzdGVyZWRSZWYuY3VycmVudCB8fCByZWdpc3RlckNvbnRyb2xJZCA9PT0gTk9PUCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBoYXNSZWdpc3RlcmVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICByZWdpc3RlckNvbnRyb2xJZChjb250cm9sU291cmNlUmVmLmN1cnJlbnQsIHVuZGVmaW5lZCk7XG4gIH0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChyZWdpc3RlckNvbnRyb2xJZCA9PT0gTk9PUCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgbGV0IG5leHRJZDtcbiAgICBpZiAoaW1wbGljaXQpIHtcbiAgICAgIGNvbnN0IGVsZW0gPSBjb250cm9sUmVmPy5jdXJyZW50O1xuICAgICAgaWYgKGlzRWxlbWVudChlbGVtKSAmJiBlbGVtLmNsb3Nlc3QoJ2xhYmVsJykgIT0gbnVsbCkge1xuICAgICAgICBuZXh0SWQgPSBpZCA/PyBudWxsO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmV4dElkID0gY29udHJvbElkRm9yRWZmZWN0ID8/IGRlZmF1bHRJZDtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGlkICE9IG51bGwpIHtcbiAgICAgIGhhZEV4cGxpY2l0SWRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICBuZXh0SWQgPSBpZDtcbiAgICB9IGVsc2UgaWYgKGhhZEV4cGxpY2l0SWRSZWYuY3VycmVudCkge1xuICAgICAgbmV4dElkID0gZGVmYXVsdElkO1xuICAgIH0gZWxzZSB7XG4gICAgICB1bnJlZ2lzdGVyQ29udHJvbElkKCk7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAobmV4dElkID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHVucmVnaXN0ZXJDb250cm9sSWQoKTtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGhhc1JlZ2lzdGVyZWRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgcmVnaXN0ZXJDb250cm9sSWQoY29udHJvbFNvdXJjZVJlZi5jdXJyZW50LCBuZXh0SWQpO1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH0sIFtpZCwgY29udHJvbFJlZiwgY29udHJvbElkRm9yRWZmZWN0LCByZWdpc3RlckNvbnRyb2xJZCwgaW1wbGljaXQsIGRlZmF1bHRJZCwgY29udHJvbFNvdXJjZVJlZiwgdW5yZWdpc3RlckNvbnRyb2xJZF0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiB1bnJlZ2lzdGVyQ29udHJvbElkO1xuICB9LCBbdW5yZWdpc3RlckNvbnRyb2xJZF0pO1xuICByZXR1cm4gY29udHJvbElkID8/IGRlZmF1bHRJZDtcbn0iLCJleHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplVmFsdWUodmFsdWUpIHtcbiAgaWYgKHZhbHVlID09IG51bGwpIHtcbiAgICByZXR1cm4gJyc7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgdHJ5IHtcbiAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgfVxufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFJhZGlvUm9vdENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCh1bmRlZmluZWQpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgUmFkaW9Sb290Q29udGV4dC5kaXNwbGF5TmFtZSA9IFwiUmFkaW9Sb290Q29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVJhZGlvUm9vdENvbnRleHQoKSB7XG4gIGNvbnN0IHZhbHVlID0gUmVhY3QudXNlQ29udGV4dChSYWRpb1Jvb3RDb250ZXh0KTtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IFJhZGlvUm9vdENvbnRleHQgaXMgbWlzc2luZy4gUmFkaW8gcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxSYWRpby5Sb290Pi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSg1MikpO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1lcmdlZFJlZnMgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VNZXJnZWRSZWZzJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB2aXN1YWxseUhpZGRlbiwgdmlzdWFsbHlIaWRkZW5JbnB1dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3Zpc3VhbGx5SGlkZGVuJztcbmltcG9ydCB7IEVNUFRZX09CSkVDVCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IE5PT1AgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL25vb3AubWpzXCI7XG5pbXBvcnQgeyBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nIH0gZnJvbSBcIi4uL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyBkaXNwYXRjaENsaWNrV2l0aE1vZGlmaWVycyB9IGZyb20gXCIuLi8uLi91dGlscy9kaXNwYXRjaENsaWNrV2l0aE1vZGlmaWVycy5tanNcIjtcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBBQ1RJVkVfQ09NUE9TSVRFX0lURU0gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbXBvc2l0ZS9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyBDb21wb3NpdGVJdGVtIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvaXRlbS9Db21wb3NpdGVJdGVtLm1qc1wiO1xuaW1wb3J0IHsgdXNlRmllbGRSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZmllbGQtcm9vdC1jb250ZXh0L0ZpZWxkUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWVsZEl0ZW1Db250ZXh0IH0gZnJvbSBcIi4uLy4uL2ZpZWxkL2l0ZW0vRmllbGRJdGVtQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZUxhYmVsYWJsZUNvbnRleHQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2xhYmVsYWJsZS1wcm92aWRlci9MYWJlbGFibGVDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQXJpYUxhYmVsbGVkQnkgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2xhYmVsYWJsZS1wcm92aWRlci91c2VBcmlhTGFiZWxsZWRCeS5tanNcIjtcbmltcG9ydCB7IHVzZUxhYmVsYWJsZUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9sYWJlbGFibGUtcHJvdmlkZXIvdXNlTGFiZWxhYmxlSWQubWpzXCI7XG5pbXBvcnQgeyB1c2VSYWRpb0dyb3VwQ29udGV4dCB9IGZyb20gXCIuLi8uLi9yYWRpby1ncm91cC9SYWRpb0dyb3VwQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHNlcmlhbGl6ZVZhbHVlIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9zZXJpYWxpemVWYWx1ZS5tanNcIjtcbmltcG9ydCB7IFJhZGlvUm9vdENvbnRleHQgfSBmcm9tIFwiLi9SYWRpb1Jvb3RDb250ZXh0Lm1qc1wiO1xuXG4vKipcbiAqIFJlcHJlc2VudHMgdGhlIHJhZGlvIGJ1dHRvbiBpdHNlbGYuXG4gKiBSZW5kZXJzIGEgYDxzcGFuPmAgZWxlbWVudCBhbmQgYSBoaWRkZW4gYDxpbnB1dD5gIGJlc2lkZS5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBSYWRpb10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3JhZGlvKVxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCwganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IFJhZGlvUm9vdCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFJhZGlvUm9vdChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIGRpc2FibGVkOiBkaXNhYmxlZFByb3AgPSBmYWxzZSxcbiAgICByZWFkT25seTogcmVhZE9ubHlQcm9wID0gZmFsc2UsXG4gICAgcmVxdWlyZWQ6IHJlcXVpcmVkUHJvcCA9IGZhbHNlLFxuICAgICdhcmlhLWxhYmVsbGVkYnknOiBhcmlhTGFiZWxsZWRCeVByb3AsXG4gICAgdmFsdWUsXG4gICAgaW5wdXRSZWY6IGlucHV0UmVmUHJvcCxcbiAgICBuYXRpdmVCdXR0b24gPSBmYWxzZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IGdyb3VwQ29udGV4dCA9IHVzZVJhZGlvR3JvdXBDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBkaXNhYmxlZDogZGlzYWJsZWRHcm91cCxcbiAgICByZWFkT25seTogcmVhZE9ubHlHcm91cCxcbiAgICByZXF1aXJlZDogcmVxdWlyZWRHcm91cCxcbiAgICBmb3JtOiBmb3JtR3JvdXAsXG4gICAgY2hlY2tlZFZhbHVlLFxuICAgIHRvdWNoZWQgPSBmYWxzZSxcbiAgICB2YWxpZGF0aW9uLFxuICAgIG5hbWUsXG4gICAgc2V0Q2hlY2tlZFZhbHVlID0gTk9PUCxcbiAgICBzZXRUb3VjaGVkID0gTk9PUCxcbiAgICByZWdpc3RlcklucHV0UmVmID0gTk9PUFxuICB9ID0gZ3JvdXBDb250ZXh0ID8/IHt9O1xuICBjb25zdCB7XG4gICAgc2V0VG91Y2hlZDogc2V0RmllbGRUb3VjaGVkLFxuICAgIHNldEZpbGxlZCxcbiAgICBzdGF0ZTogZmllbGRTdGF0ZSxcbiAgICBkaXNhYmxlZDogZmllbGREaXNhYmxlZFxuICB9ID0gdXNlRmllbGRSb290Q29udGV4dCgpO1xuICBjb25zdCBmaWVsZEl0ZW1Db250ZXh0ID0gdXNlRmllbGRJdGVtQ29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgbGFiZWxJZCxcbiAgICBnZXREZXNjcmlwdGlvblByb3BzXG4gIH0gPSB1c2VMYWJlbGFibGVDb250ZXh0KCk7XG4gIGNvbnN0IGRpc2FibGVkID0gZmllbGREaXNhYmxlZCB8fCBmaWVsZEl0ZW1Db250ZXh0LmRpc2FibGVkIHx8IGRpc2FibGVkR3JvdXAgfHwgZGlzYWJsZWRQcm9wO1xuICBjb25zdCByZWFkT25seSA9IHJlYWRPbmx5R3JvdXAgfHwgcmVhZE9ubHlQcm9wO1xuICBjb25zdCByZXF1aXJlZCA9IHJlcXVpcmVkR3JvdXAgfHwgcmVxdWlyZWRQcm9wO1xuICBjb25zdCBmb3JtID0gZm9ybUdyb3VwO1xuICBjb25zdCBjaGVja2VkID0gZ3JvdXBDb250ZXh0ID8gY2hlY2tlZFZhbHVlID09PSB2YWx1ZSA6IHZhbHVlID09PSAnJztcbiAgY29uc3QgcmFkaW9SZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGlucHV0UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCByZWdpc3RlckZpZWxkSW5wdXQgPSB2YWxpZGF0aW9uPy5yZWdpc3RlcklucHV0O1xuICBjb25zdCByZWdpc3RlcklucHV0ID0gUmVhY3QudXNlQ2FsbGJhY2soZWxlbWVudCA9PiByZWdpc3RlckZpZWxkSW5wdXQ/LihlbGVtZW50LCB7XG4gICAgY29udHJvbFJlZjogcmFkaW9SZWYsXG4gICAgdmFsdWU6IHVuZGVmaW5lZFxuICB9KSwgW3JlZ2lzdGVyRmllbGRJbnB1dF0pO1xuICBjb25zdCBtZXJnZWRJbnB1dFJlZiA9IHVzZU1lcmdlZFJlZnMoaW5wdXRSZWZQcm9wLCBpbnB1dFJlZiwgcmVnaXN0ZXJJbnB1dFJlZiwgcmVnaXN0ZXJJbnB1dCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlucHV0UmVmLmN1cnJlbnQ/LmNoZWNrZWQpIHtcbiAgICAgIHNldEZpbGxlZCh0cnVlKTtcbiAgICB9XG4gIH0sIFtzZXRGaWxsZWRdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWlucHV0UmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGRpc2FibGVkICYmIGNoZWNrZWQpIHtcbiAgICAgIHJlZ2lzdGVySW5wdXRSZWYobnVsbCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJlZ2lzdGVySW5wdXRSZWYoaW5wdXRSZWYuY3VycmVudCk7XG4gIH0sIFtjaGVja2VkLCBkaXNhYmxlZCwgcmVnaXN0ZXJJbnB1dFJlZl0pO1xuICBjb25zdCBpZCA9IHVzZUJhc2VVaUlkKCk7XG4gIGNvbnN0IGlucHV0SWQgPSB1c2VMYWJlbGFibGVJZCh7XG4gICAgaWQ6IGlkUHJvcCxcbiAgICBpbXBsaWNpdDogZmFsc2UsXG4gICAgY29udHJvbFJlZjogcmFkaW9SZWZcbiAgfSk7XG4gIGNvbnN0IGhpZGRlbklucHV0SWQgPSBuYXRpdmVCdXR0b24gPyB1bmRlZmluZWQgOiBpbnB1dElkO1xuICBjb25zdCBhcmlhTGFiZWxsZWRCeSA9IHVzZUFyaWFMYWJlbGxlZEJ5KGFyaWFMYWJlbGxlZEJ5UHJvcCwgbGFiZWxJZCwgaW5wdXRSZWYsICFuYXRpdmVCdXR0b24sIGhpZGRlbklucHV0SWQpO1xuICBjb25zdCByb290UHJvcHMgPSB7XG4gICAgcm9sZTogJ3JhZGlvJyxcbiAgICAnYXJpYS1jaGVja2VkJzogY2hlY2tlZCxcbiAgICAnYXJpYS1sYWJlbGxlZGJ5JzogYXJpYUxhYmVsbGVkQnksXG4gICAgW0FDVElWRV9DT01QT1NJVEVfSVRFTV06IGNoZWNrZWQgPyAnJyA6IHVuZGVmaW5lZCxcbiAgICBpZDogbmF0aXZlQnV0dG9uID8gaW5wdXRJZCA6IGlkLFxuICAgIG9uS2V5RG93bihldmVudCkge1xuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJykge1xuICAgICAgICAvLyBSYWRpbyBvbmx5IGFjdGl2YXRlcyB3aXRoIFNwYWNlLiBQcmV2ZW50aW5nIHRoZSBrZXlkb3duJ3MgZGVmYXVsdFxuICAgICAgICAvLyBzdG9wcyB1c2VCdXR0b24gZnJvbSB0dXJuaW5nIEVudGVyIGludG8gYSBjbGljay5cbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uQ2xpY2soZXZlbnQpIHtcbiAgICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkIHx8IGRpc2FibGVkIHx8IHJlYWRPbmx5KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBjb25zdCBpbnB1dCA9IGlucHV0UmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoIWlucHV0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGRpc3BhdGNoQ2xpY2tXaXRoTW9kaWZpZXJzKGlucHV0LCBldmVudCk7XG4gICAgfSxcbiAgICBvbkZvY3VzKGV2ZW50KSB7XG4gICAgICBpZiAoZXZlbnQuZGVmYXVsdFByZXZlbnRlZCB8fCBkaXNhYmxlZCB8fCByZWFkT25seSB8fCAhdG91Y2hlZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpbnB1dFJlZi5jdXJyZW50Py5jbGljaygpO1xuICAgICAgc2V0VG91Y2hlZChmYWxzZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCB7XG4gICAgZ2V0QnV0dG9uUHJvcHMsXG4gICAgYnV0dG9uUmVmXG4gIH0gPSB1c2VCdXR0b24oe1xuICAgIGRpc2FibGVkLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uLFxuICAgIGNvbXBvc2l0ZTogZmFsc2VcbiAgfSk7XG4gIGNvbnN0IGlucHV0UHJvcHMgPSB7XG4gICAgdHlwZTogJ3JhZGlvJyxcbiAgICByZWY6IG1lcmdlZElucHV0UmVmLFxuICAgIGZvcm0sXG4gICAgaWQ6IGhpZGRlbklucHV0SWQsXG4gICAgbmFtZSxcbiAgICB0YWJJbmRleDogLTEsXG4gICAgc3R5bGU6IG5hbWUgPyB2aXN1YWxseUhpZGRlbklucHV0IDogdmlzdWFsbHlIaWRkZW4sXG4gICAgJ2FyaWEtaGlkZGVuJzogdHJ1ZSxcbiAgICAuLi4odmFsdWUgIT09IHVuZGVmaW5lZCA/IHtcbiAgICAgIHZhbHVlOiBzZXJpYWxpemVWYWx1ZSh2YWx1ZSlcbiAgICB9IDogRU1QVFlfT0JKRUNUKSxcbiAgICBkaXNhYmxlZCxcbiAgICBjaGVja2VkLFxuICAgIHJlcXVpcmVkLFxuICAgIHJlYWRPbmx5LFxuICAgIG9uQ2hhbmdlKGV2ZW50KSB7XG4gICAgICAvLyBXb3JrYXJvdW5kIGZvciBodHRwczovL2dpdGh1Yi5jb20vcmVhY3QvcmVhY3QvaXNzdWVzLzkwMjNcbiAgICAgIGlmIChldmVudC5uYXRpdmVFdmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChkaXNhYmxlZCB8fCByZWFkT25seSB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRldGFpbHMgPSBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5ub25lLCBldmVudC5uYXRpdmVFdmVudCk7XG4gICAgICBzZXRDaGVja2VkVmFsdWUodmFsdWUsIGRldGFpbHMpO1xuICAgICAgaWYgKGRldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBzZXRGaWVsZFRvdWNoZWQodHJ1ZSk7XG4gICAgfSxcbiAgICBvbkNsaWNrKGV2ZW50KSB7XG4gICAgICAvLyBDbGlja3MgZGlzcGF0Y2hlZCBvbiB0aGUgaW5wdXQgZnJvbSB0aGUgcm9vdCdzIGBvbkNsaWNrYCBhbmQgYG9uRm9jdXNgIGFyZSBhblxuICAgICAgLy8gaW1wbGVtZW50YXRpb24gZGV0YWlsIGFuZCBtdXN0IG5vdCByZWFjaCBhbmNlc3RvcnMuXG4gICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICB9LFxuICAgIG9uRm9jdXMoKSB7XG4gICAgICByYWRpb1JlZi5jdXJyZW50Py5mb2N1cygpO1xuICAgIH1cbiAgfTtcbiAgY29uc3Qgc3RhdGUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgLi4uZmllbGRTdGF0ZSxcbiAgICByZXF1aXJlZCxcbiAgICBkaXNhYmxlZCxcbiAgICByZWFkT25seSxcbiAgICBjaGVja2VkXG4gIH0pLCBbZmllbGRTdGF0ZSwgZGlzYWJsZWQsIHJlYWRPbmx5LCBjaGVja2VkLCByZXF1aXJlZF0pO1xuICBjb25zdCBjb250ZXh0VmFsdWUgPSBzdGF0ZTtcbiAgY29uc3QgaXNSYWRpb0dyb3VwID0gZ3JvdXBDb250ZXh0ICE9PSB1bmRlZmluZWQ7XG4gIGNvbnN0IHJlZnMgPSBbZm9yd2FyZGVkUmVmLCByYWRpb1JlZiwgYnV0dG9uUmVmXTtcbiAgY29uc3QgcHJvcHMgPSBbcm9vdFByb3BzLCBlbGVtZW50UHJvcHMsIGdldEJ1dHRvblByb3BzLCBnZXREZXNjcmlwdGlvblByb3BzLCB2YWxpZGF0aW9uID8gdmFsaWRhdGlvblByb3BzID0+IHZhbGlkYXRpb24uZ2V0VmFsaWRhdGlvblByb3BzKGRpc2FibGVkLCB2YWxpZGF0aW9uUHJvcHMpIDogRU1QVFlfT0JKRUNUXTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ3NwYW4nLCBjb21wb25lbnRQcm9wcywge1xuICAgIGVuYWJsZWQ6ICFpc1JhZGlvR3JvdXAsXG4gICAgc3RhdGUsXG4gICAgcmVmOiByZWZzLFxuICAgIHByb3BzLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmdcbiAgfSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeHMoUmFkaW9Sb290Q29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBjb250ZXh0VmFsdWUsXG4gICAgY2hpbGRyZW46IFtpc1JhZGlvR3JvdXAgPyAvKiNfX1BVUkVfXyovX2pzeChDb21wb3NpdGVJdGVtLCB7XG4gICAgICB0YWc6IFwic3BhblwiLFxuICAgICAgcmVuZGVyOiByZW5kZXIsXG4gICAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSxcbiAgICAgIHN0eWxlOiBzdHlsZSxcbiAgICAgIHN0YXRlOiBzdGF0ZSxcbiAgICAgIHJlZnM6IHJlZnMsXG4gICAgICBwcm9wczogcHJvcHMsXG4gICAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nXG4gICAgfSkgOiBlbGVtZW50LCAvKiNfX1BVUkVfXyovX2pzeChcImlucHV0XCIsIHtcbiAgICAgIC4uLmlucHV0UHJvcHMsXG4gICAgICBzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcbiAgICB9KV1cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFJhZGlvUm9vdC5kaXNwbGF5TmFtZSA9IFwiUmFkaW9Sb290XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmFkaW9Sb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1JhZGlvUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nIH0gZnJvbSBcIi4uL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuQ2hhbmdlQ29tcGxldGUgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZU9wZW5DaGFuZ2VDb21wbGV0ZS5tanNcIjtcbmltcG9ydCB7IHVzZVRyYW5zaXRpb25TdGF0dXMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVRyYW5zaXRpb25TdGF0dXMubWpzXCI7XG5cbi8qKlxuICogSW5kaWNhdGVzIHdoZXRoZXIgdGhlIHJhZGlvIGJ1dHRvbiBpcyBzZWxlY3RlZC5cbiAqIFJlbmRlcnMgYSBgPHNwYW4+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIFJhZGlvXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvcmFkaW8pXG4gKi9cbmV4cG9ydCBjb25zdCBSYWRpb0luZGljYXRvciA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFJhZGlvSW5kaWNhdG9yKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAga2VlcE1vdW50ZWQgPSBmYWxzZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCByb290U3RhdGUgPSB1c2VSYWRpb1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHJlbmRlcmVkID0gcm9vdFN0YXRlLmNoZWNrZWQ7XG4gIGNvbnN0IHtcbiAgICBtb3VudGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgc2V0TW91bnRlZFxuICB9ID0gdXNlVHJhbnNpdGlvblN0YXR1cyhyZW5kZXJlZCk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIC4uLnJvb3RTdGF0ZSxcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG4gIGNvbnN0IGluZGljYXRvclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgc2hvdWxkUmVuZGVyID0ga2VlcE1vdW50ZWQgfHwgbW91bnRlZDtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ3NwYW4nLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogW2ZvcndhcmRlZFJlZiwgaW5kaWNhdG9yUmVmXSxcbiAgICBzdGF0ZSxcbiAgICBwcm9wczogZWxlbWVudFByb3BzLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmdcbiAgfSk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgb3BlbjogcmVuZGVyZWQsXG4gICAgcmVmOiBpbmRpY2F0b3JSZWYsXG4gICAgb25Db21wbGV0ZSgpIHtcbiAgICAgIGlmICghcmVuZGVyZWQpIHtcbiAgICAgICAgc2V0TW91bnRlZChmYWxzZSk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgaWYgKCFzaG91bGRSZW5kZXIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gZWxlbWVudDtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgUmFkaW9JbmRpY2F0b3IuZGlzcGxheU5hbWUgPSBcIlJhZGlvSW5kaWNhdG9yXCI7IiwiZXhwb3J0IHsgUmFkaW9Sb290IGFzIFJvb3QgfSBmcm9tIFwiLi9yb290L1JhZGlvUm9vdC5tanNcIjtcbmV4cG9ydCB7IFJhZGlvSW5kaWNhdG9yIGFzIEluZGljYXRvciB9IGZyb20gXCIuL2luZGljYXRvci9SYWRpb0luZGljYXRvci5tanNcIjsiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFFQSxJQUFhLHlCQUF5QjtDQUNwQyxRQUFRLE9BQU87RUFDYixJQUFJLE9BQ0YsT0FBTyxFQUNMLGdCQUFnQixHQUNsQjtFQUVGLE9BQU8sRUFDTCxrQkFBa0IsR0FDcEI7Q0FDRjtDQUNBLEdBQUc7Q0FDSCxHQUFHO0FBQ0w7Ozs7OztBQ1BBLFNBQWdCLHFCQUFxQixTQUFTLENBQUMsR0FBRztDQUNoRCxNQUFNLEVBQ0osT0FDQSxPQUNBLFVBQ0EsU0FDQSxPQUFPLGtCQUNMO0NBQ0osTUFBTSxFQUNKLFVBQ0EsWUFDQSxvQkFDQSxpQkFDRSx3QkFBd0I7Q0FLNUIsTUFBTSxXQUFBLGFBQWlCLE9BQU8sRUFBRTtDQUNoQyxNQUFNLENBQUMsZUFBZSxvQkFBQSxhQUEwQixTQUFTLGlCQUFpQixRQUFRLGNBQWM7RUFDOUYsSUFBSSxTQUFTLFlBQVksSUFBSTtHQUMzQixNQUFNLFdBQVcsYUFBYTtHQUM5QixhQUFhLFdBQVc7R0FDeEIsU0FBUyxVQUFVO0VBQ3JCO0VBQ0EsT0FBTyxTQUFTO0NBQ2xCLElBQUksRUFBRTtDQUNOLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsTUFBTSxlQUFBLGFBQXFCLE9BQU8sSUFBSTtDQUt0QyxNQUFNLE1BQUEsYUFBWSxhQUFZLFNBQVE7RUFDcEMsTUFBTSxlQUFlLGFBQWE7RUFDbEMsSUFBSSxjQUNGLFdBQVcsWUFBWTtFQUV6QixhQUFhLFVBQVU7RUFDdkIsSUFBSSxNQUNGLFNBQVMsTUFBTTtHQUNiLFVBQVUsWUFBWTtHQUN0QixPQUFPLGlCQUFpQjtHQUN4QjtHQUNBO0VBQ0YsQ0FBQztDQUVMLEdBQUc7RUFBQztFQUFlO0VBQVU7RUFBWTtFQUFVO0VBQU87Q0FBTyxDQUFDO0NBQ2xFLHlCQUF5QjtFQUN2QixJQUFJLGlCQUFpQixNQUNuQjtFQUVGLE9BQU8sb0JBQW1CLFFBQU87R0FDL0IsTUFBTSxJQUFJLGFBQWEsVUFBVSxJQUFJLElBQUksYUFBYSxPQUFPLENBQUMsRUFBRSxRQUFRO0dBQ3hFLElBQUksS0FBSyxNQUNQLGlCQUFpQixDQUFDO0VBRXRCLENBQUM7Q0FDSCxHQUFHLENBQUMsZUFBZSxrQkFBa0IsQ0FBQztDQUN0QyxPQUFPO0VBQ0w7RUFDQTtDQUNGO0FBQ0Y7OztBQ2pFQSxTQUFnQixpQkFBaUIsU0FBUyxDQUFDLEdBQUc7Q0FDNUMsTUFBTSxFQUNKLHNCQUNBLGtCQUNBLDZCQUNFLHdCQUF3QjtDQUM1QixNQUFNLEVBQ0osS0FDQSxVQUNFLHFCQUFxQixNQUFNO0NBQy9CLE1BQU0sZ0JBQWdCLHFCQUFxQjtDQUMzQyxNQUFNLFVBQUEsYUFBZ0IsT0FBTyxJQUFJO0NBQ2pDLE1BQU0sWUFBWSxjQUFjLEtBQUssT0FBTztDQWlCNUMsT0FBTztFQUNMLGdCQUFBO0dBaEJBLFVBQVUsZ0JBQWdCLElBQUk7R0FDOUIsVUFBVTtJQUNSLHlCQUF5QixLQUFLO0dBQ2hDO0dBQ0EsY0FBYztJQUNaLE1BQU0sT0FBTyxRQUFRO0lBQ3JCLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUM1QjtJQUVGLE1BQU0sV0FBVyxLQUFLLGFBQWEsVUFBVSxLQUFLLEtBQUssaUJBQWlCO0lBQ3hFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUNyQixLQUFLLE1BQU07R0FFZjtFQUdhO0VBQ2IsY0FBYztFQUNkO0NBQ0Y7QUFDRjs7O0FDbkNBLFNBQWdCLGNBQWMsZ0JBQWdCO0NBQzVDLE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxRQUFRLGNBQ1IsUUFBUSxhQUNSLE9BQU8sYUFDUCxVQUNBLHdCQUNBLE1BQU0sT0FDTixHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLGdCQUNBLGlCQUNFLGlCQUFpQixFQUNuQixTQUNGLENBQUM7Q0FDRCxPQUFPLGlCQUFpQixLQUFLLGdCQUFnQjtFQUMzQztFQUVBLEtBQUssQ0FBQyxjQUFjLEdBQUcsSUFBSTtFQUMzQixPQUFPO0dBQUM7R0FBZ0IsR0FBRztHQUFPO0VBQVk7RUFDOUM7Q0FDRixDQUFDO0FBQ0g7OztBQzVCQSxJQUFhLG1CQUFnQywyQkFBTSxjQUFjLEVBQy9ELFVBQVUsTUFDWixDQUFDO0FBQzBDLGlCQUFpQixjQUFjO0FBQzFFLFNBQWdCLHNCQUFzQjtDQUVwQyxPQUFBLGFBRHNCLFdBQVcsZ0JBQ3BCO0FBQ2Y7OztBQ0xBLFNBQWdCLGtCQUFrQix3QkFBd0IsU0FBUyxnQkFBZ0IsaUJBQWlCLE1BQU0sZUFBZTtDQUN2SCxNQUFNLENBQUMsd0JBQXdCLDZCQUFBLGFBQW1DLFNBQVM7Q0FDM0UsTUFBTSxtQkFBbUIsWUFBWSxnQkFBZ0IsR0FBRyxjQUFjLFVBQVUsS0FBQSxDQUFTO0NBQ3pGLE1BQU0saUJBQWlCLDBCQUEwQixXQUFXO0NBTTVELHlCQUF5QjtFQUN2QixNQUFNLHFCQUFxQiwwQkFBMEIsV0FBVyxDQUFDLGlCQUFpQixLQUFBLElBQVksa0JBQWtCLGVBQWUsU0FBUyxnQkFBZ0I7RUFDeEosSUFBSSwyQkFBMkIsb0JBQzdCLDBCQUEwQixrQkFBa0I7Q0FFaEQsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLFNBQVMsa0JBQWtCLGFBQWEsa0JBQWtCO0NBQ3hELE1BQU0sUUFBUSxvQkFBb0IsV0FBVztDQUM3QyxJQUFJLENBQUMsT0FDSDtDQUVGLElBQUksQ0FBQyxNQUFNLE1BQU0sa0JBQ2YsTUFBTSxLQUFLO0NBRWIsT0FBTyxNQUFNLE1BQU0sS0FBQTtBQUNyQjtBQUNBLFNBQVMsb0JBQW9CLGFBQWE7Q0FDeEMsSUFBSSxDQUFDLGFBQ0g7Q0FJRixNQUFNLFNBQVMsWUFBWTtDQUMzQixJQUFJLFVBQVUsT0FBTyxZQUFZLFNBQy9CLE9BQU87Q0FFVCxNQUFNLFlBQVksWUFBWTtDQUM5QixJQUFJLFdBQVc7RUFDYixNQUFNLGNBQWMsWUFBWTtFQUNoQyxJQUFJLGVBQWUsWUFBWSxZQUFZLFdBQ3pDLE9BQU87Q0FFWDtDQUNBLE1BQU0sU0FBUyxZQUFZO0NBQzNCLE9BQU8sVUFBVSxPQUFPO0FBQzFCOzs7QUN6Q0EsU0FBZ0IsZUFBZSxTQUFTLENBQUMsR0FBRztDQUMxQyxNQUFNLEVBQ0osSUFDQSxXQUFXLE9BQ1gsZUFDRTtDQUNKLE1BQU0sRUFDSixXQUNBLHNCQUNFLG9CQUFvQjtDQUN4QixNQUFNLFlBQVksWUFBWSxFQUFFO0NBQ2hDLE1BQU0scUJBQXFCLFdBQVcsWUFBWSxLQUFBO0NBQ2xELE1BQU0sbUJBQW1CLHFCQUFxQixPQUFPLENBQUM7Q0FDdEQsTUFBTSxtQkFBQSxhQUF5QixPQUFPLEtBQUs7Q0FDM0MsTUFBTSxtQkFBQSxhQUF5QixPQUFPLE1BQU0sSUFBSTtDQUNoRCxNQUFNLHNCQUFzQix3QkFBd0I7RUFDbEQsSUFBSSxDQUFDLGlCQUFpQixXQUFXLHNCQUFzQixNQUNyRDtFQUVGLGlCQUFpQixVQUFVO0VBQzNCLGtCQUFrQixpQkFBaUIsU0FBUyxLQUFBLENBQVM7Q0FDdkQsQ0FBQztDQUNELHlCQUF5QjtFQUN2QixJQUFJLHNCQUFzQixNQUN4QjtFQUVGLElBQUk7RUFDSixJQUFJLFVBQVU7R0FDWixNQUFNLE9BQU8sWUFBWTtHQUN6QixJQUFJLFVBQVUsSUFBSSxLQUFLLEtBQUssUUFBUSxPQUFPLEtBQUssTUFDOUMsU0FBUyxNQUFNO1FBRWYsU0FBUyxzQkFBc0I7RUFFbkMsT0FBTyxJQUFJLE1BQU0sTUFBTTtHQUNyQixpQkFBaUIsVUFBVTtHQUMzQixTQUFTO0VBQ1gsT0FBTyxJQUFJLGlCQUFpQixTQUMxQixTQUFTO09BQ0o7R0FDTCxvQkFBb0I7R0FDcEI7RUFDRjtFQUNBLElBQUksV0FBVyxLQUFBLEdBQVc7R0FDeEIsb0JBQW9CO0dBQ3BCO0VBQ0Y7RUFDQSxpQkFBaUIsVUFBVTtFQUMzQixrQkFBa0IsaUJBQWlCLFNBQVMsTUFBTTtDQUVwRCxHQUFHO0VBQUM7RUFBSTtFQUFZO0VBQW9CO0VBQW1CO0VBQVU7RUFBVztFQUFrQjtDQUFtQixDQUFDO0NBQ3RILGFBQU0sZ0JBQWdCO0VBQ3BCLE9BQU87Q0FDVCxHQUFHLENBQUMsbUJBQW1CLENBQUM7Q0FDeEIsT0FBTyxhQUFhO0FBQ3RCOzs7QUNqRUEsU0FBZ0IsZUFBZSxPQUFPO0NBQ3BDLElBQUksU0FBUyxNQUNYLE9BQU87Q0FFVCxJQUFJLE9BQU8sVUFBVSxVQUNuQixPQUFPO0NBRVQsSUFBSTtFQUNGLE9BQU8sS0FBSyxVQUFVLEtBQUs7Q0FDN0IsUUFBUTtFQUNOLE9BQU8sT0FBTyxLQUFLO0NBQ3JCO0FBQ0Y7OztBQ1JBLElBQWEsbUJBQWdDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQy9CLGlCQUFpQixjQUFjO0FBQzFFLFNBQWdCLHNCQUFzQjtDQUNwQyxNQUFNLFFBQUEsYUFBYyxXQUFXLGdCQUFnQjtDQUMvQyxJQUFJLFVBQVUsS0FBQSxHQUNaLE1BQU0sSUFBSSxNQUE4Qyx1RkFBaUg7Q0FFM0ssT0FBTztBQUNUOzs7O0FDcUJBLElBQWEsWUFBeUIsMkJBQU0sV0FBVyxTQUFTLFVBQVUsZ0JBQWdCLGNBQWM7Q0FDdEcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxVQUFVLGVBQWUsT0FDekIsVUFBVSxlQUFlLE9BQ3pCLFVBQVUsZUFBZSxPQUN6QixtQkFBbUIsb0JBQ25CLE9BQ0EsVUFBVSxjQUNWLGVBQWUsT0FDZixJQUFJLFFBQ0osT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxlQUFlLHFCQUFxQjtDQUMxQyxNQUFNLEVBQ0osVUFBVSxlQUNWLFVBQVUsZUFDVixVQUFVLGVBQ1YsTUFBTSxXQUNOLGNBQ0EsVUFBVSxPQUNWLFlBQ0EsTUFDQSxrQkFBa0IsTUFDbEIsYUFBYSxNQUNiLG1CQUFtQixTQUNqQixnQkFBZ0IsQ0FBQztDQUNyQixNQUFNLEVBQ0osWUFBWSxpQkFDWixXQUNBLE9BQU8sWUFDUCxVQUFVLGtCQUNSLG9CQUFvQjtDQUN4QixNQUFNLG1CQUFtQixvQkFBb0I7Q0FDN0MsTUFBTSxFQUNKLFNBQ0Esd0JBQ0Usb0JBQW9CO0NBQ3hCLE1BQU0sV0FBVyxpQkFBaUIsaUJBQWlCLFlBQVksaUJBQWlCO0NBQ2hGLE1BQU0sV0FBVyxpQkFBaUI7Q0FDbEMsTUFBTSxXQUFXLGlCQUFpQjtDQUNsQyxNQUFNLE9BQU87Q0FDYixNQUFNLFVBQVUsZUFBZSxpQkFBaUIsUUFBUSxVQUFVO0NBQ2xFLE1BQU0sV0FBQSxhQUFpQixPQUFPLElBQUk7Q0FDbEMsTUFBTSxXQUFBLGFBQWlCLE9BQU8sSUFBSTtDQUNsQyxNQUFNLHFCQUFxQixZQUFZO0NBQ3ZDLE1BQU0sZ0JBQUEsYUFBc0IsYUFBWSxZQUFXLHFCQUFxQixTQUFTO0VBQy9FLFlBQVk7RUFDWixPQUFPLEtBQUE7Q0FDVCxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztDQUN4QixNQUFNLGlCQUFpQixjQUFjLGNBQWMsVUFBVSxrQkFBa0IsYUFBYTtDQUM1Rix5QkFBeUI7RUFDdkIsSUFBSSxTQUFTLFNBQVMsU0FDcEIsVUFBVSxJQUFJO0NBRWxCLEdBQUcsQ0FBQyxTQUFTLENBQUM7Q0FDZCx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFNBQVMsU0FDWjtFQUVGLElBQUksWUFBWSxTQUFTO0dBQ3ZCLGlCQUFpQixJQUFJO0dBQ3JCO0VBQ0Y7RUFDQSxpQkFBaUIsU0FBUyxPQUFPO0NBQ25DLEdBQUc7RUFBQztFQUFTO0VBQVU7Q0FBZ0IsQ0FBQztDQUN4QyxNQUFNLEtBQUssWUFBWTtDQUN2QixNQUFNLFVBQVUsZUFBZTtFQUM3QixJQUFJO0VBQ0osVUFBVTtFQUNWLFlBQVk7Q0FDZCxDQUFDO0NBQ0QsTUFBTSxnQkFBZ0IsZUFBZSxLQUFBLElBQVk7Q0FFakQsTUFBTSxZQUFZO0VBQ2hCLE1BQU07RUFDTixnQkFBZ0I7RUFDaEIsbUJBSnFCLGtCQUFrQixvQkFBb0IsU0FBUyxVQUFVLENBQUMsY0FBYyxhQUk3RDtHQUMvQix3QkFBd0IsVUFBVSxLQUFLLEtBQUE7RUFDeEMsSUFBSSxlQUFlLFVBQVU7RUFDN0IsVUFBVSxPQUFPO0dBQ2YsSUFBSSxNQUFNLFFBQVEsU0FHaEIsTUFBTSxlQUFlO0VBRXpCO0VBQ0EsUUFBUSxPQUFPO0dBQ2IsSUFBSSxNQUFNLG9CQUFvQixZQUFZLFVBQ3hDO0dBRUYsTUFBTSxlQUFlO0dBQ3JCLE1BQU0sUUFBUSxTQUFTO0dBQ3ZCLElBQUksQ0FBQyxPQUNIO0dBRUYsMkJBQTJCLE9BQU8sS0FBSztFQUN6QztFQUNBLFFBQVEsT0FBTztHQUNiLElBQUksTUFBTSxvQkFBb0IsWUFBWSxZQUFZLENBQUMsU0FDckQ7R0FFRixTQUFTLFNBQVMsTUFBTTtHQUN4QixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUNBLE1BQU0sRUFDSixnQkFDQSxjQUNFLFVBQVU7RUFDWjtFQUNBLFFBQVE7RUFDUixXQUFXO0NBQ2IsQ0FBQztDQUNELE1BQU0sYUFBYTtFQUNqQixNQUFNO0VBQ04sS0FBSztFQUNMO0VBQ0EsSUFBSTtFQUNKO0VBQ0EsVUFBVTtFQUNWLE9BQU8sT0FBTyxzQkFBc0I7RUFDcEMsZUFBZTtFQUNmLEdBQUksVUFBVSxLQUFBLElBQVksRUFDeEIsT0FBTyxlQUFlLEtBQUssRUFDN0IsSUFBSTtFQUNKO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsU0FBUyxPQUFPO0dBRWQsSUFBSSxNQUFNLFlBQVksa0JBQ3BCO0dBRUYsSUFBSSxZQUFZLFlBQVksVUFBVSxLQUFBLEdBQ3BDO0dBRUYsTUFBTSxVQUFVLHlCQUF5QkEsTUFBYyxNQUFNLFdBQVc7R0FDeEUsZ0JBQWdCLE9BQU8sT0FBTztHQUM5QixJQUFJLFFBQVEsWUFDVjtHQUVGLGdCQUFnQixJQUFJO0VBQ3RCO0VBQ0EsUUFBUSxPQUFPO0dBR2IsTUFBTSxnQkFBZ0I7RUFDeEI7RUFDQSxVQUFVO0dBQ1IsU0FBUyxTQUFTLE1BQU07RUFDMUI7Q0FDRjtDQUNBLE1BQU0sUUFBQSxhQUFjLGVBQWU7RUFDakMsR0FBRztFQUNIO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsSUFBSTtFQUFDO0VBQVk7RUFBVTtFQUFVO0VBQVM7Q0FBUSxDQUFDO0NBQ3ZELE1BQU0sZUFBZTtDQUNyQixNQUFNLGVBQWUsaUJBQWlCLEtBQUE7Q0FDdEMsTUFBTSxPQUFPO0VBQUM7RUFBYztFQUFVO0NBQVM7Q0FDL0MsTUFBTSxRQUFRO0VBQUM7RUFBVztFQUFjO0VBQWdCO0VBQXFCLGNBQWEsb0JBQW1CLFdBQVcsbUJBQW1CLFVBQVUsZUFBZSxJQUFJO0NBQVk7Q0FDcEwsTUFBTSxVQUFVLGlCQUFpQixRQUFRLGdCQUFnQjtFQUN2RCxTQUFTLENBQUM7RUFDVjtFQUNBLEtBQUs7RUFDTDtFQUNBO0NBQ0YsQ0FBQztDQUNELE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxLQUFBLENBQU0saUJBQWlCLFVBQVU7RUFDbkQsT0FBTztFQUNQLFVBQVUsQ0FBQyxlQUE0QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGVBQWU7R0FDekQsS0FBSztHQUNHO0dBQ0c7R0FDSjtHQUNBO0dBQ0Q7R0FDQztHQUNpQjtFQUMxQixDQUFDLElBQUksU0FBc0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxTQUFTO0dBQ3ZDLEdBQUc7R0FDSCwwQkFBMEI7RUFDNUIsQ0FBQyxDQUFDO0NBQ0osQ0FBQztBQUNILENBQUM7QUFDMEMsVUFBVSxjQUFjOzs7Ozs7Ozs7QUNqTm5FLElBQWEsaUJBQThCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ2hILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxjQUFjLE9BQ2QsR0FBRyxpQkFDRDtDQUNKLE1BQU0sWUFBWSxvQkFBb0I7Q0FDdEMsTUFBTSxXQUFXLFVBQVU7Q0FDM0IsTUFBTSxFQUNKLFNBQ0Esa0JBQ0EsZUFDRSxvQkFBb0IsUUFBUTtDQUNoQyxNQUFNLFFBQVE7RUFDWixHQUFHO0VBQ0g7Q0FDRjtDQUNBLE1BQU0sZUFBQSxhQUFxQixPQUFPLElBQUk7Q0FDdEMsTUFBTSxlQUFlLGVBQWU7Q0FDcEMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLGdCQUFnQjtFQUN2RCxLQUFLLENBQUMsY0FBYyxZQUFZO0VBQ2hDO0VBQ0EsT0FBTztFQUNQO0NBQ0YsQ0FBQztDQUNELHNCQUFzQjtFQUNwQixNQUFNO0VBQ04sS0FBSztFQUNMLGFBQWE7R0FDWCxJQUFJLENBQUMsVUFDSCxXQUFXLEtBQUs7RUFFcEI7Q0FDRixDQUFDO0NBQ0QsSUFBSSxDQUFDLGNBQ0gsT0FBTztDQUVULE9BQU87QUFDVCxDQUFDO0FBQzBDLGVBQWUsY0FBYyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExXX0=