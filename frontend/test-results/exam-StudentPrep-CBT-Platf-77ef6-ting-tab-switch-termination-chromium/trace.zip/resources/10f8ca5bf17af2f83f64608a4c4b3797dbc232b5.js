import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=076f3cfd";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=cdd924ad";
//#region node_modules/@base-ui/utils/useIsoLayoutEffect.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var noop = () => {};
var useIsoLayoutEffect = typeof document !== "undefined" ? import_react.useLayoutEffect : noop;
//#endregion
//#region node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function hasWindow() {
	return typeof window !== "undefined";
}
function getNodeName(node) {
	if (isNode(node)) return (node.nodeName || "").toLowerCase();
	return "#document";
}
function getWindow(node) {
	var _node$ownerDocument;
	return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
	var _ref;
	return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
	if (!hasWindow()) return false;
	return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
	if (!hasWindow()) return false;
	return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
	if (!hasWindow()) return false;
	return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
	if (!hasWindow() || typeof ShadowRoot === "undefined") return false;
	return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
function isOverflowElement(element) {
	const { overflow, overflowX, overflowY, display } = getComputedStyle(element);
	return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
}
function isLastTraversableNode(node) {
	return /^(html|body|#document)$/.test(getNodeName(node));
}
function getComputedStyle(element) {
	return getWindow(element).getComputedStyle(element);
}
function getParentNode(node) {
	if (getNodeName(node) === "html") return node;
	const result = node.assignedSlot || node.parentNode || isShadowRoot(node) && node.host || getDocumentElement(node);
	return isShadowRoot(result) ? result.host : result;
}
//#endregion
//#region node_modules/@base-ui/utils/useRefWithInit.mjs
var UNINITIALIZED = {};
/**
* A React.useRef() that is initialized with a function. Note that it accepts an optional
* initialization argument, so the initialization function doesn't need to be an inline closure.
*
* @usage
*   const ref = useRefWithInit(sortColumns, columns)
*/
function useRefWithInit(init, initArg) {
	const ref = import_react.useRef(UNINITIALIZED);
	if (ref.current === UNINITIALIZED) ref.current = init(initArg);
	return ref;
}
//#endregion
//#region node_modules/@base-ui/utils/empty.mjs
function NOOP() {}
var EMPTY_ARRAY = Object.freeze([]);
var EMPTY_OBJECT = Object.freeze({});
//#endregion
//#region node_modules/@base-ui/utils/useMergedRefs.mjs
/**
* Merges refs into a single memoized callback ref or `null`.
* This makes sure multiple refs are updated together and have the same value.
*
* This function accepts up to four refs. If you need to merge more, or have an unspecified number of refs to merge,
* use `useMergedRefsN` instead.
*/
function useMergedRefs(a, b, c, d) {
	const forkRef = useRefWithInit(createForkRef).current;
	if (didChange(forkRef, a, b, c, d)) update(forkRef, [
		a,
		b,
		c,
		d
	]);
	return forkRef.callback;
}
/**
* Merges an array of refs into a single memoized callback ref or `null`.
*
* If you need to merge a fixed number (up to four) of refs, use `useMergedRefs` instead for better performance.
*/
function useMergedRefsN(refs) {
	const forkRef = useRefWithInit(createForkRef).current;
	if (didChangeN(forkRef, refs)) update(forkRef, refs);
	return forkRef.callback;
}
function createForkRef() {
	return {
		callback: null,
		cleanup: null,
		refs: []
	};
}
function didChange(forkRef, a, b, c, d) {
	return forkRef.refs[0] !== a || forkRef.refs[1] !== b || forkRef.refs[2] !== c || forkRef.refs[3] !== d;
}
function didChangeN(forkRef, newRefs) {
	return forkRef.refs.length !== newRefs.length || forkRef.refs.some((ref, index) => ref !== newRefs[index]);
}
function update(forkRef, refs) {
	forkRef.refs = refs;
	if (refs.every((ref) => ref == null)) {
		forkRef.callback = null;
		return;
	}
	forkRef.callback = (instance) => {
		if (forkRef.cleanup) {
			forkRef.cleanup();
			forkRef.cleanup = null;
		}
		if (instance != null) {
			const cleanupCallbacks = Array(refs.length).fill(null);
			for (let i = 0; i < refs.length; i += 1) {
				const ref = refs[i];
				if (ref == null) continue;
				switch (typeof ref) {
					case "function": {
						const refCleanup = ref(instance);
						if (typeof refCleanup === "function") cleanupCallbacks[i] = refCleanup;
						break;
					}
					case "object": ref.current = instance;
				}
			}
			forkRef.cleanup = () => {
				for (let i = 0; i < refs.length; i += 1) {
					const ref = refs[i];
					if (ref == null) continue;
					switch (typeof ref) {
						case "function": {
							const cleanupCallback = cleanupCallbacks[i];
							if (typeof cleanupCallback === "function") cleanupCallback();
							else ref(null);
							break;
						}
						case "object": ref.current = null;
					}
				}
			};
		}
	};
}
//#endregion
//#region node_modules/@base-ui/utils/safeReact.mjs
/**
* A clone of the React namespace for reading APIs that may be missing in older
* supported React versions. Bundlers can rewrite direct `React.someNewApi`
* reads into named imports, which breaks React 17. Reading from this cloned
* object keeps those lookups optional.
*
* @see https://github.com/mui/material-ui/issues/41190#issuecomment-2040873379
*/
var SafeReact = { ...import_react };
//#endregion
//#region node_modules/@base-ui/utils/useStableCallback.mjs
var useInsertionEffect = SafeReact.useInsertionEffect;
var useSafeInsertionEffect = useInsertionEffect && useInsertionEffect !== SafeReact.useLayoutEffect ? useInsertionEffect : (fn) => fn();
/**
* Stabilizes the function passed so it's always the same between renders.
*
* The function becomes non-reactive to any values it captures.
* It can safely be passed as a dependency of `React.useMemo` and `React.useEffect` without re-triggering them if its captured values change.
*
* The function must only be called inside effects and event handlers, never during render (which throws an error).
*
* This hook is a more permissive version of React 19.2's `React.useEffectEvent` in that it can be passed through contexts and called in event handler props, not just effects.
*/
function useStableCallback(callback) {
	const stable = useRefWithInit(createStableCallback).current;
	stable.next = callback;
	useSafeInsertionEffect(stable.effect);
	return stable.trampoline;
}
function createStableCallback() {
	const stable = {
		next: void 0,
		callback: assertNotCalled,
		trampoline: (...args) => stable.callback?.(...args),
		effect: () => {
			stable.callback = stable.next;
		}
	};
	return stable;
}
function assertNotCalled() {
	throw new Error("Base UI: Cannot call an event handler while rendering.");
}
//#endregion
//#region node_modules/@base-ui/utils/reactVersion.mjs
var majorVersion = parseInt("19.2.8", 10);
function isReactVersionAtLeast(reactVersionToCheck) {
	return majorVersion >= reactVersionToCheck;
}
//#endregion
//#region node_modules/@base-ui/utils/getReactElementRef.mjs
/**
* Extracts the `ref` from a React element, handling different React versions.
*/
function getReactElementRef(element) {
	if (!/*#__PURE__*/ import_react.isValidElement(element)) return null;
	const reactElement = element;
	const propsWithRef = reactElement.props;
	return (isReactVersionAtLeast(19) ? propsWithRef?.ref : reactElement.ref) ?? null;
}
//#endregion
//#region node_modules/@base-ui/utils/mergeObjects.mjs
function mergeObjects(a, b) {
	if (a && !b) return a;
	if (!a && b) return b;
	if (a || b) return {
		...a,
		...b
	};
}
//#endregion
//#region node_modules/@base-ui/utils/warn.mjs
var set$1 = /* @__PURE__ */ new Set();
function warn(...messages) {
	{
		const messageKey = messages.join(" ");
		if (!set$1.has(messageKey)) {
			set$1.add(messageKey);
			console.warn(`Base UI: ${messageKey}`);
		}
	}
}
//#endregion
//#region node_modules/@base-ui/react/internals/getStateAttributesProps.mjs
function getStateAttributesProps(state, customMapping) {
	const props = {};
	for (const key in state) {
		const value = state[key];
		if (customMapping?.hasOwnProperty(key)) {
			const customProps = customMapping[key](value);
			if (customProps != null) Object.assign(props, customProps);
			continue;
		}
		if (value === true) props[`data-${key.toLowerCase()}`] = "";
		else if (value) props[`data-${key.toLowerCase()}`] = value.toString();
	}
	return props;
}
//#endregion
//#region node_modules/@base-ui/react/utils/resolveClassName.mjs
/**
* If the provided className is a string, it will be returned as is.
* Otherwise, the function will call the className function with the state as the first argument.
*
* @param className
* @param state
*/
function resolveClassName(className, state) {
	return typeof className === "function" ? className(state) : className;
}
//#endregion
//#region node_modules/@base-ui/react/utils/resolveStyle.mjs
/**
* If the provided style is an object, it will be returned as is.
* Otherwise, the function will call the style function with the state as the first argument.
*
* @param style
* @param state
*/
function resolveStyle(style, state) {
	return typeof style === "function" ? style(state) : style;
}
//#endregion
//#region node_modules/@base-ui/react/merge-props/mergeProps.mjs
var EMPTY_PROPS = {};
/**
* Merges multiple sets of React props. It follows the Object.assign pattern where the rightmost object's fields overwrite
* the conflicting ones from others. This doesn't apply to event handlers, `className` and `style` props.
*
* Event handlers are merged and called in right-to-left order (rightmost handler executes first, leftmost last).
* For React synthetic events, the rightmost handler can prevent prior (left-positioned) handlers from executing
* by calling `event.preventBaseUIHandler()`. For non-synthetic events (custom events with primitive/object values),
* all handlers always execute without prevention capability.
*
* The `className` prop is merged by concatenating classes in right-to-left order (rightmost class appears first in the string).
* The `style` prop is merged with rightmost styles overwriting the prior ones.
*
* Props can either be provided as objects or as functions that take the previous props as an argument.
* The function will receive the merged props up to that point (going from left to right):
* so in the case of `(obj1, obj2, fn, obj3)`, `fn` will receive the merged props of `obj1` and `obj2`.
* The function is responsible for chaining event handlers if needed (that is, we don't run the merge logic).
*
* Event handlers returned by the functions are not automatically prevented when `preventBaseUIHandler` is called.
* They must check `event.baseUIHandlerPrevented` themselves and bail out if it's true.
*
* @important **`ref` is not merged.**
* @param a Props object to merge.
* @param b Props object to merge. The function will overwrite conflicting props from `a`.
* @param c Props object to merge. The function will overwrite conflicting props from previous parameters.
* @param d Props object to merge. The function will overwrite conflicting props from previous parameters.
* @param e Props object to merge. The function will overwrite conflicting props from previous parameters.
* @returns The merged props.
* @public
*/
function mergeProps(a, b, c, d, e) {
	if (!c && !d && !e && !a) return createInitialMergedProps(b);
	let merged = createInitialMergedProps(a);
	if (b) merged = mergeInto(merged, b);
	if (c) merged = mergeInto(merged, c);
	if (d) merged = mergeInto(merged, d);
	if (e) merged = mergeInto(merged, e);
	return merged;
}
/**
* Merges an arbitrary number of React props using the same logic as {@link mergeProps}.
* This function accepts an array of props instead of individual arguments.
*
* This has slightly lower performance than {@link mergeProps} due to accepting an array
* instead of a fixed number of arguments. Prefer {@link mergeProps} when merging 5 or
* fewer prop sets for better performance.
*
* @param props Array of props to merge.
* @returns The merged props.
* @see mergeProps
* @public
*/
function mergePropsN(props) {
	if (props.length === 0) return EMPTY_PROPS;
	if (props.length === 1) return createInitialMergedProps(props[0]);
	let merged = createInitialMergedProps(props[0]);
	for (let i = 1; i < props.length; i += 1) merged = mergeInto(merged, props[i]);
	return merged;
}
function createInitialMergedProps(inputProps) {
	if (isPropsGetter(inputProps)) return { ...resolvePropsGetter(inputProps, EMPTY_PROPS) };
	return copyInitialProps(inputProps);
}
function mergeInto(merged, inputProps) {
	if (isPropsGetter(inputProps)) return resolvePropsGetter(inputProps, merged);
	return mutablyMergeInto(merged, inputProps);
}
function copyInitialProps(inputProps) {
	const copiedProps = { ...inputProps };
	for (const propName in copiedProps) {
		const propValue = copiedProps[propName];
		if (isEventHandler(propName, propValue)) copiedProps[propName] = wrapEventHandler(propValue);
	}
	return copiedProps;
}
/**
* Merges two sets of props. In case of conflicts, the external props take precedence.
*/
function mutablyMergeInto(mergedProps, externalProps) {
	if (!externalProps) return mergedProps;
	for (const propName in externalProps) {
		const externalPropValue = externalProps[propName];
		switch (propName) {
			case "style":
				mergedProps[propName] = mergeObjects(mergedProps.style, externalPropValue);
				break;
			case "className":
				mergedProps[propName] = mergeClassNames(mergedProps.className, externalPropValue);
				break;
			default: if (isEventHandler(propName, externalPropValue)) mergedProps[propName] = mergeEventHandlers(mergedProps[propName], externalPropValue);
			else mergedProps[propName] = externalPropValue;
		}
	}
	return mergedProps;
}
function isEventHandler(key, value) {
	const code0 = key.charCodeAt(0);
	const code1 = key.charCodeAt(1);
	const code2 = key.charCodeAt(2);
	return code0 === 111 && code1 === 110 && code2 >= 65 && code2 <= 90 && (typeof value === "function" || typeof value === "undefined");
}
function isPropsGetter(inputProps) {
	return typeof inputProps === "function";
}
function resolvePropsGetter(inputProps, previousProps) {
	if (isPropsGetter(inputProps)) return inputProps(previousProps);
	return inputProps ?? EMPTY_PROPS;
}
function mergeEventHandlers(ourHandler, theirHandler) {
	if (!theirHandler) return ourHandler;
	if (!ourHandler) return wrapEventHandler(theirHandler);
	return (...args) => {
		const event = args[0];
		if (isSyntheticEvent(event)) {
			const baseUIEvent = event;
			makeEventPreventable(baseUIEvent);
			const result = theirHandler(...args);
			if (!baseUIEvent.baseUIHandlerPrevented) ourHandler?.(...args);
			return result;
		}
		const result = theirHandler(...args);
		ourHandler?.(...args);
		return result;
	};
}
function wrapEventHandler(handler) {
	if (!handler) return handler;
	return (...args) => {
		const event = args[0];
		if (isSyntheticEvent(event)) makeEventPreventable(event);
		return handler(...args);
	};
}
function makeEventPreventable(event) {
	event.preventBaseUIHandler = () => {
		event.baseUIHandlerPrevented = true;
	};
	return event;
}
function mergeClassNames(ourClassName, theirClassName) {
	if (theirClassName) {
		if (ourClassName) return theirClassName + " " + ourClassName;
		return theirClassName;
	}
	return ourClassName;
}
function isSyntheticEvent(event) {
	return event != null && typeof event === "object" && "nativeEvent" in event;
}
//#endregion
//#region node_modules/@base-ui/react/internals/useRenderElement.mjs
/**
* Renders a Base UI element.
*
* @param element The default HTML element to render. Can be overridden by the `render` prop.
* @param componentProps An object containing the `render` and `className` props to be used for element customization. Other props are ignored.
* @param params Additional parameters for rendering the element.
*/
function useRenderElement(element, componentProps, params = {}) {
	const renderProp = componentProps.render;
	const outProps = useRenderElementProps(componentProps, params);
	if (params.enabled === false) return null;
	return evaluateRenderProp(element, renderProp, outProps, params.state ?? EMPTY_OBJECT);
}
/**
* Computes render element final props.
*/
function useRenderElementProps(componentProps, params = {}) {
	const { className: classNameProp, style: styleProp, render: renderProp } = componentProps;
	const { state = EMPTY_OBJECT, ref, props, stateAttributesMapping, enabled = true } = params;
	const className = enabled ? resolveClassName(classNameProp, state) : void 0;
	const style = enabled ? resolveStyle(styleProp, state) : void 0;
	const stateProps = enabled ? getStateAttributesProps(state, stateAttributesMapping) : EMPTY_OBJECT;
	const resolvedProps = enabled && props ? resolveRenderFunctionProps(props) : void 0;
	const outProps = enabled ? mergeObjects(stateProps, resolvedProps) ?? {} : EMPTY_OBJECT;
	if (typeof document !== "undefined") {
		if (!enabled) useMergedRefs(null, null);
		else if (Array.isArray(ref)) outProps.ref = useMergedRefsN([
			outProps.ref,
			getReactElementRef(renderProp),
			...ref
		]);
		else outProps.ref = useMergedRefs(outProps.ref, getReactElementRef(renderProp), ref);
	}
	if (!enabled) return EMPTY_OBJECT;
	if (className !== void 0) outProps.className = mergeClassNames(outProps.className, className);
	if (style !== void 0) outProps.style = mergeObjects(outProps.style, style);
	return outProps;
}
function resolveRenderFunctionProps(props) {
	if (Array.isArray(props)) return mergePropsN(props);
	return mergeProps(void 0, props);
}
var REACT_LAZY_TYPE = Symbol.for("react.lazy");
var COMPONENT_IDENTIFIER_PATTERN = /^[A-Z][A-Za-z0-9$]*$/;
var LOWERCASE_CHARACTER_PATTERN = /[a-z]/;
function evaluateRenderProp(element, render, props, state) {
	if (render) {
		if (typeof render === "function") {
			warnIfRenderPropLooksLikeComponent(render);
			return render(props, state);
		}
		const mergedProps = mergeProps(props, render.props);
		mergedProps.ref = props.ref;
		let newElement = render;
		if (newElement?.$$typeof === REACT_LAZY_TYPE) newElement = import_react.Children.toArray(render)[0];
		if (!/*#__PURE__*/ import_react.isValidElement(newElement)) throw new Error([
			"Base UI: The `render` prop was provided an invalid React element as `React.isValidElement(render)` is `false`.",
			"A valid React element must be provided to the `render` prop because it is cloned with props to replace the default element.",
			"https://base-ui.com/r/invalid-render-prop"
		].join("\n"));
		return /*#__PURE__*/ import_react.cloneElement(newElement, mergedProps);
	}
	if (element) {
		if (typeof element === "string") return renderTag(element, props);
	}
	throw new Error("Base UI: Render element or function are not defined.");
}
function warnIfRenderPropLooksLikeComponent(renderFn) {
	const functionName = renderFn.name;
	if (functionName.length === 0) return;
	if (!COMPONENT_IDENTIFIER_PATTERN.test(functionName)) return;
	if (!LOWERCASE_CHARACTER_PATTERN.test(functionName)) return;
	warn(`The \`render\` prop received a function named \`${functionName}\` that starts with an uppercase letter.`, "This usually means a React component was passed directly as `render={Component}`.", "Base UI calls `render` as a plain function, which can break the Rules of Hooks during reconciliation.", "If this is an intentional render callback, rename it to start with a lowercase letter.", "Use `render={<Component />}` or `render={(props) => <Component {...props} />}` instead.", "https://base-ui.com/r/invalid-render-prop");
}
function renderTag(Tag, props) {
	if (Tag === "button") return /*#__PURE__*/ (0, import_react.createElement)("button", {
		type: "button",
		...props,
		key: props.key
	});
	if (Tag === "img") return /*#__PURE__*/ (0, import_react.createElement)("img", {
		alt: "",
		...props,
		key: props.key
	});
	return /*#__PURE__*/ import_react.createElement(Tag, props);
}
//#endregion
//#region node_modules/@base-ui/utils/error.mjs
var set = /* @__PURE__ */ new Set();
function error(...messages) {
	{
		const messageKey = messages.join(" ");
		if (!set.has(messageKey)) {
			set.add(messageKey);
			console.error(`Base UI: ${messageKey}`);
		}
	}
}
//#endregion
//#region node_modules/@base-ui/react/internals/composite/root/CompositeRootContext.mjs
var CompositeRootContext = /*#__PURE__*/ import_react.createContext(void 0);
CompositeRootContext.displayName = "CompositeRootContext";
function useCompositeRootContext(optional = false) {
	const context = import_react.useContext(CompositeRootContext);
	if (context === void 0 && !optional) throw new Error("Base UI: CompositeRootContext is missing. Composite parts must be placed within <Composite.Root>.");
	return context;
}
//#endregion
export { isOverflowElement as C, isNode as S, useIsoLayoutEffect as T, getParentNode as _, makeEventPreventable as a, isHTMLElement as b, useStableCallback as c, EMPTY_ARRAY as d, EMPTY_OBJECT as f, getNodeName as g, getComputedStyle as h, useRenderElement as i, SafeReact as l, useRefWithInit as m, useCompositeRootContext as n, mergeProps as o, NOOP as p, error as r, isReactVersionAtLeast as s, CompositeRootContext as t, useMergedRefs as u, getWindow as v, isShadowRoot as w, isLastTraversableNode as x, isElement as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcG9zaXRlUm9vdENvbnRleHQtRDFTdnRpcTcuanMiLCJuYW1lcyI6WyJSZWFjdCIsInNldCJdLCJzb3VyY2VzIjpbIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdC5tanMiLCIuLi8uLi9AZmxvYXRpbmctdWkvdXRpbHMvZGlzdC9mbG9hdGluZy11aS51dGlscy5kb20ubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlUmVmV2l0aEluaXQubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvZW1wdHkubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlTWVyZ2VkUmVmcy5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9zYWZlUmVhY3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2subWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3JlYWN0VmVyc2lvbi5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9nZXRSZWFjdEVsZW1lbnRSZWYubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvbWVyZ2VPYmplY3RzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3dhcm4ubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2dldFN0YXRlQXR0cmlidXRlc1Byb3BzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3Jlc29sdmVDbGFzc05hbWUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcmVzb2x2ZVN0eWxlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lcmdlLXByb3BzL21lcmdlUHJvcHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvZXJyb3IubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2NvbXBvc2l0ZS9yb290L0NvbXBvc2l0ZVJvb3RDb250ZXh0Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmNvbnN0IG5vb3AgPSAoKSA9PiB7fTtcbmV4cG9ydCBjb25zdCB1c2VJc29MYXlvdXRFZmZlY3QgPSB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnID8gUmVhY3QudXNlTGF5b3V0RWZmZWN0IDogbm9vcDsiLCJmdW5jdGlvbiBoYXNXaW5kb3coKSB7XG4gIHJldHVybiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJztcbn1cbmZ1bmN0aW9uIGdldE5vZGVOYW1lKG5vZGUpIHtcbiAgaWYgKGlzTm9kZShub2RlKSkge1xuICAgIHJldHVybiAobm9kZS5ub2RlTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKTtcbiAgfVxuICAvLyBNb2NrZWQgbm9kZXMgaW4gdGVzdGluZyBlbnZpcm9ubWVudHMgbWF5IG5vdCBiZSBpbnN0YW5jZXMgb2YgTm9kZS4gQnlcbiAgLy8gcmV0dXJuaW5nIGAjZG9jdW1lbnRgIGFuIGluZmluaXRlIGxvb3Agd29uJ3Qgb2NjdXIuXG4gIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMjMxN1xuICByZXR1cm4gJyNkb2N1bWVudCc7XG59XG5mdW5jdGlvbiBnZXRXaW5kb3cobm9kZSkge1xuICB2YXIgX25vZGUkb3duZXJEb2N1bWVudDtcbiAgcmV0dXJuIChub2RlID09IG51bGwgfHwgKF9ub2RlJG93bmVyRG9jdW1lbnQgPSBub2RlLm93bmVyRG9jdW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfbm9kZSRvd25lckRvY3VtZW50LmRlZmF1bHRWaWV3KSB8fCB3aW5kb3c7XG59XG5mdW5jdGlvbiBnZXREb2N1bWVudEVsZW1lbnQobm9kZSkge1xuICB2YXIgX3JlZjtcbiAgcmV0dXJuIChfcmVmID0gKGlzTm9kZShub2RlKSA/IG5vZGUub3duZXJEb2N1bWVudCA6IG5vZGUuZG9jdW1lbnQpIHx8IHdpbmRvdy5kb2N1bWVudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9yZWYuZG9jdW1lbnRFbGVtZW50O1xufVxuZnVuY3Rpb24gaXNOb2RlKHZhbHVlKSB7XG4gIGlmICghaGFzV2luZG93KCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgTm9kZSB8fCB2YWx1ZSBpbnN0YW5jZW9mIGdldFdpbmRvdyh2YWx1ZSkuTm9kZTtcbn1cbmZ1bmN0aW9uIGlzRWxlbWVudCh2YWx1ZSkge1xuICBpZiAoIWhhc1dpbmRvdygpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIEVsZW1lbnQgfHwgdmFsdWUgaW5zdGFuY2VvZiBnZXRXaW5kb3codmFsdWUpLkVsZW1lbnQ7XG59XG5mdW5jdGlvbiBpc0hUTUxFbGVtZW50KHZhbHVlKSB7XG4gIGlmICghaGFzV2luZG93KCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgfHwgdmFsdWUgaW5zdGFuY2VvZiBnZXRXaW5kb3codmFsdWUpLkhUTUxFbGVtZW50O1xufVxuZnVuY3Rpb24gaXNTaGFkb3dSb290KHZhbHVlKSB7XG4gIGlmICghaGFzV2luZG93KCkgfHwgdHlwZW9mIFNoYWRvd1Jvb3QgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFNoYWRvd1Jvb3QgfHwgdmFsdWUgaW5zdGFuY2VvZiBnZXRXaW5kb3codmFsdWUpLlNoYWRvd1Jvb3Q7XG59XG5mdW5jdGlvbiBpc092ZXJmbG93RWxlbWVudChlbGVtZW50KSB7XG4gIGNvbnN0IHtcbiAgICBvdmVyZmxvdyxcbiAgICBvdmVyZmxvd1gsXG4gICAgb3ZlcmZsb3dZLFxuICAgIGRpc3BsYXlcbiAgfSA9IGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gIHJldHVybiAvYXV0b3xzY3JvbGx8b3ZlcmxheXxoaWRkZW58Y2xpcC8udGVzdChvdmVyZmxvdyArIG92ZXJmbG93WSArIG92ZXJmbG93WCkgJiYgZGlzcGxheSAhPT0gJ2lubGluZScgJiYgZGlzcGxheSAhPT0gJ2NvbnRlbnRzJztcbn1cbmZ1bmN0aW9uIGlzVGFibGVFbGVtZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIC9eKHRhYmxlfHRkfHRoKSQvLnRlc3QoZ2V0Tm9kZU5hbWUoZWxlbWVudCkpO1xufVxuZnVuY3Rpb24gaXNUb3BMYXllcihlbGVtZW50KSB7XG4gIHRyeSB7XG4gICAgaWYgKGVsZW1lbnQubWF0Y2hlcygnOnBvcG92ZXItb3BlbicpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH0gY2F0Y2ggKF9lKSB7XG4gICAgLy8gbm8tb3BcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiBlbGVtZW50Lm1hdGNoZXMoJzptb2RhbCcpO1xuICB9IGNhdGNoIChfZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuY29uc3Qgd2lsbENoYW5nZVJlID0gL3RyYW5zZm9ybXx0cmFuc2xhdGV8c2NhbGV8cm90YXRlfHBlcnNwZWN0aXZlfGZpbHRlci87XG5jb25zdCBjb250YWluUmUgPSAvcGFpbnR8bGF5b3V0fHN0cmljdHxjb250ZW50LztcbmNvbnN0IGlzTm90Tm9uZSA9IHZhbHVlID0+ICEhdmFsdWUgJiYgdmFsdWUgIT09ICdub25lJztcbmxldCBpc1dlYktpdFZhbHVlO1xuZnVuY3Rpb24gaXNDb250YWluaW5nQmxvY2soZWxlbWVudE9yQ3NzKSB7XG4gIGNvbnN0IGNzcyA9IGlzRWxlbWVudChlbGVtZW50T3JDc3MpID8gZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50T3JDc3MpIDogZWxlbWVudE9yQ3NzO1xuXG4gIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0NTUy9Db250YWluaW5nX2Jsb2NrI2lkZW50aWZ5aW5nX3RoZV9jb250YWluaW5nX2Jsb2NrXG4gIC8vIGh0dHBzOi8vZHJhZnRzLmNzc3dnLm9yZy9jc3MtdHJhbnNmb3Jtcy0yLyNpbmRpdmlkdWFsLXRyYW5zZm9ybXNcbiAgcmV0dXJuIGlzTm90Tm9uZShjc3MudHJhbnNmb3JtKSB8fCBpc05vdE5vbmUoY3NzLnRyYW5zbGF0ZSkgfHwgaXNOb3ROb25lKGNzcy5zY2FsZSkgfHwgaXNOb3ROb25lKGNzcy5yb3RhdGUpIHx8IGlzTm90Tm9uZShjc3MucGVyc3BlY3RpdmUpIHx8ICFpc1dlYktpdCgpICYmIChpc05vdE5vbmUoY3NzLmJhY2tkcm9wRmlsdGVyKSB8fCBpc05vdE5vbmUoY3NzLmZpbHRlcikpIHx8IHdpbGxDaGFuZ2VSZS50ZXN0KGNzcy53aWxsQ2hhbmdlIHx8ICcnKSB8fCBjb250YWluUmUudGVzdChjc3MuY29udGFpbiB8fCAnJyk7XG59XG5mdW5jdGlvbiBnZXRDb250YWluaW5nQmxvY2soZWxlbWVudCkge1xuICBsZXQgY3VycmVudE5vZGUgPSBnZXRQYXJlbnROb2RlKGVsZW1lbnQpO1xuICB3aGlsZSAoaXNIVE1MRWxlbWVudChjdXJyZW50Tm9kZSkgJiYgIWlzTGFzdFRyYXZlcnNhYmxlTm9kZShjdXJyZW50Tm9kZSkpIHtcbiAgICBpZiAoaXNDb250YWluaW5nQmxvY2soY3VycmVudE5vZGUpKSB7XG4gICAgICByZXR1cm4gY3VycmVudE5vZGU7XG4gICAgfSBlbHNlIGlmIChpc1RvcExheWVyKGN1cnJlbnROb2RlKSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGN1cnJlbnROb2RlID0gZ2V0UGFyZW50Tm9kZShjdXJyZW50Tm9kZSk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBpc1dlYktpdCgpIHtcbiAgaWYgKGlzV2ViS2l0VmFsdWUgPT0gbnVsbCkge1xuICAgIGlzV2ViS2l0VmFsdWUgPSB0eXBlb2YgQ1NTICE9PSAndW5kZWZpbmVkJyAmJiBDU1Muc3VwcG9ydHMgJiYgQ1NTLnN1cHBvcnRzKCctd2Via2l0LWJhY2tkcm9wLWZpbHRlcicsICdub25lJyk7XG4gIH1cbiAgcmV0dXJuIGlzV2ViS2l0VmFsdWU7XG59XG5mdW5jdGlvbiBpc0xhc3RUcmF2ZXJzYWJsZU5vZGUobm9kZSkge1xuICByZXR1cm4gL14oaHRtbHxib2R5fCNkb2N1bWVudCkkLy50ZXN0KGdldE5vZGVOYW1lKG5vZGUpKTtcbn1cbmZ1bmN0aW9uIGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCkge1xuICByZXR1cm4gZ2V0V2luZG93KGVsZW1lbnQpLmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG59XG5mdW5jdGlvbiBnZXROb2RlU2Nyb2xsKGVsZW1lbnQpIHtcbiAgaWYgKGlzRWxlbWVudChlbGVtZW50KSkge1xuICAgIHJldHVybiB7XG4gICAgICBzY3JvbGxMZWZ0OiBlbGVtZW50LnNjcm9sbExlZnQsXG4gICAgICBzY3JvbGxUb3A6IGVsZW1lbnQuc2Nyb2xsVG9wXG4gICAgfTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHNjcm9sbExlZnQ6IGVsZW1lbnQuc2Nyb2xsWCxcbiAgICBzY3JvbGxUb3A6IGVsZW1lbnQuc2Nyb2xsWVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0UGFyZW50Tm9kZShub2RlKSB7XG4gIGlmIChnZXROb2RlTmFtZShub2RlKSA9PT0gJ2h0bWwnKSB7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbiAgY29uc3QgcmVzdWx0ID1cbiAgLy8gU3RlcCBpbnRvIHRoZSBzaGFkb3cgRE9NIG9mIHRoZSBwYXJlbnQgb2YgYSBzbG90dGVkIG5vZGUuXG4gIG5vZGUuYXNzaWduZWRTbG90IHx8XG4gIC8vIERPTSBFbGVtZW50IGRldGVjdGVkLlxuICBub2RlLnBhcmVudE5vZGUgfHxcbiAgLy8gU2hhZG93Um9vdCBkZXRlY3RlZC5cbiAgaXNTaGFkb3dSb290KG5vZGUpICYmIG5vZGUuaG9zdCB8fFxuICAvLyBGYWxsYmFjay5cbiAgZ2V0RG9jdW1lbnRFbGVtZW50KG5vZGUpO1xuICByZXR1cm4gaXNTaGFkb3dSb290KHJlc3VsdCkgPyByZXN1bHQuaG9zdCA6IHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGdldE5lYXJlc3RPdmVyZmxvd0FuY2VzdG9yKG5vZGUpIHtcbiAgY29uc3QgcGFyZW50Tm9kZSA9IGdldFBhcmVudE5vZGUobm9kZSk7XG4gIGlmIChpc0xhc3RUcmF2ZXJzYWJsZU5vZGUocGFyZW50Tm9kZSkpIHtcbiAgICByZXR1cm4gKG5vZGUub3duZXJEb2N1bWVudCB8fCBub2RlKS5ib2R5O1xuICB9XG4gIGlmIChpc0hUTUxFbGVtZW50KHBhcmVudE5vZGUpICYmIGlzT3ZlcmZsb3dFbGVtZW50KHBhcmVudE5vZGUpKSB7XG4gICAgcmV0dXJuIHBhcmVudE5vZGU7XG4gIH1cbiAgcmV0dXJuIGdldE5lYXJlc3RPdmVyZmxvd0FuY2VzdG9yKHBhcmVudE5vZGUpO1xufVxuZnVuY3Rpb24gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMobm9kZSwgbGlzdCwgdHJhdmVyc2VJZnJhbWVzKSB7XG4gIHZhciBfbm9kZSRvd25lckRvY3VtZW50MjtcbiAgaWYgKGxpc3QgPT09IHZvaWQgMCkge1xuICAgIGxpc3QgPSBbXTtcbiAgfVxuICBpZiAodHJhdmVyc2VJZnJhbWVzID09PSB2b2lkIDApIHtcbiAgICB0cmF2ZXJzZUlmcmFtZXMgPSB0cnVlO1xuICB9XG4gIGNvbnN0IHNjcm9sbGFibGVBbmNlc3RvciA9IGdldE5lYXJlc3RPdmVyZmxvd0FuY2VzdG9yKG5vZGUpO1xuICBjb25zdCBpc0JvZHkgPSBzY3JvbGxhYmxlQW5jZXN0b3IgPT09ICgoX25vZGUkb3duZXJEb2N1bWVudDIgPSBub2RlLm93bmVyRG9jdW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfbm9kZSRvd25lckRvY3VtZW50Mi5ib2R5KTtcbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KHNjcm9sbGFibGVBbmNlc3Rvcik7XG4gIGlmIChpc0JvZHkpIHtcbiAgICBjb25zdCBmcmFtZUVsZW1lbnQgPSBnZXRGcmFtZUVsZW1lbnQod2luKTtcbiAgICByZXR1cm4gbGlzdC5jb25jYXQod2luLCB3aW4udmlzdWFsVmlld3BvcnQgfHwgW10sIGlzT3ZlcmZsb3dFbGVtZW50KHNjcm9sbGFibGVBbmNlc3RvcikgPyBzY3JvbGxhYmxlQW5jZXN0b3IgOiBbXSwgZnJhbWVFbGVtZW50ICYmIHRyYXZlcnNlSWZyYW1lcyA/IGdldE92ZXJmbG93QW5jZXN0b3JzKGZyYW1lRWxlbWVudCkgOiBbXSk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGxpc3QuY29uY2F0KHNjcm9sbGFibGVBbmNlc3RvciwgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoc2Nyb2xsYWJsZUFuY2VzdG9yLCBbXSwgdHJhdmVyc2VJZnJhbWVzKSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldEZyYW1lRWxlbWVudCh3aW4pIHtcbiAgcmV0dXJuIHdpbi5wYXJlbnQgJiYgT2JqZWN0LmdldFByb3RvdHlwZU9mKHdpbi5wYXJlbnQpID8gd2luLmZyYW1lRWxlbWVudCA6IG51bGw7XG59XG5cbmV4cG9ydCB7IGdldENvbXB1dGVkU3R5bGUsIGdldENvbnRhaW5pbmdCbG9jaywgZ2V0RG9jdW1lbnRFbGVtZW50LCBnZXRGcmFtZUVsZW1lbnQsIGdldE5lYXJlc3RPdmVyZmxvd0FuY2VzdG9yLCBnZXROb2RlTmFtZSwgZ2V0Tm9kZVNjcm9sbCwgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMsIGdldFBhcmVudE5vZGUsIGdldFdpbmRvdywgaXNDb250YWluaW5nQmxvY2ssIGlzRWxlbWVudCwgaXNIVE1MRWxlbWVudCwgaXNMYXN0VHJhdmVyc2FibGVOb2RlLCBpc05vZGUsIGlzT3ZlcmZsb3dFbGVtZW50LCBpc1NoYWRvd1Jvb3QsIGlzVGFibGVFbGVtZW50LCBpc1RvcExheWVyLCBpc1dlYktpdCB9O1xuIiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5jb25zdCBVTklOSVRJQUxJWkVEID0ge307XG5cbi8qKlxuICogQSBSZWFjdC51c2VSZWYoKSB0aGF0IGlzIGluaXRpYWxpemVkIHdpdGggYSBmdW5jdGlvbi4gTm90ZSB0aGF0IGl0IGFjY2VwdHMgYW4gb3B0aW9uYWxcbiAqIGluaXRpYWxpemF0aW9uIGFyZ3VtZW50LCBzbyB0aGUgaW5pdGlhbGl6YXRpb24gZnVuY3Rpb24gZG9lc24ndCBuZWVkIHRvIGJlIGFuIGlubGluZSBjbG9zdXJlLlxuICpcbiAqIEB1c2FnZVxuICogICBjb25zdCByZWYgPSB1c2VSZWZXaXRoSW5pdChzb3J0Q29sdW1ucywgY29sdW1ucylcbiAqL1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlUmVmV2l0aEluaXQoaW5pdCwgaW5pdEFyZykge1xuICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYoVU5JTklUSUFMSVpFRCk7XG4gIGlmIChyZWYuY3VycmVudCA9PT0gVU5JTklUSUFMSVpFRCkge1xuICAgIHJlZi5jdXJyZW50ID0gaW5pdChpbml0QXJnKTtcbiAgfVxuICByZXR1cm4gcmVmO1xufSIsImV4cG9ydCBmdW5jdGlvbiBOT09QKCkge31cbmV4cG9ydCBjb25zdCBFTVBUWV9BUlJBWSA9IE9iamVjdC5mcmVlemUoW10pO1xuZXhwb3J0IGNvbnN0IEVNUFRZX09CSkVDVCA9IE9iamVjdC5mcmVlemUoe30pOyIsImltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSBcIi4vdXNlUmVmV2l0aEluaXQubWpzXCI7XG5cbi8qKlxuICogTWVyZ2VzIHJlZnMgaW50byBhIHNpbmdsZSBtZW1vaXplZCBjYWxsYmFjayByZWYgb3IgYG51bGxgLlxuICogVGhpcyBtYWtlcyBzdXJlIG11bHRpcGxlIHJlZnMgYXJlIHVwZGF0ZWQgdG9nZXRoZXIgYW5kIGhhdmUgdGhlIHNhbWUgdmFsdWUuXG4gKlxuICogVGhpcyBmdW5jdGlvbiBhY2NlcHRzIHVwIHRvIGZvdXIgcmVmcy4gSWYgeW91IG5lZWQgdG8gbWVyZ2UgbW9yZSwgb3IgaGF2ZSBhbiB1bnNwZWNpZmllZCBudW1iZXIgb2YgcmVmcyB0byBtZXJnZSxcbiAqIHVzZSBgdXNlTWVyZ2VkUmVmc05gIGluc3RlYWQuXG4gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZU1lcmdlZFJlZnMoYSwgYiwgYywgZCkge1xuICBjb25zdCBmb3JrUmVmID0gdXNlUmVmV2l0aEluaXQoY3JlYXRlRm9ya1JlZikuY3VycmVudDtcbiAgaWYgKGRpZENoYW5nZShmb3JrUmVmLCBhLCBiLCBjLCBkKSkge1xuICAgIHVwZGF0ZShmb3JrUmVmLCBbYSwgYiwgYywgZF0pO1xuICB9XG4gIHJldHVybiBmb3JrUmVmLmNhbGxiYWNrO1xufVxuXG4vKipcbiAqIE1lcmdlcyBhbiBhcnJheSBvZiByZWZzIGludG8gYSBzaW5nbGUgbWVtb2l6ZWQgY2FsbGJhY2sgcmVmIG9yIGBudWxsYC5cbiAqXG4gKiBJZiB5b3UgbmVlZCB0byBtZXJnZSBhIGZpeGVkIG51bWJlciAodXAgdG8gZm91cikgb2YgcmVmcywgdXNlIGB1c2VNZXJnZWRSZWZzYCBpbnN0ZWFkIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2UuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZXJnZWRSZWZzTihyZWZzKSB7XG4gIGNvbnN0IGZvcmtSZWYgPSB1c2VSZWZXaXRoSW5pdChjcmVhdGVGb3JrUmVmKS5jdXJyZW50O1xuICBpZiAoZGlkQ2hhbmdlTihmb3JrUmVmLCByZWZzKSkge1xuICAgIHVwZGF0ZShmb3JrUmVmLCByZWZzKTtcbiAgfVxuICByZXR1cm4gZm9ya1JlZi5jYWxsYmFjaztcbn1cbmZ1bmN0aW9uIGNyZWF0ZUZvcmtSZWYoKSB7XG4gIHJldHVybiB7XG4gICAgY2FsbGJhY2s6IG51bGwsXG4gICAgY2xlYW51cDogbnVsbCxcbiAgICByZWZzOiBbXVxuICB9O1xufVxuZnVuY3Rpb24gZGlkQ2hhbmdlKGZvcmtSZWYsIGEsIGIsIGMsIGQpIHtcbiAgLy8gcHJldHRpZXItaWdub3JlXG4gIHJldHVybiBmb3JrUmVmLnJlZnNbMF0gIT09IGEgfHwgZm9ya1JlZi5yZWZzWzFdICE9PSBiIHx8IGZvcmtSZWYucmVmc1syXSAhPT0gYyB8fCBmb3JrUmVmLnJlZnNbM10gIT09IGQ7XG59XG5mdW5jdGlvbiBkaWRDaGFuZ2VOKGZvcmtSZWYsIG5ld1JlZnMpIHtcbiAgcmV0dXJuIGZvcmtSZWYucmVmcy5sZW5ndGggIT09IG5ld1JlZnMubGVuZ3RoIHx8IGZvcmtSZWYucmVmcy5zb21lKChyZWYsIGluZGV4KSA9PiByZWYgIT09IG5ld1JlZnNbaW5kZXhdKTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZShmb3JrUmVmLCByZWZzKSB7XG4gIGZvcmtSZWYucmVmcyA9IHJlZnM7XG4gIGlmIChyZWZzLmV2ZXJ5KHJlZiA9PiByZWYgPT0gbnVsbCkpIHtcbiAgICBmb3JrUmVmLmNhbGxiYWNrID0gbnVsbDtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9ya1JlZi5jYWxsYmFjayA9IGluc3RhbmNlID0+IHtcbiAgICBpZiAoZm9ya1JlZi5jbGVhbnVwKSB7XG4gICAgICBmb3JrUmVmLmNsZWFudXAoKTtcbiAgICAgIGZvcmtSZWYuY2xlYW51cCA9IG51bGw7XG4gICAgfVxuICAgIGlmIChpbnN0YW5jZSAhPSBudWxsKSB7XG4gICAgICBjb25zdCBjbGVhbnVwQ2FsbGJhY2tzID0gQXJyYXkocmVmcy5sZW5ndGgpLmZpbGwobnVsbCk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlZnMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgY29uc3QgcmVmID0gcmVmc1tpXTtcbiAgICAgICAgaWYgKHJlZiA9PSBudWxsKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgc3dpdGNoICh0eXBlb2YgcmVmKSB7XG4gICAgICAgICAgY2FzZSAnZnVuY3Rpb24nOlxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBjb25zdCByZWZDbGVhbnVwID0gcmVmKGluc3RhbmNlKTtcbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiByZWZDbGVhbnVwID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgY2xlYW51cENhbGxiYWNrc1tpXSA9IHJlZkNsZWFudXA7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgY2FzZSAnb2JqZWN0JzpcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgcmVmLmN1cnJlbnQgPSBpbnN0YW5jZTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZm9ya1JlZi5jbGVhbnVwID0gKCkgPT4ge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlZnMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgICBjb25zdCByZWYgPSByZWZzW2ldO1xuICAgICAgICAgIGlmIChyZWYgPT0gbnVsbCkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHN3aXRjaCAodHlwZW9mIHJlZikge1xuICAgICAgICAgICAgY2FzZSAnZnVuY3Rpb24nOlxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgY29uc3QgY2xlYW51cENhbGxiYWNrID0gY2xlYW51cENhbGxiYWNrc1tpXTtcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNsZWFudXBDYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgY2xlYW51cENhbGxiYWNrKCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIC8vIExlZ2FjeSByZWYgd2l0aCBubyBhdHRhY2gtdGltZSBjbGVhbnVwOiBkZXRhY2ggYnkgY2FsbGluZyBpdCB3aXRoIGBudWxsYC5cbiAgICAgICAgICAgICAgICAgIC8vIEl0IHJldHVybnMgbm90aGluZzsgUmVhY3QgMTkgY2xlYW51cHMgYXJlIGhhbmRsZWQgaW4gdGhlIGJyYW5jaCBhYm92ZS5cbiAgICAgICAgICAgICAgICAgIHZvaWQgcmVmKG51bGwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnb2JqZWN0JzpcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfVxuICB9O1xufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuLyoqXG4gKiBBIGNsb25lIG9mIHRoZSBSZWFjdCBuYW1lc3BhY2UgZm9yIHJlYWRpbmcgQVBJcyB0aGF0IG1heSBiZSBtaXNzaW5nIGluIG9sZGVyXG4gKiBzdXBwb3J0ZWQgUmVhY3QgdmVyc2lvbnMuIEJ1bmRsZXJzIGNhbiByZXdyaXRlIGRpcmVjdCBgUmVhY3Quc29tZU5ld0FwaWBcbiAqIHJlYWRzIGludG8gbmFtZWQgaW1wb3J0cywgd2hpY2ggYnJlYWtzIFJlYWN0IDE3LiBSZWFkaW5nIGZyb20gdGhpcyBjbG9uZWRcbiAqIG9iamVjdCBrZWVwcyB0aG9zZSBsb29rdXBzIG9wdGlvbmFsLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL211aS9tYXRlcmlhbC11aS9pc3N1ZXMvNDExOTAjaXNzdWVjb21tZW50LTIwNDA4NzMzNzlcbiAqL1xuZXhwb3J0IGNvbnN0IFNhZmVSZWFjdCA9IHtcbiAgLi4uUmVhY3Rcbn07IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyBTYWZlUmVhY3QgfSBmcm9tIFwiLi9zYWZlUmVhY3QubWpzXCI7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gXCIuL3VzZVJlZldpdGhJbml0Lm1qc1wiO1xuY29uc3QgdXNlSW5zZXJ0aW9uRWZmZWN0ID0gU2FmZVJlYWN0LnVzZUluc2VydGlvbkVmZmVjdDtcbmNvbnN0IHVzZVNhZmVJbnNlcnRpb25FZmZlY3QgPVxuLy8gUmVhY3QgMTcgZG9lc24ndCBoYXZlIHVzZUluc2VydGlvbkVmZmVjdC5cbnVzZUluc2VydGlvbkVmZmVjdCAmJlxuLy8gUHJlYWN0IHJlcGxhY2VzIHVzZUluc2VydGlvbkVmZmVjdCB3aXRoIHVzZUxheW91dEVmZmVjdCBhbmQgZmlyZXMgdG9vIGxhdGUuXG51c2VJbnNlcnRpb25FZmZlY3QgIT09IFNhZmVSZWFjdC51c2VMYXlvdXRFZmZlY3QgPyB1c2VJbnNlcnRpb25FZmZlY3QgOiBmbiA9PiBmbigpO1xuLyoqXG4gKiBTdGFiaWxpemVzIHRoZSBmdW5jdGlvbiBwYXNzZWQgc28gaXQncyBhbHdheXMgdGhlIHNhbWUgYmV0d2VlbiByZW5kZXJzLlxuICpcbiAqIFRoZSBmdW5jdGlvbiBiZWNvbWVzIG5vbi1yZWFjdGl2ZSB0byBhbnkgdmFsdWVzIGl0IGNhcHR1cmVzLlxuICogSXQgY2FuIHNhZmVseSBiZSBwYXNzZWQgYXMgYSBkZXBlbmRlbmN5IG9mIGBSZWFjdC51c2VNZW1vYCBhbmQgYFJlYWN0LnVzZUVmZmVjdGAgd2l0aG91dCByZS10cmlnZ2VyaW5nIHRoZW0gaWYgaXRzIGNhcHR1cmVkIHZhbHVlcyBjaGFuZ2UuXG4gKlxuICogVGhlIGZ1bmN0aW9uIG11c3Qgb25seSBiZSBjYWxsZWQgaW5zaWRlIGVmZmVjdHMgYW5kIGV2ZW50IGhhbmRsZXJzLCBuZXZlciBkdXJpbmcgcmVuZGVyICh3aGljaCB0aHJvd3MgYW4gZXJyb3IpLlxuICpcbiAqIFRoaXMgaG9vayBpcyBhIG1vcmUgcGVybWlzc2l2ZSB2ZXJzaW9uIG9mIFJlYWN0IDE5LjIncyBgUmVhY3QudXNlRWZmZWN0RXZlbnRgIGluIHRoYXQgaXQgY2FuIGJlIHBhc3NlZCB0aHJvdWdoIGNvbnRleHRzIGFuZCBjYWxsZWQgaW4gZXZlbnQgaGFuZGxlciBwcm9wcywgbm90IGp1c3QgZWZmZWN0cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVN0YWJsZUNhbGxiYWNrKGNhbGxiYWNrKSB7XG4gIGNvbnN0IHN0YWJsZSA9IHVzZVJlZldpdGhJbml0KGNyZWF0ZVN0YWJsZUNhbGxiYWNrKS5jdXJyZW50O1xuICBzdGFibGUubmV4dCA9IGNhbGxiYWNrO1xuICB1c2VTYWZlSW5zZXJ0aW9uRWZmZWN0KHN0YWJsZS5lZmZlY3QpO1xuICByZXR1cm4gc3RhYmxlLnRyYW1wb2xpbmU7XG59XG5mdW5jdGlvbiBjcmVhdGVTdGFibGVDYWxsYmFjaygpIHtcbiAgY29uc3Qgc3RhYmxlID0ge1xuICAgIG5leHQ6IHVuZGVmaW5lZCxcbiAgICBjYWxsYmFjazogYXNzZXJ0Tm90Q2FsbGVkLFxuICAgIHRyYW1wb2xpbmU6ICguLi5hcmdzKSA9PiBzdGFibGUuY2FsbGJhY2s/LiguLi5hcmdzKSxcbiAgICBlZmZlY3Q6ICgpID0+IHtcbiAgICAgIHN0YWJsZS5jYWxsYmFjayA9IHN0YWJsZS5uZXh0O1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIHN0YWJsZTtcbn1cbmZ1bmN0aW9uIGFzc2VydE5vdENhbGxlZCgpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAvLyBUT0RPOiBmaXggbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICB0aHJvdyAvKiBtaW5pZnktZXJyb3ItZGlzYWJsZWQgKi9uZXcgRXJyb3IoJ0Jhc2UgVUk6IENhbm5vdCBjYWxsIGFuIGV2ZW50IGhhbmRsZXIgd2hpbGUgcmVuZGVyaW5nLicpO1xuICB9XG59IiwiLyoqXG4gKiBDcmVhdGVzIGEgZm9ybWF0RXJyb3JNZXNzYWdlIGZ1bmN0aW9uIHdpdGggYSBjdXN0b20gVVJMIGFuZCBwcmVmaXguXG4gKiBAcGFyYW0gYmFzZVVybCAtIFRoZSBiYXNlIFVSTCBmb3IgdGhlIGVycm9yIHBhZ2UgKGUuZy4sICdodHRwczovL2Jhc2UtdWkuY29tL3Byb2R1Y3Rpb24tZXJyb3InKVxuICogQHBhcmFtIHByZWZpeCAtIFRoZSBwcmVmaXggZm9yIHRoZSBlcnJvciBtZXNzYWdlIChlLmcuLCAnQmFzZSBVSScpXG4gKiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgZm9ybWF0cyBlcnJvciBtZXNzYWdlcyB3aXRoIHRoZSBnaXZlbiBVUkwgYW5kIHByZWZpeFxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRm9ybWF0RXJyb3JNZXNzYWdlKGJhc2VVcmwsIHByZWZpeCkge1xuICByZXR1cm4gZnVuY3Rpb24gZm9ybWF0RXJyb3JNZXNzYWdlKGNvZGUsIC4uLmFyZ3MpIHtcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKGJhc2VVcmwpO1xuICAgIHVybC5zZWFyY2hQYXJhbXMuc2V0KCdjb2RlJywgY29kZS50b1N0cmluZygpKTtcbiAgICBhcmdzLmZvckVhY2goYXJnID0+IHVybC5zZWFyY2hQYXJhbXMuYXBwZW5kKCdhcmdzW10nLCBhcmcpKTtcbiAgICByZXR1cm4gYCR7cHJlZml4fSBlcnJvciAjJHtjb2RlfTsgdmlzaXQgJHt1cmx9IGZvciB0aGUgZnVsbCBtZXNzYWdlLmA7XG4gIH07XG59XG5cbi8qKlxuICogV0FSTklORzogRG9uJ3QgaW1wb3J0IHRoaXMgZGlyZWN0bHkuIEl0J3MgaW1wb3J0ZWQgYnkgdGhlIGNvZGUgZ2VuZXJhdGVkIGJ5XG4gKiBgQG11aS9pbnRlcm5hbC1iYWJlbC1wbHVnaW4tbWluaWZ5LWVycm9yc2AuIE1ha2Ugc3VyZSB0byBhbHdheXMgdXNlIHN0cmluZyBsaXRlcmFscyBpbiBgRXJyb3JgXG4gKiBjb25zdHJ1Y3RvcnMgdG8gZW5zdXJlIHRoZSBwbHVnaW4gd29ya3MgYXMgZXhwZWN0ZWQuIFN1cHBvcnRlZCBwYXR0ZXJucyBpbmNsdWRlOlxuICogICB0aHJvdyBuZXcgRXJyb3IoJ015IG1lc3NhZ2UnKTtcbiAqICAgdGhyb3cgbmV3IEVycm9yKGBNeSBtZXNzYWdlOiAke2Zvb31gKTtcbiAqICAgdGhyb3cgbmV3IEVycm9yKGBNeSBtZXNzYWdlOiAke2Zvb31gICsgJ2Fub3RoZXIgc3RyaW5nJyk7XG4gKiAgIC4uLlxuICovXG5jb25zdCBmb3JtYXRFcnJvck1lc3NhZ2UgPSBjcmVhdGVGb3JtYXRFcnJvck1lc3NhZ2UoJ2h0dHBzOi8vYmFzZS11aS5jb20vcHJvZHVjdGlvbi1lcnJvcicsICdCYXNlIFVJJyk7XG5leHBvcnQgZGVmYXVsdCBmb3JtYXRFcnJvck1lc3NhZ2U7IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuY29uc3QgbWFqb3JWZXJzaW9uID0gcGFyc2VJbnQoUmVhY3QudmVyc2lvbiwgMTApO1xuZXhwb3J0IGZ1bmN0aW9uIGlzUmVhY3RWZXJzaW9uQXRMZWFzdChyZWFjdFZlcnNpb25Ub0NoZWNrKSB7XG4gIHJldHVybiBtYWpvclZlcnNpb24gPj0gcmVhY3RWZXJzaW9uVG9DaGVjaztcbn0iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBpc1JlYWN0VmVyc2lvbkF0TGVhc3QgfSBmcm9tIFwiLi9yZWFjdFZlcnNpb24ubWpzXCI7XG5cbi8qKlxuICogRXh0cmFjdHMgdGhlIGByZWZgIGZyb20gYSBSZWFjdCBlbGVtZW50LCBoYW5kbGluZyBkaWZmZXJlbnQgUmVhY3QgdmVyc2lvbnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRSZWFjdEVsZW1lbnRSZWYoZWxlbWVudCkge1xuICBpZiAoISAvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQoZWxlbWVudCkpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCByZWFjdEVsZW1lbnQgPSBlbGVtZW50O1xuICBjb25zdCBwcm9wc1dpdGhSZWYgPSByZWFjdEVsZW1lbnQucHJvcHM7XG4gIHJldHVybiAoaXNSZWFjdFZlcnNpb25BdExlYXN0KDE5KSA/IHByb3BzV2l0aFJlZj8ucmVmIDogcmVhY3RFbGVtZW50LnJlZikgPz8gbnVsbDtcbn0iLCJleHBvcnQgZnVuY3Rpb24gbWVyZ2VPYmplY3RzKGEsIGIpIHtcbiAgaWYgKGEgJiYgIWIpIHtcbiAgICByZXR1cm4gYTtcbiAgfVxuICBpZiAoIWEgJiYgYikge1xuICAgIHJldHVybiBiO1xuICB9XG4gIGlmIChhIHx8IGIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uYSxcbiAgICAgIC4uLmJcbiAgICB9O1xuICB9XG4gIHJldHVybiB1bmRlZmluZWQ7XG59IiwibGV0IHNldDtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIHNldCA9IG5ldyBTZXQoKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKC4uLm1lc3NhZ2VzKSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgY29uc3QgbWVzc2FnZUtleSA9IG1lc3NhZ2VzLmpvaW4oJyAnKTtcbiAgICBpZiAoIXNldC5oYXMobWVzc2FnZUtleSkpIHtcbiAgICAgIHNldC5hZGQobWVzc2FnZUtleSk7XG4gICAgICBjb25zb2xlLndhcm4oYEJhc2UgVUk6ICR7bWVzc2FnZUtleX1gKTtcbiAgICB9XG4gIH1cbn0iLCJleHBvcnQgZnVuY3Rpb24gZ2V0U3RhdGVBdHRyaWJ1dGVzUHJvcHMoc3RhdGUsIGN1c3RvbU1hcHBpbmcpIHtcbiAgY29uc3QgcHJvcHMgPSB7fTtcblxuICAvKiBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZ3VhcmQtZm9yLWluICovXG4gIGZvciAoY29uc3Qga2V5IGluIHN0YXRlKSB7XG4gICAgY29uc3QgdmFsdWUgPSBzdGF0ZVtrZXldO1xuICAgIGlmIChjdXN0b21NYXBwaW5nPy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICBjb25zdCBjdXN0b21Qcm9wcyA9IGN1c3RvbU1hcHBpbmdba2V5XSh2YWx1ZSk7XG4gICAgICBpZiAoY3VzdG9tUHJvcHMgIT0gbnVsbCkge1xuICAgICAgICBPYmplY3QuYXNzaWduKHByb3BzLCBjdXN0b21Qcm9wcyk7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKHZhbHVlID09PSB0cnVlKSB7XG4gICAgICBwcm9wc1tgZGF0YS0ke2tleS50b0xvd2VyQ2FzZSgpfWBdID0gJyc7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSkge1xuICAgICAgcHJvcHNbYGRhdGEtJHtrZXkudG9Mb3dlckNhc2UoKX1gXSA9IHZhbHVlLnRvU3RyaW5nKCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBwcm9wcztcbn0iLCIvKipcbiAqIElmIHRoZSBwcm92aWRlZCBjbGFzc05hbWUgaXMgYSBzdHJpbmcsIGl0IHdpbGwgYmUgcmV0dXJuZWQgYXMgaXMuXG4gKiBPdGhlcndpc2UsIHRoZSBmdW5jdGlvbiB3aWxsIGNhbGwgdGhlIGNsYXNzTmFtZSBmdW5jdGlvbiB3aXRoIHRoZSBzdGF0ZSBhcyB0aGUgZmlyc3QgYXJndW1lbnQuXG4gKlxuICogQHBhcmFtIGNsYXNzTmFtZVxuICogQHBhcmFtIHN0YXRlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQ2xhc3NOYW1lKGNsYXNzTmFtZSwgc3RhdGUpIHtcbiAgcmV0dXJuIHR5cGVvZiBjbGFzc05hbWUgPT09ICdmdW5jdGlvbicgPyBjbGFzc05hbWUoc3RhdGUpIDogY2xhc3NOYW1lO1xufSIsIi8qKlxuICogSWYgdGhlIHByb3ZpZGVkIHN0eWxlIGlzIGFuIG9iamVjdCwgaXQgd2lsbCBiZSByZXR1cm5lZCBhcyBpcy5cbiAqIE90aGVyd2lzZSwgdGhlIGZ1bmN0aW9uIHdpbGwgY2FsbCB0aGUgc3R5bGUgZnVuY3Rpb24gd2l0aCB0aGUgc3RhdGUgYXMgdGhlIGZpcnN0IGFyZ3VtZW50LlxuICpcbiAqIEBwYXJhbSBzdHlsZVxuICogQHBhcmFtIHN0YXRlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlU3R5bGUoc3R5bGUsIHN0YXRlKSB7XG4gIHJldHVybiB0eXBlb2Ygc3R5bGUgPT09ICdmdW5jdGlvbicgPyBzdHlsZShzdGF0ZSkgOiBzdHlsZTtcbn0iLCJpbXBvcnQgeyBtZXJnZU9iamVjdHMgfSBmcm9tICdAYmFzZS11aS91dGlscy9tZXJnZU9iamVjdHMnO1xuY29uc3QgRU1QVFlfUFJPUFMgPSB7fTtcblxuLyogZXNsaW50LWRpc2FibGUgaWQtZGVueWxpc3QgKi9cbi8qKlxuICogTWVyZ2VzIG11bHRpcGxlIHNldHMgb2YgUmVhY3QgcHJvcHMuIEl0IGZvbGxvd3MgdGhlIE9iamVjdC5hc3NpZ24gcGF0dGVybiB3aGVyZSB0aGUgcmlnaHRtb3N0IG9iamVjdCdzIGZpZWxkcyBvdmVyd3JpdGVcbiAqIHRoZSBjb25mbGljdGluZyBvbmVzIGZyb20gb3RoZXJzLiBUaGlzIGRvZXNuJ3QgYXBwbHkgdG8gZXZlbnQgaGFuZGxlcnMsIGBjbGFzc05hbWVgIGFuZCBgc3R5bGVgIHByb3BzLlxuICpcbiAqIEV2ZW50IGhhbmRsZXJzIGFyZSBtZXJnZWQgYW5kIGNhbGxlZCBpbiByaWdodC10by1sZWZ0IG9yZGVyIChyaWdodG1vc3QgaGFuZGxlciBleGVjdXRlcyBmaXJzdCwgbGVmdG1vc3QgbGFzdCkuXG4gKiBGb3IgUmVhY3Qgc3ludGhldGljIGV2ZW50cywgdGhlIHJpZ2h0bW9zdCBoYW5kbGVyIGNhbiBwcmV2ZW50IHByaW9yIChsZWZ0LXBvc2l0aW9uZWQpIGhhbmRsZXJzIGZyb20gZXhlY3V0aW5nXG4gKiBieSBjYWxsaW5nIGBldmVudC5wcmV2ZW50QmFzZVVJSGFuZGxlcigpYC4gRm9yIG5vbi1zeW50aGV0aWMgZXZlbnRzIChjdXN0b20gZXZlbnRzIHdpdGggcHJpbWl0aXZlL29iamVjdCB2YWx1ZXMpLFxuICogYWxsIGhhbmRsZXJzIGFsd2F5cyBleGVjdXRlIHdpdGhvdXQgcHJldmVudGlvbiBjYXBhYmlsaXR5LlxuICpcbiAqIFRoZSBgY2xhc3NOYW1lYCBwcm9wIGlzIG1lcmdlZCBieSBjb25jYXRlbmF0aW5nIGNsYXNzZXMgaW4gcmlnaHQtdG8tbGVmdCBvcmRlciAocmlnaHRtb3N0IGNsYXNzIGFwcGVhcnMgZmlyc3QgaW4gdGhlIHN0cmluZykuXG4gKiBUaGUgYHN0eWxlYCBwcm9wIGlzIG1lcmdlZCB3aXRoIHJpZ2h0bW9zdCBzdHlsZXMgb3ZlcndyaXRpbmcgdGhlIHByaW9yIG9uZXMuXG4gKlxuICogUHJvcHMgY2FuIGVpdGhlciBiZSBwcm92aWRlZCBhcyBvYmplY3RzIG9yIGFzIGZ1bmN0aW9ucyB0aGF0IHRha2UgdGhlIHByZXZpb3VzIHByb3BzIGFzIGFuIGFyZ3VtZW50LlxuICogVGhlIGZ1bmN0aW9uIHdpbGwgcmVjZWl2ZSB0aGUgbWVyZ2VkIHByb3BzIHVwIHRvIHRoYXQgcG9pbnQgKGdvaW5nIGZyb20gbGVmdCB0byByaWdodCk6XG4gKiBzbyBpbiB0aGUgY2FzZSBvZiBgKG9iajEsIG9iajIsIGZuLCBvYmozKWAsIGBmbmAgd2lsbCByZWNlaXZlIHRoZSBtZXJnZWQgcHJvcHMgb2YgYG9iajFgIGFuZCBgb2JqMmAuXG4gKiBUaGUgZnVuY3Rpb24gaXMgcmVzcG9uc2libGUgZm9yIGNoYWluaW5nIGV2ZW50IGhhbmRsZXJzIGlmIG5lZWRlZCAodGhhdCBpcywgd2UgZG9uJ3QgcnVuIHRoZSBtZXJnZSBsb2dpYykuXG4gKlxuICogRXZlbnQgaGFuZGxlcnMgcmV0dXJuZWQgYnkgdGhlIGZ1bmN0aW9ucyBhcmUgbm90IGF1dG9tYXRpY2FsbHkgcHJldmVudGVkIHdoZW4gYHByZXZlbnRCYXNlVUlIYW5kbGVyYCBpcyBjYWxsZWQuXG4gKiBUaGV5IG11c3QgY2hlY2sgYGV2ZW50LmJhc2VVSUhhbmRsZXJQcmV2ZW50ZWRgIHRoZW1zZWx2ZXMgYW5kIGJhaWwgb3V0IGlmIGl0J3MgdHJ1ZS5cbiAqXG4gKiBAaW1wb3J0YW50ICoqYHJlZmAgaXMgbm90IG1lcmdlZC4qKlxuICogQHBhcmFtIGEgUHJvcHMgb2JqZWN0IHRvIG1lcmdlLlxuICogQHBhcmFtIGIgUHJvcHMgb2JqZWN0IHRvIG1lcmdlLiBUaGUgZnVuY3Rpb24gd2lsbCBvdmVyd3JpdGUgY29uZmxpY3RpbmcgcHJvcHMgZnJvbSBgYWAuXG4gKiBAcGFyYW0gYyBQcm9wcyBvYmplY3QgdG8gbWVyZ2UuIFRoZSBmdW5jdGlvbiB3aWxsIG92ZXJ3cml0ZSBjb25mbGljdGluZyBwcm9wcyBmcm9tIHByZXZpb3VzIHBhcmFtZXRlcnMuXG4gKiBAcGFyYW0gZCBQcm9wcyBvYmplY3QgdG8gbWVyZ2UuIFRoZSBmdW5jdGlvbiB3aWxsIG92ZXJ3cml0ZSBjb25mbGljdGluZyBwcm9wcyBmcm9tIHByZXZpb3VzIHBhcmFtZXRlcnMuXG4gKiBAcGFyYW0gZSBQcm9wcyBvYmplY3QgdG8gbWVyZ2UuIFRoZSBmdW5jdGlvbiB3aWxsIG92ZXJ3cml0ZSBjb25mbGljdGluZyBwcm9wcyBmcm9tIHByZXZpb3VzIHBhcmFtZXRlcnMuXG4gKiBAcmV0dXJucyBUaGUgbWVyZ2VkIHByb3BzLlxuICogQHB1YmxpY1xuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBtZXJnZVByb3BzKGEsIGIsIGMsIGQsIGUpIHtcbiAgaWYgKCFjICYmICFkICYmICFlICYmICFhKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUluaXRpYWxNZXJnZWRQcm9wcyhiKTtcbiAgfVxuXG4gIC8vIFdlIG5lZWQgdG8gbXV0YWJseSBvd24gYG1lcmdlZGAuXG4gIGxldCBtZXJnZWQgPSBjcmVhdGVJbml0aWFsTWVyZ2VkUHJvcHMoYSk7XG4gIGlmIChiKSB7XG4gICAgbWVyZ2VkID0gbWVyZ2VJbnRvKG1lcmdlZCwgYik7XG4gIH1cbiAgaWYgKGMpIHtcbiAgICBtZXJnZWQgPSBtZXJnZUludG8obWVyZ2VkLCBjKTtcbiAgfVxuICBpZiAoZCkge1xuICAgIG1lcmdlZCA9IG1lcmdlSW50byhtZXJnZWQsIGQpO1xuICB9XG4gIGlmIChlKSB7XG4gICAgbWVyZ2VkID0gbWVyZ2VJbnRvKG1lcmdlZCwgZSk7XG4gIH1cbiAgcmV0dXJuIG1lcmdlZDtcbn1cbi8qIGVzbGludC1lbmFibGUgaWQtZGVueWxpc3QgKi9cblxuLyoqXG4gKiBNZXJnZXMgYW4gYXJiaXRyYXJ5IG51bWJlciBvZiBSZWFjdCBwcm9wcyB1c2luZyB0aGUgc2FtZSBsb2dpYyBhcyB7QGxpbmsgbWVyZ2VQcm9wc30uXG4gKiBUaGlzIGZ1bmN0aW9uIGFjY2VwdHMgYW4gYXJyYXkgb2YgcHJvcHMgaW5zdGVhZCBvZiBpbmRpdmlkdWFsIGFyZ3VtZW50cy5cbiAqXG4gKiBUaGlzIGhhcyBzbGlnaHRseSBsb3dlciBwZXJmb3JtYW5jZSB0aGFuIHtAbGluayBtZXJnZVByb3BzfSBkdWUgdG8gYWNjZXB0aW5nIGFuIGFycmF5XG4gKiBpbnN0ZWFkIG9mIGEgZml4ZWQgbnVtYmVyIG9mIGFyZ3VtZW50cy4gUHJlZmVyIHtAbGluayBtZXJnZVByb3BzfSB3aGVuIG1lcmdpbmcgNSBvclxuICogZmV3ZXIgcHJvcCBzZXRzIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2UuXG4gKlxuICogQHBhcmFtIHByb3BzIEFycmF5IG9mIHByb3BzIHRvIG1lcmdlLlxuICogQHJldHVybnMgVGhlIG1lcmdlZCBwcm9wcy5cbiAqIEBzZWUgbWVyZ2VQcm9wc1xuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VQcm9wc04ocHJvcHMpIHtcbiAgaWYgKHByb3BzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBFTVBUWV9QUk9QUztcbiAgfVxuICBpZiAocHJvcHMubGVuZ3RoID09PSAxKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUluaXRpYWxNZXJnZWRQcm9wcyhwcm9wc1swXSk7XG4gIH1cblxuICAvLyBXZSBuZWVkIHRvIG11dGFibHkgb3duIGBtZXJnZWRgLlxuICBsZXQgbWVyZ2VkID0gY3JlYXRlSW5pdGlhbE1lcmdlZFByb3BzKHByb3BzWzBdKTtcbiAgZm9yIChsZXQgaSA9IDE7IGkgPCBwcm9wcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgIG1lcmdlZCA9IG1lcmdlSW50byhtZXJnZWQsIHByb3BzW2ldKTtcbiAgfVxuICByZXR1cm4gbWVyZ2VkO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5pdGlhbE1lcmdlZFByb3BzKGlucHV0UHJvcHMpIHtcbiAgaWYgKGlzUHJvcHNHZXR0ZXIoaW5wdXRQcm9wcykpIHtcbiAgICAvLyBHZXR0ZXItcmV0dXJuZWQgaGFuZGxlcnMgaW50ZW50aW9uYWxseSBrZWVwIHRoZWlyIGV4aXN0aW5nIHNlbWFudGljcy5cbiAgICByZXR1cm4ge1xuICAgICAgLi4ucmVzb2x2ZVByb3BzR2V0dGVyKGlucHV0UHJvcHMsIEVNUFRZX1BST1BTKVxuICAgIH07XG4gIH1cbiAgcmV0dXJuIGNvcHlJbml0aWFsUHJvcHMoaW5wdXRQcm9wcyk7XG59XG5mdW5jdGlvbiBtZXJnZUludG8obWVyZ2VkLCBpbnB1dFByb3BzKSB7XG4gIGlmIChpc1Byb3BzR2V0dGVyKGlucHV0UHJvcHMpKSB7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9wc0dldHRlcihpbnB1dFByb3BzLCBtZXJnZWQpO1xuICB9XG4gIHJldHVybiBtdXRhYmx5TWVyZ2VJbnRvKG1lcmdlZCwgaW5wdXRQcm9wcyk7XG59XG5mdW5jdGlvbiBjb3B5SW5pdGlhbFByb3BzKGlucHV0UHJvcHMpIHtcbiAgY29uc3QgY29waWVkUHJvcHMgPSB7XG4gICAgLi4uaW5wdXRQcm9wc1xuICB9O1xuXG4gIC8vIGBjb3BpZWRQcm9wc2AgaXMgb3VyIGZyZXNoIG93bi1vYmplY3QgY29weSwgc28gaXRlcmF0aW5nIHdpdGggYGZvci4uLmluYCBpcyBzYWZlIGhlcmUuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBndWFyZC1mb3ItaW5cbiAgZm9yIChjb25zdCBwcm9wTmFtZSBpbiBjb3BpZWRQcm9wcykge1xuICAgIGNvbnN0IHByb3BWYWx1ZSA9IGNvcGllZFByb3BzW3Byb3BOYW1lXTtcbiAgICBpZiAoaXNFdmVudEhhbmRsZXIocHJvcE5hbWUsIHByb3BWYWx1ZSkpIHtcbiAgICAgIGNvcGllZFByb3BzW3Byb3BOYW1lXSA9IHdyYXBFdmVudEhhbmRsZXIocHJvcFZhbHVlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGNvcGllZFByb3BzO1xufVxuXG4vKipcbiAqIE1lcmdlcyB0d28gc2V0cyBvZiBwcm9wcy4gSW4gY2FzZSBvZiBjb25mbGljdHMsIHRoZSBleHRlcm5hbCBwcm9wcyB0YWtlIHByZWNlZGVuY2UuXG4gKi9cbmZ1bmN0aW9uIG11dGFibHlNZXJnZUludG8obWVyZ2VkUHJvcHMsIGV4dGVybmFsUHJvcHMpIHtcbiAgaWYgKCFleHRlcm5hbFByb3BzKSB7XG4gICAgcmV0dXJuIG1lcmdlZFByb3BzO1xuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGd1YXJkLWZvci1pblxuICBmb3IgKGNvbnN0IHByb3BOYW1lIGluIGV4dGVybmFsUHJvcHMpIHtcbiAgICBjb25zdCBleHRlcm5hbFByb3BWYWx1ZSA9IGV4dGVybmFsUHJvcHNbcHJvcE5hbWVdO1xuICAgIHN3aXRjaCAocHJvcE5hbWUpIHtcbiAgICAgIGNhc2UgJ3N0eWxlJzpcbiAgICAgICAge1xuICAgICAgICAgIG1lcmdlZFByb3BzW3Byb3BOYW1lXSA9IG1lcmdlT2JqZWN0cyhtZXJnZWRQcm9wcy5zdHlsZSwgZXh0ZXJuYWxQcm9wVmFsdWUpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICBjYXNlICdjbGFzc05hbWUnOlxuICAgICAgICB7XG4gICAgICAgICAgbWVyZ2VkUHJvcHNbcHJvcE5hbWVdID0gbWVyZ2VDbGFzc05hbWVzKG1lcmdlZFByb3BzLmNsYXNzTmFtZSwgZXh0ZXJuYWxQcm9wVmFsdWUpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB7XG4gICAgICAgICAgaWYgKGlzRXZlbnRIYW5kbGVyKHByb3BOYW1lLCBleHRlcm5hbFByb3BWYWx1ZSkpIHtcbiAgICAgICAgICAgIG1lcmdlZFByb3BzW3Byb3BOYW1lXSA9IG1lcmdlRXZlbnRIYW5kbGVycyhtZXJnZWRQcm9wc1twcm9wTmFtZV0sIGV4dGVybmFsUHJvcFZhbHVlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbWVyZ2VkUHJvcHNbcHJvcE5hbWVdID0gZXh0ZXJuYWxQcm9wVmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWRQcm9wcztcbn1cbmZ1bmN0aW9uIGlzRXZlbnRIYW5kbGVyKGtleSwgdmFsdWUpIHtcbiAgLy8gVGhpcyBhcHByb2FjaCBpcyBtb3JlIGVmZmljaWVudCB0aGFuIHVzaW5nIGEgcmVnZXguXG4gIGNvbnN0IGNvZGUwID0ga2V5LmNoYXJDb2RlQXQoMCk7XG4gIGNvbnN0IGNvZGUxID0ga2V5LmNoYXJDb2RlQXQoMSk7XG4gIGNvbnN0IGNvZGUyID0ga2V5LmNoYXJDb2RlQXQoMik7XG4gIHJldHVybiBjb2RlMCA9PT0gMTExIC8qIG8gKi8gJiYgY29kZTEgPT09IDExMCAvKiBuICovICYmIGNvZGUyID49IDY1IC8qIEEgKi8gJiYgY29kZTIgPD0gOTAgLyogWiAqLyAmJiAodHlwZW9mIHZhbHVlID09PSAnZnVuY3Rpb24nIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCcpO1xufVxuZnVuY3Rpb24gaXNQcm9wc0dldHRlcihpbnB1dFByb3BzKSB7XG4gIHJldHVybiB0eXBlb2YgaW5wdXRQcm9wcyA9PT0gJ2Z1bmN0aW9uJztcbn1cbmZ1bmN0aW9uIHJlc29sdmVQcm9wc0dldHRlcihpbnB1dFByb3BzLCBwcmV2aW91c1Byb3BzKSB7XG4gIGlmIChpc1Byb3BzR2V0dGVyKGlucHV0UHJvcHMpKSB7XG4gICAgcmV0dXJuIGlucHV0UHJvcHMocHJldmlvdXNQcm9wcyk7XG4gIH1cbiAgcmV0dXJuIGlucHV0UHJvcHMgPz8gRU1QVFlfUFJPUFM7XG59XG5mdW5jdGlvbiBtZXJnZUV2ZW50SGFuZGxlcnMob3VySGFuZGxlciwgdGhlaXJIYW5kbGVyKSB7XG4gIGlmICghdGhlaXJIYW5kbGVyKSB7XG4gICAgcmV0dXJuIG91ckhhbmRsZXI7XG4gIH1cbiAgaWYgKCFvdXJIYW5kbGVyKSB7XG4gICAgcmV0dXJuIHdyYXBFdmVudEhhbmRsZXIodGhlaXJIYW5kbGVyKTtcbiAgfVxuICByZXR1cm4gKC4uLmFyZ3MpID0+IHtcbiAgICBjb25zdCBldmVudCA9IGFyZ3NbMF07XG4gICAgaWYgKGlzU3ludGhldGljRXZlbnQoZXZlbnQpKSB7XG4gICAgICBjb25zdCBiYXNlVUlFdmVudCA9IGV2ZW50O1xuICAgICAgbWFrZUV2ZW50UHJldmVudGFibGUoYmFzZVVJRXZlbnQpO1xuICAgICAgY29uc3QgcmVzdWx0ID0gdGhlaXJIYW5kbGVyKC4uLmFyZ3MpO1xuICAgICAgaWYgKCFiYXNlVUlFdmVudC5iYXNlVUlIYW5kbGVyUHJldmVudGVkKSB7XG4gICAgICAgIG91ckhhbmRsZXI/LiguLi5hcmdzKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IHRoZWlySGFuZGxlciguLi5hcmdzKTtcbiAgICBvdXJIYW5kbGVyPy4oLi4uYXJncyk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfTtcbn1cbmZ1bmN0aW9uIHdyYXBFdmVudEhhbmRsZXIoaGFuZGxlcikge1xuICBpZiAoIWhhbmRsZXIpIHtcbiAgICByZXR1cm4gaGFuZGxlcjtcbiAgfVxuICByZXR1cm4gKC4uLmFyZ3MpID0+IHtcbiAgICBjb25zdCBldmVudCA9IGFyZ3NbMF07XG4gICAgaWYgKGlzU3ludGhldGljRXZlbnQoZXZlbnQpKSB7XG4gICAgICBtYWtlRXZlbnRQcmV2ZW50YWJsZShldmVudCk7XG4gICAgfVxuICAgIHJldHVybiBoYW5kbGVyKC4uLmFyZ3MpO1xuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIG1ha2VFdmVudFByZXZlbnRhYmxlKGV2ZW50KSB7XG4gIGV2ZW50LnByZXZlbnRCYXNlVUlIYW5kbGVyID0gKCkgPT4ge1xuICAgIGV2ZW50LmJhc2VVSUhhbmRsZXJQcmV2ZW50ZWQgPSB0cnVlO1xuICB9O1xuICByZXR1cm4gZXZlbnQ7XG59XG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VDbGFzc05hbWVzKG91ckNsYXNzTmFtZSwgdGhlaXJDbGFzc05hbWUpIHtcbiAgaWYgKHRoZWlyQ2xhc3NOYW1lKSB7XG4gICAgaWYgKG91ckNsYXNzTmFtZSkge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHByZWZlci10ZW1wbGF0ZVxuICAgICAgcmV0dXJuIHRoZWlyQ2xhc3NOYW1lICsgJyAnICsgb3VyQ2xhc3NOYW1lO1xuICAgIH1cbiAgICByZXR1cm4gdGhlaXJDbGFzc05hbWU7XG4gIH1cbiAgcmV0dXJuIG91ckNsYXNzTmFtZTtcbn1cbmZ1bmN0aW9uIGlzU3ludGhldGljRXZlbnQoZXZlbnQpIHtcbiAgcmV0dXJuIGV2ZW50ICE9IG51bGwgJiYgdHlwZW9mIGV2ZW50ID09PSAnb2JqZWN0JyAmJiAnbmF0aXZlRXZlbnQnIGluIGV2ZW50O1xufSIsImltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1lcmdlZFJlZnMsIHVzZU1lcmdlZFJlZnNOIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlTWVyZ2VkUmVmcyc7XG5pbXBvcnQgeyBnZXRSZWFjdEVsZW1lbnRSZWYgfSBmcm9tICdAYmFzZS11aS91dGlscy9nZXRSZWFjdEVsZW1lbnRSZWYnO1xuaW1wb3J0IHsgbWVyZ2VPYmplY3RzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvbWVyZ2VPYmplY3RzJztcbmltcG9ydCB7IHdhcm4gfSBmcm9tICdAYmFzZS11aS91dGlscy93YXJuJztcbmltcG9ydCB7IEVNUFRZX09CSkVDVCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IGdldFN0YXRlQXR0cmlidXRlc1Byb3BzIH0gZnJvbSBcIi4vZ2V0U3RhdGVBdHRyaWJ1dGVzUHJvcHMubWpzXCI7XG5pbXBvcnQgeyByZXNvbHZlQ2xhc3NOYW1lIH0gZnJvbSBcIi4uL3V0aWxzL3Jlc29sdmVDbGFzc05hbWUubWpzXCI7XG5pbXBvcnQgeyByZXNvbHZlU3R5bGUgfSBmcm9tIFwiLi4vdXRpbHMvcmVzb2x2ZVN0eWxlLm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcywgbWVyZ2VQcm9wc04sIG1lcmdlQ2xhc3NOYW1lcyB9IGZyb20gXCIuLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUVsZW1lbnQgYXMgX2NyZWF0ZUVsZW1lbnQgfSBmcm9tIFwicmVhY3RcIjtcbi8qKlxuICogUmVuZGVycyBhIEJhc2UgVUkgZWxlbWVudC5cbiAqXG4gKiBAcGFyYW0gZWxlbWVudCBUaGUgZGVmYXVsdCBIVE1MIGVsZW1lbnQgdG8gcmVuZGVyLiBDYW4gYmUgb3ZlcnJpZGRlbiBieSB0aGUgYHJlbmRlcmAgcHJvcC5cbiAqIEBwYXJhbSBjb21wb25lbnRQcm9wcyBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgYHJlbmRlcmAgYW5kIGBjbGFzc05hbWVgIHByb3BzIHRvIGJlIHVzZWQgZm9yIGVsZW1lbnQgY3VzdG9taXphdGlvbi4gT3RoZXIgcHJvcHMgYXJlIGlnbm9yZWQuXG4gKiBAcGFyYW0gcGFyYW1zIEFkZGl0aW9uYWwgcGFyYW1ldGVycyBmb3IgcmVuZGVyaW5nIHRoZSBlbGVtZW50LlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUmVuZGVyRWxlbWVudChlbGVtZW50LCBjb21wb25lbnRQcm9wcywgcGFyYW1zID0ge30pIHtcbiAgY29uc3QgcmVuZGVyUHJvcCA9IGNvbXBvbmVudFByb3BzLnJlbmRlcjtcbiAgY29uc3Qgb3V0UHJvcHMgPSB1c2VSZW5kZXJFbGVtZW50UHJvcHMoY29tcG9uZW50UHJvcHMsIHBhcmFtcyk7XG4gIGlmIChwYXJhbXMuZW5hYmxlZCA9PT0gZmFsc2UpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCBzdGF0ZSA9IHBhcmFtcy5zdGF0ZSA/PyBFTVBUWV9PQkpFQ1Q7XG4gIHJldHVybiBldmFsdWF0ZVJlbmRlclByb3AoZWxlbWVudCwgcmVuZGVyUHJvcCwgb3V0UHJvcHMsIHN0YXRlKTtcbn1cblxuLyoqXG4gKiBDb21wdXRlcyByZW5kZXIgZWxlbWVudCBmaW5hbCBwcm9wcy5cbiAqL1xuZnVuY3Rpb24gdXNlUmVuZGVyRWxlbWVudFByb3BzKGNvbXBvbmVudFByb3BzLCBwYXJhbXMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgY2xhc3NOYW1lOiBjbGFzc05hbWVQcm9wLFxuICAgIHN0eWxlOiBzdHlsZVByb3AsXG4gICAgcmVuZGVyOiByZW5kZXJQcm9wXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHN0YXRlID0gRU1QVFlfT0JKRUNULFxuICAgIHJlZixcbiAgICBwcm9wcyxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLFxuICAgIGVuYWJsZWQgPSB0cnVlXG4gIH0gPSBwYXJhbXM7XG4gIGNvbnN0IGNsYXNzTmFtZSA9IGVuYWJsZWQgPyByZXNvbHZlQ2xhc3NOYW1lKGNsYXNzTmFtZVByb3AsIHN0YXRlKSA6IHVuZGVmaW5lZDtcbiAgY29uc3Qgc3R5bGUgPSBlbmFibGVkID8gcmVzb2x2ZVN0eWxlKHN0eWxlUHJvcCwgc3RhdGUpIDogdW5kZWZpbmVkO1xuICBjb25zdCBzdGF0ZVByb3BzID0gZW5hYmxlZCA/IGdldFN0YXRlQXR0cmlidXRlc1Byb3BzKHN0YXRlLCBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nKSA6IEVNUFRZX09CSkVDVDtcbiAgY29uc3QgcmVzb2x2ZWRQcm9wcyA9IGVuYWJsZWQgJiYgcHJvcHMgPyByZXNvbHZlUmVuZGVyRnVuY3Rpb25Qcm9wcyhwcm9wcykgOiB1bmRlZmluZWQ7XG5cbiAgLy8gRW5zdXJlIG91dFByb3BzIGlzIGFsd2F5cyBhIG5ldyBtdXRhYmxlIG9iamVjdCB3aGVuIGVuYWJsZWQsIG5ldmVyIEVNUFRZX09CSkVDVC5cbiAgLy8gVGhpcyBwcmV2ZW50cyBwb3RlbnRpYWwgVHlwZUVycm9yIHdoZW4gc2V0dGluZyByZWYsIGNsYXNzTmFtZSwgb3Igc3R5bGUgcHJvcGVydGllcyxcbiAgLy8gc2luY2UgRU1QVFlfT0JKRUNUIGlzIGZyb3plbiBhbmQgbXV0YXRpb25zIHdvdWxkIGZhaWwgaW4gc3RyaWN0IG1vZGUuXG4gIGNvbnN0IG91dFByb3BzID0gZW5hYmxlZCA/IG1lcmdlT2JqZWN0cyhzdGF0ZVByb3BzLCByZXNvbHZlZFByb3BzKSA/PyB7fSA6IEVNUFRZX09CSkVDVDtcblxuICAvLyBTQUZFVFk6IFRoZSBgdXNlTWVyZ2VkUmVmc2AgZnVuY3Rpb25zIHVzZSBhIHNpbmdsZSBob29rIHRvIHN0b3JlIHRoZSBzYW1lIHZhbHVlLFxuICAvLyBzd2l0Y2hpbmcgYmV0d2VlbiB0aGVtIGF0IHJ1bnRpbWUgaXMgc2FmZS4gSWYgdGhpcyBhc3NlcnRpb24gZmFpbHMsIFJlYWN0IHdpbGxcbiAgLy8gdGhyb3cgYXQgcnVudGltZSBhbnl3YXkuXG4gIC8vIFRoaXMgYWxzbyBza2lwcyB0aGUgYHVzZU1lcmdlZFJlZnNgIGNhbGwgb24gdGhlIHNlcnZlciwgd2hpY2ggaXMgZmluZSBiZWNhdXNlXG4gIC8vIHJlZnMgYXJlIG5vdCB1c2VkIG9uIHRoZSBzZXJ2ZXIgc2lkZS5cbiAgLyogZXNsaW50LWRpc2FibGUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3MgKi9cbiAgaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIC8vIENhbGxlZCBvbmx5IHRvIGtlZXAgdGhlIGhvb2sgb3JkZXIgc3RhYmxlIHdoZW4gZGlzYWJsZWQ7IHRoZSBtZXJnZWQgcmVmIGlzIHVudXNlZC5cbiAgICAgIHZvaWQgdXNlTWVyZ2VkUmVmcyhudWxsLCBudWxsKTtcbiAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocmVmKSkge1xuICAgICAgb3V0UHJvcHMucmVmID0gdXNlTWVyZ2VkUmVmc04oW291dFByb3BzLnJlZiwgZ2V0UmVhY3RFbGVtZW50UmVmKHJlbmRlclByb3ApLCAuLi5yZWZdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0UHJvcHMucmVmID0gdXNlTWVyZ2VkUmVmcyhvdXRQcm9wcy5yZWYsIGdldFJlYWN0RWxlbWVudFJlZihyZW5kZXJQcm9wKSwgcmVmKTtcbiAgICB9XG4gIH1cbiAgaWYgKCFlbmFibGVkKSB7XG4gICAgcmV0dXJuIEVNUFRZX09CSkVDVDtcbiAgfVxuICBpZiAoY2xhc3NOYW1lICE9PSB1bmRlZmluZWQpIHtcbiAgICBvdXRQcm9wcy5jbGFzc05hbWUgPSBtZXJnZUNsYXNzTmFtZXMob3V0UHJvcHMuY2xhc3NOYW1lLCBjbGFzc05hbWUpO1xuICB9XG4gIGlmIChzdHlsZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgb3V0UHJvcHMuc3R5bGUgPSBtZXJnZU9iamVjdHMob3V0UHJvcHMuc3R5bGUsIHN0eWxlKTtcbiAgfVxuICByZXR1cm4gb3V0UHJvcHM7XG59XG5mdW5jdGlvbiByZXNvbHZlUmVuZGVyRnVuY3Rpb25Qcm9wcyhwcm9wcykge1xuICBpZiAoQXJyYXkuaXNBcnJheShwcm9wcykpIHtcbiAgICByZXR1cm4gbWVyZ2VQcm9wc04ocHJvcHMpO1xuICB9XG4gIHJldHVybiBtZXJnZVByb3BzKHVuZGVmaW5lZCwgcHJvcHMpO1xufVxuXG4vLyBUaGUgc3ltYm9sIFJlYWN0IHVzZXMgaW50ZXJuYWxseSBmb3IgbGF6eSBjb21wb25lbnRzXG4vLyBodHRwczovL2dpdGh1Yi5jb20vcmVhY3QvcmVhY3QvYmxvYi9hMDU2NjI1MGIyMTA0OTliNGM1Njc3ZjVhYzJlZWRiZDcxZDUxYTFiL3BhY2thZ2VzL3NoYXJlZC9SZWFjdFN5bWJvbHMuanMjTDMxXG4vL1xuLy8gVE9ETyBkZWxldGUgb25jZSBodHRwczovL2dpdGh1Yi5jb20vcmVhY3QvcmVhY3QvaXNzdWVzLzMyMzkyIGlzIGZpeGVkXG5jb25zdCBSRUFDVF9MQVpZX1RZUEUgPSBTeW1ib2wuZm9yKCdyZWFjdC5sYXp5Jyk7XG5jb25zdCBDT01QT05FTlRfSURFTlRJRklFUl9QQVRURVJOID0gL15bQS1aXVtBLVphLXowLTkkXSokLztcbmNvbnN0IExPV0VSQ0FTRV9DSEFSQUNURVJfUEFUVEVSTiA9IC9bYS16XS87XG5mdW5jdGlvbiBldmFsdWF0ZVJlbmRlclByb3AoZWxlbWVudCwgcmVuZGVyLCBwcm9wcywgc3RhdGUpIHtcbiAgaWYgKHJlbmRlcikge1xuICAgIGlmICh0eXBlb2YgcmVuZGVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICB3YXJuSWZSZW5kZXJQcm9wTG9va3NMaWtlQ29tcG9uZW50KHJlbmRlcik7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVuZGVyKHByb3BzLCBzdGF0ZSk7XG4gICAgfVxuICAgIGNvbnN0IG1lcmdlZFByb3BzID0gbWVyZ2VQcm9wcyhwcm9wcywgcmVuZGVyLnByb3BzKTtcbiAgICBtZXJnZWRQcm9wcy5yZWYgPSBwcm9wcy5yZWY7XG4gICAgbGV0IG5ld0VsZW1lbnQgPSByZW5kZXI7XG4gICAgLy8gV29ya2Fyb3VuZCBmb3IgaHR0cHM6Ly9naXRodWIuY29tL3JlYWN0L3JlYWN0L2lzc3Vlcy8zMjM5MlxuICAgIC8vIFRoaXMgd29ya3MgYmVjYXVzZSB0aGUgdG9BcnJheSgpIGxvZ2ljIHVud3JhcCBsYXp5IGVsZW1lbnQgdHlwZSBpblxuICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWFjdC9yZWFjdC9ibG9iL2EwNTY2MjUwYjIxMDQ5OWI0YzU2NzdmNWFjMmVlZGJkNzFkNTFhMWIvcGFja2FnZXMvcmVhY3Qvc3JjL1JlYWN0Q2hpbGRyZW4uanMjTDE4NlxuICAgIGlmIChuZXdFbGVtZW50Py4kJHR5cGVvZiA9PT0gUkVBQ1RfTEFaWV9UWVBFKSB7XG4gICAgICBjb25zdCBjaGlsZHJlbiA9IFJlYWN0LkNoaWxkcmVuLnRvQXJyYXkocmVuZGVyKTtcbiAgICAgIG5ld0VsZW1lbnQgPSBjaGlsZHJlblswXTtcbiAgICB9XG5cbiAgICAvLyBUaGVyZSBpcyBhIGhpZ2ggbnVtYmVyIG9mIGluZGlyZWN0aW9ucywgdGhlIGVycm9yIG1lc3NhZ2UgdGhyb3duIGJ5IFJlYWN0LmNsb25lRWxlbWVudCgpIGlzXG4gICAgLy8gaGFyZCB0byB1c2UgZm9yIGRldmVsb3BlcnMsIHRoaXMgbG9naWMgcHJvdmlkZXMgYSBiZXR0ZXIgY29udGV4dC5cbiAgICAvL1xuICAgIC8vIE91ciBnZW5lcmFsIGd1aWRlbGluZSBpcyB0byBuZXZlciBjaGFuZ2UgdGhlIGNvbnRyb2wgZmxvdyBkZXBlbmRpbmcgb24gdGhlIGVudmlyb25tZW50LlxuICAgIC8vIEhvd2V2ZXIsIFJlYWN0LmNsb25lRWxlbWVudCgpIHRocm93cyBpZiBSZWFjdC5pc1ZhbGlkRWxlbWVudCgpIGlzIGZhbHNlLFxuICAgIC8vIHNvIHdlIGNhbiB0aHJvdyBiZWZvcmUgd2l0aCBjdXN0b20gbWVzc2FnZS5cbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgaWYgKCEgLyojX19QVVJFX18qL1JlYWN0LmlzVmFsaWRFbGVtZW50KG5ld0VsZW1lbnQpKSB7XG4gICAgICAgIC8vIFRPRE86IGZpeCBtdWkvbm8tZ3VhcmRlZC10aHJvd1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFsnQmFzZSBVSTogVGhlIGByZW5kZXJgIHByb3Agd2FzIHByb3ZpZGVkIGFuIGludmFsaWQgUmVhY3QgZWxlbWVudCBhcyBgUmVhY3QuaXNWYWxpZEVsZW1lbnQocmVuZGVyKWAgaXMgYGZhbHNlYC4nLCAnQSB2YWxpZCBSZWFjdCBlbGVtZW50IG11c3QgYmUgcHJvdmlkZWQgdG8gdGhlIGByZW5kZXJgIHByb3AgYmVjYXVzZSBpdCBpcyBjbG9uZWQgd2l0aCBwcm9wcyB0byByZXBsYWNlIHRoZSBkZWZhdWx0IGVsZW1lbnQuJywgJ2h0dHBzOi8vYmFzZS11aS5jb20vci9pbnZhbGlkLXJlbmRlci1wcm9wJ10uam9pbignXFxuJykpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNsb25lRWxlbWVudChuZXdFbGVtZW50LCBtZXJnZWRQcm9wcyk7XG4gIH1cbiAgaWYgKGVsZW1lbnQpIHtcbiAgICBpZiAodHlwZW9mIGVsZW1lbnQgPT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gcmVuZGVyVGFnKGVsZW1lbnQsIHByb3BzKTtcbiAgICB9XG4gIH1cbiAgLy8gVW5yZWFjaGFibGUsIGJ1dCB0aGUgdHlwaW5ncyBvbiBgdXNlUmVuZGVyRWxlbWVudGAgbmVlZCB0byBiZSByZXdvcmtlZFxuICAvLyB0byBhbm5vdGF0ZSBpdCBjb3JyZWN0bHkuXG4gIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogUmVuZGVyIGVsZW1lbnQgb3IgZnVuY3Rpb24gYXJlIG5vdCBkZWZpbmVkLicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDgpKTtcbn1cbmZ1bmN0aW9uIHdhcm5JZlJlbmRlclByb3BMb29rc0xpa2VDb21wb25lbnQocmVuZGVyRm4pIHtcbiAgY29uc3QgZnVuY3Rpb25OYW1lID0gcmVuZGVyRm4ubmFtZTtcbiAgaWYgKGZ1bmN0aW9uTmFtZS5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCFDT01QT05FTlRfSURFTlRJRklFUl9QQVRURVJOLnRlc3QoZnVuY3Rpb25OYW1lKSkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIUxPV0VSQ0FTRV9DSEFSQUNURVJfUEFUVEVSTi50ZXN0KGZ1bmN0aW9uTmFtZSkpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgd2FybihgVGhlIFxcYHJlbmRlclxcYCBwcm9wIHJlY2VpdmVkIGEgZnVuY3Rpb24gbmFtZWQgXFxgJHtmdW5jdGlvbk5hbWV9XFxgIHRoYXQgc3RhcnRzIHdpdGggYW4gdXBwZXJjYXNlIGxldHRlci5gLCAnVGhpcyB1c3VhbGx5IG1lYW5zIGEgUmVhY3QgY29tcG9uZW50IHdhcyBwYXNzZWQgZGlyZWN0bHkgYXMgYHJlbmRlcj17Q29tcG9uZW50fWAuJywgJ0Jhc2UgVUkgY2FsbHMgYHJlbmRlcmAgYXMgYSBwbGFpbiBmdW5jdGlvbiwgd2hpY2ggY2FuIGJyZWFrIHRoZSBSdWxlcyBvZiBIb29rcyBkdXJpbmcgcmVjb25jaWxpYXRpb24uJywgJ0lmIHRoaXMgaXMgYW4gaW50ZW50aW9uYWwgcmVuZGVyIGNhbGxiYWNrLCByZW5hbWUgaXQgdG8gc3RhcnQgd2l0aCBhIGxvd2VyY2FzZSBsZXR0ZXIuJywgJ1VzZSBgcmVuZGVyPXs8Q29tcG9uZW50IC8+fWAgb3IgYHJlbmRlcj17KHByb3BzKSA9PiA8Q29tcG9uZW50IHsuLi5wcm9wc30gLz59YCBpbnN0ZWFkLicsICdodHRwczovL2Jhc2UtdWkuY29tL3IvaW52YWxpZC1yZW5kZXItcHJvcCcpO1xufVxuZnVuY3Rpb24gcmVuZGVyVGFnKFRhZywgcHJvcHMpIHtcbiAgaWYgKFRhZyA9PT0gJ2J1dHRvbicpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL19jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIsIHtcbiAgICAgIHR5cGU6IFwiYnV0dG9uXCIsXG4gICAgICAuLi5wcm9wcyxcbiAgICAgIGtleTogcHJvcHMua2V5XG4gICAgfSk7XG4gIH1cbiAgaWYgKFRhZyA9PT0gJ2ltZycpIHtcbiAgICByZXR1cm4gLyojX19QVVJFX18qL19jcmVhdGVFbGVtZW50KFwiaW1nXCIsIHtcbiAgICAgIGFsdDogXCJcIixcbiAgICAgIC4uLnByb3BzLFxuICAgICAga2V5OiBwcm9wcy5rZXlcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoVGFnLCBwcm9wcyk7XG59IiwibGV0IHNldDtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIHNldCA9IG5ldyBTZXQoKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvciguLi5tZXNzYWdlcykge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGNvbnN0IG1lc3NhZ2VLZXkgPSBtZXNzYWdlcy5qb2luKCcgJyk7XG4gICAgaWYgKCFzZXQuaGFzKG1lc3NhZ2VLZXkpKSB7XG4gICAgICBzZXQuYWRkKG1lc3NhZ2VLZXkpO1xuICAgICAgY29uc29sZS5lcnJvcihgQmFzZSBVSTogJHttZXNzYWdlS2V5fWApO1xuICAgIH1cbiAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0KCkge1xuICBzZXQ/LmNsZWFyKCk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQ29tcG9zaXRlUm9vdENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCh1bmRlZmluZWQpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgQ29tcG9zaXRlUm9vdENvbnRleHQuZGlzcGxheU5hbWUgPSBcIkNvbXBvc2l0ZVJvb3RDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlQ29tcG9zaXRlUm9vdENvbnRleHQob3B0aW9uYWwgPSBmYWxzZSkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChDb21wb3NpdGVSb290Q29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQgJiYgIW9wdGlvbmFsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBDb21wb3NpdGVSb290Q29udGV4dCBpcyBtaXNzaW5nLiBDb21wb3NpdGUgcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxDb21wb3NpdGUuUm9vdD4uJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTYpKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn0iXSwibWFwcGluZ3MiOiI7Ozs7QUFHQSxJQUFNLGFBQWEsQ0FBQztBQUNwQixJQUFhLHFCQUFxQixPQUFPLGFBQWEsY0FBQSxhQUFvQixrQkFBa0I7OztBQ0o1RixTQUFTLFlBQVk7Q0FDbkIsT0FBTyxPQUFPLFdBQVc7QUFDM0I7QUFDQSxTQUFTLFlBQVksTUFBTTtDQUN6QixJQUFJLE9BQU8sSUFBSSxHQUNiLFFBQVEsS0FBSyxZQUFZLEdBQUEsQ0FBSSxZQUFZO0NBSzNDLE9BQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLElBQUk7Q0FDSixRQUFRLFFBQVEsU0FBUyxzQkFBc0IsS0FBSyxrQkFBa0IsT0FBTyxLQUFLLElBQUksb0JBQW9CLGdCQUFnQjtBQUM1SDtBQUNBLFNBQVMsbUJBQW1CLE1BQU07Q0FDaEMsSUFBSTtDQUNKLFFBQVEsUUFBUSxPQUFPLElBQUksSUFBSSxLQUFLLGdCQUFnQixLQUFLLGFBQWEsT0FBTyxhQUFhLE9BQU8sS0FBSyxJQUFJLEtBQUs7QUFDakg7QUFDQSxTQUFTLE9BQU8sT0FBTztDQUNyQixJQUFJLENBQUMsVUFBVSxHQUNiLE9BQU87Q0FFVCxPQUFPLGlCQUFpQixRQUFRLGlCQUFpQixVQUFVLEtBQUssQ0FBQyxDQUFDO0FBQ3BFO0FBQ0EsU0FBUyxVQUFVLE9BQU87Q0FDeEIsSUFBSSxDQUFDLFVBQVUsR0FDYixPQUFPO0NBRVQsT0FBTyxpQkFBaUIsV0FBVyxpQkFBaUIsVUFBVSxLQUFLLENBQUMsQ0FBQztBQUN2RTtBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLElBQUksQ0FBQyxVQUFVLEdBQ2IsT0FBTztDQUVULE9BQU8saUJBQWlCLGVBQWUsaUJBQWlCLFVBQVUsS0FBSyxDQUFDLENBQUM7QUFDM0U7QUFDQSxTQUFTLGFBQWEsT0FBTztDQUMzQixJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sZUFBZSxhQUN4QyxPQUFPO0NBRVQsT0FBTyxpQkFBaUIsY0FBYyxpQkFBaUIsVUFBVSxLQUFLLENBQUMsQ0FBQztBQUMxRTtBQUNBLFNBQVMsa0JBQWtCLFNBQVM7Q0FDbEMsTUFBTSxFQUNKLFVBQ0EsV0FDQSxXQUNBLFlBQ0UsaUJBQWlCLE9BQU87Q0FDNUIsT0FBTyxrQ0FBa0MsS0FBSyxXQUFXLFlBQVksU0FBUyxLQUFLLFlBQVksWUFBWSxZQUFZO0FBQ3pIO0FBK0NBLFNBQVMsc0JBQXNCLE1BQU07Q0FDbkMsT0FBTywwQkFBMEIsS0FBSyxZQUFZLElBQUksQ0FBQztBQUN6RDtBQUNBLFNBQVMsaUJBQWlCLFNBQVM7Q0FDakMsT0FBTyxVQUFVLE9BQU8sQ0FBQyxDQUFDLGlCQUFpQixPQUFPO0FBQ3BEO0FBYUEsU0FBUyxjQUFjLE1BQU07Q0FDM0IsSUFBSSxZQUFZLElBQUksTUFBTSxRQUN4QixPQUFPO0NBRVQsTUFBTSxTQUVOLEtBQUssZ0JBRUwsS0FBSyxjQUVMLGFBQWEsSUFBSSxLQUFLLEtBQUssUUFFM0IsbUJBQW1CLElBQUk7Q0FDdkIsT0FBTyxhQUFhLE1BQU0sSUFBSSxPQUFPLE9BQU87QUFDOUM7OztBQ2hJQSxJQUFNLGdCQUFnQixDQUFDOzs7Ozs7OztBQVV2QixTQUFnQixlQUFlLE1BQU0sU0FBUztDQUM1QyxNQUFNLE1BQUEsYUFBWSxPQUFPLGFBQWE7Q0FDdEMsSUFBSSxJQUFJLFlBQVksZUFDbEIsSUFBSSxVQUFVLEtBQUssT0FBTztDQUU1QixPQUFPO0FBQ1Q7OztBQ25CQSxTQUFnQixPQUFPLENBQUM7QUFDeEIsSUFBYSxjQUFjLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFDM0MsSUFBYSxlQUFlLE9BQU8sT0FBTyxDQUFDLENBQUM7Ozs7Ozs7Ozs7QUNRNUMsU0FBZ0IsY0FBYyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ3hDLE1BQU0sVUFBVSxlQUFlLGFBQWEsQ0FBQyxDQUFDO0NBQzlDLElBQUksVUFBVSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FDL0IsT0FBTyxTQUFTO0VBQUM7RUFBRztFQUFHO0VBQUc7Q0FBQyxDQUFDO0NBRTlCLE9BQU8sUUFBUTtBQUNqQjs7Ozs7O0FBT0EsU0FBZ0IsZUFBZSxNQUFNO0NBQ25DLE1BQU0sVUFBVSxlQUFlLGFBQWEsQ0FBQyxDQUFDO0NBQzlDLElBQUksV0FBVyxTQUFTLElBQUksR0FDMUIsT0FBTyxTQUFTLElBQUk7Q0FFdEIsT0FBTyxRQUFRO0FBQ2pCO0FBQ0EsU0FBUyxnQkFBZ0I7Q0FDdkIsT0FBTztFQUNMLFVBQVU7RUFDVixTQUFTO0VBQ1QsTUFBTSxDQUFDO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsVUFBVSxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FFdEMsT0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLE9BQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUN4RztBQUNBLFNBQVMsV0FBVyxTQUFTLFNBQVM7Q0FDcEMsT0FBTyxRQUFRLEtBQUssV0FBVyxRQUFRLFVBQVUsUUFBUSxLQUFLLE1BQU0sS0FBSyxVQUFVLFFBQVEsUUFBUSxNQUFNO0FBQzNHO0FBQ0EsU0FBUyxPQUFPLFNBQVMsTUFBTTtDQUM3QixRQUFRLE9BQU87Q0FDZixJQUFJLEtBQUssT0FBTSxRQUFPLE9BQU8sSUFBSSxHQUFHO0VBQ2xDLFFBQVEsV0FBVztFQUNuQjtDQUNGO0NBQ0EsUUFBUSxZQUFXLGFBQVk7RUFDN0IsSUFBSSxRQUFRLFNBQVM7R0FDbkIsUUFBUSxRQUFRO0dBQ2hCLFFBQVEsVUFBVTtFQUNwQjtFQUNBLElBQUksWUFBWSxNQUFNO0dBQ3BCLE1BQU0sbUJBQW1CLE1BQU0sS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLElBQUk7R0FDckQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLLEdBQUc7SUFDdkMsTUFBTSxNQUFNLEtBQUs7SUFDakIsSUFBSSxPQUFPLE1BQ1Q7SUFFRixRQUFRLE9BQU8sS0FBZjtLQUNFLEtBQUssWUFDSDtNQUNFLE1BQU0sYUFBYSxJQUFJLFFBQVE7TUFDL0IsSUFBSSxPQUFPLGVBQWUsWUFDeEIsaUJBQWlCLEtBQUs7TUFFeEI7S0FDRjtLQUNGLEtBQUssVUFFRCxJQUFJLFVBQVU7SUFJcEI7R0FDRjtHQUNBLFFBQVEsZ0JBQWdCO0lBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSyxHQUFHO0tBQ3ZDLE1BQU0sTUFBTSxLQUFLO0tBQ2pCLElBQUksT0FBTyxNQUNUO0tBRUYsUUFBUSxPQUFPLEtBQWY7TUFDRSxLQUFLLFlBQ0g7T0FDRSxNQUFNLGtCQUFrQixpQkFBaUI7T0FDekMsSUFBSSxPQUFPLG9CQUFvQixZQUM3QixnQkFBZ0I7WUFJaEIsSUFBUyxJQUFJO09BRWY7TUFDRjtNQUNGLEtBQUssVUFFRCxJQUFJLFVBQVU7S0FJcEI7SUFDRjtHQUNGO0VBQ0Y7Q0FDRjtBQUNGOzs7Ozs7Ozs7OztBQ25HQSxJQUFhLFlBQVksRUFDdkIsR0FBR0EsYUFDTDs7O0FDUkEsSUFBTSxxQkFBcUIsVUFBVTtBQUNyQyxJQUFNLHlCQUVOLHNCQUVBLHVCQUF1QixVQUFVLGtCQUFrQixzQkFBcUIsT0FBTSxHQUFHOzs7Ozs7Ozs7OztBQVdqRixTQUFnQixrQkFBa0IsVUFBVTtDQUMxQyxNQUFNLFNBQVMsZUFBZSxvQkFBb0IsQ0FBQyxDQUFDO0NBQ3BELE9BQU8sT0FBTztDQUNkLHVCQUF1QixPQUFPLE1BQU07Q0FDcEMsT0FBTyxPQUFPO0FBQ2hCO0FBQ0EsU0FBUyx1QkFBdUI7Q0FDOUIsTUFBTSxTQUFTO0VBQ2IsTUFBTSxLQUFBO0VBQ04sVUFBVTtFQUNWLGFBQWEsR0FBRyxTQUFTLE9BQU8sV0FBVyxHQUFHLElBQUk7RUFDbEQsY0FBYztHQUNaLE9BQU8sV0FBVyxPQUFPO0VBQzNCO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQjtDQUl2QixNQUFpQyxJQUFJLE1BQU0sd0RBQXdEO0FBRXZHOzs7QUUxQ0EsSUFBTSxlQUFlLFNBQVMsVUFBZSxFQUFFO0FBQy9DLFNBQWdCLHNCQUFzQixxQkFBcUI7Q0FDekQsT0FBTyxnQkFBZ0I7QUFDekI7Ozs7OztBQ0VBLFNBQWdCLG1CQUFtQixTQUFTO0NBQzFDLElBQUksQ0FBZSwyQkFBTSxlQUFlLE9BQU8sR0FDN0MsT0FBTztDQUVULE1BQU0sZUFBZTtDQUNyQixNQUFNLGVBQWUsYUFBYTtDQUNsQyxRQUFRLHNCQUFzQixFQUFFLElBQUksY0FBYyxNQUFNLGFBQWEsUUFBUTtBQUMvRTs7O0FDYkEsU0FBZ0IsYUFBYSxHQUFHLEdBQUc7Q0FDakMsSUFBSSxLQUFLLENBQUMsR0FDUixPQUFPO0NBRVQsSUFBSSxDQUFDLEtBQUssR0FDUixPQUFPO0NBRVQsSUFBSSxLQUFLLEdBQ1AsT0FBTztFQUNMLEdBQUc7RUFDSCxHQUFHO0NBQ0w7QUFHSjs7O0FDZEEsSUFBSUMsd0JBRUksSUFBSSxJQUFJO0FBRWhCLFNBQWdCLEtBQUssR0FBRyxVQUFVO0NBQ1c7RUFDekMsTUFBTSxhQUFhLFNBQVMsS0FBSyxHQUFHO0VBQ3BDLElBQUksQ0FBQ0EsTUFBSSxJQUFJLFVBQVUsR0FBRztHQUN4QixNQUFJLElBQUksVUFBVTtHQUNsQixRQUFRLEtBQUssWUFBWSxZQUFZO0VBQ3ZDO0NBQ0Y7QUFDRjs7O0FDWkEsU0FBZ0Isd0JBQXdCLE9BQU8sZUFBZTtDQUM1RCxNQUFNLFFBQVEsQ0FBQztDQUdmLEtBQUssTUFBTSxPQUFPLE9BQU87RUFDdkIsTUFBTSxRQUFRLE1BQU07RUFDcEIsSUFBSSxlQUFlLGVBQWUsR0FBRyxHQUFHO0dBQ3RDLE1BQU0sY0FBYyxjQUFjLElBQUksQ0FBQyxLQUFLO0dBQzVDLElBQUksZUFBZSxNQUNqQixPQUFPLE9BQU8sT0FBTyxXQUFXO0dBRWxDO0VBQ0Y7RUFDQSxJQUFJLFVBQVUsTUFDWixNQUFNLFFBQVEsSUFBSSxZQUFZLE9BQU87T0FDaEMsSUFBSSxPQUNULE1BQU0sUUFBUSxJQUFJLFlBQVksT0FBTyxNQUFNLFNBQVM7Q0FFeEQ7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7QUNiQSxTQUFnQixpQkFBaUIsV0FBVyxPQUFPO0NBQ2pELE9BQU8sT0FBTyxjQUFjLGFBQWEsVUFBVSxLQUFLLElBQUk7QUFDOUQ7Ozs7Ozs7Ozs7QUNGQSxTQUFnQixhQUFhLE9BQU8sT0FBTztDQUN6QyxPQUFPLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0FBQ3REOzs7QUNSQSxJQUFNLGNBQWMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUNyQixTQUFnQixXQUFXLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUN4QyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FDckIsT0FBTyx5QkFBeUIsQ0FBQztDQUluQyxJQUFJLFNBQVMseUJBQXlCLENBQUM7Q0FDdkMsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsSUFBSSxHQUNGLFNBQVMsVUFBVSxRQUFRLENBQUM7Q0FFOUIsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7OztBQWdCQSxTQUFnQixZQUFZLE9BQU87Q0FDakMsSUFBSSxNQUFNLFdBQVcsR0FDbkIsT0FBTztDQUVULElBQUksTUFBTSxXQUFXLEdBQ25CLE9BQU8seUJBQXlCLE1BQU0sRUFBRTtDQUkxQyxJQUFJLFNBQVMseUJBQXlCLE1BQU0sRUFBRTtDQUM5QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUssR0FDckMsU0FBUyxVQUFVLFFBQVEsTUFBTSxFQUFFO0NBRXJDLE9BQU87QUFDVDtBQUNBLFNBQVMseUJBQXlCLFlBQVk7Q0FDNUMsSUFBSSxjQUFjLFVBQVUsR0FFMUIsT0FBTyxFQUNMLEdBQUcsbUJBQW1CLFlBQVksV0FBVyxFQUMvQztDQUVGLE9BQU8saUJBQWlCLFVBQVU7QUFDcEM7QUFDQSxTQUFTLFVBQVUsUUFBUSxZQUFZO0NBQ3JDLElBQUksY0FBYyxVQUFVLEdBQzFCLE9BQU8sbUJBQW1CLFlBQVksTUFBTTtDQUU5QyxPQUFPLGlCQUFpQixRQUFRLFVBQVU7QUFDNUM7QUFDQSxTQUFTLGlCQUFpQixZQUFZO0NBQ3BDLE1BQU0sY0FBYyxFQUNsQixHQUFHLFdBQ0w7Q0FJQSxLQUFLLE1BQU0sWUFBWSxhQUFhO0VBQ2xDLE1BQU0sWUFBWSxZQUFZO0VBQzlCLElBQUksZUFBZSxVQUFVLFNBQVMsR0FDcEMsWUFBWSxZQUFZLGlCQUFpQixTQUFTO0NBRXREO0NBQ0EsT0FBTztBQUNUOzs7O0FBS0EsU0FBUyxpQkFBaUIsYUFBYSxlQUFlO0NBQ3BELElBQUksQ0FBQyxlQUNILE9BQU87Q0FJVCxLQUFLLE1BQU0sWUFBWSxlQUFlO0VBQ3BDLE1BQU0sb0JBQW9CLGNBQWM7RUFDeEMsUUFBUSxVQUFSO0dBQ0UsS0FBSztJQUVELFlBQVksWUFBWSxhQUFhLFlBQVksT0FBTyxpQkFBaUI7SUFDekU7R0FFSixLQUFLO0lBRUQsWUFBWSxZQUFZLGdCQUFnQixZQUFZLFdBQVcsaUJBQWlCO0lBQ2hGO0dBRUosU0FFSSxJQUFJLGVBQWUsVUFBVSxpQkFBaUIsR0FDNUMsWUFBWSxZQUFZLG1CQUFtQixZQUFZLFdBQVcsaUJBQWlCO1FBRW5GLFlBQVksWUFBWTtFQUdoQztDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxlQUFlLEtBQUssT0FBTztDQUVsQyxNQUFNLFFBQVEsSUFBSSxXQUFXLENBQUM7Q0FDOUIsTUFBTSxRQUFRLElBQUksV0FBVyxDQUFDO0NBQzlCLE1BQU0sUUFBUSxJQUFJLFdBQVcsQ0FBQztDQUM5QixPQUFPLFVBQVUsT0FBZSxVQUFVLE9BQWUsU0FBUyxNQUFjLFNBQVMsT0FBZSxPQUFPLFVBQVUsY0FBYyxPQUFPLFVBQVU7QUFDMUo7QUFDQSxTQUFTLGNBQWMsWUFBWTtDQUNqQyxPQUFPLE9BQU8sZUFBZTtBQUMvQjtBQUNBLFNBQVMsbUJBQW1CLFlBQVksZUFBZTtDQUNyRCxJQUFJLGNBQWMsVUFBVSxHQUMxQixPQUFPLFdBQVcsYUFBYTtDQUVqQyxPQUFPLGNBQWM7QUFDdkI7QUFDQSxTQUFTLG1CQUFtQixZQUFZLGNBQWM7Q0FDcEQsSUFBSSxDQUFDLGNBQ0gsT0FBTztDQUVULElBQUksQ0FBQyxZQUNILE9BQU8saUJBQWlCLFlBQVk7Q0FFdEMsUUFBUSxHQUFHLFNBQVM7RUFDbEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsSUFBSSxpQkFBaUIsS0FBSyxHQUFHO0dBQzNCLE1BQU0sY0FBYztHQUNwQixxQkFBcUIsV0FBVztHQUNoQyxNQUFNLFNBQVMsYUFBYSxHQUFHLElBQUk7R0FDbkMsSUFBSSxDQUFDLFlBQVksd0JBQ2YsYUFBYSxHQUFHLElBQUk7R0FFdEIsT0FBTztFQUNUO0VBQ0EsTUFBTSxTQUFTLGFBQWEsR0FBRyxJQUFJO0VBQ25DLGFBQWEsR0FBRyxJQUFJO0VBQ3BCLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxJQUFJLENBQUMsU0FDSCxPQUFPO0NBRVQsUUFBUSxHQUFHLFNBQVM7RUFDbEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsSUFBSSxpQkFBaUIsS0FBSyxHQUN4QixxQkFBcUIsS0FBSztFQUU1QixPQUFPLFFBQVEsR0FBRyxJQUFJO0NBQ3hCO0FBQ0Y7QUFDQSxTQUFnQixxQkFBcUIsT0FBTztDQUMxQyxNQUFNLDZCQUE2QjtFQUNqQyxNQUFNLHlCQUF5QjtDQUNqQztDQUNBLE9BQU87QUFDVDtBQUNBLFNBQWdCLGdCQUFnQixjQUFjLGdCQUFnQjtDQUM1RCxJQUFJLGdCQUFnQjtFQUNsQixJQUFJLGNBRUYsT0FBTyxpQkFBaUIsTUFBTTtFQUVoQyxPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBQy9CLE9BQU8sU0FBUyxRQUFRLE9BQU8sVUFBVSxZQUFZLGlCQUFpQjtBQUN4RTs7Ozs7Ozs7OztBQ3hNQSxTQUFnQixpQkFBaUIsU0FBUyxnQkFBZ0IsU0FBUyxDQUFDLEdBQUc7Q0FDckUsTUFBTSxhQUFhLGVBQWU7Q0FDbEMsTUFBTSxXQUFXLHNCQUFzQixnQkFBZ0IsTUFBTTtDQUM3RCxJQUFJLE9BQU8sWUFBWSxPQUNyQixPQUFPO0NBR1QsT0FBTyxtQkFBbUIsU0FBUyxZQUFZLFVBRGpDLE9BQU8sU0FBUyxZQUNnQztBQUNoRTs7OztBQUtBLFNBQVMsc0JBQXNCLGdCQUFnQixTQUFTLENBQUMsR0FBRztDQUMxRCxNQUFNLEVBQ0osV0FBVyxlQUNYLE9BQU8sV0FDUCxRQUFRLGVBQ047Q0FDSixNQUFNLEVBQ0osUUFBUSxjQUNSLEtBQ0EsT0FDQSx3QkFDQSxVQUFVLFNBQ1I7Q0FDSixNQUFNLFlBQVksVUFBVSxpQkFBaUIsZUFBZSxLQUFLLElBQUksS0FBQTtDQUNyRSxNQUFNLFFBQVEsVUFBVSxhQUFhLFdBQVcsS0FBSyxJQUFJLEtBQUE7Q0FDekQsTUFBTSxhQUFhLFVBQVUsd0JBQXdCLE9BQU8sc0JBQXNCLElBQUk7Q0FDdEYsTUFBTSxnQkFBZ0IsV0FBVyxRQUFRLDJCQUEyQixLQUFLLElBQUksS0FBQTtDQUs3RSxNQUFNLFdBQVcsVUFBVSxhQUFhLFlBQVksYUFBYSxLQUFLLENBQUMsSUFBSTtDQVEzRSxJQUFJLE9BQU8sYUFBYSxhQUFhO0VBQ25DLElBQUksQ0FBQyxTQUVILGNBQW1CLE1BQU0sSUFBSTtPQUN4QixJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQzFCLFNBQVMsTUFBTSxlQUFlO0dBQUMsU0FBUztHQUFLLG1CQUFtQixVQUFVO0dBQUcsR0FBRztFQUFHLENBQUM7T0FFcEYsU0FBUyxNQUFNLGNBQWMsU0FBUyxLQUFLLG1CQUFtQixVQUFVLEdBQUcsR0FBRztDQUVsRjtDQUNBLElBQUksQ0FBQyxTQUNILE9BQU87Q0FFVCxJQUFJLGNBQWMsS0FBQSxHQUNoQixTQUFTLFlBQVksZ0JBQWdCLFNBQVMsV0FBVyxTQUFTO0NBRXBFLElBQUksVUFBVSxLQUFBLEdBQ1osU0FBUyxRQUFRLGFBQWEsU0FBUyxPQUFPLEtBQUs7Q0FFckQsT0FBTztBQUNUO0FBQ0EsU0FBUywyQkFBMkIsT0FBTztDQUN6QyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ3JCLE9BQU8sWUFBWSxLQUFLO0NBRTFCLE9BQU8sV0FBVyxLQUFBLEdBQVcsS0FBSztBQUNwQztBQU1BLElBQU0sa0JBQWtCLE9BQU8sSUFBSSxZQUFZO0FBQy9DLElBQU0sK0JBQStCO0FBQ3JDLElBQU0sOEJBQThCO0FBQ3BDLFNBQVMsbUJBQW1CLFNBQVMsUUFBUSxPQUFPLE9BQU87Q0FDekQsSUFBSSxRQUFRO0VBQ1YsSUFBSSxPQUFPLFdBQVcsWUFBWTtHQUU5QixtQ0FBbUMsTUFBTTtHQUUzQyxPQUFPLE9BQU8sT0FBTyxLQUFLO0VBQzVCO0VBQ0EsTUFBTSxjQUFjLFdBQVcsT0FBTyxPQUFPLEtBQUs7RUFDbEQsWUFBWSxNQUFNLE1BQU07RUFDeEIsSUFBSSxhQUFhO0VBSWpCLElBQUksWUFBWSxhQUFhLGlCQUUzQixhQUFBLGFBRHVCLFNBQVMsUUFBUSxNQUNwQixDQUFDLENBQUM7RUFVdEIsSUFBSSxDQUFlLDJCQUFNLGVBQWUsVUFBVSxHQUdoRCxNQUFNLElBQUksTUFBTTtHQUFDO0dBQWtIO0dBQStIO0VBQTJDLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQztFQUc3VCxPQUFvQiwyQkFBTSxhQUFhLFlBQVksV0FBVztDQUNoRTtDQUNBLElBQUksU0FDRTtNQUFBLE9BQU8sWUFBWSxVQUNyQixPQUFPLFVBQVUsU0FBUyxLQUFLO0NBQUE7Q0FLbkMsTUFBTSxJQUFJLE1BQThDLHNEQUErRTtBQUN6STtBQUNBLFNBQVMsbUNBQW1DLFVBQVU7Q0FDcEQsTUFBTSxlQUFlLFNBQVM7Q0FDOUIsSUFBSSxhQUFhLFdBQVcsR0FDMUI7Q0FFRixJQUFJLENBQUMsNkJBQTZCLEtBQUssWUFBWSxHQUNqRDtDQUVGLElBQUksQ0FBQyw0QkFBNEIsS0FBSyxZQUFZLEdBQ2hEO0NBRUYsS0FBSyxtREFBbUQsYUFBYSwyQ0FBMkMscUZBQXFGLHlHQUF5RywwRkFBMEYsMkZBQTJGLDJDQUEyQztBQUNoaEI7QUFDQSxTQUFTLFVBQVUsS0FBSyxPQUFPO0NBQzdCLElBQUksUUFBUSxVQUNWLE9BQW9CLGVBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBZSxVQUFVO0VBQzNDLE1BQU07RUFDTixHQUFHO0VBQ0gsS0FBSyxNQUFNO0NBQ2IsQ0FBQztDQUVILElBQUksUUFBUSxPQUNWLE9BQW9CLGVBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBZSxPQUFPO0VBQ3hDLEtBQUs7RUFDTCxHQUFHO0VBQ0gsS0FBSyxNQUFNO0NBQ2IsQ0FBQztDQUVILE9BQW9CLDJCQUFNLGNBQWMsS0FBSyxLQUFLO0FBQ3BEOzs7QUN4S0EsSUFBSSxzQkFFSSxJQUFJLElBQUk7QUFFaEIsU0FBZ0IsTUFBTSxHQUFHLFVBQVU7Q0FDVTtFQUN6QyxNQUFNLGFBQWEsU0FBUyxLQUFLLEdBQUc7RUFDcEMsSUFBSSxDQUFDLElBQUksSUFBSSxVQUFVLEdBQUc7R0FDeEIsSUFBSSxJQUFJLFVBQVU7R0FDbEIsUUFBUSxNQUFNLFlBQVksWUFBWTtFQUN4QztDQUNGO0FBQ0Y7OztBQ1JBLElBQWEsdUJBQW9DLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ25DLHFCQUFxQixjQUFjO0FBQzlFLFNBQWdCLHdCQUF3QixXQUFXLE9BQU87Q0FDeEQsTUFBTSxVQUFBLGFBQWdCLFdBQVcsb0JBQW9CO0NBQ3JELElBQUksWUFBWSxLQUFBLEtBQWEsQ0FBQyxVQUM1QixNQUFNLElBQUksTUFBOEMsbUdBQTZIO0NBRXZMLE9BQU87QUFDVCIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4XX0=