import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport18_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport18_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=cdd924ad";
import { useDispatch, useSelector } from "/node_modules/.vite/deps/react-redux.js?v=987a6311";
import { initializeExam, tickTimer, answerQuestion, syncExamData, fetchExamPayload, recordViolation, acknowledgeWarning } from "/src/store/examSlice.ts";
import { Clock, CheckCircle2, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=9515acc4";
import { clsx } from "/node_modules/.vite/deps/clsx.js?v=95c6fb2b";
import { twMerge } from "/node_modules/.vite/deps/tailwind-merge.js?v=701157d2";
import "/node_modules/katex/dist/katex.min.css";
import ReactMarkdown from "/node_modules/.vite/deps/react-markdown.js?v=7708ee08";
import remarkMath from "/node_modules/.vite/deps/remark-math.js?v=8594cc8a";
import remarkGfm from "/node_modules/.vite/deps/remark-gfm.js?v=0b313ecf";
import rehypeKatex from "/node_modules/.vite/deps/rehype-katex.js?v=4b690b55";
import { Button } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "/src/components/ui/card.tsx";
import { RadioGroup, RadioGroupItem } from "/src/components/ui/radio-group.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "/src/components/ui/alert-dialog.tsx";
import { Toaster } from "/src/components/ui/sonner.tsx";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=8dd6803b";
var _jsxFileName = "C:/Users/User/Desktop/studentprep/frontend/src/App.tsx";
import __vite__cjsImport18_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=cdd924ad";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$();
export function cn(...inputs) {
	return twMerge(clsx(inputs));
}
const SubmitButton = ({ children }) => {
	_s();
	const dispatch = useDispatch();
	return /* @__PURE__ */ _jsxDEV(AlertDialog, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogTrigger, { render: /* @__PURE__ */ _jsxDEV(Button, {
		variant: "default",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 35
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(AlertDialogContent, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogHeader, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogTitle, { children: "Submit Exam?" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 11
	}, this), /* @__PURE__ */ _jsxDEV(AlertDialogDescription, { children: "You are about to submit your exam. This action cannot be undone. Are you sure you want to proceed?" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 11
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 9
	}, this), /* @__PURE__ */ _jsxDEV(AlertDialogFooter, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogCancel, { children: "Go Back" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 11
	}, this), /* @__PURE__ */ _jsxDEV(AlertDialogAction, {
		onClick: () => {
			dispatch(syncExamData({
				isFinal: true,
				reason: "NORMAL"
			}));
			toast.success("Exam Submitted Successfully", { description: "Your answers have been recorded." });
			window.scrollTo(0, 0);
		},
		children: "Submit"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 11
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 9
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
};
_s(SubmitButton, "rgTLoBID190wEKCp9+G8W6F7A5M=", false, function() {
	return [useDispatch];
});
_c = SubmitButton;
function RichText({ text }) {
	// If the text just contains inline \(...\), we can do a simple replace to $...$ so remark-math picks it up natively!
	const processedText = text.replace(/\\\((.*?)\\\)/g, "$$$1$$");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "prose prose-slate max-w-none",
		children: /* @__PURE__ */ _jsxDEV(ReactMarkdown, {
			remarkPlugins: [remarkMath, remarkGfm],
			rehypePlugins: [rehypeKatex],
			children: processedText
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 5
	}, this);
}
_c2 = RichText;
function RequiredAsterisk() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "-ml-2 text-[18px] font-bold text-destructive",
		children: "*"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 10
	}, this);
}
_c3 = RequiredAsterisk;
function LoginForm({ onLogin }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center justify-center min-h-screen p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-md bg-white rounded-xl shadow-sm border border-slate-200 p-8",
			children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-2xl font-bold text-slate-900 mb-6 text-center",
				children: "StudentPrep Portal"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				className: "space-y-4",
				onSubmit: (e) => {
					e.preventDefault();
					onLogin();
				},
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ _jsxDEV(Label, {
							className: "flex items-start text-slate-700",
							children: ["JAMB Registration Number ", /* @__PURE__ */ _jsxDEV(RequiredAsterisk, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 40
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							required: true,
							className: "w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",
							placeholder: "e.g. 12345678AB"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ _jsxDEV(Label, {
							className: "flex items-start text-slate-700",
							children: ["PIN ", /* @__PURE__ */ _jsxDEV(RequiredAsterisk, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "password",
							required: true,
							className: "w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent",
							placeholder: "••••••••"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						type: "submit",
						className: "w-full mt-4 h-11 text-base",
						children: "Start Exam"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
}
_c4 = LoginForm;
function ExamDashboard() {
	_s2();
	const dispatch = useDispatch();
	const exam = useSelector((state) => state.exam);
	// Anti-Cheat Engine Listener
	useEffect(() => {
		let debounceTimer;
		const handleViolation = () => {
			// Prevent double firing if blur and visibilitychange happen simultaneously
			if (exam.isExamTerminated) return;
			clearTimeout(debounceTimer);
			debounceTimer = setTimeout(() => {
				dispatch(recordViolation());
			}, 300);
		};
		const onVisibilityChange = () => {
			if (document.visibilityState === "hidden") handleViolation();
		};
		window.addEventListener("blur", handleViolation);
		document.addEventListener("visibilitychange", onVisibilityChange);
		return () => {
			window.removeEventListener("blur", handleViolation);
			document.removeEventListener("visibilitychange", onVisibilityChange);
			clearTimeout(debounceTimer);
		};
	}, [dispatch, exam.isExamTerminated]);
	// If exam is terminated (3 strikes), trigger final sync exactly once
	useEffect(() => {
		if (exam.isExamTerminated) {
			dispatch(syncExamData({
				isFinal: true,
				reason: "FLAGGED_TAB_SWITCH"
			}));
		}
	}, [exam.isExamTerminated, dispatch]);
	useEffect(() => {
		const timer = setInterval(() => {
			dispatch(tickTimer());
		}, 1e3);
		const syncer = setInterval(() => {
			dispatch(syncExamData());
		}, 3e4);
		return () => {
			clearInterval(timer);
			clearInterval(syncer);
		};
	}, [dispatch]);
	// Background Flush Engine
	useEffect(() => {
		const handleOnline = () => {
			// Re-attempt sync immediately when internet is restored
			dispatch(syncExamData());
		};
		window.addEventListener("online", handleOnline);
		return () => window.removeEventListener("online", handleOnline);
	}, [dispatch]);
	const formatTime = (seconds) => {
		const h = Math.floor(seconds / 3600);
		const m = Math.floor(seconds % 3600 / 60);
		const s = seconds % 60;
		return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
	};
	const questions = useSelector((state) => state.exam.questions);
	const [currentIdx, setCurrentIdx] = useState(0);
	const currentQ = questions[currentIdx];
	if (!questions || questions.length === 0) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen flex items-center justify-center font-bold text-slate-500",
			children: "Loading Exam..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 164,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen flex flex-col",
		children: [
			/* @__PURE__ */ _jsxDEV(AlertDialog, {
				open: exam.showWarningModal,
				children: /* @__PURE__ */ _jsxDEV(AlertDialogContent, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogHeader, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogTitle, {
					className: "text-destructive font-bold text-xl",
					children: "Warning: Exam Environment Left"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(AlertDialogDescription, {
					className: "text-base text-slate-800",
					children: [
						"You have clicked outside the exam window or switched tabs. This is a violation of exam rules.",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 108
						}, this),
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 113
						}, this),
						/* @__PURE__ */ _jsxDEV("strong", { children: [
							"Strikes: ",
							exam.tabSwitchCount,
							" / 3"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 66
						}, this),
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 71
						}, this),
						"If you reach 3 strikes, your exam will be automatically submitted and flagged for malpractice."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 174,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(AlertDialogFooter, { children: /* @__PURE__ */ _jsxDEV(AlertDialogAction, {
					onClick: () => dispatch(acknowledgeWarning()),
					children: "I Understand"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 13
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 180,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AlertDialog, {
				open: exam.isExamTerminated,
				children: /* @__PURE__ */ _jsxDEV(AlertDialogContent, {
					className: "border-2 border-destructive",
					children: /* @__PURE__ */ _jsxDEV(AlertDialogHeader, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogTitle, {
						className: "text-destructive font-bold text-xl uppercase",
						children: "Exam Terminated"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(AlertDialogDescription, {
						className: "text-base text-slate-800 font-semibold",
						children: [
							"Your exam has been forcefully submitted due to multiple rule violations (Tab Switching).",
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 191,
								columnNumber: 103
							}, this),
							/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 191,
								columnNumber: 108
							}, this),
							"This attempt has been flagged for administrative review."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 186,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-white border-b border-slate-200 sticky top-0 z-10",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-6xl mx-auto px-4 h-16 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-8 h-8 bg-primary rounded text-white flex items-center justify-center font-bold",
							children: "SP"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "font-bold text-slate-900 text-lg",
							children: "StudentPrep CBT"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-full",
								children: [exam.syncStatus === "synced" ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-primary" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 49
								}, this) : exam.syncStatus === "syncing" ? /* @__PURE__ */ _jsxDEV("div", { className: "w-4 h-4 rounded-full border-2 border-primary border-t-transparent animate-spin" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 50
								}, this) : /* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-orange-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 208,
									columnNumber: 18
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: cn("text-xs font-bold uppercase tracking-wider", exam.syncStatus === "error" ? "text-orange-600" : "text-slate-600"),
									children: exam.syncStatus === "error" ? "Saving Locally" : exam.syncStatus
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 209,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: cn("flex items-center gap-2 font-mono text-xl font-bold px-4 py-1.5 rounded-md", exam.timeLeft < 300 ? "bg-destructive/10 text-destructive" : "bg-slate-100 text-slate-800"),
								children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 15
								}, this), formatTime(exam.timeLeft)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(SubmitButton, { children: "Submit Final" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 204,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 199,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 198,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-6xl mx-auto w-full p-4 md:p-8 grid grid-cols-1 md:grid-cols-4 gap-8",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "md:col-span-1 space-y-6",
					children: [/* @__PURE__ */ _jsxDEV(Card, { children: [/* @__PURE__ */ _jsxDEV(CardHeader, {
						className: "pb-3 border-b mb-4",
						children: /* @__PURE__ */ _jsxDEV(CardTitle, {
							className: "text-sm font-bold uppercase tracking-wider text-slate-500",
							children: "Candidate Info"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 225,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(CardContent, { children: /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 gap-y-2 text-sm",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-500",
								children: "Name:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-900 truncate",
								children: "John Doe"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 62
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-500",
								children: "Reg No:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-900",
								children: "12345678AB"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 64
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-500",
								children: "Center:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-900",
								children: "Abuja CBT-01"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 64
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 229,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 228,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 224,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Card, {
						className: "h-full flex flex-col",
						children: [
							/* @__PURE__ */ _jsxDEV(CardHeader, {
								className: "pb-3 border-b flex flex-row items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV(CardTitle, {
									className: "text-sm font-bold uppercase tracking-wider text-slate-500",
									children: "Question Map"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 238,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full",
									children: [
										Object.keys(exam.answers).length,
										"/",
										questions.length
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(CardContent, {
								className: "flex-1 p-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-5 gap-2",
									children: questions.map((q, idx) => {
										const isAnswered = !!exam.answers[q.id];
										const isCurrent = currentIdx === idx;
										return /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCurrentIdx(idx),
											className: cn("w-10 h-10 rounded text-sm font-medium flex items-center justify-center transition-colors cursor-pointer border", isCurrent ? "border-slate-900 bg-white text-slate-900 border-2" : isAnswered ? "bg-primary text-white hover:bg-primary/90 border-primary" : "bg-slate-100 text-slate-600 hover:bg-slate-200 border-transparent"),
											children: idx + 1
										}, idx, false, {
											fileName: _jsxFileName,
											lineNumber: 249,
											columnNumber: 21
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(CardFooter, {
								className: "border-t bg-slate-50 p-4 flex-col items-start space-y-2 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-3 h-3 bg-slate-100 border border-slate-200 rounded-sm" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 266,
											columnNumber: 56
										}, this), " Unanswered"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 266,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-3 h-3 border-2 border-slate-900 bg-white rounded-sm" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 267,
											columnNumber: 56
										}, this), " Current"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 267,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-3 h-3 bg-primary rounded-sm" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 268,
											columnNumber: 56
										}, this), " Answered"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 268,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 265,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 236,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 223,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "md:col-span-3",
					children: /* @__PURE__ */ _jsxDEV(Card, {
						className: "p-2 md:p-4",
						children: [
							/* @__PURE__ */ _jsxDEV(CardHeader, {
								className: "flex flex-row justify-between items-center mb-2 border-b-0",
								children: [/* @__PURE__ */ _jsxDEV(CardTitle, {
									className: "text-lg font-bold text-slate-800",
									children: [
										"Question ",
										currentIdx + 1,
										" of ",
										questions.length
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 276,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-xs font-semibold",
									children: currentQ.subject
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(CardContent, { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-slate-800 text-lg leading-relaxed mb-8",
								children: [/* @__PURE__ */ _jsxDEV(RichText, { text: currentQ.content.text || currentQ.content.passage || "" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 17
								}, this), currentQ.content.assets && currentQ.content.assets.map((asset, i) => asset.type === "IMAGE" && /* @__PURE__ */ _jsxDEV("img", {
									src: asset.url,
									alt: asset.alt,
									className: "mt-4 max-w-md rounded shadow-sm border border-slate-200"
								}, i, false, {
									fileName: _jsxFileName,
									lineNumber: 283,
									columnNumber: 45
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(RadioGroup, {
								value: exam.answers[currentQ.id],
								onValueChange: (val) => dispatch(answerQuestion({
									questionId: currentQ.id,
									optionId: val
								})),
								className: "space-y-3",
								children: Object.entries(currentQ.content.options || {}).map(([optKey, optText], i) => {
									const optId = optKey;
									const isSelected = exam.answers[currentQ.id] === optId;
									return /* @__PURE__ */ _jsxDEV(Label, {
										htmlFor: optId,
										className: cn("flex items-center gap-4 w-full text-left px-5 py-4 rounded-lg border-2 transition-all cursor-pointer", isSelected ? "border-primary bg-primary/5 shadow-sm" : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"),
										children: [
											/* @__PURE__ */ _jsxDEV(RadioGroupItem, {
												value: optId,
												id: optId,
												className: cn(isSelected ? "text-primary border-primary" : "")
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 300,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: cn("font-bold text-lg", isSelected ? "text-primary" : "text-slate-400"),
												children: optKey
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 301,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-medium text-slate-700 text-base flex-1",
												children: /* @__PURE__ */ _jsxDEV(RichText, { text: String(optText) }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 303,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 302,
												columnNumber: 23
											}, this)
										]
									}, i, true, {
										fileName: _jsxFileName,
										lineNumber: 295,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(CardFooter, {
								className: "flex justify-between mt-6 pt-6 border-t border-slate-100",
								children: [/* @__PURE__ */ _jsxDEV(Button, {
									variant: "outline",
									onClick: () => setCurrentIdx(Math.max(0, currentIdx - 1)),
									disabled: currentIdx === 0,
									children: "Previous"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 15
								}, this), currentIdx < questions.length - 1 ? /* @__PURE__ */ _jsxDEV(Button, {
									onClick: () => setCurrentIdx(currentIdx + 1),
									children: "Next Question"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 319,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV(SubmitButton, { children: "Submit Final" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 274,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 273,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 222,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 168,
		columnNumber: 5
	}, this);
}
_s2(ExamDashboard, "oF5+/RTocKVGIWpSExkZGp5LrTs=", false, function() {
	return [
		useDispatch,
		useSelector,
		useSelector
	];
});
_c5 = ExamDashboard;
export default function App() {
	_s3();
	const [isLoggedIn, setIsLoggedIn] = useState(false);
	const dispatch = useDispatch();
	const handleLogin = async () => {
		await dispatch(initializeExam({
			sessionId: "00000000-0000-0000-0000-000000000000",
			userId: "11111111-1111-1111-1111-111111111111"
		}));
		await dispatch(fetchExamPayload());
		setIsLoggedIn(true);
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [isLoggedIn ? /* @__PURE__ */ _jsxDEV(ExamDashboard, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 347,
		columnNumber: 21
	}, this) : /* @__PURE__ */ _jsxDEV(LoginForm, { onLogin: handleLogin }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 347,
		columnNumber: 41
	}, this), /* @__PURE__ */ _jsxDEV(Toaster, { position: "top-center" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 348,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 346,
		columnNumber: 5
	}, this);
}
_s3(App, "EgJRHXRjpzs54LIVaCSfkLpa+ks=", false, function() {
	return [useDispatch];
});
_c6 = App;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "SubmitButton");
$RefreshReg$(_c2, "RichText");
$RefreshReg$(_c3, "RequiredAsterisk");
$RefreshReg$(_c4, "LoginForm");
$RefreshReg$(_c5, "ExamDashboard");
$RefreshReg$(_c6, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/User/Desktop/studentprep/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/User/Desktop/studentprep/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/User/Desktop/studentprep/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGFBQWEsbUJBQW1CO0FBRXpDLFNBQVMsZ0JBQWdCLFdBQVcsZ0JBQWdCLGNBQWMsa0JBQWtCLGlCQUFpQiwwQkFBMEI7QUFDL0gsU0FBUyxPQUFPLGNBQWMsbUJBQW1CO0FBQ2pELFNBQVMsWUFBNkI7QUFDdEMsU0FBUyxlQUFlO0FBRXhCLE9BQU87QUFDUCxPQUFPLG1CQUFtQjtBQUMxQixPQUFPLGdCQUFnQjtBQUN2QixPQUFPLGVBQWU7QUFDdEIsT0FBTyxpQkFBaUI7QUFFeEIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsTUFBTSxhQUFhLFlBQVksV0FBVyxrQkFBa0I7QUFDckUsU0FBUyxZQUFZLHNCQUFzQjtBQUMzQyxTQUFTLGFBQWE7QUFDdEIsU0FBUyxhQUFhLG1CQUFtQixtQkFBbUIsb0JBQW9CLHdCQUF3QixtQkFBbUIsbUJBQW1CLGtCQUFrQiwwQkFBMEI7QUFDMUwsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsYUFBYTs7OztBQUV0QixPQUFPLFNBQVMsR0FBRyxHQUFHLFFBQXNCO0NBQzFDLE9BQU8sUUFBUSxLQUFLLE1BQU0sQ0FBQztBQUM3QjtBQUVBLE1BQU0sZ0JBQWdCLEVBQUUsZUFBOEM7O0NBQ3BFLE1BQU0sV0FBVyxZQUF5QjtDQUMxQyxPQUNFLHdCQUFDLGFBQUQsYUFDRSx3QkFBQyxvQkFBRCxFQUFvQixRQUFRLHdCQUFDLFFBQUQ7RUFBUSxTQUFRO0VBQVc7Q0FBaUI7Ozs7VUFBSTs7OztXQUM1RSx3QkFBQyxvQkFBRCxhQUNFLHdCQUFDLG1CQUFELGFBQ0Usd0JBQUMsa0JBQUQsWUFBa0IsZUFBOEI7Ozs7V0FDaEQsd0JBQUMsd0JBQUQsWUFBd0IscUdBRUE7Ozs7U0FDUDs7OztXQUNuQix3QkFBQyxtQkFBRCxhQUNFLHdCQUFDLG1CQUFELFlBQW1CLFVBQTBCOzs7O1dBQzdDLHdCQUFDLG1CQUFEO0VBQW1CLGVBQWU7R0FDaEMsU0FBUyxhQUFhO0lBQUUsU0FBUztJQUFNLFFBQVE7R0FBUyxDQUFDLENBQUM7R0FDMUQsTUFBTSxRQUFRLCtCQUErQixFQUFFLGFBQWEsbUNBQW1DLENBQUM7R0FDaEcsT0FBTyxTQUFTLEdBQUUsQ0FBQztFQUNyQjtZQUFHO0NBQXlCOzs7O1NBQ1g7Ozs7U0FDRDs7OztTQUNUOzs7OztBQUVqQjs7Ozs7QUFFQSxTQUFTLFNBQVMsRUFBRSxRQUEwQjs7Q0FFNUMsTUFBTSxnQkFBZ0IsS0FBSyxRQUFRLGtCQUFrQixRQUFRO0NBQzdELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxlQUFEO0dBQ0UsZUFBZSxDQUFDLFlBQVksU0FBUztHQUNyQyxlQUFlLENBQUMsV0FBVzthQUUxQjtFQUNZOzs7OztDQUNaOzs7OztBQUVUOztBQUVBLFNBQVMsbUJBQW1CO0NBQzFCLE9BQU8sd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBK0M7Q0FBTzs7Ozs7QUFDL0U7O0FBRUEsU0FBUyxVQUFVLEVBQUUsV0FBb0M7Q0FDdkQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFxRDtHQUFzQjs7OzthQUN6Rix3QkFBQyxRQUFEO0lBQU0sV0FBVTtJQUFZLFdBQVcsTUFBTTtLQUFFLEVBQUUsZUFBZTtLQUFHLFFBQVE7SUFBRztjQUE5RTtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQW1ELDZCQUN4Qix3QkFBQyxrQkFBRCxDQUFtQjs7OztlQUN2Qzs7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUFPLE1BQUs7T0FBTztPQUFTLFdBQVU7T0FBa0ksYUFBWTtNQUFtQjs7OztjQUNwTTs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FBbUQsUUFDN0Msd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7ZUFDbEI7Ozs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FBTyxNQUFLO09BQVc7T0FBUyxXQUFVO09BQWtJLGFBQVk7TUFBWTs7OztjQUNqTTs7Ozs7O0tBQ0wsd0JBQUMsUUFBRDtNQUFRLE1BQUs7TUFBUyxXQUFVO2dCQUE2QjtLQUVyRDs7Ozs7SUFDSjs7Ozs7V0FDSDs7Ozs7O0NBQ0Y7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxnQkFBZ0I7O0NBQ3ZCLE1BQU0sV0FBVyxZQUF5QjtDQUMxQyxNQUFNLE9BQU8sYUFBYSxVQUFxQixNQUFNLElBQUk7O0NBR3pELGdCQUFnQjtFQUNkLElBQUk7RUFFSixNQUFNLHdCQUF3Qjs7R0FFNUIsSUFBSSxLQUFLLGtCQUFrQjtHQUMzQixhQUFhLGFBQWE7R0FDMUIsZ0JBQWdCLGlCQUFpQjtJQUMvQixTQUFTLGdCQUFnQixDQUFDO0dBQzVCLEdBQUcsR0FBRztFQUNSO0VBRUEsTUFBTSwyQkFBMkI7R0FDL0IsSUFBSSxTQUFTLG9CQUFvQixVQUFVLGdCQUFnQjtFQUM3RDtFQUVBLE9BQU8saUJBQWlCLFFBQVEsZUFBZTtFQUMvQyxTQUFTLGlCQUFpQixvQkFBb0Isa0JBQWtCO0VBRWhFLGFBQWE7R0FDWCxPQUFPLG9CQUFvQixRQUFRLGVBQWU7R0FDbEQsU0FBUyxvQkFBb0Isb0JBQW9CLGtCQUFrQjtHQUNuRSxhQUFhLGFBQWE7RUFDNUI7Q0FDRixHQUFHLENBQUMsVUFBVSxLQUFLLGdCQUFnQixDQUFDOztDQUdwQyxnQkFBZ0I7RUFDZCxJQUFJLEtBQUssa0JBQWtCO0dBQ3hCLFNBQVMsYUFBYTtJQUFFLFNBQVM7SUFBTSxRQUFRO0dBQXFCLENBQUMsQ0FBQztFQUN6RTtDQUNGLEdBQUcsQ0FBQyxLQUFLLGtCQUFrQixRQUFRLENBQUM7Q0FFcEMsZ0JBQWdCO0VBQ2QsTUFBTSxRQUFRLGtCQUFrQjtHQUFFLFNBQVMsVUFBVSxDQUFDO0VBQUcsR0FBRyxHQUFJO0VBQ2hFLE1BQU0sU0FBUyxrQkFBa0I7R0FBRSxTQUFTLGFBQWEsQ0FBQztFQUFHLEdBQUcsR0FBSztFQUNyRSxhQUFhO0dBQUUsY0FBYyxLQUFLO0dBQUcsY0FBYyxNQUFNO0VBQUc7Q0FDOUQsR0FBRyxDQUFDLFFBQVEsQ0FBQzs7Q0FHYixnQkFBZ0I7RUFDZCxNQUFNLHFCQUFxQjs7R0FFekIsU0FBUyxhQUFhLENBQUM7RUFDekI7RUFDQSxPQUFPLGlCQUFpQixVQUFVLFlBQVk7RUFDOUMsYUFBYSxPQUFPLG9CQUFvQixVQUFVLFlBQVk7Q0FDaEUsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUViLE1BQU0sY0FBYyxZQUFvQjtFQUN0QyxNQUFNLElBQUksS0FBSyxNQUFNLFVBQVUsSUFBSTtFQUNuQyxNQUFNLElBQUksS0FBSyxNQUFPLFVBQVUsT0FBUSxFQUFFO0VBQzFDLE1BQU0sSUFBSSxVQUFVO0VBQ3BCLE9BQU8sR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQzFHO0NBRUEsTUFBTSxZQUFZLGFBQWEsVUFBcUIsTUFBTSxLQUFLLFNBQVM7Q0FDeEUsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsQ0FBQztDQUM5QyxNQUFNLFdBQVcsVUFBVTtDQUUzQixJQUFJLENBQUMsYUFBYSxVQUFVLFdBQVcsR0FBRztFQUN4QyxPQUFPLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQXlFO0VBQW9COzs7OztDQUNySDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLGFBQUQ7SUFBYSxNQUFNLEtBQUs7Y0FDdEIsd0JBQUMsb0JBQUQsYUFDRSx3QkFBQyxtQkFBRCxhQUNFLHdCQUFDLGtCQUFEO0tBQWtCLFdBQVU7ZUFBcUM7SUFBZ0Q7Ozs7Y0FDakgsd0JBQUMsd0JBQUQ7S0FBd0IsV0FBVTtlQUFsQztNQUE2RDtNQUNrQyx3QkFBQyxNQUFELENBQUk7Ozs7O01BQUMsd0JBQUMsTUFBRCxDQUFJOzs7OztNQUN0Ryx3QkFBQyxVQUFEO09BQVE7T0FBVSxLQUFLO09BQWU7TUFBWTs7Ozs7TUFBQyx3QkFBQyxNQUFELENBQUk7Ozs7O01BQUMsd0JBQUMsTUFBRCxDQUFJOzs7OztNQUFDO0tBRXZDOzs7OztZQUNQOzs7O2NBQ25CLHdCQUFDLG1CQUFELFlBQ0Usd0JBQUMsbUJBQUQ7S0FBbUIsZUFBZSxTQUFTLG1CQUFtQixDQUFDO2VBQUc7SUFBK0I7Ozs7YUFDaEY7Ozs7WUFDRDs7Ozs7R0FDVDs7Ozs7R0FFYix3QkFBQyxhQUFEO0lBQWEsTUFBTSxLQUFLO2NBQ3RCLHdCQUFDLG9CQUFEO0tBQW9CLFdBQVU7ZUFDNUIsd0JBQUMsbUJBQUQsYUFDRSx3QkFBQyxrQkFBRDtNQUFrQixXQUFVO2dCQUErQztLQUFpQzs7OztlQUM1Ryx3QkFBQyx3QkFBRDtNQUF3QixXQUFVO2dCQUFsQztPQUEyRTtPQUNlLHdCQUFDLE1BQUQsQ0FBSTs7Ozs7T0FBQyx3QkFBQyxNQUFELENBQUk7Ozs7O09BQUM7TUFFNUU7Ozs7O2FBQ1A7Ozs7O0lBQ0Q7Ozs7O0dBQ1Q7Ozs7O0dBRWIsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FDaEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQW1GO01BQU87Ozs7Z0JBQ3pHLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFtQztNQUFtQjs7OztjQUNqRTs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNJLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0csS0FBSyxlQUFlLFdBQVcsd0JBQUMsY0FBRCxFQUFjLFdBQVUsdUJBQXdCOzs7O21CQUMvRSxLQUFLLGVBQWUsWUFBWSx3QkFBQyxPQUFELEVBQUssV0FBVSxpRkFBa0Y7Ozs7bUJBQ2pJLHdCQUFDLGFBQUQsRUFBYSxXQUFVLDBCQUEyQjs7OztrQkFDbkQsd0JBQUMsUUFBRDtTQUFNLFdBQVcsR0FBRyw4Q0FBOEMsS0FBSyxlQUFlLFVBQVUsb0JBQW9CLGdCQUFnQjttQkFDakksS0FBSyxlQUFlLFVBQVUsbUJBQW1CLEtBQUs7UUFDbkQ7Ozs7Z0JBQ0g7Ozs7OztPQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFXLEdBQUcsOEVBQThFLEtBQUssV0FBVyxNQUFNLHVDQUF1Qyw2QkFBNkI7a0JBQTNMLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OztrQkFDM0IsV0FBVyxLQUFLLFFBQVEsQ0FDdEI7Ozs7OztPQUNMLHdCQUFDLGNBQUQsWUFBYyxlQUEwQjs7Ozs7TUFDckM7Ozs7O2FBQ0Y7Ozs7OztHQUNDOzs7OztHQUVSLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxZQUFEO01BQVksV0FBVTtnQkFDcEIsd0JBQUMsV0FBRDtPQUFXLFdBQVU7aUJBQTREO01BQXlCOzs7OztLQUNoRzs7OztlQUNaLHdCQUFDLGFBQUQsWUFDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpQjtPQUFXOzs7OztPQUFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF3QztPQUFjOzs7OztPQUNuSCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUI7T0FBYTs7Ozs7T0FBQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBK0I7T0FBZ0I7Ozs7O09BQzlHLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpQjtPQUFhOzs7OztPQUFDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUErQjtPQUFrQjs7Ozs7TUFDN0c7Ozs7O2NBQ007Ozs7YUFDVDs7OztlQUNOLHdCQUFDLE1BQUQ7TUFBTSxXQUFVO2dCQUFoQjtPQUNFLHdCQUFDLFlBQUQ7UUFBWSxXQUFVO2tCQUF0QixDQUNFLHdCQUFDLFdBQUQ7U0FBVyxXQUFVO21CQUE0RDtRQUF1Qjs7OztrQkFDeEcsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQ0csT0FBTyxLQUFLLEtBQUssT0FBTyxDQUFDLENBQUM7VUFBTztVQUFFLFVBQVU7U0FDMUM7Ozs7O2dCQUNJOzs7Ozs7T0FDWix3QkFBQyxhQUFEO1FBQWEsV0FBVTtrQkFDckIsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osVUFBVSxLQUFLLEdBQUcsUUFBUTtVQUN6QixNQUFNLGFBQWEsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO1VBQ3BDLE1BQU0sWUFBWSxlQUFlO1VBQ2pDLE9BQ0Usd0JBQUMsVUFBRDtXQUVFLGVBQWUsY0FBYyxHQUFHO1dBQ2hDLFdBQVcsR0FDVCxrSEFDQSxZQUFZLHNEQUNaLGFBQWEsNkRBQ2IsbUVBQ0Y7cUJBRUMsTUFBTTtVQUNELEdBVkQ7Ozs7aUJBVUM7U0FFWixDQUFDO1FBQ0U7Ozs7O09BQ007Ozs7O09BQ2Isd0JBQUMsWUFBRDtRQUFZLFdBQVU7a0JBQXRCO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBeUMsd0JBQUMsT0FBRCxFQUFLLFdBQVUsMERBQStEOzs7O29CQUFDLGFBQWdCOzs7Ozs7U0FDeEksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBeUMsd0JBQUMsT0FBRCxFQUFLLFdBQVUsd0RBQTZEOzs7O29CQUFDLFVBQWE7Ozs7OztTQUNuSSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUF5Qyx3QkFBQyxPQUFELEVBQUssV0FBVSxnQ0FBcUM7Ozs7b0JBQUMsV0FBYzs7Ozs7O1FBQ2xHOzs7Ozs7TUFDUjs7Ozs7YUFDSDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE1BQUQ7TUFBTSxXQUFVO2dCQUFoQjtPQUNFLHdCQUFDLFlBQUQ7UUFBWSxXQUFVO2tCQUF0QixDQUNFLHdCQUFDLFdBQUQ7U0FBVyxXQUFVO21CQUFyQjtVQUF3RDtVQUFVLGFBQWE7VUFBRTtVQUFLLFVBQVU7U0FBa0I7Ozs7O2tCQUNsSCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBNEUsU0FBUztRQUFjOzs7O2dCQUN6Rzs7Ozs7O09BQ1osd0JBQUMsYUFBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLE1BQU0sU0FBUyxRQUFRLFFBQVEsU0FBUyxRQUFRLFdBQVcsR0FBSzs7OztrQkFDekUsU0FBUyxRQUFRLFVBQVUsU0FBUyxRQUFRLE9BQU8sS0FBSyxPQUFZLE1BQ25FLE1BQU0sU0FBUyxXQUFXLHdCQUFDLE9BQUQ7U0FBYSxLQUFLLE1BQU07U0FBSyxLQUFLLE1BQU07U0FBSyxXQUFVO1FBQTJELEdBQXhHOzs7O2VBQXdHLENBQzdJLENBQ0U7Ozs7O2lCQUNMLHdCQUFDLFlBQUQ7UUFDRSxPQUFPLEtBQUssUUFBUSxTQUFTO1FBQzdCLGdCQUFnQixRQUFRLFNBQVMsZUFBZTtTQUFFLFlBQVksU0FBUztTQUFJLFVBQVU7UUFBSSxDQUFDLENBQUM7UUFDM0YsV0FBVTtrQkFFVCxPQUFPLFFBQVEsU0FBUyxRQUFRLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxVQUFVLE1BQU07U0FDNUUsTUFBTSxRQUFRO1NBQ2QsTUFBTSxhQUFhLEtBQUssUUFBUSxTQUFTLFFBQVE7U0FDakQsT0FDRSx3QkFBQyxPQUFEO1VBRUUsU0FBUztVQUNULFdBQVcsR0FBRyx3R0FBd0csYUFBYSwwQ0FBMEMsMkRBQTJEO29CQUgxTztXQUtFLHdCQUFDLGdCQUFEO1lBQWdCLE9BQU87WUFBTyxJQUFJO1lBQU8sV0FBVyxHQUFHLGFBQWEsZ0NBQWdDLEVBQUU7V0FBSTs7Ozs7V0FDMUcsd0JBQUMsUUFBRDtZQUFNLFdBQVcsR0FBRyxxQkFBcUIsYUFBYSxpQkFBaUIsZ0JBQWdCO3NCQUFJO1dBQWE7Ozs7O1dBQ3hHLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNkLHdCQUFDLFVBQUQsRUFBVSxNQUFNLE9BQU8sT0FBTyxFQUFJOzs7OztXQUM5Qjs7Ozs7VUFDRDtZQVRBOzs7O2dCQVNBO1FBRVgsQ0FBQztPQUNTOzs7O2VBQ0Q7Ozs7O09BQ2Isd0JBQUMsWUFBRDtRQUFZLFdBQVU7a0JBQXRCLENBQ0Usd0JBQUMsUUFBRDtTQUNFLFNBQVE7U0FDUixlQUFlLGNBQWMsS0FBSyxJQUFJLEdBQUcsYUFBYSxDQUFDLENBQUM7U0FDeEQsVUFBVSxlQUFlO21CQUMxQjtRQUVPOzs7O2tCQUNQLGFBQWEsVUFBVSxTQUFTLElBQy9CLHdCQUFDLFFBQUQ7U0FDRSxlQUFlLGNBQWMsYUFBYSxDQUFDO21CQUM1QztRQUVPOzs7O21CQUVSLHdCQUFDLGNBQUQsWUFBYyxlQUEwQjs7OztnQkFFaEM7Ozs7OztNQUNSOzs7Ozs7SUFDSDs7OztZQUNEOzs7Ozs7RUFDSDs7Ozs7O0FBRVQ7Ozs7Ozs7OztBQUVBLGVBQWUsU0FBUyxNQUFNOztDQUM1QixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sV0FBVyxZQUF5QjtDQUUxQyxNQUFNLGNBQWMsWUFBWTtFQUM5QixNQUFNLFNBQVMsZUFBZTtHQUFFLFdBQVc7R0FBd0MsUUFBUTtFQUF1QyxDQUFDLENBQUM7RUFDcEksTUFBTSxTQUFTLGlCQUFpQixDQUFDO0VBQ2pDLGNBQWMsSUFBSTtDQUNwQjtDQUVBLE9BQ0UsZ0RBQ0csYUFBYSx3QkFBQyxlQUFELENBQWdCOzs7O1lBQUksd0JBQUMsV0FBRCxFQUFXLFNBQVMsWUFBYzs7OztXQUNwRSx3QkFBQyxTQUFELEVBQVMsVUFBUyxhQUFjOzs7O1NBQ2hDOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlRGlzcGF0Y2gsIHVzZVNlbGVjdG9yIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xyXG5pbXBvcnQgdHlwZSB7IEFwcERpc3BhdGNoLCBSb290U3RhdGUgfSBmcm9tICcuL3N0b3JlL3N0b3JlJztcclxuaW1wb3J0IHsgaW5pdGlhbGl6ZUV4YW0sIHRpY2tUaW1lciwgYW5zd2VyUXVlc3Rpb24sIHN5bmNFeGFtRGF0YSwgZmV0Y2hFeGFtUGF5bG9hZCwgcmVjb3JkVmlvbGF0aW9uLCBhY2tub3dsZWRnZVdhcm5pbmcgfSBmcm9tICcuL3N0b3JlL2V4YW1TbGljZSc7XHJcbmltcG9ydCB7IENsb2NrLCBDaGVja0NpcmNsZTIsIEFsZXJ0Q2lyY2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuaW1wb3J0IHsgY2xzeCwgdHlwZSBDbGFzc1ZhbHVlIH0gZnJvbSAnY2xzeCc7XHJcbmltcG9ydCB7IHR3TWVyZ2UgfSBmcm9tICd0YWlsd2luZC1tZXJnZSc7XHJcblxyXG5pbXBvcnQgJ2thdGV4L2Rpc3Qva2F0ZXgubWluLmNzcyc7XHJcbmltcG9ydCBSZWFjdE1hcmtkb3duIGZyb20gJ3JlYWN0LW1hcmtkb3duJztcclxuaW1wb3J0IHJlbWFya01hdGggZnJvbSAncmVtYXJrLW1hdGgnO1xyXG5pbXBvcnQgcmVtYXJrR2ZtIGZyb20gJ3JlbWFyay1nZm0nO1xyXG5pbXBvcnQgcmVoeXBlS2F0ZXggZnJvbSAncmVoeXBlLWthdGV4JztcclxuXHJcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJy4vY29tcG9uZW50cy91aS9idXR0b24nO1xyXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlLCBDYXJkRm9vdGVyIH0gZnJvbSAnLi9jb21wb25lbnRzL3VpL2NhcmQnO1xyXG5pbXBvcnQgeyBSYWRpb0dyb3VwLCBSYWRpb0dyb3VwSXRlbSB9IGZyb20gJy4vY29tcG9uZW50cy91aS9yYWRpby1ncm91cCc7XHJcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnLi9jb21wb25lbnRzL3VpL2xhYmVsJztcclxuaW1wb3J0IHsgQWxlcnREaWFsb2csIEFsZXJ0RGlhbG9nQWN0aW9uLCBBbGVydERpYWxvZ0NhbmNlbCwgQWxlcnREaWFsb2dDb250ZW50LCBBbGVydERpYWxvZ0Rlc2NyaXB0aW9uLCBBbGVydERpYWxvZ0Zvb3RlciwgQWxlcnREaWFsb2dIZWFkZXIsIEFsZXJ0RGlhbG9nVGl0bGUsIEFsZXJ0RGlhbG9nVHJpZ2dlciB9IGZyb20gJy4vY29tcG9uZW50cy91aS9hbGVydC1kaWFsb2cnO1xyXG5pbXBvcnQgeyBUb2FzdGVyIH0gZnJvbSAnLi9jb21wb25lbnRzL3VpL3Nvbm5lcic7XHJcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc29ubmVyJztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBjbiguLi5pbnB1dHM6IENsYXNzVmFsdWVbXSkge1xyXG4gIHJldHVybiB0d01lcmdlKGNsc3goaW5wdXRzKSk7XHJcbn1cclxuXHJcbmNvbnN0IFN1Ym1pdEJ1dHRvbiA9ICh7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSA9PiB7XHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaDxBcHBEaXNwYXRjaD4oKTtcclxuICByZXR1cm4gKFxyXG4gICAgPEFsZXJ0RGlhbG9nPlxyXG4gICAgICA8QWxlcnREaWFsb2dUcmlnZ2VyIHJlbmRlcj17PEJ1dHRvbiB2YXJpYW50PVwiZGVmYXVsdFwiPntjaGlsZHJlbn08L0J1dHRvbj59IC8+XHJcbiAgICAgIDxBbGVydERpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgPEFsZXJ0RGlhbG9nSGVhZGVyPlxyXG4gICAgICAgICAgPEFsZXJ0RGlhbG9nVGl0bGU+U3VibWl0IEV4YW0/PC9BbGVydERpYWxvZ1RpdGxlPlxyXG4gICAgICAgICAgPEFsZXJ0RGlhbG9nRGVzY3JpcHRpb24+XHJcbiAgICAgICAgICAgIFlvdSBhcmUgYWJvdXQgdG8gc3VibWl0IHlvdXIgZXhhbS4gVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS4gQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHByb2NlZWQ/XHJcbiAgICAgICAgICA8L0FsZXJ0RGlhbG9nRGVzY3JpcHRpb24+XHJcbiAgICAgICAgPC9BbGVydERpYWxvZ0hlYWRlcj5cclxuICAgICAgICA8QWxlcnREaWFsb2dGb290ZXI+XHJcbiAgICAgICAgICA8QWxlcnREaWFsb2dDYW5jZWw+R28gQmFjazwvQWxlcnREaWFsb2dDYW5jZWw+XHJcbiAgICAgICAgICA8QWxlcnREaWFsb2dBY3Rpb24gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICBkaXNwYXRjaChzeW5jRXhhbURhdGEoeyBpc0ZpbmFsOiB0cnVlLCByZWFzb246ICdOT1JNQUwnIH0pKTtcclxuICAgICAgICAgICAgdG9hc3Quc3VjY2VzcyhcIkV4YW0gU3VibWl0dGVkIFN1Y2Nlc3NmdWxseVwiLCB7IGRlc2NyaXB0aW9uOiBcIllvdXIgYW5zd2VycyBoYXZlIGJlZW4gcmVjb3JkZWQuXCIgfSk7XHJcbiAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLDApO1xyXG4gICAgICAgICAgfX0+U3VibWl0PC9BbGVydERpYWxvZ0FjdGlvbj5cclxuICAgICAgICA8L0FsZXJ0RGlhbG9nRm9vdGVyPlxyXG4gICAgICA8L0FsZXJ0RGlhbG9nQ29udGVudD5cclxuICAgIDwvQWxlcnREaWFsb2c+XHJcbiAgKTtcclxufTtcclxuXHJcbmZ1bmN0aW9uIFJpY2hUZXh0KHsgdGV4dCB9OiB7IHRleHQ6IHN0cmluZyB9KSB7XHJcbiAgLy8gSWYgdGhlIHRleHQganVzdCBjb250YWlucyBpbmxpbmUgXFwoLi4uXFwpLCB3ZSBjYW4gZG8gYSBzaW1wbGUgcmVwbGFjZSB0byAkLi4uJCBzbyByZW1hcmstbWF0aCBwaWNrcyBpdCB1cCBuYXRpdmVseSFcclxuICBjb25zdCBwcm9jZXNzZWRUZXh0ID0gdGV4dC5yZXBsYWNlKC9cXFxcXFwoKC4qPylcXFxcXFwpL2csICckJCQxJCQnKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcm9zZSBwcm9zZS1zbGF0ZSBtYXgtdy1ub25lXCI+XHJcbiAgICAgIDxSZWFjdE1hcmtkb3duXHJcbiAgICAgICAgcmVtYXJrUGx1Z2lucz17W3JlbWFya01hdGgsIHJlbWFya0dmbV19XHJcbiAgICAgICAgcmVoeXBlUGx1Z2lucz17W3JlaHlwZUthdGV4XX1cclxuICAgICAgPlxyXG4gICAgICAgIHtwcm9jZXNzZWRUZXh0fVxyXG4gICAgICA8L1JlYWN0TWFya2Rvd24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBSZXF1aXJlZEFzdGVyaXNrKCkge1xyXG4gIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCItbWwtMiB0ZXh0LVsxOHB4XSBmb250LWJvbGQgdGV4dC1kZXN0cnVjdGl2ZVwiPio8L3NwYW4+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBMb2dpbkZvcm0oeyBvbkxvZ2luIH06IHsgb25Mb2dpbjogKCkgPT4gdm9pZCB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtc2NyZWVuIHAtNFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCBiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLThcIj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG1iLTYgdGV4dC1jZW50ZXJcIj5TdHVkZW50UHJlcCBQb3J0YWw8L2gxPlxyXG4gICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNFwiIG9uU3VibWl0PXsoZSkgPT4geyBlLnByZXZlbnREZWZhdWx0KCk7IG9uTG9naW4oKTsgfX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cclxuICAgICAgICAgICAgPExhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICBKQU1CIFJlZ2lzdHJhdGlvbiBOdW1iZXIgPFJlcXVpcmVkQXN0ZXJpc2sgLz5cclxuICAgICAgICAgICAgPC9MYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcmVxdWlyZWQgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1wcmltYXJ5IGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiIHBsYWNlaG9sZGVyPVwiZS5nLiAxMjM0NTY3OEFCXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0xXCI+XHJcbiAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgUElOIDxSZXF1aXJlZEFzdGVyaXNrIC8+XHJcbiAgICAgICAgICAgIDwvTGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiByZXF1aXJlZCBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnkgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50XCIgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgbXQtNCBoLTExIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICBTdGFydCBFeGFtXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gRXhhbURhc2hib2FyZCgpIHtcclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoPEFwcERpc3BhdGNoPigpO1xyXG4gIGNvbnN0IGV4YW0gPSB1c2VTZWxlY3Rvcigoc3RhdGU6IFJvb3RTdGF0ZSkgPT4gc3RhdGUuZXhhbSk7XHJcblxyXG4gIC8vIEFudGktQ2hlYXQgRW5naW5lIExpc3RlbmVyXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBkZWJvdW5jZVRpbWVyOiBOb2RlSlMuVGltZW91dDtcclxuICAgIFxyXG4gICAgY29uc3QgaGFuZGxlVmlvbGF0aW9uID0gKCkgPT4ge1xyXG4gICAgICAvLyBQcmV2ZW50IGRvdWJsZSBmaXJpbmcgaWYgYmx1ciBhbmQgdmlzaWJpbGl0eWNoYW5nZSBoYXBwZW4gc2ltdWx0YW5lb3VzbHlcclxuICAgICAgaWYgKGV4YW0uaXNFeGFtVGVybWluYXRlZCkgcmV0dXJuO1xyXG4gICAgICBjbGVhclRpbWVvdXQoZGVib3VuY2VUaW1lcik7XHJcbiAgICAgIGRlYm91bmNlVGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBkaXNwYXRjaChyZWNvcmRWaW9sYXRpb24oKSk7XHJcbiAgICAgIH0sIDMwMCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IG9uVmlzaWJpbGl0eUNoYW5nZSA9ICgpID0+IHtcclxuICAgICAgaWYgKGRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSA9PT0gJ2hpZGRlbicpIGhhbmRsZVZpb2xhdGlvbigpO1xyXG4gICAgfTtcclxuICAgIFxyXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLCBoYW5kbGVWaW9sYXRpb24pO1xyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIG9uVmlzaWJpbGl0eUNoYW5nZSk7XHJcblxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2JsdXInLCBoYW5kbGVWaW9sYXRpb24pO1xyXG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd2aXNpYmlsaXR5Y2hhbmdlJywgb25WaXNpYmlsaXR5Q2hhbmdlKTtcclxuICAgICAgY2xlYXJUaW1lb3V0KGRlYm91bmNlVGltZXIpO1xyXG4gICAgfTtcclxuICB9LCBbZGlzcGF0Y2gsIGV4YW0uaXNFeGFtVGVybWluYXRlZF0pO1xyXG5cclxuICAvLyBJZiBleGFtIGlzIHRlcm1pbmF0ZWQgKDMgc3RyaWtlcyksIHRyaWdnZXIgZmluYWwgc3luYyBleGFjdGx5IG9uY2VcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGV4YW0uaXNFeGFtVGVybWluYXRlZCkge1xyXG4gICAgICAgZGlzcGF0Y2goc3luY0V4YW1EYXRhKHsgaXNGaW5hbDogdHJ1ZSwgcmVhc29uOiAnRkxBR0dFRF9UQUJfU1dJVENIJyB9KSk7XHJcbiAgICB9XHJcbiAgfSwgW2V4YW0uaXNFeGFtVGVybWluYXRlZCwgZGlzcGF0Y2hdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4geyBkaXNwYXRjaCh0aWNrVGltZXIoKSk7IH0sIDEwMDApO1xyXG4gICAgY29uc3Qgc3luY2VyID0gc2V0SW50ZXJ2YWwoKCkgPT4geyBkaXNwYXRjaChzeW5jRXhhbURhdGEoKSk7IH0sIDMwMDAwKTtcclxuICAgIHJldHVybiAoKSA9PiB7IGNsZWFySW50ZXJ2YWwodGltZXIpOyBjbGVhckludGVydmFsKHN5bmNlcik7IH07XHJcbiAgfSwgW2Rpc3BhdGNoXSk7XHJcblxyXG4gIC8vIEJhY2tncm91bmQgRmx1c2ggRW5naW5lXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZU9ubGluZSA9ICgpID0+IHtcclxuICAgICAgLy8gUmUtYXR0ZW1wdCBzeW5jIGltbWVkaWF0ZWx5IHdoZW4gaW50ZXJuZXQgaXMgcmVzdG9yZWRcclxuICAgICAgZGlzcGF0Y2goc3luY0V4YW1EYXRhKCkpO1xyXG4gICAgfTtcclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdvbmxpbmUnLCBoYW5kbGVPbmxpbmUpO1xyXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdvbmxpbmUnLCBoYW5kbGVPbmxpbmUpO1xyXG4gIH0sIFtkaXNwYXRjaF0pO1xyXG5cclxuICBjb25zdCBmb3JtYXRUaW1lID0gKHNlY29uZHM6IG51bWJlcikgPT4ge1xyXG4gICAgY29uc3QgaCA9IE1hdGguZmxvb3Ioc2Vjb25kcyAvIDM2MDApO1xyXG4gICAgY29uc3QgbSA9IE1hdGguZmxvb3IoKHNlY29uZHMgJSAzNjAwKSAvIDYwKTtcclxuICAgIGNvbnN0IHMgPSBzZWNvbmRzICUgNjA7XHJcbiAgICByZXR1cm4gYCR7aC50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJyl9OiR7bS50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJyl9OiR7cy50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJyl9YDtcclxuICB9O1xyXG5cclxuICBjb25zdCBxdWVzdGlvbnMgPSB1c2VTZWxlY3Rvcigoc3RhdGU6IFJvb3RTdGF0ZSkgPT4gc3RhdGUuZXhhbS5xdWVzdGlvbnMpO1xyXG4gIGNvbnN0IFtjdXJyZW50SWR4LCBzZXRDdXJyZW50SWR4XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IGN1cnJlbnRRID0gcXVlc3Rpb25zW2N1cnJlbnRJZHhdO1xyXG5cclxuICBpZiAoIXF1ZXN0aW9ucyB8fCBxdWVzdGlvbnMubGVuZ3RoID09PSAwKSB7XHJcbiAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwXCI+TG9hZGluZyBFeGFtLi4uPC9kaXY+O1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgey8qIEFudGktQ2hlYXQgTW9kYWxzICovfVxyXG4gICAgICA8QWxlcnREaWFsb2cgb3Blbj17ZXhhbS5zaG93V2FybmluZ01vZGFsfT5cclxuICAgICAgICA8QWxlcnREaWFsb2dDb250ZW50PlxyXG4gICAgICAgICAgPEFsZXJ0RGlhbG9nSGVhZGVyPlxyXG4gICAgICAgICAgICA8QWxlcnREaWFsb2dUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LWRlc3RydWN0aXZlIGZvbnQtYm9sZCB0ZXh0LXhsXCI+V2FybmluZzogRXhhbSBFbnZpcm9ubWVudCBMZWZ0PC9BbGVydERpYWxvZ1RpdGxlPlxyXG4gICAgICAgICAgICA8QWxlcnREaWFsb2dEZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgdGV4dC1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICBZb3UgaGF2ZSBjbGlja2VkIG91dHNpZGUgdGhlIGV4YW0gd2luZG93IG9yIHN3aXRjaGVkIHRhYnMuIFRoaXMgaXMgYSB2aW9sYXRpb24gb2YgZXhhbSBydWxlcy48YnIvPjxici8+XHJcbiAgICAgICAgICAgICAgPHN0cm9uZz5TdHJpa2VzOiB7ZXhhbS50YWJTd2l0Y2hDb3VudH0gLyAzPC9zdHJvbmc+PGJyLz48YnIvPlxyXG4gICAgICAgICAgICAgIElmIHlvdSByZWFjaCAzIHN0cmlrZXMsIHlvdXIgZXhhbSB3aWxsIGJlIGF1dG9tYXRpY2FsbHkgc3VibWl0dGVkIGFuZCBmbGFnZ2VkIGZvciBtYWxwcmFjdGljZS5cclxuICAgICAgICAgICAgPC9BbGVydERpYWxvZ0Rlc2NyaXB0aW9uPlxyXG4gICAgICAgICAgPC9BbGVydERpYWxvZ0hlYWRlcj5cclxuICAgICAgICAgIDxBbGVydERpYWxvZ0Zvb3Rlcj5cclxuICAgICAgICAgICAgPEFsZXJ0RGlhbG9nQWN0aW9uIG9uQ2xpY2s9eygpID0+IGRpc3BhdGNoKGFja25vd2xlZGdlV2FybmluZygpKX0+SSBVbmRlcnN0YW5kPC9BbGVydERpYWxvZ0FjdGlvbj5cclxuICAgICAgICAgIDwvQWxlcnREaWFsb2dGb290ZXI+XHJcbiAgICAgICAgPC9BbGVydERpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgIDwvQWxlcnREaWFsb2c+XHJcblxyXG4gICAgICA8QWxlcnREaWFsb2cgb3Blbj17ZXhhbS5pc0V4YW1UZXJtaW5hdGVkfT5cclxuICAgICAgICA8QWxlcnREaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cImJvcmRlci0yIGJvcmRlci1kZXN0cnVjdGl2ZVwiPlxyXG4gICAgICAgICAgPEFsZXJ0RGlhbG9nSGVhZGVyPlxyXG4gICAgICAgICAgICA8QWxlcnREaWFsb2dUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LWRlc3RydWN0aXZlIGZvbnQtYm9sZCB0ZXh0LXhsIHVwcGVyY2FzZVwiPkV4YW0gVGVybWluYXRlZDwvQWxlcnREaWFsb2dUaXRsZT5cclxuICAgICAgICAgICAgPEFsZXJ0RGlhbG9nRGVzY3JpcHRpb24gY2xhc3NOYW1lPVwidGV4dC1iYXNlIHRleHQtc2xhdGUtODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICBZb3VyIGV4YW0gaGFzIGJlZW4gZm9yY2VmdWxseSBzdWJtaXR0ZWQgZHVlIHRvIG11bHRpcGxlIHJ1bGUgdmlvbGF0aW9ucyAoVGFiIFN3aXRjaGluZykuPGJyLz48YnIvPlxyXG4gICAgICAgICAgICAgIFRoaXMgYXR0ZW1wdCBoYXMgYmVlbiBmbGFnZ2VkIGZvciBhZG1pbmlzdHJhdGl2ZSByZXZpZXcuXHJcbiAgICAgICAgICAgIDwvQWxlcnREaWFsb2dEZXNjcmlwdGlvbj5cclxuICAgICAgICAgIDwvQWxlcnREaWFsb2dIZWFkZXI+XHJcbiAgICAgICAgPC9BbGVydERpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgIDwvQWxlcnREaWFsb2c+XHJcblxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgc3RpY2t5IHRvcC0wIHotMTBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTZ4bCBteC1hdXRvIHB4LTQgaC0xNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLXByaW1hcnkgcm91bmRlZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZFwiPlNQPC9kaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgdGV4dC1sZ1wiPlN0dWRlbnRQcmVwIENCVDwvaDE+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTEwMCBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIHtleGFtLnN5bmNTdGF0dXMgPT09ICdzeW5jZWQnID8gPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHJpbWFyeVwiIC8+IDpcclxuICAgICAgICAgICAgICAgICBleGFtLnN5bmNTdGF0dXMgPT09ICdzeW5jaW5nJyA/IDxkaXYgY2xhc3NOYW1lPVwidy00IGgtNCByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLXByaW1hcnkgYm9yZGVyLXQtdHJhbnNwYXJlbnQgYW5pbWF0ZS1zcGluXCIgLz4gOlxyXG4gICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtb3JhbmdlLTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiLCBleGFtLnN5bmNTdGF0dXMgPT09ICdlcnJvcicgPyBcInRleHQtb3JhbmdlLTYwMFwiIDogXCJ0ZXh0LXNsYXRlLTYwMFwiKX0+XHJcbiAgICAgICAgICAgICAgICAgIHtleGFtLnN5bmNTdGF0dXMgPT09ICdlcnJvcicgPyAnU2F2aW5nIExvY2FsbHknIDogZXhhbS5zeW5jU3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y24oXCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LW1vbm8gdGV4dC14bCBmb250LWJvbGQgcHgtNCBweS0xLjUgcm91bmRlZC1tZFwiLCBleGFtLnRpbWVMZWZ0IDwgMzAwID8gXCJiZy1kZXN0cnVjdGl2ZS8xMCB0ZXh0LWRlc3RydWN0aXZlXCIgOiBcImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTgwMFwiKX0+XHJcbiAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgIHtmb3JtYXRUaW1lKGV4YW0udGltZUxlZnQpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPFN1Ym1pdEJ1dHRvbj5TdWJtaXQgRmluYWw8L1N1Ym1pdEJ1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy02eGwgbXgtYXV0byB3LWZ1bGwgcC00IG1kOnAtOCBncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0xIHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgPENhcmQ+XHJcbiAgICAgICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cInBiLTMgYm9yZGVyLWIgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwXCI+Q2FuZGlkYXRlIEluZm88L0NhcmRUaXRsZT5cclxuICAgICAgICAgICAgPC9DYXJkSGVhZGVyPlxyXG4gICAgICAgICAgICA8Q2FyZENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC15LTIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5OYW1lOjwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIHRydW5jYXRlXCI+Sm9obiBEb2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMFwiPlJlZyBObzo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPjEyMzQ1Njc4QUI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMFwiPkNlbnRlcjo8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPkFidWphIENCVC0wMTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImgtZnVsbCBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cInBiLTMgYm9yZGVyLWIgZmxleCBmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS01MDBcIj5RdWVzdGlvbiBNYXA8L0NhcmRUaXRsZT5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIGJnLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTYwMCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIHtPYmplY3Qua2V5cyhleGFtLmFuc3dlcnMpLmxlbmd0aH0ve3F1ZXN0aW9ucy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L0NhcmRIZWFkZXI+XHJcbiAgICAgICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJmbGV4LTEgcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy01IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICB7cXVlc3Rpb25zLm1hcCgocSwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQW5zd2VyZWQgPSAhIWV4YW0uYW5zd2Vyc1txLmlkXTtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNDdXJyZW50ID0gY3VycmVudElkeCA9PT0gaWR4O1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRJZHgoaWR4KX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidy0xMCBoLTEwIHJvdW5kZWQgdGV4dC1zbSBmb250LW1lZGl1bSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBib3JkZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNDdXJyZW50ID8gXCJib3JkZXItc2xhdGUtOTAwIGJnLXdoaXRlIHRleHQtc2xhdGUtOTAwIGJvcmRlci0yXCIgOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0Fuc3dlcmVkID8gXCJiZy1wcmltYXJ5IHRleHQtd2hpdGUgaG92ZXI6YmctcHJpbWFyeS85MCBib3JkZXItcHJpbWFyeVwiIDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGJvcmRlci10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpZHggKyAxfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cclxuICAgICAgICAgICAgPENhcmRGb290ZXIgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYmctc2xhdGUtNTAgcC00IGZsZXgtY29sIGl0ZW1zLXN0YXJ0IHNwYWNlLXktMiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPjxkaXYgY2xhc3NOYW1lPVwidy0zIGgtMyBiZy1zbGF0ZS0xMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1zbVwiPjwvZGl2PiBVbmFuc3dlcmVkPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPjxkaXYgY2xhc3NOYW1lPVwidy0zIGgtMyBib3JkZXItMiBib3JkZXItc2xhdGUtOTAwIGJnLXdoaXRlIHJvdW5kZWQtc21cIj48L2Rpdj4gQ3VycmVudDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48ZGl2IGNsYXNzTmFtZT1cInctMyBoLTMgYmctcHJpbWFyeSByb3VuZGVkLXNtXCI+PC9kaXY+IEFuc3dlcmVkPC9kaXY+XHJcbiAgICAgICAgICAgIDwvQ2FyZEZvb3Rlcj5cclxuICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0zXCI+XHJcbiAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJwLTIgbWQ6cC00XCI+XHJcbiAgICAgICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi0yIGJvcmRlci1iLTBcIj5cclxuICAgICAgICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+UXVlc3Rpb24ge2N1cnJlbnRJZHggKyAxfSBvZiB7cXVlc3Rpb25zLmxlbmd0aH08L0NhcmRUaXRsZT5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj57Y3VycmVudFEuc3ViamVjdH08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvQ2FyZEhlYWRlcj5cclxuICAgICAgICAgICAgPENhcmRDb250ZW50PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS04MDAgdGV4dC1sZyBsZWFkaW5nLXJlbGF4ZWQgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgPFJpY2hUZXh0IHRleHQ9e2N1cnJlbnRRLmNvbnRlbnQudGV4dCB8fCBjdXJyZW50US5jb250ZW50LnBhc3NhZ2UgfHwgJyd9IC8+XHJcbiAgICAgICAgICAgICAgICB7Y3VycmVudFEuY29udGVudC5hc3NldHMgJiYgY3VycmVudFEuY29udGVudC5hc3NldHMubWFwKChhc3NldDogYW55LCBpOiBudW1iZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgYXNzZXQudHlwZSA9PT0gJ0lNQUdFJyAmJiA8aW1nIGtleT17aX0gc3JjPXthc3NldC51cmx9IGFsdD17YXNzZXQuYWx0fSBjbGFzc05hbWU9XCJtdC00IG1heC13LW1kIHJvdW5kZWQgc2hhZG93LXNtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxSYWRpb0dyb3VwIFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2V4YW0uYW5zd2Vyc1tjdXJyZW50US5pZF19IFxyXG4gICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gZGlzcGF0Y2goYW5zd2VyUXVlc3Rpb24oeyBxdWVzdGlvbklkOiBjdXJyZW50US5pZCwgb3B0aW9uSWQ6IHZhbCB9KSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhjdXJyZW50US5jb250ZW50Lm9wdGlvbnMgfHwge30pLm1hcCgoW29wdEtleSwgb3B0VGV4dF0sIGkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3Qgb3B0SWQgPSBvcHRLZXk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBleGFtLmFuc3dlcnNbY3VycmVudFEuaWRdID09PSBvcHRJZDtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8TGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9e29wdElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHctZnVsbCB0ZXh0LWxlZnQgcHgtNSBweS00IHJvdW5kZWQtbGcgYm9yZGVyLTIgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIiwgaXNTZWxlY3RlZCA/IFwiYm9yZGVyLXByaW1hcnkgYmctcHJpbWFyeS81IHNoYWRvdy1zbVwiIDogXCJib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtNTBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJhZGlvR3JvdXBJdGVtIHZhbHVlPXtvcHRJZH0gaWQ9e29wdElkfSBjbGFzc05hbWU9e2NuKGlzU2VsZWN0ZWQgPyBcInRleHQtcHJpbWFyeSBib3JkZXItcHJpbWFyeVwiIDogXCJcIil9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwiZm9udC1ib2xkIHRleHQtbGdcIiwgaXNTZWxlY3RlZCA/IFwidGV4dC1wcmltYXJ5XCIgOiBcInRleHQtc2xhdGUtNDAwXCIpfT57b3B0S2V5fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIHRleHQtYmFzZSBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJpY2hUZXh0IHRleHQ9e1N0cmluZyhvcHRUZXh0KX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L1JhZGlvR3JvdXA+XHJcbiAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XHJcbiAgICAgICAgICAgIDxDYXJkRm9vdGVyIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIG10LTYgcHQtNiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiBcclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRJZHgoTWF0aC5tYXgoMCwgY3VycmVudElkeCAtIDEpKX1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjdXJyZW50SWR4ID09PSAwfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFByZXZpb3VzXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAge2N1cnJlbnRJZHggPCBxdWVzdGlvbnMubGVuZ3RoIC0gMSA/IChcclxuICAgICAgICAgICAgICAgIDxCdXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRJZHgoY3VycmVudElkeCArIDEpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBOZXh0IFF1ZXN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPFN1Ym1pdEJ1dHRvbj5TdWJtaXQgRmluYWw8L1N1Ym1pdEJ1dHRvbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L0NhcmRGb290ZXI+XHJcbiAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcclxuICBjb25zdCBbaXNMb2dnZWRJbiwgc2V0SXNMb2dnZWRJbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaDxBcHBEaXNwYXRjaD4oKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCBkaXNwYXRjaChpbml0aWFsaXplRXhhbSh7IHNlc3Npb25JZDogJzAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMCcsIHVzZXJJZDogJzExMTExMTExLTExMTEtMTExMS0xMTExLTExMTExMTExMTExMScgfSkpO1xyXG4gICAgYXdhaXQgZGlzcGF0Y2goZmV0Y2hFeGFtUGF5bG9hZCgpKTtcclxuICAgIHNldElzTG9nZ2VkSW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtpc0xvZ2dlZEluID8gPEV4YW1EYXNoYm9hcmQgLz4gOiA8TG9naW5Gb3JtIG9uTG9naW49e2hhbmRsZUxvZ2lufSAvPn1cclxuICAgICAgPFRvYXN0ZXIgcG9zaXRpb249XCJ0b3AtY2VudGVyXCIgLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIl19