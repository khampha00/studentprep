import { n as __exportAll, r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=076f3cfd";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=cdd924ad";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom.js?v=cdd924ad";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=cdd924ad";
import { C as isOverflowElement, S as isNode, T as useIsoLayoutEffect, _ as getParentNode, b as isHTMLElement, c as useStableCallback, f as EMPTY_OBJECT, g as getNodeName, h as getComputedStyle, i as useRenderElement, m as useRefWithInit, p as NOOP, s as isReactVersionAtLeast, u as useMergedRefs, v as getWindow, w as isShadowRoot, x as isLastTraversableNode, y as isElement } from "/node_modules/.vite/deps/CompositeRootContext-D1Svtiq7.js?v=076f3cfd";
import { _ as AnimationFrame, a as resolveRef, c as createChangeEventDetails, d as focusOut, f as imperativeAction, g as triggerPress, i as useTransitionStatus, l as closePress, m as outsidePress, n as transitionStatusMapping, o as visuallyHidden, p as none, r as useOpenChangeComplete, t as TransitionStatusDataAttributes, u as escapeKey, v as useAnimationFrame, y as useOnMount } from "/node_modules/.vite/deps/stateAttributesMapping-Da3c5kE6.js?v=076f3cfd";
import { _ as activeElement, a as COMPOSITE_KEYS, m as isElementVisible, v as contains, y as getTarget } from "/node_modules/.vite/deps/composite-Bo6ZVhSW.js?v=076f3cfd";
import { n as useId, t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-B8kiyj7L.js?v=076f3cfd";
import { t as useButton } from "/node_modules/.vite/deps/useButton-B5DKzZ8P.js?v=076f3cfd";
//#region node_modules/@base-ui/utils/addEventListener.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Adds an event listener and returns a cleanup function to remove it.
*/
function addEventListener(target, type, listener, options) {
	target.addEventListener(type, listener, options);
	return () => {
		target.removeEventListener(type, listener, options);
	};
}
//#endregion
//#region node_modules/@base-ui/utils/platform/shared.mjs
/**
* Reads `navigator.userAgent` / `navigator.platform` (legacy but universally
* supported) into a normalized shape. In development, prefers the modern
* `navigator.userAgentData` API on Chromium to avoid DevTools warnings about
* the deprecated reads; that branch is dead-code-eliminated in production
* builds to keep the bundle small.
*
* Returns empty/zero values when `navigator` is undefined (SSR), so every
* derived flag safely evaluates to `false`.
*/
function readRawData() {
	if (typeof navigator === "undefined") return {
		userAgent: "",
		platform: "",
		maxTouchPoints: 0
	};
	{
		const uaData = navigator.userAgentData;
		if (uaData && Array.isArray(uaData.brands)) return {
			userAgent: uaData.brands.map(({ brand, version }) => `${brand}/${version}`).join(" "),
			platform: uaData.platform ?? navigator.platform ?? "",
			maxTouchPoints: navigator.maxTouchPoints ?? 0
		};
	}
	return {
		userAgent: navigator.userAgent,
		platform: navigator.platform ?? "",
		maxTouchPoints: navigator.maxTouchPoints ?? 0
	};
}
var { userAgent, platform, maxTouchPoints } = readRawData();
var lowerUserAgent = userAgent.toLowerCase();
var lowerPlatform = platform.toLowerCase();
//#endregion
//#region node_modules/@base-ui/utils/platform/os.mjs
/** iPhone, iPad (including iPadOS 13+ reporting as macOS), iPod. */
var ios = /^i(os$|p)/.test(lowerPlatform) || lowerPlatform === "macintel" && maxTouchPoints > 1;
/** Android phones, tablets, and embedded Android browsers. */
var ANDROID_STRING = "android";
var android = lowerPlatform === ANDROID_STRING || lowerUserAgent.includes(ANDROID_STRING);
/** macOS desktop. Excludes iPadOS, which reports as `MacIntel`. */
var mac = !ios && lowerPlatform.startsWith("mac");
lowerPlatform.startsWith("win");
!android && /^(linux|chrome os)/.test(lowerPlatform);
/** Any Apple OS (`mac || ios`). */
var apple = mac || ios;
//#endregion
//#region node_modules/@base-ui/utils/platform/engine.mjs
/** WebKit: Safari, all iOS browsers, GNOME Web. Excludes Blink. */
var webkit = typeof CSS !== "undefined" && !!CSS.supports?.("-webkit-backdrop-filter:none");
!webkit && lowerUserAgent.includes("firefox");
!webkit && lowerUserAgent.includes("chrom");
//#endregion
//#region node_modules/@base-ui/utils/platform/screen-reader.mjs
/**
* The user *may* be using VoiceOver — actual activation is not detectable.
* True on any Apple platform (macOS, iOS, iPadOS).
*/
var voiceOver = apple;
//#endregion
//#region node_modules/@base-ui/utils/platform/env.mjs
/** Running in jsdom or HappyDOM (used by unit tests). */
var jsdom = /jsdom|happydom/.test(lowerUserAgent);
//#endregion
//#region node_modules/@base-ui/utils/owner.mjs
function ownerDocument(node) {
	return node?.ownerDocument || document;
}
//#endregion
//#region node_modules/@base-ui/utils/useTimeout.mjs
var EMPTY = 0;
var Timeout = class Timeout {
	static create() {
		return new Timeout();
	}
	currentId = EMPTY;
	/**
	* Executes `fn` after `delay`, clearing any previously scheduled call.
	*/
	start(delay, fn) {
		this.clear();
		this.currentId = setTimeout(() => {
			this.currentId = EMPTY;
			fn();
		}, delay);
	}
	isStarted() {
		return this.currentId !== EMPTY;
	}
	clear = () => {
		if (this.currentId !== EMPTY) {
			clearTimeout(this.currentId);
			this.currentId = EMPTY;
		}
	};
	disposeEffect = () => {
		return this.clear;
	};
};
/**
* A `setTimeout` with automatic cleanup and guard.
*/
function useTimeout() {
	const timeout = useRefWithInit(Timeout.create).current;
	useOnMount(timeout.disposeEffect);
	return timeout;
}
//#endregion
//#region node_modules/@base-ui/utils/useScrollLock.mjs
var originalHtmlStyles = {};
var originalBodyStyles = {};
var originalHtmlScrollBehavior = "";
function getViewportScroller(html, body) {
	return isOverflowElement(html) ? html : body;
}
function isPageScrollLocked(win, html, body) {
	return /hidden|clip/.test(win.getComputedStyle(getViewportScroller(html, body)).overflowY);
}
function hasInsetScrollbars(referenceElement) {
	if (typeof document === "undefined") return false;
	const doc = ownerDocument(referenceElement);
	return getWindow(doc).innerWidth - doc.documentElement.clientWidth > 0;
}
function supportsStableScrollbarGutter(referenceElement) {
	if (!(typeof CSS !== "undefined" && CSS.supports && CSS.supports("scrollbar-gutter", "stable")) || typeof document === "undefined") return false;
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const scrollContainer = getViewportScroller(html, body);
	const originalScrollContainerOverflowY = scrollContainer.style.overflowY;
	const originalHtmlStyleGutter = html.style.scrollbarGutter;
	html.style.scrollbarGutter = "stable";
	scrollContainer.style.overflowY = "scroll";
	const before = scrollContainer.offsetWidth;
	scrollContainer.style.overflowY = "hidden";
	const after = scrollContainer.offsetWidth;
	scrollContainer.style.overflowY = originalScrollContainerOverflowY;
	html.style.scrollbarGutter = originalHtmlStyleGutter;
	return before === after;
}
function preventScrollOverlayScrollbars(referenceElement) {
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const elementToLock = getViewportScroller(html, body);
	const originalElementToLockStyles = {
		overflowY: elementToLock.style.overflowY,
		overflowX: elementToLock.style.overflowX
	};
	Object.assign(elementToLock.style, {
		overflowY: "hidden",
		overflowX: "hidden"
	});
	return () => {
		Object.assign(elementToLock.style, originalElementToLockStyles);
	};
}
function preventScrollInsetScrollbars(referenceElement) {
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const win = getWindow(html);
	let scrollTop = 0;
	let scrollLeft = 0;
	let updateGutterOnly = false;
	const resizeFrame = AnimationFrame.create();
	if (webkit && (win.visualViewport?.scale ?? 1) !== 1) return () => {};
	function lockScroll() {
		const htmlStyles = win.getComputedStyle(html);
		const bodyStyles = win.getComputedStyle(body);
		const scrollbarGutterValue = (htmlStyles.scrollbarGutter || "").includes("both-edges") ? "stable both-edges" : "stable";
		scrollTop = html.scrollTop;
		scrollLeft = html.scrollLeft;
		originalHtmlStyles = {
			scrollbarGutter: html.style.scrollbarGutter,
			overflowY: html.style.overflowY,
			overflowX: html.style.overflowX
		};
		originalHtmlScrollBehavior = html.style.scrollBehavior;
		originalBodyStyles = {
			position: body.style.position,
			height: body.style.height,
			width: body.style.width,
			boxSizing: body.style.boxSizing,
			overflowY: body.style.overflowY,
			overflowX: body.style.overflowX,
			scrollBehavior: body.style.scrollBehavior
		};
		const isScrollableY = html.scrollHeight > html.clientHeight;
		const isScrollableX = html.scrollWidth > html.clientWidth;
		const hasConstantOverflowY = htmlStyles.overflowY === "scroll" || bodyStyles.overflowY === "scroll";
		const hasConstantOverflowX = htmlStyles.overflowX === "scroll" || bodyStyles.overflowX === "scroll";
		const scrollbarWidth = Math.max(0, win.innerWidth - body.clientWidth);
		const scrollbarHeight = Math.max(0, win.innerHeight - body.clientHeight);
		const marginY = parseFloat(bodyStyles.marginTop) + parseFloat(bodyStyles.marginBottom);
		const marginX = parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight);
		const elementToLock = getViewportScroller(html, body);
		updateGutterOnly = supportsStableScrollbarGutter(referenceElement);
		if (updateGutterOnly) {
			html.style.scrollbarGutter = scrollbarGutterValue;
			elementToLock.style.overflowY = "hidden";
			elementToLock.style.overflowX = "hidden";
			return;
		}
		Object.assign(html.style, {
			scrollbarGutter: scrollbarGutterValue,
			overflowY: "hidden",
			overflowX: "hidden"
		});
		if (isScrollableY || hasConstantOverflowY) html.style.overflowY = "scroll";
		if (isScrollableX || hasConstantOverflowX) html.style.overflowX = "scroll";
		Object.assign(body.style, {
			position: "relative",
			height: marginY || scrollbarHeight ? `calc(100dvh - ${marginY + scrollbarHeight}px)` : "100dvh",
			width: marginX || scrollbarWidth ? `calc(100vw - ${marginX + scrollbarWidth}px)` : "100vw",
			boxSizing: "border-box",
			overflowY: "hidden",
			overflowX: "hidden",
			scrollBehavior: "unset"
		});
		body.scrollTop = scrollTop;
		body.scrollLeft = scrollLeft;
		html.setAttribute("data-base-ui-scroll-locked", "");
		html.style.scrollBehavior = "unset";
	}
	function cleanup() {
		Object.assign(html.style, originalHtmlStyles);
		Object.assign(body.style, originalBodyStyles);
		if (!updateGutterOnly) {
			html.scrollTop = scrollTop;
			html.scrollLeft = scrollLeft;
			html.removeAttribute("data-base-ui-scroll-locked");
			html.style.scrollBehavior = originalHtmlScrollBehavior;
		}
	}
	function handleResize() {
		cleanup();
		resizeFrame.request(lockScroll);
	}
	lockScroll();
	const unsubscribeResize = addEventListener(win, "resize", handleResize);
	return () => {
		resizeFrame.cancel();
		cleanup();
		if (typeof win.removeEventListener === "function") unsubscribeResize();
	};
}
var ScrollLocker = class {
	lockCount = 0;
	restore = null;
	timeoutLock = Timeout.create();
	timeoutUnlock = Timeout.create();
	acquire(referenceElement) {
		this.lockCount += 1;
		if (this.lockCount === 1 && this.restore === null) this.timeoutLock.start(0, () => this.lock(referenceElement));
		return this.release;
	}
	release = () => {
		this.lockCount -= 1;
		if (this.lockCount === 0 && this.restore) this.timeoutUnlock.start(0, this.unlock);
	};
	unlock = () => {
		if (this.lockCount === 0 && this.restore) {
			this.restore?.();
			this.restore = null;
		}
	};
	lock(referenceElement) {
		if (this.lockCount === 0 || this.restore !== null) return;
		const doc = ownerDocument(referenceElement);
		const html = doc.documentElement;
		const body = doc.body;
		const win = getWindow(html);
		if (isPageScrollLocked(win, html, body)) {
			const observer = new win.MutationObserver(() => {
				if (isPageScrollLocked(win, html, body)) return;
				observer.disconnect();
				this.restore = null;
				this.lock(referenceElement);
			});
			const options = { attributes: true };
			observer.observe(html, options);
			observer.observe(body, options);
			this.restore = () => observer.disconnect();
			return;
		}
		const hasOverlayScrollbars = ios || !hasInsetScrollbars(referenceElement);
		this.restore = hasOverlayScrollbars ? preventScrollOverlayScrollbars(referenceElement) : preventScrollInsetScrollbars(referenceElement);
	}
};
var SCROLL_LOCKER = new ScrollLocker();
/**
* Locks the scroll of the document when enabled.
*
* @param enabled - Whether to enable the scroll lock.
* @param referenceElement - Element to use as a reference for lock calculations.
*/
function useScrollLock(enabled = true, referenceElement = null) {
	useIsoLayoutEffect(() => {
		if (!enabled) return;
		return SCROLL_LOCKER.acquire(referenceElement);
	}, [enabled, referenceElement]);
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/event.mjs
function stopEvent(event) {
	event.preventDefault();
	event.stopPropagation();
}
function isReactEvent(event) {
	return "nativeEvent" in event;
}
function isVirtualClick(event) {
	if (event.pointerType === "" && event.isTrusted) return true;
	if (android && event.pointerType) return event.type === "click" && event.buttons === 1;
	return event.detail === 0 && !event.pointerType;
}
function isVirtualPointerEvent(event) {
	if (jsdom) return false;
	return !android && event.width === 0 && event.height === 0 || android && event.width === 1 && event.height === 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "mouse" || event.width < 1 && event.height < 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "touch";
}
function isMouseLikePointerType(pointerType, strict) {
	const values = ["mouse", "pen"];
	if (!strict) values.push("", void 0);
	return values.includes(pointerType);
}
function isClickLikeEvent(event) {
	const type = event.type;
	return type === "click" || type === "mousedown" || type === "keydown" || type === "keyup";
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/constants.mjs
var FOCUSABLE_ATTRIBUTE = "data-base-ui-focusable";
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/element.mjs
function isEventTargetWithin(event, node) {
	if (node == null) return false;
	if ("composedPath" in event) return event.composedPath().includes(node);
	const eventAgain = event;
	return eventAgain.target != null && node.contains(eventAgain.target);
}
function isRootElement(element) {
	return element.matches("html,body");
}
function isTypeableElement(element) {
	return isHTMLElement(element) && element.matches("input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])");
}
function isTypeableCombobox(element) {
	if (!element) return false;
	return element.getAttribute("role") === "combobox" && isTypeableElement(element);
}
function getFloatingFocusElement(floatingElement) {
	if (!floatingElement) return null;
	return floatingElement.hasAttribute("data-base-ui-focusable") ? floatingElement : floatingElement.querySelector(`[data-base-ui-focusable]`) || floatingElement;
}
//#endregion
//#region node_modules/@base-ui/utils/mergeCleanups.mjs
/**
* Combines multiple cleanup functions into a single cleanup function.
*/
function mergeCleanups(...cleanups) {
	return () => {
		for (let i = 0; i < cleanups.length; i += 1) {
			const cleanup = cleanups[i];
			if (cleanup) cleanup();
		}
	};
}
//#endregion
//#region node_modules/@base-ui/utils/useValueAsRef.mjs
/**
* Untracks the provided value by turning it into a ref to remove its reactivity.
*
* Used to access the passed value inside `React.useEffect` without causing the effect to re-run when the value changes.
*/
function useValueAsRef(value) {
	const latest = useRefWithInit(createLatestRef, value).current;
	latest.next = value;
	useIsoLayoutEffect(latest.effect);
	return latest;
}
function createLatestRef(value) {
	const latest = {
		current: value,
		next: value,
		effect: () => {
			latest.current = latest.next;
		}
	};
	return latest;
}
//#endregion
//#region node_modules/@base-ui/react/utils/FocusGuard.mjs
var import_jsx_runtime = require_jsx_runtime();
var FocusGuard = /*#__PURE__*/ import_react.forwardRef(function FocusGuard(props, ref) {
	const [role, setRole] = import_react.useState();
	useIsoLayoutEffect(() => {
		if (voiceOver && webkit) setRole("button");
	}, []);
	const restProps = {
		tabIndex: 0,
		role
	};
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
		...props,
		ref,
		style: visuallyHidden,
		"aria-hidden": role ? void 0 : true,
		...restProps,
		"data-base-ui-focus-guard": ""
	});
});
FocusGuard.displayName = "FocusGuard";
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/tabbable.mjs
var CANDIDATE_SELECTOR = "a[href],button,input,select,textarea,summary,details,iframe,object,embed,[tabindex],[contenteditable]:not([contenteditable=\"false\"]),audio[controls],video[controls]";
function getParentElement(element) {
	const assignedSlot = element.assignedSlot;
	if (assignedSlot) return assignedSlot;
	if (element.parentElement) return element.parentElement;
	const rootNode = element.getRootNode();
	return isShadowRoot(rootNode) ? rootNode.host : null;
}
function getDetailsSummary(details) {
	for (const child of Array.from(details.children)) if (getNodeName(child) === "summary") return child;
	return null;
}
function isWithinOpenDetailsSummary(element, details) {
	const summary = getDetailsSummary(details);
	return !!summary && (element === summary || contains(summary, element));
}
function isFocusableCandidate(element) {
	const nodeName = element ? getNodeName(element) : "";
	return element != null && element.matches(CANDIDATE_SELECTOR) && (nodeName !== "summary" || element.parentElement != null && getNodeName(element.parentElement) === "details" && getDetailsSummary(element.parentElement) === element) && (nodeName !== "details" || getDetailsSummary(element) == null) && (nodeName !== "input" || element.type !== "hidden");
}
function isFocusableElement(element) {
	if (!isFocusableCandidate(element) || !element.isConnected || element.matches(":disabled")) return false;
	for (let current = element; current; current = getParentElement(current)) {
		const isAncestor = current !== element;
		const isSlot = getNodeName(current) === "slot";
		if (current.hasAttribute("inert")) return false;
		if (isAncestor && getNodeName(current) === "details" && !current.open && !isWithinOpenDetailsSummary(element, current) || current.hasAttribute("hidden") || !isSlot && !isVisibleInTabbableTree(current, isAncestor)) return false;
	}
	return true;
}
function isVisibleInTabbableTree(element, isAncestor) {
	const styles = getComputedStyle(element);
	if (!isAncestor) return isElementVisible(element, styles);
	return styles.display !== "none";
}
function getTabIndex(element) {
	const tabIndex = element.tabIndex;
	if (tabIndex < 0) {
		const nodeName = getNodeName(element);
		if (nodeName === "details" || nodeName === "audio" || nodeName === "video" || isHTMLElement(element) && element.isContentEditable) return 0;
	}
	return tabIndex;
}
function getNamedRadioInput(element) {
	if (getNodeName(element) !== "input") return null;
	const input = element;
	return input.type === "radio" && input.name !== "" ? input : null;
}
function isTabbableRadio(element, candidates) {
	const input = getNamedRadioInput(element);
	if (!input) return true;
	const checkedRadio = candidates.find((candidate) => {
		const radio = getNamedRadioInput(candidate);
		return radio?.name === input.name && radio.form === input.form && radio.checked;
	});
	if (checkedRadio) return checkedRadio === input;
	return candidates.find((candidate) => {
		const radio = getNamedRadioInput(candidate);
		return radio?.name === input.name && radio.form === input.form;
	}) === input;
}
function getComposedChildren(container) {
	if (isHTMLElement(container) && getNodeName(container) === "slot") {
		const assignedElements = container.assignedElements({ flatten: true });
		if (assignedElements.length > 0) return assignedElements;
	}
	if (isHTMLElement(container) && container.shadowRoot) return Array.from(container.shadowRoot.children);
	return Array.from(container.children);
}
function appendCandidates(container, list) {
	getComposedChildren(container).forEach((child) => {
		if (isFocusableCandidate(child)) list.push(child);
		appendCandidates(child, list);
	});
}
function appendMatchingElements(container, selector, list) {
	getComposedChildren(container).forEach((child) => {
		if (isHTMLElement(child) && child.matches(selector)) list.push(child);
		appendMatchingElements(child, selector, list);
	});
}
function isTabbable(element) {
	return isFocusableElement(element) && getTabIndex(element) >= 0;
}
function focusable(container) {
	const candidates = [];
	appendCandidates(container, candidates);
	return candidates.filter(isFocusableElement);
}
function tabbable(container) {
	const candidates = focusable(container);
	return candidates.filter((element) => getTabIndex(element) >= 0 && isTabbableRadio(element, candidates));
}
function getTabbableIn(container, dir) {
	const list = tabbable(container);
	const len = list.length;
	if (len === 0) return;
	const active = activeElement(ownerDocument(container));
	const index = list.indexOf(active);
	return list[index === -1 ? dir === 1 ? 0 : len - 1 : index + dir];
}
function getNextTabbable(referenceElement) {
	return getTabbableIn(ownerDocument(referenceElement).body, 1) || referenceElement;
}
function getPreviousTabbable(referenceElement) {
	return getTabbableIn(ownerDocument(referenceElement).body, -1) || referenceElement;
}
function isOutsideEvent(event, container) {
	const containerElement = container || event.currentTarget;
	const relatedTarget = event.relatedTarget;
	return !relatedTarget || !contains(containerElement, relatedTarget);
}
function disableFocusInside(container) {
	tabbable(container).forEach((element) => {
		element.dataset.tabindex = element.getAttribute("tabindex") || "";
		element.setAttribute("tabindex", "-1");
	});
}
function enableFocusInside(container) {
	const elements = [];
	appendMatchingElements(container, "[data-tabindex]", elements);
	elements.forEach((element) => {
		const tabindex = element.dataset.tabindex;
		delete element.dataset.tabindex;
		if (tabindex) element.setAttribute("tabindex", tabindex);
		else element.removeAttribute("tabindex");
	});
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/nodes.mjs
function getNodeChildren(nodes, id, onlyOpenChildren = true) {
	return nodes.filter((node) => node.parentId === id).flatMap((child) => [...!onlyOpenChildren || child.context?.open ? [child] : [], ...getNodeChildren(nodes, child.id, onlyOpenChildren)]);
}
function getNodeAncestors(nodes, id) {
	let allAncestors = [];
	let currentParentId = nodes.find((node) => node.id === id)?.parentId;
	while (currentParentId) {
		const currentNode = nodes.find((node) => node.id === currentParentId);
		currentParentId = currentNode?.parentId;
		if (currentNode) allAncestors = allAncestors.concat(currentNode);
	}
	return allAncestors;
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/createAttribute.mjs
function createAttribute(name) {
	return `data-base-ui-${name}`;
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/enqueueFocus.mjs
var rafId = 0;
function enqueueFocus(el, options = {}) {
	const { preventScroll = false, sync = false, shouldFocus } = options;
	cancelAnimationFrame(rafId);
	function exec() {
		if (shouldFocus && !shouldFocus()) return;
		el?.focus({ preventScroll });
	}
	if (sync) {
		exec();
		return NOOP;
	}
	const currentRafId = requestAnimationFrame(exec);
	rafId = currentRafId;
	return () => {
		if (rafId === currentRafId) {
			cancelAnimationFrame(currentRafId);
			rafId = 0;
		}
	};
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/markOthers.mjs
var counters = {
	inert: /* @__PURE__ */ new WeakMap(),
	"aria-hidden": /* @__PURE__ */ new WeakMap()
};
var markerName = "data-base-ui-inert";
var uncontrolledElementsSets = {
	inert: /* @__PURE__ */ new WeakSet(),
	"aria-hidden": /* @__PURE__ */ new WeakSet()
};
var markerCounterMap = /* @__PURE__ */ new WeakMap();
var lockCount = 0;
function getUncontrolledElementsSet(controlAttribute) {
	return uncontrolledElementsSets[controlAttribute];
}
function unwrapHost(node) {
	if (!node) return null;
	return isShadowRoot(node) ? node.host : unwrapHost(node.parentNode);
}
var correctElements = (parent, targets) => targets.map((target) => {
	if (parent.contains(target)) return target;
	const correctedTarget = unwrapHost(target);
	if (parent.contains(correctedTarget)) return correctedTarget;
	return null;
}).filter((x) => x != null);
var buildKeepSet = (targets) => {
	const keep = /* @__PURE__ */ new Set();
	targets.forEach((target) => {
		let node = target;
		while (node && !keep.has(node)) {
			keep.add(node);
			node = node.parentNode;
		}
	});
	return keep;
};
var collectOutsideElements = (root, keepElements, stopElements) => {
	const outside = [];
	const walk = (parent) => {
		if (!parent || stopElements.has(parent)) return;
		Array.from(parent.children).forEach((node) => {
			if (getNodeName(node) === "script") return;
			if (keepElements.has(node)) walk(node);
			else outside.push(node);
		});
	};
	walk(root);
	return outside;
};
function applyAttributeToOthers(uncorrectedAvoidElements, body, ariaHidden, inert, { mark = true }) {
	let controlAttribute = null;
	if (inert) controlAttribute = "inert";
	else if (ariaHidden) controlAttribute = "aria-hidden";
	let counterMap = null;
	let uncontrolledElementsSet = null;
	const avoidElements = correctElements(body, uncorrectedAvoidElements);
	const markerTargets = mark ? collectOutsideElements(body, buildKeepSet(avoidElements), new Set(avoidElements)) : [];
	const hiddenElements = [];
	const markedElements = [];
	if (controlAttribute) {
		const map = counters[controlAttribute];
		const currentUncontrolledElementsSet = getUncontrolledElementsSet(controlAttribute);
		uncontrolledElementsSet = currentUncontrolledElementsSet;
		counterMap = map;
		const ariaLiveElements = correctElements(body, Array.from(body.querySelectorAll("[aria-live]")));
		const controlElements = avoidElements.concat(ariaLiveElements);
		collectOutsideElements(body, buildKeepSet(controlElements), new Set(controlElements)).forEach((node) => {
			const attr = node.getAttribute(controlAttribute);
			const alreadyHidden = attr !== null && attr !== "false";
			const counterValue = (map.get(node) || 0) + 1;
			map.set(node, counterValue);
			hiddenElements.push(node);
			if (counterValue === 1 && alreadyHidden) currentUncontrolledElementsSet.add(node);
			if (!alreadyHidden) node.setAttribute(controlAttribute, controlAttribute === "inert" ? "" : "true");
		});
	}
	if (mark) markerTargets.forEach((node) => {
		const markerValue = (markerCounterMap.get(node) || 0) + 1;
		markerCounterMap.set(node, markerValue);
		markedElements.push(node);
		if (markerValue === 1) node.setAttribute(markerName, "");
	});
	lockCount += 1;
	return () => {
		if (counterMap) hiddenElements.forEach((element) => {
			const counterValue = (counterMap.get(element) || 0) - 1;
			counterMap.set(element, counterValue);
			if (!counterValue) {
				if (!uncontrolledElementsSet?.has(element) && controlAttribute) element.removeAttribute(controlAttribute);
				uncontrolledElementsSet?.delete(element);
			}
		});
		if (mark) markedElements.forEach((element) => {
			const markerValue = (markerCounterMap.get(element) || 0) - 1;
			markerCounterMap.set(element, markerValue);
			if (!markerValue) element.removeAttribute(markerName);
		});
		lockCount -= 1;
		if (!lockCount) {
			counters.inert = /* @__PURE__ */ new WeakMap();
			counters["aria-hidden"] = /* @__PURE__ */ new WeakMap();
			uncontrolledElementsSets.inert = /* @__PURE__ */ new WeakSet();
			uncontrolledElementsSets["aria-hidden"] = /* @__PURE__ */ new WeakSet();
			markerCounterMap = /* @__PURE__ */ new WeakMap();
		}
	};
}
function markOthers(avoidElements, options = {}) {
	const { ariaHidden = false, inert = false, mark = true } = options;
	const body = ownerDocument(avoidElements[0]).body;
	return applyAttributeToOthers(avoidElements, body, ariaHidden, inert, { mark });
}
//#endregion
//#region node_modules/@base-ui/react/internals/constants.mjs
var CLICK_TRIGGER_IDENTIFIER = "data-base-ui-click-trigger";
var BASE_UI_SWIPE_IGNORE_ATTRIBUTE = "data-base-ui-swipe-ignore";
var LEGACY_SWIPE_IGNORE_ATTRIBUTE = "data-swipe-ignore";
`${BASE_UI_SWIPE_IGNORE_ATTRIBUTE}`;
`${LEGACY_SWIPE_IGNORE_ATTRIBUTE}`;
/**
* Special visually hidden styles for the aria-owns owner element to ensure owned element
* accessibility in iOS/Safari/VoiceControl.
* The owner element is an empty span, so most of the common visually hidden styles are not needed.
* @see https://github.com/floating-ui/floating-ui/issues/3403
*/
var ownerVisuallyHidden = {
	clipPath: "inset(50%)",
	position: "fixed",
	top: 0,
	left: 0
};
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/components/FloatingPortal.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var PortalContext = /*#__PURE__*/ import_react.createContext(null);
PortalContext.displayName = "PortalContext";
var usePortalContext = () => import_react.useContext(PortalContext);
var attr = createAttribute("portal");
function useFloatingPortalNode(props = {}) {
	const { ref, container: containerProp, componentProps = EMPTY_OBJECT, elementProps } = props;
	const uniqueId = useId();
	const parentPortalNode = usePortalContext()?.portalNode;
	const [containerElement, setContainerElement] = import_react.useState(null);
	const [portalNode, setPortalNode] = import_react.useState(null);
	const setPortalNodeRef = useStableCallback((node) => {
		if (node !== null) setPortalNode(node);
	});
	const containerRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (containerProp === null) {
			if (containerRef.current) {
				containerRef.current = null;
				setPortalNode(null);
				setContainerElement(null);
			}
			return;
		}
		const resolvedContainer = (containerProp && (isNode(containerProp) ? containerProp : containerProp.current)) ?? parentPortalNode ?? document.body;
		if (resolvedContainer == null) {
			if (containerRef.current) {
				containerRef.current = null;
				setPortalNode(null);
				setContainerElement(null);
			}
			return;
		}
		if (containerRef.current !== resolvedContainer) {
			containerRef.current = resolvedContainer;
			setPortalNode(null);
			setContainerElement(resolvedContainer);
		}
	}, [containerProp, parentPortalNode]);
	const portalElement = useRenderElement("div", componentProps, {
		ref: [ref, setPortalNodeRef],
		props: [{
			id: uniqueId,
			[attr]: ""
		}, elementProps]
	});
	const portalSubtree = containerElement && portalElement ? /*#__PURE__*/ import_react_dom.createPortal(portalElement, containerElement) : null;
	return {
		node: portalNode,
		nodeId: /*#__PURE__*/ import_react.isValidElement(portalElement) ? portalElement.props.id : void 0,
		subtree: portalSubtree
	};
}
/**
* Portals the floating element into a given container element — by default,
* outside of the app root and into the body.
* This is necessary to ensure the floating element can appear outside any
* potential parent containers that cause clipping (such as `overflow: hidden`),
* while retaining its location in the React tree.
* @see https://floating-ui.com/docs/FloatingPortal
* @internal
*/
var FloatingPortal = /*#__PURE__*/ import_react.forwardRef(function FloatingPortal(componentProps, forwardedRef) {
	const { render, className, style, children, container, ...elementProps } = componentProps;
	const { node: portalNode, nodeId: portalNodeId, subtree: portalSubtree } = useFloatingPortalNode({
		container,
		ref: forwardedRef,
		componentProps,
		elementProps
	});
	const beforeOutsideRef = import_react.useRef(null);
	const afterOutsideRef = import_react.useRef(null);
	const beforeInsideRef = import_react.useRef(null);
	const afterInsideRef = import_react.useRef(null);
	const [focusManagerState, setFocusManagerState] = import_react.useState(null);
	const focusInsideDisabledRef = import_react.useRef(false);
	const modal = focusManagerState?.modal;
	const open = focusManagerState?.open;
	const shouldRenderGuards = !!focusManagerState && !focusManagerState.modal && focusManagerState.open && !!portalNode;
	import_react.useEffect(() => {
		if (!portalNode || modal) return;
		function onFocus(event) {
			if (portalNode && event.relatedTarget && isOutsideEvent(event)) {
				if (event.type === "focusin") {
					if (focusInsideDisabledRef.current) {
						enableFocusInside(portalNode);
						focusInsideDisabledRef.current = false;
					}
				} else {
					disableFocusInside(portalNode);
					focusInsideDisabledRef.current = true;
				}
			}
		}
		return mergeCleanups(addEventListener(portalNode, "focusin", onFocus, true), addEventListener(portalNode, "focusout", onFocus, true));
	}, [portalNode, modal]);
	useIsoLayoutEffect(() => {
		if (!portalNode || open !== true || !focusInsideDisabledRef.current) return;
		enableFocusInside(portalNode);
		focusInsideDisabledRef.current = false;
	}, [open, portalNode]);
	const portalContextValue = import_react.useMemo(() => ({
		beforeOutsideRef,
		afterOutsideRef,
		beforeInsideRef,
		afterInsideRef,
		portalNode,
		setFocusManagerState
	}), [portalNode]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [portalSubtree, /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(PortalContext.Provider, {
		value: portalContextValue,
		children: [
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
				"data-type": "outside",
				ref: beforeOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) beforeInsideRef.current?.focus();
					else getPreviousTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
				}
			}),
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
				"aria-owns": portalNodeId,
				style: ownerVisuallyHidden
			}),
			portalNode && /*#__PURE__*/ import_react_dom.createPortal(children, portalNode),
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
				"data-type": "outside",
				ref: afterOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) afterInsideRef.current?.focus();
					else {
						getNextTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
						if (focusManagerState?.closeOnFocusOut) focusManagerState?.onOpenChange(false, createChangeEventDetails("focus-out", event.nativeEvent));
					}
				}
			})
		]
	})] });
});
FloatingPortal.displayName = "FloatingPortal";
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/createEventEmitter.mjs
function createEventEmitter() {
	const map = /* @__PURE__ */ new Map();
	return {
		emit(event, data) {
			map.get(event)?.forEach((listener) => listener(data));
		},
		on(event, listener) {
			if (!map.has(event)) map.set(event, /* @__PURE__ */ new Set());
			map.get(event).add(listener);
		},
		off(event, listener) {
			map.get(event)?.delete(listener);
		}
	};
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/components/FloatingTree.mjs
var FloatingNodeContext = /*#__PURE__*/ import_react.createContext(null);
FloatingNodeContext.displayName = "FloatingNodeContext";
var FloatingTreeContext = /*#__PURE__*/ import_react.createContext(null);
FloatingTreeContext.displayName = "FloatingTreeContext";
var useFloatingParentNodeId = () => import_react.useContext(FloatingNodeContext)?.id || null;
/**
* Returns the nearest floating tree context, if available.
*/
var useFloatingTree = (externalTree) => {
	const contextTree = import_react.useContext(FloatingTreeContext);
	return externalTree ?? contextTree;
};
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/components/FloatingFocusManager.mjs
function getEventType(event, lastInteractionType) {
	const win = getWindow(getTarget(event));
	if (event instanceof win.KeyboardEvent) return "keyboard";
	if (event instanceof win.FocusEvent) return lastInteractionType || "keyboard";
	if ("pointerType" in event) return event.pointerType || "keyboard";
	if ("touches" in event) return "touch";
	if (event instanceof win.MouseEvent) return lastInteractionType || (event.detail === 0 ? "keyboard" : "mouse");
	return "";
}
var LIST_LIMIT = 20;
var previouslyFocusedElements = [];
function clearDisconnectedPreviouslyFocusedElements() {
	previouslyFocusedElements = previouslyFocusedElements.filter((entry) => {
		return entry.deref()?.isConnected;
	});
}
function addPreviouslyFocusedElement(element) {
	clearDisconnectedPreviouslyFocusedElements();
	if (element && getNodeName(element) !== "body") {
		previouslyFocusedElements.push(new WeakRef(element));
		if (previouslyFocusedElements.length > LIST_LIMIT) previouslyFocusedElements = previouslyFocusedElements.slice(-20);
	}
}
function getPreviouslyFocusedElement() {
	clearDisconnectedPreviouslyFocusedElements();
	return previouslyFocusedElements[previouslyFocusedElements.length - 1]?.deref();
}
function getFirstTabbableElement(container) {
	if (!container) return null;
	if (isTabbable(container)) return container;
	return tabbable(container)[0] || container;
}
function handleTabIndex(floatingFocusElement) {
	if (floatingFocusElement.hasAttribute("tabindex") && !floatingFocusElement.hasAttribute("data-tabindex")) return;
	if (!floatingFocusElement.getAttribute("role")?.includes("dialog")) return;
	const tabbableContent = focusable(floatingFocusElement).filter((element) => {
		const dataTabIndex = element.getAttribute("data-tabindex") || "";
		return isTabbable(element) || element.hasAttribute("data-tabindex") && !dataTabIndex.startsWith("-");
	});
	const tabIndex = floatingFocusElement.getAttribute("tabindex");
	if (tabbableContent.length === 0) {
		if (tabIndex !== "0") {
			floatingFocusElement.setAttribute("tabindex", "0");
			floatingFocusElement.setAttribute("data-tabindex", "0");
		}
	} else if (tabIndex !== "-1" || floatingFocusElement.hasAttribute("data-tabindex") && floatingFocusElement.getAttribute("data-tabindex") !== "-1") {
		floatingFocusElement.setAttribute("tabindex", "-1");
		floatingFocusElement.setAttribute("data-tabindex", "-1");
	}
}
/**
* Provides focus management for the floating element.
* @see https://floating-ui.com/docs/FloatingFocusManager
* @internal
*/
function FloatingFocusManager(props) {
	const { context, children, disabled = false, initialFocus = true, returnFocus = true, restoreFocus = false, modal = true, closeOnFocusOut = true, openInteractionType = "", nextFocusableElement, previousFocusableElement, beforeContentFocusGuardRef, externalTree, getInsideElements } = props;
	const store = "rootStore" in context ? context.rootStore : context;
	const open = store.useState("open");
	const domReference = store.useState("domReferenceElement");
	const floating = store.useState("floatingElement");
	const { events, dataRef } = store.context;
	const getNodeId = useStableCallback(() => dataRef.current.floatingContext?.nodeId);
	const ignoreInitialFocus = initialFocus === false;
	const isUntrappedTypeableCombobox = isTypeableCombobox(domReference) && ignoreInitialFocus;
	const initialFocusRef = useValueAsRef(initialFocus);
	const returnFocusRef = useValueAsRef(returnFocus);
	const openInteractionTypeRef = useValueAsRef(openInteractionType);
	const openRef = useValueAsRef(open);
	const tree = useFloatingTree(externalTree);
	const portalContext = usePortalContext();
	const preventReturnFocusRef = import_react.useRef(false);
	const isPointerDownRef = import_react.useRef(false);
	const pointerDownOutsideRef = import_react.useRef(false);
	const lastFocusedTabbableRef = import_react.useRef(null);
	const closeTypeRef = import_react.useRef("");
	const lastInteractionTypeRef = import_react.useRef("");
	const beforeGuardRef = import_react.useRef(null);
	const afterGuardRef = import_react.useRef(null);
	const mergedBeforeGuardRef = useMergedRefs(beforeGuardRef, beforeContentFocusGuardRef, portalContext?.beforeInsideRef);
	const mergedAfterGuardRef = useMergedRefs(afterGuardRef, portalContext?.afterInsideRef);
	const blurTimeout = useTimeout();
	const pointerDownTimeout = useTimeout();
	const restoreFocusFrame = useAnimationFrame();
	const isInsidePortal = portalContext != null;
	const floatingFocusElement = getFloatingFocusElement(floating);
	const getTabbableContent = useStableCallback((container = floatingFocusElement) => {
		return container ? tabbable(container) : [];
	});
	const getResolvedInsideElements = useStableCallback(() => getInsideElements?.().filter((element) => element != null) ?? []);
	import_react.useEffect(() => {
		if (disabled || !modal) return;
		function onKeyDown(event) {
			if (event.key === "Tab") {
				if (contains(floatingFocusElement, activeElement(ownerDocument(floatingFocusElement))) && getTabbableContent().length === 0 && !isUntrappedTypeableCombobox) stopEvent(event);
			}
		}
		return addEventListener(ownerDocument(floatingFocusElement), "keydown", onKeyDown);
	}, [
		disabled,
		floatingFocusElement,
		modal,
		isUntrappedTypeableCombobox,
		getTabbableContent
	]);
	import_react.useEffect(() => {
		if (disabled || !open) return;
		const doc = ownerDocument(floatingFocusElement);
		function clearPointerDownOutside() {
			pointerDownOutsideRef.current = false;
		}
		function onPointerDown(event) {
			const target = getTarget(event);
			const insideElements = getResolvedInsideElements();
			const pointerTargetInside = contains(floating, target) || contains(domReference, target) || contains(portalContext?.portalNode, target) || insideElements.some((element) => element === target || contains(element, target));
			pointerDownOutsideRef.current = !pointerTargetInside;
			lastInteractionTypeRef.current = event.pointerType || "keyboard";
			if (target?.closest(`[data-base-ui-click-trigger]`)) {
				isPointerDownRef.current = true;
				pointerDownTimeout.start(0, () => {
					isPointerDownRef.current = false;
				});
			}
		}
		function onKeyDown() {
			lastInteractionTypeRef.current = "keyboard";
		}
		return mergeCleanups(addEventListener(doc, "pointerdown", onPointerDown, true), addEventListener(doc, "pointerup", clearPointerDownOutside, true), addEventListener(doc, "pointercancel", clearPointerDownOutside, true), addEventListener(doc, "keydown", onKeyDown, true), clearPointerDownOutside);
	}, [
		disabled,
		floating,
		domReference,
		floatingFocusElement,
		open,
		portalContext,
		pointerDownTimeout,
		getResolvedInsideElements
	]);
	import_react.useEffect(() => {
		if (disabled || !closeOnFocusOut) return;
		const doc = ownerDocument(floatingFocusElement);
		function handlePointerDown() {
			isPointerDownRef.current = true;
			pointerDownTimeout.start(0, () => {
				isPointerDownRef.current = false;
			});
		}
		function handleFocusIn(event) {
			const target = getTarget(event);
			if (isTabbable(target)) lastFocusedTabbableRef.current = target;
		}
		function handleFocusOutside(event) {
			const relatedTarget = event.relatedTarget;
			const currentTarget = event.currentTarget;
			const target = getTarget(event);
			if (modal && relatedTarget == null && target != null && contains(floating, target)) addPreviouslyFocusedElement(target);
			queueMicrotask(() => {
				const nodeId = getNodeId();
				const triggers = store.context.triggerElements;
				const insideElements = getResolvedInsideElements();
				const isRelatedFocusGuard = relatedTarget?.hasAttribute(createAttribute("focus-guard")) && [
					beforeGuardRef.current,
					afterGuardRef.current,
					portalContext?.beforeInsideRef.current,
					portalContext?.afterInsideRef.current,
					portalContext?.beforeOutsideRef.current,
					portalContext?.afterOutsideRef.current,
					resolveRef(previousFocusableElement),
					resolveRef(nextFocusableElement)
				].includes(relatedTarget);
				const movedToUnrelatedNode = !(contains(domReference, relatedTarget) || contains(floating, relatedTarget) || contains(relatedTarget, floating) || contains(portalContext?.portalNode, relatedTarget) || insideElements.some((element) => element === relatedTarget || contains(element, relatedTarget)) || triggers.hasMatchingElement((trigger) => contains(trigger, relatedTarget)) || isRelatedFocusGuard || tree && (getNodeChildren(tree.nodesRef.current, nodeId).find((node) => contains(node.context?.elements.floating, relatedTarget) || contains(node.context?.elements.domReference, relatedTarget)) || getNodeAncestors(tree.nodesRef.current, nodeId).find((node) => [node.context?.elements.floating, getFloatingFocusElement(node.context?.elements.floating)].includes(relatedTarget) || node.context?.elements.domReference === relatedTarget)));
				if (currentTarget === domReference && floatingFocusElement) handleTabIndex(floatingFocusElement);
				if (restoreFocus && currentTarget !== domReference && !isElementVisible(target) && activeElement(doc) === doc.body) {
					if (isHTMLElement(floatingFocusElement)) {
						floatingFocusElement.focus();
						if (restoreFocus === "popup") {
							restoreFocusFrame.request(() => {
								floatingFocusElement.focus();
							});
							return;
						}
					}
					const tabbableContent = getTabbableContent();
					const prevTabbable = lastFocusedTabbableRef.current;
					const nodeToFocus = (prevTabbable && tabbableContent.includes(prevTabbable) ? prevTabbable : null) || tabbableContent[tabbableContent.length - 1] || floatingFocusElement;
					if (isHTMLElement(nodeToFocus)) nodeToFocus.focus();
				}
				if (dataRef.current.insideReactTree) {
					dataRef.current.insideReactTree = false;
					return;
				}
				if ((isUntrappedTypeableCombobox ? true : !modal) && relatedTarget && movedToUnrelatedNode && !isPointerDownRef.current && (isUntrappedTypeableCombobox || relatedTarget !== getPreviouslyFocusedElement())) {
					preventReturnFocusRef.current = true;
					store.setOpen(false, createChangeEventDetails(focusOut, event));
				}
			});
		}
		function markInsideReactTree() {
			if (pointerDownOutsideRef.current) return;
			dataRef.current.insideReactTree = true;
			blurTimeout.start(0, () => {
				dataRef.current.insideReactTree = false;
			});
		}
		const domReferenceElement = isHTMLElement(domReference) ? domReference : null;
		if (!floating && !domReferenceElement) return;
		return mergeCleanups(domReferenceElement && addEventListener(domReferenceElement, "focusout", handleFocusOutside), domReferenceElement && addEventListener(domReferenceElement, "pointerdown", handlePointerDown), floating && addEventListener(floating, "focusin", handleFocusIn), floating && addEventListener(floating, "focusout", handleFocusOutside), floating && portalContext && addEventListener(floating, "focusout", markInsideReactTree, true));
	}, [
		disabled,
		domReference,
		floating,
		floatingFocusElement,
		modal,
		tree,
		portalContext,
		store,
		closeOnFocusOut,
		restoreFocus,
		getTabbableContent,
		isUntrappedTypeableCombobox,
		getNodeId,
		dataRef,
		blurTimeout,
		pointerDownTimeout,
		restoreFocusFrame,
		nextFocusableElement,
		previousFocusableElement,
		getResolvedInsideElements
	]);
	import_react.useEffect(() => {
		if (disabled || !floating || !open) return;
		const portalNodes = Array.from(portalContext?.portalNode?.querySelectorAll(`[${createAttribute("portal")}]`) || []);
		const rootAncestorComboboxDomReference = (tree ? getNodeAncestors(tree.nodesRef.current, getNodeId()) : []).find((node) => isTypeableCombobox(node.context?.elements.domReference || null))?.context?.elements.domReference;
		const ariaHiddenCleanup = markOthers([
			...[
				floating,
				...portalNodes,
				beforeGuardRef.current,
				afterGuardRef.current,
				portalContext?.beforeOutsideRef.current,
				portalContext?.afterOutsideRef.current,
				...getResolvedInsideElements()
			],
			rootAncestorComboboxDomReference,
			resolveRef(previousFocusableElement),
			resolveRef(nextFocusableElement),
			isUntrappedTypeableCombobox ? domReference : null
		].filter((x) => x != null), {
			ariaHidden: modal || isUntrappedTypeableCombobox,
			mark: false
		});
		const markerCleanup = markOthers([floating, ...portalNodes].filter((x) => x != null));
		return () => {
			markerCleanup();
			ariaHiddenCleanup();
		};
	}, [
		open,
		disabled,
		domReference,
		floating,
		modal,
		portalContext,
		isUntrappedTypeableCombobox,
		tree,
		getNodeId,
		nextFocusableElement,
		previousFocusableElement,
		getResolvedInsideElements
	]);
	useIsoLayoutEffect(() => {
		if (!open || disabled || !isHTMLElement(floatingFocusElement)) return;
		closeTypeRef.current = "";
		lastInteractionTypeRef.current = "";
		const doc = ownerDocument(floatingFocusElement);
		const previouslyFocusedElement = activeElement(doc);
		queueMicrotask(() => {
			const initialFocusValueOrFn = initialFocusRef.current;
			const resolvedInitialFocus = typeof initialFocusValueOrFn === "function" ? initialFocusValueOrFn(openInteractionTypeRef.current || "") : initialFocusValueOrFn;
			if (resolvedInitialFocus === void 0 || resolvedInitialFocus === false) return;
			if (contains(floatingFocusElement, previouslyFocusedElement)) return;
			let focusableElements = null;
			const getDefaultFocusElement = () => {
				if (focusableElements == null) focusableElements = getTabbableContent(floatingFocusElement);
				return focusableElements[0] || floatingFocusElement;
			};
			let elToFocus;
			if (resolvedInitialFocus === true || resolvedInitialFocus === null) elToFocus = getDefaultFocusElement();
			else elToFocus = resolveRef(resolvedInitialFocus);
			elToFocus = elToFocus || getDefaultFocusElement();
			const hadFocusInside = contains(floatingFocusElement, activeElement(doc));
			enqueueFocus(elToFocus, {
				preventScroll: elToFocus === floatingFocusElement,
				shouldFocus() {
					if (!openRef.current) return false;
					if (hadFocusInside) return true;
					const currentActiveElement = activeElement(doc);
					return !(currentActiveElement !== elToFocus && contains(floatingFocusElement, currentActiveElement));
				}
			});
		});
	}, [
		disabled,
		open,
		floatingFocusElement,
		getTabbableContent,
		initialFocusRef,
		openInteractionTypeRef,
		openRef
	]);
	useIsoLayoutEffect(() => {
		if (disabled || !floatingFocusElement) return;
		const doc = ownerDocument(floatingFocusElement);
		const elementFocusedBeforeOpen = activeElement(doc);
		const preferPreviousFocus = openInteractionTypeRef.current == null;
		addPreviouslyFocusedElement(elementFocusedBeforeOpen);
		function onOpenChangeLocal(details) {
			if (!details.open) closeTypeRef.current = getEventType(details.nativeEvent, lastInteractionTypeRef.current);
			if (details.reason === "trigger-hover" && details.nativeEvent.type === "mouseleave") preventReturnFocusRef.current = true;
			if (details.reason !== "outside-press") return;
			if (details.nested) preventReturnFocusRef.current = false;
			else if (isVirtualClick(details.nativeEvent) || isVirtualPointerEvent(details.nativeEvent)) preventReturnFocusRef.current = false;
			else {
				let isPreventScrollSupported = false;
				ownerDocument(floatingFocusElement).createElement("div").focus({ get preventScroll() {
					isPreventScrollSupported = true;
					return false;
				} });
				if (isPreventScrollSupported) preventReturnFocusRef.current = false;
				else preventReturnFocusRef.current = true;
			}
		}
		events.on("openchange", onOpenChangeLocal);
		function getReturnElement(closeType) {
			const returnFocusValueOrFn = returnFocusRef.current;
			let resolvedReturnFocusValue = typeof returnFocusValueOrFn === "function" ? returnFocusValueOrFn(closeType) : returnFocusValueOrFn;
			if (resolvedReturnFocusValue === void 0 || resolvedReturnFocusValue === false) return null;
			if (resolvedReturnFocusValue === null) resolvedReturnFocusValue = true;
			const referenceReturnElement = domReference?.isConnected ? domReference : null;
			const previousReturnElement = elementFocusedBeforeOpen?.isConnected && getNodeName(elementFocusedBeforeOpen) !== "body" ? elementFocusedBeforeOpen : null;
			let defaultReturnElement = preferPreviousFocus ? previousReturnElement || referenceReturnElement : referenceReturnElement || previousReturnElement;
			if (!defaultReturnElement) defaultReturnElement = getPreviouslyFocusedElement() || null;
			if (typeof resolvedReturnFocusValue === "boolean") return defaultReturnElement;
			return resolveRef(resolvedReturnFocusValue) || defaultReturnElement || null;
		}
		return () => {
			events.off("openchange", onOpenChangeLocal);
			const activeEl = activeElement(doc);
			const insideElements = getResolvedInsideElements();
			const isFocusInsideFloatingTree = contains(floating, activeEl) || insideElements.some((element) => element === activeEl || contains(element, activeEl)) || tree && getNodeChildren(tree.nodesRef.current, getNodeId(), false).some((node) => contains(node.context?.elements.floating, activeEl));
			const returnFocusValueOrFn = returnFocusRef.current;
			const closeType = closeTypeRef.current;
			const returnElement = getReturnElement(closeType);
			queueMicrotask(() => {
				const tabbableReturnElement = getFirstTabbableElement(returnElement);
				const hasExplicitReturnFocus = typeof returnFocusValueOrFn !== "boolean";
				if (returnFocusValueOrFn && !preventReturnFocusRef.current && isHTMLElement(tabbableReturnElement) && (!hasExplicitReturnFocus && tabbableReturnElement !== activeEl && activeEl !== doc.body ? isFocusInsideFloatingTree : true)) {
					const focusOptions = { preventScroll: true };
					if (closeType === "keyboard") focusOptions.focusVisible = true;
					tabbableReturnElement.focus(focusOptions);
				}
				preventReturnFocusRef.current = false;
			});
		};
	}, [
		disabled,
		floating,
		floatingFocusElement,
		returnFocusRef,
		openInteractionTypeRef,
		events,
		tree,
		domReference,
		getNodeId,
		getResolvedInsideElements
	]);
	useIsoLayoutEffect(() => {
		if (!webkit || open || !floating) return;
		const activeEl = activeElement(ownerDocument(floating));
		if (!isHTMLElement(activeEl) || !isTypeableElement(activeEl)) return;
		if (contains(floating, activeEl)) activeEl.blur();
	}, [open, floating]);
	useIsoLayoutEffect(() => {
		if (disabled || !portalContext) return;
		portalContext.setFocusManagerState({
			modal,
			closeOnFocusOut,
			open,
			onOpenChange: store.setOpen,
			domReference
		});
		return () => {
			portalContext.setFocusManagerState(null);
		};
	}, [
		disabled,
		portalContext,
		modal,
		open,
		store,
		closeOnFocusOut,
		domReference
	]);
	useIsoLayoutEffect(() => {
		if (disabled || !floatingFocusElement) return;
		handleTabIndex(floatingFocusElement);
		return () => {
			queueMicrotask(clearDisconnectedPreviouslyFocusedElements);
		};
	}, [disabled, floatingFocusElement]);
	const shouldRenderGuards = !disabled && (modal ? !isUntrappedTypeableCombobox : true) && (isInsidePortal || modal);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		shouldRenderGuards && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			"data-type": "inside",
			ref: mergedBeforeGuardRef,
			onFocus: (event) => {
				if (modal) {
					const els = getTabbableContent();
					enqueueFocus(els[els.length - 1]);
				} else if (portalContext?.portalNode) {
					preventReturnFocusRef.current = false;
					if (isOutsideEvent(event, portalContext.portalNode)) getNextTabbable(domReference)?.focus();
					else resolveRef(previousFocusableElement ?? portalContext.beforeOutsideRef)?.focus();
				}
			}
		}),
		children,
		shouldRenderGuards && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			"data-type": "inside",
			ref: mergedAfterGuardRef,
			onFocus: (event) => {
				if (modal) enqueueFocus(getTabbableContent()[0]);
				else if (portalContext?.portalNode) {
					if (closeOnFocusOut) preventReturnFocusRef.current = true;
					if (isOutsideEvent(event, portalContext.portalNode)) getPreviousTabbable(domReference)?.focus();
					else resolveRef(nextFocusableElement ?? portalContext.afterOutsideRef)?.focus();
				}
			}
		})
	] });
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/hooks/useClick.mjs
/**
* Opens or closes the floating element when clicking the reference element.
* @see https://floating-ui.com/docs/useClick
*/
function useClick(context, props = {}) {
	const { enabled = true, event: eventOption = "click", toggle = true, ignoreMouse = false, stickIfOpen = true, touchOpenDelay = 0, reason = triggerPress } = props;
	const store = "rootStore" in context ? context.rootStore : context;
	const dataRef = store.context.dataRef;
	const pointerTypeRef = import_react.useRef(void 0);
	const frame = useAnimationFrame();
	const touchOpenTimeout = useTimeout();
	const reference = import_react.useMemo(() => {
		function setOpenWithTouchDelay(nextOpen, nativeEvent, target, pointerType) {
			const details = createChangeEventDetails(reason, nativeEvent, target);
			if (nextOpen && pointerType === "touch" && touchOpenDelay > 0) touchOpenTimeout.start(touchOpenDelay, () => {
				store.setOpen(true, details);
			});
			else store.setOpen(nextOpen, details);
		}
		function getNextOpen(open, currentTarget, isClickLikeOpenEvent) {
			const openEvent = dataRef.current.openEvent;
			const hasClickedOnInactiveTrigger = store.select("domReferenceElement") !== currentTarget;
			if (open && hasClickedOnInactiveTrigger) return true;
			if (!open) return true;
			if (!toggle) return true;
			if (openEvent && stickIfOpen) return !isClickLikeOpenEvent(openEvent.type);
			return false;
		}
		return {
			onPointerDown(event) {
				pointerTypeRef.current = isMouseLikePointerType(event.pointerType, true) && isVirtualPointerEvent(event.nativeEvent) ? "virtual" : event.pointerType;
			},
			onMouseDown(event) {
				const pointerType = pointerTypeRef.current;
				const nativeEvent = event.nativeEvent;
				const open = store.select("open");
				if (event.button !== 0 || eventOption === "click" || isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
				const nextOpen = getNextOpen(open, event.currentTarget, (openEventType) => openEventType === "click" || openEventType === "mousedown");
				const target = getTarget(nativeEvent);
				if (isTypeableElement(target)) {
					setOpenWithTouchDelay(nextOpen, nativeEvent, target, pointerType);
					return;
				}
				const eventCurrentTarget = event.currentTarget;
				frame.request(() => {
					setOpenWithTouchDelay(nextOpen, nativeEvent, eventCurrentTarget, pointerType);
				});
			},
			onClick(event) {
				if (eventOption === "mousedown-only") return;
				const pointerType = pointerTypeRef.current;
				if (eventOption === "mousedown" && pointerType) {
					pointerTypeRef.current = void 0;
					return;
				}
				if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
				setOpenWithTouchDelay(getNextOpen(store.select("open"), event.currentTarget, (openEventType) => openEventType === "click" || openEventType === "mousedown" || openEventType === "keydown" || openEventType === "keyup"), event.nativeEvent, event.currentTarget, pointerType);
			},
			onKeyDown() {
				pointerTypeRef.current = void 0;
			}
		};
	}, [
		dataRef,
		eventOption,
		ignoreMouse,
		reason,
		store,
		stickIfOpen,
		toggle,
		frame,
		touchOpenTimeout,
		touchOpenDelay
	]);
	return import_react.useMemo(() => enabled ? { reference } : EMPTY_OBJECT, [enabled, reference]);
}
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/hooks/useDismiss.mjs
function alwaysFalse() {
	return false;
}
function normalizeProp(normalizable) {
	return {
		escapeKey: typeof normalizable === "boolean" ? normalizable : normalizable?.escapeKey ?? false,
		outsidePress: typeof normalizable === "boolean" ? normalizable : normalizable?.outsidePress ?? true
	};
}
/**
* Closes the floating element when a dismissal is requested — by default, when
* the user presses the `escape` key or outside of the floating element.
* @see https://floating-ui.com/docs/useDismiss
*/
function useDismiss(context, props = {}) {
	const { enabled = true, escapeKey: escapeKey$1 = true, outsidePress: outsidePressProp = true, outsidePressEvent = "sloppy", referencePress = alwaysFalse, bubbles, externalTree } = props;
	const store = "rootStore" in context ? context.rootStore : context;
	const open = store.useState("open");
	const floatingElement = store.useState("floatingElement");
	const { dataRef } = store.context;
	const tree = useFloatingTree(externalTree);
	const outsidePressFn = useStableCallback(typeof outsidePressProp === "function" ? outsidePressProp : () => false);
	const outsidePress$1 = typeof outsidePressProp === "function" ? outsidePressFn : outsidePressProp;
	const outsidePressEnabled = outsidePress$1 !== false;
	const getOutsidePressEventProp = useStableCallback(() => outsidePressEvent);
	const { escapeKey: escapeKeyBubbles, outsidePress: outsidePressBubbles } = normalizeProp(bubbles);
	const pressStartedInsideRef = import_react.useRef(false);
	const pressStartPreventedRef = import_react.useRef(false);
	const suppressNextOutsideClickRef = import_react.useRef(false);
	const isComposingRef = import_react.useRef(false);
	const currentPointerTypeRef = import_react.useRef("");
	const touchStateRef = import_react.useRef(null);
	const cancelDismissOnEndTimeout = useTimeout();
	const clearInsideReactTreeTimeout = useTimeout();
	const clearInsideReactTree = useStableCallback(() => {
		clearInsideReactTreeTimeout.clear();
		dataRef.current.insideReactTree = false;
	});
	const hasBlockingChild = useStableCallback((bubbleKey) => {
		const nodeId = dataRef.current.floatingContext?.nodeId;
		return (tree ? getNodeChildren(tree.nodesRef.current, nodeId) : []).some((child) => child.context?.open && !child.context.dataRef.current[bubbleKey]);
	});
	const isEventWithinOwnElements = useStableCallback((event) => {
		return isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement"));
	});
	const closeOnReferencePress = useStableCallback((event) => {
		if (!referencePress()) return;
		store.setOpen(false, createChangeEventDetails(triggerPress, event.nativeEvent));
	});
	const closeOnEscapeKeyDown = useStableCallback((event) => {
		if (!open || !enabled || !escapeKey$1 || event.key !== "Escape") return;
		if (isComposingRef.current) return;
		if (!escapeKeyBubbles && hasBlockingChild("__escapeKeyBubbles")) return;
		const native = isReactEvent(event) ? event.nativeEvent : event;
		const eventDetails = createChangeEventDetails(escapeKey, native);
		store.setOpen(false, eventDetails);
		if (!eventDetails.isCanceled) event.preventDefault();
		if (!escapeKeyBubbles && !eventDetails.isPropagationAllowed) event.stopPropagation();
	});
	const markInsideReactTree = useStableCallback(() => {
		dataRef.current.insideReactTree = true;
		clearInsideReactTreeTimeout.start(0, clearInsideReactTree);
	});
	const markPressStartedInsideReactTree = useStableCallback((event) => {
		if (!open || !enabled || event.button !== 0) return;
		const target = getTarget(event.nativeEvent);
		if (!contains(store.select("floatingElement"), target)) return;
		if (!pressStartedInsideRef.current) {
			pressStartedInsideRef.current = true;
			pressStartPreventedRef.current = false;
		}
	});
	const markInsidePressStartPrevented = useStableCallback((event) => {
		if (!open || !enabled) return;
		if (!(event.defaultPrevented || event.nativeEvent.defaultPrevented)) return;
		if (pressStartedInsideRef.current) pressStartPreventedRef.current = true;
	});
	import_react.useEffect(() => {
		if (!open || !enabled) return clearInsideReactTree;
		dataRef.current.__escapeKeyBubbles = escapeKeyBubbles;
		dataRef.current.__outsidePressBubbles = outsidePressBubbles;
		const compositionTimeout = new Timeout();
		const preventedPressSuppressionTimeout = new Timeout();
		function handleCompositionStart() {
			compositionTimeout.clear();
			isComposingRef.current = true;
		}
		function handleCompositionEnd() {
			compositionTimeout.start(webkit ? 5 : 0, () => {
				isComposingRef.current = false;
			});
		}
		function suppressImmediateOutsideClickAfterPreventedStart() {
			suppressNextOutsideClickRef.current = true;
			preventedPressSuppressionTimeout.start(0, () => {
				suppressNextOutsideClickRef.current = false;
			});
		}
		function resetPressStartState() {
			pressStartedInsideRef.current = false;
			pressStartPreventedRef.current = false;
		}
		function getOutsidePressEvent() {
			const type = currentPointerTypeRef.current;
			const computedType = type === "pen" || !type ? "mouse" : type;
			const outsidePressEventValue = getOutsidePressEventProp();
			const resolved = typeof outsidePressEventValue === "function" ? outsidePressEventValue() : outsidePressEventValue;
			if (typeof resolved === "string") return resolved;
			return resolved[computedType];
		}
		function shouldIgnoreEvent(event) {
			const computedOutsidePressEvent = getOutsidePressEvent();
			return computedOutsidePressEvent === "intentional" && event.type !== "click" || computedOutsidePressEvent === "sloppy" && event.type === "click";
		}
		function isEventWithinFloatingTree(event) {
			const nodeId = dataRef.current.floatingContext?.nodeId;
			const targetIsInsideChildren = tree && getNodeChildren(tree.nodesRef.current, nodeId).some((node) => isEventTargetWithin(event, node.context?.elements.floating));
			return isEventWithinOwnElements(event) || targetIsInsideChildren;
		}
		function closeOnPressOutside(event) {
			if (shouldIgnoreEvent(event)) {
				if (event.type !== "click" && !isEventWithinOwnElements(event)) {
					preventedPressSuppressionTimeout.clear();
					suppressNextOutsideClickRef.current = false;
				}
				clearInsideReactTree();
				return;
			}
			if (dataRef.current.insideReactTree) {
				clearInsideReactTree();
				return;
			}
			const target = getTarget(event);
			const inertSelector = `[${createAttribute("inert")}]`;
			const targetRoot = isElement(target) ? target.getRootNode() : null;
			const markers = Array.from((isShadowRoot(targetRoot) ? targetRoot : ownerDocument(store.select("floatingElement"))).querySelectorAll(inertSelector));
			const triggers = store.context.triggerElements;
			if (target && (triggers.hasElement(target) || triggers.hasMatchingElement((trigger) => contains(trigger, target)))) return;
			let targetRootAncestor = isElement(target) ? target : null;
			while (targetRootAncestor && !isLastTraversableNode(targetRootAncestor)) {
				const nextParent = getParentNode(targetRootAncestor);
				if (isLastTraversableNode(nextParent) || !isElement(nextParent)) break;
				targetRootAncestor = nextParent;
			}
			if (markers.length && isElement(target) && !isRootElement(target) && !contains(target, store.select("floatingElement")) && markers.every((marker) => !contains(targetRootAncestor, marker))) return;
			if (isHTMLElement(target) && !("touches" in event)) {
				const lastTraversableNode = isLastTraversableNode(target);
				const style = getComputedStyle(target);
				const scrollRe = /auto|scroll/;
				const isScrollableX = lastTraversableNode || scrollRe.test(style.overflowX);
				const isScrollableY = lastTraversableNode || scrollRe.test(style.overflowY);
				const canScrollX = isScrollableX && target.clientWidth > 0 && target.scrollWidth > target.clientWidth;
				const canScrollY = isScrollableY && target.clientHeight > 0 && target.scrollHeight > target.clientHeight;
				const isRTL = style.direction === "rtl";
				const pressedVerticalScrollbar = canScrollY && (isRTL ? event.offsetX <= target.offsetWidth - target.clientWidth : event.offsetX > target.clientWidth);
				const pressedHorizontalScrollbar = canScrollX && event.offsetY > target.clientHeight;
				if (pressedVerticalScrollbar || pressedHorizontalScrollbar) return;
			}
			if (isEventWithinFloatingTree(event)) return;
			if (getOutsidePressEvent() === "intentional" && suppressNextOutsideClickRef.current) {
				preventedPressSuppressionTimeout.clear();
				suppressNextOutsideClickRef.current = false;
				return;
			}
			if (typeof outsidePress$1 === "function" && !outsidePress$1(event)) return;
			if (hasBlockingChild("__outsidePressBubbles")) return;
			store.setOpen(false, createChangeEventDetails(outsidePress, event));
			clearInsideReactTree();
		}
		function handlePointerDown(event) {
			if (getOutsidePressEvent() !== "sloppy" || event.pointerType === "touch" || !store.select("open") || !enabled || isEventWithinOwnElements(event)) return;
			closeOnPressOutside(event);
		}
		function handleTouchStart(event) {
			if (getOutsidePressEvent() !== "sloppy" || !store.select("open") || !enabled || isEventWithinOwnElements(event)) return;
			const touch = event.touches[0];
			if (touch) {
				touchStateRef.current = {
					startTime: Date.now(),
					startX: touch.clientX,
					startY: touch.clientY,
					dismissOnTouchEnd: false,
					dismissOnMouseDown: true
				};
				cancelDismissOnEndTimeout.start(1e3, () => {
					if (touchStateRef.current) {
						touchStateRef.current.dismissOnTouchEnd = false;
						touchStateRef.current.dismissOnMouseDown = false;
					}
				});
			}
		}
		function addTargetEventListenerOnce(event, listener) {
			const target = getTarget(event);
			if (!target) return;
			const unsubscribe = addEventListener(target, event.type, () => {
				listener(event);
				unsubscribe();
			});
		}
		function handleTouchStartCapture(event) {
			currentPointerTypeRef.current = "touch";
			addTargetEventListenerOnce(event, handleTouchStart);
		}
		function closeOnPressOutsideCapture(event) {
			cancelDismissOnEndTimeout.clear();
			if (event.type === "pointerdown") currentPointerTypeRef.current = event.pointerType;
			if (event.type === "mousedown" && touchStateRef.current && !touchStateRef.current.dismissOnMouseDown) return;
			addTargetEventListenerOnce(event, (targetEvent) => {
				if (targetEvent.type === "pointerdown") handlePointerDown(targetEvent);
				else closeOnPressOutside(targetEvent);
			});
		}
		function handlePressEndCapture(event) {
			if (!pressStartedInsideRef.current) return;
			const pressStartedInsideDefaultPrevented = pressStartPreventedRef.current;
			resetPressStartState();
			if (getOutsidePressEvent() !== "intentional") return;
			if (event.type === "pointercancel") {
				if (pressStartedInsideDefaultPrevented) suppressImmediateOutsideClickAfterPreventedStart();
				return;
			}
			if (isEventWithinFloatingTree(event)) return;
			if (pressStartedInsideDefaultPrevented) {
				suppressImmediateOutsideClickAfterPreventedStart();
				return;
			}
			if (typeof outsidePress$1 === "function" && !outsidePress$1(event)) return;
			preventedPressSuppressionTimeout.clear();
			suppressNextOutsideClickRef.current = true;
			clearInsideReactTree();
		}
		function handleTouchMove(event) {
			if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventWithinOwnElements(event)) return;
			const touch = event.touches[0];
			if (!touch) return;
			const deltaX = Math.abs(touch.clientX - touchStateRef.current.startX);
			const deltaY = Math.abs(touch.clientY - touchStateRef.current.startY);
			const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
			if (distance > 5) touchStateRef.current.dismissOnTouchEnd = true;
			if (distance > 10) {
				closeOnPressOutside(event);
				cancelDismissOnEndTimeout.clear();
				touchStateRef.current = null;
			}
		}
		function handleTouchMoveCapture(event) {
			addTargetEventListenerOnce(event, handleTouchMove);
		}
		function handleTouchEnd(event) {
			if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventWithinOwnElements(event)) return;
			if (touchStateRef.current.dismissOnTouchEnd) closeOnPressOutside(event);
			cancelDismissOnEndTimeout.clear();
			touchStateRef.current = null;
		}
		function handleTouchEndCapture(event) {
			addTargetEventListenerOnce(event, handleTouchEnd);
		}
		const doc = ownerDocument(floatingElement);
		const unsubscribe = mergeCleanups(escapeKey$1 && mergeCleanups(addEventListener(doc, "keydown", closeOnEscapeKeyDown), addEventListener(doc, "compositionstart", handleCompositionStart), addEventListener(doc, "compositionend", handleCompositionEnd)), outsidePressEnabled && mergeCleanups(addEventListener(doc, "click", closeOnPressOutsideCapture, true), addEventListener(doc, "pointerdown", closeOnPressOutsideCapture, true), addEventListener(doc, "pointerup", handlePressEndCapture, true), addEventListener(doc, "pointercancel", handlePressEndCapture, true), addEventListener(doc, "mousedown", closeOnPressOutsideCapture, true), addEventListener(doc, "mouseup", handlePressEndCapture, true), addEventListener(doc, "touchstart", handleTouchStartCapture, true), addEventListener(doc, "touchmove", handleTouchMoveCapture, true), addEventListener(doc, "touchend", handleTouchEndCapture, true)));
		return () => {
			unsubscribe();
			compositionTimeout.clear();
			preventedPressSuppressionTimeout.clear();
			resetPressStartState();
			suppressNextOutsideClickRef.current = false;
			clearInsideReactTree();
		};
	}, [
		dataRef,
		floatingElement,
		escapeKey$1,
		outsidePressEnabled,
		outsidePress$1,
		open,
		enabled,
		escapeKeyBubbles,
		outsidePressBubbles,
		closeOnEscapeKeyDown,
		clearInsideReactTree,
		getOutsidePressEventProp,
		hasBlockingChild,
		isEventWithinOwnElements,
		tree,
		store,
		cancelDismissOnEndTimeout
	]);
	const reference = import_react.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		onPointerDown: closeOnReferencePress,
		onClick: closeOnReferencePress
	}), [closeOnEscapeKeyDown, closeOnReferencePress]);
	const floating = import_react.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		onPointerDown: markInsidePressStartPrevented,
		onMouseDown: markInsidePressStartPrevented,
		onClickCapture: markInsideReactTree,
		onMouseDownCapture(event) {
			markInsideReactTree();
			markPressStartedInsideReactTree(event);
		},
		onPointerDownCapture(event) {
			markInsideReactTree();
			markPressStartedInsideReactTree(event);
		},
		onMouseUpCapture: markInsideReactTree,
		onTouchEndCapture: markInsideReactTree,
		onTouchMoveCapture: markInsideReactTree
	}), [
		closeOnEscapeKeyDown,
		markInsideReactTree,
		markPressStartedInsideReactTree,
		markInsidePressStartPrevented
	]);
	return import_react.useMemo(() => enabled ? {
		reference,
		floating,
		trigger: reference
	} : {}, [
		enabled,
		reference,
		floating
	]);
}
//#endregion
//#region node_modules/@base-ui/react/utils/popups/popupHandle.mjs
/**
* Minimal store contract exposed by popup handles to detached triggers.
*
* Detached triggers read `store` during render and subscribe to be notified when the handle switches
* between its fallback store and a root's live store.
*
* @template HandleStore Store shape exposed to detached triggers.
*/
/**
* Store shape holding a trigger registry, required by `BasePopupHandle.openByTrigger` to resolve a
* trigger element by id on both the attached root's store and the fallback store.
*/
/**
* Store shape required by `BasePopupHandle.openByTrigger`/`closePopup` to drive open/close state.
* Only the root-owned `Store` needs this — the `HandleStore` view exposed to detached triggers may
* omit `setOpen` entirely (as Dialog and PreviewCard's do) since it is never called while detached.
*/
/**
* Shared implementation for popup handles that coordinate detached triggers with a mounted root.
*
* Subclasses provide the component-specific imperative methods, while this base class owns the
* fallback store, root store attachment stack, subscriber notifications, and development warning for
* overlapping roots.
*
* @template HandleStore Store shape exposed to detached triggers.
* @template Store Root-owned store attached by the component root.
*/
var BasePopupHandle = class {
	/**
	* Stores of every root currently using this handle, in attach order. A handle is meant to be used
	* by a single mounted root, but roots can transiently overlap (e.g. during an animated route
	* transition), so this stack lets `attachStore`'s cleanup restore the previous root instead of
	* leaving a still-mounted root uncontrollable when a newer overlapping root detaches first.
	*/
	attachedStores = [];
	/**
	* Store of the root that currently controls the handle: the most recently attached one still
	* mounted, or `null` when no root is attached. Imperative methods are no-ops while this is `null`.
	*/
	attachedStoreValue = null;
	/**
	* Listeners notified when `attachedStore` changes, so detached triggers can follow the store pointer.
	*/
	storeListeners = /* @__PURE__ */ new Set();
	/**
	* Creates a handle backed by the store used while no root is attached.
	*
	* @param fallbackStore Inert, closed store handed to detached triggers while no root is attached,
	* so they can render and register without a mounted root. Triggers register into whichever store
	* `store` currently resolves to, so while detached they live in this store's trigger map and
	* migrate themselves to the root's store (and back) as it attaches/detaches.
	* @param componentName Component name used to prefix dev warnings, e.g. `'Menu'` produces
	* `MenuHandle.open()` in warning text.
	* @param throwOnMissingTrigger Whether `open(triggerId)` throws when no trigger with that id is
	* registered. Anchored popups (Menu, Popover, Tooltip, PreviewCard) need a trigger to anchor to,
	* so they throw; Dialog is not anchored and instead opens unassociated with a dev warning.
	*/
	constructor(fallbackStore, componentName, throwOnMissingTrigger = true) {
		this.fallbackStore = fallbackStore;
		this.componentName = componentName;
		this.throwOnMissingTrigger = throwOnMissingTrigger;
	}
	get attachedStore() {
		return this.attachedStoreValue;
	}
	/**
	* Store that detached triggers read from: the attached root's store, or an inert fallback store
	* used while no root is attached.
	* @internal
	*/
	get store() {
		return this.attachedStoreValue ?? this.fallbackStore;
	}
	/**
	* Stable fallback store used for server rendering and hydration. Root stores cannot be recorded on
	* the handle during render because a handle can be shared by concurrent server-rendered requests.
	* @internal
	*/
	get serverStore() {
		return this.fallbackStore;
	}
	/**
	* Subscribes to changes of the attached store pointer so detached triggers re-render and re-bind
	* when a root attaches or detaches. Returns a function that removes the listener.
	* @internal
	*/
	subscribeStore(listener) {
		this.storeListeners.add(listener);
		return () => {
			this.storeListeners.delete(listener);
		};
	}
	/**
	* Points the handle at a root's store and notifies subscribers so detached triggers re-render and
	* re-register into it (their registration ref re-fires on the store-pointer change). Returns a
	* cleanup function that detaches the store again.
	* @internal
	*/
	attachStore(newStore) {
		this.attachedStores.push(newStore);
		this.setActiveStore(newStore);
		if (this.attachedStores.length > 1) {
			const dev = this;
			(dev.overlapWarningFrame ??= AnimationFrame.create()).request(() => {
				if (this.attachedStores.length > 1) console.warn("Base UI: A handle is attached to more than one mounted root at the same time. The most recently mounted root takes over and the previous one stops being controlled by the handle. A handle should be used by a single root that stays mounted for the lifetime of the handle.");
			});
		}
		return () => {
			const index = this.attachedStores.lastIndexOf(newStore);
			if (index !== -1) this.attachedStores.splice(index, 1);
			this.setActiveStore(this.attachedStores[this.attachedStores.length - 1] ?? null);
		};
	}
	/**
	* Sets the store that currently controls the handle and notifies subscribers when it changes, so
	* detached triggers re-render and migrate their registration to the new store.
	*/
	setActiveStore(store) {
		if (this.attachedStoreValue !== store) {
			this.attachedStoreValue = store;
			this.storeListeners.forEach((listener) => {
				listener();
			});
		}
	}
	/**
	* Opens the attached root's store and associates it with the trigger with the given id, or a
	* no-op (with a dev warning) while no root is attached. Shared by every concrete handle's public
	* `open()` method, which only narrows the parameter type.
	*
	* When a trigger id is given but no matching trigger is registered, anchored popups throw (see
	* `throwOnMissingTrigger`); Dialog opens unassociated with a dev warning instead.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the popup, or `null`/`undefined` to open
	* without associating any trigger.
	*/
	openByTrigger(triggerId) {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn(`Base UI: ${this.componentName}Handle.open() was called while no root using this handle is mounted. The call was ignored; mount a root with this handle before opening it imperatively.`);
			return;
		}
		let triggerElement;
		if (triggerId) {
			for (let i = this.attachedStores.length - 1; i >= 0 && !triggerElement; i -= 1) triggerElement = this.attachedStores[i].context.triggerElements.getById(triggerId);
			triggerElement ??= this.fallbackStore.context.triggerElements.getById(triggerId);
		}
		if (triggerId && !triggerElement) {
			if (this.throwOnMissingTrigger) throw new Error(`Base UI: ${this.componentName}Handle.open() was called with the trigger id "${triggerId}", but no matching trigger is registered with this handle. An anchored popup cannot open without a trigger to anchor to. Pass the id of a mounted ${this.componentName}.Trigger that has this handle set on its "handle" prop.`);
			console.warn(`Base UI: ${this.componentName}Handle.open: No trigger found with id "${triggerId}". The popup will open, but the trigger will not be associated with it.`);
		}
		attachedStore.setOpen(true, createChangeEventDetails(imperativeAction, void 0, triggerElement));
	}
	/**
	* Closes the popup by setting the attached root's store to closed, or a no-op (with a dev warning)
	* while no root is attached. Shared by every concrete handle's public `close()` method.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	closePopup() {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn(`Base UI: ${this.componentName}Handle.close() was called while no root using this handle is mounted. The call was ignored.`);
			return;
		}
		attachedStore.setOpen(false, createChangeEventDetails(imperativeAction));
	}
};
//#endregion
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
/**
* @license React
* use-sync-external-store-shim.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
			var value = getSnapshot();
			if (!didWarnUncachedGetSnapshot) {
				var cachedValue = getSnapshot();
				objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
			}
			cachedValue = useState({ inst: {
				value,
				getSnapshot
			} });
			var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/use-sync-external-store/shim/index.js
var require_shim = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_use_sync_external_store_shim_development();
}));
//#endregion
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js
/**
* @license React
* use-sync-external-store-shim/with-selector.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_with_selector_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), shim = require_shim(), objectIs = "function" === typeof Object.is ? Object.is : is, useSyncExternalStore = shim.useSyncExternalStore, useRef = React.useRef, useEffect = React.useEffect, useMemo = React.useMemo, useDebugValue = React.useDebugValue;
		exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
			var instRef = useRef(null);
			if (null === instRef.current) {
				var inst = {
					hasValue: !1,
					value: null
				};
				instRef.current = inst;
			} else inst = instRef.current;
			instRef = useMemo(function() {
				function memoizedSelector(nextSnapshot) {
					if (!hasMemo) {
						hasMemo = !0;
						memoizedSnapshot = nextSnapshot;
						nextSnapshot = selector(nextSnapshot);
						if (void 0 !== isEqual && inst.hasValue) {
							var currentSelection = inst.value;
							if (isEqual(currentSelection, nextSnapshot)) return memoizedSelection = currentSelection;
						}
						return memoizedSelection = nextSnapshot;
					}
					currentSelection = memoizedSelection;
					if (objectIs(memoizedSnapshot, nextSnapshot)) return currentSelection;
					var nextSelection = selector(nextSnapshot);
					if (void 0 !== isEqual && isEqual(currentSelection, nextSelection)) return memoizedSnapshot = nextSnapshot, currentSelection;
					memoizedSnapshot = nextSnapshot;
					return memoizedSelection = nextSelection;
				}
				var hasMemo = !1, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
				return [function() {
					return memoizedSelector(getSnapshot());
				}, null === maybeGetServerSnapshot ? void 0 : function() {
					return memoizedSelector(maybeGetServerSnapshot());
				}];
			}, [
				getSnapshot,
				getServerSnapshot,
				selector,
				isEqual
			]);
			var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
			useEffect(function() {
				inst.hasValue = !0;
				inst.value = value;
			}, [value]);
			useDebugValue(value);
			return value;
		};
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/use-sync-external-store/shim/with-selector.js
var require_with_selector = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_with_selector_development();
}));
//#endregion
//#region node_modules/@base-ui/utils/fastHooks.mjs
var hooks = [];
var currentInstance = void 0;
function getInstance() {
	return currentInstance;
}
function register(hook) {
	hooks.push(hook);
}
//#endregion
//#region node_modules/@base-ui/utils/store/useStore.mjs
var import_shim = require_shim();
var import_with_selector = require_with_selector();
var useStoreImplementation = isReactVersionAtLeast(19) ? useStoreFast : useStoreLegacy;
function useStore(store, selector, a1, a2, a3) {
	return useStoreImplementation(store, selector, a1, a2, a3);
}
function useStoreR19(store, selector, a1, a2, a3) {
	const getSelection = import_react.useCallback(() => selector(store.getSnapshot(), a1, a2, a3), [
		store,
		selector,
		a1,
		a2,
		a3
	]);
	return (0, import_shim.useSyncExternalStore)(store.subscribe, getSelection, getSelection);
}
register({
	before(instance) {
		instance.syncIndex = 0;
		if (!instance.didInitialize) {
			instance.syncTick = 1;
			instance.syncHooks = [];
			instance.didChangeStore = true;
			instance.getSnapshot = () => {
				let didChange = false;
				for (let i = 0; i < instance.syncHooks.length; i += 1) {
					const hook = instance.syncHooks[i];
					const value = hook.selector(hook.store.state, hook.a1, hook.a2, hook.a3);
					if (!Object.is(hook.value, value)) {
						didChange = true;
						hook.value = value;
					}
				}
				if (didChange) instance.syncTick += 1;
				return instance.syncTick;
			};
		}
	},
	after(instance) {
		if (instance.syncHooks.length > 0) {
			if (instance.didChangeStore) {
				instance.didChangeStore = false;
				instance.subscribe = (onStoreChange) => {
					const stores = /* @__PURE__ */ new Set();
					for (const hook of instance.syncHooks) stores.add(hook.store);
					const unsubscribes = [];
					for (const store of stores) unsubscribes.push(store.subscribe(onStoreChange));
					return () => {
						for (const unsubscribe of unsubscribes) unsubscribe();
					};
				};
			}
			(0, import_shim.useSyncExternalStore)(instance.subscribe, instance.getSnapshot, instance.getSnapshot);
		}
	}
});
function useStoreFast(store, selector, a1, a2, a3) {
	const instance = getInstance();
	if (!instance) return useStoreR19(store, selector, a1, a2, a3);
	const index = instance.syncIndex;
	instance.syncIndex += 1;
	let hook;
	if (!instance.didInitialize) {
		hook = {
			store,
			selector,
			a1,
			a2,
			a3,
			value: selector(store.getSnapshot(), a1, a2, a3)
		};
		instance.syncHooks.push(hook);
	} else {
		hook = instance.syncHooks[index];
		if (hook.store !== store || hook.selector !== selector || !Object.is(hook.a1, a1) || !Object.is(hook.a2, a2) || !Object.is(hook.a3, a3)) {
			if (hook.store !== store) instance.didChangeStore = true;
			hook.store = store;
			hook.selector = selector;
			hook.a1 = a1;
			hook.a2 = a2;
			hook.a3 = a3;
			hook.value = selector(store.getSnapshot(), a1, a2, a3);
		}
	}
	return hook.value;
}
function useStoreLegacy(store, selector, a1, a2, a3) {
	return (0, import_with_selector.useSyncExternalStoreWithSelector)(store.subscribe, store.getSnapshot, store.getSnapshot, (state) => selector(state, a1, a2, a3));
}
//#endregion
//#region node_modules/@base-ui/utils/store/Store.mjs
/**
* A data store implementation that allows subscribing to state changes and updating the state.
* It uses an observer pattern to notify subscribers when the state changes.
*/
var Store = class {
	/**
	* The current state of the store.
	* This property is updated immediately when the state changes as a result of calling {@link setState}, {@link update}, or {@link set}.
	* To subscribe to state changes, use the {@link useState} method. The value returned by {@link useState} is updated after the component renders (similarly to React's useState).
	* The values can be used directly (to avoid subscribing to the store) in effects or event handlers.
	*
	* Do not modify properties in state directly. Instead, use the provided methods to ensure proper state management and listener notification.
	*/
	constructor(state) {
		this.state = state;
		this.listeners = /* @__PURE__ */ new Set();
		this.updateTick = 0;
	}
	/**
	* Registers a listener that will be called whenever the store's state changes.
	*
	* @param fn The listener function to be called on state changes.
	* @returns A function to unsubscribe the listener.
	*/
	subscribe = (fn) => {
		this.listeners.add(fn);
		return () => {
			this.listeners.delete(fn);
		};
	};
	/**
	* Returns the current state of the store.
	*/
	getSnapshot = () => {
		return this.state;
	};
	/**
	* Updates the entire store's state and notifies all registered listeners.
	*
	* @param newState The new state to set for the store.
	*/
	setState(newState) {
		if (this.state === newState) return;
		this.state = newState;
		this.updateTick += 1;
		const currentTick = this.updateTick;
		for (const listener of this.listeners) {
			if (currentTick !== this.updateTick) return;
			listener(newState);
		}
	}
	/**
	* Merges the provided changes into the current state and notifies listeners if there are changes.
	*
	* @param changes An object containing the changes to apply to the current state.
	*/
	update(changes) {
		for (const key in changes) if (!Object.is(this.state[key], changes[key])) {
			this.setState({
				...this.state,
				...changes
			});
			return;
		}
	}
	/**
	* Sets a specific key in the store's state to a new value and notifies listeners if the value has changed.
	*
	* @param key The key in the store's state to update.
	* @param value The new value to set for the specified key.
	*/
	set(key, value) {
		if (!Object.is(this.state[key], value)) this.setState({
			...this.state,
			[key]: value
		});
	}
	/**
	* Gives the state a new reference and updates all registered listeners.
	*/
	notifyAll() {
		const newState = { ...this.state };
		this.setState(newState);
	}
	use(selector, a1, a2, a3) {
		return useStore(this, selector, a1, a2, a3);
	}
};
//#endregion
//#region node_modules/@base-ui/utils/store/ReactStore.mjs
/**
* A Store that supports controlled state keys, non-reactive values and provides utility methods for React.
*/
var ReactStore = class extends Store {
	/**
	* Creates a new ReactStore instance.
	*
	* @param state Initial state of the store.
	* @param context Non-reactive context values.
	* @param selectors Optional selectors for use with `useState`.
	*/
	constructor(state, context = {}, selectors) {
		super(state);
		this.context = context;
		this.selectors = selectors;
	}
	/**
	* Non-reactive values such as refs, callbacks, etc.
	*/
	/**
	* Synchronizes a single external value into the store.
	*
	* Note that the while the value in `state` is updated immediately, the value returned
	* by `useState` is updated before the next render (similarly to React's `useState`).
	*/
	useSyncedValue(key, value) {
		import_react.useDebugValue(key);
		const store = this;
		useIsoLayoutEffect(() => {
			if (store.state[key] !== value) store.set(key, value);
		}, [
			store,
			key,
			value
		]);
	}
	/**
	* Synchronizes a single external value into the store and
	* cleans it up (sets to `undefined`) on unmount.
	*
	* Note that the while the value in `state` is updated immediately, the value returned
	* by `useState` is updated before the next render (similarly to React's `useState`).
	*/
	useSyncedValueWithCleanup(key, value) {
		const store = this;
		useIsoLayoutEffect(() => {
			if (store.state[key] !== value) store.set(key, value);
			return () => {
				store.set(key, void 0);
			};
		}, [
			store,
			key,
			value
		]);
	}
	/**
	* Synchronizes multiple external values into the store.
	*
	* Note that the while the values in `state` are updated immediately, the values returned
	* by `useState` are updated before the next render (similarly to React's `useState`).
	*/
	useSyncedValues(statePart) {
		const store = this;
		{
			import_react.useDebugValue(statePart, (p) => Object.keys(p));
			const keys = import_react.useRef(Object.keys(statePart)).current;
			const nextKeys = Object.keys(statePart);
			if (keys.length !== nextKeys.length || keys.some((key, index) => key !== nextKeys[index])) console.error("ReactStore.useSyncedValues expects the same prop keys on every render. Keys should be stable.");
		}
		const dependencies = Object.values(statePart);
		useIsoLayoutEffect(() => {
			store.update(statePart);
		}, [store, ...dependencies]);
	}
	/**
	* Registers a controllable prop pair (`controlled`, `defaultValue`) for a specific key. If `controlled`
	* is non-undefined, the store's state at `key` is updated to match `controlled`.
	*/
	useControlledProp(key, controlled) {
		import_react.useDebugValue(key);
		const store = this;
		const isControlled = controlled !== void 0;
		useIsoLayoutEffect(() => {
			if (isControlled && !Object.is(store.state[key], controlled)) store.setState({
				...store.state,
				[key]: controlled
			});
		}, [
			store,
			key,
			controlled,
			isControlled
		]);
		{
			const cache = this.controlledValues ??= /* @__PURE__ */ new Map();
			if (!cache.has(key)) cache.set(key, isControlled);
			const previouslyControlled = cache.get(key);
			if (previouslyControlled !== void 0 && previouslyControlled !== isControlled) console.error(`A component is changing the ${isControlled ? "" : "un"}controlled state of ${key.toString()} to be ${isControlled ? "un" : ""}controlled. Elements should not switch from uncontrolled to controlled (or vice versa).`);
		}
	}
	/** Gets the current value from the store using a selector with the provided key.
	*
	* @param key Key of the selector to use.
	*/
	select(key, a1, a2, a3) {
		const selector = this.selectors[key];
		return selector(this.state, a1, a2, a3);
	}
	/**
	* Returns a value from the store's state using a selector function.
	* Used to subscribe to specific parts of the state.
	* This methods causes a rerender whenever the selected state changes.
	*
	* @param key Key of the selector to use.
	*/
	useState(key, a1, a2, a3) {
		import_react.useDebugValue(key);
		return useStore(this, this.selectors[key], a1, a2, a3);
	}
	/**
	* Wraps a function with `useStableCallback` to ensure it has a stable reference
	* and assigns it to the context.
	*
	* @param key Key of the event callback. Must be a function in the context.
	* @param fn Function to assign.
	*/
	useContextCallback(key, fn) {
		import_react.useDebugValue(key);
		const stableFunction = useStableCallback(fn ?? NOOP);
		this.context[key] = stableFunction;
	}
	/**
	* Returns a stable setter function for a specific key in the store's state.
	* It's commonly used to pass as a ref callback to React elements.
	*
	* @param key Key of the state to set.
	*/
	useStateSetter(key) {
		const ref = import_react.useRef(void 0);
		if (ref.current === void 0) ref.current = (value) => {
			this.set(key, value);
		};
		return ref.current;
	}
	/**
	* Observes changes derived from the store's selectors and calls the listener when the selected value changes.
	*
	* @param key Key of the selector to observe.
	* @param listener Listener function called when the selector result changes.
	*/
	observe(selector, listener) {
		let selectFn;
		if (typeof selector === "function") selectFn = selector;
		else selectFn = this.selectors[selector];
		let prevValue = selectFn(this.state);
		listener(prevValue, prevValue, this);
		return this.subscribe((nextState) => {
			const nextValue = selectFn(nextState);
			if (!Object.is(prevValue, nextValue)) {
				const oldValue = prevValue;
				prevValue = nextValue;
				listener(nextValue, oldValue, this);
			}
		});
	}
};
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/components/FloatingRootStore.mjs
var selectors$1 = {
	open: (state) => state.open,
	transitionStatus: (state) => state.transitionStatus,
	domReferenceElement: (state) => state.domReferenceElement,
	referenceElement: (state) => state.positionReference ?? state.referenceElement,
	floatingElement: (state) => state.floatingElement,
	floatingId: (state) => state.floatingId
};
var FloatingRootStore = class extends ReactStore {
	constructor(options) {
		const { syncOnly, nested, onOpenChange, triggerElements, ...initialState } = options;
		super({
			...initialState,
			positionReference: initialState.referenceElement,
			domReferenceElement: initialState.referenceElement
		}, {
			onOpenChange,
			dataRef: { current: {} },
			events: createEventEmitter(),
			nested,
			triggerElements
		}, selectors$1);
		this.syncOnly = syncOnly;
	}
	/**
	* Syncs the event used by hover logic to distinguish hover-open from click-like interaction.
	*/
	syncOpenEvent = (newOpen, event) => {
		if (!newOpen || !this.state.open || event != null && isClickLikeEvent(event)) this.context.dataRef.current.openEvent = newOpen ? event : void 0;
	};
	/**
	* Runs the root-owned side effects for an open state change.
	*/
	dispatchOpenChange = (newOpen, eventDetails) => {
		this.syncOpenEvent(newOpen, eventDetails.event);
		const details = {
			open: newOpen,
			reason: eventDetails.reason,
			nativeEvent: eventDetails.event,
			nested: this.context.nested,
			triggerElement: eventDetails.trigger
		};
		this.context.events.emit("openchange", details);
	};
	/**
	* Emits the `openchange` event through the internal event emitter and calls the `onOpenChange` handler with the provided arguments.
	*
	* @param newOpen The new open state.
	* @param eventDetails Details about the event that triggered the open state change.
	*/
	setOpen = (newOpen, eventDetails) => {
		if (this.syncOnly) {
			this.context.onOpenChange?.(newOpen, eventDetails);
			return;
		}
		this.dispatchOpenChange(newOpen, eventDetails);
		this.context.onOpenChange?.(newOpen, eventDetails);
	};
};
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/hooks/useSyncedFloatingRootContext.mjs
/**
* Keeps a FloatingRootStore in sync with the provided PopupStore.
* Uses the provided FloatingRootStore when one exists, otherwise creates one once and updates it on every render.
*/
function useSyncedFloatingRootContext(options) {
	const { popupStore, treatPopupAsFloatingElement = false, floatingRootContext: floatingRootContextProp, floatingId, nested, onOpenChange } = options;
	const open = popupStore.useState("open");
	const referenceElement = popupStore.useState("activeTriggerElement");
	const floatingElement = popupStore.useState(treatPopupAsFloatingElement ? "popupElement" : "positionerElement");
	const triggerElements = popupStore.context.triggerElements;
	const handleOpenChange = onOpenChange;
	const internalStoreRef = import_react.useRef(null);
	if (floatingRootContextProp === void 0 && internalStoreRef.current === null) internalStoreRef.current = new FloatingRootStore({
		open,
		transitionStatus: void 0,
		referenceElement,
		floatingElement,
		triggerElements,
		onOpenChange: handleOpenChange,
		floatingId,
		syncOnly: true,
		nested
	});
	const store = floatingRootContextProp ?? internalStoreRef.current;
	popupStore.useSyncedValue("floatingId", floatingId);
	useIsoLayoutEffect(() => {
		const valuesToSync = {
			open,
			floatingId,
			referenceElement,
			floatingElement
		};
		if (isElement(referenceElement)) valuesToSync.domReferenceElement = referenceElement;
		if (store.state.positionReference === store.state.referenceElement) valuesToSync.positionReference = referenceElement;
		store.update(valuesToSync);
	}, [
		open,
		floatingId,
		referenceElement,
		floatingElement,
		store
	]);
	store.context.onOpenChange = handleOpenChange;
	store.context.nested = nested;
	return store;
}
//#endregion
//#region node_modules/@base-ui/react/utils/popups/popupStoreUtils.mjs
var FOCUSABLE_POPUP_PROPS = {
	tabIndex: -1,
	[FOCUSABLE_ATTRIBUTE]: ""
};
/**
* Returns the default `initialFocus` resolver for a popup. When opened by touch it focuses the
* popup element itself to prevent the virtual keyboard from opening (required for Android
* specifically; iOS handles this automatically). Otherwise it falls back to the default behavior.
*/
function createDefaultInitialFocus(popupRef) {
	return (interactionType) => interactionType === "touch" ? popupRef.current : true;
}
/**
* The subset of a popup handle that a Root needs to bind its store to. Both the real handle classes
* and any test double satisfy it.
*/
/**
* Creates and owns a popup store on behalf of a Root part. The store is created exactly once, with
* controlled props and root state synced separately after creation. Sets up the synced floating
* root context and returns the store.
*
* @param createStore Factory that builds the store. Called exactly once, receiving the floating id
* and whether the popup is nested inside another floating element, both resolved on the first render.
* @param treatPopupAsFloatingElement Whether the popup element is passed to Floating UI as the
* floating element instead of the default positioner.
*/
function usePopupRootStore(createStore, treatPopupAsFloatingElement = false) {
	const floatingId = useId();
	const nested = useFloatingParentNodeId() != null;
	const store = useRefWithInit(() => createStore(floatingId, nested)).current;
	useSyncedFloatingRootContext({
		popupStore: store,
		treatPopupAsFloatingElement,
		floatingRootContext: store.state.floatingRootContext,
		floatingId,
		nested,
		onOpenChange: store.setOpen
	});
	return store;
}
/**
* Attaches a Root's store to a handle for this component's committed lifetime. Popup Roots render
* it before their interactions and user children so its layout effect runs before descendant layout
* effects. This lets descendants call the handle during the Root's initial commit without attaching
* during render, which would leak suspended or abandoned stores. Store subscribers are notified by
* `attachStore` in this ordinary layout phase, where React permits synchronous updates.
*
* Popup Roots must render this component only when a handle is present so handle-less Roots avoid
* mounting an extra fiber and layout effect.
*/
function PopupHandleAttachment({ handle, store }) {
	useIsoLayoutEffect(() => {
		return handle.attachStore(store);
	}, [handle, store]);
	return null;
}
/**
* Returns a callback ref that registers/unregisters the trigger element in the store.
*
* @param store The Store instance where the trigger should be registered.
*/
function useTriggerRegistration(id, store) {
	const registeredElementIdRef = import_react.useRef(null);
	const registeredElementRef = import_react.useRef(null);
	return import_react.useCallback((element) => {
		if (id === void 0) return;
		let shouldSyncTriggerCount = false;
		if (registeredElementIdRef.current !== null) {
			const registeredId = registeredElementIdRef.current;
			const registeredElement = registeredElementRef.current;
			const currentElement = store.context.triggerElements.getById(registeredId);
			if (registeredElement && currentElement === registeredElement) {
				store.context.triggerElements.delete(registeredId);
				shouldSyncTriggerCount = true;
			}
			registeredElementIdRef.current = null;
			registeredElementRef.current = null;
		}
		if (element !== null) {
			registeredElementIdRef.current = id;
			registeredElementRef.current = element;
			store.context.triggerElements.add(id, element);
			shouldSyncTriggerCount = true;
		}
		if (shouldSyncTriggerCount) {
			const triggerCount = store.context.triggerElements.size;
			if (store.select("open") && store.state.triggerCount !== triggerCount) store.set("triggerCount", triggerCount);
		}
	}, [store, id]);
}
function setPopupOpenState(state, open, trigger, preventUnmountOnClose = false) {
	if (open) state.preventUnmountingOnClose = false;
	else if (preventUnmountOnClose) state.preventUnmountingOnClose = true;
	const triggerId = trigger?.id ?? null;
	if (triggerId || open) {
		state.activeTriggerId = triggerId;
		state.activeTriggerElement = trigger ?? null;
	}
}
/**
* Sets up trigger data forwarding to the store.
*
* @param triggerId Id of the trigger.
* @param triggerElementRef Ref for the trigger DOM element.
* @param store The Store instance managing the popup state.
* @param stateUpdates An object with state updates to apply when the trigger is active.
*/
function useTriggerDataForwarding(triggerId, triggerElementRef, store, stateUpdates) {
	const isMountedByThisTrigger = store.useState("isMountedByTrigger", triggerId);
	const baseRegisterTrigger = useTriggerRegistration(triggerId, store);
	const applyTriggerData = useStableCallback((element) => {
		const open = store.select("open");
		const activeTriggerId = store.select("activeTriggerId");
		if (activeTriggerId === triggerId) {
			store.update({
				activeTriggerElement: element,
				...open ? stateUpdates : null
			});
			return;
		}
		if (activeTriggerId == null && open) store.update({
			activeTriggerId: triggerId,
			activeTriggerElement: element,
			...stateUpdates
		});
	});
	const registerTrigger = import_react.useCallback((element) => {
		baseRegisterTrigger(element);
		if (element) applyTriggerData(element);
	}, [baseRegisterTrigger, applyTriggerData]);
	useIsoLayoutEffect(() => {
		if (isMountedByThisTrigger) store.update({
			activeTriggerElement: triggerElementRef.current,
			...stateUpdates
		});
	}, [
		isMountedByThisTrigger,
		store,
		triggerElementRef,
		...Object.values(stateUpdates)
	]);
	return {
		registerTrigger,
		isMountedByThisTrigger
	};
}
/**
* Keeps trigger registration state synchronized while the popup is open.
*
* When a popup opens without an explicit trigger id and exactly one trigger is registered, that
* trigger is claimed as the active trigger. When the active trigger id is still registered but its
* element changed, the active element is refreshed. When the active trigger id is missing from the
* registry but the same element is still registered under a different id (e.g. the rendered trigger
* carries its own DOM `id` that differs from Base UI's internal trigger id), the active id is
* reassociated to the registered id instead of being treated as lost. When the active trigger
* unregisters, the default path preserves existing ownership so non-closing popup families do not
* silently claim a different trigger while staying open.
*
* If `closeOnActiveTriggerUnmount` is enabled, unregistering a previously resolved active trigger
* requests a close after a microtask so a same-tick replacement trigger with the same id can
* register first. An active trigger id that has not matched a registered trigger yet is treated as
* pending and does not request a close.
*
* This should be called on the Root part.
*
* @param store The Store instance managing the popup state.
* @param options Options for active trigger unmount behavior.
*/
function useImplicitActiveTrigger(store, options = {}) {
	const { closeOnActiveTriggerUnmount = false } = options;
	const resolvedActiveTriggerIdRef = import_react.useRef(null);
	const open = store.useState("open");
	const reactiveTriggerCount = store.useState("triggerCount");
	const activeTriggerId = store.useState("activeTriggerId");
	const reactiveActiveTriggerElement = store.useState("activeTriggerElement");
	useIsoLayoutEffect(() => {
		if (!open) {
			resolvedActiveTriggerIdRef.current = null;
			if (store.state.triggerCount !== 0) store.set("triggerCount", 0);
			return;
		}
		const triggerCount = store.context.triggerElements.size;
		const stateUpdates = {};
		if (store.state.triggerCount !== triggerCount) stateUpdates.triggerCount = triggerCount;
		const currentActiveTriggerId = store.select("activeTriggerId");
		let lostActiveTriggerId = null;
		if (currentActiveTriggerId) {
			const activeTriggerElement = store.context.triggerElements.getById(currentActiveTriggerId);
			if (!activeTriggerElement) {
				for (const [triggerId, triggerElement] of store.context.triggerElements.entries()) if (triggerElement === store.state.activeTriggerElement) {
					stateUpdates.activeTriggerId = triggerId;
					stateUpdates.activeTriggerElement = triggerElement;
					resolvedActiveTriggerIdRef.current = triggerId;
					break;
				}
				if (stateUpdates.activeTriggerId === void 0) {
					if (resolvedActiveTriggerIdRef.current === currentActiveTriggerId) lostActiveTriggerId = currentActiveTriggerId;
					else resolvedActiveTriggerIdRef.current = null;
				}
			} else {
				resolvedActiveTriggerIdRef.current = currentActiveTriggerId;
				if (activeTriggerElement !== store.state.activeTriggerElement) stateUpdates.activeTriggerElement = activeTriggerElement;
			}
		} else resolvedActiveTriggerIdRef.current = null;
		if (!lostActiveTriggerId && !currentActiveTriggerId && triggerCount === 1) {
			const iteratorResult = store.context.triggerElements.entries().next();
			if (!iteratorResult.done) {
				const [implicitTriggerId, implicitTriggerElement] = iteratorResult.value;
				stateUpdates.activeTriggerId = implicitTriggerId;
				stateUpdates.activeTriggerElement = implicitTriggerElement;
				resolvedActiveTriggerIdRef.current = implicitTriggerId;
			}
		}
		if (stateUpdates.triggerCount !== void 0 || stateUpdates.activeTriggerId !== void 0 || stateUpdates.activeTriggerElement !== void 0) store.update(stateUpdates);
		if (lostActiveTriggerId) {
			if (closeOnActiveTriggerUnmount) queueMicrotask(() => {
				if (store.select("open") && store.select("activeTriggerId") === lostActiveTriggerId && !store.context.triggerElements.getById(lostActiveTriggerId)) {
					const eventDetails = createChangeEventDetails(none);
					store.setOpen(false, eventDetails);
					if (!eventDetails.isCanceled) store.update({
						activeTriggerId: null,
						activeTriggerElement: null
					});
				}
			});
		}
	}, [
		open,
		store,
		reactiveTriggerCount,
		activeTriggerId,
		reactiveActiveTriggerElement,
		closeOnActiveTriggerUnmount
	]);
}
/**
* Manages the mounted state of the popup.
* Sets up the transition status listeners and handles unmounting when needed.
* Updates the `mounted`, `transitionStatus`, and `preventUnmountingOnClose` states in the store.
*
* @param open Whether the popup is open.
* @param store The Store instance managing the popup state.
* @param onUnmount Optional callback to be called when the popup is unmounted.
*
* @returns A function to forcibly unmount the popup.
*/
function useOpenStateTransitions(open, store, onUnmount) {
	const { mounted, setMounted, transitionStatus } = useTransitionStatus(open);
	const preventUnmountingOnClose = store.useState("preventUnmountingOnClose");
	const syncedPreventUnmountingOnClose = open ? false : preventUnmountingOnClose;
	store.useSyncedValues({
		mounted,
		transitionStatus,
		preventUnmountingOnClose: syncedPreventUnmountingOnClose
	});
	const forceUnmount = useStableCallback(() => {
		setMounted(false);
		store.update({
			activeTriggerId: null,
			activeTriggerElement: null,
			mounted: false,
			preventUnmountingOnClose: false
		});
		onUnmount?.();
		store.context.onOpenChangeComplete?.(false);
	});
	useOpenChangeComplete({
		enabled: mounted && !open && !syncedPreventUnmountingOnClose,
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (!open) forceUnmount();
		}
	});
	return {
		forceUnmount,
		transitionStatus
	};
}
function usePopupInteractionProps(store, statePart) {
	store.useSyncedValues(statePart);
	useIsoLayoutEffect(() => () => {
		store.update({
			activeTriggerProps: EMPTY_OBJECT,
			inactiveTriggerProps: EMPTY_OBJECT,
			popupProps: EMPTY_OBJECT
		});
	}, [store]);
}
function usePopupRootSync(store, open) {
	useIsoLayoutEffect(() => {
		if (!open && store.state.openMethod !== null) store.set("openMethod", null);
	}, [open, store]);
	useIsoLayoutEffect(() => () => {
		if (store.state.openMethod !== null) store.set("openMethod", null);
	}, [store]);
}
//#endregion
//#region node_modules/@base-ui/react/utils/popups/popupTriggerMap.mjs
/**
* Development-only reverse index of element to registered id, keyed by the owning map.
*
* Registration would otherwise have to scan every entry to detect an element claimed by two ids,
* making the mount of many triggers sharing one handle quadratic. Kept module-scoped, lazily
* initialized, and read only from `process.env.NODE_ENV` guards so production builds drop it along
* with the checks.
*/
var devElementIdsByMap;
function getDevElementIds(map) {
	devElementIdsByMap ??= /* @__PURE__ */ new WeakMap();
	let elementIds = devElementIdsByMap.get(map);
	if (!elementIds) {
		elementIds = /* @__PURE__ */ new WeakMap();
		devElementIdsByMap.set(map, elementIds);
	}
	return elementIds;
}
/**
* Data structure to keep track of popup trigger elements by their IDs.
*
* Element lookups iterate the id map rather than maintaining a parallel Set. Registration is O(1),
* while `hasElement` and `hasMatchingElement` are linear in the number of triggers.
*/
var PopupTriggerMap = class {
	constructor() {
		this.idMap = /* @__PURE__ */ new Map();
	}
	/**
	* Adds a trigger element with the given ID.
	*
	* Note: The provided element is assumed to not be registered under multiple IDs.
	*/
	add(id, element) {
		{
			const elementIds = getDevElementIds(this);
			const existingId = elementIds.get(element);
			if (existingId !== void 0 && existingId !== id) throw new Error("Base UI: A trigger element cannot be registered under multiple IDs in PopupTriggerMap.");
			const previousElement = this.idMap.get(id);
			if (previousElement !== void 0 && previousElement !== element) elementIds.delete(previousElement);
			elementIds.set(element, id);
		}
		this.idMap.set(id, element);
	}
	/**
	* Removes the trigger element with the given ID.
	*/
	delete(id) {
		{
			const element = this.idMap.get(id);
			if (element !== void 0) devElementIdsByMap?.get(this)?.delete(element);
		}
		this.idMap.delete(id);
	}
	/**
	* Whether the given element is registered as a trigger.
	*/
	hasElement(element) {
		for (const registered of this.idMap.values()) if (registered === element) return true;
		return false;
	}
	/**
	* Whether there is a registered trigger element matching the given predicate.
	*/
	hasMatchingElement(predicate) {
		for (const element of this.idMap.values()) if (predicate(element)) return true;
		return false;
	}
	/**
	* Returns the trigger element associated with the given ID, or undefined if no such element exists.
	*/
	getById(id) {
		return this.idMap.get(id);
	}
	/**
	* Returns an iterable of all registered trigger entries, where each entry is a tuple of [id, element].
	*/
	entries() {
		return this.idMap.entries();
	}
	/**
	* Returns an iterable of all registered trigger elements.
	*/
	elements() {
		return this.idMap.values();
	}
	/**
	* Returns the number of registered trigger elements.
	*/
	get size() {
		return this.idMap.size;
	}
};
//#endregion
//#region node_modules/@base-ui/react/floating-ui-react/utils/getEmptyRootContext.mjs
function getEmptyRootContext() {
	return new FloatingRootStore({
		open: false,
		transitionStatus: void 0,
		floatingElement: null,
		referenceElement: null,
		triggerElements: new PopupTriggerMap(),
		floatingId: void 0,
		syncOnly: false,
		nested: false,
		onOpenChange: void 0
	});
}
//#endregion
//#region node_modules/@base-ui/react/utils/popups/store.mjs
/**
* State common to all popup stores.
*/
function createInitialPopupStoreState() {
	return {
		open: false,
		openProp: void 0,
		mounted: false,
		transitionStatus: void 0,
		floatingRootContext: getEmptyRootContext(),
		floatingId: void 0,
		triggerCount: 0,
		preventUnmountingOnClose: false,
		payload: void 0,
		activeTriggerId: null,
		activeTriggerElement: null,
		triggerIdProp: void 0,
		popupElement: null,
		positionerElement: null,
		activeTriggerProps: EMPTY_OBJECT,
		inactiveTriggerProps: EMPTY_OBJECT,
		popupProps: EMPTY_OBJECT
	};
}
function createPopupFloatingRootContext(triggerElements, floatingId, nested = false) {
	return new FloatingRootStore({
		open: false,
		transitionStatus: void 0,
		floatingElement: null,
		referenceElement: null,
		triggerElements,
		floatingId,
		syncOnly: true,
		nested,
		onOpenChange: void 0
	});
}
var activeTriggerIdSelector = (state) => state.triggerIdProp ?? state.activeTriggerId;
var openSelector = (state) => state.openProp ?? state.open;
var popupIdSelector = (state) => {
	return (state.popupElement?.id ?? state.floatingId) || void 0;
};
function triggerOwnsOpenPopup(state, triggerId) {
	return triggerId !== void 0 && openSelector(state) && activeTriggerIdSelector(state) === triggerId;
}
function triggerOwnsOpenPopupOrIsOnlyTrigger(state, triggerId) {
	if (triggerOwnsOpenPopup(state, triggerId)) return true;
	return triggerId !== void 0 && openSelector(state) && activeTriggerIdSelector(state) == null && state.triggerCount === 1;
}
var popupStoreSelectors = {
	open: openSelector,
	mounted: (state) => state.mounted,
	transitionStatus: (state) => state.transitionStatus,
	floatingRootContext: (state) => state.floatingRootContext,
	triggerCount: (state) => state.triggerCount,
	preventUnmountingOnClose: (state) => state.preventUnmountingOnClose,
	payload: (state) => state.payload,
	activeTriggerId: activeTriggerIdSelector,
	activeTriggerElement: (state) => state.mounted ? state.activeTriggerElement : null,
	popupId: popupIdSelector,
	/**
	* Whether the trigger with the given ID was used to open the popup.
	*/
	isTriggerActive: (state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId,
	/**
	* Whether the popup is open and was activated by a trigger with the given ID.
	*/
	isOpenedByTrigger: (state, triggerId) => triggerOwnsOpenPopup(state, triggerId),
	/**
	* Whether the popup is mounted and was activated by a trigger with the given ID.
	*/
	isMountedByTrigger: (state, triggerId) => triggerId !== void 0 && activeTriggerIdSelector(state) === triggerId && state.mounted,
	triggerProps: (state, isActive) => isActive ? state.activeTriggerProps : state.inactiveTriggerProps,
	/**
	* Popup id for the trigger that currently owns the open popup.
	*/
	triggerPopupId: (state, triggerId) => triggerOwnsOpenPopupOrIsOnlyTrigger(state, triggerId) ? popupIdSelector(state) : void 0,
	popupProps: (state) => state.popupProps,
	popupElement: (state) => state.popupElement,
	positionerElement: (state) => state.positionerElement
};
/**
* Store members a detached handle-backed trigger reads or invokes for trigger registration and data
* forwarding. `set`/`update` are included only for trigger-count and trigger-data bookkeeping; on a
* detached (inert) store they are intentionally no-ops, so a write through them is not guaranteed to
* be durable. Component handle-store views Pick these from their concrete store (preserving its
* context and selectors) and add any component-specific trigger-invoked members such as `setOpen`.
*/
/**
* The subset of a popup store that trigger registration and data forwarding rely on. Narrow enough
* that an inert store can be passed while detached.
*/
//#endregion
//#region node_modules/@base-ui/react/utils/popups/usePopupHandleStore.mjs
/**
* Reads the store currently exposed by a popup handle and subscribes to store-pointer changes.
* Detached triggers use this to follow a handle as a root attaches or detaches: while no root is
* attached, the handle exposes its fallback store; once a root attaches, subscribers re-render and
* read from the live root store.
*
* Returns `undefined` when no handle is provided so callers can fall back to their root context.
*
* @param handle The popup handle to read from, or `undefined` when the trigger is not handle-bound.
*/
function usePopupHandleStore(handle) {
	const subscribe = import_react.useCallback((listener) => {
		if (handle === void 0) return NOOP;
		return handle.subscribeStore(listener);
	}, [handle]);
	const getSnapshot = import_react.useCallback(() => {
		return handle === void 0 ? void 0 : handle.store;
	}, [handle]);
	return (0, import_shim.useSyncExternalStore)(subscribe, getSnapshot, () => handle?.serverStore);
}
//#endregion
//#region node_modules/@base-ui/react/dialog/root/useDialogRoot.mjs
function DialogInteractions({ store, parentContext, isDrawer }) {
	const open = store.useState("open");
	const disablePointerDismissal = store.useState("disablePointerDismissal");
	const modal = store.useState("modal");
	const popupElement = store.useState("popupElement");
	const floatingRootContext = store.useState("floatingRootContext");
	const [ownNestedOpenDialogs, setOwnNestedOpenDialogs] = import_react.useState(0);
	const [ownNestedOpenDrawers, setOwnNestedOpenDrawers] = import_react.useState(0);
	const isTopmost = ownNestedOpenDialogs === 0;
	const dismiss = useDismiss(floatingRootContext, {
		outsidePressEvent() {
			if (store.context.internalBackdropRef.current || store.context.backdropRef.current) return "intentional";
			return {
				mouse: modal === "trap-focus" ? "sloppy" : "intentional",
				touch: "sloppy"
			};
		},
		outsidePress(event) {
			if (!store.context.outsidePressEnabledRef.current) return false;
			if ("button" in event && event.button !== 0) return false;
			if ("touches" in event) {
				if (event.type === "touchend") {
					if (event.changedTouches.length !== 1 || event.touches.length !== 0) return false;
				} else if (event.touches.length !== 1) return false;
			}
			const target = getTarget(event);
			if (isTopmost && !disablePointerDismissal) {
				if (modal) {
					const internalBackdrop = store.context.internalBackdropRef.current;
					const backdrop = store.context.backdropRef.current;
					return internalBackdrop || backdrop ? internalBackdrop === target || backdrop === target || contains(target, popupElement) && !target?.hasAttribute("data-base-ui-portal") : true;
				}
				return true;
			}
			return false;
		},
		escapeKey: isTopmost
	});
	useScrollLock(open && modal === true, popupElement);
	store.useContextCallback("onNestedDialogOpen", (dialogCount, drawerCount) => {
		setOwnNestedOpenDialogs(dialogCount);
		setOwnNestedOpenDrawers(drawerCount);
	});
	useIsoLayoutEffect(() => {
		if (parentContext?.onNestedDialogOpen) {
			if (open) parentContext.onNestedDialogOpen(ownNestedOpenDialogs + 1, ownNestedOpenDrawers + (isDrawer ? 1 : 0));
			else parentContext.onNestedDialogOpen(0, 0);
		}
		return () => {
			if (parentContext?.onNestedDialogOpen && open) parentContext.onNestedDialogOpen(0, 0);
		};
	}, [
		isDrawer,
		open,
		ownNestedOpenDialogs,
		ownNestedOpenDrawers,
		parentContext
	]);
	usePopupInteractionProps(store, {
		activeTriggerProps: dismiss.reference,
		inactiveTriggerProps: dismiss.trigger,
		popupProps: dismiss.floating,
		nestedOpenDialogCount: ownNestedOpenDialogs,
		nestedOpenDrawerCount: ownNestedOpenDrawers
	});
	return null;
}
//#endregion
//#region node_modules/@base-ui/react/dialog/root/DialogRootContext.mjs
var DialogRootContext = /*#__PURE__*/ import_react.createContext(void 0);
DialogRootContext.displayName = "DialogRootContext";
function useDialogRootContext(optional) {
	const store = import_react.useContext(DialogRootContext);
	if (!optional && store === void 0) throw new Error("Base UI: DialogRootContext is missing. Dialog parts must be placed within <Dialog.Root>.");
	return store;
}
//#endregion
//#region node_modules/@base-ui/react/utils/NullStore.mjs
/**
* A `ReactStore` whose state never changes.
*
* Useful for fallback stores that need to support normal store reads while detached from the
* component that owns real state. Context values may still contain mutable refs or maps.
*/
var NullStore = class extends ReactStore {
	setState(_newState) {}
	update(_changes) {}
	set(_key, _value) {}
	notifyAll() {}
};
//#endregion
//#region node_modules/@base-ui/react/dialog/store/DialogStore.mjs
var selectors = {
	...popupStoreSelectors,
	modal: (state) => state.modal,
	nested: (state) => state.nested,
	nestedOpenDialogCount: (state) => state.nestedOpenDialogCount,
	nestedOpenDrawerCount: (state) => state.nestedOpenDrawerCount,
	disablePointerDismissal: (state) => state.disablePointerDismissal,
	openMethod: (state) => state.openMethod,
	descriptionElementId: (state) => state.descriptionElementId,
	titleElementId: (state) => state.titleElementId,
	viewportElement: (state) => state.viewportElement,
	role: (state) => state.role
};
/**
* The subset of `DialogStore` that detached handle-backed triggers rely on. Both the real
* `DialogStore` and the inert fallback store satisfy it, so a trigger can read from whichever
* store the handle currently exposes.
*/
var DialogStore = class extends ReactStore {
	constructor(initialState, floatingId, nested) {
		const triggerElements = new PopupTriggerMap();
		const state = createInitialState(initialState, triggerElements, floatingId, nested);
		super(state, createInitialContext(triggerElements), selectors);
	}
	setOpen = (nextOpen, eventDetails) => {
		eventDetails.preventUnmountOnClose = () => {
			this.set("preventUnmountingOnClose", true);
		};
		if (!nextOpen && eventDetails.trigger == null && this.state.activeTriggerId != null) eventDetails.trigger = this.state.activeTriggerElement ?? void 0;
		this.context.onOpenChange?.(nextOpen, eventDetails);
		if (eventDetails.isCanceled) return;
		this.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
		const updatedState = { open: nextOpen };
		setPopupOpenState(updatedState, nextOpen, eventDetails.trigger);
		this.update(updatedState);
	};
};
/**
* Creates the inert fallback store used by detached handle-backed triggers while no
* `Dialog.Root` is attached. It preserves a dialog-specific trigger registry in context so
* detached triggers can register before migrating to the live root store.
*/
function createNullDialogStore() {
	const triggerElements = new PopupTriggerMap();
	return new NullStore(Object.freeze(createInitialState(void 0, triggerElements)), Object.freeze(createInitialContext(triggerElements)), selectors);
}
function createInitialState(initialState, triggerElements, floatingId, nested = false) {
	const state = {
		...createInitialPopupStoreState(),
		modal: true,
		disablePointerDismissal: false,
		viewportElement: null,
		descriptionElementId: void 0,
		titleElementId: void 0,
		openMethod: null,
		nested: false,
		nestedOpenDialogCount: 0,
		nestedOpenDrawerCount: 0,
		role: "dialog",
		...initialState
	};
	state.floatingRootContext = createPopupFloatingRootContext(triggerElements, floatingId, nested);
	return state;
}
function createInitialContext(triggerElements) {
	return {
		popupRef: /*#__PURE__*/ import_react.createRef(),
		backdropRef: /*#__PURE__*/ import_react.createRef(),
		internalBackdropRef: /*#__PURE__*/ import_react.createRef(),
		outsidePressEnabledRef: { current: true },
		triggerElements,
		onOpenChange: void 0,
		onOpenChangeComplete: void 0
	};
}
//#endregion
//#region node_modules/@base-ui/react/dialog/root/useRenderDialogRoot.mjs
function useRenderDialogRoot(mode, props) {
	const { children, open: openProp, defaultOpen = false, onOpenChange, onOpenChangeComplete, disablePointerDismissal: disablePointerDismissalProp = false, modal: modalProp = true, actionsRef, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null } = props;
	const isDrawer = mode === "drawer";
	const isAlertDialog = mode === "alert-dialog";
	const modal = isAlertDialog ? true : modalProp;
	const disablePointerDismissal = isAlertDialog || disablePointerDismissalProp;
	const role = isAlertDialog ? "alertdialog" : "dialog";
	const parentStore = useDialogRootContext(true);
	const rootState = {
		modal,
		disablePointerDismissal,
		nested: parentStore != null,
		role
	};
	const store = usePopupRootStore((floatingId, floatingNested) => new DialogStore({
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp,
		...rootState
	}, floatingId, floatingNested), true);
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useSyncedValues(rootState);
	store.useContextCallback("onOpenChange", onOpenChange);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const payload = store.useState("payload");
	usePopupRootSync(store, open);
	useImplicitActiveTrigger(store);
	const { forceUnmount } = useOpenStateTransitions(open, store);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: () => store.setOpen(false, createChangeEventDetails(imperativeAction))
	}), [forceUnmount, store]);
	const shouldRenderInteractions = open || mounted;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(DialogRootContext.Provider, {
		value: store,
		children: [
			handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
				handle,
				store
			}),
			shouldRenderInteractions && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DialogInteractions, {
				store,
				parentContext: parentStore?.context,
				isDrawer
			}),
			typeof children === "function" ? children({ payload }) : children
		]
	});
}
//#endregion
//#region node_modules/@base-ui/react/alert-dialog/root/AlertDialogRoot.mjs
/**
* Groups all parts of the alert dialog.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Alert Dialog](https://base-ui.com/react/components/alert-dialog)
*/
function AlertDialogRoot(props) {
	return useRenderDialogRoot("alert-dialog", props);
}
(function(CommonPopupDataAttributes) {
	/**
	* Present when the popup is open.
	*/
	CommonPopupDataAttributes["open"] = "data-open";
	/**
	* Present when the popup is closed.
	*/
	CommonPopupDataAttributes["closed"] = "data-closed";
	/**
	* Present when the popup begins animating in.
	*/
	CommonPopupDataAttributes[CommonPopupDataAttributes["startingStyle"] = TransitionStatusDataAttributes.startingStyle] = "startingStyle";
	/**
	* Present when the popup is animating out.
	*/
	CommonPopupDataAttributes[CommonPopupDataAttributes["endingStyle"] = TransitionStatusDataAttributes.endingStyle] = "endingStyle";
	/**
	* Present when the anchor is hidden.
	*/
	CommonPopupDataAttributes["anchorHidden"] = "data-anchor-hidden";
	/**
	* Indicates which side the popup is positioned relative to the trigger.
	* @type { 'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
	*/
	CommonPopupDataAttributes["side"] = "data-side";
	/**
	* Indicates how the popup is aligned relative to specified side.
	* @type {'start' | 'center' | 'end'}
	*/
	CommonPopupDataAttributes["align"] = "data-align";
	return CommonPopupDataAttributes;
})({});
var TRIGGER_HOOK = { "data-popup-open": "" };
var POPUP_OPEN_HOOK = { "data-open": "" };
var POPUP_CLOSED_HOOK = { "data-closed": "" };
var ANCHOR_HIDDEN_HOOK = { "data-anchor-hidden": "" };
var triggerOpenStateMapping = { open(value) {
	if (value) return TRIGGER_HOOK;
	return null;
} };
var popupStateMapping = {
	open(value) {
		if (value) return POPUP_OPEN_HOOK;
		return POPUP_CLOSED_HOOK;
	},
	anchorHidden(value) {
		if (value) return ANCHOR_HIDDEN_HOOK;
		return null;
	}
};
var popupTransitionStateMapping = {
	...popupStateMapping,
	...transitionStatusMapping
};
//#endregion
//#region node_modules/@base-ui/react/dialog/backdrop/DialogBackdrop.mjs
/**
* An overlay displayed beneath the popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogBackdrop = /*#__PURE__*/ import_react.forwardRef(function DialogBackdrop(componentProps, forwardedRef) {
	const { render, className, style, forceRender = false, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const open = store.useState("open");
	const nested = store.useState("nested");
	const mounted = store.useState("mounted");
	const state = {
		open,
		transitionStatus: store.useState("transitionStatus")
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: [store.context.backdropRef, forwardedRef],
		stateAttributesMapping: popupTransitionStateMapping,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: {
				userSelect: "none",
				WebkitUserSelect: "none"
			}
		}, elementProps],
		enabled: forceRender || !nested
	});
});
DialogBackdrop.displayName = "DialogBackdrop";
//#endregion
//#region node_modules/@base-ui/react/dialog/close/DialogClose.mjs
/**
* A button that closes the dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogClose = /*#__PURE__*/ import_react.forwardRef(function DialogClose(componentProps, forwardedRef) {
	const { render, className, style, disabled = false, nativeButton = true, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const open = store.useState("open");
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const state = { disabled };
	function handleClick(event) {
		if (open) store.setOpen(false, createChangeEventDetails(closePress, event.nativeEvent));
	}
	return useRenderElement("button", componentProps, {
		state,
		ref: [forwardedRef, buttonRef],
		props: [
			{ onClick: handleClick },
			elementProps,
			getButtonProps
		]
	});
});
DialogClose.displayName = "DialogClose";
//#endregion
//#region node_modules/@base-ui/react/dialog/description/DialogDescription.mjs
/**
* A paragraph with additional information about the dialog.
* Renders a `<p>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogDescription = /*#__PURE__*/ import_react.forwardRef(function DialogDescription(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const id = useBaseUiId(idProp);
	store.useSyncedValueWithCleanup("descriptionElementId", id);
	return useRenderElement("p", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
DialogDescription.displayName = "DialogDescription";
//#endregion
//#region node_modules/@base-ui/react/dialog/portal/DialogPortalContext.mjs
var DialogPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
DialogPortalContext.displayName = "DialogPortalContext";
function useDialogPortalContext() {
	const value = import_react.useContext(DialogPortalContext);
	if (value === void 0) throw new Error("Base UI: <Dialog.Portal> is missing.");
	return value;
}
//#endregion
//#region node_modules/@base-ui/react/dialog/utils/stateAttributesMapping.mjs
/**
* Shared by `Dialog.Popup` and `Dialog.Viewport`, whose states have the same shape.
* `nested` is not mapped: unmapped `true` booleans already render as `data-nested`.
*/
var dialogStateAttributesMapping = {
	...popupStateMapping,
	...transitionStatusMapping,
	nestedDialogOpen(value) {
		return value ? { "data-nested-dialog-open": "" } : null;
	}
};
//#endregion
//#region node_modules/@base-ui/react/dialog/popup/DialogPopup.mjs
/**
* A container for the dialog contents.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogPopup = /*#__PURE__*/ import_react.forwardRef(function DialogPopup(componentProps, forwardedRef) {
	const { render, className, style, finalFocus, initialFocus, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const descriptionElementId = store.useState("descriptionElementId");
	const disablePointerDismissal = store.useState("disablePointerDismissal");
	const floatingRootContext = store.useState("floatingRootContext");
	const rootPopupProps = store.useState("popupProps");
	const modal = store.useState("modal");
	const mounted = store.useState("mounted");
	const nested = store.useState("nested");
	const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
	const open = store.useState("open");
	const openMethod = store.useState("openMethod");
	const titleElementId = store.useState("titleElementId");
	const transitionStatus = store.useState("transitionStatus");
	const role = store.useState("role");
	const floatingId = floatingRootContext.useState("floatingId");
	useDialogPortalContext();
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	const resolvedInitialFocus = initialFocus === void 0 ? createDefaultInitialFocus(store.context.popupRef) : initialFocus;
	const nestedDialogOpen = nestedOpenDialogCount > 0;
	const setPopupElement = store.useStateSetter("popupElement");
	const element = useRenderElement("div", componentProps, {
		state: {
			open,
			nested,
			transitionStatus,
			nestedDialogOpen
		},
		props: [
			rootPopupProps,
			{
				id: floatingId,
				"aria-labelledby": titleElementId,
				"aria-describedby": descriptionElementId,
				role,
				...FOCUSABLE_POPUP_PROPS,
				hidden: !mounted,
				onKeyDown(event) {
					if (COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
				},
				style: { "--nested-dialogs": nestedOpenDialogCount }
			},
			elementProps
		],
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement
		],
		stateAttributesMapping: dialogStateAttributesMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingRootContext,
		openInteractionType: openMethod,
		disabled: !mounted,
		closeOnFocusOut: !disablePointerDismissal,
		initialFocus: resolvedInitialFocus,
		returnFocus: finalFocus,
		modal: modal !== false,
		restoreFocus: "popup",
		children: element
	});
});
DialogPopup.displayName = "DialogPopup";
//#endregion
//#region node_modules/@base-ui/utils/inertValue.mjs
function inertValue(value) {
	if (isReactVersionAtLeast(19)) return value;
	return value ? "true" : void 0;
}
//#endregion
//#region node_modules/@base-ui/react/utils/InternalBackdrop.mjs
/**
* @internal
*/
var InternalBackdrop = /*#__PURE__*/ import_react.forwardRef(function InternalBackdrop(props, ref) {
	const { cutout, ...otherProps } = props;
	let clipPath;
	if (cutout) {
		const rect = cutout.getBoundingClientRect();
		clipPath = `polygon(0% 0%,100% 0%,100% 100%,0% 100%,0% 0%,${rect.left}px ${rect.top}px,${rect.left}px ${rect.bottom}px,${rect.right}px ${rect.bottom}px,${rect.right}px ${rect.top}px,${rect.left}px ${rect.top}px)`;
	}
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		ref,
		role: "presentation",
		"data-base-ui-inert": "",
		...otherProps,
		style: {
			position: "fixed",
			inset: 0,
			userSelect: "none",
			WebkitUserSelect: "none",
			clipPath
		}
	});
});
InternalBackdrop.displayName = "InternalBackdrop";
//#endregion
//#region node_modules/@base-ui/react/dialog/portal/DialogPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogPortal = /*#__PURE__*/ import_react.forwardRef(function DialogPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	const store = useDialogRootContext();
	const mounted = store.useState("mounted");
	const modal = store.useState("modal");
	const open = store.useState("open");
	if (!(mounted || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DialogPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(FloatingPortal, {
			ref: forwardedRef,
			...portalProps,
			children: [mounted && modal === true && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
				ref: store.context.internalBackdropRef,
				inert: inertValue(!open)
			}), props.children]
		})
	});
});
DialogPortal.displayName = "DialogPortal";
//#endregion
//#region node_modules/@base-ui/react/dialog/title/DialogTitle.mjs
/**
* A heading that labels the dialog.
* Renders an `<h2>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogTitle = /*#__PURE__*/ import_react.forwardRef(function DialogTitle(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const id = useBaseUiId(idProp);
	store.useSyncedValueWithCleanup("titleElementId", id);
	return useRenderElement("h2", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
DialogTitle.displayName = "DialogTitle";
//#endregion
//#region node_modules/@base-ui/utils/useEnhancedClickHandler.mjs
/**
* Provides a cross-browser way to determine the type of the pointer used to click.
* Safari and Firefox do not provide the PointerEvent to the click handler (they use MouseEvent) yet.
* Additionally, this implementation detects if the click was triggered by the keyboard.
*
* @param handler The function to be called when the button is clicked. The first parameter is the original event and the second parameter is the pointer type.
*/
function useEnhancedClickHandler(handler) {
	const lastClickInteractionTypeRef = import_react.useRef("");
	const handlePointerDown = import_react.useCallback((event) => {
		if (event.defaultPrevented) return;
		lastClickInteractionTypeRef.current = event.pointerType;
		handler(event, event.pointerType);
	}, [handler]);
	return {
		onClick: import_react.useCallback((event) => {
			if (event.detail === 0) {
				handler(event, "keyboard");
				return;
			}
			if ("pointerType" in event) handler(event, event.pointerType);
			else handler(event, lastClickInteractionTypeRef.current);
			lastClickInteractionTypeRef.current = "";
		}, [handler]),
		onPointerDown: handlePointerDown
	};
}
//#endregion
//#region node_modules/@base-ui/react/utils/useOpenInteractionType.mjs
function useOpenMethodTriggerProps(open, setOpenMethod) {
	const { onClick, onPointerDown } = useEnhancedClickHandler(useStableCallback((_, interactionType) => {
		if (!(typeof open === "function" ? open() : open)) setOpenMethod(interactionType || (ios ? "touch" : ""));
	}));
	return import_react.useMemo(() => ({
		onClick,
		onPointerDown
	}), [onClick, onPointerDown]);
}
//#endregion
//#region node_modules/@base-ui/react/dialog/trigger/DialogTrigger.mjs
/**
* A button that opens the dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogTrigger = /*#__PURE__*/ import_react.forwardRef(function DialogTrigger(componentProps, forwardedRef) {
	const { render, className, style, disabled = false, nativeButton = true, id: idProp, payload, handle, ...elementProps } = componentProps;
	const dialogRootStore = useDialogRootContext(true);
	const store = usePopupHandleStore(handle) ?? dialogRootStore;
	if (!store) throw new Error("Base UI: <Dialog.Trigger> must be used within <Dialog.Root> or provided with a handle.");
	const thisTriggerId = useBaseUiId(idProp);
	const floatingContext = store.useState("floatingRootContext");
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const popupId = store.useState("triggerPopupId", thisTriggerId);
	const triggerElementRef = import_react.useRef(null);
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, { payload });
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const click = useClick(floatingContext);
	const interactionTypeProps = useOpenMethodTriggerProps(() => store.select("open"), (interactionType) => {
		store.set("openMethod", interactionType);
	});
	const state = {
		disabled,
		open: isOpenedByThisTrigger
	};
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	return useRenderElement("button", componentProps, {
		state,
		ref: [
			buttonRef,
			forwardedRef,
			registerTrigger,
			triggerElementRef
		],
		props: [
			click.reference,
			rootTriggerProps,
			interactionTypeProps,
			{
				[CLICK_TRIGGER_IDENTIFIER]: "",
				id: thisTriggerId,
				"aria-haspopup": "dialog",
				"aria-expanded": isOpenedByThisTrigger,
				"aria-controls": popupId
			},
			elementProps,
			getButtonProps
		],
		stateAttributesMapping: triggerOpenStateMapping
	});
});
DialogTrigger.displayName = "DialogTrigger";
//#endregion
//#region node_modules/@base-ui/react/alert-dialog/trigger/AlertDialogTrigger.mjs
/**
* A button that opens the alert dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Alert Dialog](https://base-ui.com/react/components/alert-dialog)
*/
var AlertDialogTrigger = DialogTrigger;
//#endregion
//#region node_modules/@base-ui/react/dialog/viewport/DialogViewport.mjs
/**
* A positioning container for the dialog popup that can be made scrollable.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogViewport = /*#__PURE__*/ import_react.forwardRef(function DialogViewport(componentProps, forwardedRef) {
	const { render, className, style, children, ...elementProps } = componentProps;
	const keepMounted = useDialogPortalContext();
	const store = useDialogRootContext();
	const open = store.useState("open");
	const nested = store.useState("nested");
	const transitionStatus = store.useState("transitionStatus");
	const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
	const mounted = store.useState("mounted");
	const setViewportElement = store.useStateSetter("viewportElement");
	return useRenderElement("div", componentProps, {
		enabled: keepMounted || mounted,
		state: {
			open,
			nested,
			transitionStatus,
			nestedDialogOpen: nestedOpenDialogCount > 0
		},
		ref: [forwardedRef, setViewportElement],
		stateAttributesMapping: dialogStateAttributesMapping,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: { pointerEvents: !open ? "none" : void 0 },
			children
		}, elementProps]
	});
});
DialogViewport.displayName = "DialogViewport";
//#endregion
//#region node_modules/@base-ui/react/dialog/store/DialogHandle.mjs
/**
* Controls a Dialog imperatively and associates detached `Dialog.Trigger` components with a
* `Dialog.Root`. Create one with `Dialog.createHandle()` and pass it to the `handle` prop of the
* root and of any triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var DialogHandle = class extends BasePopupHandle {
	constructor() {
		super(createNullDialogStore(), "Dialog", false);
	}
	/**
	* Opens the dialog, optionally associating it with a trigger.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the dialog. The trigger must be a matching
	* `Dialog.Trigger` with this handle passed as a prop. Pass `null` to open without associating any trigger.
	*/
	open(triggerId) {
		this.openByTrigger(triggerId);
	}
	/**
	* Opens the dialog with the given payload, without associating it with any trigger.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param payload Payload to set when opening the dialog. It is exposed to the root's render-prop children.
	*/
	openWithPayload(payload) {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn("Base UI: DialogHandle.openWithPayload() was called while no root using this handle is mounted. The call and its payload were ignored; mount a root with this handle before opening it imperatively.");
			return;
		}
		attachedStore.set("payload", payload);
		attachedStore.setOpen(true, createChangeEventDetails(imperativeAction));
	}
	/**
	* Closes the dialog.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	close() {
		this.closePopup();
	}
	/**
	* Whether the dialog is currently open. Returns `false` while no root is attached to the handle.
	*/
	get isOpen() {
		return this.attachedStore?.select("open") ?? false;
	}
};
//#endregion
//#region node_modules/@base-ui/react/alert-dialog/handle.mjs
/**
* Controls an Alert Dialog imperatively and associates detached `AlertDialog.Trigger` components with
* an `AlertDialog.Root`. Create one with `AlertDialog.createHandle()` and pass it to the `handle`
* prop of the root and of any triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var AlertDialogHandle = class extends DialogHandle {};
/**
* Creates a new handle to connect an AlertDialog.Root with detached AlertDialog.Trigger components.
*/
function createAlertDialogHandle() {
	return new AlertDialogHandle();
}
//#endregion
//#region node_modules/@base-ui/react/alert-dialog/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Backdrop: () => DialogBackdrop,
	Close: () => DialogClose,
	Description: () => DialogDescription,
	Handle: () => AlertDialogHandle,
	Popup: () => DialogPopup,
	Portal: () => DialogPortal,
	Root: () => AlertDialogRoot,
	Title: () => DialogTitle,
	Trigger: () => AlertDialogTrigger,
	Viewport: () => DialogViewport,
	createHandle: () => createAlertDialogHandle
});
//#endregion
export { index_parts_exports as AlertDialog };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFJQSxTQUFnQixpQkFBaUIsUUFBUSxNQUFNLFVBQVUsU0FBUztDQUNoRSxPQUFPLGlCQUFpQixNQUFNLFVBQVUsT0FBTztDQUMvQyxhQUFhO0VBQ1gsT0FBTyxvQkFBb0IsTUFBTSxVQUFVLE9BQU87Q0FDcEQ7QUFDRjs7Ozs7Ozs7Ozs7OztBQ0NBLFNBQVMsY0FBYztDQUNyQixJQUFJLE9BQU8sY0FBYyxhQUN2QixPQUFPO0VBQ0wsV0FBVztFQUNYLFVBQVU7RUFDVixnQkFBZ0I7Q0FDbEI7Q0FFeUM7RUFDekMsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxVQUFVLE1BQU0sUUFBUSxPQUFPLE1BQU0sR0FDdkMsT0FBTztHQUNMLFdBQVcsT0FBTyxPQUFPLEtBQUssRUFDNUIsT0FDQSxjQUNJLEdBQUcsTUFBTSxHQUFHLFNBQVMsQ0FBQyxDQUFDLEtBQUssR0FBRztHQUNyQyxVQUFVLE9BQU8sWUFBWSxVQUFVLFlBQVk7R0FDbkQsZ0JBQWdCLFVBQVUsa0JBQWtCO0VBQzlDO0NBRUo7Q0FDQSxPQUFPO0VBQ0wsV0FBVyxVQUFVO0VBQ3JCLFVBQVUsVUFBVSxZQUFZO0VBQ2hDLGdCQUFnQixVQUFVLGtCQUFrQjtDQUM5QztBQUNGO0FBQ0EsSUFBTSxFQUNKLFdBQ0EsVUFDQSxtQkFDRSxZQUFZO0FBQ2hCLElBQWEsaUJBQWlCLFVBQVUsWUFBWTtBQUNwRCxJQUFhLGdCQUFnQixTQUFTLFlBQVk7Ozs7QUNyQ2xELElBQWEsTUFBTSxZQUFZLEtBQUssYUFBYSxLQUFLLGtCQUFrQixjQUFjLGlCQUFpQjs7QUFHdkcsSUFBTSxpQkFBaUI7QUFDdkIsSUFBYSxVQUFVLGtCQUFrQixrQkFBa0IsZUFBZSxTQUFTLGNBQWM7O0FBR2pHLElBQWEsTUFBTSxDQUFDLE9BQU8sY0FBYyxXQUFXLEtBQUs7QUFHbEMsY0FBYyxXQUFXLEtBQUs7QUFHaEMsQ0FBQyxXQUFXLHFCQUFxQixLQUFLLGFBQWE7O0FBR3hFLElBQWEsUUFBUSxPQUFPOzs7O0FDaEI1QixJQUFhLFNBQVMsT0FBTyxRQUFRLGVBQWUsQ0FBQyxDQUFDLElBQUksV0FBVyw4QkFBOEI7QUFPOUUsQ0FBQyxVQUFVLGVBQWUsU0FBUyxTQUFTO0FBTzVDLENBQUMsVUFBVSxlQUFlLFNBQVMsT0FBTzs7Ozs7OztBQ1QvRCxJQUFhLFlBQVk7Ozs7QUNSekIsSUFBYSxRQUFRLGlCQUFpQixLQUFLLGNBQWM7OztBQ0Z6RCxTQUFnQixjQUFjLE1BQU07Q0FDbEMsT0FBTyxNQUFNLGlCQUFpQjtBQUNoQzs7O0FDQ0EsSUFBTSxRQUFRO0FBQ2QsSUFBYSxVQUFiLE1BQWEsUUFBUTtDQUNuQixPQUFPLFNBQVM7RUFDZCxPQUFPLElBQUksUUFBUTtDQUNyQjtDQUNBLFlBQVk7Ozs7Q0FLWixNQUFNLE9BQU8sSUFBSTtFQUNmLEtBQUssTUFBTTtFQUNYLEtBQUssWUFBWSxpQkFBaUI7R0FDaEMsS0FBSyxZQUFZO0dBQ2pCLEdBQUc7RUFDTCxHQUFHLEtBQUs7Q0FDVjtDQUNBLFlBQVk7RUFDVixPQUFPLEtBQUssY0FBYztDQUM1QjtDQUNBLGNBQWM7RUFDWixJQUFJLEtBQUssY0FBYyxPQUFPO0dBQzVCLGFBQWEsS0FBSyxTQUFTO0dBQzNCLEtBQUssWUFBWTtFQUNuQjtDQUNGO0NBQ0Esc0JBQXNCO0VBQ3BCLE9BQU8sS0FBSztDQUNkO0FBQ0Y7Ozs7QUFLQSxTQUFnQixhQUFhO0NBQzNCLE1BQU0sVUFBVSxlQUFlLFFBQVEsTUFBTSxDQUFDLENBQUM7Q0FDL0MsV0FBVyxRQUFRLGFBQWE7Q0FDaEMsT0FBTztBQUNUOzs7QUNqQ0EsSUFBSSxxQkFBcUIsQ0FBQztBQUMxQixJQUFJLHFCQUFxQixDQUFDO0FBQzFCLElBQUksNkJBQTZCO0FBSWpDLFNBQVMsb0JBQW9CLE1BQU0sTUFBTTtDQUN2QyxPQUFPLGtCQUFrQixJQUFJLElBQUksT0FBTztBQUMxQztBQUNBLFNBQVMsbUJBQW1CLEtBQUssTUFBTSxNQUFNO0NBQzNDLE9BQU8sY0FBYyxLQUFLLElBQUksaUJBQWlCLG9CQUFvQixNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUztBQUMzRjtBQUNBLFNBQVMsbUJBQW1CLGtCQUFrQjtDQUM1QyxJQUFJLE9BQU8sYUFBYSxhQUN0QixPQUFPO0NBRVQsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0NBRTFDLE9BRFlBLFVBQVksR0FDZixDQUFDLENBQUMsYUFBYSxJQUFJLGdCQUFnQixjQUFjO0FBQzVEO0FBQ0EsU0FBUyw4QkFBOEIsa0JBQWtCO0NBRXZELElBQUksRUFEYyxPQUFPLFFBQVEsZUFBZSxJQUFJLFlBQVksSUFBSSxTQUFTLG9CQUFvQixRQUFRLE1BQ3ZGLE9BQU8sYUFBYSxhQUNwQyxPQUFPO0NBRVQsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0NBQzFDLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLE1BQU0sa0JBQWtCLG9CQUFvQixNQUFNLElBQUk7Q0FDdEQsTUFBTSxtQ0FBbUMsZ0JBQWdCLE1BQU07Q0FDL0QsTUFBTSwwQkFBMEIsS0FBSyxNQUFNO0NBQzNDLEtBQUssTUFBTSxrQkFBa0I7Q0FDN0IsZ0JBQWdCLE1BQU0sWUFBWTtDQUNsQyxNQUFNLFNBQVMsZ0JBQWdCO0NBQy9CLGdCQUFnQixNQUFNLFlBQVk7Q0FDbEMsTUFBTSxRQUFRLGdCQUFnQjtDQUM5QixnQkFBZ0IsTUFBTSxZQUFZO0NBQ2xDLEtBQUssTUFBTSxrQkFBa0I7Q0FDN0IsT0FBTyxXQUFXO0FBQ3BCO0FBQ0EsU0FBUywrQkFBK0Isa0JBQWtCO0NBQ3hELE1BQU0sTUFBTSxjQUFjLGdCQUFnQjtDQUMxQyxNQUFNLE9BQU8sSUFBSTtDQUNqQixNQUFNLE9BQU8sSUFBSTtDQU1qQixNQUFNLGdCQUFnQixvQkFBb0IsTUFBTSxJQUFJO0NBQ3BELE1BQU0sOEJBQThCO0VBQ2xDLFdBQVcsY0FBYyxNQUFNO0VBQy9CLFdBQVcsY0FBYyxNQUFNO0NBQ2pDO0NBQ0EsT0FBTyxPQUFPLGNBQWMsT0FBTztFQUNqQyxXQUFXO0VBQ1gsV0FBVztDQUNiLENBQUM7Q0FDRCxhQUFhO0VBQ1gsT0FBTyxPQUFPLGNBQWMsT0FBTywyQkFBMkI7Q0FDaEU7QUFDRjtBQUNBLFNBQVMsNkJBQTZCLGtCQUFrQjtDQUN0RCxNQUFNLE1BQU0sY0FBYyxnQkFBZ0I7Q0FDMUMsTUFBTSxPQUFPLElBQUk7Q0FDakIsTUFBTSxPQUFPLElBQUk7Q0FDakIsTUFBTSxNQUFNQSxVQUFZLElBQUk7Q0FDNUIsSUFBSSxZQUFZO0NBQ2hCLElBQUksYUFBYTtDQUNqQixJQUFJLG1CQUFtQjtDQUN2QixNQUFNLGNBQWMsZUFBZSxPQUFPO0NBRzFDLElBQUlDLFdBQTJCLElBQUksZ0JBQWdCLFNBQVMsT0FBTyxHQUNqRSxhQUFhLENBQUM7Q0FFaEIsU0FBUyxhQUFhO0VBR3BCLE1BQU0sYUFBYSxJQUFJLGlCQUFpQixJQUFJO0VBQzVDLE1BQU0sYUFBYSxJQUFJLGlCQUFpQixJQUFJO0VBRzVDLE1BQU0sd0JBRjJCLFdBQVcsbUJBQW1CLElBQ2pCLFNBQVMsWUFDZixJQUFJLHNCQUFzQjtFQUNsRSxZQUFZLEtBQUs7RUFDakIsYUFBYSxLQUFLO0VBQ2xCLHFCQUFxQjtHQUNuQixpQkFBaUIsS0FBSyxNQUFNO0dBQzVCLFdBQVcsS0FBSyxNQUFNO0dBQ3RCLFdBQVcsS0FBSyxNQUFNO0VBQ3hCO0VBQ0EsNkJBQTZCLEtBQUssTUFBTTtFQUN4QyxxQkFBcUI7R0FDbkIsVUFBVSxLQUFLLE1BQU07R0FDckIsUUFBUSxLQUFLLE1BQU07R0FDbkIsT0FBTyxLQUFLLE1BQU07R0FDbEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsZ0JBQWdCLEtBQUssTUFBTTtFQUM3QjtFQUNBLE1BQU0sZ0JBQWdCLEtBQUssZUFBZSxLQUFLO0VBQy9DLE1BQU0sZ0JBQWdCLEtBQUssY0FBYyxLQUFLO0VBQzlDLE1BQU0sdUJBQXVCLFdBQVcsY0FBYyxZQUFZLFdBQVcsY0FBYztFQUMzRixNQUFNLHVCQUF1QixXQUFXLGNBQWMsWUFBWSxXQUFXLGNBQWM7RUFHM0YsTUFBTSxpQkFBaUIsS0FBSyxJQUFJLEdBQUcsSUFBSSxhQUFhLEtBQUssV0FBVztFQUNwRSxNQUFNLGtCQUFrQixLQUFLLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSyxZQUFZO0VBSXZFLE1BQU0sVUFBVSxXQUFXLFdBQVcsU0FBUyxJQUFJLFdBQVcsV0FBVyxZQUFZO0VBQ3JGLE1BQU0sVUFBVSxXQUFXLFdBQVcsVUFBVSxJQUFJLFdBQVcsV0FBVyxXQUFXO0VBQ3JGLE1BQU0sZ0JBQWdCLG9CQUFvQixNQUFNLElBQUk7RUFDcEQsbUJBQW1CLDhCQUE4QixnQkFBZ0I7RUFPakUsSUFBSSxrQkFBa0I7R0FDcEIsS0FBSyxNQUFNLGtCQUFrQjtHQUM3QixjQUFjLE1BQU0sWUFBWTtHQUNoQyxjQUFjLE1BQU0sWUFBWTtHQUNoQztFQUNGO0VBQ0EsT0FBTyxPQUFPLEtBQUssT0FBTztHQUN4QixpQkFBaUI7R0FDakIsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBQ0QsSUFBSSxpQkFBaUIsc0JBQ25CLEtBQUssTUFBTSxZQUFZO0VBRXpCLElBQUksaUJBQWlCLHNCQUNuQixLQUFLLE1BQU0sWUFBWTtFQUV6QixPQUFPLE9BQU8sS0FBSyxPQUFPO0dBQ3hCLFVBQVU7R0FDVixRQUFRLFdBQVcsa0JBQWtCLGlCQUFpQixVQUFVLGdCQUFnQixPQUFPO0dBQ3ZGLE9BQU8sV0FBVyxpQkFBaUIsZ0JBQWdCLFVBQVUsZUFBZSxPQUFPO0dBQ25GLFdBQVc7R0FFWCxXQUFXO0dBQ1gsV0FBVztHQUNYLGdCQUFnQjtFQUNsQixDQUFDO0VBQ0QsS0FBSyxZQUFZO0VBQ2pCLEtBQUssYUFBYTtFQUNsQixLQUFLLGFBQWEsOEJBQThCLEVBQUU7RUFDbEQsS0FBSyxNQUFNLGlCQUFpQjtDQUM5QjtDQUNBLFNBQVMsVUFBVTtFQUNqQixPQUFPLE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtFQUM1QyxPQUFPLE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtFQUM1QyxJQUFJLENBQUMsa0JBQWtCO0dBQ3JCLEtBQUssWUFBWTtHQUNqQixLQUFLLGFBQWE7R0FDbEIsS0FBSyxnQkFBZ0IsNEJBQTRCO0dBQ2pELEtBQUssTUFBTSxpQkFBaUI7RUFDOUI7Q0FDRjtDQUNBLFNBQVMsZUFBZTtFQUN0QixRQUFRO0VBQ1IsWUFBWSxRQUFRLFVBQVU7Q0FDaEM7Q0FDQSxXQUFXO0NBQ1gsTUFBTSxvQkFBb0IsaUJBQWlCLEtBQUssVUFBVSxZQUFZO0NBQ3RFLGFBQWE7RUFDWCxZQUFZLE9BQU87RUFDbkIsUUFBUTtFQUlSLElBQUksT0FBTyxJQUFJLHdCQUF3QixZQUNyQyxrQkFBa0I7Q0FFdEI7QUFDRjtBQUNBLElBQU0sZUFBTixNQUFtQjtDQUNqQixZQUFZO0NBQ1osVUFBVTtDQUNWLGNBQWMsUUFBUSxPQUFPO0NBQzdCLGdCQUFnQixRQUFRLE9BQU87Q0FDL0IsUUFBUSxrQkFBa0I7RUFDeEIsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxZQUFZLE1BQzNDLEtBQUssWUFBWSxNQUFNLFNBQVMsS0FBSyxLQUFLLGdCQUFnQixDQUFDO0VBRTdELE9BQU8sS0FBSztDQUNkO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxTQUMvQixLQUFLLGNBQWMsTUFBTSxHQUFHLEtBQUssTUFBTTtDQUUzQztDQUNBLGVBQWU7RUFDYixJQUFJLEtBQUssY0FBYyxLQUFLLEtBQUssU0FBUztHQUN4QyxLQUFLLFVBQVU7R0FDZixLQUFLLFVBQVU7RUFDakI7Q0FDRjtDQUNBLEtBQUssa0JBQWtCO0VBQ3JCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxZQUFZLE1BQzNDO0VBRUYsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0VBQzFDLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLE1BQU0sTUFBTUQsVUFBWSxJQUFJO0VBSzVCLElBQUksbUJBQW1CLEtBQUssTUFBTSxJQUFJLEdBQUc7R0FDdkMsTUFBTSxXQUFXLElBQUksSUFBSSx1QkFBdUI7SUFDOUMsSUFBSSxtQkFBbUIsS0FBSyxNQUFNLElBQUksR0FDcEM7SUFFRixTQUFTLFdBQVc7SUFDcEIsS0FBSyxVQUFVO0lBQ2YsS0FBSyxLQUFLLGdCQUFnQjtHQUM1QixDQUFDO0dBSUQsTUFBTSxVQUFVLEVBQ2QsWUFBWSxLQUNkO0dBQ0EsU0FBUyxRQUFRLE1BQU0sT0FBTztHQUM5QixTQUFTLFFBQVEsTUFBTSxPQUFPO0dBQzlCLEtBQUssZ0JBQWdCLFNBQVMsV0FBVztHQUN6QztFQUNGO0VBQ0EsTUFBTSx1QkFBdUJFLE9BQW1CLENBQUMsbUJBQW1CLGdCQUFnQjtFQVFwRixLQUFLLFVBQVUsdUJBQXVCLCtCQUErQixnQkFBZ0IsSUFBSSw2QkFBNkIsZ0JBQWdCO0NBQ3hJO0FBQ0Y7QUFDQSxJQUFNLGdCQUFnQixJQUFJLGFBQWE7Ozs7Ozs7QUFRdkMsU0FBZ0IsY0FBYyxVQUFVLE1BQU0sbUJBQW1CLE1BQU07Q0FDckUseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxTQUNIO0VBRUYsT0FBTyxjQUFjLFFBQVEsZ0JBQWdCO0NBQy9DLEdBQUcsQ0FBQyxTQUFTLGdCQUFnQixDQUFDO0FBQ2hDOzs7QUMvUUEsU0FBZ0IsVUFBVSxPQUFPO0NBQy9CLE1BQU0sZUFBZTtDQUNyQixNQUFNLGdCQUFnQjtBQUN4QjtBQUNBLFNBQWdCLGFBQWEsT0FBTztDQUNsQyxPQUFPLGlCQUFpQjtBQUMxQjtBQUdBLFNBQWdCLGVBQWUsT0FBTztDQUNwQyxJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTSxXQUNwQyxPQUFPO0NBRVQsSUFBSUMsV0FBdUIsTUFBTSxhQUMvQixPQUFPLE1BQU0sU0FBUyxXQUFXLE1BQU0sWUFBWTtDQUVyRCxPQUFPLE1BQU0sV0FBVyxLQUFLLENBQUMsTUFBTTtBQUN0QztBQUNBLFNBQWdCLHNCQUFzQixPQUFPO0NBQzNDLElBQUlDLE9BQ0YsT0FBTztDQUVULE9BQU8sQ0FBQ0QsV0FBdUIsTUFBTSxVQUFVLEtBQUssTUFBTSxXQUFXLEtBQUtBLFdBQXVCLE1BQU0sVUFBVSxLQUFLLE1BQU0sV0FBVyxLQUFLLE1BQU0sYUFBYSxLQUFLLE1BQU0sV0FBVyxLQUFLLE1BQU0sZ0JBQWdCLFdBRWhOLE1BQU0sUUFBUSxLQUFLLE1BQU0sU0FBUyxLQUFLLE1BQU0sYUFBYSxLQUFLLE1BQU0sV0FBVyxLQUFLLE1BQU0sZ0JBQWdCO0FBQzdHO0FBQ0EsU0FBZ0IsdUJBQXVCLGFBQWEsUUFBUTtDQUcxRCxNQUFNLFNBQVMsQ0FBQyxTQUFTLEtBQUs7Q0FDOUIsSUFBSSxDQUFDLFFBQ0gsT0FBTyxLQUFLLElBQUksTUFBUztDQUUzQixPQUFPLE9BQU8sU0FBUyxXQUFXO0FBQ3BDO0FBQ0EsU0FBZ0IsaUJBQWlCLE9BQU87Q0FDdEMsTUFBTSxPQUFPLE1BQU07Q0FDbkIsT0FBTyxTQUFTLFdBQVcsU0FBUyxlQUFlLFNBQVMsYUFBYSxTQUFTO0FBQ3BGOzs7QUN2Q0EsSUFBYSxzQkFBc0I7OztBQ29CbkMsU0FBZ0Isb0JBQW9CLE9BQU8sTUFBTTtDQUMvQyxJQUFJLFFBQVEsTUFDVixPQUFPO0NBRVQsSUFBSSxrQkFBa0IsT0FDcEIsT0FBTyxNQUFNLGFBQWEsQ0FBQyxDQUFDLFNBQVMsSUFBSTtDQUkzQyxNQUFNLGFBQWE7Q0FDbkIsT0FBTyxXQUFXLFVBQVUsUUFBUSxLQUFLLFNBQVMsV0FBVyxNQUFNO0FBQ3JFO0FBQ0EsU0FBZ0IsY0FBYyxTQUFTO0NBQ3JDLE9BQU8sUUFBUSxRQUFRLFdBQVc7QUFDcEM7QUFDQSxTQUFnQixrQkFBa0IsU0FBUztDQUN6QyxPQUFPLGNBQWMsT0FBTyxLQUFLLFFBQVEsOEhBQXlCO0FBQ3BFO0FBSUEsU0FBZ0IsbUJBQW1CLFNBQVM7Q0FDMUMsSUFBSSxDQUFDLFNBQ0gsT0FBTztDQUVULE9BQU8sUUFBUSxhQUFhLE1BQU0sTUFBTSxjQUFjLGtCQUFrQixPQUFPO0FBQ2pGO0FBYUEsU0FBZ0Isd0JBQXdCLGlCQUFpQjtDQUN2RCxJQUFJLENBQUMsaUJBQ0gsT0FBTztDQU1ULE9BQU8sZ0JBQWdCLHFDQUFnQyxJQUFJLGtCQUFrQixnQkFBZ0IsY0FBYywwQkFBMEIsS0FBSztBQUM1STs7Ozs7O0FDakVBLFNBQWdCLGNBQWMsR0FBRyxVQUFVO0NBQ3pDLGFBQWE7RUFDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUssR0FBRztHQUMzQyxNQUFNLFVBQVUsU0FBUztHQUN6QixJQUFJLFNBQ0YsUUFBUTtFQUVaO0NBQ0Y7QUFDRjs7Ozs7Ozs7QUNGQSxTQUFnQixjQUFjLE9BQU87Q0FDbkMsTUFBTSxTQUFTLGVBQWUsaUJBQWlCLEtBQUssQ0FBQyxDQUFDO0NBQ3RELE9BQU8sT0FBTztDQUdkLG1CQUFtQixPQUFPLE1BQU07Q0FDaEMsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixNQUFNLFNBQVM7RUFDYixTQUFTO0VBQ1QsTUFBTTtFQUNOLGNBQWM7R0FDWixPQUFPLFVBQVUsT0FBTztFQUMxQjtDQUNGO0NBQ0EsT0FBTztBQUNUOzs7O0FDaEJBLElBQWEsYUFBMEIsMkJBQU0sV0FBVyxTQUFTLFdBQVcsT0FBTyxLQUFLO0NBQ3RGLE1BQU0sQ0FBQyxNQUFNLHdCQUFpQixTQUFTO0NBQ3ZDLHlCQUF5QjtFQUt2QixJQUFJRSxhQUFtQ0osUUFDckMsUUFBUSxRQUFRO0NBRXBCLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsTUFBTSxZQUFZO0VBQ2hCLFVBQVU7RUFFVjtDQUNGO0NBQ0EsT0FBb0IsMENBQUssUUFBUTtFQUMvQixHQUFHO0VBQ0U7RUFDTCxPQUFPO0VBQ1AsZUFBZSxPQUFPLFNBQVk7RUFDbEMsR0FBRztFQUNILDRCQUE0QjtDQUM5QixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxXQUFXLGNBQWM7OztBQ2hDcEUsSUFBTSxxQkFBcUI7QUFDM0IsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxNQUFNLGVBQWUsUUFBUTtDQUM3QixJQUFJLGNBQ0YsT0FBTztDQUVULElBQUksUUFBUSxlQUNWLE9BQU8sUUFBUTtDQUVqQixNQUFNLFdBQVcsUUFBUSxZQUFZO0NBQ3JDLE9BQU8sYUFBYSxRQUFRLElBQUksU0FBUyxPQUFPO0FBQ2xEO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUztDQUNsQyxLQUFLLE1BQU0sU0FBUyxNQUFNLEtBQUssUUFBUSxRQUFRLEdBQzdDLElBQUksWUFBWSxLQUFLLE1BQU0sV0FDekIsT0FBTztDQUdYLE9BQU87QUFDVDtBQUNBLFNBQVMsMkJBQTJCLFNBQVMsU0FBUztDQUNwRCxNQUFNLFVBQVUsa0JBQWtCLE9BQU87Q0FDekMsT0FBTyxDQUFDLENBQUMsWUFBWSxZQUFZLFdBQVcsU0FBUyxTQUFTLE9BQU87QUFDdkU7QUFDQSxTQUFTLHFCQUFxQixTQUFTO0NBQ3JDLE1BQU0sV0FBVyxVQUFVLFlBQVksT0FBTyxJQUFJO0NBQ2xELE9BQU8sV0FBVyxRQUFRLFFBQVEsUUFBUSxrQkFBa0IsTUFBTSxhQUFhLGFBQWEsUUFBUSxpQkFBaUIsUUFBUSxZQUFZLFFBQVEsYUFBYSxNQUFNLGFBQWEsa0JBQWtCLFFBQVEsYUFBYSxNQUFNLGFBQWEsYUFBYSxhQUFhLGtCQUFrQixPQUFPLEtBQUssVUFBVSxhQUFhLFdBQVcsUUFBUSxTQUFTO0FBQ3hWO0FBQ0EsU0FBUyxtQkFBbUIsU0FBUztDQUNuQyxJQUFJLENBQUMscUJBQXFCLE9BQU8sS0FBSyxDQUFDLFFBQVEsZUFBZSxRQUFRLFFBQVEsV0FBVyxHQUN2RixPQUFPO0NBRVQsS0FBSyxJQUFJLFVBQVUsU0FBUyxTQUFTLFVBQVUsaUJBQWlCLE9BQU8sR0FBRztFQUN4RSxNQUFNLGFBQWEsWUFBWTtFQUMvQixNQUFNLFNBQVMsWUFBWSxPQUFPLE1BQU07RUFDeEMsSUFBSSxRQUFRLGFBQWEsT0FBTyxHQUM5QixPQUFPO0VBRVQsSUFBSSxjQUFjLFlBQVksT0FBTyxNQUFNLGFBQWEsQ0FBQyxRQUFRLFFBQVEsQ0FBQywyQkFBMkIsU0FBUyxPQUFPLEtBQUssUUFBUSxhQUFhLFFBQVEsS0FBSyxDQUFDLFVBQVUsQ0FBQyx3QkFBd0IsU0FBUyxVQUFVLEdBQ2pOLE9BQU87Q0FFWDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsd0JBQXdCLFNBQVMsWUFBWTtDQUNwRCxNQUFNLFNBQVMsaUJBQWlCLE9BQU87Q0FDdkMsSUFBSSxDQUFDLFlBQ0gsT0FBTyxpQkFBaUIsU0FBUyxNQUFNO0NBRXpDLE9BQU8sT0FBTyxZQUFZO0FBQzVCO0FBQ0EsU0FBUyxZQUFZLFNBQVM7Q0FDNUIsTUFBTSxXQUFXLFFBQVE7Q0FDekIsSUFBSSxXQUFXLEdBQUc7RUFDaEIsTUFBTSxXQUFXLFlBQVksT0FBTztFQUNwQyxJQUFJLGFBQWEsYUFBYSxhQUFhLFdBQVcsYUFBYSxXQUFXLGNBQWMsT0FBTyxLQUFLLFFBQVEsbUJBQzlHLE9BQU87Q0FFWDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsbUJBQW1CLFNBQVM7Q0FDbkMsSUFBSSxZQUFZLE9BQU8sTUFBTSxTQUMzQixPQUFPO0NBRVQsTUFBTSxRQUFRO0NBQ2QsT0FBTyxNQUFNLFNBQVMsV0FBVyxNQUFNLFNBQVMsS0FBSyxRQUFRO0FBQy9EO0FBQ0EsU0FBUyxnQkFBZ0IsU0FBUyxZQUFZO0NBQzVDLE1BQU0sUUFBUSxtQkFBbUIsT0FBTztDQUN4QyxJQUFJLENBQUMsT0FDSCxPQUFPO0NBRVQsTUFBTSxlQUFlLFdBQVcsTUFBSyxjQUFhO0VBQ2hELE1BQU0sUUFBUSxtQkFBbUIsU0FBUztFQUMxQyxPQUFPLE9BQU8sU0FBUyxNQUFNLFFBQVEsTUFBTSxTQUFTLE1BQU0sUUFBUSxNQUFNO0NBQzFFLENBQUM7Q0FDRCxJQUFJLGNBQ0YsT0FBTyxpQkFBaUI7Q0FFMUIsT0FBTyxXQUFXLE1BQUssY0FBYTtFQUNsQyxNQUFNLFFBQVEsbUJBQW1CLFNBQVM7RUFDMUMsT0FBTyxPQUFPLFNBQVMsTUFBTSxRQUFRLE1BQU0sU0FBUyxNQUFNO0NBQzVELENBQUMsTUFBTTtBQUNUO0FBQ0EsU0FBUyxvQkFBb0IsV0FBVztDQUN0QyxJQUFJLGNBQWMsU0FBUyxLQUFLLFlBQVksU0FBUyxNQUFNLFFBQVE7RUFDakUsTUFBTSxtQkFBbUIsVUFBVSxpQkFBaUIsRUFDbEQsU0FBUyxLQUNYLENBQUM7RUFDRCxJQUFJLGlCQUFpQixTQUFTLEdBQzVCLE9BQU87Q0FFWDtDQUNBLElBQUksY0FBYyxTQUFTLEtBQUssVUFBVSxZQUN4QyxPQUFPLE1BQU0sS0FBSyxVQUFVLFdBQVcsUUFBUTtDQUVqRCxPQUFPLE1BQU0sS0FBSyxVQUFVLFFBQVE7QUFDdEM7QUFDQSxTQUFTLGlCQUFpQixXQUFXLE1BQU07Q0FDekMsb0JBQW9CLFNBQVMsQ0FBQyxDQUFDLFNBQVEsVUFBUztFQUM5QyxJQUFJLHFCQUFxQixLQUFLLEdBQzVCLEtBQUssS0FBSyxLQUFLO0VBRWpCLGlCQUFpQixPQUFPLElBQUk7Q0FDOUIsQ0FBQztBQUNIO0FBQ0EsU0FBUyx1QkFBdUIsV0FBVyxVQUFVLE1BQU07Q0FDekQsb0JBQW9CLFNBQVMsQ0FBQyxDQUFDLFNBQVEsVUFBUztFQUM5QyxJQUFJLGNBQWMsS0FBSyxLQUFLLE1BQU0sUUFBUSxRQUFRLEdBQ2hELEtBQUssS0FBSyxLQUFLO0VBRWpCLHVCQUF1QixPQUFPLFVBQVUsSUFBSTtDQUM5QyxDQUFDO0FBQ0g7QUFDQSxTQUFnQixXQUFXLFNBQVM7Q0FDbEMsT0FBTyxtQkFBbUIsT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLO0FBQ2hFO0FBQ0EsU0FBZ0IsVUFBVSxXQUFXO0NBQ25DLE1BQU0sYUFBYSxDQUFDO0NBQ3BCLGlCQUFpQixXQUFXLFVBQVU7Q0FDdEMsT0FBTyxXQUFXLE9BQU8sa0JBQWtCO0FBQzdDO0FBQ0EsU0FBZ0IsU0FBUyxXQUFXO0NBQ2xDLE1BQU0sYUFBYSxVQUFVLFNBQVM7Q0FDdEMsT0FBTyxXQUFXLFFBQU8sWUFBVyxZQUFZLE9BQU8sS0FBSyxLQUFLLGdCQUFnQixTQUFTLFVBQVUsQ0FBQztBQUN2RztBQUNBLFNBQVMsY0FBYyxXQUFXLEtBQUs7Q0FDckMsTUFBTSxPQUFPLFNBQVMsU0FBUztDQUMvQixNQUFNLE1BQU0sS0FBSztDQUNqQixJQUFJLFFBQVEsR0FDVjtDQUVGLE1BQU0sU0FBUyxjQUFjLGNBQWMsU0FBUyxDQUFDO0NBQ3JELE1BQU0sUUFBUSxLQUFLLFFBQVEsTUFBTTtDQUdqQyxPQUFPLEtBRFcsVUFBVSxLQUFLLFFBQVEsSUFBSSxJQUFJLE1BQU0sSUFBSSxRQUFRO0FBRXJFO0FBQ0EsU0FBZ0IsZ0JBQWdCLGtCQUFrQjtDQUNoRCxPQUFPLGNBQWMsY0FBYyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ25FO0FBQ0EsU0FBZ0Isb0JBQW9CLGtCQUFrQjtDQUNwRCxPQUFPLGNBQWMsY0FBYyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLO0FBQ3BFO0FBdUJBLFNBQWdCLGVBQWUsT0FBTyxXQUFXO0NBQy9DLE1BQU0sbUJBQW1CLGFBQWEsTUFBTTtDQUM1QyxNQUFNLGdCQUFnQixNQUFNO0NBQzVCLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLGtCQUFrQixhQUFhO0FBQ3BFO0FBQ0EsU0FBZ0IsbUJBQW1CLFdBQVc7Q0FFNUMsU0FEa0MsU0FDbkIsQ0FBQyxDQUFDLFNBQVEsWUFBVztFQUNsQyxRQUFRLFFBQVEsV0FBVyxRQUFRLGFBQWEsVUFBVSxLQUFLO0VBQy9ELFFBQVEsYUFBYSxZQUFZLElBQUk7Q0FDdkMsQ0FBQztBQUNIO0FBQ0EsU0FBZ0Isa0JBQWtCLFdBQVc7Q0FDM0MsTUFBTSxXQUFXLENBQUM7Q0FDbEIsdUJBQXVCLFdBQVcsbUJBQW1CLFFBQVE7Q0FDN0QsU0FBUyxTQUFRLFlBQVc7RUFDMUIsTUFBTSxXQUFXLFFBQVEsUUFBUTtFQUNqQyxPQUFPLFFBQVEsUUFBUTtFQUN2QixJQUFJLFVBQ0YsUUFBUSxhQUFhLFlBQVksUUFBUTtPQUV6QyxRQUFRLGdCQUFnQixVQUFVO0NBRXRDLENBQUM7QUFDSDs7O0FDak1BLFNBQWdCLGdCQUFnQixPQUFPLElBQUksbUJBQW1CLE1BQU07Q0FFbEUsT0FEdUIsTUFBTSxRQUFPLFNBQVEsS0FBSyxhQUFhLEVBQzFDLENBQUMsQ0FBQyxTQUFRLFVBQVMsQ0FBQyxHQUFJLENBQUMsb0JBQW9CLE1BQU0sU0FBUyxPQUFPLENBQUMsS0FBSyxJQUFJLENBQUMsR0FBSSxHQUFHLGdCQUFnQixPQUFPLE1BQU0sSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzlKO0FBaUJBLFNBQWdCLGlCQUFpQixPQUFPLElBQUk7Q0FDMUMsSUFBSSxlQUFlLENBQUM7Q0FDcEIsSUFBSSxrQkFBa0IsTUFBTSxNQUFLLFNBQVEsS0FBSyxPQUFPLEVBQUUsQ0FBQyxFQUFFO0NBQzFELE9BQU8saUJBQWlCO0VBQ3RCLE1BQU0sY0FBYyxNQUFNLE1BQUssU0FBUSxLQUFLLE9BQU8sZUFBZTtFQUNsRSxrQkFBa0IsYUFBYTtFQUMvQixJQUFJLGFBQ0YsZUFBZSxhQUFhLE9BQU8sV0FBVztDQUVsRDtDQUNBLE9BQU87QUFDVDs7O0FDakNBLFNBQWdCLGdCQUFnQixNQUFNO0NBQ3BDLE9BQU8sZ0JBQWdCO0FBQ3pCOzs7QUNEQSxJQUFJLFFBQVE7QUFDWixTQUFnQixhQUFhLElBQUksVUFBVSxDQUFDLEdBQUc7Q0FDN0MsTUFBTSxFQUNKLGdCQUFnQixPQUNoQixPQUFPLE9BQ1AsZ0JBQ0U7Q0FDSixxQkFBcUIsS0FBSztDQUMxQixTQUFTLE9BQU87RUFDZCxJQUFJLGVBQWUsQ0FBQyxZQUFZLEdBQzlCO0VBRUYsSUFBSSxNQUFNLEVBQ1IsY0FDRixDQUFDO0NBQ0g7Q0FDQSxJQUFJLE1BQU07RUFDUixLQUFLO0VBQ0wsT0FBTztDQUNUO0NBQ0EsTUFBTSxlQUFlLHNCQUFzQixJQUFJO0NBQy9DLFFBQVE7Q0FDUixhQUFhO0VBQ1gsSUFBSSxVQUFVLGNBQWM7R0FDMUIscUJBQXFCLFlBQVk7R0FDakMsUUFBUTtFQUNWO0NBQ0Y7QUFDRjs7O0FDekJBLElBQU0sV0FBVztDQUNmLHVCQUFPLElBQUksUUFBUTtDQUNuQiwrQkFBZSxJQUFJLFFBQVE7QUFDN0I7QUFDQSxJQUFNLGFBQWE7QUFDbkIsSUFBTSwyQkFBMkI7Q0FDL0IsdUJBQU8sSUFBSSxRQUFRO0NBQ25CLCtCQUFlLElBQUksUUFBUTtBQUM3QjtBQUNBLElBQUksbUNBQW1CLElBQUksUUFBUTtBQUNuQyxJQUFJLFlBQVk7QUFDaEIsU0FBUywyQkFBMkIsa0JBQWtCO0NBQ3BELE9BQU8seUJBQXlCO0FBQ2xDO0FBQ0EsU0FBUyxXQUFXLE1BQU07Q0FDeEIsSUFBSSxDQUFDLE1BQ0gsT0FBTztDQUVULE9BQU8sYUFBYSxJQUFJLElBQUksS0FBSyxPQUFPLFdBQVcsS0FBSyxVQUFVO0FBQ3BFO0FBQ0EsSUFBTSxtQkFBbUIsUUFBUSxZQUFZLFFBQVEsS0FBSSxXQUFVO0NBQ2pFLElBQUksT0FBTyxTQUFTLE1BQU0sR0FDeEIsT0FBTztDQUVULE1BQU0sa0JBQWtCLFdBQVcsTUFBTTtDQUN6QyxJQUFJLE9BQU8sU0FBUyxlQUFlLEdBQ2pDLE9BQU87Q0FFVCxPQUFPO0FBQ1QsQ0FBQyxDQUFDLENBQUMsUUFBTyxNQUFLLEtBQUssSUFBSTtBQUN4QixJQUFNLGdCQUFlLFlBQVc7Q0FDOUIsTUFBTSx1QkFBTyxJQUFJLElBQUk7Q0FDckIsUUFBUSxTQUFRLFdBQVU7RUFDeEIsSUFBSSxPQUFPO0VBQ1gsT0FBTyxRQUFRLENBQUMsS0FBSyxJQUFJLElBQUksR0FBRztHQUM5QixLQUFLLElBQUksSUFBSTtHQUNiLE9BQU8sS0FBSztFQUNkO0NBQ0YsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLElBQU0sMEJBQTBCLE1BQU0sY0FBYyxpQkFBaUI7Q0FDbkUsTUFBTSxVQUFVLENBQUM7Q0FDakIsTUFBTSxRQUFPLFdBQVU7RUFDckIsSUFBSSxDQUFDLFVBQVUsYUFBYSxJQUFJLE1BQU0sR0FDcEM7RUFFRixNQUFNLEtBQUssT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFRLFNBQVE7R0FDMUMsSUFBSSxZQUFZLElBQUksTUFBTSxVQUN4QjtHQUVGLElBQUksYUFBYSxJQUFJLElBQUksR0FDdkIsS0FBSyxJQUFJO1FBRVQsUUFBUSxLQUFLLElBQUk7RUFFckIsQ0FBQztDQUNIO0NBQ0EsS0FBSyxJQUFJO0NBQ1QsT0FBTztBQUNUO0FBQ0EsU0FBUyx1QkFBdUIsMEJBQTBCLE1BQU0sWUFBWSxPQUFPLEVBQ2pGLE9BQU8sUUFDTjtDQUNELElBQUksbUJBQW1CO0NBQ3ZCLElBQUksT0FDRixtQkFBbUI7TUFDZCxJQUFJLFlBQ1QsbUJBQW1CO0NBRXJCLElBQUksYUFBYTtDQUNqQixJQUFJLDBCQUEwQjtDQUM5QixNQUFNLGdCQUFnQixnQkFBZ0IsTUFBTSx3QkFBd0I7Q0FDcEUsTUFBTSxnQkFBZ0IsT0FBTyx1QkFBdUIsTUFBTSxhQUFhLGFBQWEsR0FBRyxJQUFJLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQztDQUNsSCxNQUFNLGlCQUFpQixDQUFDO0NBQ3hCLE1BQU0saUJBQWlCLENBQUM7Q0FDeEIsSUFBSSxrQkFBa0I7RUFDcEIsTUFBTSxNQUFNLFNBQVM7RUFDckIsTUFBTSxpQ0FBaUMsMkJBQTJCLGdCQUFnQjtFQUNsRiwwQkFBMEI7RUFDMUIsYUFBYTtFQUNiLE1BQU0sbUJBQW1CLGdCQUFnQixNQUFNLE1BQU0sS0FBSyxLQUFLLGlCQUFpQixhQUFhLENBQUMsQ0FBQztFQUMvRixNQUFNLGtCQUFrQixjQUFjLE9BQU8sZ0JBQWdCO0VBRTdELHVCQUQ4QyxNQUFNLGFBQWEsZUFBZSxHQUFHLElBQUksSUFBSSxlQUFlLENBQzdGLENBQUMsQ0FBQyxTQUFRLFNBQVE7R0FDN0IsTUFBTSxPQUFPLEtBQUssYUFBYSxnQkFBZ0I7R0FDL0MsTUFBTSxnQkFBZ0IsU0FBUyxRQUFRLFNBQVM7R0FDaEQsTUFBTSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksS0FBSyxLQUFLO0dBQzVDLElBQUksSUFBSSxNQUFNLFlBQVk7R0FDMUIsZUFBZSxLQUFLLElBQUk7R0FDeEIsSUFBSSxpQkFBaUIsS0FBSyxlQUN4QiwrQkFBK0IsSUFBSSxJQUFJO0dBRXpDLElBQUksQ0FBQyxlQUNILEtBQUssYUFBYSxrQkFBa0IscUJBQXFCLFVBQVUsS0FBSyxNQUFNO0VBRWxGLENBQUM7Q0FDSDtDQUNBLElBQUksTUFDRixjQUFjLFNBQVEsU0FBUTtFQUM1QixNQUFNLGVBQWUsaUJBQWlCLElBQUksSUFBSSxLQUFLLEtBQUs7RUFDeEQsaUJBQWlCLElBQUksTUFBTSxXQUFXO0VBQ3RDLGVBQWUsS0FBSyxJQUFJO0VBQ3hCLElBQUksZ0JBQWdCLEdBQ2xCLEtBQUssYUFBYSxZQUFZLEVBQUU7Q0FFcEMsQ0FBQztDQUVILGFBQWE7Q0FDYixhQUFhO0VBQ1gsSUFBSSxZQUNGLGVBQWUsU0FBUSxZQUFXO0dBRWhDLE1BQU0sZ0JBRHNCLFdBQVcsSUFBSSxPQUFPLEtBQUssS0FDWjtHQUMzQyxXQUFXLElBQUksU0FBUyxZQUFZO0dBQ3BDLElBQUksQ0FBQyxjQUFjO0lBQ2pCLElBQUksQ0FBQyx5QkFBeUIsSUFBSSxPQUFPLEtBQUssa0JBQzVDLFFBQVEsZ0JBQWdCLGdCQUFnQjtJQUUxQyx5QkFBeUIsT0FBTyxPQUFPO0dBQ3pDO0VBQ0YsQ0FBQztFQUVILElBQUksTUFDRixlQUFlLFNBQVEsWUFBVztHQUNoQyxNQUFNLGVBQWUsaUJBQWlCLElBQUksT0FBTyxLQUFLLEtBQUs7R0FDM0QsaUJBQWlCLElBQUksU0FBUyxXQUFXO0dBQ3pDLElBQUksQ0FBQyxhQUNILFFBQVEsZ0JBQWdCLFVBQVU7RUFFdEMsQ0FBQztFQUVILGFBQWE7RUFDYixJQUFJLENBQUMsV0FBVztHQUNkLFNBQVMsd0JBQVEsSUFBSSxRQUFRO0dBQzdCLFNBQVMsaUNBQWlCLElBQUksUUFBUTtHQUN0Qyx5QkFBeUIsd0JBQVEsSUFBSSxRQUFRO0dBQzdDLHlCQUF5QixpQ0FBaUIsSUFBSSxRQUFRO0dBQ3RELG1DQUFtQixJQUFJLFFBQVE7RUFDakM7Q0FDRjtBQUNGO0FBQ0EsU0FBZ0IsV0FBVyxlQUFlLFVBQVUsQ0FBQyxHQUFHO0NBQ3RELE1BQU0sRUFDSixhQUFhLE9BQ2IsUUFBUSxPQUNSLE9BQU8sU0FDTDtDQUNKLE1BQU0sT0FBTyxjQUFjLGNBQWMsRUFBRSxDQUFDLENBQUM7Q0FDN0MsT0FBTyx1QkFBdUIsZUFBZSxNQUFNLFlBQVksT0FBTyxFQUNwRSxLQUNGLENBQUM7QUFDSDs7O0FDckpBLElBQWEsMkJBQTJCO0FBQ3hDLElBQWEsaUNBQWlDO0FBQzlDLElBQWEsZ0NBQWdDO0FBQ0EsR0FBSTtBQUNMLEdBQUk7Ozs7Ozs7QUF3QmhELElBQWEsc0JBQXNCO0NBQ2pDLFVBQVU7Q0FDVixVQUFVO0NBQ1YsS0FBSztDQUNMLE1BQU07QUFDUjs7OztBQ3JCQSxJQUFNLGdCQUE2QiwyQkFBTSxjQUFjLElBQUk7QUFDaEIsY0FBYyxjQUFjO0FBQ3ZFLElBQWEsc0NBQStCLFdBQVcsYUFBYTtBQUNwRSxJQUFNLE9BQU8sZ0JBQWdCLFFBQVE7QUFDckMsU0FBZ0Isc0JBQXNCLFFBQVEsQ0FBQyxHQUFHO0NBQ2hELE1BQU0sRUFDSixLQUNBLFdBQVcsZUFDWCxpQkFBaUIsY0FDakIsaUJBQ0U7Q0FDSixNQUFNLFdBQVcsTUFBTTtDQUV2QixNQUFNLG1CQURnQixpQkFDZSxDQUFDLEVBQUU7Q0FDeEMsTUFBTSxDQUFDLGtCQUFrQixvQ0FBNkIsU0FBUyxJQUFJO0NBQ25FLE1BQU0sQ0FBQyxZQUFZLDhCQUF1QixTQUFTLElBQUk7Q0FDdkQsTUFBTSxtQkFBbUIsbUJBQWtCLFNBQVE7RUFDakQsSUFBSSxTQUFTLE1BSVgsY0FBYyxJQUFJO0NBRXRCLENBQUM7Q0FDRCxNQUFNLDRCQUFxQixPQUFPLElBQUk7Q0FDdEMseUJBQXlCO0VBRXZCLElBQUksa0JBQWtCLE1BQU07R0FDMUIsSUFBSSxhQUFhLFNBQVM7SUFDeEIsYUFBYSxVQUFVO0lBQ3ZCLGNBQWMsSUFBSTtJQUNsQixvQkFBb0IsSUFBSTtHQUMxQjtHQUNBO0VBQ0Y7RUFDQSxNQUFNLHFCQUFxQixrQkFBa0IsT0FBTyxhQUFhLElBQUksZ0JBQWdCLGNBQWMsYUFBYSxvQkFBb0IsU0FBUztFQUM3SSxJQUFJLHFCQUFxQixNQUFNO0dBQzdCLElBQUksYUFBYSxTQUFTO0lBQ3hCLGFBQWEsVUFBVTtJQUN2QixjQUFjLElBQUk7SUFDbEIsb0JBQW9CLElBQUk7R0FDMUI7R0FDQTtFQUNGO0VBQ0EsSUFBSSxhQUFhLFlBQVksbUJBQW1CO0dBQzlDLGFBQWEsVUFBVTtHQUN2QixjQUFjLElBQUk7R0FDbEIsb0JBQW9CLGlCQUFpQjtFQUN2QztDQUNGLEdBQUcsQ0FBQyxlQUFlLGdCQUFnQixDQUFDO0NBQ3BDLE1BQU0sZ0JBQWdCLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM1RCxLQUFLLENBQUMsS0FBSyxnQkFBZ0I7RUFDM0IsT0FBTyxDQUFDO0dBQ04sSUFBSTtJQUNILE9BQU87RUFDVixHQUFHLFlBQVk7Q0FDakIsQ0FBQztDQUlELE1BQU0sZ0JBQWdCLG9CQUFvQixnQkFBNkIsK0JBQVMsYUFBYSxlQUFlLGdCQUFnQixJQUFJO0NBQ2hJLE9BQU87RUFDTCxNQUFNO0VBR04sUUFBcUIsMkJBQU0sZUFBZSxhQUFhLElBQUksY0FBYyxNQUFNLEtBQUs7RUFDcEYsU0FBUztDQUNYO0FBQ0Y7Ozs7Ozs7Ozs7QUFXQSxJQUFhLGlCQUE4QiwyQkFBTSxXQUFXLFNBQVMsZUFBZSxnQkFBZ0IsY0FBYztDQUNoSCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsVUFDQSxXQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLEVBQ0osTUFBTSxZQUNOLFFBQVEsY0FDUixTQUFTLGtCQUNQLHNCQUFzQjtFQUN4QjtFQUNBLEtBQUs7RUFDTDtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sZ0NBQXlCLE9BQU8sSUFBSTtDQUMxQyxNQUFNLCtCQUF3QixPQUFPLElBQUk7Q0FDekMsTUFBTSwrQkFBd0IsT0FBTyxJQUFJO0NBQ3pDLE1BQU0sOEJBQXVCLE9BQU8sSUFBSTtDQUN4QyxNQUFNLENBQUMsbUJBQW1CLHFDQUE4QixTQUFTLElBQUk7Q0FDckUsTUFBTSxzQ0FBK0IsT0FBTyxLQUFLO0NBQ2pELE1BQU0sUUFBUSxtQkFBbUI7Q0FDakMsTUFBTSxPQUFPLG1CQUFtQjtDQUNoQyxNQUFNLHFCQUFxQixDQUFDLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLFNBQVMsa0JBQWtCLFFBQVEsQ0FBQyxDQUFDO0NBRzFHLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxjQUFjLE9BQ2pCO0VBTUYsU0FBUyxRQUFRLE9BQU87R0FDdEIsSUFBSSxjQUFjLE1BQU0saUJBQWlCLGVBQWUsS0FBSyxHQUFHO0lBQzlELElBQUksTUFBTSxTQUFTLFdBQ2I7U0FBQSx1QkFBdUIsU0FBUztNQUNsQyxrQkFBa0IsVUFBVTtNQUM1Qix1QkFBdUIsVUFBVTtLQUNuQztXQUNLO0tBQ0wsbUJBQW1CLFVBQVU7S0FDN0IsdUJBQXVCLFVBQVU7SUFDbkM7R0FDRjtFQUNGO0VBSUEsT0FBTyxjQUFjLGlCQUFpQixZQUFZLFdBQVcsU0FBUyxJQUFJLEdBQUcsaUJBQWlCLFlBQVksWUFBWSxTQUFTLElBQUksQ0FBQztDQUN0SSxHQUFHLENBQUMsWUFBWSxLQUFLLENBQUM7Q0FDdEIseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxjQUFjLFNBQVMsUUFBUSxDQUFDLHVCQUF1QixTQUMxRDtFQUlGLGtCQUFrQixVQUFVO0VBQzVCLHVCQUF1QixVQUFVO0NBQ25DLEdBQUcsQ0FBQyxNQUFNLFVBQVUsQ0FBQztDQUNyQixNQUFNLGtDQUEyQixlQUFlO0VBQzlDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLElBQUksQ0FBQyxVQUFVLENBQUM7Q0FDaEIsT0FBb0Isd0RBQVksVUFBVSxFQUN4QyxVQUFVLENBQUMsZUFBNEIsMkNBQU0sY0FBYyxVQUFVO0VBQ25FLE9BQU87RUFDUCxVQUFVO0dBQUMsc0JBQXNCLGNBQTJCLDBDQUFLLFlBQVk7SUFDM0UsYUFBYTtJQUNiLEtBQUs7SUFDTCxVQUFTLFVBQVM7S0FDaEIsSUFBSSxlQUFlLE9BQU8sVUFBVSxHQUNsQyxnQkFBZ0IsU0FBUyxNQUFNO1VBSS9CLG9CQUZxQixvQkFBb0Isa0JBQWtCLGVBQWUsSUFFL0QsQ0FBQyxFQUFFLE1BQU07SUFFeEI7R0FDRixDQUFDO0dBQUcsc0JBQXNCLGNBQTJCLDBDQUFLLFFBQVE7SUFDaEUsYUFBYTtJQUNiLE9BQU87R0FDVCxDQUFDO0dBQUcsY0FBMkIsK0JBQVMsYUFBYSxVQUFVLFVBQVU7R0FBRyxzQkFBc0IsY0FBMkIsMENBQUssWUFBWTtJQUM1SSxhQUFhO0lBQ2IsS0FBSztJQUNMLFVBQVMsVUFBUztLQUNoQixJQUFJLGVBQWUsT0FBTyxVQUFVLEdBQ2xDLGVBQWUsU0FBUyxNQUFNO1VBQ3pCO01BR0wsZ0JBRnFCLG9CQUFvQixrQkFBa0IsZUFBZSxJQUUvRCxDQUFDLEVBQUUsTUFBTTtNQUNwQixJQUFJLG1CQUFtQixpQkFDckIsbUJBQW1CLGFBQWEsT0FBTyx5QkFBeUIsYUFBa0IsTUFBTSxXQUFXLENBQUM7S0FFeEc7SUFDRjtHQUNGLENBQUM7RUFBQztDQUNKLENBQUMsQ0FBQyxFQUNKLENBQUM7QUFDSCxDQUFDO0FBQzBDLGVBQWUsY0FBYzs7O0FDaE54RSxTQUFnQixxQkFBcUI7Q0FDbkMsTUFBTSxzQkFBTSxJQUFJLElBQUk7Q0FDcEIsT0FBTztFQUNMLEtBQUssT0FBTyxNQUFNO0dBQ2hCLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRSxTQUFRLGFBQVksU0FBUyxJQUFJLENBQUM7RUFDcEQ7RUFDQSxHQUFHLE9BQU8sVUFBVTtHQUNsQixJQUFJLENBQUMsSUFBSSxJQUFJLEtBQUssR0FDaEIsSUFBSSxJQUFJLHVCQUFPLElBQUksSUFBSSxDQUFDO0dBRTFCLElBQUksSUFBSSxLQUFLLENBQUMsQ0FBQyxJQUFJLFFBQVE7RUFDN0I7RUFDQSxJQUFJLE9BQU8sVUFBVTtHQUNuQixJQUFJLElBQUksS0FBSyxDQUFDLEVBQUUsT0FBTyxRQUFRO0VBQ2pDO0NBQ0Y7QUFDRjs7O0FDUkEsSUFBTSxzQkFBbUMsMkJBQU0sY0FBYyxJQUFJO0FBQ3RCLG9CQUFvQixjQUFjO0FBQzdFLElBQU0sc0JBQW1DLDJCQUFNLGNBQWMsSUFBSTtBQU10QixvQkFBb0IsY0FBYztBQUM3RSxJQUFhLDZDQUFzQyxXQUFXLG1CQUFtQixDQUFDLEVBQUUsTUFBTTs7OztBQUsxRixJQUFhLG1CQUFrQixpQkFBZ0I7Q0FDN0MsTUFBTSwyQkFBb0IsV0FBVyxtQkFBbUI7Q0FDeEQsT0FBTyxnQkFBZ0I7QUFDekI7OztBQ0tBLFNBQVMsYUFBYSxPQUFPLHFCQUFxQjtDQUNoRCxNQUFNLE1BQU1ELFVBQVksVUFBVSxLQUFLLENBQUM7Q0FDeEMsSUFBSSxpQkFBaUIsSUFBSSxlQUN2QixPQUFPO0NBRVQsSUFBSSxpQkFBaUIsSUFBSSxZQUd2QixPQUFPLHVCQUF1QjtDQUVoQyxJQUFJLGlCQUFpQixPQUNuQixPQUFPLE1BQU0sZUFBZTtDQUU5QixJQUFJLGFBQWEsT0FDZixPQUFPO0NBRVQsSUFBSSxpQkFBaUIsSUFBSSxZQUV2QixPQUFPLHdCQUF3QixNQUFNLFdBQVcsSUFBSSxhQUFhO0NBRW5FLE9BQU87QUFDVDtBQUNBLElBQU0sYUFBYTtBQUNuQixJQUFJLDRCQUE0QixDQUFDO0FBQ2pDLFNBQVMsNkNBQTZDO0NBQ3BELDRCQUE0QiwwQkFBMEIsUUFBTyxVQUFTO0VBQ3BFLE9BQU8sTUFBTSxNQUFNLENBQUMsRUFBRTtDQUN4QixDQUFDO0FBQ0g7QUFDQSxTQUFTLDRCQUE0QixTQUFTO0NBQzVDLDJDQUEyQztDQUMzQyxJQUFJLFdBQVcsWUFBWSxPQUFPLE1BQU0sUUFBUTtFQUM5QywwQkFBMEIsS0FBSyxJQUFJLFFBQVEsT0FBTyxDQUFDO0VBQ25ELElBQUksMEJBQTBCLFNBQVMsWUFDckMsNEJBQTRCLDBCQUEwQixNQUFNLEdBQVc7Q0FFM0U7QUFDRjtBQUNBLFNBQVMsOEJBQThCO0NBQ3JDLDJDQUEyQztDQUMzQyxPQUFPLDBCQUEwQiwwQkFBMEIsU0FBUyxFQUFFLEVBQUUsTUFBTTtBQUNoRjtBQUNBLFNBQVMsd0JBQXdCLFdBQVc7Q0FDMUMsSUFBSSxDQUFDLFdBQ0gsT0FBTztDQUVULElBQUksV0FBVyxTQUFTLEdBQ3RCLE9BQU87Q0FFVCxPQUFPLFNBQVMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUNuQztBQUNBLFNBQVMsZUFBZSxzQkFBc0I7Q0FDNUMsSUFBSSxxQkFBcUIsYUFBYSxVQUFVLEtBQUssQ0FBQyxxQkFBcUIsYUFBYSxlQUFlLEdBQ3JHO0NBRUYsSUFBSSxDQUFDLHFCQUFxQixhQUFhLE1BQU0sQ0FBQyxFQUFFLFNBQVMsUUFBUSxHQUMvRDtDQUdGLE1BQU0sa0JBRG9CLFVBQVUsb0JBQ0ksQ0FBQyxDQUFDLFFBQU8sWUFBVztFQUMxRCxNQUFNLGVBQWUsUUFBUSxhQUFhLGVBQWUsS0FBSztFQUM5RCxPQUFPLFdBQVcsT0FBTyxLQUFLLFFBQVEsYUFBYSxlQUFlLEtBQUssQ0FBQyxhQUFhLFdBQVcsR0FBRztDQUNyRyxDQUFDO0NBQ0QsTUFBTSxXQUFXLHFCQUFxQixhQUFhLFVBQVU7Q0FDN0QsSUFBSSxnQkFBZ0IsV0FBVyxHQUN6QjtNQUFBLGFBQWEsS0FBSztHQUNwQixxQkFBcUIsYUFBYSxZQUFZLEdBQUc7R0FHakQscUJBQXFCLGFBQWEsaUJBQWlCLEdBQUc7RUFDeEQ7UUFDSyxJQUFJLGFBQWEsUUFBUSxxQkFBcUIsYUFBYSxlQUFlLEtBQUsscUJBQXFCLGFBQWEsZUFBZSxNQUFNLE1BQU07RUFDakoscUJBQXFCLGFBQWEsWUFBWSxJQUFJO0VBQ2xELHFCQUFxQixhQUFhLGlCQUFpQixJQUFJO0NBQ3pEO0FBQ0Y7Ozs7OztBQU1BLFNBQWdCLHFCQUFxQixPQUFPO0NBQzFDLE1BQU0sRUFDSixTQUNBLFVBQ0EsV0FBVyxPQUNYLGVBQWUsTUFDZixjQUFjLE1BQ2QsZUFBZSxPQUNmLFFBQVEsTUFDUixrQkFBa0IsTUFDbEIsc0JBQXNCLElBQ3RCLHNCQUNBLDBCQUNBLDRCQUNBLGNBQ0Esc0JBQ0U7Q0FDSixNQUFNLFFBQVEsZUFBZSxVQUFVLFFBQVEsWUFBWTtDQUMzRCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxlQUFlLE1BQU0sU0FBUyxxQkFBcUI7Q0FDekQsTUFBTSxXQUFXLE1BQU0sU0FBUyxpQkFBaUI7Q0FDakQsTUFBTSxFQUNKLFFBQ0EsWUFDRSxNQUFNO0NBQ1YsTUFBTSxZQUFZLHdCQUF3QixRQUFRLFFBQVEsaUJBQWlCLE1BQU07Q0FDakYsTUFBTSxxQkFBcUIsaUJBQWlCO0NBSzVDLE1BQU0sOEJBQThCLG1CQUFtQixZQUFZLEtBQUs7Q0FDeEUsTUFBTSxrQkFBa0IsY0FBYyxZQUFZO0NBQ2xELE1BQU0saUJBQWlCLGNBQWMsV0FBVztDQUNoRCxNQUFNLHlCQUF5QixjQUFjLG1CQUFtQjtDQUNoRSxNQUFNLFVBQVUsY0FBYyxJQUFJO0NBQ2xDLE1BQU0sT0FBTyxnQkFBZ0IsWUFBWTtDQUN6QyxNQUFNLGdCQUFnQixpQkFBaUI7Q0FDdkMsTUFBTSxxQ0FBOEIsT0FBTyxLQUFLO0NBQ2hELE1BQU0sZ0NBQXlCLE9BQU8sS0FBSztDQUMzQyxNQUFNLHFDQUE4QixPQUFPLEtBQUs7Q0FDaEQsTUFBTSxzQ0FBK0IsT0FBTyxJQUFJO0NBQ2hELE1BQU0sNEJBQXFCLE9BQU8sRUFBRTtDQUNwQyxNQUFNLHNDQUErQixPQUFPLEVBQUU7Q0FDOUMsTUFBTSw4QkFBdUIsT0FBTyxJQUFJO0NBQ3hDLE1BQU0sNkJBQXNCLE9BQU8sSUFBSTtDQUN2QyxNQUFNLHVCQUF1QixjQUFjLGdCQUFnQiw0QkFBNEIsZUFBZSxlQUFlO0NBQ3JILE1BQU0sc0JBQXNCLGNBQWMsZUFBZSxlQUFlLGNBQWM7Q0FDdEYsTUFBTSxjQUFjLFdBQVc7Q0FDL0IsTUFBTSxxQkFBcUIsV0FBVztDQUN0QyxNQUFNLG9CQUFvQixrQkFBa0I7Q0FDNUMsTUFBTSxpQkFBaUIsaUJBQWlCO0NBQ3hDLE1BQU0sdUJBQXVCLHdCQUF3QixRQUFRO0NBQzdELE1BQU0scUJBQXFCLG1CQUFtQixZQUFZLHlCQUF5QjtFQUNqRixPQUFPLFlBQVksU0FBUyxTQUFTLElBQUksQ0FBQztDQUM1QyxDQUFDO0NBQ0QsTUFBTSw0QkFBNEIsd0JBQXdCLG9CQUFvQixDQUFDLENBQUMsUUFBTyxZQUFXLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQztDQUd4SCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksQ0FBQyxPQUNmO0VBRUYsU0FBUyxVQUFVLE9BQU87R0FDeEIsSUFBSSxNQUFNLFFBQVEsT0FFWjtRQUFBLFNBQVMsc0JBQXNCLGNBQWMsY0FBYyxvQkFBb0IsQ0FBQyxDQUFDLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxXQUFXLEtBQUssQ0FBQyw2QkFDOUgsVUFBVSxLQUFLO0dBQUE7RUFHckI7RUFFQSxPQUFPLGlCQURLLGNBQWMsb0JBQ0YsR0FBSyxXQUFXLFNBQVM7Q0FDbkQsR0FBRztFQUFDO0VBQVU7RUFBc0I7RUFBTztFQUE2QjtDQUFrQixDQUFDO0NBRzNGLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksWUFBWSxDQUFDLE1BQ2Y7RUFFRixNQUFNLE1BQU0sY0FBYyxvQkFBb0I7RUFDOUMsU0FBUywwQkFBMEI7R0FDakMsc0JBQXNCLFVBQVU7RUFDbEM7RUFDQSxTQUFTLGNBQWMsT0FBTztHQUM1QixNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLE1BQU0saUJBQWlCLDBCQUEwQjtHQUNqRCxNQUFNLHNCQUFzQixTQUFTLFVBQVUsTUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNLEtBQUssU0FBUyxlQUFlLFlBQVksTUFBTSxLQUFLLGVBQWUsTUFBSyxZQUFXLFlBQVksVUFBVSxTQUFTLFNBQVMsTUFBTSxDQUFDO0dBQ3pOLHNCQUFzQixVQUFVLENBQUM7R0FDakMsdUJBQXVCLFVBQVUsTUFBTSxlQUFlO0dBQ3RELElBQUksUUFBUSxRQUFRLDhCQUErQixHQUFHO0lBQ3BELGlCQUFpQixVQUFVO0lBRzNCLG1CQUFtQixNQUFNLFNBQVM7S0FDaEMsaUJBQWlCLFVBQVU7SUFDN0IsQ0FBQztHQUNIO0VBQ0Y7RUFDQSxTQUFTLFlBQVk7R0FDbkIsdUJBQXVCLFVBQVU7RUFDbkM7RUFDQSxPQUFPLGNBQWMsaUJBQWlCLEtBQUssZUFBZSxlQUFlLElBQUksR0FBRyxpQkFBaUIsS0FBSyxhQUFhLHlCQUF5QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssaUJBQWlCLHlCQUF5QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssV0FBVyxXQUFXLElBQUksR0FHMVEsdUJBQXVCO0NBQ3pCLEdBQUc7RUFBQztFQUFVO0VBQVU7RUFBYztFQUFzQjtFQUFNO0VBQWU7RUFBb0I7Q0FBeUIsQ0FBQztDQUcvSCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksQ0FBQyxpQkFDZjtFQUVGLE1BQU0sTUFBTSxjQUFjLG9CQUFvQjtFQUc5QyxTQUFTLG9CQUFvQjtHQUMzQixpQkFBaUIsVUFBVTtHQUMzQixtQkFBbUIsTUFBTSxTQUFTO0lBQ2hDLGlCQUFpQixVQUFVO0dBQzdCLENBQUM7RUFDSDtFQUNBLFNBQVMsY0FBYyxPQUFPO0dBQzVCLE1BQU0sU0FBUyxVQUFVLEtBQUs7R0FDOUIsSUFBSSxXQUFXLE1BQU0sR0FDbkIsdUJBQXVCLFVBQVU7RUFFckM7RUFDQSxTQUFTLG1CQUFtQixPQUFPO0dBQ2pDLE1BQU0sZ0JBQWdCLE1BQU07R0FDNUIsTUFBTSxnQkFBZ0IsTUFBTTtHQUM1QixNQUFNLFNBQVMsVUFBVSxLQUFLO0dBSzlCLElBQUksU0FBUyxpQkFBaUIsUUFBUSxVQUFVLFFBQVEsU0FBUyxVQUFVLE1BQU0sR0FDL0UsNEJBQTRCLE1BQU07R0FFcEMscUJBQXFCO0lBQ25CLE1BQU0sU0FBUyxVQUFVO0lBQ3pCLE1BQU0sV0FBVyxNQUFNLFFBQVE7SUFDL0IsTUFBTSxpQkFBaUIsMEJBQTBCO0lBQ2pELE1BQU0sc0JBQXNCLGVBQWUsYUFBYSxnQkFBZ0IsYUFBYSxDQUFDLEtBQUs7S0FBQyxlQUFlO0tBQVMsY0FBYztLQUFTLGVBQWUsZ0JBQWdCO0tBQVMsZUFBZSxlQUFlO0tBQVMsZUFBZSxpQkFBaUI7S0FBUyxlQUFlLGdCQUFnQjtLQUFTLFdBQVcsd0JBQXdCO0tBQUcsV0FBVyxvQkFBb0I7SUFBQyxDQUFDLENBQUMsU0FBUyxhQUFhO0lBQ3pZLE1BQU0sdUJBQXVCLEVBQUUsU0FBUyxjQUFjLGFBQWEsS0FBSyxTQUFTLFVBQVUsYUFBYSxLQUFLLFNBQVMsZUFBZSxRQUFRLEtBQUssU0FBUyxlQUFlLFlBQVksYUFBYSxLQUFLLGVBQWUsTUFBSyxZQUFXLFlBQVksaUJBQWlCLFNBQVMsU0FBUyxhQUFhLENBQUMsS0FBSyxTQUFTLG9CQUFtQixZQUFXLFNBQVMsU0FBUyxhQUFhLENBQUMsS0FBSyx1QkFBdUIsU0FBUyxnQkFBZ0IsS0FBSyxTQUFTLFNBQVMsTUFBTSxDQUFDLENBQUMsTUFBSyxTQUFRLFNBQVMsS0FBSyxTQUFTLFNBQVMsVUFBVSxhQUFhLEtBQUssU0FBUyxLQUFLLFNBQVMsU0FBUyxjQUFjLGFBQWEsQ0FBQyxLQUFLLGlCQUFpQixLQUFLLFNBQVMsU0FBUyxNQUFNLENBQUMsQ0FBQyxNQUFLLFNBQVEsQ0FBQyxLQUFLLFNBQVMsU0FBUyxVQUFVLHdCQUF3QixLQUFLLFNBQVMsU0FBUyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsYUFBYSxLQUFLLEtBQUssU0FBUyxTQUFTLGlCQUFpQixhQUFhO0lBQ3Z6QixJQUFJLGtCQUFrQixnQkFBZ0Isc0JBQ3BDLGVBQWUsb0JBQW9CO0lBS3JDLElBQUksZ0JBQWdCLGtCQUFrQixnQkFBZ0IsQ0FBQyxpQkFBaUIsTUFBTSxLQUFLLGNBQWMsR0FBRyxNQUFNLElBQUksTUFBTTtLQUdsSCxJQUFJLGNBQWMsb0JBQW9CLEdBQUc7TUFDdkMscUJBQXFCLE1BQU07TUFHM0IsSUFBSSxpQkFBaUIsU0FBUztPQUs1QixrQkFBa0IsY0FBYztRQUM5QixxQkFBcUIsTUFBTTtPQUM3QixDQUFDO09BQ0Q7TUFDRjtLQUNGO0tBQ0EsTUFBTSxrQkFBa0IsbUJBQW1CO0tBQzNDLE1BQU0sZUFBZSx1QkFBdUI7S0FDNUMsTUFBTSxlQUFlLGdCQUFnQixnQkFBZ0IsU0FBUyxZQUFZLElBQUksZUFBZSxTQUFTLGdCQUFnQixnQkFBZ0IsU0FBUyxNQUFNO0tBQ3JKLElBQUksY0FBYyxXQUFXLEdBQzNCLFlBQVksTUFBTTtJQUV0QjtJQUdBLElBQUksUUFBUSxRQUFRLGlCQUFpQjtLQUNuQyxRQUFRLFFBQVEsa0JBQWtCO0tBQ2xDO0lBQ0Y7SUFJQSxLQUFLLDhCQUE4QixPQUFPLENBQUMsVUFBVSxpQkFBaUIsd0JBQXdCLENBQUMsaUJBQWlCLFlBUWhILCtCQUErQixrQkFBa0IsNEJBQTRCLElBQUk7S0FDL0Usc0JBQXNCLFVBQVU7S0FDaEMsTUFBTSxRQUFRLE9BQU8seUJBQXlCTSxVQUFrQixLQUFLLENBQUM7SUFDeEU7R0FDRixDQUFDO0VBQ0g7RUFDQSxTQUFTLHNCQUFzQjtHQUM3QixJQUFJLHNCQUFzQixTQUN4QjtHQUVGLFFBQVEsUUFBUSxrQkFBa0I7R0FDbEMsWUFBWSxNQUFNLFNBQVM7SUFDekIsUUFBUSxRQUFRLGtCQUFrQjtHQUNwQyxDQUFDO0VBQ0g7RUFDQSxNQUFNLHNCQUFzQixjQUFjLFlBQVksSUFBSSxlQUFlO0VBQ3pFLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQ2hCO0VBRUYsT0FBTyxjQUFjLHVCQUF1QixpQkFBaUIscUJBQXFCLFlBQVksa0JBQWtCLEdBQUcsdUJBQXVCLGlCQUFpQixxQkFBcUIsZUFBZSxpQkFBaUIsR0FBRyxZQUFZLGlCQUFpQixVQUFVLFdBQVcsYUFBYSxHQUFHLFlBQVksaUJBQWlCLFVBQVUsWUFBWSxrQkFBa0IsR0FBRyxZQUFZLGlCQUFpQixpQkFBaUIsVUFBVSxZQUFZLHFCQUFxQixJQUFJLENBQUM7Q0FDN2IsR0FBRztFQUFDO0VBQVU7RUFBYztFQUFVO0VBQXNCO0VBQU87RUFBTTtFQUFlO0VBQU87RUFBaUI7RUFBYztFQUFvQjtFQUE2QjtFQUFXO0VBQVM7RUFBYTtFQUFvQjtFQUFtQjtFQUFzQjtFQUEwQjtDQUF5QixDQUFDO0NBR2pVLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUM1QjtFQUlGLE1BQU0sY0FBYyxNQUFNLEtBQUssZUFBZSxZQUFZLGlCQUFpQixJQUFJLGdCQUFnQixRQUFRLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztFQUVsSCxNQUFNLG9DQURZLE9BQU8saUJBQWlCLEtBQUssU0FBUyxTQUFTLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FDOUIsTUFBSyxTQUFRLG1CQUFtQixLQUFLLFNBQVMsU0FBUyxnQkFBZ0IsSUFBSSxDQUFDLENBQUMsRUFBRSxTQUFTLFNBQVM7RUFHcEosTUFBTSxvQkFBb0IsV0FESDtHQUFDLEdBQUc7SUFESTtJQUFVLEdBQUc7SUFBYSxlQUFlO0lBQVMsY0FBYztJQUFTLGVBQWUsaUJBQWlCO0lBQVMsZUFBZSxnQkFBZ0I7SUFBUyxHQUFHLDBCQUEwQjtHQUN2SztHQUFHO0dBQWtDLFdBQVcsd0JBQXdCO0dBQUcsV0FBVyxvQkFBb0I7R0FBRyw4QkFBOEIsZUFBZTtFQUFJLENBQUMsQ0FBQyxRQUFPLE1BQUssS0FBSyxJQUMzTCxHQUFnQjtHQUNuRCxZQUFZLFNBQVM7R0FDckIsTUFBTTtFQUNSLENBQUM7RUFFRCxNQUFNLGdCQUFnQixXQURPLENBQUMsVUFBVSxHQUFHLFdBQVcsQ0FBQyxDQUFDLFFBQU8sTUFBSyxLQUFLLElBQ3hDLENBQW9CO0VBQ3JELGFBQWE7R0FDWCxjQUFjO0dBQ2Qsa0JBQWtCO0VBQ3BCO0NBQ0YsR0FBRztFQUFDO0VBQU07RUFBVTtFQUFjO0VBQVU7RUFBTztFQUFlO0VBQTZCO0VBQU07RUFBVztFQUFzQjtFQUEwQjtDQUF5QixDQUFDO0NBRzFMLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsUUFBUSxZQUFZLENBQUMsY0FBYyxvQkFBb0IsR0FDMUQ7RUFFRixhQUFhLFVBQVU7RUFDdkIsdUJBQXVCLFVBQVU7RUFDakMsTUFBTSxNQUFNLGNBQWMsb0JBQW9CO0VBQzlDLE1BQU0sMkJBQTJCLGNBQWMsR0FBRztFQUdsRCxxQkFBcUI7R0FDbkIsTUFBTSx3QkFBd0IsZ0JBQWdCO0dBQzlDLE1BQU0sdUJBQXVCLE9BQU8sMEJBQTBCLGFBQWEsc0JBQXNCLHVCQUF1QixXQUFXLEVBQUUsSUFBSTtHQUd6SSxJQUFJLHlCQUF5QixVQUFhLHlCQUF5QixPQUNqRTtHQUdGLElBRHFDLFNBQVMsc0JBQXNCLHdCQUNyQyxHQUM3QjtHQUVGLElBQUksb0JBQW9CO0dBQ3hCLE1BQU0sK0JBQStCO0lBQ25DLElBQUkscUJBQXFCLE1BQ3ZCLG9CQUFvQixtQkFBbUIsb0JBQW9CO0lBRTdELE9BQU8sa0JBQWtCLE1BQU07R0FDakM7R0FDQSxJQUFJO0dBQ0osSUFBSSx5QkFBeUIsUUFBUSx5QkFBeUIsTUFDNUQsWUFBWSx1QkFBdUI7UUFFbkMsWUFBWSxXQUFXLG9CQUFvQjtHQUU3QyxZQUFZLGFBQWEsdUJBQXVCO0dBQ2hELE1BQU0saUJBQWlCLFNBQVMsc0JBQXNCLGNBQWMsR0FBRyxDQUFDO0dBR3hFLGFBQWtCLFdBQVc7SUFDM0IsZUFBZSxjQUFjO0lBQzdCLGNBQWM7S0FJWixJQUFJLENBQUMsUUFBUSxTQUNYLE9BQU87S0FFVCxJQUFJLGdCQUNGLE9BQU87S0FFVCxNQUFNLHVCQUF1QixjQUFjLEdBQUc7S0FFOUMsT0FBTyxFQURrQix5QkFBeUIsYUFBYSxTQUFTLHNCQUFzQixvQkFBb0I7SUFFcEg7R0FDRixDQUFDO0VBQ0gsQ0FBQztDQUNILEdBQUc7RUFBQztFQUFVO0VBQU07RUFBc0I7RUFBb0I7RUFBaUI7RUFBd0I7Q0FBTyxDQUFDO0NBRy9HLHlCQUF5QjtFQUN2QixJQUFJLFlBQVksQ0FBQyxzQkFDZjtFQUVGLE1BQU0sTUFBTSxjQUFjLG9CQUFvQjtFQUM5QyxNQUFNLDJCQUEyQixjQUFjLEdBQUc7RUFJbEQsTUFBTSxzQkFBc0IsdUJBQXVCLFdBQVc7RUFDOUQsNEJBQTRCLHdCQUF3QjtFQUNwRCxTQUFTLGtCQUFrQixTQUFTO0dBQ2xDLElBQUksQ0FBQyxRQUFRLE1BQ1gsYUFBYSxVQUFVLGFBQWEsUUFBUSxhQUFhLHVCQUF1QixPQUFPO0dBRXpGLElBQUksUUFBUSxXQUFXLG1CQUF3QixRQUFRLFlBQVksU0FBUyxjQUMxRSxzQkFBc0IsVUFBVTtHQUVsQyxJQUFJLFFBQVEsV0FBVyxpQkFDckI7R0FFRixJQUFJLFFBQVEsUUFDVixzQkFBc0IsVUFBVTtRQUMzQixJQUFJLGVBQWUsUUFBUSxXQUFXLEtBQUssc0JBQXNCLFFBQVEsV0FBVyxHQUN6RixzQkFBc0IsVUFBVTtRQUMzQjtJQU1MLElBQUksMkJBQTJCO0lBQy9CLGNBQWMsb0JBQW9CLENBQUMsQ0FBQyxjQUFjLEtBQUssQ0FBQyxDQUFDLE1BQU0sRUFDN0QsSUFBSSxnQkFBZ0I7S0FDbEIsMkJBQTJCO0tBQzNCLE9BQU87SUFDVCxFQUNGLENBQUM7SUFDRCxJQUFJLDBCQUNGLHNCQUFzQixVQUFVO1NBRWhDLHNCQUFzQixVQUFVO0dBRXBDO0VBQ0Y7RUFDQSxPQUFPLEdBQUcsY0FBYyxpQkFBaUI7RUFDekMsU0FBUyxpQkFBaUIsV0FBVztHQUNuQyxNQUFNLHVCQUF1QixlQUFlO0dBQzVDLElBQUksMkJBQTJCLE9BQU8seUJBQXlCLGFBQWEscUJBQXFCLFNBQVMsSUFBSTtHQUc5RyxJQUFJLDZCQUE2QixVQUFhLDZCQUE2QixPQUN6RSxPQUFPO0dBRVQsSUFBSSw2QkFBNkIsTUFDL0IsMkJBQTJCO0dBRTdCLE1BQU0seUJBQXlCLGNBQWMsY0FBYyxlQUFlO0dBQzFFLE1BQU0sd0JBQXdCLDBCQUEwQixlQUFlLFlBQVksd0JBQXdCLE1BQU0sU0FBUywyQkFBMkI7R0FDckosSUFBSSx1QkFBdUIsc0JBQXNCLHlCQUF5Qix5QkFBeUIsMEJBQTBCO0dBQzdILElBQUksQ0FBQyxzQkFDSCx1QkFBdUIsNEJBQTRCLEtBQUs7R0FFMUQsSUFBSSxPQUFPLDZCQUE2QixXQUN0QyxPQUFPO0dBRVQsT0FBTyxXQUFXLHdCQUF3QixLQUFLLHdCQUF3QjtFQUN6RTtFQUNBLGFBQWE7R0FDWCxPQUFPLElBQUksY0FBYyxpQkFBaUI7R0FDMUMsTUFBTSxXQUFXLGNBQWMsR0FBRztHQUNsQyxNQUFNLGlCQUFpQiwwQkFBMEI7R0FDakQsTUFBTSw0QkFBNEIsU0FBUyxVQUFVLFFBQVEsS0FBSyxlQUFlLE1BQUssWUFBVyxZQUFZLFlBQVksU0FBUyxTQUFTLFFBQVEsQ0FBQyxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssU0FBUyxTQUFTLFVBQVUsR0FBRyxLQUFLLENBQUMsQ0FBQyxNQUFLLFNBQVEsU0FBUyxLQUFLLFNBQVMsU0FBUyxVQUFVLFFBQVEsQ0FBQztHQUc1UixNQUFNLHVCQUF1QixlQUFlO0dBQzVDLE1BQU0sWUFBWSxhQUFhO0dBQy9CLE1BQU0sZ0JBQWdCLGlCQUFpQixTQUFTO0dBQ2hELHFCQUFxQjtJQUduQixNQUFNLHdCQUF3Qix3QkFBd0IsYUFBYTtJQUNuRSxNQUFNLHlCQUF5QixPQUFPLHlCQUF5QjtJQUMvRCxJQUFJLHdCQUF3QixDQUFDLHNCQUFzQixXQUFXLGNBQWMscUJBQXFCLE1BSWpHLENBQUMsMEJBQTBCLDBCQUEwQixZQUFZLGFBQWEsSUFBSSxPQUFPLDRCQUE0QixPQUFPO0tBQzFILE1BQU0sZUFBZSxFQUNuQixlQUFlLEtBQ2pCO0tBQ0EsSUFBSSxjQUFjLFlBQ2hCLGFBQWEsZUFBZTtLQUU5QixzQkFBc0IsTUFBTSxZQUFZO0lBQzFDO0lBQ0Esc0JBQXNCLFVBQVU7R0FDbEMsQ0FBQztFQUNIO0NBQ0YsR0FBRztFQUFDO0VBQVU7RUFBVTtFQUFzQjtFQUFnQjtFQUF3QjtFQUFRO0VBQU07RUFBYztFQUFXO0NBQXlCLENBQUM7Q0FLdkoseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQ0wsVUFBMEIsUUFBUSxDQUFDLFVBQ3RDO0VBRUYsTUFBTSxXQUFXLGNBQWMsY0FBYyxRQUFRLENBQUM7RUFDdEQsSUFBSSxDQUFDLGNBQWMsUUFBUSxLQUFLLENBQUMsa0JBQWtCLFFBQVEsR0FDekQ7RUFFRixJQUFJLFNBQVMsVUFBVSxRQUFRLEdBQzdCLFNBQVMsS0FBSztDQUVsQixHQUFHLENBQUMsTUFBTSxRQUFRLENBQUM7Q0FJbkIseUJBQXlCO0VBQ3ZCLElBQUksWUFBWSxDQUFDLGVBQ2Y7RUFFRixjQUFjLHFCQUFxQjtHQUNqQztHQUNBO0dBQ0E7R0FDQSxjQUFjLE1BQU07R0FDcEI7RUFDRixDQUFDO0VBQ0QsYUFBYTtHQUNYLGNBQWMscUJBQXFCLElBQUk7RUFDekM7Q0FDRixHQUFHO0VBQUM7RUFBVTtFQUFlO0VBQU87RUFBTTtFQUFPO0VBQWlCO0NBQVksQ0FBQztDQUcvRSx5QkFBeUI7RUFDdkIsSUFBSSxZQUFZLENBQUMsc0JBQ2Y7RUFFRixlQUFlLG9CQUFvQjtFQUNuQyxhQUFhO0dBQ1gsZUFBZSwwQ0FBMEM7RUFDM0Q7Q0FDRixHQUFHLENBQUMsVUFBVSxvQkFBb0IsQ0FBQztDQUNuQyxNQUFNLHFCQUFxQixDQUFDLGFBQWEsUUFBUSxDQUFDLDhCQUE4QixVQUFVLGtCQUFrQjtDQUM1RyxPQUFvQix3REFBWSxVQUFVLEVBQ3hDLFVBQVU7RUFBQyxzQkFBbUMsMENBQUssWUFBWTtHQUM3RCxhQUFhO0dBQ2IsS0FBSztHQUNMLFVBQVMsVUFBUztJQUNoQixJQUFJLE9BQU87S0FDVCxNQUFNLE1BQU0sbUJBQW1CO0tBRS9CLGFBQWtCLElBQUksSUFBSSxTQUFTLEVBQUU7SUFDdkMsT0FBTyxJQUFJLGVBQWUsWUFBWTtLQUNwQyxzQkFBc0IsVUFBVTtLQUNoQyxJQUFJLGVBQWUsT0FBTyxjQUFjLFVBQVUsR0FFaEQsZ0JBRHFDLFlBQzFCLENBQUMsRUFBRSxNQUFNO1VBRXBCLFdBQVcsNEJBQTRCLGNBQWMsZ0JBQWdCLENBQUMsRUFBRSxNQUFNO0lBRWxGO0dBQ0Y7RUFDRixDQUFDO0VBQUc7RUFBVSxzQkFBbUMsMENBQUssWUFBWTtHQUNoRSxhQUFhO0dBQ2IsS0FBSztHQUNMLFVBQVMsVUFBUztJQUNoQixJQUFJLE9BRUYsYUFBa0IsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO1NBQ3BDLElBQUksZUFBZSxZQUFZO0tBQ3BDLElBQUksaUJBQ0Ysc0JBQXNCLFVBQVU7S0FFbEMsSUFBSSxlQUFlLE9BQU8sY0FBYyxVQUFVLEdBRWhELG9CQUR5QyxZQUM5QixDQUFDLEVBQUUsTUFBTTtVQUVwQixXQUFXLHdCQUF3QixjQUFjLGVBQWUsQ0FBQyxFQUFFLE1BQU07SUFFN0U7R0FDRjtFQUNGLENBQUM7Q0FBQyxFQUNKLENBQUM7QUFDSDs7Ozs7OztBQ3ZrQkEsU0FBZ0IsU0FBUyxTQUFTLFFBQVEsQ0FBQyxHQUFHO0NBQzVDLE1BQU0sRUFDSixVQUFVLE1BQ1YsT0FBTyxjQUFjLFNBQ3JCLFNBQVMsTUFDVCxjQUFjLE9BQ2QsY0FBYyxNQUNkLGlCQUFpQixHQUNqQixTQUFTTSxpQkFDUDtDQUNKLE1BQU0sUUFBUSxlQUFlLFVBQVUsUUFBUSxZQUFZO0NBQzNELE1BQU0sVUFBVSxNQUFNLFFBQVE7Q0FDOUIsTUFBTSw4QkFBdUIsT0FBTyxNQUFTO0NBQzdDLE1BQU0sUUFBUSxrQkFBa0I7Q0FDaEMsTUFBTSxtQkFBbUIsV0FBVztDQUNwQyxNQUFNLHlCQUFrQixjQUFjO0VBQ3BDLFNBQVMsc0JBQXNCLFVBQVUsYUFBYSxRQUFRLGFBQWE7R0FDekUsTUFBTSxVQUFVLHlCQUF5QixRQUFRLGFBQWEsTUFBTTtHQUNwRSxJQUFJLFlBQVksZ0JBQWdCLFdBQVcsaUJBQWlCLEdBQzFELGlCQUFpQixNQUFNLHNCQUFzQjtJQUMzQyxNQUFNLFFBQVEsTUFBTSxPQUFPO0dBQzdCLENBQUM7UUFFRCxNQUFNLFFBQVEsVUFBVSxPQUFPO0VBRW5DO0VBQ0EsU0FBUyxZQUFZLE1BQU0sZUFBZSxzQkFBc0I7R0FDOUQsTUFBTSxZQUFZLFFBQVEsUUFBUTtHQUNsQyxNQUFNLDhCQUE4QixNQUFNLE9BQU8scUJBQXFCLE1BQU07R0FDNUUsSUFBSSxRQUFRLDZCQUVWLE9BQU87R0FFVCxJQUFJLENBQUMsTUFFSCxPQUFPO0dBRVQsSUFBSSxDQUFDLFFBRUgsT0FBTztHQUVULElBQUksYUFBYSxhQUVmLE9BQU8sQ0FBQyxxQkFBcUIsVUFBVSxJQUFJO0dBSTdDLE9BQU87RUFDVDtFQUNBLE9BQU87R0FDTCxjQUFjLE9BQU87SUFLbkIsZUFBZSxVQUFVLHVCQUF1QixNQUFNLGFBQWEsSUFBSSxLQUFLLHNCQUFzQixNQUFNLFdBQVcsSUFBSSxZQUFZLE1BQU07R0FDM0k7R0FDQSxZQUFZLE9BQU87SUFDakIsTUFBTSxjQUFjLGVBQWU7SUFDbkMsTUFBTSxjQUFjLE1BQU07SUFDMUIsTUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNO0lBSWhDLElBQUksTUFBTSxXQUFXLEtBQUssZ0JBQWdCLFdBQVcsdUJBQXVCLGFBQWEsSUFBSSxLQUFLLGFBQ2hHO0lBRUYsTUFBTSxXQUFXLFlBQVksTUFBTSxNQUFNLGdCQUFlLGtCQUFpQixrQkFBa0IsV0FBVyxrQkFBa0IsV0FBVztJQUluSSxNQUFNLFNBQVMsVUFBVSxXQUFXO0lBQ3BDLElBQUksa0JBQWtCLE1BQU0sR0FBRztLQUM3QixzQkFBc0IsVUFBVSxhQUFhLFFBQVEsV0FBVztLQUNoRTtJQUNGO0lBSUEsTUFBTSxxQkFBcUIsTUFBTTtJQUlqQyxNQUFNLGNBQWM7S0FDbEIsc0JBQXNCLFVBQVUsYUFBYSxvQkFBb0IsV0FBVztJQUM5RSxDQUFDO0dBQ0g7R0FDQSxRQUFRLE9BQU87SUFDYixJQUFJLGdCQUFnQixrQkFDbEI7SUFFRixNQUFNLGNBQWMsZUFBZTtJQUNuQyxJQUFJLGdCQUFnQixlQUFlLGFBQWE7S0FDOUMsZUFBZSxVQUFVO0tBQ3pCO0lBQ0Y7SUFDQSxJQUFJLHVCQUF1QixhQUFhLElBQUksS0FBSyxhQUMvQztJQUlGLHNCQURpQixZQURKLE1BQU0sT0FBTyxNQUNNLEdBQUcsTUFBTSxnQkFBZSxrQkFBaUIsa0JBQWtCLFdBQVcsa0JBQWtCLGVBQWUsa0JBQWtCLGFBQWEsa0JBQWtCLE9BQzNKLEdBQUcsTUFBTSxhQUFhLE1BQU0sZUFBZSxXQUFXO0dBQ3JGO0dBQ0EsWUFBWTtJQUNWLGVBQWUsVUFBVTtHQUMzQjtFQUNGO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBYTtFQUFhO0VBQVE7RUFBTztFQUFhO0VBQVE7RUFBTztFQUFrQjtDQUFjLENBQUM7Q0FDbkgsb0JBQWEsY0FBYyxVQUFVLEVBQ25DLFVBQ0YsSUFBSSxjQUFjLENBQUMsU0FBUyxTQUFTLENBQUM7QUFDeEM7OztBQzNHQSxTQUFTLGNBQWM7Q0FDckIsT0FBTztBQUNUO0FBQ0EsU0FBZ0IsY0FBYyxjQUFjO0NBQzFDLE9BQU87RUFDTCxXQUFXLE9BQU8saUJBQWlCLFlBQVksZUFBZSxjQUFjLGFBQWE7RUFDekYsY0FBYyxPQUFPLGlCQUFpQixZQUFZLGVBQWUsY0FBYyxnQkFBZ0I7Q0FDakc7QUFDRjs7Ozs7O0FBTUEsU0FBZ0IsV0FBVyxTQUFTLFFBQVEsQ0FBQyxHQUFHO0NBQzlDLE1BQU0sRUFDSixVQUFVLE1BQ1YseUJBQVksTUFDWixjQUFjLG1CQUFtQixNQUNqQyxvQkFBb0IsVUFDcEIsaUJBQWlCLGFBQ2pCLFNBQ0EsaUJBQ0U7Q0FDSixNQUFNLFFBQVEsZUFBZSxVQUFVLFFBQVEsWUFBWTtDQUMzRCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQUN4RCxNQUFNLEVBQ0osWUFDRSxNQUFNO0NBQ1YsTUFBTSxPQUFPLGdCQUFnQixZQUFZO0NBQ3pDLE1BQU0saUJBQWlCLGtCQUFrQixPQUFPLHFCQUFxQixhQUFhLHlCQUF5QixLQUFLO0NBQ2hILE1BQU1DLGlCQUFlLE9BQU8scUJBQXFCLGFBQWEsaUJBQWlCO0NBQy9FLE1BQU0sc0JBQXNCQSxtQkFBaUI7Q0FDN0MsTUFBTSwyQkFBMkIsd0JBQXdCLGlCQUFpQjtDQUMxRSxNQUFNLEVBQ0osV0FBVyxrQkFDWCxjQUFjLHdCQUNaLGNBQWMsT0FBTztDQUN6QixNQUFNLHFDQUE4QixPQUFPLEtBQUs7Q0FDaEQsTUFBTSxzQ0FBK0IsT0FBTyxLQUFLO0NBRWpELE1BQU0sMkNBQW9DLE9BQU8sS0FBSztDQUN0RCxNQUFNLDhCQUF1QixPQUFPLEtBQUs7Q0FDekMsTUFBTSxxQ0FBOEIsT0FBTyxFQUFFO0NBQzdDLE1BQU0sNkJBQXNCLE9BQU8sSUFBSTtDQUN2QyxNQUFNLDRCQUE0QixXQUFXO0NBQzdDLE1BQU0sOEJBQThCLFdBQVc7Q0FDL0MsTUFBTSx1QkFBdUIsd0JBQXdCO0VBQ25ELDRCQUE0QixNQUFNO0VBQ2xDLFFBQVEsUUFBUSxrQkFBa0I7Q0FDcEMsQ0FBQztDQUNELE1BQU0sbUJBQW1CLG1CQUFrQixjQUFhO0VBQ3RELE1BQU0sU0FBUyxRQUFRLFFBQVEsaUJBQWlCO0VBRWhELFFBRGlCLE9BQU8sZ0JBQWdCLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFBSSxDQUFDLEdBQzFELE1BQUssVUFBUyxNQUFNLFNBQVMsUUFBUSxDQUFDLE1BQU0sUUFBUSxRQUFRLFFBQVEsVUFBVTtDQUNoRyxDQUFDO0NBQ0QsTUFBTSwyQkFBMkIsbUJBQWtCLFVBQVM7RUFDMUQsT0FBTyxvQkFBb0IsT0FBTyxNQUFNLE9BQU8saUJBQWlCLENBQUMsS0FBSyxvQkFBb0IsT0FBTyxNQUFNLE9BQU8scUJBQXFCLENBQUM7Q0FDdEksQ0FBQztDQUNELE1BQU0sd0JBQXdCLG1CQUFrQixVQUFTO0VBQ3ZELElBQUksQ0FBQyxlQUFlLEdBQ2xCO0VBRUYsTUFBTSxRQUFRLE9BQU8seUJBQXlCRCxjQUFzQixNQUFNLFdBQVcsQ0FBQztDQUN4RixDQUFDO0NBQ0QsTUFBTSx1QkFBdUIsbUJBQWtCLFVBQVM7RUFDdEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUNFLGVBQWEsTUFBTSxRQUFRLFVBQ25EO0VBS0YsSUFBSSxlQUFlLFNBQ2pCO0VBRUYsSUFBSSxDQUFDLG9CQUFvQixpQkFBaUIsb0JBQW9CLEdBQzVEO0VBRUYsTUFBTSxTQUFTLGFBQWEsS0FBSyxJQUFJLE1BQU0sY0FBYztFQUN6RCxNQUFNLGVBQWUseUJBQXlCQyxXQUFtQixNQUFNO0VBQ3ZFLE1BQU0sUUFBUSxPQUFPLFlBQVk7RUFDakMsSUFBSSxDQUFDLGFBQWEsWUFDaEIsTUFBTSxlQUFlO0VBRXZCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLHNCQUNyQyxNQUFNLGdCQUFnQjtDQUUxQixDQUFDO0NBQ0QsTUFBTSxzQkFBc0Isd0JBQXdCO0VBQ2xELFFBQVEsUUFBUSxrQkFBa0I7RUFDbEMsNEJBQTRCLE1BQU0sR0FBRyxvQkFBb0I7Q0FDM0QsQ0FBQztDQUNELE1BQU0sa0NBQWtDLG1CQUFrQixVQUFTO0VBQ2pFLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxNQUFNLFdBQVcsR0FDeEM7RUFFRixNQUFNLFNBQVMsVUFBVSxNQUFNLFdBQVc7RUFJMUMsSUFBSSxDQUFDLFNBQVMsTUFBTSxPQUFPLGlCQUFpQixHQUFHLE1BQU0sR0FDbkQ7RUFFRixJQUFJLENBQUMsc0JBQXNCLFNBQVM7R0FDbEMsc0JBQXNCLFVBQVU7R0FDaEMsdUJBQXVCLFVBQVU7RUFDbkM7Q0FDRixDQUFDO0NBQ0QsTUFBTSxnQ0FBZ0MsbUJBQWtCLFVBQVM7RUFDL0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUNaO0VBRUYsSUFBSSxFQUFFLE1BQU0sb0JBQW9CLE1BQU0sWUFBWSxtQkFDaEQ7RUFFRixJQUFJLHNCQUFzQixTQUN4Qix1QkFBdUIsVUFBVTtDQUVyQyxDQUFDO0NBQ0QsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUNaLE9BQU87RUFFVCxRQUFRLFFBQVEscUJBQXFCO0VBQ3JDLFFBQVEsUUFBUSx3QkFBd0I7RUFDeEMsTUFBTSxxQkFBcUIsSUFBSSxRQUFRO0VBQ3ZDLE1BQU0sbUNBQW1DLElBQUksUUFBUTtFQUNyRCxTQUFTLHlCQUF5QjtHQUNoQyxtQkFBbUIsTUFBTTtHQUN6QixlQUFlLFVBQVU7RUFDM0I7RUFDQSxTQUFTLHVCQUF1QjtHQUk5QixtQkFBbUIsTUFHbkJULFNBQXlCLElBQUksU0FBUztJQUNwQyxlQUFlLFVBQVU7R0FDM0IsQ0FBQztFQUNIO0VBQ0EsU0FBUyxtREFBbUQ7R0FDMUQsNEJBQTRCLFVBQVU7R0FHdEMsaUNBQWlDLE1BQU0sU0FBUztJQUM5Qyw0QkFBNEIsVUFBVTtHQUN4QyxDQUFDO0VBQ0g7RUFDQSxTQUFTLHVCQUF1QjtHQUM5QixzQkFBc0IsVUFBVTtHQUNoQyx1QkFBdUIsVUFBVTtFQUNuQztFQUNBLFNBQVMsdUJBQXVCO0dBQzlCLE1BQU0sT0FBTyxzQkFBc0I7R0FDbkMsTUFBTSxlQUFlLFNBQVMsU0FBUyxDQUFDLE9BQU8sVUFBVTtHQUN6RCxNQUFNLHlCQUF5Qix5QkFBeUI7R0FDeEQsTUFBTSxXQUFXLE9BQU8sMkJBQTJCLGFBQWEsdUJBQXVCLElBQUk7R0FDM0YsSUFBSSxPQUFPLGFBQWEsVUFDdEIsT0FBTztHQUVULE9BQU8sU0FBUztFQUNsQjtFQUNBLFNBQVMsa0JBQWtCLE9BQU87R0FDaEMsTUFBTSw0QkFBNEIscUJBQXFCO0dBQ3ZELE9BQU8sOEJBQThCLGlCQUFpQixNQUFNLFNBQVMsV0FBVyw4QkFBOEIsWUFBWSxNQUFNLFNBQVM7RUFDM0k7RUFDQSxTQUFTLDBCQUEwQixPQUFPO0dBQ3hDLE1BQU0sU0FBUyxRQUFRLFFBQVEsaUJBQWlCO0dBQ2hELE1BQU0seUJBQXlCLFFBQVEsZ0JBQWdCLEtBQUssU0FBUyxTQUFTLE1BQU0sQ0FBQyxDQUFDLE1BQUssU0FBUSxvQkFBb0IsT0FBTyxLQUFLLFNBQVMsU0FBUyxRQUFRLENBQUM7R0FDOUosT0FBTyx5QkFBeUIsS0FBSyxLQUFLO0VBQzVDO0VBQ0EsU0FBUyxvQkFBb0IsT0FBTztHQUNsQyxJQUFJLGtCQUFrQixLQUFLLEdBQUc7SUFHNUIsSUFBSSxNQUFNLFNBQVMsV0FBVyxDQUFDLHlCQUF5QixLQUFLLEdBQUc7S0FDOUQsaUNBQWlDLE1BQU07S0FDdkMsNEJBQTRCLFVBQVU7SUFDeEM7SUFDQSxxQkFBcUI7SUFDckI7R0FDRjtHQUNBLElBQUksUUFBUSxRQUFRLGlCQUFpQjtJQUNuQyxxQkFBcUI7SUFDckI7R0FDRjtHQUNBLE1BQU0sU0FBUyxVQUFVLEtBQUs7R0FDOUIsTUFBTSxnQkFBZ0IsSUFBSSxnQkFBZ0IsT0FBTyxFQUFFO0dBQ25ELE1BQU0sYUFBYSxVQUFVLE1BQU0sSUFBSSxPQUFPLFlBQVksSUFBSTtHQUM5RCxNQUFNLFVBQVUsTUFBTSxNQUFNLGFBQWEsVUFBVSxJQUFJLGFBQWEsY0FBYyxNQUFNLE9BQU8saUJBQWlCLENBQUMsR0FBRyxpQkFBaUIsYUFBYSxDQUFDO0dBQ25KLE1BQU0sV0FBVyxNQUFNLFFBQVE7R0FHL0IsSUFBSSxXQUFXLFNBQVMsV0FBVyxNQUFNLEtBQUssU0FBUyxvQkFBbUIsWUFBVyxTQUFTLFNBQVMsTUFBTSxDQUFDLElBQzVHO0dBRUYsSUFBSSxxQkFBcUIsVUFBVSxNQUFNLElBQUksU0FBUztHQUN0RCxPQUFPLHNCQUFzQixDQUFDLHNCQUFzQixrQkFBa0IsR0FBRztJQUN2RSxNQUFNLGFBQWEsY0FBYyxrQkFBa0I7SUFDbkQsSUFBSSxzQkFBc0IsVUFBVSxLQUFLLENBQUMsVUFBVSxVQUFVLEdBQzVEO0lBRUYscUJBQXFCO0dBQ3ZCO0dBSUEsSUFBSSxRQUFRLFVBQVUsVUFBVSxNQUFNLEtBQUssQ0FBQyxjQUFjLE1BQU0sS0FFaEUsQ0FBQyxTQUFTLFFBQVEsTUFBTSxPQUFPLGlCQUFpQixDQUFDLEtBR2pELFFBQVEsT0FBTSxXQUFVLENBQUMsU0FBUyxvQkFBb0IsTUFBTSxDQUFDLEdBQzNEO0dBS0YsSUFBSSxjQUFjLE1BQU0sS0FBSyxFQUFFLGFBQWEsUUFBUTtJQUNsRCxNQUFNLHNCQUFzQixzQkFBc0IsTUFBTTtJQUN4RCxNQUFNLFFBQVEsaUJBQWlCLE1BQU07SUFDckMsTUFBTSxXQUFXO0lBQ2pCLE1BQU0sZ0JBQWdCLHVCQUF1QixTQUFTLEtBQUssTUFBTSxTQUFTO0lBQzFFLE1BQU0sZ0JBQWdCLHVCQUF1QixTQUFTLEtBQUssTUFBTSxTQUFTO0lBQzFFLE1BQU0sYUFBYSxpQkFBaUIsT0FBTyxjQUFjLEtBQUssT0FBTyxjQUFjLE9BQU87SUFDMUYsTUFBTSxhQUFhLGlCQUFpQixPQUFPLGVBQWUsS0FBSyxPQUFPLGVBQWUsT0FBTztJQUM1RixNQUFNLFFBQVEsTUFBTSxjQUFjO0lBT2xDLE1BQU0sMkJBQTJCLGVBQWUsUUFBUSxNQUFNLFdBQVcsT0FBTyxjQUFjLE9BQU8sY0FBYyxNQUFNLFVBQVUsT0FBTztJQUMxSSxNQUFNLDZCQUE2QixjQUFjLE1BQU0sVUFBVSxPQUFPO0lBQ3hFLElBQUksNEJBQTRCLDRCQUM5QjtHQUVKO0dBQ0EsSUFBSSwwQkFBMEIsS0FBSyxHQUNqQztHQU1GLElBQUkscUJBQXFCLE1BQU0saUJBQWlCLDRCQUE0QixTQUFTO0lBQ25GLGlDQUFpQyxNQUFNO0lBQ3ZDLDRCQUE0QixVQUFVO0lBQ3RDO0dBQ0Y7R0FDQSxJQUFJLE9BQU9PLG1CQUFpQixjQUFjLENBQUNBLGVBQWEsS0FBSyxHQUMzRDtHQUVGLElBQUksaUJBQWlCLHVCQUF1QixHQUMxQztHQUVGLE1BQU0sUUFBUSxPQUFPLHlCQUF5QkcsY0FBc0IsS0FBSyxDQUFDO0dBQzFFLHFCQUFxQjtFQUN2QjtFQUNBLFNBQVMsa0JBQWtCLE9BQU87R0FDaEMsSUFBSSxxQkFBcUIsTUFBTSxZQUFZLE1BQU0sZ0JBQWdCLFdBQVcsQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsV0FBVyx5QkFBeUIsS0FBSyxHQUM3STtHQUVGLG9CQUFvQixLQUFLO0VBQzNCO0VBQ0EsU0FBUyxpQkFBaUIsT0FBTztHQUMvQixJQUFJLHFCQUFxQixNQUFNLFlBQVksQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsV0FBVyx5QkFBeUIsS0FBSyxHQUM1RztHQUVGLE1BQU0sUUFBUSxNQUFNLFFBQVE7R0FDNUIsSUFBSSxPQUFPO0lBQ1QsY0FBYyxVQUFVO0tBQ3RCLFdBQVcsS0FBSyxJQUFJO0tBQ3BCLFFBQVEsTUFBTTtLQUNkLFFBQVEsTUFBTTtLQUNkLG1CQUFtQjtLQUNuQixvQkFBb0I7SUFDdEI7SUFDQSwwQkFBMEIsTUFBTSxXQUFZO0tBQzFDLElBQUksY0FBYyxTQUFTO01BQ3pCLGNBQWMsUUFBUSxvQkFBb0I7TUFDMUMsY0FBYyxRQUFRLHFCQUFxQjtLQUM3QztJQUNGLENBQUM7R0FDSDtFQUNGO0VBQ0EsU0FBUywyQkFBMkIsT0FBTyxVQUFVO0dBQ25ELE1BQU0sU0FBUyxVQUFVLEtBQUs7R0FDOUIsSUFBSSxDQUFDLFFBQ0g7R0FFRixNQUFNLGNBQWMsaUJBQWlCLFFBQVEsTUFBTSxZQUFZO0lBQzdELFNBQVMsS0FBSztJQUNkLFlBQVk7R0FDZCxDQUFDO0VBQ0g7RUFDQSxTQUFTLHdCQUF3QixPQUFPO0dBQ3RDLHNCQUFzQixVQUFVO0dBQ2hDLDJCQUEyQixPQUFPLGdCQUFnQjtFQUNwRDtFQUNBLFNBQVMsMkJBQTJCLE9BQU87R0FDekMsMEJBQTBCLE1BQU07R0FDaEMsSUFBSSxNQUFNLFNBQVMsZUFDakIsc0JBQXNCLFVBQVUsTUFBTTtHQUV4QyxJQUFJLE1BQU0sU0FBUyxlQUFlLGNBQWMsV0FBVyxDQUFDLGNBQWMsUUFBUSxvQkFDaEY7R0FFRiwyQkFBMkIsUUFBTyxnQkFBZTtJQUMvQyxJQUFJLFlBQVksU0FBUyxlQUN2QixrQkFBa0IsV0FBVztTQUU3QixvQkFBb0IsV0FBVztHQUVuQyxDQUFDO0VBQ0g7RUFDQSxTQUFTLHNCQUFzQixPQUFPO0dBQ3BDLElBQUksQ0FBQyxzQkFBc0IsU0FDekI7R0FFRixNQUFNLHFDQUFxQyx1QkFBdUI7R0FDbEUscUJBQXFCO0dBQ3JCLElBQUkscUJBQXFCLE1BQU0sZUFDN0I7R0FFRixJQUFJLE1BQU0sU0FBUyxpQkFBaUI7SUFDbEMsSUFBSSxvQ0FDRixpREFBaUQ7SUFFbkQ7R0FDRjtHQUNBLElBQUksMEJBQTBCLEtBQUssR0FDakM7R0FPRixJQUFJLG9DQUFvQztJQUN0QyxpREFBaUQ7SUFDakQ7R0FDRjtHQUdBLElBQUksT0FBT0gsbUJBQWlCLGNBQWMsQ0FBQ0EsZUFBYSxLQUFLLEdBQzNEO0dBRUYsaUNBQWlDLE1BQU07R0FDdkMsNEJBQTRCLFVBQVU7R0FDdEMscUJBQXFCO0VBQ3ZCO0VBQ0EsU0FBUyxnQkFBZ0IsT0FBTztHQUM5QixJQUFJLHFCQUFxQixNQUFNLFlBQVksQ0FBQyxjQUFjLFdBQVcseUJBQXlCLEtBQUssR0FDakc7R0FFRixNQUFNLFFBQVEsTUFBTSxRQUFRO0dBQzVCLElBQUksQ0FBQyxPQUNIO0dBRUYsTUFBTSxTQUFTLEtBQUssSUFBSSxNQUFNLFVBQVUsY0FBYyxRQUFRLE1BQU07R0FDcEUsTUFBTSxTQUFTLEtBQUssSUFBSSxNQUFNLFVBQVUsY0FBYyxRQUFRLE1BQU07R0FDcEUsTUFBTSxXQUFXLEtBQUssS0FBSyxTQUFTLFNBQVMsU0FBUyxNQUFNO0dBQzVELElBQUksV0FBVyxHQUNiLGNBQWMsUUFBUSxvQkFBb0I7R0FFNUMsSUFBSSxXQUFXLElBQUk7SUFDakIsb0JBQW9CLEtBQUs7SUFDekIsMEJBQTBCLE1BQU07SUFDaEMsY0FBYyxVQUFVO0dBQzFCO0VBQ0Y7RUFDQSxTQUFTLHVCQUF1QixPQUFPO0dBQ3JDLDJCQUEyQixPQUFPLGVBQWU7RUFDbkQ7RUFDQSxTQUFTLGVBQWUsT0FBTztHQUM3QixJQUFJLHFCQUFxQixNQUFNLFlBQVksQ0FBQyxjQUFjLFdBQVcseUJBQXlCLEtBQUssR0FDakc7R0FFRixJQUFJLGNBQWMsUUFBUSxtQkFDeEIsb0JBQW9CLEtBQUs7R0FFM0IsMEJBQTBCLE1BQU07R0FDaEMsY0FBYyxVQUFVO0VBQzFCO0VBQ0EsU0FBUyxzQkFBc0IsT0FBTztHQUNwQywyQkFBMkIsT0FBTyxjQUFjO0VBQ2xEO0VBQ0EsTUFBTSxNQUFNLGNBQWMsZUFBZTtFQUN6QyxNQUFNLGNBQWMsY0FBY0MsZUFBYSxjQUFjLGlCQUFpQixLQUFLLFdBQVcsb0JBQW9CLEdBQUcsaUJBQWlCLEtBQUssb0JBQW9CLHNCQUFzQixHQUFHLGlCQUFpQixLQUFLLGtCQUFrQixvQkFBb0IsQ0FBQyxHQUFHLHVCQUF1QixjQUFjLGlCQUFpQixLQUFLLFNBQVMsNEJBQTRCLElBQUksR0FBRyxpQkFBaUIsS0FBSyxlQUFlLDRCQUE0QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssYUFBYSx1QkFBdUIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLGlCQUFpQix1QkFBdUIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLGFBQWEsNEJBQTRCLElBQUksR0FBRyxpQkFBaUIsS0FBSyxXQUFXLHVCQUF1QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssY0FBYyx5QkFBeUIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLGFBQWEsd0JBQXdCLElBQUksR0FBRyxpQkFBaUIsS0FBSyxZQUFZLHVCQUF1QixJQUFJLENBQUMsQ0FBQztFQUN2M0IsYUFBYTtHQUNYLFlBQVk7R0FDWixtQkFBbUIsTUFBTTtHQUN6QixpQ0FBaUMsTUFBTTtHQUN2QyxxQkFBcUI7R0FDckIsNEJBQTRCLFVBQVU7R0FDdEMscUJBQXFCO0VBQ3ZCO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBaUJBO0VBQVc7RUFBcUJEO0VBQWM7RUFBTTtFQUFTO0VBQWtCO0VBQXFCO0VBQXNCO0VBQXNCO0VBQTBCO0VBQWtCO0VBQTBCO0VBQU07RUFBTztDQUF5QixDQUFDO0NBQzNSLE1BQU0seUJBQWtCLGVBQWU7RUFDckMsV0FBVztFQUNYLGVBQWU7RUFDZixTQUFTO0NBQ1gsSUFBSSxDQUFDLHNCQUFzQixxQkFBcUIsQ0FBQztDQUNqRCxNQUFNLHdCQUFpQixlQUFlO0VBQ3BDLFdBQVc7RUFJWCxlQUFlO0VBQ2YsYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixtQkFBbUIsT0FBTztHQUN4QixvQkFBb0I7R0FDcEIsZ0NBQWdDLEtBQUs7RUFDdkM7RUFDQSxxQkFBcUIsT0FBTztHQUMxQixvQkFBb0I7R0FDcEIsZ0NBQWdDLEtBQUs7RUFDdkM7RUFDQSxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLG9CQUFvQjtDQUN0QixJQUFJO0VBQUM7RUFBc0I7RUFBcUI7RUFBaUM7Q0FBNkIsQ0FBQztDQUMvRyxvQkFBYSxjQUFjLFVBQVU7RUFDbkM7RUFDQTtFQUNBLFNBQVM7Q0FDWCxJQUFJLENBQUMsR0FBRztFQUFDO0VBQVM7RUFBVztDQUFRLENBQUM7QUFDeEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hhQSxJQUFhLGtCQUFiLE1BQTZCOzs7Ozs7O0NBTzNCLGlCQUFpQixDQUFDOzs7OztDQU1sQixxQkFBcUI7Ozs7Q0FLckIsaUNBQWlCLElBQUksSUFBSTs7Ozs7Ozs7Ozs7Ozs7Q0FlekIsWUFBWSxlQUFlLGVBQWUsd0JBQXdCLE1BQU07RUFDdEUsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyx3QkFBd0I7Q0FDL0I7Q0FDQSxJQUFJLGdCQUFnQjtFQUNsQixPQUFPLEtBQUs7Q0FDZDs7Ozs7O0NBT0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLHNCQUFzQixLQUFLO0NBQ3pDOzs7Ozs7Q0FPQSxJQUFJLGNBQWM7RUFDaEIsT0FBTyxLQUFLO0NBQ2Q7Ozs7OztDQU9BLGVBQWUsVUFBVTtFQUN2QixLQUFLLGVBQWUsSUFBSSxRQUFRO0VBQ2hDLGFBQWE7R0FDWCxLQUFLLGVBQWUsT0FBTyxRQUFRO0VBQ3JDO0NBQ0Y7Ozs7Ozs7Q0FRQSxZQUFZLFVBQVU7RUFDcEIsS0FBSyxlQUFlLEtBQUssUUFBUTtFQUNqQyxLQUFLLGVBQWUsUUFBUTtFQUUxQixJQUFJLEtBQUssZUFBZSxTQUFTLEdBQUc7R0FRbEMsTUFBTSxNQUFNO0dBQ1osQ0FBQyxJQUFJLHdCQUF3QixlQUFlLE9BQU8sR0FBRyxjQUFjO0lBQ2xFLElBQUksS0FBSyxlQUFlLFNBQVMsR0FDL0IsUUFBUSxLQUFLLGdSQUEwUjtHQUUzUyxDQUFDO0VBQ0g7RUFFRixhQUFhO0dBQ1gsTUFBTSxRQUFRLEtBQUssZUFBZSxZQUFZLFFBQVE7R0FDdEQsSUFBSSxVQUFVLElBQ1osS0FBSyxlQUFlLE9BQU8sT0FBTyxDQUFDO0dBS3JDLEtBQUssZUFBZSxLQUFLLGVBQWUsS0FBSyxlQUFlLFNBQVMsTUFBTSxJQUFJO0VBQ2pGO0NBQ0Y7Ozs7O0NBTUEsZUFBZSxPQUFPO0VBQ3BCLElBQUksS0FBSyx1QkFBdUIsT0FBTztHQUNyQyxLQUFLLHFCQUFxQjtHQUMxQixLQUFLLGVBQWUsU0FBUSxhQUFZO0lBQ3RDLFNBQVM7R0FDWCxDQUFDO0VBQ0g7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxjQUFjLFdBQVc7RUFDdkIsTUFBTSxnQkFBZ0IsS0FBSztFQUMzQixJQUFJLGtCQUFrQixNQUFNO0dBRXhCLFFBQVEsS0FBSyxZQUFZLEtBQUssY0FBYyx5SkFBOEo7R0FFNU07RUFDRjtFQVNBLElBQUk7RUFDSixJQUFJLFdBQVc7R0FDYixLQUFLLElBQUksSUFBSSxLQUFLLGVBQWUsU0FBUyxHQUFHLEtBQUssS0FBSyxDQUFDLGdCQUFnQixLQUFLLEdBQzNFLGlCQUFpQixLQUFLLGVBQWUsRUFBRSxDQUFDLFFBQVEsZ0JBQWdCLFFBQVEsU0FBUztHQUVuRixtQkFBbUIsS0FBSyxjQUFjLFFBQVEsZ0JBQWdCLFFBQVEsU0FBUztFQUNqRjtFQUNBLElBQUksYUFBYSxDQUFDLGdCQUFnQjtHQUNoQyxJQUFJLEtBQUssdUJBQ1AsTUFBTSxJQUFJLE1BQThDLFlBQVksS0FBSyxjQUFjLGdEQUFnRCxVQUFVLG9KQUFtSyxLQUFLLGNBQWMsd0RBQXFJO0dBRzVjLFFBQVEsS0FBSyxZQUFZLEtBQUssY0FBYyx5Q0FBeUMsVUFBVSx3RUFBNkU7RUFFaEw7RUFDQSxjQUFjLFFBQVEsTUFBTSx5QkFBeUJJLGtCQUEwQixRQUFXLGNBQWMsQ0FBQztDQUMzRzs7Ozs7OztDQVFBLGFBQWE7RUFDWCxNQUFNLGdCQUFnQixLQUFLO0VBQzNCLElBQUksa0JBQWtCLE1BQU07R0FFeEIsUUFBUSxLQUFLLFlBQVksS0FBSyxjQUFjLDRGQUFpRztHQUUvSTtFQUNGO0VBQ0EsY0FBYyxRQUFRLE9BQU8seUJBQXlCQSxnQkFBd0IsQ0FBQztDQUNqRjtBQUNGOzs7Ozs7Ozs7Ozs7O0NDbE5BLENBQ0csV0FBWTtFQUNYLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsT0FBUSxNQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQVEsTUFBTSxLQUFLLE1BQU07RUFDeEU7RUFDQSxTQUFTLHVCQUF1QixXQUFXLGFBQWE7R0FDdEQscUJBQ0UsS0FBSyxNQUFNLE1BQU0sb0JBQ2Ysb0JBQW9CLENBQUMsR0FDdkIsUUFBUSxNQUNOLGdNQUNGO0dBQ0YsSUFBSSxRQUFRLFlBQVk7R0FDeEIsSUFBSSxDQUFDLDRCQUE0QjtJQUMvQixJQUFJLGNBQWMsWUFBWTtJQUM5QixTQUFTLE9BQU8sV0FBVyxNQUN4QixRQUFRLE1BQ1Asc0VBQ0YsR0FDQyw2QkFBNkIsQ0FBQztHQUNuQztHQUNBLGNBQWMsU0FBUyxFQUNyQixNQUFNO0lBQVM7SUFBb0I7R0FBWSxFQUNqRCxDQUFDO0dBQ0QsSUFBSSxPQUFPLFlBQVksRUFBRSxDQUFDLE1BQ3hCLGNBQWMsWUFBWTtHQUM1QixnQkFDRSxXQUFZO0lBQ1YsS0FBSyxRQUFRO0lBQ2IsS0FBSyxjQUFjO0lBQ25CLHVCQUF1QixJQUFJLEtBQUssWUFBWSxFQUFRLEtBQUssQ0FBQztHQUM1RCxHQUNBO0lBQUM7SUFBVztJQUFPO0dBQVcsQ0FDaEM7R0FDQSxVQUNFLFdBQVk7SUFDVix1QkFBdUIsSUFBSSxLQUFLLFlBQVksRUFBUSxLQUFLLENBQUM7SUFDMUQsT0FBTyxVQUFVLFdBQVk7S0FDM0IsdUJBQXVCLElBQUksS0FBSyxZQUFZLEVBQVEsS0FBSyxDQUFDO0lBQzVELENBQUM7R0FDSCxHQUNBLENBQUMsU0FBUyxDQUNaO0dBQ0EsY0FBYyxLQUFLO0dBQ25CLE9BQU87RUFDVDtFQUNBLFNBQVMsdUJBQXVCLE1BQU07R0FDcEMsSUFBSSxvQkFBb0IsS0FBSztHQUM3QixPQUFPLEtBQUs7R0FDWixJQUFJO0lBQ0YsSUFBSSxZQUFZLGtCQUFrQjtJQUNsQyxPQUFPLENBQUMsU0FBUyxNQUFNLFNBQVM7R0FDbEMsU0FBUyxPQUFPO0lBQ2QsT0FBTyxDQUFDO0dBQ1Y7RUFDRjtFQUNBLFNBQVMsdUJBQXVCLFdBQVcsYUFBYTtHQUN0RCxPQUFPLFlBQVk7RUFDckI7RUFDQSxnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiwrQkFDeEMsK0JBQStCLDRCQUE0QixNQUFNLENBQUM7RUFDcEUsSUFBSSx5QkFDRixXQUFXLGVBQWUsT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLElBQ3pELFdBQVcsTUFBTSxVQUNqQixZQUFZLE1BQU0sV0FDbEIsa0JBQWtCLE1BQU0saUJBQ3hCLGdCQUFnQixNQUFNLGVBQ3RCLG9CQUFvQixDQUFDLEdBQ3JCLDZCQUE2QixDQUFDLEdBQzlCLE9BQ0UsZ0JBQWdCLE9BQU8sVUFDdkIsZ0JBQWdCLE9BQU8sT0FBTyxZQUM5QixnQkFBZ0IsT0FBTyxPQUFPLFNBQVMsZ0JBQ25DLHlCQUNBO0VBQ1IsUUFBUSx1QkFDTixLQUFLLE1BQU0sTUFBTSx1QkFBdUIsTUFBTSx1QkFBdUI7RUFDdkUsZ0JBQWdCLE9BQU8sa0NBQ3JCLGVBQ0UsT0FBTywrQkFBK0IsOEJBQ3hDLCtCQUErQiwyQkFBMkIsTUFBTSxDQUFDO0NBQ3JFLEdBQUc7Ozs7O0NDekZILE9BQU87Ozs7Ozs7Ozs7Ozs7O0NDTVQsQ0FDRyxXQUFZO0VBQ1gsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixPQUFRLE1BQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUksTUFBUSxNQUFNLEtBQUssTUFBTTtFQUN4RTtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLCtCQUN4QywrQkFBK0IsNEJBQTRCLE1BQU0sQ0FBQztFQUNwRSxJQUFJLHlCQUNGLHVCQUNBLFdBQVcsZUFBZSxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFDekQsdUJBQXVCLEtBQUssc0JBQzVCLFNBQVMsTUFBTSxRQUNmLFlBQVksTUFBTSxXQUNsQixVQUFVLE1BQU0sU0FDaEIsZ0JBQWdCLE1BQU07RUFDeEIsUUFBUSxtQ0FBbUMsU0FDekMsV0FDQSxhQUNBLG1CQUNBLFVBQ0EsU0FDQTtHQUNBLElBQUksVUFBVSxPQUFPLElBQUk7R0FDekIsSUFBSSxTQUFTLFFBQVEsU0FBUztJQUM1QixJQUFJLE9BQU87S0FBRSxVQUFVLENBQUM7S0FBRyxPQUFPO0lBQUs7SUFDdkMsUUFBUSxVQUFVO0dBQ3BCLE9BQU8sT0FBTyxRQUFRO0dBQ3RCLFVBQVUsUUFDUixXQUFZO0lBQ1YsU0FBUyxpQkFBaUIsY0FBYztLQUN0QyxJQUFJLENBQUMsU0FBUztNQUNaLFVBQVUsQ0FBQztNQUNYLG1CQUFtQjtNQUNuQixlQUFlLFNBQVMsWUFBWTtNQUNwQyxJQUFJLEtBQUssTUFBTSxXQUFXLEtBQUssVUFBVTtPQUN2QyxJQUFJLG1CQUFtQixLQUFLO09BQzVCLElBQUksUUFBUSxrQkFBa0IsWUFBWSxHQUN4QyxPQUFRLG9CQUFvQjtNQUNoQztNQUNBLE9BQVEsb0JBQW9CO0tBQzlCO0tBQ0EsbUJBQW1CO0tBQ25CLElBQUksU0FBUyxrQkFBa0IsWUFBWSxHQUN6QyxPQUFPO0tBQ1QsSUFBSSxnQkFBZ0IsU0FBUyxZQUFZO0tBQ3pDLElBQUksS0FBSyxNQUFNLFdBQVcsUUFBUSxrQkFBa0IsYUFBYSxHQUMvRCxPQUFRLG1CQUFtQixjQUFlO0tBQzVDLG1CQUFtQjtLQUNuQixPQUFRLG9CQUFvQjtJQUM5QjtJQUNBLElBQUksVUFBVSxDQUFDLEdBQ2Isa0JBQ0EsbUJBQ0EseUJBQ0UsS0FBSyxNQUFNLG9CQUFvQixPQUFPO0lBQzFDLE9BQU8sQ0FDTCxXQUFZO0tBQ1YsT0FBTyxpQkFBaUIsWUFBWSxDQUFDO0lBQ3ZDLEdBQ0EsU0FBUyx5QkFDTCxLQUFLLElBQ0wsV0FBWTtLQUNWLE9BQU8saUJBQWlCLHVCQUF1QixDQUFDO0lBQ2xELENBQ047R0FDRixHQUNBO0lBQUM7SUFBYTtJQUFtQjtJQUFVO0dBQU8sQ0FDcEQ7R0FDQSxJQUFJLFFBQVEscUJBQXFCLFdBQVcsUUFBUSxJQUFJLFFBQVEsRUFBRTtHQUNsRSxVQUNFLFdBQVk7SUFDVixLQUFLLFdBQVcsQ0FBQztJQUNqQixLQUFLLFFBQVE7R0FDZixHQUNBLENBQUMsS0FBSyxDQUNSO0dBQ0EsY0FBYyxLQUFLO0dBQ25CLE9BQU87RUFDVDtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLDhCQUN4QywrQkFBK0IsMkJBQTJCLE1BQU0sQ0FBQztDQUNyRSxHQUFHOzs7OztDQzNGSCxPQUFPOzs7O0FDSFQsSUFBTSxRQUFRLENBQUM7QUFDZixJQUFJLGtCQUFrQjtBQUN0QixTQUFnQixjQUFjO0NBQzVCLE9BQU87QUFDVDtBQUlBLFNBQWdCLFNBQVMsTUFBTTtDQUM3QixNQUFNLEtBQUssSUFBSTtBQUNqQjs7Ozs7QUNGQSxJQUFNLHlCQURnQyxzQkFBc0IsRUFDRCxJQUFJLGVBQWU7QUFDOUUsU0FBZ0IsU0FBUyxPQUFPLFVBQVUsSUFBSSxJQUFJLElBQUk7Q0FDcEQsT0FBTyx1QkFBdUIsT0FBTyxVQUFVLElBQUksSUFBSSxFQUFFO0FBQzNEO0FBQ0EsU0FBUyxZQUFZLE9BQU8sVUFBVSxJQUFJLElBQUksSUFBSTtDQUNoRCxNQUFNLDRCQUFxQixrQkFBa0IsU0FBUyxNQUFNLFlBQVksR0FBRyxJQUFJLElBQUksRUFBRSxHQUFHO0VBQUM7RUFBTztFQUFVO0VBQUk7RUFBSTtDQUFFLENBQUM7Q0FDckgsV0FBT0Msa0NBQXFCLE1BQU0sV0FBVyxjQUFjLFlBQVk7QUFDekU7QUFDQSxTQUFTO0NBQ1AsT0FBTyxVQUFVO0VBQ2YsU0FBUyxZQUFZO0VBQ3JCLElBQUksQ0FBQyxTQUFTLGVBQWU7R0FDM0IsU0FBUyxXQUFXO0dBQ3BCLFNBQVMsWUFBWSxDQUFDO0dBQ3RCLFNBQVMsaUJBQWlCO0dBQzFCLFNBQVMsb0JBQW9CO0lBQzNCLElBQUksWUFBWTtJQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxVQUFVLFFBQVEsS0FBSyxHQUFHO0tBQ3JELE1BQU0sT0FBTyxTQUFTLFVBQVU7S0FDaEMsTUFBTSxRQUFRLEtBQUssU0FBUyxLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRTtLQUN2RSxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssT0FBTyxLQUFLLEdBQUc7TUFDakMsWUFBWTtNQUNaLEtBQUssUUFBUTtLQUNmO0lBQ0Y7SUFDQSxJQUFJLFdBQ0YsU0FBUyxZQUFZO0lBRXZCLE9BQU8sU0FBUztHQUNsQjtFQUNGO0NBQ0Y7Q0FDQSxNQUFNLFVBQVU7RUFDZCxJQUFJLFNBQVMsVUFBVSxTQUFTLEdBQUc7R0FDakMsSUFBSSxTQUFTLGdCQUFnQjtJQUMzQixTQUFTLGlCQUFpQjtJQUMxQixTQUFTLGFBQVksa0JBQWlCO0tBQ3BDLE1BQU0seUJBQVMsSUFBSSxJQUFJO0tBQ3ZCLEtBQUssTUFBTSxRQUFRLFNBQVMsV0FDMUIsT0FBTyxJQUFJLEtBQUssS0FBSztLQUV2QixNQUFNLGVBQWUsQ0FBQztLQUN0QixLQUFLLE1BQU0sU0FBUyxRQUNsQixhQUFhLEtBQUssTUFBTSxVQUFVLGFBQWEsQ0FBQztLQUVsRCxhQUFhO01BQ1gsS0FBSyxNQUFNLGVBQWUsY0FDeEIsWUFBWTtLQUVoQjtJQUNGO0dBQ0Y7R0FFQSxzQ0FBcUIsU0FBUyxXQUFXLFNBQVMsYUFBYSxTQUFTLFdBQVc7RUFDckY7Q0FDRjtBQUNGLENBQUM7QUFDRCxTQUFTLGFBQWEsT0FBTyxVQUFVLElBQUksSUFBSSxJQUFJO0NBQ2pELE1BQU0sV0FBVyxZQUFZO0NBQzdCLElBQUksQ0FBQyxVQUVILE9BQU8sWUFBWSxPQUFPLFVBQVUsSUFBSSxJQUFJLEVBQUU7Q0FFaEQsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsU0FBUyxhQUFhO0NBQ3RCLElBQUk7Q0FDSixJQUFJLENBQUMsU0FBUyxlQUFlO0VBQzNCLE9BQU87R0FDTDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsT0FBTyxTQUFTLE1BQU0sWUFBWSxHQUFHLElBQUksSUFBSSxFQUFFO0VBQ2pEO0VBQ0EsU0FBUyxVQUFVLEtBQUssSUFBSTtDQUM5QixPQUFPO0VBQ0wsT0FBTyxTQUFTLFVBQVU7RUFDMUIsSUFBSSxLQUFLLFVBQVUsU0FBUyxLQUFLLGFBQWEsWUFBWSxDQUFDLE9BQU8sR0FBRyxLQUFLLElBQUksRUFBRSxLQUFLLENBQUMsT0FBTyxHQUFHLEtBQUssSUFBSSxFQUFFLEtBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSyxJQUFJLEVBQUUsR0FBRztHQUN2SSxJQUFJLEtBQUssVUFBVSxPQUNqQixTQUFTLGlCQUFpQjtHQUU1QixLQUFLLFFBQVE7R0FDYixLQUFLLFdBQVc7R0FDaEIsS0FBSyxLQUFLO0dBQ1YsS0FBSyxLQUFLO0dBQ1YsS0FBSyxLQUFLO0dBQ1YsS0FBSyxRQUFRLFNBQVMsTUFBTSxZQUFZLEdBQUcsSUFBSSxJQUFJLEVBQUU7RUFDdkQ7Q0FDRjtDQUNBLE9BQU8sS0FBSztBQUNkO0FBQ0EsU0FBUyxlQUFlLE9BQU8sVUFBVSxJQUFJLElBQUksSUFBSTtDQUNuRCxXQUFPQyx1REFBaUMsTUFBTSxXQUFXLE1BQU0sYUFBYSxNQUFNLGNBQWEsVUFBUyxTQUFTLE9BQU8sSUFBSSxJQUFJLEVBQUUsQ0FBQztBQUNySTs7Ozs7OztBQ25HQSxJQUFhLFFBQWIsTUFBbUI7Ozs7Ozs7OztDQVlqQixZQUFZLE9BQU87RUFDakIsS0FBSyxRQUFRO0VBQ2IsS0FBSyw0QkFBWSxJQUFJLElBQUk7RUFDekIsS0FBSyxhQUFhO0NBQ3BCOzs7Ozs7O0NBUUEsYUFBWSxPQUFNO0VBQ2hCLEtBQUssVUFBVSxJQUFJLEVBQUU7RUFDckIsYUFBYTtHQUNYLEtBQUssVUFBVSxPQUFPLEVBQUU7RUFDMUI7Q0FDRjs7OztDQUtBLG9CQUFvQjtFQUNsQixPQUFPLEtBQUs7Q0FDZDs7Ozs7O0NBT0EsU0FBUyxVQUFVO0VBQ2pCLElBQUksS0FBSyxVQUFVLFVBQ2pCO0VBRUYsS0FBSyxRQUFRO0VBQ2IsS0FBSyxjQUFjO0VBQ25CLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLEtBQUssTUFBTSxZQUFZLEtBQUssV0FBVztHQUNyQyxJQUFJLGdCQUFnQixLQUFLLFlBR3ZCO0dBRUYsU0FBUyxRQUFRO0VBQ25CO0NBQ0Y7Ozs7OztDQU9BLE9BQU8sU0FBUztFQUNkLEtBQUssTUFBTSxPQUFPLFNBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxNQUFNLE1BQU0sUUFBUSxJQUFJLEdBQUc7R0FDN0MsS0FBSyxTQUFTO0lBQ1osR0FBRyxLQUFLO0lBQ1IsR0FBRztHQUNMLENBQUM7R0FDRDtFQUNGO0NBRUo7Ozs7Ozs7Q0FRQSxJQUFJLEtBQUssT0FBTztFQUNkLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxNQUFNLE1BQU0sS0FBSyxHQUNuQyxLQUFLLFNBQVM7R0FDWixHQUFHLEtBQUs7SUFDUCxNQUFNO0VBQ1QsQ0FBQztDQUVMOzs7O0NBS0EsWUFBWTtFQUNWLE1BQU0sV0FBVyxFQUNmLEdBQUcsS0FBSyxNQUNWO0VBQ0EsS0FBSyxTQUFTLFFBQVE7Q0FDeEI7Q0FDQSxJQUFJLFVBQVUsSUFBSSxJQUFJLElBQUk7RUFFeEIsT0FBTyxTQUFTLE1BQU0sVUFBVSxJQUFJLElBQUksRUFBRTtDQUM1QztBQUNGOzs7Ozs7QUNoR0EsSUFBYSxhQUFiLGNBQWdDLE1BQU07Ozs7Ozs7O0NBUXBDLFlBQVksT0FBTyxVQUFVLENBQUMsR0FBRyxXQUFXO0VBQzFDLE1BQU0sS0FBSztFQUNYLEtBQUssVUFBVTtFQUNmLEtBQUssWUFBWTtDQUNuQjs7Ozs7Ozs7OztDQVlBLGVBQWUsS0FBSyxPQUFPO0VBQ3pCLGFBQU0sY0FBYyxHQUFHO0VBRXZCLE1BQU0sUUFBUTtFQUNkLHlCQUF5QjtHQUN2QixJQUFJLE1BQU0sTUFBTSxTQUFTLE9BQ3ZCLE1BQU0sSUFBSSxLQUFLLEtBQUs7RUFFeEIsR0FBRztHQUFDO0dBQU87R0FBSztFQUFLLENBQUM7Q0FDeEI7Ozs7Ozs7O0NBU0EsMEJBQTBCLEtBQUssT0FBTztFQUVwQyxNQUFNLFFBQVE7RUFDZCx5QkFBeUI7R0FDdkIsSUFBSSxNQUFNLE1BQU0sU0FBUyxPQUN2QixNQUFNLElBQUksS0FBSyxLQUFLO0dBRXRCLGFBQWE7SUFDWCxNQUFNLElBQUksS0FBSyxNQUFTO0dBQzFCO0VBQ0YsR0FBRztHQUFDO0dBQU87R0FBSztFQUFLLENBQUM7Q0FDeEI7Ozs7Ozs7Q0FRQSxnQkFBZ0IsV0FBVztFQUV6QixNQUFNLFFBQVE7RUFDNkI7R0FFekMsYUFBTSxjQUFjLFlBQVcsTUFBSyxPQUFPLEtBQUssQ0FBQyxDQUFDO0dBQ2xELE1BQU0sb0JBQWEsT0FBTyxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztHQUNsRCxNQUFNLFdBQVcsT0FBTyxLQUFLLFNBQVM7R0FDdEMsSUFBSSxLQUFLLFdBQVcsU0FBUyxVQUFVLEtBQUssTUFBTSxLQUFLLFVBQVUsUUFBUSxTQUFTLE1BQU0sR0FDdEYsUUFBUSxNQUFNLCtGQUErRjtFQUVqSDtFQUNBLE1BQU0sZUFBZSxPQUFPLE9BQU8sU0FBUztFQUM1Qyx5QkFBeUI7R0FDdkIsTUFBTSxPQUFPLFNBQVM7RUFFeEIsR0FBRyxDQUFDLE9BQU8sR0FBRyxZQUFZLENBQUM7Q0FDN0I7Ozs7O0NBTUEsa0JBQWtCLEtBQUssWUFBWTtFQUNqQyxhQUFNLGNBQWMsR0FBRztFQUV2QixNQUFNLFFBQVE7RUFDZCxNQUFNLGVBQWUsZUFBZTtFQUNwQyx5QkFBeUI7R0FDdkIsSUFBSSxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsTUFBTSxNQUFNLE1BQU0sVUFBVSxHQUV6RCxNQUFNLFNBQVM7SUFDYixHQUFHLE1BQU07S0FDUixNQUFNO0dBQ1QsQ0FBQztFQUVMLEdBQUc7R0FBQztHQUFPO0dBQUs7R0FBWTtFQUFZLENBQUM7RUFDRTtHQUV6QyxNQUFNLFFBQVEsS0FBSyxxQ0FBcUIsSUFBSSxJQUFJO0dBQ2hELElBQUksQ0FBQyxNQUFNLElBQUksR0FBRyxHQUNoQixNQUFNLElBQUksS0FBSyxZQUFZO0dBRTdCLE1BQU0sdUJBQXVCLE1BQU0sSUFBSSxHQUFHO0dBQzFDLElBQUkseUJBQXlCLFVBQWEseUJBQXlCLGNBQ2pFLFFBQVEsTUFBTSwrQkFBK0IsZUFBZSxLQUFLLEtBQUssc0JBQXNCLElBQUksU0FBUyxFQUFFLFNBQVMsZUFBZSxPQUFPLEdBQUcsd0ZBQXdGO0VBRXpPO0NBQ0Y7Ozs7O0NBT0EsT0FBTyxLQUFLLElBQUksSUFBSSxJQUFJO0VBQ3RCLE1BQU0sV0FBVyxLQUFLLFVBQVU7RUFDaEMsT0FBTyxTQUFTLEtBQUssT0FBTyxJQUFJLElBQUksRUFBRTtDQUN4Qzs7Ozs7Ozs7Q0FVQSxTQUFTLEtBQUssSUFBSSxJQUFJLElBQUk7RUFDeEIsYUFBTSxjQUFjLEdBQUc7RUFDdkIsT0FBTyxTQUFTLE1BQU0sS0FBSyxVQUFVLE1BQU0sSUFBSSxJQUFJLEVBQUU7Q0FDdkQ7Ozs7Ozs7O0NBU0EsbUJBQW1CLEtBQUssSUFBSTtFQUMxQixhQUFNLGNBQWMsR0FBRztFQUN2QixNQUFNLGlCQUFpQixrQkFBa0IsTUFBTSxJQUFJO0VBQ25ELEtBQUssUUFBUSxPQUFPO0NBQ3RCOzs7Ozs7O0NBUUEsZUFBZSxLQUFLO0VBQ2xCLE1BQU0sbUJBQVksT0FBTyxNQUFTO0VBQ2xDLElBQUksSUFBSSxZQUFZLFFBQ2xCLElBQUksV0FBVSxVQUFTO0dBQ3JCLEtBQUssSUFBSSxLQUFLLEtBQUs7RUFDckI7RUFFRixPQUFPLElBQUk7Q0FDYjs7Ozs7OztDQVNBLFFBQVEsVUFBVSxVQUFVO0VBQzFCLElBQUk7RUFDSixJQUFJLE9BQU8sYUFBYSxZQUN0QixXQUFXO09BRVgsV0FBVyxLQUFLLFVBQVU7RUFFNUIsSUFBSSxZQUFZLFNBQVMsS0FBSyxLQUFLO0VBQ25DLFNBQVMsV0FBVyxXQUFXLElBQUk7RUFDbkMsT0FBTyxLQUFLLFdBQVUsY0FBYTtHQUNqQyxNQUFNLFlBQVksU0FBUyxTQUFTO0dBQ3BDLElBQUksQ0FBQyxPQUFPLEdBQUcsV0FBVyxTQUFTLEdBQUc7SUFDcEMsTUFBTSxXQUFXO0lBQ2pCLFlBQVk7SUFDWixTQUFTLFdBQVcsVUFBVSxJQUFJO0dBQ3BDO0VBQ0YsQ0FBQztDQUNIO0FBQ0Y7OztBQ3ZNQSxJQUFNQyxjQUFZO0NBQ2hCLE9BQU0sVUFBUyxNQUFNO0NBQ3JCLG1CQUFrQixVQUFTLE1BQU07Q0FDakMsc0JBQXFCLFVBQVMsTUFBTTtDQUNwQyxtQkFBa0IsVUFBUyxNQUFNLHFCQUFxQixNQUFNO0NBQzVELGtCQUFpQixVQUFTLE1BQU07Q0FDaEMsYUFBWSxVQUFTLE1BQU07QUFDN0I7QUFDQSxJQUFhLG9CQUFiLGNBQXVDLFdBQVc7Q0FDaEQsWUFBWSxTQUFTO0VBQ25CLE1BQU0sRUFDSixVQUNBLFFBQ0EsY0FDQSxpQkFDQSxHQUFHLGlCQUNEO0VBQ0osTUFBTTtHQUNKLEdBQUc7R0FDSCxtQkFBbUIsYUFBYTtHQUNoQyxxQkFBcUIsYUFBYTtFQUNwQyxHQUFHO0dBQ0Q7R0FDQSxTQUFTLEVBQ1AsU0FBUyxDQUFDLEVBQ1o7R0FDQSxRQUFRLG1CQUFtQjtHQUMzQjtHQUNBO0VBQ0YsR0FBR0EsV0FBUztFQUNaLEtBQUssV0FBVztDQUNsQjs7OztDQUtBLGlCQUFpQixTQUFTLFVBQVU7RUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLE1BQU0sUUFHNUIsU0FBUyxRQUFRLGlCQUFpQixLQUFLLEdBQ3JDLEtBQUssUUFBUSxRQUFRLFFBQVEsWUFBWSxVQUFVLFFBQVE7Q0FFL0Q7Ozs7Q0FLQSxzQkFBc0IsU0FBUyxpQkFBaUI7RUFDOUMsS0FBSyxjQUFjLFNBQVMsYUFBYSxLQUFLO0VBQzlDLE1BQU0sVUFBVTtHQUNkLE1BQU07R0FDTixRQUFRLGFBQWE7R0FDckIsYUFBYSxhQUFhO0dBQzFCLFFBQVEsS0FBSyxRQUFRO0dBQ3JCLGdCQUFnQixhQUFhO0VBQy9CO0VBQ0EsS0FBSyxRQUFRLE9BQU8sS0FBSyxjQUFjLE9BQU87Q0FDaEQ7Ozs7Ozs7Q0FRQSxXQUFXLFNBQVMsaUJBQWlCO0VBQ25DLElBQUksS0FBSyxVQUFVO0dBQ2pCLEtBQUssUUFBUSxlQUFlLFNBQVMsWUFBWTtHQUNqRDtFQUNGO0VBQ0EsS0FBSyxtQkFBbUIsU0FBUyxZQUFZO0VBQzdDLEtBQUssUUFBUSxlQUFlLFNBQVMsWUFBWTtDQUNuRDtBQUNGOzs7Ozs7O0FDbkVBLFNBQWdCLDZCQUE2QixTQUFTO0NBQ3BELE1BQU0sRUFDSixZQUNBLDhCQUE4QixPQUM5QixxQkFBcUIseUJBQ3JCLFlBQ0EsUUFDQSxpQkFDRTtDQUNKLE1BQU0sT0FBTyxXQUFXLFNBQVMsTUFBTTtDQUN2QyxNQUFNLG1CQUFtQixXQUFXLFNBQVMsc0JBQXNCO0NBQ25FLE1BQU0sa0JBQWtCLFdBQVcsU0FBUyw4QkFBOEIsaUJBQWlCLG1CQUFtQjtDQUM5RyxNQUFNLGtCQUFrQixXQUFXLFFBQVE7Q0FDM0MsTUFBTSxtQkFBbUI7Q0FDekIsTUFBTSxnQ0FBeUIsT0FBTyxJQUFJO0NBQzFDLElBQUksNEJBQTRCLFVBQWEsaUJBQWlCLFlBQVksTUFDeEUsaUJBQWlCLFVBQVUsSUFBSSxrQkFBa0I7RUFDL0M7RUFDQSxrQkFBa0I7RUFDbEI7RUFDQTtFQUNBO0VBQ0EsY0FBYztFQUNkO0VBQ0EsVUFBVTtFQUNWO0NBQ0YsQ0FBQztDQUVILE1BQU0sUUFBUSwyQkFBMkIsaUJBQWlCO0NBQzFELFdBQVcsZUFBZSxjQUFjLFVBQVU7Q0FDbEQseUJBQXlCO0VBQ3ZCLE1BQU0sZUFBZTtHQUNuQjtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsSUFBSSxVQUFVLGdCQUFnQixHQUM1QixhQUFhLHNCQUFzQjtFQUVyQyxJQUFJLE1BQU0sTUFBTSxzQkFBc0IsTUFBTSxNQUFNLGtCQUNoRCxhQUFhLG9CQUFvQjtFQUVuQyxNQUFNLE9BQU8sWUFBWTtDQUMzQixHQUFHO0VBQUM7RUFBTTtFQUFZO0VBQWtCO0VBQWlCO0NBQUssQ0FBQztDQUcvRCxNQUFNLFFBQVEsZUFBZTtDQUM3QixNQUFNLFFBQVEsU0FBUztDQUN2QixPQUFPO0FBQ1Q7OztBQzVDQSxJQUFhLHdCQUF3QjtDQUNuQyxVQUFVO0VBQ1Qsc0JBQXNCO0FBQ3pCOzs7Ozs7QUFPQSxTQUFnQiwwQkFBMEIsVUFBVTtDQUNsRCxRQUFPLG9CQUFtQixvQkFBb0IsVUFBVSxTQUFTLFVBQVU7QUFDN0U7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFnQixrQkFBa0IsYUFBYSw4QkFBOEIsT0FBTztDQUNsRixNQUFNLGFBQWEsTUFBTTtDQUN6QixNQUFNLFNBQVMsd0JBQXdCLEtBQUs7Q0FDNUMsTUFBTSxRQUFRLHFCQUFxQixZQUFZLFlBQVksTUFBTSxDQUFDLENBQUMsQ0FBQztDQUNwRSw2QkFBNkI7RUFDM0IsWUFBWTtFQUNaO0VBQ0EscUJBQXFCLE1BQU0sTUFBTTtFQUNqQztFQUNBO0VBQ0EsY0FBYyxNQUFNO0NBQ3RCLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7O0FBWUEsU0FBZ0Isc0JBQXNCLEVBQ3BDLFFBQ0EsU0FDQztDQUNELHlCQUF5QjtFQUN2QixPQUFPLE9BQU8sWUFBWSxLQUFLO0NBQ2pDLEdBQUcsQ0FBQyxRQUFRLEtBQUssQ0FBQztDQUNsQixPQUFPO0FBQ1Q7Ozs7OztBQU9BLFNBQWdCLHVCQUF1QixJQUFJLE9BQU87Q0FFaEQsTUFBTSxzQ0FBK0IsT0FBTyxJQUFJO0NBQ2hELE1BQU0sb0NBQTZCLE9BQU8sSUFBSTtDQUM5QyxvQkFBYSxhQUFZLFlBQVc7RUFDbEMsSUFBSSxPQUFPLFFBQ1Q7RUFFRixJQUFJLHlCQUF5QjtFQUM3QixJQUFJLHVCQUF1QixZQUFZLE1BQU07R0FDM0MsTUFBTSxlQUFlLHVCQUF1QjtHQUM1QyxNQUFNLG9CQUFvQixxQkFBcUI7R0FDL0MsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLGdCQUFnQixRQUFRLFlBQVk7R0FDekUsSUFBSSxxQkFBcUIsbUJBQW1CLG1CQUFtQjtJQUM3RCxNQUFNLFFBQVEsZ0JBQWdCLE9BQU8sWUFBWTtJQUNqRCx5QkFBeUI7R0FDM0I7R0FDQSx1QkFBdUIsVUFBVTtHQUNqQyxxQkFBcUIsVUFBVTtFQUNqQztFQUNBLElBQUksWUFBWSxNQUFNO0dBQ3BCLHVCQUF1QixVQUFVO0dBQ2pDLHFCQUFxQixVQUFVO0dBQy9CLE1BQU0sUUFBUSxnQkFBZ0IsSUFBSSxJQUFJLE9BQU87R0FDN0MseUJBQXlCO0VBQzNCO0VBQ0EsSUFBSSx3QkFBd0I7R0FDMUIsTUFBTSxlQUFlLE1BQU0sUUFBUSxnQkFBZ0I7R0FDbkQsSUFBSSxNQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sTUFBTSxpQkFBaUIsY0FDdkQsTUFBTSxJQUFJLGdCQUFnQixZQUFZO0VBRTFDO0NBQ0YsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ2hCO0FBQ0EsU0FBZ0Isa0JBQWtCLE9BQU8sTUFBTSxTQUFTLHdCQUF3QixPQUFPO0NBQ3JGLElBQUksTUFFRixNQUFNLDJCQUEyQjtNQUM1QixJQUFJLHVCQUNULE1BQU0sMkJBQTJCO0NBRW5DLE1BQU0sWUFBWSxTQUFTLE1BQU07Q0FJakMsSUFBSSxhQUFhLE1BQU07RUFDckIsTUFBTSxrQkFBa0I7RUFDeEIsTUFBTSx1QkFBdUIsV0FBVztDQUMxQztBQUNGOzs7Ozs7Ozs7QUE4REEsU0FBZ0IseUJBQXlCLFdBQVcsbUJBQW1CLE9BQU8sY0FBYztDQUMxRixNQUFNLHlCQUF5QixNQUFNLFNBQVMsc0JBQXNCLFNBQVM7Q0FDN0UsTUFBTSxzQkFBc0IsdUJBQXVCLFdBQVcsS0FBSztDQUtuRSxNQUFNLG1CQUFtQixtQkFBa0IsWUFBVztFQUNwRCxNQUFNLE9BQU8sTUFBTSxPQUFPLE1BQU07RUFDaEMsTUFBTSxrQkFBa0IsTUFBTSxPQUFPLGlCQUFpQjtFQUN0RCxJQUFJLG9CQUFvQixXQUFXO0dBQ2pDLE1BQU0sT0FBTztJQUNYLHNCQUFzQjtJQUN0QixHQUFJLE9BQU8sZUFBZTtHQUM1QixDQUFDO0dBQ0Q7RUFDRjtFQUNBLElBQUksbUJBQW1CLFFBQVEsTUFJN0IsTUFBTSxPQUFPO0dBQ1gsaUJBQWlCO0dBQ2pCLHNCQUFzQjtHQUN0QixHQUFHO0VBQ0wsQ0FBQztDQUVMLENBQUM7Q0FPRCxNQUFNLCtCQUF3QixhQUFZLFlBQVc7RUFDbkQsb0JBQW9CLE9BQU87RUFDM0IsSUFBSSxTQUNGLGlCQUFpQixPQUFPO0NBRTVCLEdBQUcsQ0FBQyxxQkFBcUIsZ0JBQWdCLENBQUM7Q0FDMUMseUJBQXlCO0VBQ3ZCLElBQUksd0JBQ0YsTUFBTSxPQUFPO0dBQ1gsc0JBQXNCLGtCQUFrQjtHQUN4QyxHQUFHO0VBQ0wsQ0FBQztDQUdMLEdBQUc7RUFBQztFQUF3QjtFQUFPO0VBQW1CLEdBQUcsT0FBTyxPQUFPLFlBQVk7Q0FBQyxDQUFDO0NBQ3JGLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF1QkEsU0FBZ0IseUJBQXlCLE9BQU8sVUFBVSxDQUFDLEdBQUc7Q0FDNUQsTUFBTSxFQUNKLDhCQUE4QixVQUM1QjtDQUVKLE1BQU0sMENBQW1DLE9BQU8sSUFBSTtDQUNwRCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLGNBQWM7Q0FHMUQsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQU14RCxNQUFNLCtCQUErQixNQUFNLFNBQVMsc0JBQXNCO0NBQzFFLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsTUFBTTtHQUNULDJCQUEyQixVQUFVO0dBQ3JDLElBQUksTUFBTSxNQUFNLGlCQUFpQixHQUMvQixNQUFNLElBQUksZ0JBQWdCLENBQUM7R0FFN0I7RUFDRjtFQUNBLE1BQU0sZUFBZSxNQUFNLFFBQVEsZ0JBQWdCO0VBQ25ELE1BQU0sZUFBZSxDQUFDO0VBQ3RCLElBQUksTUFBTSxNQUFNLGlCQUFpQixjQUMvQixhQUFhLGVBQWU7RUFFOUIsTUFBTSx5QkFBeUIsTUFBTSxPQUFPLGlCQUFpQjtFQUM3RCxJQUFJLHNCQUFzQjtFQUMxQixJQUFJLHdCQUF3QjtHQUMxQixNQUFNLHVCQUF1QixNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsc0JBQXNCO0dBQ3pGLElBQUksQ0FBQyxzQkFBc0I7SUFDekIsS0FBSyxNQUFNLENBQUMsV0FBVyxtQkFBbUIsTUFBTSxRQUFRLGdCQUFnQixRQUFRLEdBQzlFLElBQUksbUJBQW1CLE1BQU0sTUFBTSxzQkFBc0I7S0FDdkQsYUFBYSxrQkFBa0I7S0FDL0IsYUFBYSx1QkFBdUI7S0FDcEMsMkJBQTJCLFVBQVU7S0FDckM7SUFDRjtJQUVGLElBQUksYUFBYSxvQkFBb0IsUUFBVztLQUM5QyxJQUFJLDJCQUEyQixZQUFZLHdCQUN6QyxzQkFBc0I7VUFFdEIsMkJBQTJCLFVBQVU7SUFFekM7R0FDRixPQUFPO0lBQ0wsMkJBQTJCLFVBQVU7SUFDckMsSUFBSSx5QkFBeUIsTUFBTSxNQUFNLHNCQUN2QyxhQUFhLHVCQUF1QjtHQUV4QztFQUNGLE9BQ0UsMkJBQTJCLFVBQVU7RUFFdkMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLDBCQUEwQixpQkFBaUIsR0FBRztHQUN6RSxNQUFNLGlCQUFpQixNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsQ0FBQyxDQUFDLEtBQUs7R0FDcEUsSUFBSSxDQUFDLGVBQWUsTUFBTTtJQUN4QixNQUFNLENBQUMsbUJBQW1CLDBCQUEwQixlQUFlO0lBQ25FLGFBQWEsa0JBQWtCO0lBQy9CLGFBQWEsdUJBQXVCO0lBQ3BDLDJCQUEyQixVQUFVO0dBQ3ZDO0VBQ0Y7RUFDQSxJQUFJLGFBQWEsaUJBQWlCLFVBQWEsYUFBYSxvQkFBb0IsVUFBYSxhQUFhLHlCQUF5QixRQUNqSSxNQUFNLE9BQU8sWUFBWTtFQUUzQixJQUFJLHFCQUNFO09BQUEsNkJBRUYscUJBQXFCO0lBQ25CLElBQUksTUFBTSxPQUFPLE1BQU0sS0FBSyxNQUFNLE9BQU8saUJBQWlCLE1BQU0sdUJBQXVCLENBQUMsTUFBTSxRQUFRLGdCQUFnQixRQUFRLG1CQUFtQixHQUFHO0tBQ2xKLE1BQU0sZUFBZSx5QkFBeUJDLElBQVk7S0FDMUQsTUFBTSxRQUFRLE9BQU8sWUFBWTtLQUdqQyxJQUFJLENBQUMsYUFBYSxZQUNoQixNQUFNLE9BQU87TUFDWCxpQkFBaUI7TUFDakIsc0JBQXNCO0tBQ3hCLENBQUM7SUFFTDtHQUNGLENBQUM7RUFBQTtDQUdQLEdBQUc7RUFBQztFQUFNO0VBQU87RUFBc0I7RUFBaUI7RUFBOEI7Q0FBMkIsQ0FBQztBQUNwSDs7Ozs7Ozs7Ozs7O0FBYUEsU0FBZ0Isd0JBQXdCLE1BQU0sT0FBTyxXQUFXO0NBQzlELE1BQU0sRUFDSixTQUNBLFlBQ0EscUJBQ0Usb0JBQW9CLElBQUk7Q0FDNUIsTUFBTSwyQkFBMkIsTUFBTSxTQUFTLDBCQUEwQjtDQUcxRSxNQUFNLGlDQUFpQyxPQUFPLFFBQVE7Q0FDdEQsTUFBTSxnQkFBZ0I7RUFDcEI7RUFDQTtFQUNBLDBCQUEwQjtDQUM1QixDQUFDO0NBQ0QsTUFBTSxlQUFlLHdCQUF3QjtFQUMzQyxXQUFXLEtBQUs7RUFDaEIsTUFBTSxPQUFPO0dBQ1gsaUJBQWlCO0dBQ2pCLHNCQUFzQjtHQUN0QixTQUFTO0dBQ1QsMEJBQTBCO0VBQzVCLENBQUM7RUFDRCxZQUFZO0VBQ1osTUFBTSxRQUFRLHVCQUF1QixLQUFLO0NBQzVDLENBQUM7Q0FDRCxzQkFBc0I7RUFDcEIsU0FBUyxXQUFXLENBQUMsUUFBUSxDQUFDO0VBQzlCO0VBQ0EsS0FBSyxNQUFNLFFBQVE7RUFDbkIsYUFBYTtHQUNYLElBQUksQ0FBQyxNQUNILGFBQWE7RUFFakI7Q0FDRixDQUFDO0NBQ0QsT0FBTztFQUNMO0VBQ0E7Q0FDRjtBQUNGO0FBQ0EsU0FBZ0IseUJBQXlCLE9BQU8sV0FBVztDQUN6RCxNQUFNLGdCQUFnQixTQUFTO0NBQy9CLCtCQUErQjtFQUM3QixNQUFNLE9BQU87R0FDWCxvQkFBb0I7R0FDcEIsc0JBQXNCO0dBQ3RCLFlBQVk7RUFDZCxDQUFDO0NBQ0gsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUNaO0FBQ0EsU0FBZ0IsaUJBQWlCLE9BQU8sTUFBTTtDQUM1Qyx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFFBQVEsTUFBTSxNQUFNLGVBQWUsTUFDdEMsTUFBTSxJQUFJLGNBQWMsSUFBSTtDQUVoQyxHQUFHLENBQUMsTUFBTSxLQUFLLENBQUM7Q0FDaEIsK0JBQStCO0VBQzdCLElBQUksTUFBTSxNQUFNLGVBQWUsTUFDN0IsTUFBTSxJQUFJLGNBQWMsSUFBSTtDQUVoQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ1o7Ozs7Ozs7Ozs7O0FDOWFBLElBQUk7QUFDSixTQUFTLGlCQUFpQixLQUFLO0NBQzdCLHVDQUF1QixJQUFJLFFBQVE7Q0FDbkMsSUFBSSxhQUFhLG1CQUFtQixJQUFJLEdBQUc7Q0FDM0MsSUFBSSxDQUFDLFlBQVk7RUFDZiw2QkFBYSxJQUFJLFFBQVE7RUFDekIsbUJBQW1CLElBQUksS0FBSyxVQUFVO0NBQ3hDO0NBQ0EsT0FBTztBQUNUOzs7Ozs7O0FBUUEsSUFBYSxrQkFBYixNQUE2QjtDQUMzQixjQUFjO0VBQ1osS0FBSyx3QkFBUSxJQUFJLElBQUk7Q0FDdkI7Ozs7OztDQU9BLElBQUksSUFBSSxTQUFTO0VBQzRCO0dBQ3pDLE1BQU0sYUFBYSxpQkFBaUIsSUFBSTtHQUN4QyxNQUFNLGFBQWEsV0FBVyxJQUFJLE9BQU87R0FDekMsSUFBSSxlQUFlLFVBQWEsZUFBZSxJQUc3QyxNQUFNLElBQUksTUFBTSx3RkFBd0Y7R0FLMUcsTUFBTSxrQkFBa0IsS0FBSyxNQUFNLElBQUksRUFBRTtHQUN6QyxJQUFJLG9CQUFvQixVQUFhLG9CQUFvQixTQUN2RCxXQUFXLE9BQU8sZUFBZTtHQUVuQyxXQUFXLElBQUksU0FBUyxFQUFFO0VBQzVCO0VBQ0EsS0FBSyxNQUFNLElBQUksSUFBSSxPQUFPO0NBQzVCOzs7O0NBS0EsT0FBTyxJQUFJO0VBQ2tDO0dBQ3pDLE1BQU0sVUFBVSxLQUFLLE1BQU0sSUFBSSxFQUFFO0dBQ2pDLElBQUksWUFBWSxRQUNkLG9CQUFvQixJQUFJLElBQUksQ0FBQyxFQUFFLE9BQU8sT0FBTztFQUVqRDtFQUNBLEtBQUssTUFBTSxPQUFPLEVBQUU7Q0FDdEI7Ozs7Q0FLQSxXQUFXLFNBQVM7RUFDbEIsS0FBSyxNQUFNLGNBQWMsS0FBSyxNQUFNLE9BQU8sR0FDekMsSUFBSSxlQUFlLFNBQ2pCLE9BQU87RUFHWCxPQUFPO0NBQ1Q7Ozs7Q0FLQSxtQkFBbUIsV0FBVztFQUM1QixLQUFLLE1BQU0sV0FBVyxLQUFLLE1BQU0sT0FBTyxHQUN0QyxJQUFJLFVBQVUsT0FBTyxHQUNuQixPQUFPO0VBR1gsT0FBTztDQUNUOzs7O0NBS0EsUUFBUSxJQUFJO0VBQ1YsT0FBTyxLQUFLLE1BQU0sSUFBSSxFQUFFO0NBQzFCOzs7O0NBS0EsVUFBVTtFQUNSLE9BQU8sS0FBSyxNQUFNLFFBQVE7Q0FDNUI7Ozs7Q0FLQSxXQUFXO0VBQ1QsT0FBTyxLQUFLLE1BQU0sT0FBTztDQUMzQjs7OztDQUtBLElBQUksT0FBTztFQUNULE9BQU8sS0FBSyxNQUFNO0NBQ3BCO0FBQ0Y7OztBQ3RIQSxTQUFnQixzQkFBc0I7Q0FDcEMsT0FBTyxJQUFJLGtCQUFrQjtFQUMzQixNQUFNO0VBQ04sa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsaUJBQWlCLElBQUksZ0JBQWdCO0VBQ3JDLFlBQVk7RUFDWixVQUFVO0VBQ1YsUUFBUTtFQUNSLGNBQWM7Q0FDaEIsQ0FBQztBQUNIOzs7Ozs7QUNOQSxTQUFnQiwrQkFBK0I7Q0FDN0MsT0FBTztFQUNMLE1BQU07RUFDTixVQUFVO0VBQ1YsU0FBUztFQUNULGtCQUFrQjtFQUNsQixxQkFBcUIsb0JBQW9CO0VBQ3pDLFlBQVk7RUFDWixjQUFjO0VBQ2QsMEJBQTBCO0VBQzFCLFNBQVM7RUFDVCxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLGVBQWU7RUFDZixjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixzQkFBc0I7RUFDdEIsWUFBWTtDQUNkO0FBQ0Y7QUFDQSxTQUFnQiwrQkFBK0IsaUJBQWlCLFlBQVksU0FBUyxPQUFPO0NBQzFGLE9BQU8sSUFBSSxrQkFBa0I7RUFDM0IsTUFBTTtFQUNOLGtCQUFrQjtFQUNsQixpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCO0VBQ0E7RUFDQSxVQUFVO0VBQ1Y7RUFDQSxjQUFjO0NBQ2hCLENBQUM7QUFDSDtBQUNBLElBQU0sMkJBQTBCLFVBQVMsTUFBTSxpQkFBaUIsTUFBTTtBQUN0RSxJQUFNLGdCQUFlLFVBQVMsTUFBTSxZQUFZLE1BQU07QUFDdEQsSUFBTSxtQkFBa0IsVUFBUztDQUUvQixRQURnQixNQUFNLGNBQWMsTUFBTSxNQUFNLGVBQzlCO0FBQ3BCO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTyxXQUFXO0NBQzlDLE9BQU8sY0FBYyxVQUFhLGFBQWEsS0FBSyxLQUFLLHdCQUF3QixLQUFLLE1BQU07QUFDOUY7QUFDQSxTQUFTLG9DQUFvQyxPQUFPLFdBQVc7Q0FDN0QsSUFBSSxxQkFBcUIsT0FBTyxTQUFTLEdBQ3ZDLE9BQU87Q0FFVCxPQUFPLGNBQWMsVUFBYSxhQUFhLEtBQUssS0FBSyx3QkFBd0IsS0FBSyxLQUFLLFFBQVEsTUFBTSxpQkFBaUI7QUFDNUg7QUFDQSxJQUFhLHNCQUFzQjtDQUNqQyxNQUFNO0NBQ04sVUFBUyxVQUFTLE1BQU07Q0FDeEIsbUJBQWtCLFVBQVMsTUFBTTtDQUNqQyxzQkFBcUIsVUFBUyxNQUFNO0NBQ3BDLGVBQWMsVUFBUyxNQUFNO0NBQzdCLDJCQUEwQixVQUFTLE1BQU07Q0FDekMsVUFBUyxVQUFTLE1BQU07Q0FDeEIsaUJBQWlCO0NBQ2pCLHVCQUFzQixVQUFTLE1BQU0sVUFBVSxNQUFNLHVCQUF1QjtDQUM1RSxTQUFTOzs7O0NBSVQsa0JBQWtCLE9BQU8sY0FBYyxjQUFjLFVBQWEsd0JBQXdCLEtBQUssTUFBTTs7OztDQUlyRyxvQkFBb0IsT0FBTyxjQUFjLHFCQUFxQixPQUFPLFNBQVM7Ozs7Q0FJOUUscUJBQXFCLE9BQU8sY0FBYyxjQUFjLFVBQWEsd0JBQXdCLEtBQUssTUFBTSxhQUFhLE1BQU07Q0FDM0gsZUFBZSxPQUFPLGFBQWEsV0FBVyxNQUFNLHFCQUFxQixNQUFNOzs7O0NBSS9FLGlCQUFpQixPQUFPLGNBQWMsb0NBQW9DLE9BQU8sU0FBUyxJQUFJLGdCQUFnQixLQUFLLElBQUk7Q0FDdkgsYUFBWSxVQUFTLE1BQU07Q0FDM0IsZUFBYyxVQUFTLE1BQU07Q0FDN0Isb0JBQW1CLFVBQVMsTUFBTTtBQUNwQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekVBLFNBQWdCLG9CQUFvQixRQUFRO0NBQzFDLE1BQU0seUJBQWtCLGFBQVksYUFBWTtFQUM5QyxJQUFJLFdBQVcsUUFDYixPQUFPO0VBRVQsT0FBTyxPQUFPLGVBQWUsUUFBUTtDQUN2QyxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsTUFBTSwyQkFBb0Isa0JBQWtCO0VBQzFDLE9BQU8sV0FBVyxTQUFZLFNBQVksT0FBTztDQUNuRCxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsV0FBT0gsa0NBQXFCLFdBQVcsbUJBQW1CLFFBQVEsV0FBVztBQUMvRTs7O0FDbEJBLFNBQWdCLG1CQUFtQixFQUNqQyxPQUNBLGVBQ0EsWUFDQztDQUNELE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLDBCQUEwQixNQUFNLFNBQVMseUJBQXlCO0NBQ3hFLE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLGVBQWUsTUFBTSxTQUFTLGNBQWM7Q0FDbEQsTUFBTSxzQkFBc0IsTUFBTSxTQUFTLHFCQUFxQjtDQUNoRSxNQUFNLENBQUMsc0JBQXNCLHdDQUFpQyxTQUFTLENBQUM7Q0FDeEUsTUFBTSxDQUFDLHNCQUFzQix3Q0FBaUMsU0FBUyxDQUFDO0NBQ3hFLE1BQU0sWUFBWSx5QkFBeUI7Q0FDM0MsTUFBTSxVQUFVLFdBQVcscUJBQXFCO0VBQzlDLG9CQUFvQjtHQUNsQixJQUFJLE1BQU0sUUFBUSxvQkFBb0IsV0FBVyxNQUFNLFFBQVEsWUFBWSxTQUN6RSxPQUFPO0dBSVQsT0FBTztJQUNMLE9BQU8sVUFBVSxlQUFlLFdBQVc7SUFDM0MsT0FBTztHQUNUO0VBQ0Y7RUFDQSxhQUFhLE9BQU87R0FDbEIsSUFBSSxDQUFDLE1BQU0sUUFBUSx1QkFBdUIsU0FDeEMsT0FBTztHQUtULElBQUksWUFBWSxTQUFTLE1BQU0sV0FBVyxHQUN4QyxPQUFPO0dBRVQsSUFBSSxhQUFhLE9BQU87SUFLdEIsSUFBSSxNQUFNLFNBQVMsWUFDYjtTQUFBLE1BQU0sZUFBZSxXQUFXLEtBQUssTUFBTSxRQUFRLFdBQVcsR0FDaEUsT0FBTztJQUFBLE9BRUosSUFBSSxNQUFNLFFBQVEsV0FBVyxHQUNsQyxPQUFPO0dBRVg7R0FDQSxNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLElBQUksYUFBYSxDQUFDLHlCQUF5QjtJQUl6QyxJQUFJLE9BQU87S0FDVCxNQUFNLG1CQUFtQixNQUFNLFFBQVEsb0JBQW9CO0tBQzNELE1BQU0sV0FBVyxNQUFNLFFBQVEsWUFBWTtLQUMzQyxPQUFPLG9CQUFvQixXQUFXLHFCQUFxQixVQUFVLGFBQWEsVUFBVSxTQUFTLFFBQVEsWUFBWSxLQUFLLENBQUMsUUFBUSxhQUFhLHFCQUFxQixJQUFJO0lBQy9LO0lBQ0EsT0FBTztHQUNUO0dBQ0EsT0FBTztFQUNUO0VBQ0EsV0FBVztDQUNiLENBQUM7Q0FDRCxjQUFjLFFBQVEsVUFBVSxNQUFNLFlBQVk7Q0FJbEQsTUFBTSxtQkFBbUIsdUJBQXVCLGFBQWEsZ0JBQWdCO0VBQzNFLHdCQUF3QixXQUFXO0VBQ25DLHdCQUF3QixXQUFXO0NBQ3JDLENBQUM7Q0FHRCx5QkFBeUI7RUFDdkIsSUFBSSxlQUFlLG9CQUFvQjtHQUNyQyxJQUFJLE1BQ0YsY0FBYyxtQkFBbUIsdUJBQXVCLEdBQUcsd0JBQXdCLFdBQVcsSUFBSSxFQUFFO1FBRXBHLGNBQWMsbUJBQW1CLEdBQUcsQ0FBQztFQUV6QztFQUNBLGFBQWE7R0FDWCxJQUFJLGVBQWUsc0JBQXNCLE1BQ3ZDLGNBQWMsbUJBQW1CLEdBQUcsQ0FBQztFQUV6QztDQUNGLEdBQUc7RUFBQztFQUFVO0VBQU07RUFBc0I7RUFBc0I7Q0FBYSxDQUFDO0NBQzlFLHlCQUF5QixPQUFPO0VBRzlCLG9CQUFvQixRQUFRO0VBQzVCLHNCQUFzQixRQUFRO0VBRzlCLFlBQVksUUFBUTtFQUNwQix1QkFBdUI7RUFDdkIsdUJBQXVCO0NBQ3pCLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7OztBQ3hHQSxJQUFhLG9CQUFpQywyQkFBTSxjQUFjLE1BQVM7QUFDaEMsa0JBQWtCLGNBQWM7QUFDM0UsU0FBZ0IscUJBQXFCLFVBQVU7Q0FDN0MsTUFBTSxxQkFBYyxXQUFXLGlCQUFpQjtDQUNoRCxJQUFJLENBQUMsWUFBWSxVQUFVLFFBQ3pCLE1BQU0sSUFBSSxNQUE4QywwRkFBb0g7Q0FFOUssT0FBTztBQUNUOzs7Ozs7Ozs7QUNMQSxJQUFhLFlBQWIsY0FBK0IsV0FBVztDQUl4QyxTQUFTLFdBQVcsQ0FBQztDQUNyQixPQUFPLFVBQVUsQ0FBQztDQUNsQixJQUFJLE1BQU0sUUFBUSxDQUFDO0NBQ25CLFlBQVksQ0FBQztBQUNmOzs7QUNYQSxJQUFNLFlBQVk7Q0FDaEIsR0FBRztDQUNILFFBQU8sVUFBUyxNQUFNO0NBQ3RCLFNBQVEsVUFBUyxNQUFNO0NBQ3ZCLHdCQUF1QixVQUFTLE1BQU07Q0FDdEMsd0JBQXVCLFVBQVMsTUFBTTtDQUN0QywwQkFBeUIsVUFBUyxNQUFNO0NBQ3hDLGFBQVksVUFBUyxNQUFNO0NBQzNCLHVCQUFzQixVQUFTLE1BQU07Q0FDckMsaUJBQWdCLFVBQVMsTUFBTTtDQUMvQixrQkFBaUIsVUFBUyxNQUFNO0NBQ2hDLE9BQU0sVUFBUyxNQUFNO0FBQ3ZCOzs7Ozs7QUFRQSxJQUFhLGNBQWIsY0FBaUMsV0FBVztDQUMxQyxZQUFZLGNBQWMsWUFBWSxRQUFRO0VBQzVDLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLE1BQU0sUUFBUSxtQkFBbUIsY0FBYyxpQkFBaUIsWUFBWSxNQUFNO0VBQ2xGLE1BQU0sT0FBTyxxQkFBcUIsZUFBZSxHQUFHLFNBQVM7Q0FDL0Q7Q0FDQSxXQUFXLFVBQVUsaUJBQWlCO0VBQ3BDLGFBQWEsOEJBQThCO0dBQ3pDLEtBQUssSUFBSSw0QkFBNEIsSUFBSTtFQUMzQztFQUNBLElBQUksQ0FBQyxZQUFZLGFBQWEsV0FBVyxRQUFRLEtBQUssTUFBTSxtQkFBbUIsTUFHN0UsYUFBYSxVQUFVLEtBQUssTUFBTSx3QkFBd0I7RUFFNUQsS0FBSyxRQUFRLGVBQWUsVUFBVSxZQUFZO0VBQ2xELElBQUksYUFBYSxZQUNmO0VBRUYsS0FBSyxNQUFNLG9CQUFvQixtQkFBbUIsVUFBVSxZQUFZO0VBQ3hFLE1BQU0sZUFBZSxFQUNuQixNQUFNLFNBQ1I7RUFDQSxrQkFBa0IsY0FBYyxVQUFVLGFBQWEsT0FBTztFQUM5RCxLQUFLLE9BQU8sWUFBWTtDQUMxQjtBQUNGOzs7Ozs7QUFPQSxTQUFnQix3QkFBd0I7Q0FDdEMsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7Q0FDNUMsT0FBTyxJQUFJLFVBQVUsT0FBTyxPQUFPLG1CQUFtQixRQUFXLGVBQWUsQ0FBQyxHQUFHLE9BQU8sT0FBTyxxQkFBcUIsZUFBZSxDQUFDLEdBQUcsU0FBUztBQUNySjtBQUNBLFNBQVMsbUJBQW1CLGNBQWMsaUJBQWlCLFlBQVksU0FBUyxPQUFPO0NBQ3JGLE1BQU0sUUFBUTtFQUNaLEdBQUcsNkJBQTZCO0VBQ2hDLE9BQU87RUFDUCx5QkFBeUI7RUFDekIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLFFBQVE7RUFDUix1QkFBdUI7RUFDdkIsdUJBQXVCO0VBQ3ZCLE1BQU07RUFDTixHQUFHO0NBQ0w7Q0FDQSxNQUFNLHNCQUFzQiwrQkFBK0IsaUJBQWlCLFlBQVksTUFBTTtDQUM5RixPQUFPO0FBQ1Q7QUFDQSxTQUFTLHFCQUFxQixpQkFBaUI7Q0FDN0MsT0FBTztFQUNMLFVBQXVCLDJCQUFNLFVBQVU7RUFDdkMsYUFBMEIsMkJBQU0sVUFBVTtFQUMxQyxxQkFBa0MsMkJBQU0sVUFBVTtFQUNsRCx3QkFBd0IsRUFDdEIsU0FBUyxLQUNYO0VBQ0E7RUFDQSxjQUFjO0VBQ2Qsc0JBQXNCO0NBQ3hCO0FBQ0Y7OztBQ2pGQSxTQUFnQixvQkFBb0IsTUFBTSxPQUFPO0NBQy9DLE1BQU0sRUFDSixVQUNBLE1BQU0sVUFDTixjQUFjLE9BQ2QsY0FDQSxzQkFDQSx5QkFBeUIsOEJBQThCLE9BQ3ZELE9BQU8sWUFBWSxNQUNuQixZQUNBLFFBQ0EsV0FBVyxlQUNYLGtCQUFrQix1QkFBdUIsU0FDdkM7Q0FDSixNQUFNLFdBQVcsU0FBUztDQUMxQixNQUFNLGdCQUFnQixTQUFTO0NBQy9CLE1BQU0sUUFBUSxnQkFBZ0IsT0FBTztDQUNyQyxNQUFNLDBCQUEwQixpQkFBaUI7Q0FDakQsTUFBTSxPQUFPLGdCQUFnQixnQkFBZ0I7Q0FDN0MsTUFBTSxjQUFjLHFCQUFxQixJQUFJO0NBRTdDLE1BQU0sWUFBWTtFQUNoQjtFQUNBO0VBQ0EsUUFKYSxlQUFlO0VBSzVCO0NBQ0Y7Q0FNQSxNQUFNLFFBQVEsbUJBQW1CLFlBQVksbUJBQW1CLElBQUksWUFBWTtFQUM5RSxNQUFNO0VBQ047RUFDQSxpQkFBaUI7RUFDakI7RUFDQSxHQUFHO0NBQ0wsR0FBRyxZQUFZLGNBQWMsR0FBRyxJQUFJO0NBQ3BDLE1BQU0sa0JBQWtCLFlBQVksUUFBUTtDQUM1QyxNQUFNLGtCQUFrQixpQkFBaUIsYUFBYTtDQUN0RCxNQUFNLGdCQUFnQixTQUFTO0NBQy9CLE1BQU0sbUJBQW1CLGdCQUFnQixZQUFZO0NBQ3JELE1BQU0sbUJBQW1CLHdCQUF3QixvQkFBb0I7Q0FDckUsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsaUJBQWlCLE9BQU8sSUFBSTtDQUM1Qix5QkFBeUIsS0FBSztDQUM5QixNQUFNLEVBQ0osaUJBQ0Usd0JBQXdCLE1BQU0sS0FBSztDQUN2QyxhQUFNLG9CQUFvQixtQkFBbUI7RUFDM0MsU0FBUztFQUNULGFBQWEsTUFBTSxRQUFRLE9BQU8seUJBQXlCRCxnQkFBd0IsQ0FBQztDQUN0RixJQUFJLENBQUMsY0FBYyxLQUFLLENBQUM7Q0FDekIsTUFBTSwyQkFBMkIsUUFBUTtDQUN6QyxPQUFvQiwyQ0FBTSxrQkFBa0IsVUFBVTtFQUNwRCxPQUFPO0VBQ1AsVUFBVTtHQUFDLFVBQXVCLDBDQUFLLHVCQUF1QjtJQUNwRDtJQUNEO0dBQ1QsQ0FBQztHQUFHLDRCQUF5QywwQ0FBSyxvQkFBb0I7SUFDN0Q7SUFDUCxlQUFlLGFBQWE7SUFDbEI7R0FDWixDQUFDO0dBQUcsT0FBTyxhQUFhLGFBQWEsU0FBUyxFQUM1QyxRQUNGLENBQUMsSUFBSTtFQUFRO0NBQ2YsQ0FBQztBQUNIOzs7Ozs7Ozs7QUN2RUEsU0FBZ0IsZ0JBQWdCLE9BQU87Q0FDckMsT0FBTyxvQkFBb0IsZ0JBQWdCLEtBQUs7QUFDbEQ7Q0NWdUMsU0FBVSwyQkFBMkI7Ozs7Q0FJMUUsMEJBQTBCLFVBQVU7Ozs7Q0FJcEMsMEJBQTBCLFlBQVk7Ozs7Q0FJdEMsMEJBQTBCLDBCQUEwQixtQkFBbUIsK0JBQStCLGlCQUFpQjs7OztDQUl2SCwwQkFBMEIsMEJBQTBCLGlCQUFpQiwrQkFBK0IsZUFBZTs7OztDQUluSCwwQkFBMEIsa0JBQWtCOzs7OztDQUs1QywwQkFBMEIsVUFBVTs7Ozs7Q0FLcEMsMEJBQTBCLFdBQVc7Q0FDckMsT0FBTztBQUNULEdBQUUsQ0FBQyxDQUFDO0FBZUosSUFBTSxlQUFlLEVBQ25CLG1CQUFtQixHQUNyQjtBQUtBLElBQU0sa0JBQWtCLEVBQ3RCLGFBQWEsR0FDZjtBQUNBLElBQU0sb0JBQW9CLEVBQ3hCLGVBQWUsR0FDakI7QUFDQSxJQUFNLHFCQUFxQixFQUN6QixzQkFBc0IsR0FDeEI7QUFDQSxJQUFhLDBCQUEwQixFQUNyQyxLQUFLLE9BQU87Q0FDVixJQUFJLE9BQ0YsT0FBTztDQUVULE9BQU87QUFDVCxFQUNGO0FBU0EsSUFBYSxvQkFBb0I7Q0FDL0IsS0FBSyxPQUFPO0VBQ1YsSUFBSSxPQUNGLE9BQU87RUFFVCxPQUFPO0NBQ1Q7Q0FDQSxhQUFhLE9BQU87RUFDbEIsSUFBSSxPQUNGLE9BQU87RUFFVCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQWEsOEJBQThCO0NBQ3pDLEdBQUc7Q0FDSCxHQUFHO0FBQ0w7Ozs7Ozs7OztBQ3BGQSxJQUFhLGlCQUE4QiwyQkFBTSxXQUFXLFNBQVMsZUFBZSxnQkFBZ0IsY0FBYztDQUNoSCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsY0FBYyxPQUNkLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLFNBQVMsTUFBTSxTQUFTLFFBQVE7Q0FDdEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBRXhDLE1BQU0sUUFBUTtFQUNaO0VBQ0Esa0JBSHVCLE1BQU0sU0FBUyxrQkFHdkI7Q0FDakI7Q0FDQSxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QztFQUNBLEtBQUssQ0FBQyxNQUFNLFFBQVEsYUFBYSxZQUFZO0VBQzdDLHdCQUF3QjtFQUN4QixPQUFPLENBQUM7R0FDTixNQUFNO0dBQ04sUUFBUSxDQUFDO0dBQ1QsT0FBTztJQUNMLFlBQVk7SUFDWixrQkFBa0I7R0FDcEI7RUFDRixHQUFHLFlBQVk7RUFDZixTQUFTLGVBQWUsQ0FBQztDQUMzQixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxlQUFlLGNBQWM7Ozs7Ozs7OztBQzlCeEUsSUFBYSxjQUEyQiwyQkFBTSxXQUFXLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUMxRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsV0FBVyxPQUNYLGVBQWUsTUFDZixHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxFQUNKLGdCQUNBLGNBQ0UsVUFBVTtFQUNaO0VBQ0EsUUFBUTtDQUNWLENBQUM7Q0FDRCxNQUFNLFFBQVEsRUFDWixTQUNGO0NBQ0EsU0FBUyxZQUFZLE9BQU87RUFDMUIsSUFBSSxNQUNGLE1BQU0sUUFBUSxPQUFPLHlCQUF5QkssWUFBb0IsTUFBTSxXQUFXLENBQUM7Q0FFeEY7Q0FDQSxPQUFPLGlCQUFpQixVQUFVLGdCQUFnQjtFQUNoRDtFQUNBLEtBQUssQ0FBQyxjQUFjLFNBQVM7RUFDN0IsT0FBTztHQUFDLEVBQ04sU0FBUyxZQUNYO0dBQUc7R0FBYztFQUFjO0NBQ2pDLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7O0FDckNyRSxJQUFhLG9CQUFpQywyQkFBTSxXQUFXLFNBQVMsa0JBQWtCLGdCQUFnQixjQUFjO0NBQ3RILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxJQUFJLFFBQ0osR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxLQUFLLFlBQVksTUFBTTtDQUM3QixNQUFNLDBCQUEwQix3QkFBd0IsRUFBRTtDQUMxRCxPQUFPLGlCQUFpQixLQUFLLGdCQUFnQjtFQUMzQyxLQUFLO0VBQ0wsT0FBTyxDQUFDLEVBQ04sR0FDRixHQUFHLFlBQVk7Q0FDakIsQ0FBQztBQUNILENBQUM7QUFDMEMsa0JBQWtCLGNBQWM7OztBQzFCM0UsSUFBYSxzQkFBbUMsMkJBQU0sY0FBYyxNQUFTO0FBQ2xDLG9CQUFvQixjQUFjO0FBQzdFLFNBQWdCLHlCQUF5QjtDQUN2QyxNQUFNLHFCQUFjLFdBQVcsbUJBQW1CO0NBQ2xELElBQUksVUFBVSxRQUNaLE1BQU0sSUFBSSxNQUE4QyxzQ0FBZ0U7Q0FFMUgsT0FBTztBQUNUOzs7Ozs7O0FDTkEsSUFBYSwrQkFBK0I7Q0FDMUMsR0FBRztDQUNILEdBQUc7Q0FDSCxpQkFBaUIsT0FBTztFQUN0QixPQUFPLFFBQVEsRUFDYiwyQkFBMkIsR0FDN0IsSUFBSTtDQUNOO0FBQ0Y7Ozs7Ozs7OztBQ0tBLElBQWEsY0FBMkIsMkJBQU0sV0FBVyxTQUFTLFlBQVksZ0JBQWdCLGNBQWM7Q0FDMUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFlBQ0EsY0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0sMEJBQTBCLE1BQU0sU0FBUyx5QkFBeUI7Q0FDeEUsTUFBTSxzQkFBc0IsTUFBTSxTQUFTLHFCQUFxQjtDQUNoRSxNQUFNLGlCQUFpQixNQUFNLFNBQVMsWUFBWTtDQUNsRCxNQUFNLFFBQVEsTUFBTSxTQUFTLE9BQU87Q0FDcEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sU0FBUyxNQUFNLFNBQVMsUUFBUTtDQUN0QyxNQUFNLHdCQUF3QixNQUFNLFNBQVMsdUJBQXVCO0NBQ3BFLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLGFBQWEsTUFBTSxTQUFTLFlBQVk7Q0FDOUMsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLGFBQWEsb0JBQW9CLFNBQVMsWUFBWTtDQUM1RCx1QkFBdUI7Q0FDdkIsc0JBQXNCO0VBQ3BCO0VBQ0EsS0FBSyxNQUFNLFFBQVE7RUFDbkIsYUFBYTtHQUNYLElBQUksTUFDRixNQUFNLFFBQVEsdUJBQXVCLElBQUk7RUFFN0M7Q0FDRixDQUFDO0NBQ0QsTUFBTSx1QkFBdUIsaUJBQWlCLFNBQVksMEJBQTBCLE1BQU0sUUFBUSxRQUFRLElBQUk7Q0FDOUcsTUFBTSxtQkFBbUIsd0JBQXdCO0NBQ2pELE1BQU0sa0JBQWtCLE1BQU0sZUFBZSxjQUFjO0NBTzNELE1BQU0sVUFBVSxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDdEQ7R0FOQTtHQUNBO0dBQ0E7R0FDQTtFQUdJO0VBQ0osT0FBTztHQUFDO0dBQWdCO0lBQ3RCLElBQUk7SUFDSixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCO0lBQ0EsR0FBRztJQUNILFFBQVEsQ0FBQztJQUNULFVBQVUsT0FBTztLQUNmLElBQUksZUFBZSxJQUFJLE1BQU0sR0FBRyxHQUM5QixNQUFNLGdCQUFnQjtJQUUxQjtJQUNBLE9BQU8sRUFDTCxvQkFBb0Isc0JBQ3RCO0dBQ0Y7R0FBRztFQUFZO0VBQ2YsS0FBSztHQUFDO0dBQWMsTUFBTSxRQUFRO0dBQVU7RUFBZTtFQUMzRCx3QkFBd0I7Q0FDMUIsQ0FBQztDQUNELE9BQW9CLDBDQUFLLHNCQUFzQjtFQUM3QyxTQUFTO0VBQ1QscUJBQXFCO0VBQ3JCLFVBQVUsQ0FBQztFQUNYLGlCQUFpQixDQUFDO0VBQ2xCLGNBQWM7RUFDZCxhQUFhO0VBQ2IsT0FBTyxVQUFVO0VBQ2pCLGNBQWM7RUFDZCxVQUFVO0NBQ1osQ0FBQztBQUNILENBQUM7QUFDMEMsWUFBWSxjQUFjOzs7QUM5RnJFLFNBQWdCLFdBQVcsT0FBTztDQUNoQyxJQUFJLHNCQUFzQixFQUFFLEdBQzFCLE9BQU87Q0FHVCxPQUFPLFFBQVEsU0FBUztBQUMxQjs7Ozs7O0FDREEsSUFBYSxtQkFBZ0MsMkJBQU0sV0FBVyxTQUFTLGlCQUFpQixPQUFPLEtBQUs7Q0FDbEcsTUFBTSxFQUNKLFFBQ0EsR0FBRyxlQUNEO0NBQ0osSUFBSTtDQUNKLElBQUksUUFBUTtFQUNWLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxXQUFXLGlEQUFpRCxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLE9BQU8sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUk7Q0FDbE47Q0FDQSxPQUFvQiwwQ0FBSyxPQUFPO0VBQ3pCO0VBQ0wsTUFBTTtFQUlOLHNCQUFzQjtFQUN0QixHQUFHO0VBQ0gsT0FBTztHQUNMLFVBQVU7R0FDVixPQUFPO0dBQ1AsWUFBWTtHQUNaLGtCQUFrQjtHQUNsQjtFQUNGO0NBQ0YsQ0FBQztBQUNILENBQUM7QUFDMEMsaUJBQWlCLGNBQWM7Ozs7Ozs7Ozs7QUNoQjFFLElBQWEsZUFBNEIsMkJBQU0sV0FBVyxTQUFTLGFBQWEsT0FBTyxjQUFjO0NBQ25HLE1BQU0sRUFDSixjQUFjLE9BQ2QsR0FBRyxnQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FFbEMsSUFBSSxFQURpQixXQUFXLGNBRTlCLE9BQU87Q0FFVCxPQUFvQiwwQ0FBSyxvQkFBb0IsVUFBVTtFQUNyRCxPQUFPO0VBQ1AsVUFBdUIsMkNBQU0sZ0JBQWdCO0dBQzNDLEtBQUs7R0FDTCxHQUFHO0dBQ0gsVUFBVSxDQUFDLFdBQVcsVUFBVSxRQUFxQiwwQ0FBSyxrQkFBa0I7SUFDMUUsS0FBSyxNQUFNLFFBQVE7SUFDbkIsT0FBTyxXQUFXLENBQUMsSUFBSTtHQUN6QixDQUFDLEdBQUcsTUFBTSxRQUFRO0VBQ3BCLENBQUM7Q0FDSCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxhQUFhLGNBQWM7Ozs7Ozs7OztBQzlCdEUsSUFBYSxjQUEyQiwyQkFBTSxXQUFXLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUMxRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsSUFBSSxRQUNKLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FDN0IsTUFBTSwwQkFBMEIsa0JBQWtCLEVBQUU7Q0FDcEQsT0FBTyxpQkFBaUIsTUFBTSxnQkFBZ0I7RUFDNUMsS0FBSztFQUNMLE9BQU8sQ0FBQyxFQUNOLEdBQ0YsR0FBRyxZQUFZO0NBQ2pCLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7OztBQ3BCckUsU0FBZ0Isd0JBQXdCLFNBQVM7Q0FDL0MsTUFBTSwyQ0FBb0MsT0FBTyxFQUFFO0NBQ25ELE1BQU0saUNBQTBCLGFBQVksVUFBUztFQUNuRCxJQUFJLE1BQU0sa0JBQ1I7RUFFRiw0QkFBNEIsVUFBVSxNQUFNO0VBQzVDLFFBQVEsT0FBTyxNQUFNLFdBQVc7Q0FDbEMsR0FBRyxDQUFDLE9BQU8sQ0FBQztDQWVaLE9BQU87RUFDTCxzQkFmd0IsYUFBWSxVQUFTO0dBRTdDLElBQUksTUFBTSxXQUFXLEdBQUc7SUFDdEIsUUFBUSxPQUFPLFVBQVU7SUFDekI7R0FDRjtHQUNBLElBQUksaUJBQWlCLE9BRW5CLFFBQVEsT0FBTyxNQUFNLFdBQVc7UUFFaEMsUUFBUSxPQUFPLDRCQUE0QixPQUFPO0dBRXBELDRCQUE0QixVQUFVO0VBQ3hDLEdBQUcsQ0FBQyxPQUFPLENBRVU7RUFDbkIsZUFBZTtDQUNqQjtBQUNGOzs7QUM5QkEsU0FBZ0IsMEJBQTBCLE1BQU0sZUFBZTtDQVc3RCxNQUFNLEVBQ0osU0FDQSxrQkFDRSx3QkFidUIsbUJBQW1CLEdBQUcsb0JBQW9CO0VBRW5FLElBQUksRUFEVyxPQUFPLFNBQVMsYUFBYSxLQUFLLElBQUksT0FFbkQsY0FBYyxvQkFJZGYsTUFBa0IsVUFBVSxHQUFHO0NBRW5DLENBSTRCLENBQWtCO0NBQzlDLG9CQUFhLGVBQWU7RUFDMUI7RUFDQTtDQUNGLElBQUksQ0FBQyxTQUFTLGFBQWEsQ0FBQztBQUM5Qjs7Ozs7Ozs7O0FDTkEsSUFBYSxnQkFBNkIsMkJBQU0sV0FBVyxTQUFTLGNBQWMsZ0JBQWdCLGNBQWM7Q0FDOUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFdBQVcsT0FDWCxlQUFlLE1BQ2YsSUFBSSxRQUNKLFNBQ0EsUUFDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxrQkFBa0IscUJBQXFCLElBQUk7Q0FFakQsTUFBTSxRQURjLG9CQUFvQixNQUNoQixLQUFLO0NBQzdCLElBQUksQ0FBQyxPQUNILE1BQU0sSUFBSSxNQUE4Qyx3RkFBa0g7Q0FFNUssTUFBTSxnQkFBZ0IsWUFBWSxNQUFNO0NBQ3hDLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxxQkFBcUI7Q0FDNUQsTUFBTSx3QkFBd0IsTUFBTSxTQUFTLHFCQUFxQixhQUFhO0NBQy9FLE1BQU0sVUFBVSxNQUFNLFNBQVMsa0JBQWtCLGFBQWE7Q0FDOUQsTUFBTSxpQ0FBMEIsT0FBTyxJQUFJO0NBQzNDLE1BQU0sRUFDSixpQkFDQSwyQkFDRSx5QkFBeUIsZUFBZSxtQkFBbUIsT0FBTyxFQUNwRSxRQUNGLENBQUM7Q0FDRCxNQUFNLEVBQ0osZ0JBQ0EsY0FDRSxVQUFVO0VBQ1o7RUFDQSxRQUFRO0NBQ1YsQ0FBQztDQUNELE1BQU0sUUFBUSxTQUFTLGVBQWU7Q0FDdEMsTUFBTSx1QkFBdUIsZ0NBQWdDLE1BQU0sT0FBTyxNQUFNLElBQUcsb0JBQW1CO0VBQ3BHLE1BQU0sSUFBSSxjQUFjLGVBQWU7Q0FDekMsQ0FBQztDQUNELE1BQU0sUUFBUTtFQUNaO0VBQ0EsTUFBTTtDQUNSO0NBQ0EsTUFBTSxtQkFBbUIsTUFBTSxTQUFTLGdCQUFnQixzQkFBc0I7Q0FDOUUsT0FBTyxpQkFBaUIsVUFBVSxnQkFBZ0I7RUFDaEQ7RUFDQSxLQUFLO0dBQUM7R0FBVztHQUFjO0dBQWlCO0VBQWlCO0VBQ2pFLE9BQU87R0FBQyxNQUFNO0dBQVc7R0FBa0I7R0FBc0I7S0FDOUQsMkJBQTJCO0lBQzVCLElBQUk7SUFDSixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGlCQUFpQjtHQUNuQjtHQUFHO0dBQWM7RUFBYztFQUMvQix3QkFBd0I7Q0FDMUIsQ0FBQztBQUNILENBQUM7QUFDMEMsY0FBYyxjQUFjOzs7Ozs7Ozs7QUNyRXZFLElBQWEscUJBQXFCOzs7Ozs7Ozs7QUNLbEMsSUFBYSxpQkFBOEIsMkJBQU0sV0FBVyxTQUFTLGVBQWUsZ0JBQWdCLGNBQWM7Q0FDaEgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFVBQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sY0FBYyx1QkFBdUI7Q0FDM0MsTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxTQUFTLE1BQU0sU0FBUyxRQUFRO0NBQ3RDLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSx3QkFBd0IsTUFBTSxTQUFTLHVCQUF1QjtDQUNwRSxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsTUFBTSxxQkFBcUIsTUFBTSxlQUFlLGlCQUFpQjtDQVNqRSxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QyxTQUZtQixlQUFlO0VBR2xDO0dBUkE7R0FDQTtHQUNBO0dBQ0Esa0JBTHVCLHdCQUF3QjtFQVUzQztFQUNKLEtBQUssQ0FBQyxjQUFjLGtCQUFrQjtFQUN0Qyx3QkFBd0I7RUFDeEIsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLFFBQVEsQ0FBQztHQUNULE9BQU8sRUFDTCxlQUFlLENBQUMsT0FBTyxTQUFTLE9BQ2xDO0dBQ0E7RUFDRixHQUFHLFlBQVk7Q0FDakIsQ0FBQztBQUNILENBQUM7QUFDMEMsZUFBZSxjQUFjOzs7Ozs7Ozs7OztBQ3hDeEUsSUFBYSxlQUFiLGNBQWtDLGdCQUFnQjtDQUNoRCxjQUFjO0VBQ1osTUFBTSxzQkFBc0IsR0FBRyxVQUFVLEtBQUs7Q0FDaEQ7Ozs7Ozs7OztDQVVBLEtBQUssV0FBVztFQUNkLEtBQUssY0FBYyxTQUFTO0NBQzlCOzs7Ozs7OztDQVNBLGdCQUFnQixTQUFTO0VBQ3ZCLE1BQU0sZ0JBQWdCLEtBQUs7RUFDM0IsSUFBSSxrQkFBa0IsTUFBTTtHQUV4QixRQUFRLEtBQUsscU1BQTBNO0dBRXpOO0VBQ0Y7RUFDQSxjQUFjLElBQUksV0FBVyxPQUFPO0VBQ3BDLGNBQWMsUUFBUSxNQUFNLHlCQUF5QlUsZ0JBQXdCLENBQUM7Q0FDaEY7Ozs7OztDQU9BLFFBQVE7RUFDTixLQUFLLFdBQVc7Q0FDbEI7Ozs7Q0FLQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssZUFBZSxPQUFPLE1BQU0sS0FBSztDQUMvQztBQUNGOzs7Ozs7Ozs7OztBQ3REQSxJQUFhLG9CQUFiLGNBQXVDLGFBQWEsQ0FBQzs7OztBQUtyRCxTQUFnQiwwQkFBMEI7Q0FDeEMsT0FBTyxJQUFJLGtCQUFrQjtBQUMvQiIsIm5hbWVzIjpbIm93bmVyV2luZG93IiwicGxhdGZvcm0uZW5naW5lLndlYmtpdCIsInBsYXRmb3JtLm9zLmlvcyIsInBsYXRmb3JtLm9zLmFuZHJvaWQiLCJwbGF0Zm9ybS5lbnYuanNkb20iLCJwbGF0Zm9ybS5zY3JlZW5SZWFkZXIudm9pY2VPdmVyIiwiUkVBU09OUy5mb2N1c091dCIsIlJFQVNPTlMudHJpZ2dlclByZXNzIiwib3V0c2lkZVByZXNzIiwiZXNjYXBlS2V5IiwiUkVBU09OUy5lc2NhcGVLZXkiLCJSRUFTT05TLm91dHNpZGVQcmVzcyIsIlJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbiIsInVzZVN5bmNFeHRlcm5hbFN0b3JlIiwidXNlU3luY0V4dGVybmFsU3RvcmVXaXRoU2VsZWN0b3IiLCJzZWxlY3RvcnMiLCJSRUFTT05TLm5vbmUiLCJSRUFTT05TLmNsb3NlUHJlc3MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lci5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9wbGF0Zm9ybS9zaGFyZWQubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0vb3MubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0vZW5naW5lLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtL3NjcmVlbi1yZWFkZXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0vZW52Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL293bmVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlU2Nyb2xsTG9jay5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9ldmVudC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9jb25zdGFudHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvZWxlbWVudC5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9tZXJnZUNsZWFudXBzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZVZhbHVlQXNSZWYubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvRm9jdXNHdWFyZC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy90YWJiYWJsZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9ub2Rlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9jcmVhdGVBdHRyaWJ1dGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvZW5xdWV1ZUZvY3VzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL21hcmtPdGhlcnMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2NvbnN0YW50cy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nUG9ydGFsLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2NyZWF0ZUV2ZW50RW1pdHRlci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nVHJlZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nRm9jdXNNYW5hZ2VyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZUNsaWNrLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZURpc21pc3MubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcG9wdXBzL3BvcHVwSGFuZGxlLm1qcyIsIi4uLy4uL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltLmRldmVsb3BtZW50LmpzIiwiLi4vLi4vdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbS9pbmRleC5qcyIsIi4uLy4uL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltL3dpdGgtc2VsZWN0b3IuZGV2ZWxvcG1lbnQuanMiLCIuLi8uLi91c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltL3dpdGgtc2VsZWN0b3IuanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9mYXN0SG9va3MubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvc3RvcmUvdXNlU3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvc3RvcmUvU3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvc3RvcmUvUmVhY3RTdG9yZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nUm9vdFN0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZVN5bmNlZEZsb2F0aW5nUm9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcG9wdXBzL3BvcHVwU3RvcmVVdGlscy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9wb3B1cHMvcG9wdXBUcmlnZ2VyTWFwLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2dldEVtcHR5Um9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvcG9wdXBzL3N0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3BvcHVwcy91c2VQb3B1cEhhbmRsZVN0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9yb290L3VzZURpYWxvZ1Jvb3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvTnVsbFN0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9zdG9yZS9EaWFsb2dTdG9yZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcm9vdC91c2VSZW5kZXJEaWFsb2dSb290Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2FsZXJ0LWRpYWxvZy9yb290L0FsZXJ0RGlhbG9nUm9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvYmFja2Ryb3AvRGlhbG9nQmFja2Ryb3AubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL2Nsb3NlL0RpYWxvZ0Nsb3NlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9kZXNjcmlwdGlvbi9EaWFsb2dEZXNjcmlwdGlvbi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9ydGFsL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3BvcHVwL0RpYWxvZ1BvcHVwLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL2luZXJ0VmFsdWUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvSW50ZXJuYWxCYWNrZHJvcC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9ydGFsL0RpYWxvZ1BvcnRhbC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvdGl0bGUvRGlhbG9nVGl0bGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlRW5oYW5jZWRDbGlja0hhbmRsZXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvdXNlT3BlbkludGVyYWN0aW9uVHlwZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvdHJpZ2dlci9EaWFsb2dUcmlnZ2VyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2FsZXJ0LWRpYWxvZy90cmlnZ2VyL0FsZXJ0RGlhbG9nVHJpZ2dlci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvdmlld3BvcnQvRGlhbG9nVmlld3BvcnQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3N0b3JlL0RpYWxvZ0hhbmRsZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9hbGVydC1kaWFsb2cvaGFuZGxlLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEFkZHMgYW4gZXZlbnQgbGlzdGVuZXIgYW5kIHJldHVybnMgYSBjbGVhbnVwIGZ1bmN0aW9uIHRvIHJlbW92ZSBpdC5cbiAqL1xuXG5leHBvcnQgZnVuY3Rpb24gYWRkRXZlbnRMaXN0ZW5lcih0YXJnZXQsIHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKSB7XG4gIHRhcmdldC5hZGRFdmVudExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyLCBvcHRpb25zKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICB0YXJnZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucyk7XG4gIH07XG59IiwiLyoqXG4gKiBSZWFkcyBgbmF2aWdhdG9yLnVzZXJBZ2VudGAgLyBgbmF2aWdhdG9yLnBsYXRmb3JtYCAobGVnYWN5IGJ1dCB1bml2ZXJzYWxseVxuICogc3VwcG9ydGVkKSBpbnRvIGEgbm9ybWFsaXplZCBzaGFwZS4gSW4gZGV2ZWxvcG1lbnQsIHByZWZlcnMgdGhlIG1vZGVyblxuICogYG5hdmlnYXRvci51c2VyQWdlbnREYXRhYCBBUEkgb24gQ2hyb21pdW0gdG8gYXZvaWQgRGV2VG9vbHMgd2FybmluZ3MgYWJvdXRcbiAqIHRoZSBkZXByZWNhdGVkIHJlYWRzOyB0aGF0IGJyYW5jaCBpcyBkZWFkLWNvZGUtZWxpbWluYXRlZCBpbiBwcm9kdWN0aW9uXG4gKiBidWlsZHMgdG8ga2VlcCB0aGUgYnVuZGxlIHNtYWxsLlxuICpcbiAqIFJldHVybnMgZW1wdHkvemVybyB2YWx1ZXMgd2hlbiBgbmF2aWdhdG9yYCBpcyB1bmRlZmluZWQgKFNTUiksIHNvIGV2ZXJ5XG4gKiBkZXJpdmVkIGZsYWcgc2FmZWx5IGV2YWx1YXRlcyB0byBgZmFsc2VgLlxuICovXG5mdW5jdGlvbiByZWFkUmF3RGF0YSgpIHtcbiAgaWYgKHR5cGVvZiBuYXZpZ2F0b3IgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHVzZXJBZ2VudDogJycsXG4gICAgICBwbGF0Zm9ybTogJycsXG4gICAgICBtYXhUb3VjaFBvaW50czogMFxuICAgIH07XG4gIH1cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBjb25zdCB1YURhdGEgPSBuYXZpZ2F0b3IudXNlckFnZW50RGF0YTtcbiAgICBpZiAodWFEYXRhICYmIEFycmF5LmlzQXJyYXkodWFEYXRhLmJyYW5kcykpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHVzZXJBZ2VudDogdWFEYXRhLmJyYW5kcy5tYXAoKHtcbiAgICAgICAgICBicmFuZCxcbiAgICAgICAgICB2ZXJzaW9uXG4gICAgICAgIH0pID0+IGAke2JyYW5kfS8ke3ZlcnNpb259YCkuam9pbignICcpLFxuICAgICAgICBwbGF0Zm9ybTogdWFEYXRhLnBsYXRmb3JtID8/IG5hdmlnYXRvci5wbGF0Zm9ybSA/PyAnJyxcbiAgICAgICAgbWF4VG91Y2hQb2ludHM6IG5hdmlnYXRvci5tYXhUb3VjaFBvaW50cyA/PyAwXG4gICAgICB9O1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIHVzZXJBZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICBwbGF0Zm9ybTogbmF2aWdhdG9yLnBsYXRmb3JtID8/ICcnLFxuICAgIG1heFRvdWNoUG9pbnRzOiBuYXZpZ2F0b3IubWF4VG91Y2hQb2ludHMgPz8gMFxuICB9O1xufVxuY29uc3Qge1xuICB1c2VyQWdlbnQsXG4gIHBsYXRmb3JtLFxuICBtYXhUb3VjaFBvaW50c1xufSA9IHJlYWRSYXdEYXRhKCk7XG5leHBvcnQgY29uc3QgbG93ZXJVc2VyQWdlbnQgPSB1c2VyQWdlbnQudG9Mb3dlckNhc2UoKTtcbmV4cG9ydCBjb25zdCBsb3dlclBsYXRmb3JtID0gcGxhdGZvcm0udG9Mb3dlckNhc2UoKTtcbmV4cG9ydCB7IG1heFRvdWNoUG9pbnRzIH07IiwiaW1wb3J0IHsgbG93ZXJVc2VyQWdlbnQsIGxvd2VyUGxhdGZvcm0sIG1heFRvdWNoUG9pbnRzIH0gZnJvbSBcIi4vc2hhcmVkLm1qc1wiO1xuXG4vLyBpUGFkT1MgMTMrIHJlcG9ydHMgYE1hY0ludGVsYCBmb3IgYG5hdmlnYXRvci5wbGF0Zm9ybWA7IGRpc2FtYmlndWF0ZWQgdmlhXG4vLyBgbWF4VG91Y2hQb2ludHNgIHNvIGlQYWQgaXMgY2xhc3NpZmllZCBhcyBpT1MsIG5vdCBtYWNPUy5cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvYmFzZS11aS9pc3N1ZXMvMTMwOVxuLyoqIGlQaG9uZSwgaVBhZCAoaW5jbHVkaW5nIGlQYWRPUyAxMysgcmVwb3J0aW5nIGFzIG1hY09TKSwgaVBvZC4gKi9cbmV4cG9ydCBjb25zdCBpb3MgPSAvXmkob3MkfHApLy50ZXN0KGxvd2VyUGxhdGZvcm0pIHx8IGxvd2VyUGxhdGZvcm0gPT09ICdtYWNpbnRlbCcgJiYgbWF4VG91Y2hQb2ludHMgPiAxO1xuXG4vKiogQW5kcm9pZCBwaG9uZXMsIHRhYmxldHMsIGFuZCBlbWJlZGRlZCBBbmRyb2lkIGJyb3dzZXJzLiAqL1xuY29uc3QgQU5EUk9JRF9TVFJJTkcgPSAnYW5kcm9pZCc7XG5leHBvcnQgY29uc3QgYW5kcm9pZCA9IGxvd2VyUGxhdGZvcm0gPT09IEFORFJPSURfU1RSSU5HIHx8IGxvd2VyVXNlckFnZW50LmluY2x1ZGVzKEFORFJPSURfU1RSSU5HKTtcblxuLyoqIG1hY09TIGRlc2t0b3AuIEV4Y2x1ZGVzIGlQYWRPUywgd2hpY2ggcmVwb3J0cyBhcyBgTWFjSW50ZWxgLiAqL1xuZXhwb3J0IGNvbnN0IG1hYyA9ICFpb3MgJiYgbG93ZXJQbGF0Zm9ybS5zdGFydHNXaXRoKCdtYWMnKTtcblxuLyoqIFdpbmRvd3MgZGVza3RvcC4gKi9cbmV4cG9ydCBjb25zdCB3aW5kb3dzID0gbG93ZXJQbGF0Zm9ybS5zdGFydHNXaXRoKCd3aW4nKTtcblxuLyoqIExpbnV4IGRlc2t0b3AgKGluY2x1ZGluZyBDaHJvbWUgT1MpLiAqL1xuZXhwb3J0IGNvbnN0IGxpbnV4ID0gIWFuZHJvaWQgJiYgL14obGludXh8Y2hyb21lIG9zKS8udGVzdChsb3dlclBsYXRmb3JtKTtcblxuLyoqIEFueSBBcHBsZSBPUyAoYG1hYyB8fCBpb3NgKS4gKi9cbmV4cG9ydCBjb25zdCBhcHBsZSA9IG1hYyB8fCBpb3M7IiwiaW1wb3J0IHsgbG93ZXJVc2VyQWdlbnQgfSBmcm9tIFwiLi9zaGFyZWQubWpzXCI7XG5cbi8vIFdlYktpdCAoU2FmYXJpLCBhbGwgaU9TIGJyb3dzZXJzLCBHTk9NRSBXZWIpLiBEaXN0aW5ndWlzaGVkIGZyb20gQmxpbmsgYnlcbi8vIHRoZSBsZWdhY3kgYC13ZWJraXQtYmFja2Ryb3AtZmlsdGVyYCBuYW1lIOKAlCBCbGluayBmb3JrZWQgZnJvbSBXZWJLaXQgaW4gMjAxM1xuLy8gYW5kIG9ubHkgc2hpcHMgdGhlIHVucHJlZml4ZWQgYGJhY2tkcm9wLWZpbHRlcmAuXG4vKiogV2ViS2l0OiBTYWZhcmksIGFsbCBpT1MgYnJvd3NlcnMsIEdOT01FIFdlYi4gRXhjbHVkZXMgQmxpbmsuICovXG5leHBvcnQgY29uc3Qgd2Via2l0ID0gdHlwZW9mIENTUyAhPT0gJ3VuZGVmaW5lZCcgJiYgISFDU1Muc3VwcG9ydHM/LignLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXI6bm9uZScpO1xuXG4vLyBBbmNob3JlZCB0byBgIXdlYmtpdGAgc28gZW5naW5lcyBhcmUgbXV0dWFsbHkgZXhjbHVzaXZlIGJ5IGNvbnN0cnVjdGlvbi5cbi8vIEZpcmVmb3gtb24taU9TIHVzZXMgV2ViS2l0IChpdHMgVUEgbWFya2VyIGlzIGBGeGlPUy9gLCBub3QgYEZpcmVmb3gvYCk7IHRoZVxuLy8gYCF3ZWJraXRgIHByZWZpeCBhbHNvIGRlZmVuZHMgYWdhaW5zdCBmdXR1cmUgaU9TLWJyb3dzZXIgVUEgY2hhbmdlcyB0aGF0XG4vLyBtaWdodCBpbmplY3QgYEZpcmVmb3hgIGludG8gYSBXZWJLaXQtYmFzZWQgVUEuXG4vKiogR2Vja286IEZpcmVmb3guICovXG5leHBvcnQgY29uc3QgZ2Vja28gPSAhd2Via2l0ICYmIGxvd2VyVXNlckFnZW50LmluY2x1ZGVzKCdmaXJlZm94Jyk7XG5cbi8vIEFsbCBDaHJvbWl1bS1iYXNlZCBicm93c2VycyBzaGlwIGBDaHJvbWUvYCBvciBgQ2hyb21pdW0vYCBpbiB0aGVpciBVQSDigJQgYm90aFxuLy8gc2hhcmUgdGhlIGBjaHJvbWAgcHJlZml4LCBzbyBhIHNpbmdsZSBzdWJzdHJpbmcgY2hlY2sgY292ZXJzIENocm9tZSwgRWRnZSxcbi8vIE9wZXJhLCBCcmF2ZSwgZXRjLiBDaHJvbWUtb24taU9TIHVzZXMgYENyaU9TL2AgYW5kIHN0YXlzIFdlYktpdC4gVGhlIHBvc2l0aXZlXG4vLyBVQSBjaGVjayBhbHNvIG1ha2VzIHRoaXMgU1NSLXNhZmUg4oCUIGFuIGVtcHR5IFVBIG1hdGNoZXMgbm90aGluZy5cbi8qKiBCbGluazogQ2hyb21lLCBFZGdlLCBPcGVyYSwgQnJhdmUsIGFuZCBvdGhlciBDaHJvbWl1bS1iYXNlZCBicm93c2Vycy4gKi9cbmV4cG9ydCBjb25zdCBibGluayA9ICF3ZWJraXQgJiYgbG93ZXJVc2VyQWdlbnQuaW5jbHVkZXMoJ2Nocm9tJyk7IiwiaW1wb3J0IHsgYXBwbGUgfSBmcm9tIFwiLi9vcy5tanNcIjtcblxuLy8gV2hldGhlciBhIHNjcmVlbiByZWFkZXIgaXMgKmFjdHVhbGx5KiBydW5uaW5nIGNhbm5vdCBiZSBkZXRlY3RlZC4gVGhlc2UgZmxhZ3Ncbi8vIGlkZW50aWZ5IHBsYXRmb3JtcyB3aGVyZSBhIHNwZWNpZmljIHNjcmVlbiByZWFkZXIgY291bGQgYmUgYWN0aXZlLiBWb2ljZU92ZXJcbi8vIGlzIHRoZSBzeXN0ZW0gc2NyZWVuIHJlYWRlciBvbiBBcHBsZSBwbGF0Zm9ybXMgYW5kIHdvcmtzIHdpdGggZXZlcnkgYnJvd3NlclxuLy8gdGhlcmUsIHNvIHRoZSBmbGFnIGlzIHB1cmVseSBhbiBPUyBjaGVjazsgZW5naW5lLXNwZWNpZmljIHF1aXJrcyAoZS5nLiB0aGVcbi8vIE5TQWNjZXNzaWJpbGl0eSB2aXJ0dWFsLWN1cnNvciBmb2N1cyBwYXRoKSBzaG91bGQgYmUgZ2F0ZWQgYXQgdGhlIGNhbGwgc2l0ZS5cbi8qKlxuICogVGhlIHVzZXIgKm1heSogYmUgdXNpbmcgVm9pY2VPdmVyIOKAlCBhY3R1YWwgYWN0aXZhdGlvbiBpcyBub3QgZGV0ZWN0YWJsZS5cbiAqIFRydWUgb24gYW55IEFwcGxlIHBsYXRmb3JtIChtYWNPUywgaU9TLCBpUGFkT1MpLlxuICovXG5leHBvcnQgY29uc3Qgdm9pY2VPdmVyID0gYXBwbGU7IiwiaW1wb3J0IHsgbG93ZXJVc2VyQWdlbnQgfSBmcm9tIFwiLi9zaGFyZWQubWpzXCI7XG5cbi8qKiBSdW5uaW5nIGluIGpzZG9tIG9yIEhhcHB5RE9NICh1c2VkIGJ5IHVuaXQgdGVzdHMpLiAqL1xuZXhwb3J0IGNvbnN0IGpzZG9tID0gL2pzZG9tfGhhcHB5ZG9tLy50ZXN0KGxvd2VyVXNlckFnZW50KTsiLCJleHBvcnQgeyBnZXRXaW5kb3cgYXMgb3duZXJXaW5kb3cgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmV4cG9ydCBmdW5jdGlvbiBvd25lckRvY3VtZW50KG5vZGUpIHtcbiAgcmV0dXJuIG5vZGU/Lm93bmVyRG9jdW1lbnQgfHwgZG9jdW1lbnQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gXCIuL3VzZVJlZldpdGhJbml0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlT25Nb3VudCB9IGZyb20gXCIuL3VzZU9uTW91bnQubWpzXCI7XG5jb25zdCBFTVBUWSA9IDA7XG5leHBvcnQgY2xhc3MgVGltZW91dCB7XG4gIHN0YXRpYyBjcmVhdGUoKSB7XG4gICAgcmV0dXJuIG5ldyBUaW1lb3V0KCk7XG4gIH1cbiAgY3VycmVudElkID0gRU1QVFk7XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGVzIGBmbmAgYWZ0ZXIgYGRlbGF5YCwgY2xlYXJpbmcgYW55IHByZXZpb3VzbHkgc2NoZWR1bGVkIGNhbGwuXG4gICAqL1xuICBzdGFydChkZWxheSwgZm4pIHtcbiAgICB0aGlzLmNsZWFyKCk7XG4gICAgdGhpcy5jdXJyZW50SWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMuY3VycmVudElkID0gRU1QVFk7XG4gICAgICBmbigpO1xuICAgIH0sIGRlbGF5KTsgLyogTm9kZS5qcyB0eXBlcyBhcmUgZW5hYmxlZCBpbiBkZXZlbG9wbWVudCAqL1xuICB9XG4gIGlzU3RhcnRlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5jdXJyZW50SWQgIT09IEVNUFRZO1xuICB9XG4gIGNsZWFyID0gKCkgPT4ge1xuICAgIGlmICh0aGlzLmN1cnJlbnRJZCAhPT0gRU1QVFkpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aGlzLmN1cnJlbnRJZCk7XG4gICAgICB0aGlzLmN1cnJlbnRJZCA9IEVNUFRZO1xuICAgIH1cbiAgfTtcbiAgZGlzcG9zZUVmZmVjdCA9ICgpID0+IHtcbiAgICByZXR1cm4gdGhpcy5jbGVhcjtcbiAgfTtcbn1cblxuLyoqXG4gKiBBIGBzZXRUaW1lb3V0YCB3aXRoIGF1dG9tYXRpYyBjbGVhbnVwIGFuZCBndWFyZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVRpbWVvdXQoKSB7XG4gIGNvbnN0IHRpbWVvdXQgPSB1c2VSZWZXaXRoSW5pdChUaW1lb3V0LmNyZWF0ZSkuY3VycmVudDtcbiAgdXNlT25Nb3VudCh0aW1lb3V0LmRpc3Bvc2VFZmZlY3QpO1xuICByZXR1cm4gdGltZW91dDtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IGlzT3ZlcmZsb3dFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSBcIi4vYWRkRXZlbnRMaXN0ZW5lci5tanNcIjtcbmltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSBcIi4vcGxhdGZvcm0vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50LCBvd25lcldpbmRvdyB9IGZyb20gXCIuL293bmVyLm1qc1wiO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSBcIi4vdXNlSXNvTGF5b3V0RWZmZWN0Lm1qc1wiO1xuaW1wb3J0IHsgVGltZW91dCB9IGZyb20gXCIuL3VzZVRpbWVvdXQubWpzXCI7XG5pbXBvcnQgeyBBbmltYXRpb25GcmFtZSB9IGZyb20gXCIuL3VzZUFuaW1hdGlvbkZyYW1lLm1qc1wiO1xubGV0IG9yaWdpbmFsSHRtbFN0eWxlcyA9IHt9O1xubGV0IG9yaWdpbmFsQm9keVN0eWxlcyA9IHt9O1xubGV0IG9yaWdpbmFsSHRtbFNjcm9sbEJlaGF2aW9yID0gJyc7XG5cbi8vIFRoZSB2aWV3cG9ydCdzIG92ZXJmbG93IGNvbWVzIGZyb20gPGh0bWw+IHdoZW4gaXQgZXN0YWJsaXNoZXMgaXRzIG93biBzY3JvbGwgY29udGFpbmVyLCBhbmRcbi8vIHByb3BhZ2F0ZXMgZnJvbSA8Ym9keT4gb3RoZXJ3aXNlLiBBbiBgb3ZlcmZsb3dgIHN0eWxlIG9uIHRoZSBvdGhlciBlbGVtZW50IGRvZXNuJ3QgbG9jayB0aGUgcGFnZS5cbmZ1bmN0aW9uIGdldFZpZXdwb3J0U2Nyb2xsZXIoaHRtbCwgYm9keSkge1xuICByZXR1cm4gaXNPdmVyZmxvd0VsZW1lbnQoaHRtbCkgPyBodG1sIDogYm9keTtcbn1cbmZ1bmN0aW9uIGlzUGFnZVNjcm9sbExvY2tlZCh3aW4sIGh0bWwsIGJvZHkpIHtcbiAgcmV0dXJuIC9oaWRkZW58Y2xpcC8udGVzdCh3aW4uZ2V0Q29tcHV0ZWRTdHlsZShnZXRWaWV3cG9ydFNjcm9sbGVyKGh0bWwsIGJvZHkpKS5vdmVyZmxvd1kpO1xufVxuZnVuY3Rpb24gaGFzSW5zZXRTY3JvbGxiYXJzKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KTtcbiAgY29uc3Qgd2luID0gb3duZXJXaW5kb3coZG9jKTtcbiAgcmV0dXJuIHdpbi5pbm5lcldpZHRoIC0gZG9jLmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aCA+IDA7XG59XG5mdW5jdGlvbiBzdXBwb3J0c1N0YWJsZVNjcm9sbGJhckd1dHRlcihyZWZlcmVuY2VFbGVtZW50KSB7XG4gIGNvbnN0IHN1cHBvcnRlZCA9IHR5cGVvZiBDU1MgIT09ICd1bmRlZmluZWQnICYmIENTUy5zdXBwb3J0cyAmJiBDU1Muc3VwcG9ydHMoJ3Njcm9sbGJhci1ndXR0ZXInLCAnc3RhYmxlJyk7XG4gIGlmICghc3VwcG9ydGVkIHx8IHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KTtcbiAgY29uc3QgaHRtbCA9IGRvYy5kb2N1bWVudEVsZW1lbnQ7XG4gIGNvbnN0IGJvZHkgPSBkb2MuYm9keTtcbiAgY29uc3Qgc2Nyb2xsQ29udGFpbmVyID0gZ2V0Vmlld3BvcnRTY3JvbGxlcihodG1sLCBib2R5KTtcbiAgY29uc3Qgb3JpZ2luYWxTY3JvbGxDb250YWluZXJPdmVyZmxvd1kgPSBzY3JvbGxDb250YWluZXIuc3R5bGUub3ZlcmZsb3dZO1xuICBjb25zdCBvcmlnaW5hbEh0bWxTdHlsZUd1dHRlciA9IGh0bWwuc3R5bGUuc2Nyb2xsYmFyR3V0dGVyO1xuICBodG1sLnN0eWxlLnNjcm9sbGJhckd1dHRlciA9ICdzdGFibGUnO1xuICBzY3JvbGxDb250YWluZXIuc3R5bGUub3ZlcmZsb3dZID0gJ3Njcm9sbCc7XG4gIGNvbnN0IGJlZm9yZSA9IHNjcm9sbENvbnRhaW5lci5vZmZzZXRXaWR0aDtcbiAgc2Nyb2xsQ29udGFpbmVyLnN0eWxlLm92ZXJmbG93WSA9ICdoaWRkZW4nO1xuICBjb25zdCBhZnRlciA9IHNjcm9sbENvbnRhaW5lci5vZmZzZXRXaWR0aDtcbiAgc2Nyb2xsQ29udGFpbmVyLnN0eWxlLm92ZXJmbG93WSA9IG9yaWdpbmFsU2Nyb2xsQ29udGFpbmVyT3ZlcmZsb3dZO1xuICBodG1sLnN0eWxlLnNjcm9sbGJhckd1dHRlciA9IG9yaWdpbmFsSHRtbFN0eWxlR3V0dGVyO1xuICByZXR1cm4gYmVmb3JlID09PSBhZnRlcjtcbn1cbmZ1bmN0aW9uIHByZXZlbnRTY3JvbGxPdmVybGF5U2Nyb2xsYmFycyhyZWZlcmVuY2VFbGVtZW50KSB7XG4gIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQocmVmZXJlbmNlRWxlbWVudCk7XG4gIGNvbnN0IGh0bWwgPSBkb2MuZG9jdW1lbnRFbGVtZW50O1xuICBjb25zdCBib2R5ID0gZG9jLmJvZHk7XG5cbiAgLy8gSWYgYW4gYG92ZXJmbG93YCBzdHlsZSBpcyBwcmVzZW50IG9uIDxodG1sPiwgd2UgbmVlZCB0byBsb2NrIGl0LCBiZWNhdXNlIGEgbG9jayBvbiA8Ym9keT5cbiAgLy8gd29uJ3QgaGF2ZSBhbnkgZWZmZWN0LlxuICAvLyBCdXQgaWYgPGJvZHk+IGhhcyBhbiBgb3ZlcmZsb3dgIHN0eWxlIChsaWtlIGBvdmVyZmxvdy14OiBoaWRkZW5gKSwgd2UgbmVlZCB0byBsb2NrIGl0XG4gIC8vIGluc3RlYWQsIGFzIHN0aWNreSBlbGVtZW50cyBzaGlmdCBvdGhlcndpc2UuXG4gIGNvbnN0IGVsZW1lbnRUb0xvY2sgPSBnZXRWaWV3cG9ydFNjcm9sbGVyKGh0bWwsIGJvZHkpO1xuICBjb25zdCBvcmlnaW5hbEVsZW1lbnRUb0xvY2tTdHlsZXMgPSB7XG4gICAgb3ZlcmZsb3dZOiBlbGVtZW50VG9Mb2NrLnN0eWxlLm92ZXJmbG93WSxcbiAgICBvdmVyZmxvd1g6IGVsZW1lbnRUb0xvY2suc3R5bGUub3ZlcmZsb3dYXG4gIH07XG4gIE9iamVjdC5hc3NpZ24oZWxlbWVudFRvTG9jay5zdHlsZSwge1xuICAgIG92ZXJmbG93WTogJ2hpZGRlbicsXG4gICAgb3ZlcmZsb3dYOiAnaGlkZGVuJ1xuICB9KTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICBPYmplY3QuYXNzaWduKGVsZW1lbnRUb0xvY2suc3R5bGUsIG9yaWdpbmFsRWxlbWVudFRvTG9ja1N0eWxlcyk7XG4gIH07XG59XG5mdW5jdGlvbiBwcmV2ZW50U2Nyb2xsSW5zZXRTY3JvbGxiYXJzKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KTtcbiAgY29uc3QgaHRtbCA9IGRvYy5kb2N1bWVudEVsZW1lbnQ7XG4gIGNvbnN0IGJvZHkgPSBkb2MuYm9keTtcbiAgY29uc3Qgd2luID0gb3duZXJXaW5kb3coaHRtbCk7XG4gIGxldCBzY3JvbGxUb3AgPSAwO1xuICBsZXQgc2Nyb2xsTGVmdCA9IDA7XG4gIGxldCB1cGRhdGVHdXR0ZXJPbmx5ID0gZmFsc2U7XG4gIGNvbnN0IHJlc2l6ZUZyYW1lID0gQW5pbWF0aW9uRnJhbWUuY3JlYXRlKCk7XG5cbiAgLy8gUGluY2gtem9vbSBpbiBTYWZhcmkgY2F1c2VzIGEgc2hpZnQuIEp1c3QgZG9uJ3QgbG9jayBzY3JvbGwgaWYgdGhlcmUncyBhbnkgcGluY2gtem9vbS5cbiAgaWYgKHBsYXRmb3JtLmVuZ2luZS53ZWJraXQgJiYgKHdpbi52aXN1YWxWaWV3cG9ydD8uc2NhbGUgPz8gMSkgIT09IDEpIHtcbiAgICByZXR1cm4gKCkgPT4ge307XG4gIH1cbiAgZnVuY3Rpb24gbG9ja1Njcm9sbCgpIHtcbiAgICAvKiBET00gcmVhZHM6ICovXG5cbiAgICBjb25zdCBodG1sU3R5bGVzID0gd2luLmdldENvbXB1dGVkU3R5bGUoaHRtbCk7XG4gICAgY29uc3QgYm9keVN0eWxlcyA9IHdpbi5nZXRDb21wdXRlZFN0eWxlKGJvZHkpO1xuICAgIGNvbnN0IGh0bWxTY3JvbGxiYXJHdXR0ZXJWYWx1ZSA9IGh0bWxTdHlsZXMuc2Nyb2xsYmFyR3V0dGVyIHx8ICcnO1xuICAgIGNvbnN0IGhhc0JvdGhFZGdlcyA9IGh0bWxTY3JvbGxiYXJHdXR0ZXJWYWx1ZS5pbmNsdWRlcygnYm90aC1lZGdlcycpO1xuICAgIGNvbnN0IHNjcm9sbGJhckd1dHRlclZhbHVlID0gaGFzQm90aEVkZ2VzID8gJ3N0YWJsZSBib3RoLWVkZ2VzJyA6ICdzdGFibGUnO1xuICAgIHNjcm9sbFRvcCA9IGh0bWwuc2Nyb2xsVG9wO1xuICAgIHNjcm9sbExlZnQgPSBodG1sLnNjcm9sbExlZnQ7XG4gICAgb3JpZ2luYWxIdG1sU3R5bGVzID0ge1xuICAgICAgc2Nyb2xsYmFyR3V0dGVyOiBodG1sLnN0eWxlLnNjcm9sbGJhckd1dHRlcixcbiAgICAgIG92ZXJmbG93WTogaHRtbC5zdHlsZS5vdmVyZmxvd1ksXG4gICAgICBvdmVyZmxvd1g6IGh0bWwuc3R5bGUub3ZlcmZsb3dYXG4gICAgfTtcbiAgICBvcmlnaW5hbEh0bWxTY3JvbGxCZWhhdmlvciA9IGh0bWwuc3R5bGUuc2Nyb2xsQmVoYXZpb3I7XG4gICAgb3JpZ2luYWxCb2R5U3R5bGVzID0ge1xuICAgICAgcG9zaXRpb246IGJvZHkuc3R5bGUucG9zaXRpb24sXG4gICAgICBoZWlnaHQ6IGJvZHkuc3R5bGUuaGVpZ2h0LFxuICAgICAgd2lkdGg6IGJvZHkuc3R5bGUud2lkdGgsXG4gICAgICBib3hTaXppbmc6IGJvZHkuc3R5bGUuYm94U2l6aW5nLFxuICAgICAgb3ZlcmZsb3dZOiBib2R5LnN0eWxlLm92ZXJmbG93WSxcbiAgICAgIG92ZXJmbG93WDogYm9keS5zdHlsZS5vdmVyZmxvd1gsXG4gICAgICBzY3JvbGxCZWhhdmlvcjogYm9keS5zdHlsZS5zY3JvbGxCZWhhdmlvclxuICAgIH07XG4gICAgY29uc3QgaXNTY3JvbGxhYmxlWSA9IGh0bWwuc2Nyb2xsSGVpZ2h0ID4gaHRtbC5jbGllbnRIZWlnaHQ7XG4gICAgY29uc3QgaXNTY3JvbGxhYmxlWCA9IGh0bWwuc2Nyb2xsV2lkdGggPiBodG1sLmNsaWVudFdpZHRoO1xuICAgIGNvbnN0IGhhc0NvbnN0YW50T3ZlcmZsb3dZID0gaHRtbFN0eWxlcy5vdmVyZmxvd1kgPT09ICdzY3JvbGwnIHx8IGJvZHlTdHlsZXMub3ZlcmZsb3dZID09PSAnc2Nyb2xsJztcbiAgICBjb25zdCBoYXNDb25zdGFudE92ZXJmbG93WCA9IGh0bWxTdHlsZXMub3ZlcmZsb3dYID09PSAnc2Nyb2xsJyB8fCBib2R5U3R5bGVzLm92ZXJmbG93WCA9PT0gJ3Njcm9sbCc7XG5cbiAgICAvLyBWYWx1ZXMgY2FuIGJlIG5lZ2F0aXZlIGluIEZpcmVmb3hcbiAgICBjb25zdCBzY3JvbGxiYXJXaWR0aCA9IE1hdGgubWF4KDAsIHdpbi5pbm5lcldpZHRoIC0gYm9keS5jbGllbnRXaWR0aCk7XG4gICAgY29uc3Qgc2Nyb2xsYmFySGVpZ2h0ID0gTWF0aC5tYXgoMCwgd2luLmlubmVySGVpZ2h0IC0gYm9keS5jbGllbnRIZWlnaHQpO1xuXG4gICAgLy8gQXZvaWQgc2hpZnQgZHVlIHRvIHRoZSBkZWZhdWx0IDxib2R5PiBtYXJnaW4uIFRoaXMgZG9lcyBjYXVzZSBlbGVtZW50cyB0byBiZSBjbGlwcGVkXG4gICAgLy8gd2l0aCB3aGl0ZXNwYWNlLiBXYXJuIGlmIDxib2R5PiBoYXMgbWFyZ2lucz9cbiAgICBjb25zdCBtYXJnaW5ZID0gcGFyc2VGbG9hdChib2R5U3R5bGVzLm1hcmdpblRvcCkgKyBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luQm90dG9tKTtcbiAgICBjb25zdCBtYXJnaW5YID0gcGFyc2VGbG9hdChib2R5U3R5bGVzLm1hcmdpbkxlZnQpICsgcGFyc2VGbG9hdChib2R5U3R5bGVzLm1hcmdpblJpZ2h0KTtcbiAgICBjb25zdCBlbGVtZW50VG9Mb2NrID0gZ2V0Vmlld3BvcnRTY3JvbGxlcihodG1sLCBib2R5KTtcbiAgICB1cGRhdGVHdXR0ZXJPbmx5ID0gc3VwcG9ydHNTdGFibGVTY3JvbGxiYXJHdXR0ZXIocmVmZXJlbmNlRWxlbWVudCk7XG5cbiAgICAvKlxuICAgICAqIERPTSB3cml0ZXM6XG4gICAgICogRG8gbm90IHJlYWQgdGhlIERPTSBwYXN0IHRoaXMgcG9pbnQhXG4gICAgICovXG5cbiAgICBpZiAodXBkYXRlR3V0dGVyT25seSkge1xuICAgICAgaHRtbC5zdHlsZS5zY3JvbGxiYXJHdXR0ZXIgPSBzY3JvbGxiYXJHdXR0ZXJWYWx1ZTtcbiAgICAgIGVsZW1lbnRUb0xvY2suc3R5bGUub3ZlcmZsb3dZID0gJ2hpZGRlbic7XG4gICAgICBlbGVtZW50VG9Mb2NrLnN0eWxlLm92ZXJmbG93WCA9ICdoaWRkZW4nO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBPYmplY3QuYXNzaWduKGh0bWwuc3R5bGUsIHtcbiAgICAgIHNjcm9sbGJhckd1dHRlcjogc2Nyb2xsYmFyR3V0dGVyVmFsdWUsXG4gICAgICBvdmVyZmxvd1k6ICdoaWRkZW4nLFxuICAgICAgb3ZlcmZsb3dYOiAnaGlkZGVuJ1xuICAgIH0pO1xuICAgIGlmIChpc1Njcm9sbGFibGVZIHx8IGhhc0NvbnN0YW50T3ZlcmZsb3dZKSB7XG4gICAgICBodG1sLnN0eWxlLm92ZXJmbG93WSA9ICdzY3JvbGwnO1xuICAgIH1cbiAgICBpZiAoaXNTY3JvbGxhYmxlWCB8fCBoYXNDb25zdGFudE92ZXJmbG93WCkge1xuICAgICAgaHRtbC5zdHlsZS5vdmVyZmxvd1ggPSAnc2Nyb2xsJztcbiAgICB9XG4gICAgT2JqZWN0LmFzc2lnbihib2R5LnN0eWxlLCB7XG4gICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgIGhlaWdodDogbWFyZ2luWSB8fCBzY3JvbGxiYXJIZWlnaHQgPyBgY2FsYygxMDBkdmggLSAke21hcmdpblkgKyBzY3JvbGxiYXJIZWlnaHR9cHgpYCA6ICcxMDBkdmgnLFxuICAgICAgd2lkdGg6IG1hcmdpblggfHwgc2Nyb2xsYmFyV2lkdGggPyBgY2FsYygxMDB2dyAtICR7bWFyZ2luWCArIHNjcm9sbGJhcldpZHRofXB4KWAgOiAnMTAwdncnLFxuICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAvLyBBc3NpZ24gdGhlIGxvbmdoYW5kcyB0aGF0IGBjbGVhbnVwYCByZXN0b3Jlcywgc28gbm90aGluZyBpcyBsZWZ0IGJlaGluZC5cbiAgICAgIG92ZXJmbG93WTogJ2hpZGRlbicsXG4gICAgICBvdmVyZmxvd1g6ICdoaWRkZW4nLFxuICAgICAgc2Nyb2xsQmVoYXZpb3I6ICd1bnNldCdcbiAgICB9KTtcbiAgICBib2R5LnNjcm9sbFRvcCA9IHNjcm9sbFRvcDtcbiAgICBib2R5LnNjcm9sbExlZnQgPSBzY3JvbGxMZWZ0O1xuICAgIGh0bWwuc2V0QXR0cmlidXRlKCdkYXRhLWJhc2UtdWktc2Nyb2xsLWxvY2tlZCcsICcnKTtcbiAgICBodG1sLnN0eWxlLnNjcm9sbEJlaGF2aW9yID0gJ3Vuc2V0JztcbiAgfVxuICBmdW5jdGlvbiBjbGVhbnVwKCkge1xuICAgIE9iamVjdC5hc3NpZ24oaHRtbC5zdHlsZSwgb3JpZ2luYWxIdG1sU3R5bGVzKTtcbiAgICBPYmplY3QuYXNzaWduKGJvZHkuc3R5bGUsIG9yaWdpbmFsQm9keVN0eWxlcyk7XG4gICAgaWYgKCF1cGRhdGVHdXR0ZXJPbmx5KSB7XG4gICAgICBodG1sLnNjcm9sbFRvcCA9IHNjcm9sbFRvcDtcbiAgICAgIGh0bWwuc2Nyb2xsTGVmdCA9IHNjcm9sbExlZnQ7XG4gICAgICBodG1sLnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1iYXNlLXVpLXNjcm9sbC1sb2NrZWQnKTtcbiAgICAgIGh0bWwuc3R5bGUuc2Nyb2xsQmVoYXZpb3IgPSBvcmlnaW5hbEh0bWxTY3JvbGxCZWhhdmlvcjtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlUmVzaXplKCkge1xuICAgIGNsZWFudXAoKTtcbiAgICByZXNpemVGcmFtZS5yZXF1ZXN0KGxvY2tTY3JvbGwpO1xuICB9XG4gIGxvY2tTY3JvbGwoKTtcbiAgY29uc3QgdW5zdWJzY3JpYmVSZXNpemUgPSBhZGRFdmVudExpc3RlbmVyKHdpbiwgJ3Jlc2l6ZScsIGhhbmRsZVJlc2l6ZSk7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgcmVzaXplRnJhbWUuY2FuY2VsKCk7XG4gICAgY2xlYW51cCgpO1xuICAgIC8vIFNvbWV0aW1lcyB0aGlzIGNsZWFudXAgY2FuIHJ1biBhZnRlciB0ZXN0IHRlYXJkb3duIGJlY2F1c2UgaXQgaXMgY2FsbGVkXG4gICAgLy8gaW4gYSBgc2V0VGltZW91dChmbiwgMClgLiBHdWFyZCB0aGUgcmV0dXJuZWQgY2xlYW51cCB0byBhdm9pZCBjYWxsaW5nXG4gICAgLy8gYHJlbW92ZUV2ZW50TGlzdGVuZXJgIHdoZW4gaXQgaXMgbm8gbG9uZ2VyIGF2YWlsYWJsZSBpbiB0ZXN0cy5cbiAgICBpZiAodHlwZW9mIHdpbi5yZW1vdmVFdmVudExpc3RlbmVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICB1bnN1YnNjcmliZVJlc2l6ZSgpO1xuICAgIH1cbiAgfTtcbn1cbmNsYXNzIFNjcm9sbExvY2tlciB7XG4gIGxvY2tDb3VudCA9IDA7XG4gIHJlc3RvcmUgPSBudWxsO1xuICB0aW1lb3V0TG9jayA9IFRpbWVvdXQuY3JlYXRlKCk7XG4gIHRpbWVvdXRVbmxvY2sgPSBUaW1lb3V0LmNyZWF0ZSgpO1xuICBhY3F1aXJlKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgICB0aGlzLmxvY2tDb3VudCArPSAxO1xuICAgIGlmICh0aGlzLmxvY2tDb3VudCA9PT0gMSAmJiB0aGlzLnJlc3RvcmUgPT09IG51bGwpIHtcbiAgICAgIHRoaXMudGltZW91dExvY2suc3RhcnQoMCwgKCkgPT4gdGhpcy5sb2NrKHJlZmVyZW5jZUVsZW1lbnQpKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucmVsZWFzZTtcbiAgfVxuICByZWxlYXNlID0gKCkgPT4ge1xuICAgIHRoaXMubG9ja0NvdW50IC09IDE7XG4gICAgaWYgKHRoaXMubG9ja0NvdW50ID09PSAwICYmIHRoaXMucmVzdG9yZSkge1xuICAgICAgdGhpcy50aW1lb3V0VW5sb2NrLnN0YXJ0KDAsIHRoaXMudW5sb2NrKTtcbiAgICB9XG4gIH07XG4gIHVubG9jayA9ICgpID0+IHtcbiAgICBpZiAodGhpcy5sb2NrQ291bnQgPT09IDAgJiYgdGhpcy5yZXN0b3JlKSB7XG4gICAgICB0aGlzLnJlc3RvcmU/LigpO1xuICAgICAgdGhpcy5yZXN0b3JlID0gbnVsbDtcbiAgICB9XG4gIH07XG4gIGxvY2socmVmZXJlbmNlRWxlbWVudCkge1xuICAgIGlmICh0aGlzLmxvY2tDb3VudCA9PT0gMCB8fCB0aGlzLnJlc3RvcmUgIT09IG51bGwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KTtcbiAgICBjb25zdCBodG1sID0gZG9jLmRvY3VtZW50RWxlbWVudDtcbiAgICBjb25zdCBib2R5ID0gZG9jLmJvZHk7XG4gICAgY29uc3Qgd2luID0gb3duZXJXaW5kb3coaHRtbCk7XG5cbiAgICAvLyBUaGUgcGFnZSBpcyBhbHJlYWR5IGxvY2tlZCwgZWl0aGVyIGJ5IHRoZSBzaXRlIGF1dGhvciBvciBieSBhIG5vbi1CYXNlIFVJIG92ZXJsYXkgdGhhdFxuICAgIC8vIGhhc24ndCBjbGVhbmVkIHVwIHlldC4gTGVhdmUgaXQgYWxvbmUgYW5kIHdhaXQgZm9yIHRoZSBsb2NrIHRvIGNsZWFyIGJlZm9yZSB0YWtpbmcgb3ZlcixcbiAgICAvLyBvdGhlcndpc2Ugd2UnZCBzbmFwc2hvdCB0aGUgbG9ja2VkIHN0YXRlIGFuZCByZXN0b3JlIGl0IGFmdGVyIG91ciBvd24gbG9jayBpcyByZWxlYXNlZC5cbiAgICBpZiAoaXNQYWdlU2Nyb2xsTG9ja2VkKHdpbiwgaHRtbCwgYm9keSkpIHtcbiAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IHdpbi5NdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcbiAgICAgICAgaWYgKGlzUGFnZVNjcm9sbExvY2tlZCh3aW4sIGh0bWwsIGJvZHkpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgdGhpcy5yZXN0b3JlID0gbnVsbDtcbiAgICAgICAgdGhpcy5sb2NrKHJlZmVyZW5jZUVsZW1lbnQpO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIFdhdGNoIGV2ZXJ5IGF0dHJpYnV0ZTogbG9ja3MgYXJlIGFwcGxpZWQgdGhyb3VnaCBpbmxpbmUgc3R5bGVzLCBjbGFzc2VzLCBvciBhdHRyaWJ1dGVzXG4gICAgICAvLyBwYWlyZWQgd2l0aCBhIHN0eWxlc2hlZXQgKGBkYXRhLXNjcm9sbC1sb2NrZWRgIGluIHJlYWN0LXJlbW92ZS1zY3JvbGwsIGZvciBleGFtcGxlKS5cbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgIGF0dHJpYnV0ZXM6IHRydWVcbiAgICAgIH07XG4gICAgICBvYnNlcnZlci5vYnNlcnZlKGh0bWwsIG9wdGlvbnMpO1xuICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShib2R5LCBvcHRpb25zKTtcbiAgICAgIHRoaXMucmVzdG9yZSA9ICgpID0+IG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaGFzT3ZlcmxheVNjcm9sbGJhcnMgPSBwbGF0Zm9ybS5vcy5pb3MgfHwgIWhhc0luc2V0U2Nyb2xsYmFycyhyZWZlcmVuY2VFbGVtZW50KTtcblxuICAgIC8vIE9uIGlPUywgc2Nyb2xsIGxvY2tpbmcgZG9lcyBub3Qgd29yayBpZiB0aGUgbmF2YmFyIGlzIGNvbGxhcHNlZC4gRHVlIHRvIG51bWVyb3VzXG4gICAgLy8gc2lkZSBlZmZlY3RzIGFuZCBidWdzIHRoYXQgYXJpc2Ugb24gaU9TLCBpdCBtdXN0IGJlIHJlc2VhcmNoZWQgZXh0ZW5zaXZlbHkgYmVmb3JlXG4gICAgLy8gYmVpbmcgZW5hYmxlZCB0byBlbnN1cmUgaXQgZG9lc24ndCBjYXVzZSB0aGUgZm9sbG93aW5nIGlzc3VlczpcbiAgICAvLyAtIFRleHRib3hlcyBtdXN0IHNjcm9sbCBpbnRvIHZpZXcgd2hlbiBmb2N1c2VkLCBub3IgY2F1c2UgYSBnbGl0Y2h5IHNjcm9sbCBhbmltYXRpb24uXG4gICAgLy8gLSBUaGUgbmF2YmFyIG11c3Qgbm90IGZvcmNlIGl0c2VsZiBpbnRvIHZpZXcgYW5kIGNhdXNlIGxheW91dCBzaGlmdC5cbiAgICAvLyAtIFNjcm9sbCBjb250YWluZXJzIG11c3Qgbm90IGZsaWNrZXIgdXBvbiBjbG9zaW5nIGEgcG9wdXAgd2hlbiBpdCBoYXMgYW4gZXhpdCBhbmltYXRpb24uXG4gICAgdGhpcy5yZXN0b3JlID0gaGFzT3ZlcmxheVNjcm9sbGJhcnMgPyBwcmV2ZW50U2Nyb2xsT3ZlcmxheVNjcm9sbGJhcnMocmVmZXJlbmNlRWxlbWVudCkgOiBwcmV2ZW50U2Nyb2xsSW5zZXRTY3JvbGxiYXJzKHJlZmVyZW5jZUVsZW1lbnQpO1xuICB9XG59XG5jb25zdCBTQ1JPTExfTE9DS0VSID0gbmV3IFNjcm9sbExvY2tlcigpO1xuXG4vKipcbiAqIExvY2tzIHRoZSBzY3JvbGwgb2YgdGhlIGRvY3VtZW50IHdoZW4gZW5hYmxlZC5cbiAqXG4gKiBAcGFyYW0gZW5hYmxlZCAtIFdoZXRoZXIgdG8gZW5hYmxlIHRoZSBzY3JvbGwgbG9jay5cbiAqIEBwYXJhbSByZWZlcmVuY2VFbGVtZW50IC0gRWxlbWVudCB0byB1c2UgYXMgYSByZWZlcmVuY2UgZm9yIGxvY2sgY2FsY3VsYXRpb25zLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlU2Nyb2xsTG9jayhlbmFibGVkID0gdHJ1ZSwgcmVmZXJlbmNlRWxlbWVudCA9IG51bGwpIHtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHJldHVybiBTQ1JPTExfTE9DS0VSLmFjcXVpcmUocmVmZXJlbmNlRWxlbWVudCk7XG4gIH0sIFtlbmFibGVkLCByZWZlcmVuY2VFbGVtZW50XSk7XG59IiwiaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tICdAYmFzZS11aS91dGlscy9wbGF0Zm9ybSc7XG5leHBvcnQgZnVuY3Rpb24gc3RvcEV2ZW50KGV2ZW50KSB7XG4gIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzUmVhY3RFdmVudChldmVudCkge1xuICByZXR1cm4gJ25hdGl2ZUV2ZW50JyBpbiBldmVudDtcbn1cblxuLy8gTGljZW5zZTogaHR0cHM6Ly9naXRodWIuY29tL2Fkb2JlL3JlYWN0LXNwZWN0cnVtL2Jsb2IvbWFpbi9wYWNrYWdlcy9AcmVhY3QtYXJpYS91dGlscy9zcmMvaXNWaXJ0dWFsRXZlbnQudHNcbmV4cG9ydCBmdW5jdGlvbiBpc1ZpcnR1YWxDbGljayhldmVudCkge1xuICBpZiAoZXZlbnQucG9pbnRlclR5cGUgPT09ICcnICYmIGV2ZW50LmlzVHJ1c3RlZCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChwbGF0Zm9ybS5vcy5hbmRyb2lkICYmIGV2ZW50LnBvaW50ZXJUeXBlKSB7XG4gICAgcmV0dXJuIGV2ZW50LnR5cGUgPT09ICdjbGljaycgJiYgZXZlbnQuYnV0dG9ucyA9PT0gMTtcbiAgfVxuICByZXR1cm4gZXZlbnQuZGV0YWlsID09PSAwICYmICFldmVudC5wb2ludGVyVHlwZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZXZlbnQpIHtcbiAgaWYgKHBsYXRmb3JtLmVudi5qc2RvbSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gIXBsYXRmb3JtLm9zLmFuZHJvaWQgJiYgZXZlbnQud2lkdGggPT09IDAgJiYgZXZlbnQuaGVpZ2h0ID09PSAwIHx8IHBsYXRmb3JtLm9zLmFuZHJvaWQgJiYgZXZlbnQud2lkdGggPT09IDEgJiYgZXZlbnQuaGVpZ2h0ID09PSAxICYmIGV2ZW50LnByZXNzdXJlID09PSAwICYmIGV2ZW50LmRldGFpbCA9PT0gMCAmJiBldmVudC5wb2ludGVyVHlwZSA9PT0gJ21vdXNlJyB8fFxuICAvLyBpT1MgVm9pY2VPdmVyIHJldHVybnMgMC4zMzPigKIgZm9yIHdpZHRoL2hlaWdodC5cbiAgZXZlbnQud2lkdGggPCAxICYmIGV2ZW50LmhlaWdodCA8IDEgJiYgZXZlbnQucHJlc3N1cmUgPT09IDAgJiYgZXZlbnQuZGV0YWlsID09PSAwICYmIGV2ZW50LnBvaW50ZXJUeXBlID09PSAndG91Y2gnO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzTW91c2VMaWtlUG9pbnRlclR5cGUocG9pbnRlclR5cGUsIHN0cmljdCkge1xuICAvLyBPbiBzb21lIExpbnV4IG1hY2hpbmVzIHdpdGggQ2hyb21pdW0sIG1vdXNlIGlucHV0cyByZXR1cm4gYSBgcG9pbnRlclR5cGVgXG4gIC8vIG9mIFwicGVuXCI6IGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMjAxNVxuICBjb25zdCB2YWx1ZXMgPSBbJ21vdXNlJywgJ3BlbiddO1xuICBpZiAoIXN0cmljdCkge1xuICAgIHZhbHVlcy5wdXNoKCcnLCB1bmRlZmluZWQpO1xuICB9XG4gIHJldHVybiB2YWx1ZXMuaW5jbHVkZXMocG9pbnRlclR5cGUpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzQ2xpY2tMaWtlRXZlbnQoZXZlbnQpIHtcbiAgY29uc3QgdHlwZSA9IGV2ZW50LnR5cGU7XG4gIHJldHVybiB0eXBlID09PSAnY2xpY2snIHx8IHR5cGUgPT09ICdtb3VzZWRvd24nIHx8IHR5cGUgPT09ICdrZXlkb3duJyB8fCB0eXBlID09PSAna2V5dXAnO1xufSIsImV4cG9ydCBjb25zdCBGT0NVU0FCTEVfQVRUUklCVVRFID0gJ2RhdGEtYmFzZS11aS1mb2N1c2FibGUnO1xuZXhwb3J0IGNvbnN0IEFDVElWRV9LRVkgPSAnYWN0aXZlJztcbmV4cG9ydCBjb25zdCBTRUxFQ1RFRF9LRVkgPSAnc2VsZWN0ZWQnO1xuZXhwb3J0IGNvbnN0IFRZUEVBQkxFX1NFTEVDVE9SID0gXCJpbnB1dDpub3QoW3R5cGU9J2hpZGRlbiddKTpub3QoW2Rpc2FibGVkXSksXCIgKyBcIltjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPSdmYWxzZSddKSx0ZXh0YXJlYTpub3QoW2Rpc2FibGVkXSlcIjtcbmV4cG9ydCBjb25zdCBBUlJPV19MRUZUID0gJ0Fycm93TGVmdCc7XG5leHBvcnQgY29uc3QgQVJST1dfUklHSFQgPSAnQXJyb3dSaWdodCc7XG5leHBvcnQgY29uc3QgQVJST1dfVVAgPSAnQXJyb3dVcCc7XG5leHBvcnQgY29uc3QgQVJST1dfRE9XTiA9ICdBcnJvd0Rvd24nOyIsImltcG9ydCB7IGlzRWxlbWVudCwgaXNIVE1MRWxlbWVudCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tICdAYmFzZS11aS91dGlscy9wbGF0Zm9ybSc7XG5pbXBvcnQgeyBGT0NVU0FCTEVfQVRUUklCVVRFLCBUWVBFQUJMRV9TRUxFQ1RPUiB9IGZyb20gXCIuL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNvbnRhaW5zLCBnZXRUYXJnZXQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3NoYWRvd0RvbS5tanNcIjtcbmV4cG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNvbnRhaW5zLCBnZXRUYXJnZXQgfTtcbmV4cG9ydCBmdW5jdGlvbiBpc1RhcmdldEluc2lkZUVuYWJsZWRUcmlnZ2VyKHRhcmdldCwgdHJpZ2dlckVsZW1lbnRzKSB7XG4gIGlmICghaXNFbGVtZW50KHRhcmdldCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdGFyZ2V0RWxlbWVudCA9IHRhcmdldDtcbiAgaWYgKHRyaWdnZXJFbGVtZW50cy5oYXNFbGVtZW50KHRhcmdldEVsZW1lbnQpKSB7XG4gICAgcmV0dXJuICF0YXJnZXRFbGVtZW50Lmhhc0F0dHJpYnV0ZSgnZGF0YS10cmlnZ2VyLWRpc2FibGVkJyk7XG4gIH1cbiAgZm9yIChjb25zdCBbLCB0cmlnZ2VyXSBvZiB0cmlnZ2VyRWxlbWVudHMuZW50cmllcygpKSB7XG4gICAgaWYgKGNvbnRhaW5zKHRyaWdnZXIsIHRhcmdldEVsZW1lbnQpKSB7XG4gICAgICByZXR1cm4gIXRyaWdnZXIuaGFzQXR0cmlidXRlKCdkYXRhLXRyaWdnZXItZGlzYWJsZWQnKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIG5vZGUpIHtcbiAgaWYgKG5vZGUgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoJ2NvbXBvc2VkUGF0aCcgaW4gZXZlbnQpIHtcbiAgICByZXR1cm4gZXZlbnQuY29tcG9zZWRQYXRoKCkuaW5jbHVkZXMobm9kZSk7XG4gIH1cblxuICAvLyBUUyB0aGlua3MgYGV2ZW50YCBpcyBvZiB0eXBlIG5ldmVyIGFzIGl0IGFzc3VtZXMgYWxsIGJyb3dzZXJzIHN1cHBvcnQgY29tcG9zZWRQYXRoLCBidXQgYnJvd3NlcnMgd2l0aG91dCBzaGFkb3cgZG9tIGRvbid0XG4gIGNvbnN0IGV2ZW50QWdhaW4gPSBldmVudDtcbiAgcmV0dXJuIGV2ZW50QWdhaW4udGFyZ2V0ICE9IG51bGwgJiYgbm9kZS5jb250YWlucyhldmVudEFnYWluLnRhcmdldCk7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNSb290RWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50Lm1hdGNoZXMoJ2h0bWwsYm9keScpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzVHlwZWFibGVFbGVtZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzSFRNTEVsZW1lbnQoZWxlbWVudCkgJiYgZWxlbWVudC5tYXRjaGVzKFRZUEVBQkxFX1NFTEVDVE9SKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0ludGVyYWN0aXZlRWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50Py5jbG9zZXN0KGBidXR0b24sYVtocmVmXSxbcm9sZT1cImJ1dHRvblwiXSxzZWxlY3QsW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pLCR7VFlQRUFCTEVfU0VMRUNUT1J9YCkgIT0gbnVsbDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1R5cGVhYmxlQ29tYm9ib3goZWxlbWVudCkge1xuICBpZiAoIWVsZW1lbnQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIGVsZW1lbnQuZ2V0QXR0cmlidXRlKCdyb2xlJykgPT09ICdjb21ib2JveCcgJiYgaXNUeXBlYWJsZUVsZW1lbnQoZWxlbWVudCk7XG59XG5leHBvcnQgZnVuY3Rpb24gbWF0Y2hlc0ZvY3VzVmlzaWJsZShlbGVtZW50KSB7XG4gIC8vIFdlIGRvbid0IHdhbnQgdG8gYmxvY2sgZm9jdXMgZnJvbSB3b3JraW5nIHdpdGggYHZpc2libGVPbmx5YFxuICAvLyAoSlNET00gZG9lc24ndCBtYXRjaCBgOmZvY3VzLXZpc2libGVgIHdoZW4gdGhlIGVsZW1lbnQgaGFzIGA6Zm9jdXNgKVxuICBpZiAoIWVsZW1lbnQgfHwgcGxhdGZvcm0uZW52LmpzZG9tKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgdHJ5IHtcbiAgICByZXR1cm4gZWxlbWVudC5tYXRjaGVzKCc6Zm9jdXMtdmlzaWJsZScpO1xuICB9IGNhdGNoIChfZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQoZmxvYXRpbmdFbGVtZW50KSB7XG4gIGlmICghZmxvYXRpbmdFbGVtZW50KSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgLy8gVHJ5IHRvIGZpbmQgdGhlIGVsZW1lbnQgdGhhdCBoYXMgYHsuLi5nZXRGbG9hdGluZ1Byb3BzKCl9YCBzcHJlYWQgb24gaXQuXG4gIC8vIFRoaXMgaW5kaWNhdGVzIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIGFjdGluZyBhcyBhIHBvc2l0aW9uaW5nIHdyYXBwZXIsIGFuZFxuICAvLyBzbyBmb2N1cyBzaG91bGQgYmUgbWFuYWdlZCBvbiB0aGUgY2hpbGQgZWxlbWVudCB3aXRoIHRoZSBldmVudCBoYW5kbGVycyBhbmRcbiAgLy8gYXJpYSBwcm9wcy5cbiAgcmV0dXJuIGZsb2F0aW5nRWxlbWVudC5oYXNBdHRyaWJ1dGUoRk9DVVNBQkxFX0FUVFJJQlVURSkgPyBmbG9hdGluZ0VsZW1lbnQgOiBmbG9hdGluZ0VsZW1lbnQucXVlcnlTZWxlY3RvcihgWyR7Rk9DVVNBQkxFX0FUVFJJQlVURX1dYCkgfHwgZmxvYXRpbmdFbGVtZW50O1xufSIsIi8qKlxuICogQ29tYmluZXMgbXVsdGlwbGUgY2xlYW51cCBmdW5jdGlvbnMgaW50byBhIHNpbmdsZSBjbGVhbnVwIGZ1bmN0aW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VDbGVhbnVwcyguLi5jbGVhbnVwcykge1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2xlYW51cHMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IGNsZWFudXAgPSBjbGVhbnVwc1tpXTtcbiAgICAgIGlmIChjbGVhbnVwKSB7XG4gICAgICAgIGNsZWFudXAoKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi91c2VJc29MYXlvdXRFZmZlY3QubWpzXCI7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gXCIuL3VzZVJlZldpdGhJbml0Lm1qc1wiO1xuXG4vKipcbiAqIFVudHJhY2tzIHRoZSBwcm92aWRlZCB2YWx1ZSBieSB0dXJuaW5nIGl0IGludG8gYSByZWYgdG8gcmVtb3ZlIGl0cyByZWFjdGl2aXR5LlxuICpcbiAqIFVzZWQgdG8gYWNjZXNzIHRoZSBwYXNzZWQgdmFsdWUgaW5zaWRlIGBSZWFjdC51c2VFZmZlY3RgIHdpdGhvdXQgY2F1c2luZyB0aGUgZWZmZWN0IHRvIHJlLXJ1biB3aGVuIHRoZSB2YWx1ZSBjaGFuZ2VzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVmFsdWVBc1JlZih2YWx1ZSkge1xuICBjb25zdCBsYXRlc3QgPSB1c2VSZWZXaXRoSW5pdChjcmVhdGVMYXRlc3RSZWYsIHZhbHVlKS5jdXJyZW50O1xuICBsYXRlc3QubmV4dCA9IHZhbHVlO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KGxhdGVzdC5lZmZlY3QpO1xuICByZXR1cm4gbGF0ZXN0O1xufVxuZnVuY3Rpb24gY3JlYXRlTGF0ZXN0UmVmKHZhbHVlKSB7XG4gIGNvbnN0IGxhdGVzdCA9IHtcbiAgICBjdXJyZW50OiB2YWx1ZSxcbiAgICBuZXh0OiB2YWx1ZSxcbiAgICBlZmZlY3Q6ICgpID0+IHtcbiAgICAgIGxhdGVzdC5jdXJyZW50ID0gbGF0ZXN0Lm5leHQ7XG4gICAgfVxuICB9O1xuICByZXR1cm4gbGF0ZXN0O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0nO1xuaW1wb3J0IHsgdmlzdWFsbHlIaWRkZW4gfSBmcm9tICdAYmFzZS11aS91dGlscy92aXN1YWxseUhpZGRlbic7XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgRm9jdXNHdWFyZCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZvY3VzR3VhcmQocHJvcHMsIHJlZikge1xuICBjb25zdCBbcm9sZSwgc2V0Um9sZV0gPSBSZWFjdC51c2VTdGF0ZSgpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIC8vIFVubGlrZSBOVkRBIGFuZCBKQVdTLCBWb2ljZU92ZXIncyB2aXJ0dWFsIGN1cnNvciB0cmlnZ2VycyBgb25Gb2N1c2AgYXNcbiAgICAvLyBpdCBtb3ZlcyDigJQgYnV0IG9ubHkgb24gZm9jdXNhYmxlL3JvbGUtYnV0dG9uIGVsZW1lbnRzIHRocm91Z2ggV2ViS2l0J3NcbiAgICAvLyBOU0FjY2Vzc2liaWxpdHkgcGF0aC4gU2V0dGluZyBgcm9sZT1cImJ1dHRvblwiYCBsZXRzIHRoZSBmb2N1cyB0cmFwIGNhdGNoXG4gICAgLy8gdGhlIGN1cnNvci5cbiAgICBpZiAocGxhdGZvcm0uc2NyZWVuUmVhZGVyLnZvaWNlT3ZlciAmJiBwbGF0Zm9ybS5lbmdpbmUud2Via2l0KSB7XG4gICAgICBzZXRSb2xlKCdidXR0b24nKTtcbiAgICB9XG4gIH0sIFtdKTtcbiAgY29uc3QgcmVzdFByb3BzID0ge1xuICAgIHRhYkluZGV4OiAwLFxuICAgIC8vIFJvbGUgaXMgb25seSBmb3IgVm9pY2VPdmVyXG4gICAgcm9sZVxuICB9O1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goXCJzcGFuXCIsIHtcbiAgICAuLi5wcm9wcyxcbiAgICByZWY6IHJlZixcbiAgICBzdHlsZTogdmlzdWFsbHlIaWRkZW4sXG4gICAgXCJhcmlhLWhpZGRlblwiOiByb2xlID8gdW5kZWZpbmVkIDogdHJ1ZSxcbiAgICAuLi5yZXN0UHJvcHMsXG4gICAgXCJkYXRhLWJhc2UtdWktZm9jdXMtZ3VhcmRcIjogXCJcIlxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRm9jdXNHdWFyZC5kaXNwbGF5TmFtZSA9IFwiRm9jdXNHdWFyZFwiOyIsImltcG9ydCB7IGdldENvbXB1dGVkU3R5bGUsIGdldE5vZGVOYW1lLCBpc0hUTUxFbGVtZW50LCBpc1NoYWRvd1Jvb3QgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyBhY3RpdmVFbGVtZW50LCBjb250YWlucyB9IGZyb20gXCIuL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc0VsZW1lbnRWaXNpYmxlIH0gZnJvbSBcIi4vY29tcG9zaXRlLm1qc1wiO1xuY29uc3QgQ0FORElEQVRFX1NFTEVDVE9SID0gJ2FbaHJlZl0sYnV0dG9uLGlucHV0LHNlbGVjdCx0ZXh0YXJlYSxzdW1tYXJ5LGRldGFpbHMsaWZyYW1lLG9iamVjdCxlbWJlZCxbdGFiaW5kZXhdLFtjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPVwiZmFsc2VcIl0pLGF1ZGlvW2NvbnRyb2xzXSx2aWRlb1tjb250cm9sc10nO1xuZnVuY3Rpb24gZ2V0UGFyZW50RWxlbWVudChlbGVtZW50KSB7XG4gIGNvbnN0IGFzc2lnbmVkU2xvdCA9IGVsZW1lbnQuYXNzaWduZWRTbG90O1xuICBpZiAoYXNzaWduZWRTbG90KSB7XG4gICAgcmV0dXJuIGFzc2lnbmVkU2xvdDtcbiAgfVxuICBpZiAoZWxlbWVudC5wYXJlbnRFbGVtZW50KSB7XG4gICAgcmV0dXJuIGVsZW1lbnQucGFyZW50RWxlbWVudDtcbiAgfVxuICBjb25zdCByb290Tm9kZSA9IGVsZW1lbnQuZ2V0Um9vdE5vZGUoKTtcbiAgcmV0dXJuIGlzU2hhZG93Um9vdChyb290Tm9kZSkgPyByb290Tm9kZS5ob3N0IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGdldERldGFpbHNTdW1tYXJ5KGRldGFpbHMpIHtcbiAgZm9yIChjb25zdCBjaGlsZCBvZiBBcnJheS5mcm9tKGRldGFpbHMuY2hpbGRyZW4pKSB7XG4gICAgaWYgKGdldE5vZGVOYW1lKGNoaWxkKSA9PT0gJ3N1bW1hcnknKSB7XG4gICAgICByZXR1cm4gY2hpbGQ7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gaXNXaXRoaW5PcGVuRGV0YWlsc1N1bW1hcnkoZWxlbWVudCwgZGV0YWlscykge1xuICBjb25zdCBzdW1tYXJ5ID0gZ2V0RGV0YWlsc1N1bW1hcnkoZGV0YWlscyk7XG4gIHJldHVybiAhIXN1bW1hcnkgJiYgKGVsZW1lbnQgPT09IHN1bW1hcnkgfHwgY29udGFpbnMoc3VtbWFyeSwgZWxlbWVudCkpO1xufVxuZnVuY3Rpb24gaXNGb2N1c2FibGVDYW5kaWRhdGUoZWxlbWVudCkge1xuICBjb25zdCBub2RlTmFtZSA9IGVsZW1lbnQgPyBnZXROb2RlTmFtZShlbGVtZW50KSA6ICcnO1xuICByZXR1cm4gZWxlbWVudCAhPSBudWxsICYmIGVsZW1lbnQubWF0Y2hlcyhDQU5ESURBVEVfU0VMRUNUT1IpICYmIChub2RlTmFtZSAhPT0gJ3N1bW1hcnknIHx8IGVsZW1lbnQucGFyZW50RWxlbWVudCAhPSBudWxsICYmIGdldE5vZGVOYW1lKGVsZW1lbnQucGFyZW50RWxlbWVudCkgPT09ICdkZXRhaWxzJyAmJiBnZXREZXRhaWxzU3VtbWFyeShlbGVtZW50LnBhcmVudEVsZW1lbnQpID09PSBlbGVtZW50KSAmJiAobm9kZU5hbWUgIT09ICdkZXRhaWxzJyB8fCBnZXREZXRhaWxzU3VtbWFyeShlbGVtZW50KSA9PSBudWxsKSAmJiAobm9kZU5hbWUgIT09ICdpbnB1dCcgfHwgZWxlbWVudC50eXBlICE9PSAnaGlkZGVuJyk7XG59XG5mdW5jdGlvbiBpc0ZvY3VzYWJsZUVsZW1lbnQoZWxlbWVudCkge1xuICBpZiAoIWlzRm9jdXNhYmxlQ2FuZGlkYXRlKGVsZW1lbnQpIHx8ICFlbGVtZW50LmlzQ29ubmVjdGVkIHx8IGVsZW1lbnQubWF0Y2hlcygnOmRpc2FibGVkJykpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChsZXQgY3VycmVudCA9IGVsZW1lbnQ7IGN1cnJlbnQ7IGN1cnJlbnQgPSBnZXRQYXJlbnRFbGVtZW50KGN1cnJlbnQpKSB7XG4gICAgY29uc3QgaXNBbmNlc3RvciA9IGN1cnJlbnQgIT09IGVsZW1lbnQ7XG4gICAgY29uc3QgaXNTbG90ID0gZ2V0Tm9kZU5hbWUoY3VycmVudCkgPT09ICdzbG90JztcbiAgICBpZiAoY3VycmVudC5oYXNBdHRyaWJ1dGUoJ2luZXJ0JykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGlzQW5jZXN0b3IgJiYgZ2V0Tm9kZU5hbWUoY3VycmVudCkgPT09ICdkZXRhaWxzJyAmJiAhY3VycmVudC5vcGVuICYmICFpc1dpdGhpbk9wZW5EZXRhaWxzU3VtbWFyeShlbGVtZW50LCBjdXJyZW50KSB8fCBjdXJyZW50Lmhhc0F0dHJpYnV0ZSgnaGlkZGVuJykgfHwgIWlzU2xvdCAmJiAhaXNWaXNpYmxlSW5UYWJiYWJsZVRyZWUoY3VycmVudCwgaXNBbmNlc3RvcikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpc1Zpc2libGVJblRhYmJhYmxlVHJlZShlbGVtZW50LCBpc0FuY2VzdG9yKSB7XG4gIGNvbnN0IHN0eWxlcyA9IGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gIGlmICghaXNBbmNlc3Rvcikge1xuICAgIHJldHVybiBpc0VsZW1lbnRWaXNpYmxlKGVsZW1lbnQsIHN0eWxlcyk7XG4gIH1cbiAgcmV0dXJuIHN0eWxlcy5kaXNwbGF5ICE9PSAnbm9uZSc7XG59XG5mdW5jdGlvbiBnZXRUYWJJbmRleChlbGVtZW50KSB7XG4gIGNvbnN0IHRhYkluZGV4ID0gZWxlbWVudC50YWJJbmRleDtcbiAgaWYgKHRhYkluZGV4IDwgMCkge1xuICAgIGNvbnN0IG5vZGVOYW1lID0gZ2V0Tm9kZU5hbWUoZWxlbWVudCk7XG4gICAgaWYgKG5vZGVOYW1lID09PSAnZGV0YWlscycgfHwgbm9kZU5hbWUgPT09ICdhdWRpbycgfHwgbm9kZU5hbWUgPT09ICd2aWRlbycgfHwgaXNIVE1MRWxlbWVudChlbGVtZW50KSAmJiBlbGVtZW50LmlzQ29udGVudEVkaXRhYmxlKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRhYkluZGV4O1xufVxuZnVuY3Rpb24gZ2V0TmFtZWRSYWRpb0lucHV0KGVsZW1lbnQpIHtcbiAgaWYgKGdldE5vZGVOYW1lKGVsZW1lbnQpICE9PSAnaW5wdXQnKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgaW5wdXQgPSBlbGVtZW50O1xuICByZXR1cm4gaW5wdXQudHlwZSA9PT0gJ3JhZGlvJyAmJiBpbnB1dC5uYW1lICE9PSAnJyA/IGlucHV0IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGlzVGFiYmFibGVSYWRpbyhlbGVtZW50LCBjYW5kaWRhdGVzKSB7XG4gIGNvbnN0IGlucHV0ID0gZ2V0TmFtZWRSYWRpb0lucHV0KGVsZW1lbnQpO1xuICBpZiAoIWlucHV0KSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgY29uc3QgY2hlY2tlZFJhZGlvID0gY2FuZGlkYXRlcy5maW5kKGNhbmRpZGF0ZSA9PiB7XG4gICAgY29uc3QgcmFkaW8gPSBnZXROYW1lZFJhZGlvSW5wdXQoY2FuZGlkYXRlKTtcbiAgICByZXR1cm4gcmFkaW8/Lm5hbWUgPT09IGlucHV0Lm5hbWUgJiYgcmFkaW8uZm9ybSA9PT0gaW5wdXQuZm9ybSAmJiByYWRpby5jaGVja2VkO1xuICB9KTtcbiAgaWYgKGNoZWNrZWRSYWRpbykge1xuICAgIHJldHVybiBjaGVja2VkUmFkaW8gPT09IGlucHV0O1xuICB9XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbmQoY2FuZGlkYXRlID0+IHtcbiAgICBjb25zdCByYWRpbyA9IGdldE5hbWVkUmFkaW9JbnB1dChjYW5kaWRhdGUpO1xuICAgIHJldHVybiByYWRpbz8ubmFtZSA9PT0gaW5wdXQubmFtZSAmJiByYWRpby5mb3JtID09PSBpbnB1dC5mb3JtO1xuICB9KSA9PT0gaW5wdXQ7XG59XG5mdW5jdGlvbiBnZXRDb21wb3NlZENoaWxkcmVuKGNvbnRhaW5lcikge1xuICBpZiAoaXNIVE1MRWxlbWVudChjb250YWluZXIpICYmIGdldE5vZGVOYW1lKGNvbnRhaW5lcikgPT09ICdzbG90Jykge1xuICAgIGNvbnN0IGFzc2lnbmVkRWxlbWVudHMgPSBjb250YWluZXIuYXNzaWduZWRFbGVtZW50cyh7XG4gICAgICBmbGF0dGVuOiB0cnVlXG4gICAgfSk7XG4gICAgaWYgKGFzc2lnbmVkRWxlbWVudHMubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIGFzc2lnbmVkRWxlbWVudHM7XG4gICAgfVxuICB9XG4gIGlmIChpc0hUTUxFbGVtZW50KGNvbnRhaW5lcikgJiYgY29udGFpbmVyLnNoYWRvd1Jvb3QpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbShjb250YWluZXIuc2hhZG93Um9vdC5jaGlsZHJlbik7XG4gIH1cbiAgcmV0dXJuIEFycmF5LmZyb20oY29udGFpbmVyLmNoaWxkcmVuKTtcbn1cbmZ1bmN0aW9uIGFwcGVuZENhbmRpZGF0ZXMoY29udGFpbmVyLCBsaXN0KSB7XG4gIGdldENvbXBvc2VkQ2hpbGRyZW4oY29udGFpbmVyKS5mb3JFYWNoKGNoaWxkID0+IHtcbiAgICBpZiAoaXNGb2N1c2FibGVDYW5kaWRhdGUoY2hpbGQpKSB7XG4gICAgICBsaXN0LnB1c2goY2hpbGQpO1xuICAgIH1cbiAgICBhcHBlbmRDYW5kaWRhdGVzKGNoaWxkLCBsaXN0KTtcbiAgfSk7XG59XG5mdW5jdGlvbiBhcHBlbmRNYXRjaGluZ0VsZW1lbnRzKGNvbnRhaW5lciwgc2VsZWN0b3IsIGxpc3QpIHtcbiAgZ2V0Q29tcG9zZWRDaGlsZHJlbihjb250YWluZXIpLmZvckVhY2goY2hpbGQgPT4ge1xuICAgIGlmIChpc0hUTUxFbGVtZW50KGNoaWxkKSAmJiBjaGlsZC5tYXRjaGVzKHNlbGVjdG9yKSkge1xuICAgICAgbGlzdC5wdXNoKGNoaWxkKTtcbiAgICB9XG4gICAgYXBwZW5kTWF0Y2hpbmdFbGVtZW50cyhjaGlsZCwgc2VsZWN0b3IsIGxpc3QpO1xuICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1RhYmJhYmxlKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzRm9jdXNhYmxlRWxlbWVudChlbGVtZW50KSAmJiBnZXRUYWJJbmRleChlbGVtZW50KSA+PSAwO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZvY3VzYWJsZShjb250YWluZXIpIHtcbiAgY29uc3QgY2FuZGlkYXRlcyA9IFtdO1xuICBhcHBlbmRDYW5kaWRhdGVzKGNvbnRhaW5lciwgY2FuZGlkYXRlcyk7XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbHRlcihpc0ZvY3VzYWJsZUVsZW1lbnQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHRhYmJhYmxlKGNvbnRhaW5lcikge1xuICBjb25zdCBjYW5kaWRhdGVzID0gZm9jdXNhYmxlKGNvbnRhaW5lcik7XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbHRlcihlbGVtZW50ID0+IGdldFRhYkluZGV4KGVsZW1lbnQpID49IDAgJiYgaXNUYWJiYWJsZVJhZGlvKGVsZW1lbnQsIGNhbmRpZGF0ZXMpKTtcbn1cbmZ1bmN0aW9uIGdldFRhYmJhYmxlSW4oY29udGFpbmVyLCBkaXIpIHtcbiAgY29uc3QgbGlzdCA9IHRhYmJhYmxlKGNvbnRhaW5lcik7XG4gIGNvbnN0IGxlbiA9IGxpc3QubGVuZ3RoO1xuICBpZiAobGVuID09PSAwKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBjb25zdCBhY3RpdmUgPSBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoY29udGFpbmVyKSk7XG4gIGNvbnN0IGluZGV4ID0gbGlzdC5pbmRleE9mKGFjdGl2ZSk7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXN0ZWQtdGVybmFyeVxuICBjb25zdCBuZXh0SW5kZXggPSBpbmRleCA9PT0gLTEgPyBkaXIgPT09IDEgPyAwIDogbGVuIC0gMSA6IGluZGV4ICsgZGlyO1xuICByZXR1cm4gbGlzdFtuZXh0SW5kZXhdO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldE5leHRUYWJiYWJsZShyZWZlcmVuY2VFbGVtZW50KSB7XG4gIHJldHVybiBnZXRUYWJiYWJsZUluKG93bmVyRG9jdW1lbnQocmVmZXJlbmNlRWxlbWVudCkuYm9keSwgMSkgfHwgcmVmZXJlbmNlRWxlbWVudDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRQcmV2aW91c1RhYmJhYmxlKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgcmV0dXJuIGdldFRhYmJhYmxlSW4ob3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KS5ib2R5LCAtMSkgfHwgcmVmZXJlbmNlRWxlbWVudDtcbn1cbmZ1bmN0aW9uIGdldFRhYmJhYmxlTmVhckVsZW1lbnQocmVmZXJlbmNlRWxlbWVudCwgZGlyKSB7XG4gIGlmICghcmVmZXJlbmNlRWxlbWVudCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IGxpc3QgPSB0YWJiYWJsZShvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpLmJvZHkpO1xuICBjb25zdCBlbGVtZW50Q291bnQgPSBsaXN0Lmxlbmd0aDtcbiAgaWYgKGVsZW1lbnRDb3VudCA9PT0gMCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IGluZGV4ID0gbGlzdC5pbmRleE9mKHJlZmVyZW5jZUVsZW1lbnQpO1xuICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgbmV4dEluZGV4ID0gKGluZGV4ICsgZGlyICsgZWxlbWVudENvdW50KSAlIGVsZW1lbnRDb3VudDtcbiAgcmV0dXJuIGxpc3RbbmV4dEluZGV4XTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRUYWJiYWJsZUFmdGVyRWxlbWVudChyZWZlcmVuY2VFbGVtZW50KSB7XG4gIHJldHVybiBnZXRUYWJiYWJsZU5lYXJFbGVtZW50KHJlZmVyZW5jZUVsZW1lbnQsIDEpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldFRhYmJhYmxlQmVmb3JlRWxlbWVudChyZWZlcmVuY2VFbGVtZW50KSB7XG4gIHJldHVybiBnZXRUYWJiYWJsZU5lYXJFbGVtZW50KHJlZmVyZW5jZUVsZW1lbnQsIC0xKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc091dHNpZGVFdmVudChldmVudCwgY29udGFpbmVyKSB7XG4gIGNvbnN0IGNvbnRhaW5lckVsZW1lbnQgPSBjb250YWluZXIgfHwgZXZlbnQuY3VycmVudFRhcmdldDtcbiAgY29uc3QgcmVsYXRlZFRhcmdldCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gIHJldHVybiAhcmVsYXRlZFRhcmdldCB8fCAhY29udGFpbnMoY29udGFpbmVyRWxlbWVudCwgcmVsYXRlZFRhcmdldCk7XG59XG5leHBvcnQgZnVuY3Rpb24gZGlzYWJsZUZvY3VzSW5zaWRlKGNvbnRhaW5lcikge1xuICBjb25zdCB0YWJiYWJsZUVsZW1lbnRzID0gdGFiYmFibGUoY29udGFpbmVyKTtcbiAgdGFiYmFibGVFbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xuICAgIGVsZW1lbnQuZGF0YXNldC50YWJpbmRleCA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKCd0YWJpbmRleCcpIHx8ICcnO1xuICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICctMScpO1xuICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlbmFibGVGb2N1c0luc2lkZShjb250YWluZXIpIHtcbiAgY29uc3QgZWxlbWVudHMgPSBbXTtcbiAgYXBwZW5kTWF0Y2hpbmdFbGVtZW50cyhjb250YWluZXIsICdbZGF0YS10YWJpbmRleF0nLCBlbGVtZW50cyk7XG4gIGVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgY29uc3QgdGFiaW5kZXggPSBlbGVtZW50LmRhdGFzZXQudGFiaW5kZXg7XG4gICAgZGVsZXRlIGVsZW1lbnQuZGF0YXNldC50YWJpbmRleDtcbiAgICBpZiAodGFiaW5kZXgpIHtcbiAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsIHRhYmluZGV4KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoJ3RhYmluZGV4Jyk7XG4gICAgfVxuICB9KTtcbn0iLCIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tbG9vcC1mdW5jICovXG5cbmV4cG9ydCBmdW5jdGlvbiBnZXROb2RlQ2hpbGRyZW4obm9kZXMsIGlkLCBvbmx5T3BlbkNoaWxkcmVuID0gdHJ1ZSkge1xuICBjb25zdCBkaXJlY3RDaGlsZHJlbiA9IG5vZGVzLmZpbHRlcihub2RlID0+IG5vZGUucGFyZW50SWQgPT09IGlkKTtcbiAgcmV0dXJuIGRpcmVjdENoaWxkcmVuLmZsYXRNYXAoY2hpbGQgPT4gWy4uLighb25seU9wZW5DaGlsZHJlbiB8fCBjaGlsZC5jb250ZXh0Py5vcGVuID8gW2NoaWxkXSA6IFtdKSwgLi4uZ2V0Tm9kZUNoaWxkcmVuKG5vZGVzLCBjaGlsZC5pZCwgb25seU9wZW5DaGlsZHJlbildKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXREZWVwZXN0Tm9kZShub2RlcywgaWQpIHtcbiAgbGV0IGRlZXBlc3ROb2RlSWQ7XG4gIGxldCBtYXhEZXB0aCA9IC0xO1xuICBmdW5jdGlvbiBmaW5kRGVlcGVzdChub2RlSWQsIGRlcHRoKSB7XG4gICAgaWYgKGRlcHRoID4gbWF4RGVwdGgpIHtcbiAgICAgIGRlZXBlc3ROb2RlSWQgPSBub2RlSWQ7XG4gICAgICBtYXhEZXB0aCA9IGRlcHRoO1xuICAgIH1cbiAgICBjb25zdCBjaGlsZHJlbiA9IGdldE5vZGVDaGlsZHJlbihub2Rlcywgbm9kZUlkKTtcbiAgICBjaGlsZHJlbi5mb3JFYWNoKGNoaWxkID0+IHtcbiAgICAgIGZpbmREZWVwZXN0KGNoaWxkLmlkLCBkZXB0aCArIDEpO1xuICAgIH0pO1xuICB9XG4gIGZpbmREZWVwZXN0KGlkLCAwKTtcbiAgcmV0dXJuIG5vZGVzLmZpbmQobm9kZSA9PiBub2RlLmlkID09PSBkZWVwZXN0Tm9kZUlkKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXROb2RlQW5jZXN0b3JzKG5vZGVzLCBpZCkge1xuICBsZXQgYWxsQW5jZXN0b3JzID0gW107XG4gIGxldCBjdXJyZW50UGFyZW50SWQgPSBub2Rlcy5maW5kKG5vZGUgPT4gbm9kZS5pZCA9PT0gaWQpPy5wYXJlbnRJZDtcbiAgd2hpbGUgKGN1cnJlbnRQYXJlbnRJZCkge1xuICAgIGNvbnN0IGN1cnJlbnROb2RlID0gbm9kZXMuZmluZChub2RlID0+IG5vZGUuaWQgPT09IGN1cnJlbnRQYXJlbnRJZCk7XG4gICAgY3VycmVudFBhcmVudElkID0gY3VycmVudE5vZGU/LnBhcmVudElkO1xuICAgIGlmIChjdXJyZW50Tm9kZSkge1xuICAgICAgYWxsQW5jZXN0b3JzID0gYWxsQW5jZXN0b3JzLmNvbmNhdChjdXJyZW50Tm9kZSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBhbGxBbmNlc3RvcnM7XG59IiwiZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUF0dHJpYnV0ZShuYW1lKSB7XG4gIHJldHVybiBgZGF0YS1iYXNlLXVpLSR7bmFtZX1gO1xufSIsImltcG9ydCB7IE5PT1AgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5sZXQgcmFmSWQgPSAwO1xuZXhwb3J0IGZ1bmN0aW9uIGVucXVldWVGb2N1cyhlbCwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBwcmV2ZW50U2Nyb2xsID0gZmFsc2UsXG4gICAgc3luYyA9IGZhbHNlLFxuICAgIHNob3VsZEZvY3VzXG4gIH0gPSBvcHRpb25zO1xuICBjYW5jZWxBbmltYXRpb25GcmFtZShyYWZJZCk7XG4gIGZ1bmN0aW9uIGV4ZWMoKSB7XG4gICAgaWYgKHNob3VsZEZvY3VzICYmICFzaG91bGRGb2N1cygpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGVsPy5mb2N1cyh7XG4gICAgICBwcmV2ZW50U2Nyb2xsXG4gICAgfSk7XG4gIH1cbiAgaWYgKHN5bmMpIHtcbiAgICBleGVjKCk7XG4gICAgcmV0dXJuIE5PT1A7XG4gIH1cbiAgY29uc3QgY3VycmVudFJhZklkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGV4ZWMpO1xuICByYWZJZCA9IGN1cnJlbnRSYWZJZDtcbiAgcmV0dXJuICgpID0+IHtcbiAgICBpZiAocmFmSWQgPT09IGN1cnJlbnRSYWZJZCkge1xuICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUoY3VycmVudFJhZklkKTtcbiAgICAgIHJhZklkID0gMDtcbiAgICB9XG4gIH07XG59IiwiLy8gTW9kaWZpZWQgdG8gYWRkIGNvbmRpdGlvbmFsIGBhcmlhLWhpZGRlbmAgc3VwcG9ydDpcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS90aGVLYXNoZXkvYXJpYS1oaWRkZW4vYmxvYi85MjIwYzhmNGE0ZmQzNWY2M2JlZTU1MTBhOWY0MWEzNzI2NDM4MmQ0L3NyYy9pbmRleC50c1xuaW1wb3J0IHsgZ2V0Tm9kZU5hbWUsIGlzU2hhZG93Um9vdCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmNvbnN0IGNvdW50ZXJzID0ge1xuICBpbmVydDogbmV3IFdlYWtNYXAoKSxcbiAgJ2FyaWEtaGlkZGVuJzogbmV3IFdlYWtNYXAoKVxufTtcbmNvbnN0IG1hcmtlck5hbWUgPSAnZGF0YS1iYXNlLXVpLWluZXJ0JztcbmNvbnN0IHVuY29udHJvbGxlZEVsZW1lbnRzU2V0cyA9IHtcbiAgaW5lcnQ6IG5ldyBXZWFrU2V0KCksXG4gICdhcmlhLWhpZGRlbic6IG5ldyBXZWFrU2V0KClcbn07XG5sZXQgbWFya2VyQ291bnRlck1hcCA9IG5ldyBXZWFrTWFwKCk7XG5sZXQgbG9ja0NvdW50ID0gMDtcbmZ1bmN0aW9uIGdldFVuY29udHJvbGxlZEVsZW1lbnRzU2V0KGNvbnRyb2xBdHRyaWJ1dGUpIHtcbiAgcmV0dXJuIHVuY29udHJvbGxlZEVsZW1lbnRzU2V0c1tjb250cm9sQXR0cmlidXRlXTtcbn1cbmZ1bmN0aW9uIHVud3JhcEhvc3Qobm9kZSkge1xuICBpZiAoIW5vZGUpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gaXNTaGFkb3dSb290KG5vZGUpID8gbm9kZS5ob3N0IDogdW53cmFwSG9zdChub2RlLnBhcmVudE5vZGUpO1xufVxuY29uc3QgY29ycmVjdEVsZW1lbnRzID0gKHBhcmVudCwgdGFyZ2V0cykgPT4gdGFyZ2V0cy5tYXAodGFyZ2V0ID0+IHtcbiAgaWYgKHBhcmVudC5jb250YWlucyh0YXJnZXQpKSB7XG4gICAgcmV0dXJuIHRhcmdldDtcbiAgfVxuICBjb25zdCBjb3JyZWN0ZWRUYXJnZXQgPSB1bndyYXBIb3N0KHRhcmdldCk7XG4gIGlmIChwYXJlbnQuY29udGFpbnMoY29ycmVjdGVkVGFyZ2V0KSkge1xuICAgIHJldHVybiBjb3JyZWN0ZWRUYXJnZXQ7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59KS5maWx0ZXIoeCA9PiB4ICE9IG51bGwpO1xuY29uc3QgYnVpbGRLZWVwU2V0ID0gdGFyZ2V0cyA9PiB7XG4gIGNvbnN0IGtlZXAgPSBuZXcgU2V0KCk7XG4gIHRhcmdldHMuZm9yRWFjaCh0YXJnZXQgPT4ge1xuICAgIGxldCBub2RlID0gdGFyZ2V0O1xuICAgIHdoaWxlIChub2RlICYmICFrZWVwLmhhcyhub2RlKSkge1xuICAgICAga2VlcC5hZGQobm9kZSk7XG4gICAgICBub2RlID0gbm9kZS5wYXJlbnROb2RlO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBrZWVwO1xufTtcbmNvbnN0IGNvbGxlY3RPdXRzaWRlRWxlbWVudHMgPSAocm9vdCwga2VlcEVsZW1lbnRzLCBzdG9wRWxlbWVudHMpID0+IHtcbiAgY29uc3Qgb3V0c2lkZSA9IFtdO1xuICBjb25zdCB3YWxrID0gcGFyZW50ID0+IHtcbiAgICBpZiAoIXBhcmVudCB8fCBzdG9wRWxlbWVudHMuaGFzKHBhcmVudCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgQXJyYXkuZnJvbShwYXJlbnQuY2hpbGRyZW4pLmZvckVhY2gobm9kZSA9PiB7XG4gICAgICBpZiAoZ2V0Tm9kZU5hbWUobm9kZSkgPT09ICdzY3JpcHQnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChrZWVwRWxlbWVudHMuaGFzKG5vZGUpKSB7XG4gICAgICAgIHdhbGsobm9kZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvdXRzaWRlLnB1c2gobm9kZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG4gIHdhbGsocm9vdCk7XG4gIHJldHVybiBvdXRzaWRlO1xufTtcbmZ1bmN0aW9uIGFwcGx5QXR0cmlidXRlVG9PdGhlcnModW5jb3JyZWN0ZWRBdm9pZEVsZW1lbnRzLCBib2R5LCBhcmlhSGlkZGVuLCBpbmVydCwge1xuICBtYXJrID0gdHJ1ZVxufSkge1xuICBsZXQgY29udHJvbEF0dHJpYnV0ZSA9IG51bGw7XG4gIGlmIChpbmVydCkge1xuICAgIGNvbnRyb2xBdHRyaWJ1dGUgPSAnaW5lcnQnO1xuICB9IGVsc2UgaWYgKGFyaWFIaWRkZW4pIHtcbiAgICBjb250cm9sQXR0cmlidXRlID0gJ2FyaWEtaGlkZGVuJztcbiAgfVxuICBsZXQgY291bnRlck1hcCA9IG51bGw7XG4gIGxldCB1bmNvbnRyb2xsZWRFbGVtZW50c1NldCA9IG51bGw7XG4gIGNvbnN0IGF2b2lkRWxlbWVudHMgPSBjb3JyZWN0RWxlbWVudHMoYm9keSwgdW5jb3JyZWN0ZWRBdm9pZEVsZW1lbnRzKTtcbiAgY29uc3QgbWFya2VyVGFyZ2V0cyA9IG1hcmsgPyBjb2xsZWN0T3V0c2lkZUVsZW1lbnRzKGJvZHksIGJ1aWxkS2VlcFNldChhdm9pZEVsZW1lbnRzKSwgbmV3IFNldChhdm9pZEVsZW1lbnRzKSkgOiBbXTtcbiAgY29uc3QgaGlkZGVuRWxlbWVudHMgPSBbXTtcbiAgY29uc3QgbWFya2VkRWxlbWVudHMgPSBbXTtcbiAgaWYgKGNvbnRyb2xBdHRyaWJ1dGUpIHtcbiAgICBjb25zdCBtYXAgPSBjb3VudGVyc1tjb250cm9sQXR0cmlidXRlXTtcbiAgICBjb25zdCBjdXJyZW50VW5jb250cm9sbGVkRWxlbWVudHNTZXQgPSBnZXRVbmNvbnRyb2xsZWRFbGVtZW50c1NldChjb250cm9sQXR0cmlidXRlKTtcbiAgICB1bmNvbnRyb2xsZWRFbGVtZW50c1NldCA9IGN1cnJlbnRVbmNvbnRyb2xsZWRFbGVtZW50c1NldDtcbiAgICBjb3VudGVyTWFwID0gbWFwO1xuICAgIGNvbnN0IGFyaWFMaXZlRWxlbWVudHMgPSBjb3JyZWN0RWxlbWVudHMoYm9keSwgQXJyYXkuZnJvbShib2R5LnF1ZXJ5U2VsZWN0b3JBbGwoJ1thcmlhLWxpdmVdJykpKTtcbiAgICBjb25zdCBjb250cm9sRWxlbWVudHMgPSBhdm9pZEVsZW1lbnRzLmNvbmNhdChhcmlhTGl2ZUVsZW1lbnRzKTtcbiAgICBjb25zdCBjb250cm9sVGFyZ2V0cyA9IGNvbGxlY3RPdXRzaWRlRWxlbWVudHMoYm9keSwgYnVpbGRLZWVwU2V0KGNvbnRyb2xFbGVtZW50cyksIG5ldyBTZXQoY29udHJvbEVsZW1lbnRzKSk7XG4gICAgY29udHJvbFRhcmdldHMuZm9yRWFjaChub2RlID0+IHtcbiAgICAgIGNvbnN0IGF0dHIgPSBub2RlLmdldEF0dHJpYnV0ZShjb250cm9sQXR0cmlidXRlKTtcbiAgICAgIGNvbnN0IGFscmVhZHlIaWRkZW4gPSBhdHRyICE9PSBudWxsICYmIGF0dHIgIT09ICdmYWxzZSc7XG4gICAgICBjb25zdCBjb3VudGVyVmFsdWUgPSAobWFwLmdldChub2RlKSB8fCAwKSArIDE7XG4gICAgICBtYXAuc2V0KG5vZGUsIGNvdW50ZXJWYWx1ZSk7XG4gICAgICBoaWRkZW5FbGVtZW50cy5wdXNoKG5vZGUpO1xuICAgICAgaWYgKGNvdW50ZXJWYWx1ZSA9PT0gMSAmJiBhbHJlYWR5SGlkZGVuKSB7XG4gICAgICAgIGN1cnJlbnRVbmNvbnRyb2xsZWRFbGVtZW50c1NldC5hZGQobm9kZSk7XG4gICAgICB9XG4gICAgICBpZiAoIWFscmVhZHlIaWRkZW4pIHtcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoY29udHJvbEF0dHJpYnV0ZSwgY29udHJvbEF0dHJpYnV0ZSA9PT0gJ2luZXJ0JyA/ICcnIDogJ3RydWUnKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBpZiAobWFyaykge1xuICAgIG1hcmtlclRhcmdldHMuZm9yRWFjaChub2RlID0+IHtcbiAgICAgIGNvbnN0IG1hcmtlclZhbHVlID0gKG1hcmtlckNvdW50ZXJNYXAuZ2V0KG5vZGUpIHx8IDApICsgMTtcbiAgICAgIG1hcmtlckNvdW50ZXJNYXAuc2V0KG5vZGUsIG1hcmtlclZhbHVlKTtcbiAgICAgIG1hcmtlZEVsZW1lbnRzLnB1c2gobm9kZSk7XG4gICAgICBpZiAobWFya2VyVmFsdWUgPT09IDEpIHtcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUobWFya2VyTmFtZSwgJycpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIGxvY2tDb3VudCArPSAxO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGlmIChjb3VudGVyTWFwKSB7XG4gICAgICBoaWRkZW5FbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xuICAgICAgICBjb25zdCBjdXJyZW50Q291bnRlclZhbHVlID0gY291bnRlck1hcC5nZXQoZWxlbWVudCkgfHwgMDtcbiAgICAgICAgY29uc3QgY291bnRlclZhbHVlID0gY3VycmVudENvdW50ZXJWYWx1ZSAtIDE7XG4gICAgICAgIGNvdW50ZXJNYXAuc2V0KGVsZW1lbnQsIGNvdW50ZXJWYWx1ZSk7XG4gICAgICAgIGlmICghY291bnRlclZhbHVlKSB7XG4gICAgICAgICAgaWYgKCF1bmNvbnRyb2xsZWRFbGVtZW50c1NldD8uaGFzKGVsZW1lbnQpICYmIGNvbnRyb2xBdHRyaWJ1dGUpIHtcbiAgICAgICAgICAgIGVsZW1lbnQucmVtb3ZlQXR0cmlidXRlKGNvbnRyb2xBdHRyaWJ1dGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB1bmNvbnRyb2xsZWRFbGVtZW50c1NldD8uZGVsZXRlKGVsZW1lbnQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG1hcmspIHtcbiAgICAgIG1hcmtlZEVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICAgIGNvbnN0IG1hcmtlclZhbHVlID0gKG1hcmtlckNvdW50ZXJNYXAuZ2V0KGVsZW1lbnQpIHx8IDApIC0gMTtcbiAgICAgICAgbWFya2VyQ291bnRlck1hcC5zZXQoZWxlbWVudCwgbWFya2VyVmFsdWUpO1xuICAgICAgICBpZiAoIW1hcmtlclZhbHVlKSB7XG4gICAgICAgICAgZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUobWFya2VyTmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBsb2NrQ291bnQgLT0gMTtcbiAgICBpZiAoIWxvY2tDb3VudCkge1xuICAgICAgY291bnRlcnMuaW5lcnQgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgY291bnRlcnNbJ2FyaWEtaGlkZGVuJ10gPSBuZXcgV2Vha01hcCgpO1xuICAgICAgdW5jb250cm9sbGVkRWxlbWVudHNTZXRzLmluZXJ0ID0gbmV3IFdlYWtTZXQoKTtcbiAgICAgIHVuY29udHJvbGxlZEVsZW1lbnRzU2V0c1snYXJpYS1oaWRkZW4nXSA9IG5ldyBXZWFrU2V0KCk7XG4gICAgICBtYXJrZXJDb3VudGVyTWFwID0gbmV3IFdlYWtNYXAoKTtcbiAgICB9XG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gbWFya090aGVycyhhdm9pZEVsZW1lbnRzLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGFyaWFIaWRkZW4gPSBmYWxzZSxcbiAgICBpbmVydCA9IGZhbHNlLFxuICAgIG1hcmsgPSB0cnVlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBib2R5ID0gb3duZXJEb2N1bWVudChhdm9pZEVsZW1lbnRzWzBdKS5ib2R5O1xuICByZXR1cm4gYXBwbHlBdHRyaWJ1dGVUb090aGVycyhhdm9pZEVsZW1lbnRzLCBib2R5LCBhcmlhSGlkZGVuLCBpbmVydCwge1xuICAgIG1hcmtcbiAgfSk7XG59IiwiZXhwb3J0IGNvbnN0IFRZUEVBSEVBRF9SRVNFVF9NUyA9IDUwMDtcbmV4cG9ydCBjb25zdCBQQVRJRU5UX0NMSUNLX1RIUkVTSE9MRCA9IDUwMDtcbmV4cG9ydCBjb25zdCBESVNBQkxFRF9UUkFOU0lUSU9OU19TVFlMRSA9IHtcbiAgc3R5bGU6IHtcbiAgICB0cmFuc2l0aW9uOiAnbm9uZSdcbiAgfVxufTtcbmV4cG9ydCBjb25zdCBDTElDS19UUklHR0VSX0lERU5USUZJRVIgPSAnZGF0YS1iYXNlLXVpLWNsaWNrLXRyaWdnZXInO1xuZXhwb3J0IGNvbnN0IEJBU0VfVUlfU1dJUEVfSUdOT1JFX0FUVFJJQlVURSA9ICdkYXRhLWJhc2UtdWktc3dpcGUtaWdub3JlJztcbmV4cG9ydCBjb25zdCBMRUdBQ1lfU1dJUEVfSUdOT1JFX0FUVFJJQlVURSA9ICdkYXRhLXN3aXBlLWlnbm9yZSc7XG5leHBvcnQgY29uc3QgQkFTRV9VSV9TV0lQRV9JR05PUkVfU0VMRUNUT1IgPSBgWyR7QkFTRV9VSV9TV0lQRV9JR05PUkVfQVRUUklCVVRFfV1gO1xuZXhwb3J0IGNvbnN0IExFR0FDWV9TV0lQRV9JR05PUkVfU0VMRUNUT1IgPSBgWyR7TEVHQUNZX1NXSVBFX0lHTk9SRV9BVFRSSUJVVEV9XWA7XG5cbi8qKlxuICogVXNlZCBmb3IgZHJvcGRvd25zIHRoYXQgdXN1YWxseSBzdHJpY3RseSBwcmVmZXIgdG9wL2JvdHRvbSBwbGFjZW1lbnRzIGFuZFxuICogdXNlIGB2YXIoLS1hdmFpbGFibGUtaGVpZ2h0KWAgdG8gbGltaXQgdGhlaXIgaGVpZ2h0LlxuICovXG5leHBvcnQgY29uc3QgRFJPUERPV05fQ09MTElTSU9OX0FWT0lEQU5DRSA9IHtcbiAgZmFsbGJhY2tBeGlzU2lkZTogJ25vbmUnXG59O1xuXG4vKipcbiAqIFVzZWQgYnkgcmVndWxhciBwb3B1cHMgdGhhdCB1c3VhbGx5IGFyZW4ndCBzY3JvbGxhYmxlIGFuZCBhcmUgYWxsb3dlZCB0b1xuICogZnJlZWx5IGZsaXAgdG8gYW55IGF4aXMgb2YgcGxhY2VtZW50LlxuICovXG5leHBvcnQgY29uc3QgUE9QVVBfQ09MTElTSU9OX0FWT0lEQU5DRSA9IHtcbiAgZmFsbGJhY2tBeGlzU2lkZTogJ2VuZCdcbn07XG5cbi8qKlxuICogU3BlY2lhbCB2aXN1YWxseSBoaWRkZW4gc3R5bGVzIGZvciB0aGUgYXJpYS1vd25zIG93bmVyIGVsZW1lbnQgdG8gZW5zdXJlIG93bmVkIGVsZW1lbnRcbiAqIGFjY2Vzc2liaWxpdHkgaW4gaU9TL1NhZmFyaS9Wb2ljZUNvbnRyb2wuXG4gKiBUaGUgb3duZXIgZWxlbWVudCBpcyBhbiBlbXB0eSBzcGFuLCBzbyBtb3N0IG9mIHRoZSBjb21tb24gdmlzdWFsbHkgaGlkZGVuIHN0eWxlcyBhcmUgbm90IG5lZWRlZC5cbiAqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8zNDAzXG4gKi9cbmV4cG9ydCBjb25zdCBvd25lclZpc3VhbGx5SGlkZGVuID0ge1xuICBjbGlwUGF0aDogJ2luc2V0KDUwJSknLFxuICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgdG9wOiAwLFxuICBsZWZ0OiAwXG59OyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IGlzTm9kZSB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgYWRkRXZlbnRMaXN0ZW5lciB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2FkZEV2ZW50TGlzdGVuZXInO1xuaW1wb3J0IHsgbWVyZ2VDbGVhbnVwcyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL21lcmdlQ2xlYW51cHMnO1xuaW1wb3J0IHsgdXNlSWQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJZCc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBGb2N1c0d1YXJkIH0gZnJvbSBcIi4uLy4uL3V0aWxzL0ZvY3VzR3VhcmQubWpzXCI7XG5pbXBvcnQgeyBlbmFibGVGb2N1c0luc2lkZSwgZGlzYWJsZUZvY3VzSW5zaWRlLCBnZXRQcmV2aW91c1RhYmJhYmxlLCBnZXROZXh0VGFiYmFibGUsIGlzT3V0c2lkZUV2ZW50IH0gZnJvbSBcIi4uL3V0aWxzL3RhYmJhYmxlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQXR0cmlidXRlIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUF0dHJpYnV0ZS5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBvd25lclZpc3VhbGx5SGlkZGVuIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCwganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuY29uc3QgUG9ydGFsQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgUG9ydGFsQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiUG9ydGFsQ29udGV4dFwiO1xuZXhwb3J0IGNvbnN0IHVzZVBvcnRhbENvbnRleHQgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KFBvcnRhbENvbnRleHQpO1xuY29uc3QgYXR0ciA9IGNyZWF0ZUF0dHJpYnV0ZSgncG9ydGFsJyk7XG5leHBvcnQgZnVuY3Rpb24gdXNlRmxvYXRpbmdQb3J0YWxOb2RlKHByb3BzID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHJlZixcbiAgICBjb250YWluZXI6IGNvbnRhaW5lclByb3AsXG4gICAgY29tcG9uZW50UHJvcHMgPSBFTVBUWV9PQkpFQ1QsXG4gICAgZWxlbWVudFByb3BzXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgdW5pcXVlSWQgPSB1c2VJZCgpO1xuICBjb25zdCBwb3J0YWxDb250ZXh0ID0gdXNlUG9ydGFsQ29udGV4dCgpO1xuICBjb25zdCBwYXJlbnRQb3J0YWxOb2RlID0gcG9ydGFsQ29udGV4dD8ucG9ydGFsTm9kZTtcbiAgY29uc3QgW2NvbnRhaW5lckVsZW1lbnQsIHNldENvbnRhaW5lckVsZW1lbnRdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtwb3J0YWxOb2RlLCBzZXRQb3J0YWxOb2RlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBzZXRQb3J0YWxOb2RlUmVmID0gdXNlU3RhYmxlQ2FsbGJhY2sobm9kZSA9PiB7XG4gICAgaWYgKG5vZGUgIT09IG51bGwpIHtcbiAgICAgIC8vIHRoZSB1c2VJc29MYXlvdXRFZmZlY3QgYmVsb3cgd2F0Y2hpbmcgY29udGFpbmVyUHJvcCAvIHBhcmVudFBvcnRhbE5vZGVcbiAgICAgIC8vIHNldHMgc2V0UG9ydGFsTm9kZShudWxsKSB3aGVuIHRoZSBjb250YWluZXIgYmVjb21lcyBudWxsIG9yIGNoYW5nZXMuXG4gICAgICAvLyBTbyBldmVuIHRob3VnaCB0aGUgcmVmIGNhbGxiYWNrIG5vdyBpZ25vcmVzIG51bGwsIHRoZSBwb3J0YWwgbm9kZSBzdGlsbCBnZXRzIGNsZWFyZWQuXG4gICAgICBzZXRQb3J0YWxOb2RlKG5vZGUpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGNvbnRhaW5lclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAvLyBXYWl0IGZvciB0aGUgY29udGFpbmVyIHRvIGJlIHJlc29sdmVkIGlmIGV4cGxpY2l0bHkgYG51bGxgLlxuICAgIGlmIChjb250YWluZXJQcm9wID09PSBudWxsKSB7XG4gICAgICBpZiAoY29udGFpbmVyUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29udGFpbmVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBzZXRQb3J0YWxOb2RlKG51bGwpO1xuICAgICAgICBzZXRDb250YWluZXJFbGVtZW50KG51bGwpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCByZXNvbHZlZENvbnRhaW5lciA9IChjb250YWluZXJQcm9wICYmIChpc05vZGUoY29udGFpbmVyUHJvcCkgPyBjb250YWluZXJQcm9wIDogY29udGFpbmVyUHJvcC5jdXJyZW50KSkgPz8gcGFyZW50UG9ydGFsTm9kZSA/PyBkb2N1bWVudC5ib2R5O1xuICAgIGlmIChyZXNvbHZlZENvbnRhaW5lciA9PSBudWxsKSB7XG4gICAgICBpZiAoY29udGFpbmVyUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29udGFpbmVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBzZXRQb3J0YWxOb2RlKG51bGwpO1xuICAgICAgICBzZXRDb250YWluZXJFbGVtZW50KG51bGwpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY29udGFpbmVyUmVmLmN1cnJlbnQgIT09IHJlc29sdmVkQ29udGFpbmVyKSB7XG4gICAgICBjb250YWluZXJSZWYuY3VycmVudCA9IHJlc29sdmVkQ29udGFpbmVyO1xuICAgICAgc2V0UG9ydGFsTm9kZShudWxsKTtcbiAgICAgIHNldENvbnRhaW5lckVsZW1lbnQocmVzb2x2ZWRDb250YWluZXIpO1xuICAgIH1cbiAgfSwgW2NvbnRhaW5lclByb3AsIHBhcmVudFBvcnRhbE5vZGVdKTtcbiAgY29uc3QgcG9ydGFsRWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbcmVmLCBzZXRQb3J0YWxOb2RlUmVmXSxcbiAgICBwcm9wczogW3tcbiAgICAgIGlkOiB1bmlxdWVJZCxcbiAgICAgIFthdHRyXTogJydcbiAgICB9LCBlbGVtZW50UHJvcHNdXG4gIH0pO1xuXG4gIC8vIFRoaXMgYGNyZWF0ZVBvcnRhbGAgY2FsbCBpbmplY3RzIGBwb3J0YWxFbGVtZW50YCBpbnRvIHRoZSBgY29udGFpbmVyYC5cbiAgLy8gQW5vdGhlciBjYWxsIGluc2lkZSBgRmxvYXRpbmdQb3J0YWxgL2BGbG9hdGluZ1BvcnRhbExpdGVgIHRoZW4gaW5qZWN0cyB0aGUgY2hpbGRyZW4gaW50byBgcG9ydGFsRWxlbWVudGAuXG4gIGNvbnN0IHBvcnRhbFN1YnRyZWUgPSBjb250YWluZXJFbGVtZW50ICYmIHBvcnRhbEVsZW1lbnQgPyAvKiNfX1BVUkVfXyovUmVhY3RET00uY3JlYXRlUG9ydGFsKHBvcnRhbEVsZW1lbnQsIGNvbnRhaW5lckVsZW1lbnQpIDogbnVsbDtcbiAgcmV0dXJuIHtcbiAgICBub2RlOiBwb3J0YWxOb2RlLFxuICAgIC8vIGBpZGAgYW5kIGByZW5kZXJgIHByb3BzIGNhbiBvdmVycmlkZSBvciByZW1vdmUgdGhlIGdlbmVyYXRlZCBJRC4gVXNlIHRoZSBleGFjdFxuICAgIC8vIHJlbmRlcmVkIHZhbHVlIHNvIGBhcmlhLW93bnNgIG5ldmVyIHBvaW50cyBhdCBhbiBJRCBhYnNlbnQgZnJvbSB0aGUgRE9NLlxuICAgIG5vZGVJZDogLyojX19QVVJFX18qL1JlYWN0LmlzVmFsaWRFbGVtZW50KHBvcnRhbEVsZW1lbnQpID8gcG9ydGFsRWxlbWVudC5wcm9wcy5pZCA6IHVuZGVmaW5lZCxcbiAgICBzdWJ0cmVlOiBwb3J0YWxTdWJ0cmVlXG4gIH07XG59XG5cbi8qKlxuICogUG9ydGFscyB0aGUgZmxvYXRpbmcgZWxlbWVudCBpbnRvIGEgZ2l2ZW4gY29udGFpbmVyIGVsZW1lbnQg4oCUIGJ5IGRlZmF1bHQsXG4gKiBvdXRzaWRlIG9mIHRoZSBhcHAgcm9vdCBhbmQgaW50byB0aGUgYm9keS5cbiAqIFRoaXMgaXMgbmVjZXNzYXJ5IHRvIGVuc3VyZSB0aGUgZmxvYXRpbmcgZWxlbWVudCBjYW4gYXBwZWFyIG91dHNpZGUgYW55XG4gKiBwb3RlbnRpYWwgcGFyZW50IGNvbnRhaW5lcnMgdGhhdCBjYXVzZSBjbGlwcGluZyAoc3VjaCBhcyBgb3ZlcmZsb3c6IGhpZGRlbmApLFxuICogd2hpbGUgcmV0YWluaW5nIGl0cyBsb2NhdGlvbiBpbiB0aGUgUmVhY3QgdHJlZS5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ1BvcnRhbFxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjb25zdCBGbG9hdGluZ1BvcnRhbCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZsb2F0aW5nUG9ydGFsKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgY2hpbGRyZW4sXG4gICAgY29udGFpbmVyLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHtcbiAgICBub2RlOiBwb3J0YWxOb2RlLFxuICAgIG5vZGVJZDogcG9ydGFsTm9kZUlkLFxuICAgIHN1YnRyZWU6IHBvcnRhbFN1YnRyZWVcbiAgfSA9IHVzZUZsb2F0aW5nUG9ydGFsTm9kZSh7XG4gICAgY29udGFpbmVyLFxuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIGNvbXBvbmVudFByb3BzLFxuICAgIGVsZW1lbnRQcm9wc1xuICB9KTtcbiAgY29uc3QgYmVmb3JlT3V0c2lkZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgYWZ0ZXJPdXRzaWRlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBiZWZvcmVJbnNpZGVSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGFmdGVySW5zaWRlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBbZm9jdXNNYW5hZ2VyU3RhdGUsIHNldEZvY3VzTWFuYWdlclN0YXRlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBmb2N1c0luc2lkZURpc2FibGVkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgbW9kYWwgPSBmb2N1c01hbmFnZXJTdGF0ZT8ubW9kYWw7XG4gIGNvbnN0IG9wZW4gPSBmb2N1c01hbmFnZXJTdGF0ZT8ub3BlbjtcbiAgY29uc3Qgc2hvdWxkUmVuZGVyR3VhcmRzID0gISFmb2N1c01hbmFnZXJTdGF0ZSAmJiAhZm9jdXNNYW5hZ2VyU3RhdGUubW9kYWwgJiYgZm9jdXNNYW5hZ2VyU3RhdGUub3BlbiAmJiAhIXBvcnRhbE5vZGU7XG5cbiAgLy8gaHR0cHM6Ly9jb2Rlc2FuZGJveC5pby9zL3RhYmJhYmxlLXBvcnRhbC1mNHRuZz9maWxlPS9zcmMvVGFiYmFibGVQb3J0YWwudHN4XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwb3J0YWxOb2RlIHx8IG1vZGFsKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8vIE1ha2Ugc3VyZSBlbGVtZW50cyBpbnNpZGUgdGhlIHBvcnRhbCBlbGVtZW50IGFyZSB0YWJiYWJsZSBvbmx5IHdoZW4gdGhlXG4gICAgLy8gcG9ydGFsIGhhcyBhbHJlYWR5IGJlZW4gZm9jdXNlZCwgZWl0aGVyIGJ5IHRhYmJpbmcgaW50byBhIGZvY3VzIHRyYXBcbiAgICAvLyBlbGVtZW50IG91dHNpZGUgb3IgdXNpbmcgdGhlIG1vdXNlLlxuICAgIGZ1bmN0aW9uIG9uRm9jdXMoZXZlbnQpIHtcbiAgICAgIGlmIChwb3J0YWxOb2RlICYmIGV2ZW50LnJlbGF0ZWRUYXJnZXQgJiYgaXNPdXRzaWRlRXZlbnQoZXZlbnQpKSB7XG4gICAgICAgIGlmIChldmVudC50eXBlID09PSAnZm9jdXNpbicpIHtcbiAgICAgICAgICBpZiAoZm9jdXNJbnNpZGVEaXNhYmxlZFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBlbmFibGVGb2N1c0luc2lkZShwb3J0YWxOb2RlKTtcbiAgICAgICAgICAgIGZvY3VzSW5zaWRlRGlzYWJsZWRSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBkaXNhYmxlRm9jdXNJbnNpZGUocG9ydGFsTm9kZSk7XG4gICAgICAgICAgZm9jdXNJbnNpZGVEaXNhYmxlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIExpc3RlbiB0byB0aGUgZXZlbnQgb24gdGhlIGNhcHR1cmUgcGhhc2Ugc28gdGhleSBydW4gYmVmb3JlIHRoZSBmb2N1c1xuICAgIC8vIHRyYXAgZWxlbWVudHMgb25Gb2N1cyBwcm9wIGlzIGNhbGxlZC5cbiAgICByZXR1cm4gbWVyZ2VDbGVhbnVwcyhhZGRFdmVudExpc3RlbmVyKHBvcnRhbE5vZGUsICdmb2N1c2luJywgb25Gb2N1cywgdHJ1ZSksIGFkZEV2ZW50TGlzdGVuZXIocG9ydGFsTm9kZSwgJ2ZvY3Vzb3V0Jywgb25Gb2N1cywgdHJ1ZSkpO1xuICB9LCBbcG9ydGFsTm9kZSwgbW9kYWxdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBvcnRhbE5vZGUgfHwgb3BlbiAhPT0gdHJ1ZSB8fCAhZm9jdXNJbnNpZGVEaXNhYmxlZFJlZi5jdXJyZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gUmVzdG9yZSB0YWJiYWJpbGl0eSBiZWZvcmUgdGhlIGZvY3VzIG1hbmFnZXIncyBxdWV1ZWQgZm9jdXMtb24tb3BlbiBzdGVwIHJ1bnMuXG4gICAgZW5hYmxlRm9jdXNJbnNpZGUocG9ydGFsTm9kZSk7XG4gICAgZm9jdXNJbnNpZGVEaXNhYmxlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gIH0sIFtvcGVuLCBwb3J0YWxOb2RlXSk7XG4gIGNvbnN0IHBvcnRhbENvbnRleHRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBiZWZvcmVPdXRzaWRlUmVmLFxuICAgIGFmdGVyT3V0c2lkZVJlZixcbiAgICBiZWZvcmVJbnNpZGVSZWYsXG4gICAgYWZ0ZXJJbnNpZGVSZWYsXG4gICAgcG9ydGFsTm9kZSxcbiAgICBzZXRGb2N1c01hbmFnZXJTdGF0ZVxuICB9KSwgW3BvcnRhbE5vZGVdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhSZWFjdC5GcmFnbWVudCwge1xuICAgIGNoaWxkcmVuOiBbcG9ydGFsU3VidHJlZSwgLyojX19QVVJFX18qL19qc3hzKFBvcnRhbENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICAgIHZhbHVlOiBwb3J0YWxDb250ZXh0VmFsdWUsXG4gICAgICBjaGlsZHJlbjogW3Nob3VsZFJlbmRlckd1YXJkcyAmJiBwb3J0YWxOb2RlICYmIC8qI19fUFVSRV9fKi9fanN4KEZvY3VzR3VhcmQsIHtcbiAgICAgICAgXCJkYXRhLXR5cGVcIjogXCJvdXRzaWRlXCIsXG4gICAgICAgIHJlZjogYmVmb3JlT3V0c2lkZVJlZixcbiAgICAgICAgb25Gb2N1czogZXZlbnQgPT4ge1xuICAgICAgICAgIGlmIChpc091dHNpZGVFdmVudChldmVudCwgcG9ydGFsTm9kZSkpIHtcbiAgICAgICAgICAgIGJlZm9yZUluc2lkZVJlZi5jdXJyZW50Py5mb2N1cygpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBkb21SZWZlcmVuY2UgPSBmb2N1c01hbmFnZXJTdGF0ZSA/IGZvY3VzTWFuYWdlclN0YXRlLmRvbVJlZmVyZW5jZSA6IG51bGw7XG4gICAgICAgICAgICBjb25zdCBwcmV2VGFiYmFibGUgPSBnZXRQcmV2aW91c1RhYmJhYmxlKGRvbVJlZmVyZW5jZSk7XG4gICAgICAgICAgICBwcmV2VGFiYmFibGU/LmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KSwgc2hvdWxkUmVuZGVyR3VhcmRzICYmIHBvcnRhbE5vZGUgJiYgLyojX19QVVJFX18qL19qc3goXCJzcGFuXCIsIHtcbiAgICAgICAgXCJhcmlhLW93bnNcIjogcG9ydGFsTm9kZUlkLFxuICAgICAgICBzdHlsZTogb3duZXJWaXN1YWxseUhpZGRlblxuICAgICAgfSksIHBvcnRhbE5vZGUgJiYgLyojX19QVVJFX18qL1JlYWN0RE9NLmNyZWF0ZVBvcnRhbChjaGlsZHJlbiwgcG9ydGFsTm9kZSksIHNob3VsZFJlbmRlckd1YXJkcyAmJiBwb3J0YWxOb2RlICYmIC8qI19fUFVSRV9fKi9fanN4KEZvY3VzR3VhcmQsIHtcbiAgICAgICAgXCJkYXRhLXR5cGVcIjogXCJvdXRzaWRlXCIsXG4gICAgICAgIHJlZjogYWZ0ZXJPdXRzaWRlUmVmLFxuICAgICAgICBvbkZvY3VzOiBldmVudCA9PiB7XG4gICAgICAgICAgaWYgKGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3J0YWxOb2RlKSkge1xuICAgICAgICAgICAgYWZ0ZXJJbnNpZGVSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZG9tUmVmZXJlbmNlID0gZm9jdXNNYW5hZ2VyU3RhdGUgPyBmb2N1c01hbmFnZXJTdGF0ZS5kb21SZWZlcmVuY2UgOiBudWxsO1xuICAgICAgICAgICAgY29uc3QgbmV4dFRhYmJhYmxlID0gZ2V0TmV4dFRhYmJhYmxlKGRvbVJlZmVyZW5jZSk7XG4gICAgICAgICAgICBuZXh0VGFiYmFibGU/LmZvY3VzKCk7XG4gICAgICAgICAgICBpZiAoZm9jdXNNYW5hZ2VyU3RhdGU/LmNsb3NlT25Gb2N1c091dCkge1xuICAgICAgICAgICAgICBmb2N1c01hbmFnZXJTdGF0ZT8ub25PcGVuQ2hhbmdlKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5mb2N1c091dCwgZXZlbnQubmF0aXZlRXZlbnQpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pXVxuICAgIH0pXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmxvYXRpbmdQb3J0YWwuZGlzcGxheU5hbWUgPSBcIkZsb2F0aW5nUG9ydGFsXCI7IiwiZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUV2ZW50RW1pdHRlcigpIHtcbiAgY29uc3QgbWFwID0gbmV3IE1hcCgpO1xuICByZXR1cm4ge1xuICAgIGVtaXQoZXZlbnQsIGRhdGEpIHtcbiAgICAgIG1hcC5nZXQoZXZlbnQpPy5mb3JFYWNoKGxpc3RlbmVyID0+IGxpc3RlbmVyKGRhdGEpKTtcbiAgICB9LFxuICAgIG9uKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgICAgaWYgKCFtYXAuaGFzKGV2ZW50KSkge1xuICAgICAgICBtYXAuc2V0KGV2ZW50LCBuZXcgU2V0KCkpO1xuICAgICAgfVxuICAgICAgbWFwLmdldChldmVudCkuYWRkKGxpc3RlbmVyKTtcbiAgICB9LFxuICAgIG9mZihldmVudCwgbGlzdGVuZXIpIHtcbiAgICAgIG1hcC5nZXQoZXZlbnQpPy5kZWxldGUobGlzdGVuZXIpO1xuICAgIH1cbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSWQnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlUmVmV2l0aEluaXQnO1xuaW1wb3J0IHsgRmxvYXRpbmdUcmVlU3RvcmUgfSBmcm9tIFwiLi9GbG9hdGluZ1RyZWVTdG9yZS5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBGbG9hdGluZ05vZGVDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGbG9hdGluZ05vZGVDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJGbG9hdGluZ05vZGVDb250ZXh0XCI7XG5jb25zdCBGbG9hdGluZ1RyZWVDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5cbi8qKlxuICogUmV0dXJucyB0aGUgcGFyZW50IG5vZGUgaWQgZm9yIG5lc3RlZCBmbG9hdGluZyBlbGVtZW50cywgaWYgYXZhaWxhYmxlLlxuICogUmV0dXJucyBgbnVsbGAgZm9yIHRvcC1sZXZlbCBmbG9hdGluZyBlbGVtZW50cy5cbiAqL1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmxvYXRpbmdUcmVlQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRmxvYXRpbmdUcmVlQ29udGV4dFwiO1xuZXhwb3J0IGNvbnN0IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChGbG9hdGluZ05vZGVDb250ZXh0KT8uaWQgfHwgbnVsbDtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBuZWFyZXN0IGZsb2F0aW5nIHRyZWUgY29udGV4dCwgaWYgYXZhaWxhYmxlLlxuICovXG5leHBvcnQgY29uc3QgdXNlRmxvYXRpbmdUcmVlID0gZXh0ZXJuYWxUcmVlID0+IHtcbiAgY29uc3QgY29udGV4dFRyZWUgPSBSZWFjdC51c2VDb250ZXh0KEZsb2F0aW5nVHJlZUNvbnRleHQpO1xuICByZXR1cm4gZXh0ZXJuYWxUcmVlID8/IGNvbnRleHRUcmVlO1xufTtcblxuLyoqXG4gKiBSZWdpc3RlcnMgYSBub2RlIGludG8gdGhlIGBGbG9hdGluZ1RyZWVgLCByZXR1cm5pbmcgaXRzIGlkLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nVHJlZVxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRmxvYXRpbmdOb2RlSWQoZXh0ZXJuYWxUcmVlKSB7XG4gIGNvbnN0IGlkID0gdXNlSWQoKTtcbiAgY29uc3QgdHJlZSA9IHVzZUZsb2F0aW5nVHJlZShleHRlcm5hbFRyZWUpO1xuICBjb25zdCBwYXJlbnRJZCA9IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkKCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFpZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3Qgbm9kZSA9IHtcbiAgICAgIGlkLFxuICAgICAgcGFyZW50SWRcbiAgICB9O1xuICAgIHRyZWU/LmFkZE5vZGUobm9kZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRyZWU/LnJlbW92ZU5vZGUobm9kZSk7XG4gICAgfTtcbiAgfSwgW3RyZWUsIGlkLCBwYXJlbnRJZF0pO1xuICByZXR1cm4gaWQ7XG59XG4vKipcbiAqIFByb3ZpZGVzIHBhcmVudCBub2RlIGNvbnRleHQgZm9yIG5lc3RlZCBmbG9hdGluZyBlbGVtZW50cy5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ1RyZWVcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gRmxvYXRpbmdOb2RlKHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbixcbiAgICBpZFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHBhcmVudElkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nTm9kZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgaWQsXG4gICAgICBwYXJlbnRJZFxuICAgIH0pLCBbaWQsIHBhcmVudElkXSksXG4gICAgY2hpbGRyZW46IGNoaWxkcmVuXG4gIH0pO1xufVxuLyoqXG4gKiBQcm92aWRlcyBjb250ZXh0IGZvciBuZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMgd2hlbiB0aGV5IGFyZSBub3QgY2hpbGRyZW4gb2ZcbiAqIGVhY2ggb3RoZXIgb24gdGhlIERPTS5cbiAqIFRoaXMgaXMgbm90IG5lY2Vzc2FyeSBpbiBhbGwgY2FzZXMsIGV4Y2VwdCB3aGVuIHRoZXJlIG11c3QgYmUgZXhwbGljaXQgY29tbXVuaWNhdGlvbiBiZXR3ZWVuIHBhcmVudCBhbmQgY2hpbGQgZmxvYXRpbmcgZWxlbWVudHMuIEl0IGlzIG5lY2Vzc2FyeSBmb3I6XG4gKiAtIFRoZSBgYnViYmxlc2Agb3B0aW9uIGluIHRoZSBgdXNlRGlzbWlzcygpYCBIb29rXG4gKiAtIE5lc3RlZCB2aXJ0dWFsIGxpc3QgbmF2aWdhdGlvblxuICogLSBOZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMgdGhhdCBlYWNoIG9wZW4gb24gaG92ZXJcbiAqIC0gQ3VzdG9tIGNvbW11bmljYXRpb24gYmV0d2VlbiBwYXJlbnQgYW5kIGNoaWxkIGZsb2F0aW5nIGVsZW1lbnRzXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdUcmVlXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZsb2F0aW5nVHJlZShwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgZXh0ZXJuYWxUcmVlXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgdHJlZSA9IHVzZVJlZldpdGhJbml0KCgpID0+IGV4dGVybmFsVHJlZSA/PyBuZXcgRmxvYXRpbmdUcmVlU3RvcmUoKSkuY3VycmVudDtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nVHJlZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdHJlZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW5cbiAgfSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXROb2RlTmFtZSwgaXNIVE1MRWxlbWVudCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgYWRkRXZlbnRMaXN0ZW5lciB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2FkZEV2ZW50TGlzdGVuZXInO1xuaW1wb3J0IHsgbWVyZ2VDbGVhbnVwcyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL21lcmdlQ2xlYW51cHMnO1xuaW1wb3J0IHsgdXNlTWVyZ2VkUmVmcyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZU1lcmdlZFJlZnMnO1xuaW1wb3J0IHsgdXNlVmFsdWVBc1JlZiB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVZhbHVlQXNSZWYnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tICdAYmFzZS11aS91dGlscy9wbGF0Zm9ybSc7XG5pbXBvcnQgeyB1c2VBbmltYXRpb25GcmFtZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUFuaW1hdGlvbkZyYW1lJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQsIG93bmVyV2luZG93IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgRm9jdXNHdWFyZCB9IGZyb20gXCIuLi8uLi91dGlscy9Gb2N1c0d1YXJkLm1qc1wiO1xuaW1wb3J0IHsgYWN0aXZlRWxlbWVudCwgY29udGFpbnMsIGdldFRhcmdldCwgaXNUeXBlYWJsZUNvbWJvYm94LCBnZXRGbG9hdGluZ0ZvY3VzRWxlbWVudCwgaXNUeXBlYWJsZUVsZW1lbnQgfSBmcm9tIFwiLi4vdXRpbHMvZWxlbWVudC5tanNcIjtcbmltcG9ydCB7IGlzVmlydHVhbENsaWNrLCBpc1ZpcnR1YWxQb2ludGVyRXZlbnQsIHN0b3BFdmVudCB9IGZyb20gXCIuLi91dGlscy9ldmVudC5tanNcIjtcbmltcG9ydCB7IHRhYmJhYmxlLCBmb2N1c2FibGUsIGlzT3V0c2lkZUV2ZW50LCBpc1RhYmJhYmxlLCBnZXROZXh0VGFiYmFibGUsIGdldFByZXZpb3VzVGFiYmFibGUgfSBmcm9tIFwiLi4vdXRpbHMvdGFiYmFibGUubWpzXCI7XG5pbXBvcnQgeyBnZXROb2RlQW5jZXN0b3JzLCBnZXROb2RlQ2hpbGRyZW4gfSBmcm9tIFwiLi4vdXRpbHMvbm9kZXMubWpzXCI7XG5pbXBvcnQgeyBpc0VsZW1lbnRWaXNpYmxlIH0gZnJvbSBcIi4uL3V0aWxzL2NvbXBvc2l0ZS5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUF0dHJpYnV0ZSB9IGZyb20gXCIuLi91dGlscy9jcmVhdGVBdHRyaWJ1dGUubWpzXCI7XG5pbXBvcnQgeyBlbnF1ZXVlRm9jdXMgfSBmcm9tIFwiLi4vdXRpbHMvZW5xdWV1ZUZvY3VzLm1qc1wiO1xuaW1wb3J0IHsgbWFya090aGVycyB9IGZyb20gXCIuLi91dGlscy9tYXJrT3RoZXJzLm1qc1wiO1xuaW1wb3J0IHsgdXNlUG9ydGFsQ29udGV4dCB9IGZyb20gXCIuL0Zsb2F0aW5nUG9ydGFsLm1qc1wiO1xuaW1wb3J0IHsgdXNlRmxvYXRpbmdUcmVlIH0gZnJvbSBcIi4vRmxvYXRpbmdUcmVlLm1qc1wiO1xuaW1wb3J0IHsgQ0xJQ0tfVFJJR0dFUl9JREVOVElGSUVSIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyByZXNvbHZlUmVmIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3Jlc29sdmVSZWYubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCwganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZnVuY3Rpb24gZ2V0RXZlbnRUeXBlKGV2ZW50LCBsYXN0SW50ZXJhY3Rpb25UeXBlKSB7XG4gIGNvbnN0IHdpbiA9IG93bmVyV2luZG93KGdldFRhcmdldChldmVudCkpO1xuICBpZiAoZXZlbnQgaW5zdGFuY2VvZiB3aW4uS2V5Ym9hcmRFdmVudCkge1xuICAgIHJldHVybiAna2V5Ym9hcmQnO1xuICB9XG4gIGlmIChldmVudCBpbnN0YW5jZW9mIHdpbi5Gb2N1c0V2ZW50KSB7XG4gICAgLy8gRm9jdXMgZXZlbnRzIGNhbiBiZSBjYXVzZWQgYnkgYSBwcmVjZWRpbmcgcG9pbnRlciBpbnRlcmFjdGlvbiAoZS5nLiwgZm9jdXNvdXQgb24gb3V0c2lkZSBwcmVzcykuXG4gICAgLy8gUHJlZmVyIHRoZSBsYXN0IGtub3duIHBvaW50ZXIgdHlwZSBpZiBwcm92aWRlZCwgZWxzZSB0cmVhdCBhcyBrZXlib2FyZC5cbiAgICByZXR1cm4gbGFzdEludGVyYWN0aW9uVHlwZSB8fCAna2V5Ym9hcmQnO1xuICB9XG4gIGlmICgncG9pbnRlclR5cGUnIGluIGV2ZW50KSB7XG4gICAgcmV0dXJuIGV2ZW50LnBvaW50ZXJUeXBlIHx8ICdrZXlib2FyZCc7XG4gIH1cbiAgaWYgKCd0b3VjaGVzJyBpbiBldmVudCkge1xuICAgIHJldHVybiAndG91Y2gnO1xuICB9XG4gIGlmIChldmVudCBpbnN0YW5jZW9mIHdpbi5Nb3VzZUV2ZW50KSB7XG4gICAgLy8gb25DbGljayBldmVudHMgbWF5IG5vdCBjb250YWluIHBvaW50ZXIgZXZlbnRzLCBhbmQgd2lsbCBmYWxsIHRocm91Z2ggdG8gaGVyZVxuICAgIHJldHVybiBsYXN0SW50ZXJhY3Rpb25UeXBlIHx8IChldmVudC5kZXRhaWwgPT09IDAgPyAna2V5Ym9hcmQnIDogJ21vdXNlJyk7XG4gIH1cbiAgcmV0dXJuICcnO1xufVxuY29uc3QgTElTVF9MSU1JVCA9IDIwO1xubGV0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMgPSBbXTtcbmZ1bmN0aW9uIGNsZWFyRGlzY29ubmVjdGVkUHJldmlvdXNseUZvY3VzZWRFbGVtZW50cygpIHtcbiAgcHJldmlvdXNseUZvY3VzZWRFbGVtZW50cyA9IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMuZmlsdGVyKGVudHJ5ID0+IHtcbiAgICByZXR1cm4gZW50cnkuZGVyZWYoKT8uaXNDb25uZWN0ZWQ7XG4gIH0pO1xufVxuZnVuY3Rpb24gYWRkUHJldmlvdXNseUZvY3VzZWRFbGVtZW50KGVsZW1lbnQpIHtcbiAgY2xlYXJEaXNjb25uZWN0ZWRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzKCk7XG4gIGlmIChlbGVtZW50ICYmIGdldE5vZGVOYW1lKGVsZW1lbnQpICE9PSAnYm9keScpIHtcbiAgICBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLnB1c2gobmV3IFdlYWtSZWYoZWxlbWVudCkpO1xuICAgIGlmIChwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLmxlbmd0aCA+IExJU1RfTElNSVQpIHtcbiAgICAgIHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMgPSBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLnNsaWNlKC1MSVNUX0xJTUlUKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCgpIHtcbiAgY2xlYXJEaXNjb25uZWN0ZWRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzKCk7XG4gIHJldHVybiBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzW3ByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMubGVuZ3RoIC0gMV0/LmRlcmVmKCk7XG59XG5mdW5jdGlvbiBnZXRGaXJzdFRhYmJhYmxlRWxlbWVudChjb250YWluZXIpIHtcbiAgaWYgKCFjb250YWluZXIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoaXNUYWJiYWJsZShjb250YWluZXIpKSB7XG4gICAgcmV0dXJuIGNvbnRhaW5lcjtcbiAgfVxuICByZXR1cm4gdGFiYmFibGUoY29udGFpbmVyKVswXSB8fCBjb250YWluZXI7XG59XG5mdW5jdGlvbiBoYW5kbGVUYWJJbmRleChmbG9hdGluZ0ZvY3VzRWxlbWVudCkge1xuICBpZiAoZmxvYXRpbmdGb2N1c0VsZW1lbnQuaGFzQXR0cmlidXRlKCd0YWJpbmRleCcpICYmICFmbG9hdGluZ0ZvY3VzRWxlbWVudC5oYXNBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnKSkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIWZsb2F0aW5nRm9jdXNFbGVtZW50LmdldEF0dHJpYnV0ZSgncm9sZScpPy5pbmNsdWRlcygnZGlhbG9nJykpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgZm9jdXNhYmxlRWxlbWVudHMgPSBmb2N1c2FibGUoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICBjb25zdCB0YWJiYWJsZUNvbnRlbnQgPSBmb2N1c2FibGVFbGVtZW50cy5maWx0ZXIoZWxlbWVudCA9PiB7XG4gICAgY29uc3QgZGF0YVRhYkluZGV4ID0gZWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnKSB8fCAnJztcbiAgICByZXR1cm4gaXNUYWJiYWJsZShlbGVtZW50KSB8fCBlbGVtZW50Lmhhc0F0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcpICYmICFkYXRhVGFiSW5kZXguc3RhcnRzV2l0aCgnLScpO1xuICB9KTtcbiAgY29uc3QgdGFiSW5kZXggPSBmbG9hdGluZ0ZvY3VzRWxlbWVudC5nZXRBdHRyaWJ1dGUoJ3RhYmluZGV4Jyk7XG4gIGlmICh0YWJiYWJsZUNvbnRlbnQubGVuZ3RoID09PSAwKSB7XG4gICAgaWYgKHRhYkluZGV4ICE9PSAnMCcpIHtcbiAgICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LnNldEF0dHJpYnV0ZSgndGFiaW5kZXgnLCAnMCcpO1xuICAgICAgLy8gTWFyayBvdXIgb3duIHdyaXRlIHNvIHRoZSBleHRlcm5hbGx5LW1hbmFnZWQgZWFybHktcmV0dXJuIGFib3ZlIGRvZXNuJ3RcbiAgICAgIC8vIG1pc3Rha2UgaXQgZm9yIGEgdXNlci1hdXRob3JlZCBgdGFiaW5kZXhgIGFuZCBmcmVlemUgbWFuYWdlbWVudC5cbiAgICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcsICcwJyk7XG4gICAgfVxuICB9IGVsc2UgaWYgKHRhYkluZGV4ICE9PSAnLTEnIHx8IGZsb2F0aW5nRm9jdXNFbGVtZW50Lmhhc0F0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcpICYmIGZsb2F0aW5nRm9jdXNFbGVtZW50LmdldEF0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcpICE9PSAnLTEnKSB7XG4gICAgZmxvYXRpbmdGb2N1c0VsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICctMScpO1xuICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcsICctMScpO1xuICB9XG59XG4vKipcbiAqIFByb3ZpZGVzIGZvY3VzIG1hbmFnZW1lbnQgZm9yIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nRm9jdXNNYW5hZ2VyXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZsb2F0aW5nRm9jdXNNYW5hZ2VyKHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBjb250ZXh0LFxuICAgIGNoaWxkcmVuLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgaW5pdGlhbEZvY3VzID0gdHJ1ZSxcbiAgICByZXR1cm5Gb2N1cyA9IHRydWUsXG4gICAgcmVzdG9yZUZvY3VzID0gZmFsc2UsXG4gICAgbW9kYWwgPSB0cnVlLFxuICAgIGNsb3NlT25Gb2N1c091dCA9IHRydWUsXG4gICAgb3BlbkludGVyYWN0aW9uVHlwZSA9ICcnLFxuICAgIG5leHRGb2N1c2FibGVFbGVtZW50LFxuICAgIHByZXZpb3VzRm9jdXNhYmxlRWxlbWVudCxcbiAgICBiZWZvcmVDb250ZW50Rm9jdXNHdWFyZFJlZixcbiAgICBleHRlcm5hbFRyZWUsXG4gICAgZ2V0SW5zaWRlRWxlbWVudHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCBzdG9yZSA9ICdyb290U3RvcmUnIGluIGNvbnRleHQgPyBjb250ZXh0LnJvb3RTdG9yZSA6IGNvbnRleHQ7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBkb21SZWZlcmVuY2UgPSBzdG9yZS51c2VTdGF0ZSgnZG9tUmVmZXJlbmNlRWxlbWVudCcpO1xuICBjb25zdCBmbG9hdGluZyA9IHN0b3JlLnVzZVN0YXRlKCdmbG9hdGluZ0VsZW1lbnQnKTtcbiAgY29uc3Qge1xuICAgIGV2ZW50cyxcbiAgICBkYXRhUmVmXG4gIH0gPSBzdG9yZS5jb250ZXh0O1xuICBjb25zdCBnZXROb2RlSWQgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiBkYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0Py5ub2RlSWQpO1xuICBjb25zdCBpZ25vcmVJbml0aWFsRm9jdXMgPSBpbml0aWFsRm9jdXMgPT09IGZhbHNlO1xuICAvLyBBIHR5cGVhYmxlIGNvbWJvYm94IHJlZmVyZW5jZSAoZS5nLiBpbnB1dC90ZXh0YXJlYSkgd2l0aCBgaW5pdGlhbEZvY3VzPXtmYWxzZX1gXG4gIC8vIGhhcyBkaWZmZXJlbnQgZm9jdXMgc2VtYW50aWNzOiBmb2N1cyBpcyBub3QgdHJhcHBlZCBpbnNpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQsXG4gIC8vIHNvIGluIHRoZSBtb2RhbCBjYXNlIHRoZSBndWFyZHMgYXJlIG5vdCByZW5kZXJlZCwgYnV0IGBhcmlhLWhpZGRlbmAgaXMgc3RpbGxcbiAgLy8gYXBwbGllZCB0byB0aGUgb3V0c2lkZSBub2Rlcy5cbiAgY29uc3QgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94ID0gaXNUeXBlYWJsZUNvbWJvYm94KGRvbVJlZmVyZW5jZSkgJiYgaWdub3JlSW5pdGlhbEZvY3VzO1xuICBjb25zdCBpbml0aWFsRm9jdXNSZWYgPSB1c2VWYWx1ZUFzUmVmKGluaXRpYWxGb2N1cyk7XG4gIGNvbnN0IHJldHVybkZvY3VzUmVmID0gdXNlVmFsdWVBc1JlZihyZXR1cm5Gb2N1cyk7XG4gIGNvbnN0IG9wZW5JbnRlcmFjdGlvblR5cGVSZWYgPSB1c2VWYWx1ZUFzUmVmKG9wZW5JbnRlcmFjdGlvblR5cGUpO1xuICBjb25zdCBvcGVuUmVmID0gdXNlVmFsdWVBc1JlZihvcGVuKTtcbiAgY29uc3QgdHJlZSA9IHVzZUZsb2F0aW5nVHJlZShleHRlcm5hbFRyZWUpO1xuICBjb25zdCBwb3J0YWxDb250ZXh0ID0gdXNlUG9ydGFsQ29udGV4dCgpO1xuICBjb25zdCBwcmV2ZW50UmV0dXJuRm9jdXNSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBpc1BvaW50ZXJEb3duUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgcG9pbnRlckRvd25PdXRzaWRlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgbGFzdEZvY3VzZWRUYWJiYWJsZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgY2xvc2VUeXBlUmVmID0gUmVhY3QudXNlUmVmKCcnKTtcbiAgY29uc3QgbGFzdEludGVyYWN0aW9uVHlwZVJlZiA9IFJlYWN0LnVzZVJlZignJyk7XG4gIGNvbnN0IGJlZm9yZUd1YXJkUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBhZnRlckd1YXJkUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBtZXJnZWRCZWZvcmVHdWFyZFJlZiA9IHVzZU1lcmdlZFJlZnMoYmVmb3JlR3VhcmRSZWYsIGJlZm9yZUNvbnRlbnRGb2N1c0d1YXJkUmVmLCBwb3J0YWxDb250ZXh0Py5iZWZvcmVJbnNpZGVSZWYpO1xuICBjb25zdCBtZXJnZWRBZnRlckd1YXJkUmVmID0gdXNlTWVyZ2VkUmVmcyhhZnRlckd1YXJkUmVmLCBwb3J0YWxDb250ZXh0Py5hZnRlckluc2lkZVJlZik7XG4gIGNvbnN0IGJsdXJUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBwb2ludGVyRG93blRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IHJlc3RvcmVGb2N1c0ZyYW1lID0gdXNlQW5pbWF0aW9uRnJhbWUoKTtcbiAgY29uc3QgaXNJbnNpZGVQb3J0YWwgPSBwb3J0YWxDb250ZXh0ICE9IG51bGw7XG4gIGNvbnN0IGZsb2F0aW5nRm9jdXNFbGVtZW50ID0gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQoZmxvYXRpbmcpO1xuICBjb25zdCBnZXRUYWJiYWJsZUNvbnRlbnQgPSB1c2VTdGFibGVDYWxsYmFjaygoY29udGFpbmVyID0gZmxvYXRpbmdGb2N1c0VsZW1lbnQpID0+IHtcbiAgICByZXR1cm4gY29udGFpbmVyID8gdGFiYmFibGUoY29udGFpbmVyKSA6IFtdO1xuICB9KTtcbiAgY29uc3QgZ2V0UmVzb2x2ZWRJbnNpZGVFbGVtZW50cyA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IGdldEluc2lkZUVsZW1lbnRzPy4oKS5maWx0ZXIoZWxlbWVudCA9PiBlbGVtZW50ICE9IG51bGwpID8/IFtdKTtcblxuICAvLyBQcmV2ZW50IFRhYiBmcm9tIGVzY2FwaW5nIHRoZSBtb2RhbCB3aGVuIHRoZXJlIGFyZSBubyB0YWJiYWJsZSBlbGVtZW50cy5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQgfHwgIW1vZGFsKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvbktleURvd24oZXZlbnQpIHtcbiAgICAgIGlmIChldmVudC5rZXkgPT09ICdUYWInKSB7XG4gICAgICAgIC8vIFRoZSBmb2N1cyBndWFyZHMgaGF2ZSBub3RoaW5nIHRvIGZvY3VzLCBzbyB3ZSBuZWVkIHRvIHN0b3AgdGhlIGV2ZW50LlxuICAgICAgICBpZiAoY29udGFpbnMoZmxvYXRpbmdGb2N1c0VsZW1lbnQsIGFjdGl2ZUVsZW1lbnQob3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCkpKSAmJiBnZXRUYWJiYWJsZUNvbnRlbnQoKS5sZW5ndGggPT09IDAgJiYgIWlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCkge1xuICAgICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG4gICAgcmV0dXJuIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAna2V5ZG93bicsIG9uS2V5RG93bik7XG4gIH0sIFtkaXNhYmxlZCwgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIG1vZGFsLCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3gsIGdldFRhYmJhYmxlQ29udGVudF0pO1xuXG4gIC8vIFRyYWNrIHBvaW50ZXIva2V5Ym9hcmQgaW50ZXJhY3Rpb25zIHRvIGRpc2FtYmlndWF0ZSBmb2N1cyBhbmQgb3V0c2lkZSBwcmVzc2VzLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhb3Blbikge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG4gICAgZnVuY3Rpb24gY2xlYXJQb2ludGVyRG93bk91dHNpZGUoKSB7XG4gICAgICBwb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvblBvaW50ZXJEb3duKGV2ZW50KSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgY29uc3QgaW5zaWRlRWxlbWVudHMgPSBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzKCk7XG4gICAgICBjb25zdCBwb2ludGVyVGFyZ2V0SW5zaWRlID0gY29udGFpbnMoZmxvYXRpbmcsIHRhcmdldCkgfHwgY29udGFpbnMoZG9tUmVmZXJlbmNlLCB0YXJnZXQpIHx8IGNvbnRhaW5zKHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGUsIHRhcmdldCkgfHwgaW5zaWRlRWxlbWVudHMuc29tZShlbGVtZW50ID0+IGVsZW1lbnQgPT09IHRhcmdldCB8fCBjb250YWlucyhlbGVtZW50LCB0YXJnZXQpKTtcbiAgICAgIHBvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50ID0gIXBvaW50ZXJUYXJnZXRJbnNpZGU7XG4gICAgICBsYXN0SW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgPSBldmVudC5wb2ludGVyVHlwZSB8fCAna2V5Ym9hcmQnO1xuICAgICAgaWYgKHRhcmdldD8uY2xvc2VzdChgWyR7Q0xJQ0tfVFJJR0dFUl9JREVOVElGSUVSfV1gKSkge1xuICAgICAgICBpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAvLyBSZXNldCBvbiB0aGUgbmV4dCB0aWNrIHNvIGEgc2luZ2xlIGNsaWNrIG9uIGEgY2xpY2stdHJpZ2dlciBkb2Vzbid0XG4gICAgICAgIC8vIHBlcm1hbmVudGx5IHN1cHByZXNzIGZvY3VzLW91dCBjbG9zaW5nIGZvciB0aGUgbGlmZXRpbWUgb2YgdGhlIGluc3RhbmNlLlxuICAgICAgICBwb2ludGVyRG93blRpbWVvdXQuc3RhcnQoMCwgKCkgPT4ge1xuICAgICAgICAgIGlzUG9pbnRlckRvd25SZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gb25LZXlEb3duKCkge1xuICAgICAgbGFzdEludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50ID0gJ2tleWJvYXJkJztcbiAgICB9XG4gICAgcmV0dXJuIG1lcmdlQ2xlYW51cHMoYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVyZG93bicsIG9uUG9pbnRlckRvd24sIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3BvaW50ZXJ1cCcsIGNsZWFyUG9pbnRlckRvd25PdXRzaWRlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVyY2FuY2VsJywgY2xlYXJQb2ludGVyRG93bk91dHNpZGUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ2tleWRvd24nLCBvbktleURvd24sIHRydWUpLFxuICAgIC8vIEF2b2lkIGEgc3RhbGUgYHRydWVgIGxlYWtpbmcgaW50byB0aGUgbmV4dCBvcGVuIChlLmcuIGtlZXAtbW91bnRlZCBwb3B1cHMpXG4gICAgLy8gaWYgdGhlIHBvcHVwIGRpc21pc3NlZCBiZXR3ZWVuIHBvaW50ZXJkb3duIGFuZCBwb2ludGVydXAuXG4gICAgY2xlYXJQb2ludGVyRG93bk91dHNpZGUpO1xuICB9LCBbZGlzYWJsZWQsIGZsb2F0aW5nLCBkb21SZWZlcmVuY2UsIGZsb2F0aW5nRm9jdXNFbGVtZW50LCBvcGVuLCBwb3J0YWxDb250ZXh0LCBwb2ludGVyRG93blRpbWVvdXQsIGdldFJlc29sdmVkSW5zaWRlRWxlbWVudHNdKTtcblxuICAvLyBDbG9zZSBvbiBmb2N1cyBvdXQgYW5kIHJlc3RvcmUgZm9jdXMgd2l0aGluIHRoZSBmbG9hdGluZyB0cmVlIHdoZW4gbmVlZGVkLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhY2xvc2VPbkZvY3VzT3V0KSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcblxuICAgIC8vIEluIFNhZmFyaSwgYnV0dG9ucyBsb3NlIGZvY3VzIHdoZW4gcHJlc3NpbmcgdGhlbS5cbiAgICBmdW5jdGlvbiBoYW5kbGVQb2ludGVyRG93bigpIHtcbiAgICAgIGlzUG9pbnRlckRvd25SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICBwb2ludGVyRG93blRpbWVvdXQuc3RhcnQoMCwgKCkgPT4ge1xuICAgICAgICBpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVGb2N1c0luKGV2ZW50KSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgaWYgKGlzVGFiYmFibGUodGFyZ2V0KSkge1xuICAgICAgICBsYXN0Rm9jdXNlZFRhYmJhYmxlUmVmLmN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZUZvY3VzT3V0c2lkZShldmVudCkge1xuICAgICAgY29uc3QgcmVsYXRlZFRhcmdldCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gICAgICBjb25zdCBjdXJyZW50VGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG5cbiAgICAgIC8vIFdoZW4gZm9jdXMgaXMgbG9zdCB0byB0aGUgYm9keSAoZS5nLiBvbiBhIGJhY2tkcm9wIHByZXNzKSwgcmVjb3JkIHRoZSBlbGVtZW50IHRoYXRcbiAgICAgIC8vIGhhZCBmb2N1cyBzbyBhIGNvbmZpcm1hdGlvbiBkaWFsb2cgb3BlbmVkIHdoaWxlIHRoZSBib2R5IGlzIGZvY3VzZWQgY2FuIHJldHVybiBmb2N1c1xuICAgICAgLy8gdG8gaXQuIFNjb3BlZCB0byBgbW9kYWxgIHRvIGF2b2lkIG5vbi1tb2RhbCBwb3B1cHMgcG9sbHV0aW5nIHRoZSBzaGFyZWQgc3RhY2suXG4gICAgICBpZiAobW9kYWwgJiYgcmVsYXRlZFRhcmdldCA9PSBudWxsICYmIHRhcmdldCAhPSBudWxsICYmIGNvbnRhaW5zKGZsb2F0aW5nLCB0YXJnZXQpKSB7XG4gICAgICAgIGFkZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCh0YXJnZXQpO1xuICAgICAgfVxuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICBjb25zdCBub2RlSWQgPSBnZXROb2RlSWQoKTtcbiAgICAgICAgY29uc3QgdHJpZ2dlcnMgPSBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cztcbiAgICAgICAgY29uc3QgaW5zaWRlRWxlbWVudHMgPSBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzKCk7XG4gICAgICAgIGNvbnN0IGlzUmVsYXRlZEZvY3VzR3VhcmQgPSByZWxhdGVkVGFyZ2V0Py5oYXNBdHRyaWJ1dGUoY3JlYXRlQXR0cmlidXRlKCdmb2N1cy1ndWFyZCcpKSAmJiBbYmVmb3JlR3VhcmRSZWYuY3VycmVudCwgYWZ0ZXJHdWFyZFJlZi5jdXJyZW50LCBwb3J0YWxDb250ZXh0Py5iZWZvcmVJbnNpZGVSZWYuY3VycmVudCwgcG9ydGFsQ29udGV4dD8uYWZ0ZXJJbnNpZGVSZWYuY3VycmVudCwgcG9ydGFsQ29udGV4dD8uYmVmb3JlT3V0c2lkZVJlZi5jdXJyZW50LCBwb3J0YWxDb250ZXh0Py5hZnRlck91dHNpZGVSZWYuY3VycmVudCwgcmVzb2x2ZVJlZihwcmV2aW91c0ZvY3VzYWJsZUVsZW1lbnQpLCByZXNvbHZlUmVmKG5leHRGb2N1c2FibGVFbGVtZW50KV0uaW5jbHVkZXMocmVsYXRlZFRhcmdldCk7XG4gICAgICAgIGNvbnN0IG1vdmVkVG9VbnJlbGF0ZWROb2RlID0gIShjb250YWlucyhkb21SZWZlcmVuY2UsIHJlbGF0ZWRUYXJnZXQpIHx8IGNvbnRhaW5zKGZsb2F0aW5nLCByZWxhdGVkVGFyZ2V0KSB8fCBjb250YWlucyhyZWxhdGVkVGFyZ2V0LCBmbG9hdGluZykgfHwgY29udGFpbnMocG9ydGFsQ29udGV4dD8ucG9ydGFsTm9kZSwgcmVsYXRlZFRhcmdldCkgfHwgaW5zaWRlRWxlbWVudHMuc29tZShlbGVtZW50ID0+IGVsZW1lbnQgPT09IHJlbGF0ZWRUYXJnZXQgfHwgY29udGFpbnMoZWxlbWVudCwgcmVsYXRlZFRhcmdldCkpIHx8IHRyaWdnZXJzLmhhc01hdGNoaW5nRWxlbWVudCh0cmlnZ2VyID0+IGNvbnRhaW5zKHRyaWdnZXIsIHJlbGF0ZWRUYXJnZXQpKSB8fCBpc1JlbGF0ZWRGb2N1c0d1YXJkIHx8IHRyZWUgJiYgKGdldE5vZGVDaGlsZHJlbih0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkuZmluZChub2RlID0+IGNvbnRhaW5zKG5vZGUuY29udGV4dD8uZWxlbWVudHMuZmxvYXRpbmcsIHJlbGF0ZWRUYXJnZXQpIHx8IGNvbnRhaW5zKG5vZGUuY29udGV4dD8uZWxlbWVudHMuZG9tUmVmZXJlbmNlLCByZWxhdGVkVGFyZ2V0KSkgfHwgZ2V0Tm9kZUFuY2VzdG9ycyh0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkuZmluZChub2RlID0+IFtub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmZsb2F0aW5nLCBnZXRGbG9hdGluZ0ZvY3VzRWxlbWVudChub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmZsb2F0aW5nKV0uaW5jbHVkZXMocmVsYXRlZFRhcmdldCkgfHwgbm9kZS5jb250ZXh0Py5lbGVtZW50cy5kb21SZWZlcmVuY2UgPT09IHJlbGF0ZWRUYXJnZXQpKSk7XG4gICAgICAgIGlmIChjdXJyZW50VGFyZ2V0ID09PSBkb21SZWZlcmVuY2UgJiYgZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHtcbiAgICAgICAgICBoYW5kbGVUYWJJbmRleChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBSZXN0b3JlIGZvY3VzIHRvIHRoZSBwcmV2aW91c2x5IGZvY3VzZWQgdGFiYmFibGUgZWxlbWVudCB0byBwcmV2ZW50XG4gICAgICAgIC8vIGZvY3VzIGZyb20gYmVpbmcgbG9zdCBvdXRzaWRlIHRoZSBmbG9hdGluZyB0cmVlLlxuICAgICAgICBpZiAocmVzdG9yZUZvY3VzICYmIGN1cnJlbnRUYXJnZXQgIT09IGRvbVJlZmVyZW5jZSAmJiAhaXNFbGVtZW50VmlzaWJsZSh0YXJnZXQpICYmIGFjdGl2ZUVsZW1lbnQoZG9jKSA9PT0gZG9jLmJvZHkpIHtcbiAgICAgICAgICAvLyBMZXQgYEZsb2F0aW5nUG9ydGFsYCBlZmZlY3Qga25vd3MgdGhhdCBmb2N1cyBpcyBzdGlsbCBpbnNpZGUgdGhlXG4gICAgICAgICAgLy8gZmxvYXRpbmcgdHJlZS5cbiAgICAgICAgICBpZiAoaXNIVE1MRWxlbWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCkpIHtcbiAgICAgICAgICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgICAvLyBJZiBleHBsaWNpdGx5IHJlcXVlc3RlZCB0byByZXN0b3JlIGZvY3VzIHRvIHRoZSBwb3B1cCBjb250YWluZXIsIGRvIG5vdCBzZWFyY2hcbiAgICAgICAgICAgIC8vIGZvciB0aGUgbmV4dC9wcmV2aW91cyB0YWJiYWJsZSBlbGVtZW50LlxuICAgICAgICAgICAgaWYgKHJlc3RvcmVGb2N1cyA9PT0gJ3BvcHVwJykge1xuICAgICAgICAgICAgICAvLyBJZiB0aGUgZm9jdXNlZCBlbGVtZW50IGlzIHJlbW92ZWQgb24gcG9pbnRlcmRvd24sIHRoZSBicm93c2VyXG4gICAgICAgICAgICAgIC8vIHRyaWVzIHRvIG1vdmUgZm9jdXMgdG8gaXQgcmlnaHQgYWZ0ZXIgdGhlIGAuZm9jdXMoKWAgY2FsbCBhYm92ZSxcbiAgICAgICAgICAgICAgLy8gYnV0IGJlY2F1c2UgaXQncyByZW1vdmVkIGluIHRoZSBzYW1lIHRpY2ssIGZvY3VzIGlzIGxvc3QgaW5zdGVhZC5cbiAgICAgICAgICAgICAgLy8gUmUtZm9jdXNpbmcgYXN5bmNocm9ub3VzbHkgKG5leHQgZnJhbWUpIHdpbnMgdGhhdCByYWNlLlxuICAgICAgICAgICAgICByZXN0b3JlRm9jdXNGcmFtZS5yZXF1ZXN0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudC5mb2N1cygpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCB0YWJiYWJsZUNvbnRlbnQgPSBnZXRUYWJiYWJsZUNvbnRlbnQoKTtcbiAgICAgICAgICBjb25zdCBwcmV2VGFiYmFibGUgPSBsYXN0Rm9jdXNlZFRhYmJhYmxlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgY29uc3Qgbm9kZVRvRm9jdXMgPSAocHJldlRhYmJhYmxlICYmIHRhYmJhYmxlQ29udGVudC5pbmNsdWRlcyhwcmV2VGFiYmFibGUpID8gcHJldlRhYmJhYmxlIDogbnVsbCkgfHwgdGFiYmFibGVDb250ZW50W3RhYmJhYmxlQ29udGVudC5sZW5ndGggLSAxXSB8fCBmbG9hdGluZ0ZvY3VzRWxlbWVudDtcbiAgICAgICAgICBpZiAoaXNIVE1MRWxlbWVudChub2RlVG9Gb2N1cykpIHtcbiAgICAgICAgICAgIG5vZGVUb0ZvY3VzLmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8zMDYwXG4gICAgICAgIGlmIChkYXRhUmVmLmN1cnJlbnQuaW5zaWRlUmVhY3RUcmVlKSB7XG4gICAgICAgICAgZGF0YVJlZi5jdXJyZW50Lmluc2lkZVJlYWN0VHJlZSA9IGZhbHNlO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEZvY3VzIGRpZCBub3QgbW92ZSBpbnNpZGUgdGhlIGZsb2F0aW5nIHRyZWUsIGFuZCB0aGVyZSBhcmUgbm8gdGFiYmFibGVcbiAgICAgICAgLy8gcG9ydGFsIGd1YXJkcyB0byBoYW5kbGUgY2xvc2luZy5cbiAgICAgICAgaWYgKChpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3ggPyB0cnVlIDogIW1vZGFsKSAmJiByZWxhdGVkVGFyZ2V0ICYmIG1vdmVkVG9VbnJlbGF0ZWROb2RlICYmICFpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgJiYgKFxuICAgICAgICAvLyBGaXggUmVhY3QgMTggU3RyaWN0IE1vZGUgcmV0dXJuRm9jdXMgZHVlIHRvIGRvdWJsZSByZW5kZXJpbmcuXG4gICAgICAgIC8vIEZvciBhbiBcInVudHJhcHBlZFwiIHR5cGVhYmxlIGNvbWJvYm94IChpbnB1dCByb2xlPWNvbWJvYm94IHdpdGhcbiAgICAgICAgLy8gaW5pdGlhbEZvY3VzPWZhbHNlKSwgcmUtb3BlbmluZyB0aGUgcG9wdXAgYW5kIHRhYmJpbmcgb3V0IHNob3VsZCBzdGlsbCBjbG9zZSBpdCBldmVuXG4gICAgICAgIC8vIHdoZW4gdGhlIHByZXZpb3VzbHkgZm9jdXNlZCBlbGVtZW50IChlLmcuIHRoZSBuZXh0IHRhYmJhYmxlIG91dHNpZGUgdGhlIHBvcHVwKSBpc1xuICAgICAgICAvLyBmb2N1c2VkIGFnYWluLiBPdGhlcndpc2UsIHRoZSBwb3B1cCByZW1haW5zIG9wZW4gb24gdGhlIHNlY29uZCBUYWIgc2VxdWVuY2U6XG4gICAgICAgIC8vIGNsaWNrIGlucHV0IC0+IFRhYiAoY2xvc2VzKSAtPiBjbGljayBpbnB1dCAtPiBUYWIuXG4gICAgICAgIC8vIEFsbG93IGNsb3Npbmcgd2hlbiBgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94YCByZWdhcmRsZXNzIG9mIHRoZSBwcmV2aW91c2x5IGZvY3VzZWQgZWxlbWVudC5cbiAgICAgICAgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94IHx8IHJlbGF0ZWRUYXJnZXQgIT09IGdldFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCgpKSkge1xuICAgICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5mb2N1c091dCwgZXZlbnQpKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG1hcmtJbnNpZGVSZWFjdFRyZWUoKSB7XG4gICAgICBpZiAocG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgZGF0YVJlZi5jdXJyZW50Lmluc2lkZVJlYWN0VHJlZSA9IHRydWU7XG4gICAgICBibHVyVGltZW91dC5zdGFydCgwLCAoKSA9PiB7XG4gICAgICAgIGRhdGFSZWYuY3VycmVudC5pbnNpZGVSZWFjdFRyZWUgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBkb21SZWZlcmVuY2VFbGVtZW50ID0gaXNIVE1MRWxlbWVudChkb21SZWZlcmVuY2UpID8gZG9tUmVmZXJlbmNlIDogbnVsbDtcbiAgICBpZiAoIWZsb2F0aW5nICYmICFkb21SZWZlcmVuY2VFbGVtZW50KSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICByZXR1cm4gbWVyZ2VDbGVhbnVwcyhkb21SZWZlcmVuY2VFbGVtZW50ICYmIGFkZEV2ZW50TGlzdGVuZXIoZG9tUmVmZXJlbmNlRWxlbWVudCwgJ2ZvY3Vzb3V0JywgaGFuZGxlRm9jdXNPdXRzaWRlKSwgZG9tUmVmZXJlbmNlRWxlbWVudCAmJiBhZGRFdmVudExpc3RlbmVyKGRvbVJlZmVyZW5jZUVsZW1lbnQsICdwb2ludGVyZG93bicsIGhhbmRsZVBvaW50ZXJEb3duKSwgZmxvYXRpbmcgJiYgYWRkRXZlbnRMaXN0ZW5lcihmbG9hdGluZywgJ2ZvY3VzaW4nLCBoYW5kbGVGb2N1c0luKSwgZmxvYXRpbmcgJiYgYWRkRXZlbnRMaXN0ZW5lcihmbG9hdGluZywgJ2ZvY3Vzb3V0JywgaGFuZGxlRm9jdXNPdXRzaWRlKSwgZmxvYXRpbmcgJiYgcG9ydGFsQ29udGV4dCAmJiBhZGRFdmVudExpc3RlbmVyKGZsb2F0aW5nLCAnZm9jdXNvdXQnLCBtYXJrSW5zaWRlUmVhY3RUcmVlLCB0cnVlKSk7XG4gIH0sIFtkaXNhYmxlZCwgZG9tUmVmZXJlbmNlLCBmbG9hdGluZywgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIG1vZGFsLCB0cmVlLCBwb3J0YWxDb250ZXh0LCBzdG9yZSwgY2xvc2VPbkZvY3VzT3V0LCByZXN0b3JlRm9jdXMsIGdldFRhYmJhYmxlQ29udGVudCwgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94LCBnZXROb2RlSWQsIGRhdGFSZWYsIGJsdXJUaW1lb3V0LCBwb2ludGVyRG93blRpbWVvdXQsIHJlc3RvcmVGb2N1c0ZyYW1lLCBuZXh0Rm9jdXNhYmxlRWxlbWVudCwgcHJldmlvdXNGb2N1c2FibGVFbGVtZW50LCBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzXSk7XG5cbiAgLy8gSGlkZSBldmVyeXRoaW5nIG91dHNpZGUgdGhlIGZsb2F0aW5nIHRyZWUgZnJvbSBhc3Npc3RpdmUgdGVjaCB3aGlsZSBvcGVuLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhZmxvYXRpbmcgfHwgIW9wZW4pIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLy8gRG9uJ3QgaGlkZSBwb3J0YWxzIG5lc3RlZCB3aXRoaW4gdGhlIHBhcmVudCBwb3J0YWwuXG4gICAgY29uc3QgcG9ydGFsTm9kZXMgPSBBcnJheS5mcm9tKHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGU/LnF1ZXJ5U2VsZWN0b3JBbGwoYFske2NyZWF0ZUF0dHJpYnV0ZSgncG9ydGFsJyl9XWApIHx8IFtdKTtcbiAgICBjb25zdCBhbmNlc3RvcnMgPSB0cmVlID8gZ2V0Tm9kZUFuY2VzdG9ycyh0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIGdldE5vZGVJZCgpKSA6IFtdO1xuICAgIGNvbnN0IHJvb3RBbmNlc3RvckNvbWJvYm94RG9tUmVmZXJlbmNlID0gYW5jZXN0b3JzLmZpbmQobm9kZSA9PiBpc1R5cGVhYmxlQ29tYm9ib3gobm9kZS5jb250ZXh0Py5lbGVtZW50cy5kb21SZWZlcmVuY2UgfHwgbnVsbCkpPy5jb250ZXh0Py5lbGVtZW50cy5kb21SZWZlcmVuY2U7XG4gICAgY29uc3QgY29udHJvbEluc2lkZUVsZW1lbnRzID0gW2Zsb2F0aW5nLCAuLi5wb3J0YWxOb2RlcywgYmVmb3JlR3VhcmRSZWYuY3VycmVudCwgYWZ0ZXJHdWFyZFJlZi5jdXJyZW50LCBwb3J0YWxDb250ZXh0Py5iZWZvcmVPdXRzaWRlUmVmLmN1cnJlbnQsIHBvcnRhbENvbnRleHQ/LmFmdGVyT3V0c2lkZVJlZi5jdXJyZW50LCAuLi5nZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzKCldO1xuICAgIGNvbnN0IGluc2lkZUVsZW1lbnRzID0gWy4uLmNvbnRyb2xJbnNpZGVFbGVtZW50cywgcm9vdEFuY2VzdG9yQ29tYm9ib3hEb21SZWZlcmVuY2UsIHJlc29sdmVSZWYocHJldmlvdXNGb2N1c2FibGVFbGVtZW50KSwgcmVzb2x2ZVJlZihuZXh0Rm9jdXNhYmxlRWxlbWVudCksIGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCA/IGRvbVJlZmVyZW5jZSA6IG51bGxdLmZpbHRlcih4ID0+IHggIT0gbnVsbCk7XG4gICAgY29uc3QgYXJpYUhpZGRlbkNsZWFudXAgPSBtYXJrT3RoZXJzKGluc2lkZUVsZW1lbnRzLCB7XG4gICAgICBhcmlhSGlkZGVuOiBtb2RhbCB8fCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3gsXG4gICAgICBtYXJrOiBmYWxzZVxuICAgIH0pO1xuICAgIGNvbnN0IG1hcmtlckluc2lkZUVsZW1lbnRzID0gW2Zsb2F0aW5nLCAuLi5wb3J0YWxOb2Rlc10uZmlsdGVyKHggPT4geCAhPSBudWxsKTtcbiAgICBjb25zdCBtYXJrZXJDbGVhbnVwID0gbWFya090aGVycyhtYXJrZXJJbnNpZGVFbGVtZW50cyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIG1hcmtlckNsZWFudXAoKTtcbiAgICAgIGFyaWFIaWRkZW5DbGVhbnVwKCk7XG4gICAgfTtcbiAgfSwgW29wZW4sIGRpc2FibGVkLCBkb21SZWZlcmVuY2UsIGZsb2F0aW5nLCBtb2RhbCwgcG9ydGFsQ29udGV4dCwgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94LCB0cmVlLCBnZXROb2RlSWQsIG5leHRGb2N1c2FibGVFbGVtZW50LCBwcmV2aW91c0ZvY3VzYWJsZUVsZW1lbnQsIGdldFJlc29sdmVkSW5zaWRlRWxlbWVudHNdKTtcblxuICAvLyBGb2N1cyB0aGUgaW5pdGlhbCBlbGVtZW50IHdoZW4gdGhlIGZsb2F0aW5nIGVsZW1lbnQgb3BlbnMuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuIHx8IGRpc2FibGVkIHx8ICFpc0hUTUxFbGVtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjbG9zZVR5cGVSZWYuY3VycmVudCA9ICcnO1xuICAgIGxhc3RJbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCA9ICcnO1xuICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIGNvbnN0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcblxuICAgIC8vIFdhaXQgZm9yIGFueSBsYXlvdXQgZWZmZWN0IHN0YXRlIHNldHRlcnMgdG8gZXhlY3V0ZSB0byBzZXQgYHRhYkluZGV4YC5cbiAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICBjb25zdCBpbml0aWFsRm9jdXNWYWx1ZU9yRm4gPSBpbml0aWFsRm9jdXNSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IHJlc29sdmVkSW5pdGlhbEZvY3VzID0gdHlwZW9mIGluaXRpYWxGb2N1c1ZhbHVlT3JGbiA9PT0gJ2Z1bmN0aW9uJyA/IGluaXRpYWxGb2N1c1ZhbHVlT3JGbihvcGVuSW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgfHwgJycpIDogaW5pdGlhbEZvY3VzVmFsdWVPckZuO1xuXG4gICAgICAvLyBgbnVsbGAgc2hvdWxkIGZhbGxiYWNrIHRvIGRlZmF1bHQgYmVoYXZpb3IgaW4gY2FzZSBvZiBhbiBlbXB0eSByZWYuXG4gICAgICBpZiAocmVzb2x2ZWRJbml0aWFsRm9jdXMgPT09IHVuZGVmaW5lZCB8fCByZXNvbHZlZEluaXRpYWxGb2N1cyA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgZm9jdXNBbHJlYWR5SW5zaWRlRmxvYXRpbmdFbCA9IGNvbnRhaW5zKGZsb2F0aW5nRm9jdXNFbGVtZW50LCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQpO1xuICAgICAgaWYgKGZvY3VzQWxyZWFkeUluc2lkZUZsb2F0aW5nRWwpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGV0IGZvY3VzYWJsZUVsZW1lbnRzID0gbnVsbDtcbiAgICAgIGNvbnN0IGdldERlZmF1bHRGb2N1c0VsZW1lbnQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChmb2N1c2FibGVFbGVtZW50cyA9PSBudWxsKSB7XG4gICAgICAgICAgZm9jdXNhYmxlRWxlbWVudHMgPSBnZXRUYWJiYWJsZUNvbnRlbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmb2N1c2FibGVFbGVtZW50c1swXSB8fCBmbG9hdGluZ0ZvY3VzRWxlbWVudDtcbiAgICAgIH07XG4gICAgICBsZXQgZWxUb0ZvY3VzO1xuICAgICAgaWYgKHJlc29sdmVkSW5pdGlhbEZvY3VzID09PSB0cnVlIHx8IHJlc29sdmVkSW5pdGlhbEZvY3VzID09PSBudWxsKSB7XG4gICAgICAgIGVsVG9Gb2N1cyA9IGdldERlZmF1bHRGb2N1c0VsZW1lbnQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGVsVG9Gb2N1cyA9IHJlc29sdmVSZWYocmVzb2x2ZWRJbml0aWFsRm9jdXMpO1xuICAgICAgfVxuICAgICAgZWxUb0ZvY3VzID0gZWxUb0ZvY3VzIHx8IGdldERlZmF1bHRGb2N1c0VsZW1lbnQoKTtcbiAgICAgIGNvbnN0IGhhZEZvY3VzSW5zaWRlID0gY29udGFpbnMoZmxvYXRpbmdGb2N1c0VsZW1lbnQsIGFjdGl2ZUVsZW1lbnQoZG9jKSk7XG5cbiAgICAgIC8vIGVucXVldWVGb2N1cyByZXR1cm5zIGEgckFGLWNhbmNlbCBmdW5jdGlvbjsgd2UgaW50ZW50aW9uYWxseSBkb24ndCBjYW5jZWwgdGhpcyBmb2N1cy5cbiAgICAgIHZvaWQgZW5xdWV1ZUZvY3VzKGVsVG9Gb2N1cywge1xuICAgICAgICBwcmV2ZW50U2Nyb2xsOiBlbFRvRm9jdXMgPT09IGZsb2F0aW5nRm9jdXNFbGVtZW50LFxuICAgICAgICBzaG91bGRGb2N1cygpIHtcbiAgICAgICAgICAvLyBUaGlzIGZvY3VzIGlzIHF1ZXVlZCBvbiB0aGUgbmV4dCBhbmltYXRpb24gZnJhbWUuIElmIHRoZSBmbG9hdGluZyBlbGVtZW50IGhhcyBjbG9zZWRcbiAgICAgICAgICAvLyBiZWZvcmUgaXQgcnVucyDigJQgZS5nLiB0YWJiaW5nIG91dCBvZiBhIGtlcHQtbW91bnRlZCBwb3B1cCDigJQgZG9uJ3QgcHVsbCBmb2N1cyBiYWNrXG4gICAgICAgICAgLy8gb250byB0aGUgaW5pdGlhbCBlbGVtZW50IGFmdGVyIGl0IGhhcyBsZWdpdGltYXRlbHkgbW92ZWQgZWxzZXdoZXJlLlxuICAgICAgICAgIGlmICghb3BlblJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChoYWRGb2N1c0luc2lkZSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGN1cnJlbnRBY3RpdmVFbGVtZW50ID0gYWN0aXZlRWxlbWVudChkb2MpO1xuICAgICAgICAgIGNvbnN0IGZvY3VzTW92ZWRJbnNpZGUgPSBjdXJyZW50QWN0aXZlRWxlbWVudCAhPT0gZWxUb0ZvY3VzICYmIGNvbnRhaW5zKGZsb2F0aW5nRm9jdXNFbGVtZW50LCBjdXJyZW50QWN0aXZlRWxlbWVudCk7XG4gICAgICAgICAgcmV0dXJuICFmb2N1c01vdmVkSW5zaWRlO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSwgW2Rpc2FibGVkLCBvcGVuLCBmbG9hdGluZ0ZvY3VzRWxlbWVudCwgZ2V0VGFiYmFibGVDb250ZW50LCBpbml0aWFsRm9jdXNSZWYsIG9wZW5JbnRlcmFjdGlvblR5cGVSZWYsIG9wZW5SZWZdKTtcblxuICAvLyBUcmFjayByZXR1cm4gZm9jdXMgdGFyZ2V0cyBhbmQgcmVzdG9yZSBmb2N1cyBvbiB1bm1vdW50L2Nsb3NlLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIGNvbnN0IGVsZW1lbnRGb2N1c2VkQmVmb3JlT3BlbiA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcbiAgICAvLyBPbmx5IGFuIGV4cGxpY2l0IGBudWxsYCBpbnRlcmFjdGlvbiB0eXBlIHJlcHJlc2VudHMgYSBwcm9ncmFtbWF0aWMgb3Blbi5cbiAgICAvLyBgdW5kZWZpbmVkYCBpcyBub3JtYWxpemVkIHRvIGAnJ2AgYnkgdGhlIHByb3AgZGVmYXVsdCwgc28gaXQgbmV2ZXIgcmVhY2hlc1xuICAgIC8vIGhlcmUgYXMgbnVsbGlzaCBhbmQgaXMgaW50ZW50aW9uYWxseSBub3QgdHJlYXRlZCBhcyBwcm9ncmFtbWF0aWMuXG4gICAgY29uc3QgcHJlZmVyUHJldmlvdXNGb2N1cyA9IG9wZW5JbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCA9PSBudWxsO1xuICAgIGFkZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudChlbGVtZW50Rm9jdXNlZEJlZm9yZU9wZW4pO1xuICAgIGZ1bmN0aW9uIG9uT3BlbkNoYW5nZUxvY2FsKGRldGFpbHMpIHtcbiAgICAgIGlmICghZGV0YWlscy5vcGVuKSB7XG4gICAgICAgIGNsb3NlVHlwZVJlZi5jdXJyZW50ID0gZ2V0RXZlbnRUeXBlKGRldGFpbHMubmF0aXZlRXZlbnQsIGxhc3RJbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCk7XG4gICAgICB9XG4gICAgICBpZiAoZGV0YWlscy5yZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckhvdmVyICYmIGRldGFpbHMubmF0aXZlRXZlbnQudHlwZSA9PT0gJ21vdXNlbGVhdmUnKSB7XG4gICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChkZXRhaWxzLnJlYXNvbiAhPT0gUkVBU09OUy5vdXRzaWRlUHJlc3MpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGRldGFpbHMubmVzdGVkKSB7XG4gICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9IGVsc2UgaWYgKGlzVmlydHVhbENsaWNrKGRldGFpbHMubmF0aXZlRXZlbnQpIHx8IGlzVmlydHVhbFBvaW50ZXJFdmVudChkZXRhaWxzLm5hdGl2ZUV2ZW50KSkge1xuICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gT24gb3V0c2lkZSBwcmVzcywgb25seSByZXR1cm4gZm9jdXMgdG8gdGhlIHJlZmVyZW5jZSB3aGVuIHRoZSBicm93c2VyIHN1cHBvcnRzIHRoZVxuICAgICAgICAvLyBgZm9jdXMoeyBwcmV2ZW50U2Nyb2xsIH0pYCBvcHRpb247IHdpdGhvdXQgaXQsIHJlc3RvcmluZyBmb2N1cyBzY3JvbGxzIHRoZSBwYWdlLlxuICAgICAgICAvLyBDaHJvbWUgb24gQW5kcm9pZCBhbmQgU2Ftc3VuZyBJbnRlcm5ldCBzdGlsbCBkb24ndCBzdXBwb3J0IGBwcmV2ZW50U2Nyb2xsYFxuICAgICAgICAvLyAoaHR0cHM6Ly9pc3N1ZXMuY2hyb21pdW0ub3JnL2lzc3Vlcy80MTQ1MzEyMiksIHNvIHRoZSBydW50aW1lIGNoZWNrIGtlZXBzIHJldHVyblxuICAgICAgICAvLyBmb2N1cyBkaXNhYmxlZCB0aGVyZSB0byBhdm9pZCB0aGUgc2Nyb2xsIGp1bXAuXG4gICAgICAgIGxldCBpc1ByZXZlbnRTY3JvbGxTdXBwb3J0ZWQgPSBmYWxzZTtcbiAgICAgICAgb3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCkuY3JlYXRlRWxlbWVudCgnZGl2JykuZm9jdXMoe1xuICAgICAgICAgIGdldCBwcmV2ZW50U2Nyb2xsKCkge1xuICAgICAgICAgICAgaXNQcmV2ZW50U2Nyb2xsU3VwcG9ydGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoaXNQcmV2ZW50U2Nyb2xsU3VwcG9ydGVkKSB7XG4gICAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgZXZlbnRzLm9uKCdvcGVuY2hhbmdlJywgb25PcGVuQ2hhbmdlTG9jYWwpO1xuICAgIGZ1bmN0aW9uIGdldFJldHVybkVsZW1lbnQoY2xvc2VUeXBlKSB7XG4gICAgICBjb25zdCByZXR1cm5Gb2N1c1ZhbHVlT3JGbiA9IHJldHVybkZvY3VzUmVmLmN1cnJlbnQ7XG4gICAgICBsZXQgcmVzb2x2ZWRSZXR1cm5Gb2N1c1ZhbHVlID0gdHlwZW9mIHJldHVybkZvY3VzVmFsdWVPckZuID09PSAnZnVuY3Rpb24nID8gcmV0dXJuRm9jdXNWYWx1ZU9yRm4oY2xvc2VUeXBlKSA6IHJldHVybkZvY3VzVmFsdWVPckZuO1xuXG4gICAgICAvLyBgbnVsbGAgc2hvdWxkIGZhbGxiYWNrIHRvIGRlZmF1bHQgYmVoYXZpb3IgaW4gY2FzZSBvZiBhbiBlbXB0eSByZWYuXG4gICAgICBpZiAocmVzb2x2ZWRSZXR1cm5Gb2N1c1ZhbHVlID09PSB1bmRlZmluZWQgfHwgcmVzb2x2ZWRSZXR1cm5Gb2N1c1ZhbHVlID09PSBmYWxzZSkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmIChyZXNvbHZlZFJldHVybkZvY3VzVmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgcmVzb2x2ZWRSZXR1cm5Gb2N1c1ZhbHVlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJlZmVyZW5jZVJldHVybkVsZW1lbnQgPSBkb21SZWZlcmVuY2U/LmlzQ29ubmVjdGVkID8gZG9tUmVmZXJlbmNlIDogbnVsbDtcbiAgICAgIGNvbnN0IHByZXZpb3VzUmV0dXJuRWxlbWVudCA9IGVsZW1lbnRGb2N1c2VkQmVmb3JlT3Blbj8uaXNDb25uZWN0ZWQgJiYgZ2V0Tm9kZU5hbWUoZWxlbWVudEZvY3VzZWRCZWZvcmVPcGVuKSAhPT0gJ2JvZHknID8gZWxlbWVudEZvY3VzZWRCZWZvcmVPcGVuIDogbnVsbDtcbiAgICAgIGxldCBkZWZhdWx0UmV0dXJuRWxlbWVudCA9IHByZWZlclByZXZpb3VzRm9jdXMgPyBwcmV2aW91c1JldHVybkVsZW1lbnQgfHwgcmVmZXJlbmNlUmV0dXJuRWxlbWVudCA6IHJlZmVyZW5jZVJldHVybkVsZW1lbnQgfHwgcHJldmlvdXNSZXR1cm5FbGVtZW50O1xuICAgICAgaWYgKCFkZWZhdWx0UmV0dXJuRWxlbWVudCkge1xuICAgICAgICBkZWZhdWx0UmV0dXJuRWxlbWVudCA9IGdldFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCgpIHx8IG51bGw7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIHJlc29sdmVkUmV0dXJuRm9jdXNWYWx1ZSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiBkZWZhdWx0UmV0dXJuRWxlbWVudDtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNvbHZlUmVmKHJlc29sdmVkUmV0dXJuRm9jdXNWYWx1ZSkgfHwgZGVmYXVsdFJldHVybkVsZW1lbnQgfHwgbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGV2ZW50cy5vZmYoJ29wZW5jaGFuZ2UnLCBvbk9wZW5DaGFuZ2VMb2NhbCk7XG4gICAgICBjb25zdCBhY3RpdmVFbCA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcbiAgICAgIGNvbnN0IGluc2lkZUVsZW1lbnRzID0gZ2V0UmVzb2x2ZWRJbnNpZGVFbGVtZW50cygpO1xuICAgICAgY29uc3QgaXNGb2N1c0luc2lkZUZsb2F0aW5nVHJlZSA9IGNvbnRhaW5zKGZsb2F0aW5nLCBhY3RpdmVFbCkgfHwgaW5zaWRlRWxlbWVudHMuc29tZShlbGVtZW50ID0+IGVsZW1lbnQgPT09IGFjdGl2ZUVsIHx8IGNvbnRhaW5zKGVsZW1lbnQsIGFjdGl2ZUVsKSkgfHwgdHJlZSAmJiBnZXROb2RlQ2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBnZXROb2RlSWQoKSwgZmFsc2UpLnNvbWUobm9kZSA9PiBjb250YWlucyhub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmZsb2F0aW5nLCBhY3RpdmVFbCkpO1xuXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgICBjb25zdCByZXR1cm5Gb2N1c1ZhbHVlT3JGbiA9IHJldHVybkZvY3VzUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCBjbG9zZVR5cGUgPSBjbG9zZVR5cGVSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IHJldHVybkVsZW1lbnQgPSBnZXRSZXR1cm5FbGVtZW50KGNsb3NlVHlwZSk7XG4gICAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICAgIC8vIGByZXR1cm5FbGVtZW50YCBpZiBpdCBpcyB0YWJiYWJsZSwgb3RoZXJ3aXNlIGl0cyBmaXJzdCB0YWJiYWJsZSBjaGlsZCxcbiAgICAgICAgLy8gb3RoZXJ3aXNlIGByZXR1cm5FbGVtZW50YCBpdHNlbGYgKHdoaWNoIG1heSBub3QgYmUgdGFiYmFibGUgYXQgYWxsKS5cbiAgICAgICAgY29uc3QgdGFiYmFibGVSZXR1cm5FbGVtZW50ID0gZ2V0Rmlyc3RUYWJiYWJsZUVsZW1lbnQocmV0dXJuRWxlbWVudCk7XG4gICAgICAgIGNvbnN0IGhhc0V4cGxpY2l0UmV0dXJuRm9jdXMgPSB0eXBlb2YgcmV0dXJuRm9jdXNWYWx1ZU9yRm4gIT09ICdib29sZWFuJztcbiAgICAgICAgaWYgKHJldHVybkZvY3VzVmFsdWVPckZuICYmICFwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCAmJiBpc0hUTUxFbGVtZW50KHRhYmJhYmxlUmV0dXJuRWxlbWVudCkgJiYgKFxuICAgICAgICAvLyBJZiB0aGUgZm9jdXMgbW92ZWQgc29tZXdoZXJlIGVsc2UgYWZ0ZXIgbW91bnQsIGF2b2lkIHJldHVybmluZyBmb2N1c1xuICAgICAgICAvLyBzaW5jZSBpdCBsaWtlbHkgZW50ZXJlZCBhIGRpZmZlcmVudCBlbGVtZW50IHdoaWNoIHNob3VsZCBiZVxuICAgICAgICAvLyByZXNwZWN0ZWQ6IGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMjYwN1xuICAgICAgICAhaGFzRXhwbGljaXRSZXR1cm5Gb2N1cyAmJiB0YWJiYWJsZVJldHVybkVsZW1lbnQgIT09IGFjdGl2ZUVsICYmIGFjdGl2ZUVsICE9PSBkb2MuYm9keSA/IGlzRm9jdXNJbnNpZGVGbG9hdGluZ1RyZWUgOiB0cnVlKSkge1xuICAgICAgICAgIGNvbnN0IGZvY3VzT3B0aW9ucyA9IHtcbiAgICAgICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgICAgICB9O1xuICAgICAgICAgIGlmIChjbG9zZVR5cGUgPT09ICdrZXlib2FyZCcpIHtcbiAgICAgICAgICAgIGZvY3VzT3B0aW9ucy5mb2N1c1Zpc2libGUgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0YWJiYWJsZVJldHVybkVsZW1lbnQuZm9jdXMoZm9jdXNPcHRpb25zKTtcbiAgICAgICAgfVxuICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfSk7XG4gICAgfTtcbiAgfSwgW2Rpc2FibGVkLCBmbG9hdGluZywgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIHJldHVybkZvY3VzUmVmLCBvcGVuSW50ZXJhY3Rpb25UeXBlUmVmLCBldmVudHMsIHRyZWUsIGRvbVJlZmVyZW5jZSwgZ2V0Tm9kZUlkLCBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzXSk7XG5cbiAgLy8gU2FmYXJpIG1heSByYW5kb21seSBzY3JvbGwgdG8gdGhlIGJvdHRvbSBvZiB0aGUgcGFnZSBpZiBhbiBpbnB1dCBpbnNpZGUgYSBwb3B1cCBoYXMgZm9jdXNcbiAgLy8gd2hlbiB0aGUgcG9wdXAgdW5tb3VudHMgZnJvbSB0aGUgRE9NLlxuICAvLyBCeSBibHVycmluZyBpdCBiZWZvcmUgdGhlIHBvcHVwIHVubW91bnRzLCB3ZSBjYW4gcHJldmVudCB0aGlzIGJlaGF2aW9yLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcGxhdGZvcm0uZW5naW5lLndlYmtpdCB8fCBvcGVuIHx8ICFmbG9hdGluZykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBhY3RpdmVFbCA9IGFjdGl2ZUVsZW1lbnQob3duZXJEb2N1bWVudChmbG9hdGluZykpO1xuICAgIGlmICghaXNIVE1MRWxlbWVudChhY3RpdmVFbCkgfHwgIWlzVHlwZWFibGVFbGVtZW50KGFjdGl2ZUVsKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY29udGFpbnMoZmxvYXRpbmcsIGFjdGl2ZUVsKSkge1xuICAgICAgYWN0aXZlRWwuYmx1cigpO1xuICAgIH1cbiAgfSwgW29wZW4sIGZsb2F0aW5nXSk7XG5cbiAgLy8gU3luY2hyb25pemUgdGhlIGZvY3VzIG1hbmFnZXIgc3RhdGUgKG1vZGFsLCBjbG9zZU9uRm9jdXNPdXQsIG9wZW4sIGV0Yy4pIHRvIHRoZVxuICAvLyBGbG9hdGluZ1BvcnRhbCBjb250ZXh0LCB3aGljaCB1c2VzIGl0IHRvIGRlY2lkZSB3aGV0aGVyIHRvIHJlbmRlciBpdHMgb3duIGd1YXJkcy5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQgfHwgIXBvcnRhbENvbnRleHQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHBvcnRhbENvbnRleHQuc2V0Rm9jdXNNYW5hZ2VyU3RhdGUoe1xuICAgICAgbW9kYWwsXG4gICAgICBjbG9zZU9uRm9jdXNPdXQsXG4gICAgICBvcGVuLFxuICAgICAgb25PcGVuQ2hhbmdlOiBzdG9yZS5zZXRPcGVuLFxuICAgICAgZG9tUmVmZXJlbmNlXG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHBvcnRhbENvbnRleHQuc2V0Rm9jdXNNYW5hZ2VyU3RhdGUobnVsbCk7XG4gICAgfTtcbiAgfSwgW2Rpc2FibGVkLCBwb3J0YWxDb250ZXh0LCBtb2RhbCwgb3Blbiwgc3RvcmUsIGNsb3NlT25Gb2N1c091dCwgZG9tUmVmZXJlbmNlXSk7XG5cbiAgLy8gS2VlcCB0aGUgZmxvYXRpbmcgZWxlbWVudCB0YWJJbmRleCBpbiBzeW5jIGFuZCBjbGVhciBzdGFsZSBmb2N1cyByZWNvcmRzLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGhhbmRsZVRhYkluZGV4KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgcXVldWVNaWNyb3Rhc2soY2xlYXJEaXNjb25uZWN0ZWRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzKTtcbiAgICB9O1xuICB9LCBbZGlzYWJsZWQsIGZsb2F0aW5nRm9jdXNFbGVtZW50XSk7XG4gIGNvbnN0IHNob3VsZFJlbmRlckd1YXJkcyA9ICFkaXNhYmxlZCAmJiAobW9kYWwgPyAhaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94IDogdHJ1ZSkgJiYgKGlzSW5zaWRlUG9ydGFsIHx8IG1vZGFsKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhSZWFjdC5GcmFnbWVudCwge1xuICAgIGNoaWxkcmVuOiBbc2hvdWxkUmVuZGVyR3VhcmRzICYmIC8qI19fUFVSRV9fKi9fanN4KEZvY3VzR3VhcmQsIHtcbiAgICAgIFwiZGF0YS10eXBlXCI6IFwiaW5zaWRlXCIsXG4gICAgICByZWY6IG1lcmdlZEJlZm9yZUd1YXJkUmVmLFxuICAgICAgb25Gb2N1czogZXZlbnQgPT4ge1xuICAgICAgICBpZiAobW9kYWwpIHtcbiAgICAgICAgICBjb25zdCBlbHMgPSBnZXRUYWJiYWJsZUNvbnRlbnQoKTtcbiAgICAgICAgICAvLyBlbnF1ZXVlRm9jdXMgcmV0dXJucyBhIHJBRi1jYW5jZWwgZnVuY3Rpb24gd2UgZG9uJ3QgbmVlZCBoZXJlLlxuICAgICAgICAgIHZvaWQgZW5xdWV1ZUZvY3VzKGVsc1tlbHMubGVuZ3RoIC0gMV0pO1xuICAgICAgICB9IGVsc2UgaWYgKHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGUpIHtcbiAgICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgIGlmIChpc091dHNpZGVFdmVudChldmVudCwgcG9ydGFsQ29udGV4dC5wb3J0YWxOb2RlKSkge1xuICAgICAgICAgICAgY29uc3QgbmV4dFRhYmJhYmxlID0gZ2V0TmV4dFRhYmJhYmxlKGRvbVJlZmVyZW5jZSk7XG4gICAgICAgICAgICBuZXh0VGFiYmFibGU/LmZvY3VzKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc29sdmVSZWYocHJldmlvdXNGb2N1c2FibGVFbGVtZW50ID8/IHBvcnRhbENvbnRleHQuYmVmb3JlT3V0c2lkZVJlZik/LmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSksIGNoaWxkcmVuLCBzaG91bGRSZW5kZXJHdWFyZHMgJiYgLyojX19QVVJFX18qL19qc3goRm9jdXNHdWFyZCwge1xuICAgICAgXCJkYXRhLXR5cGVcIjogXCJpbnNpZGVcIixcbiAgICAgIHJlZjogbWVyZ2VkQWZ0ZXJHdWFyZFJlZixcbiAgICAgIG9uRm9jdXM6IGV2ZW50ID0+IHtcbiAgICAgICAgaWYgKG1vZGFsKSB7XG4gICAgICAgICAgLy8gZW5xdWV1ZUZvY3VzIHJldHVybnMgYSByQUYtY2FuY2VsIGZ1bmN0aW9uIHdlIGRvbid0IG5lZWQgaGVyZS5cbiAgICAgICAgICB2b2lkIGVucXVldWVGb2N1cyhnZXRUYWJiYWJsZUNvbnRlbnQoKVswXSk7XG4gICAgICAgIH0gZWxzZSBpZiAocG9ydGFsQ29udGV4dD8ucG9ydGFsTm9kZSkge1xuICAgICAgICAgIGlmIChjbG9zZU9uRm9jdXNPdXQpIHtcbiAgICAgICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3J0YWxDb250ZXh0LnBvcnRhbE5vZGUpKSB7XG4gICAgICAgICAgICBjb25zdCBwcmV2VGFiYmFibGUgPSBnZXRQcmV2aW91c1RhYmJhYmxlKGRvbVJlZmVyZW5jZSk7XG4gICAgICAgICAgICBwcmV2VGFiYmFibGU/LmZvY3VzKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc29sdmVSZWYobmV4dEZvY3VzYWJsZUVsZW1lbnQgPz8gcG9ydGFsQ29udGV4dC5hZnRlck91dHNpZGVSZWYpPy5mb2N1cygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXVxuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUFuaW1hdGlvbkZyYW1lIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlQW5pbWF0aW9uRnJhbWUnO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgZ2V0VGFyZ2V0LCBpc1R5cGVhYmxlRWxlbWVudCB9IGZyb20gXCIuLi91dGlscy9lbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgaXNNb3VzZUxpa2VQb2ludGVyVHlwZSwgaXNWaXJ0dWFsUG9pbnRlckV2ZW50IH0gZnJvbSBcIi4uL3V0aWxzL2V2ZW50Lm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuLyoqXG4gKiBPcGVucyBvciBjbG9zZXMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2hlbiBjbGlja2luZyB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlQ2xpY2tcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNsaWNrKGNvbnRleHQsIHByb3BzID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIGV2ZW50OiBldmVudE9wdGlvbiA9ICdjbGljaycsXG4gICAgdG9nZ2xlID0gdHJ1ZSxcbiAgICBpZ25vcmVNb3VzZSA9IGZhbHNlLFxuICAgIHN0aWNrSWZPcGVuID0gdHJ1ZSxcbiAgICB0b3VjaE9wZW5EZWxheSA9IDAsXG4gICAgcmVhc29uID0gUkVBU09OUy50cmlnZ2VyUHJlc3NcbiAgfSA9IHByb3BzO1xuICBjb25zdCBzdG9yZSA9ICdyb290U3RvcmUnIGluIGNvbnRleHQgPyBjb250ZXh0LnJvb3RTdG9yZSA6IGNvbnRleHQ7XG4gIGNvbnN0IGRhdGFSZWYgPSBzdG9yZS5jb250ZXh0LmRhdGFSZWY7XG4gIGNvbnN0IHBvaW50ZXJUeXBlUmVmID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gIGNvbnN0IGZyYW1lID0gdXNlQW5pbWF0aW9uRnJhbWUoKTtcbiAgY29uc3QgdG91Y2hPcGVuVGltZW91dCA9IHVzZVRpbWVvdXQoKTtcbiAgY29uc3QgcmVmZXJlbmNlID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgZnVuY3Rpb24gc2V0T3BlbldpdGhUb3VjaERlbGF5KG5leHRPcGVuLCBuYXRpdmVFdmVudCwgdGFyZ2V0LCBwb2ludGVyVHlwZSkge1xuICAgICAgY29uc3QgZGV0YWlscyA9IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhyZWFzb24sIG5hdGl2ZUV2ZW50LCB0YXJnZXQpO1xuICAgICAgaWYgKG5leHRPcGVuICYmIHBvaW50ZXJUeXBlID09PSAndG91Y2gnICYmIHRvdWNoT3BlbkRlbGF5ID4gMCkge1xuICAgICAgICB0b3VjaE9wZW5UaW1lb3V0LnN0YXJ0KHRvdWNoT3BlbkRlbGF5LCAoKSA9PiB7XG4gICAgICAgICAgc3RvcmUuc2V0T3Blbih0cnVlLCBkZXRhaWxzKTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdG9yZS5zZXRPcGVuKG5leHRPcGVuLCBkZXRhaWxzKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0TmV4dE9wZW4ob3BlbiwgY3VycmVudFRhcmdldCwgaXNDbGlja0xpa2VPcGVuRXZlbnQpIHtcbiAgICAgIGNvbnN0IG9wZW5FdmVudCA9IGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQ7XG4gICAgICBjb25zdCBoYXNDbGlja2VkT25JbmFjdGl2ZVRyaWdnZXIgPSBzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKSAhPT0gY3VycmVudFRhcmdldDtcbiAgICAgIGlmIChvcGVuICYmIGhhc0NsaWNrZWRPbkluYWN0aXZlVHJpZ2dlcikge1xuICAgICAgICAvLyBNb3ZpbmcgYmV0d2VlbiB0cmlnZ2VycyBzaG91bGQgYWx3YXlzIG9wZW4gdGhlIG5ld2x5IGFjdGl2ZSBvbmUuXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKCFvcGVuKSB7XG4gICAgICAgIC8vIEEgY2xvc2VkIHBvcHVwIHNob3VsZCBvcGVuIG9uIHRoZSBuZXh0IHByZXNzLlxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICghdG9nZ2xlKSB7XG4gICAgICAgIC8vIE5vbi10b2dnbGUgbW9kZSBuZXZlciBjbG9zZXMgb24gYSByZXBlYXRlZCB0cmlnZ2VyIHByZXNzLlxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChvcGVuRXZlbnQgJiYgc3RpY2tJZk9wZW4pIHtcbiAgICAgICAgLy8gUHJlc2VydmUgaG92ZXIvZm9jdXMtb3BlbmVkIHBvcHVwcyB1bnRpbCB0aGUgbWF0Y2hpbmcgY2xpY2stbGlrZSBldmVudCBjbG9zZXMgdGhlbS5cbiAgICAgICAgcmV0dXJuICFpc0NsaWNrTGlrZU9wZW5FdmVudChvcGVuRXZlbnQudHlwZSk7XG4gICAgICB9XG5cbiAgICAgIC8vIE90aGVyd2lzZSwgYSByZXBlYXRlZCBjbGljayB0b2dnbGVzIHRoZSBwb3B1cCBjbG9zZWQuXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBvblBvaW50ZXJEb3duKGV2ZW50KSB7XG4gICAgICAgIC8vIFNjcmVlbiByZWFkZXIgYWN0aXZhdGlvbnMgKEFuZHJvaWQgVGFsa0JhY2ssIGRlc2t0b3Agc2NyZWVuIHJlYWRlcnMpIHJlcG9ydCBhXG4gICAgICAgIC8vIG1vdXNlLWxpa2UgYHBvaW50ZXJUeXBlYCwgYnV0IGBpZ25vcmVNb3VzZWAgbXVzdCBub3QgZHJvcCB0aGVtOiBob3ZlciBsb2dpYyBjYW5ub3RcbiAgICAgICAgLy8gb3BlbiBmb3IgYSB2aXJ0dWFsIHByZXNzIHNpbmNlIHRoZXJlIGlzIG5vIHJlYWwgcG9pbnRlciBtb3ZlbWVudCB0byB3YWl0IGZvci5cbiAgICAgICAgLy8gVmlydHVhbCBgdG91Y2hgIHByZXNzZXMgKGlPUyBWb2ljZU92ZXIpIGtlZXAgdGhlaXIgdHlwZSBzbyBgdG91Y2hPcGVuRGVsYXlgIGFwcGxpZXMuXG4gICAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSBpc01vdXNlTGlrZVBvaW50ZXJUeXBlKGV2ZW50LnBvaW50ZXJUeXBlLCB0cnVlKSAmJiBpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZXZlbnQubmF0aXZlRXZlbnQpID8gJ3ZpcnR1YWwnIDogZXZlbnQucG9pbnRlclR5cGU7XG4gICAgICB9LFxuICAgICAgb25Nb3VzZURvd24oZXZlbnQpIHtcbiAgICAgICAgY29uc3QgcG9pbnRlclR5cGUgPSBwb2ludGVyVHlwZVJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCBuYXRpdmVFdmVudCA9IGV2ZW50Lm5hdGl2ZUV2ZW50O1xuICAgICAgICBjb25zdCBvcGVuID0gc3RvcmUuc2VsZWN0KCdvcGVuJyk7XG5cbiAgICAgICAgLy8gSWdub3JlIGFsbCBidXR0b25zIGV4Y2VwdCBmb3IgdGhlIFwibWFpblwiIGJ1dHRvbi5cbiAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL01vdXNlRXZlbnQvYnV0dG9uXG4gICAgICAgIGlmIChldmVudC5idXR0b24gIT09IDAgfHwgZXZlbnRPcHRpb24gPT09ICdjbGljaycgfHwgaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZSwgdHJ1ZSkgJiYgaWdub3JlTW91c2UpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbmV4dE9wZW4gPSBnZXROZXh0T3BlbihvcGVuLCBldmVudC5jdXJyZW50VGFyZ2V0LCBvcGVuRXZlbnRUeXBlID0+IG9wZW5FdmVudFR5cGUgPT09ICdjbGljaycgfHwgb3BlbkV2ZW50VHlwZSA9PT0gJ21vdXNlZG93bicpO1xuXG4gICAgICAgIC8vIEFuaW1hdGlvbnMgc29tZXRpbWVzIHdvbid0IHJ1biBvbiBhIHR5cGVhYmxlIGVsZW1lbnQgaWYgdXNpbmcgYSByQUYuXG4gICAgICAgIC8vIEZvY3VzIGlzIGFsd2F5cyBzZXQgb24gdGhlc2UgZWxlbWVudHMuIEZvciB0b3VjaCwgd2UgbWF5IGRlbGF5IG9wZW5pbmcuXG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChuYXRpdmVFdmVudCk7XG4gICAgICAgIGlmIChpc1R5cGVhYmxlRWxlbWVudCh0YXJnZXQpKSB7XG4gICAgICAgICAgc2V0T3BlbldpdGhUb3VjaERlbGF5KG5leHRPcGVuLCBuYXRpdmVFdmVudCwgdGFyZ2V0LCBwb2ludGVyVHlwZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQ2FwdHVyZSB0aGUgY3VycmVudFRhcmdldCBiZWZvcmUgdGhlIHJBRi5cbiAgICAgICAgLy8gYXMgUmVhY3Qgc2V0cyBpdCB0byBudWxsIGFmdGVyIHRoZSBldmVudCBoYW5kbGVyIGNvbXBsZXRlcy5cbiAgICAgICAgY29uc3QgZXZlbnRDdXJyZW50VGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcblxuICAgICAgICAvLyBXYWl0IHVudGlsIGZvY3VzIGlzIHNldCBvbiB0aGUgZWxlbWVudC4gVGhpcyBpcyBhbiBhbHRlcm5hdGl2ZSB0b1xuICAgICAgICAvLyBgZXZlbnQucHJldmVudERlZmF1bHQoKWAgdG8gYXZvaWQgOmZvY3VzLXZpc2libGUgZnJvbSBhcHBlYXJpbmcgd2hlbiB1c2luZyBhIHBvaW50ZXIuXG4gICAgICAgIGZyYW1lLnJlcXVlc3QoKCkgPT4ge1xuICAgICAgICAgIHNldE9wZW5XaXRoVG91Y2hEZWxheShuZXh0T3BlbiwgbmF0aXZlRXZlbnQsIGV2ZW50Q3VycmVudFRhcmdldCwgcG9pbnRlclR5cGUpO1xuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICBvbkNsaWNrKGV2ZW50KSB7XG4gICAgICAgIGlmIChldmVudE9wdGlvbiA9PT0gJ21vdXNlZG93bi1vbmx5Jykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwb2ludGVyVHlwZSA9IHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmIChldmVudE9wdGlvbiA9PT0gJ21vdXNlZG93bicgJiYgcG9pbnRlclR5cGUpIHtcbiAgICAgICAgICBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gdW5kZWZpbmVkO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZSwgdHJ1ZSkgJiYgaWdub3JlTW91c2UpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb3BlbiA9IHN0b3JlLnNlbGVjdCgnb3BlbicpO1xuICAgICAgICBjb25zdCBuZXh0T3BlbiA9IGdldE5leHRPcGVuKG9wZW4sIGV2ZW50LmN1cnJlbnRUYXJnZXQsIG9wZW5FdmVudFR5cGUgPT4gb3BlbkV2ZW50VHlwZSA9PT0gJ2NsaWNrJyB8fCBvcGVuRXZlbnRUeXBlID09PSAnbW91c2Vkb3duJyB8fCBvcGVuRXZlbnRUeXBlID09PSAna2V5ZG93bicgfHwgb3BlbkV2ZW50VHlwZSA9PT0gJ2tleXVwJyk7XG4gICAgICAgIHNldE9wZW5XaXRoVG91Y2hEZWxheShuZXh0T3BlbiwgZXZlbnQubmF0aXZlRXZlbnQsIGV2ZW50LmN1cnJlbnRUYXJnZXQsIHBvaW50ZXJUeXBlKTtcbiAgICAgIH0sXG4gICAgICBvbktleURvd24oKSB7XG4gICAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2RhdGFSZWYsIGV2ZW50T3B0aW9uLCBpZ25vcmVNb3VzZSwgcmVhc29uLCBzdG9yZSwgc3RpY2tJZk9wZW4sIHRvZ2dsZSwgZnJhbWUsIHRvdWNoT3BlblRpbWVvdXQsIHRvdWNoT3BlbkRlbGF5XSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGVuYWJsZWQgPyB7XG4gICAgcmVmZXJlbmNlXG4gIH0gOiBFTVBUWV9PQkpFQ1QsIFtlbmFibGVkLCByZWZlcmVuY2VdKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbi8qIGVzbGludC1kaXNhYmxlIG5vLXVuZGVyc2NvcmUtZGFuZ2xlICovXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyBtZXJnZUNsZWFudXBzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvbWVyZ2VDbGVhbnVwcyc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyBUaW1lb3V0LCB1c2VUaW1lb3V0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVGltZW91dCc7XG5pbXBvcnQgeyBnZXRDb21wdXRlZFN0eWxlLCBnZXRQYXJlbnROb2RlLCBpc0VsZW1lbnQsIGlzSFRNTEVsZW1lbnQsIGlzTGFzdFRyYXZlcnNhYmxlTm9kZSwgaXNTaGFkb3dSb290IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IHVzZUZsb2F0aW5nVHJlZSB9IGZyb20gXCIuLi9jb21wb25lbnRzL0Zsb2F0aW5nVHJlZS5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUF0dHJpYnV0ZSB9IGZyb20gXCIuLi91dGlscy9jcmVhdGVBdHRyaWJ1dGUubWpzXCI7XG5pbXBvcnQgeyBjb250YWlucywgZ2V0VGFyZ2V0LCBpc0V2ZW50VGFyZ2V0V2l0aGluLCBpc1Jvb3RFbGVtZW50IH0gZnJvbSBcIi4uL3V0aWxzL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc1JlYWN0RXZlbnQgfSBmcm9tIFwiLi4vdXRpbHMvZXZlbnQubWpzXCI7XG5pbXBvcnQgeyBnZXROb2RlQ2hpbGRyZW4gfSBmcm9tIFwiLi4vdXRpbHMvbm9kZXMubWpzXCI7XG5mdW5jdGlvbiBhbHdheXNGYWxzZSgpIHtcbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZVByb3Aobm9ybWFsaXphYmxlKSB7XG4gIHJldHVybiB7XG4gICAgZXNjYXBlS2V5OiB0eXBlb2Ygbm9ybWFsaXphYmxlID09PSAnYm9vbGVhbicgPyBub3JtYWxpemFibGUgOiBub3JtYWxpemFibGU/LmVzY2FwZUtleSA/PyBmYWxzZSxcbiAgICBvdXRzaWRlUHJlc3M6IHR5cGVvZiBub3JtYWxpemFibGUgPT09ICdib29sZWFuJyA/IG5vcm1hbGl6YWJsZSA6IG5vcm1hbGl6YWJsZT8ub3V0c2lkZVByZXNzID8/IHRydWVcbiAgfTtcbn1cbi8qKlxuICogQ2xvc2VzIHRoZSBmbG9hdGluZyBlbGVtZW50IHdoZW4gYSBkaXNtaXNzYWwgaXMgcmVxdWVzdGVkIOKAlCBieSBkZWZhdWx0LCB3aGVuXG4gKiB0aGUgdXNlciBwcmVzc2VzIHRoZSBgZXNjYXBlYCBrZXkgb3Igb3V0c2lkZSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VEaXNtaXNzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VEaXNtaXNzKGNvbnRleHQsIHByb3BzID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIGVzY2FwZUtleSA9IHRydWUsXG4gICAgb3V0c2lkZVByZXNzOiBvdXRzaWRlUHJlc3NQcm9wID0gdHJ1ZSxcbiAgICBvdXRzaWRlUHJlc3NFdmVudCA9ICdzbG9wcHknLFxuICAgIHJlZmVyZW5jZVByZXNzID0gYWx3YXlzRmFsc2UsXG4gICAgYnViYmxlcyxcbiAgICBleHRlcm5hbFRyZWVcbiAgfSA9IHByb3BzO1xuICBjb25zdCBzdG9yZSA9ICdyb290U3RvcmUnIGluIGNvbnRleHQgPyBjb250ZXh0LnJvb3RTdG9yZSA6IGNvbnRleHQ7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBmbG9hdGluZ0VsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdFbGVtZW50Jyk7XG4gIGNvbnN0IHtcbiAgICBkYXRhUmVmXG4gIH0gPSBzdG9yZS5jb250ZXh0O1xuICBjb25zdCB0cmVlID0gdXNlRmxvYXRpbmdUcmVlKGV4dGVybmFsVHJlZSk7XG4gIGNvbnN0IG91dHNpZGVQcmVzc0ZuID0gdXNlU3RhYmxlQ2FsbGJhY2sodHlwZW9mIG91dHNpZGVQcmVzc1Byb3AgPT09ICdmdW5jdGlvbicgPyBvdXRzaWRlUHJlc3NQcm9wIDogKCkgPT4gZmFsc2UpO1xuICBjb25zdCBvdXRzaWRlUHJlc3MgPSB0eXBlb2Ygb3V0c2lkZVByZXNzUHJvcCA9PT0gJ2Z1bmN0aW9uJyA/IG91dHNpZGVQcmVzc0ZuIDogb3V0c2lkZVByZXNzUHJvcDtcbiAgY29uc3Qgb3V0c2lkZVByZXNzRW5hYmxlZCA9IG91dHNpZGVQcmVzcyAhPT0gZmFsc2U7XG4gIGNvbnN0IGdldE91dHNpZGVQcmVzc0V2ZW50UHJvcCA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IG91dHNpZGVQcmVzc0V2ZW50KTtcbiAgY29uc3Qge1xuICAgIGVzY2FwZUtleTogZXNjYXBlS2V5QnViYmxlcyxcbiAgICBvdXRzaWRlUHJlc3M6IG91dHNpZGVQcmVzc0J1YmJsZXNcbiAgfSA9IG5vcm1hbGl6ZVByb3AoYnViYmxlcyk7XG4gIGNvbnN0IHByZXNzU3RhcnRlZEluc2lkZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHByZXNzU3RhcnRQcmV2ZW50ZWRSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAvLyBJZ25vcmUgb25seSB0aGUgdmVyeSBuZXh0IG91dHNpZGUgY2xpY2sgYWZ0ZXIgZHJhZ2dpbmcgZnJvbSBpbnNpZGUgdG8gb3V0c2lkZS5cbiAgY29uc3Qgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgaXNDb21wb3NpbmdSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBjdXJyZW50UG9pbnRlclR5cGVSZWYgPSBSZWFjdC51c2VSZWYoJycpO1xuICBjb25zdCB0b3VjaFN0YXRlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBjbGVhckluc2lkZVJlYWN0VHJlZVRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IGNsZWFySW5zaWRlUmVhY3RUcmVlID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNsZWFySW5zaWRlUmVhY3RUcmVlVGltZW91dC5jbGVhcigpO1xuICAgIGRhdGFSZWYuY3VycmVudC5pbnNpZGVSZWFjdFRyZWUgPSBmYWxzZTtcbiAgfSk7XG4gIGNvbnN0IGhhc0Jsb2NraW5nQ2hpbGQgPSB1c2VTdGFibGVDYWxsYmFjayhidWJibGVLZXkgPT4ge1xuICAgIGNvbnN0IG5vZGVJZCA9IGRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQ/Lm5vZGVJZDtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHRyZWUgPyBnZXROb2RlQ2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBub2RlSWQpIDogW107XG4gICAgcmV0dXJuIGNoaWxkcmVuLnNvbWUoY2hpbGQgPT4gY2hpbGQuY29udGV4dD8ub3BlbiAmJiAhY2hpbGQuY29udGV4dC5kYXRhUmVmLmN1cnJlbnRbYnViYmxlS2V5XSk7XG4gIH0pO1xuICBjb25zdCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMgPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgcmV0dXJuIGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdFbGVtZW50JykpIHx8IGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIHN0b3JlLnNlbGVjdCgnZG9tUmVmZXJlbmNlRWxlbWVudCcpKTtcbiAgfSk7XG4gIGNvbnN0IGNsb3NlT25SZWZlcmVuY2VQcmVzcyA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBpZiAoIXJlZmVyZW5jZVByZXNzKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMudHJpZ2dlclByZXNzLCBldmVudC5uYXRpdmVFdmVudCkpO1xuICB9KTtcbiAgY29uc3QgY2xvc2VPbkVzY2FwZUtleURvd24gPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVkIHx8ICFlc2NhcGVLZXkgfHwgZXZlbnQua2V5ICE9PSAnRXNjYXBlJykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFdhaXQgdW50aWwgSU1FIGlzIHNldHRsZWQuIFByZXNzaW5nIGBFc2NhcGVgIHdoaWxlIGNvbXBvc2luZyBzaG91bGRcbiAgICAvLyBjbG9zZSB0aGUgY29tcG9zZSBtZW51LCBidXQgbm90IHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICAgIGlmIChpc0NvbXBvc2luZ1JlZi5jdXJyZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghZXNjYXBlS2V5QnViYmxlcyAmJiBoYXNCbG9ja2luZ0NoaWxkKCdfX2VzY2FwZUtleUJ1YmJsZXMnKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBuYXRpdmUgPSBpc1JlYWN0RXZlbnQoZXZlbnQpID8gZXZlbnQubmF0aXZlRXZlbnQgOiBldmVudDtcbiAgICBjb25zdCBldmVudERldGFpbHMgPSBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5lc2NhcGVLZXksIG5hdGl2ZSk7XG4gICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgZXZlbnREZXRhaWxzKTtcbiAgICBpZiAoIWV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH1cbiAgICBpZiAoIWVzY2FwZUtleUJ1YmJsZXMgJiYgIWV2ZW50RGV0YWlscy5pc1Byb3BhZ2F0aW9uQWxsb3dlZCkge1xuICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgbWFya0luc2lkZVJlYWN0VHJlZSA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBkYXRhUmVmLmN1cnJlbnQuaW5zaWRlUmVhY3RUcmVlID0gdHJ1ZTtcbiAgICBjbGVhckluc2lkZVJlYWN0VHJlZVRpbWVvdXQuc3RhcnQoMCwgY2xlYXJJbnNpZGVSZWFjdFRyZWUpO1xuICB9KTtcbiAgY29uc3QgbWFya1ByZXNzU3RhcnRlZEluc2lkZVJlYWN0VHJlZSA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBpZiAoIW9wZW4gfHwgIWVuYWJsZWQgfHwgZXZlbnQuYnV0dG9uICE9PSAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudC5uYXRpdmVFdmVudCk7XG5cbiAgICAvLyBPbmx5IHRyZWF0IHByZXNzZXMgdGhhdCBzdGFydCB3aXRoaW4gdGhlIGZsb2F0aW5nIERPTSBzdWJ0cmVlIGFzIGluc2lkZS5cbiAgICAvLyBUaGlzIGF2b2lkcyBzdXBwcmVzc2luZyBwYXJlbnQgZGlzbWlzc2FsIHdoZW4gaW50ZXJhY3Rpbmcgd2l0aCBuZXN0ZWQgcG9ydGFscy5cbiAgICBpZiAoIWNvbnRhaW5zKHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdFbGVtZW50JyksIHRhcmdldCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFwcmVzc1N0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCkge1xuICAgICAgcHJlc3NTdGFydGVkSW5zaWRlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgcHJlc3NTdGFydFByZXZlbnRlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgbWFya0luc2lkZVByZXNzU3RhcnRQcmV2ZW50ZWQgPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghKGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQgfHwgZXZlbnQubmF0aXZlRXZlbnQuZGVmYXVsdFByZXZlbnRlZCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHByZXNzU3RhcnRlZEluc2lkZVJlZi5jdXJyZW50KSB7XG4gICAgICBwcmVzc1N0YXJ0UHJldmVudGVkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH1cbiAgfSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVkKSB7XG4gICAgICByZXR1cm4gY2xlYXJJbnNpZGVSZWFjdFRyZWU7XG4gICAgfVxuICAgIGRhdGFSZWYuY3VycmVudC5fX2VzY2FwZUtleUJ1YmJsZXMgPSBlc2NhcGVLZXlCdWJibGVzO1xuICAgIGRhdGFSZWYuY3VycmVudC5fX291dHNpZGVQcmVzc0J1YmJsZXMgPSBvdXRzaWRlUHJlc3NCdWJibGVzO1xuICAgIGNvbnN0IGNvbXBvc2l0aW9uVGltZW91dCA9IG5ldyBUaW1lb3V0KCk7XG4gICAgY29uc3QgcHJldmVudGVkUHJlc3NTdXBwcmVzc2lvblRpbWVvdXQgPSBuZXcgVGltZW91dCgpO1xuICAgIGZ1bmN0aW9uIGhhbmRsZUNvbXBvc2l0aW9uU3RhcnQoKSB7XG4gICAgICBjb21wb3NpdGlvblRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIGlzQ29tcG9zaW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVDb21wb3NpdGlvbkVuZCgpIHtcbiAgICAgIC8vIFNhZmFyaSBmaXJlcyBgY29tcG9zaXRpb25lbmRgIGJlZm9yZSBga2V5ZG93bmAsIHNvIHdlIG5lZWQgdG8gd2FpdFxuICAgICAgLy8gdW50aWwgdGhlIG5leHQgdGljayB0byBzZXQgYGlzQ29tcG9zaW5nYCB0byBgZmFsc2VgLlxuICAgICAgLy8gaHR0cHM6Ly9idWdzLndlYmtpdC5vcmcvc2hvd19idWcuY2dpP2lkPTE2NTAwNFxuICAgICAgY29tcG9zaXRpb25UaW1lb3V0LnN0YXJ0KFxuICAgICAgLy8gMG1zIG9yIDFtcyBkb24ndCB3b3JrIGluIFNhZmFyaS4gNW1zIGFwcGVhcnMgdG8gY29uc2lzdGVudGx5IHdvcmsuXG4gICAgICAvLyBPbmx5IGFwcGx5IHRvIFdlYktpdCBmb3IgdGhlIHRlc3QgdG8gcmVtYWluIDBtcy5cbiAgICAgIHBsYXRmb3JtLmVuZ2luZS53ZWJraXQgPyA1IDogMCwgKCkgPT4ge1xuICAgICAgICBpc0NvbXBvc2luZ1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gc3VwcHJlc3NJbW1lZGlhdGVPdXRzaWRlQ2xpY2tBZnRlclByZXZlbnRlZFN0YXJ0KCkge1xuICAgICAgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgLy8gRmlyZWZveCBjYW4gZW1pdCB0aGUgc3ludGhldGljIG91dHNpZGUgY2xpY2sgaW4gYSBsYXRlciB0YXNrIGFmdGVyXG4gICAgICAvLyBwb2ludGVyIGxvY2sgZXhpdCwgc28gbWljcm90YXNrIGNsZWFyaW5nIGlzIHRvbyBlYXJseSBoZXJlLlxuICAgICAgcHJldmVudGVkUHJlc3NTdXBwcmVzc2lvblRpbWVvdXQuc3RhcnQoMCwgKCkgPT4ge1xuICAgICAgICBzdXBwcmVzc05leHRPdXRzaWRlQ2xpY2tSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHJlc2V0UHJlc3NTdGFydFN0YXRlKCkge1xuICAgICAgcHJlc3NTdGFydGVkSW5zaWRlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIHByZXNzU3RhcnRQcmV2ZW50ZWRSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRPdXRzaWRlUHJlc3NFdmVudCgpIHtcbiAgICAgIGNvbnN0IHR5cGUgPSBjdXJyZW50UG9pbnRlclR5cGVSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IGNvbXB1dGVkVHlwZSA9IHR5cGUgPT09ICdwZW4nIHx8ICF0eXBlID8gJ21vdXNlJyA6IHR5cGU7XG4gICAgICBjb25zdCBvdXRzaWRlUHJlc3NFdmVudFZhbHVlID0gZ2V0T3V0c2lkZVByZXNzRXZlbnRQcm9wKCk7XG4gICAgICBjb25zdCByZXNvbHZlZCA9IHR5cGVvZiBvdXRzaWRlUHJlc3NFdmVudFZhbHVlID09PSAnZnVuY3Rpb24nID8gb3V0c2lkZVByZXNzRXZlbnRWYWx1ZSgpIDogb3V0c2lkZVByZXNzRXZlbnRWYWx1ZTtcbiAgICAgIGlmICh0eXBlb2YgcmVzb2x2ZWQgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlZDtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNvbHZlZFtjb21wdXRlZFR5cGVdO1xuICAgIH1cbiAgICBmdW5jdGlvbiBzaG91bGRJZ25vcmVFdmVudChldmVudCkge1xuICAgICAgY29uc3QgY29tcHV0ZWRPdXRzaWRlUHJlc3NFdmVudCA9IGdldE91dHNpZGVQcmVzc0V2ZW50KCk7XG4gICAgICByZXR1cm4gY29tcHV0ZWRPdXRzaWRlUHJlc3NFdmVudCA9PT0gJ2ludGVudGlvbmFsJyAmJiBldmVudC50eXBlICE9PSAnY2xpY2snIHx8IGNvbXB1dGVkT3V0c2lkZVByZXNzRXZlbnQgPT09ICdzbG9wcHknICYmIGV2ZW50LnR5cGUgPT09ICdjbGljayc7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzRXZlbnRXaXRoaW5GbG9hdGluZ1RyZWUoZXZlbnQpIHtcbiAgICAgIGNvbnN0IG5vZGVJZCA9IGRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQ/Lm5vZGVJZDtcbiAgICAgIGNvbnN0IHRhcmdldElzSW5zaWRlQ2hpbGRyZW4gPSB0cmVlICYmIGdldE5vZGVDaGlsZHJlbih0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkuc29tZShub2RlID0+IGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIG5vZGUuY29udGV4dD8uZWxlbWVudHMuZmxvYXRpbmcpKTtcbiAgICAgIHJldHVybiBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMoZXZlbnQpIHx8IHRhcmdldElzSW5zaWRlQ2hpbGRyZW47XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNsb3NlT25QcmVzc091dHNpZGUoZXZlbnQpIHtcbiAgICAgIGlmIChzaG91bGRJZ25vcmVFdmVudChldmVudCkpIHtcbiAgICAgICAgLy8gQSBuZXcgcHJlc3MgYmVnYW4gb3V0c2lkZSB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbmQgaXRzIHRyaWdnZXIuIENsZWFyIGFueVxuICAgICAgICAvLyBsZWZ0b3ZlciBkcmFnLW91dCBzdXBwcmVzc2lvbiBzbyB0aGlzIHByZXNzJ3MgZXZlbnR1YWwgY2xpY2sgY2FuIGRpc21pc3MuXG4gICAgICAgIGlmIChldmVudC50eXBlICE9PSAnY2xpY2snICYmICFpc0V2ZW50V2l0aGluT3duRWxlbWVudHMoZXZlbnQpKSB7XG4gICAgICAgICAgcHJldmVudGVkUHJlc3NTdXBwcmVzc2lvblRpbWVvdXQuY2xlYXIoKTtcbiAgICAgICAgICBzdXBwcmVzc05leHRPdXRzaWRlQ2xpY2tSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNsZWFySW5zaWRlUmVhY3RUcmVlKCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChkYXRhUmVmLmN1cnJlbnQuaW5zaWRlUmVhY3RUcmVlKSB7XG4gICAgICAgIGNsZWFySW5zaWRlUmVhY3RUcmVlKCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG4gICAgICBjb25zdCBpbmVydFNlbGVjdG9yID0gYFske2NyZWF0ZUF0dHJpYnV0ZSgnaW5lcnQnKX1dYDtcbiAgICAgIGNvbnN0IHRhcmdldFJvb3QgPSBpc0VsZW1lbnQodGFyZ2V0KSA/IHRhcmdldC5nZXRSb290Tm9kZSgpIDogbnVsbDtcbiAgICAgIGNvbnN0IG1hcmtlcnMgPSBBcnJheS5mcm9tKChpc1NoYWRvd1Jvb3QodGFyZ2V0Um9vdCkgPyB0YXJnZXRSb290IDogb3duZXJEb2N1bWVudChzdG9yZS5zZWxlY3QoJ2Zsb2F0aW5nRWxlbWVudCcpKSkucXVlcnlTZWxlY3RvckFsbChpbmVydFNlbGVjdG9yKSk7XG4gICAgICBjb25zdCB0cmlnZ2VycyA9IHN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzO1xuXG4gICAgICAvLyBJZiBhbm90aGVyIHRyaWdnZXIgaXMgY2xpY2tlZCwgZG9uJ3QgY2xvc2UgdGhlIGZsb2F0aW5nIGVsZW1lbnQuXG4gICAgICBpZiAodGFyZ2V0ICYmICh0cmlnZ2Vycy5oYXNFbGVtZW50KHRhcmdldCkgfHwgdHJpZ2dlcnMuaGFzTWF0Y2hpbmdFbGVtZW50KHRyaWdnZXIgPT4gY29udGFpbnModHJpZ2dlciwgdGFyZ2V0KSkpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGxldCB0YXJnZXRSb290QW5jZXN0b3IgPSBpc0VsZW1lbnQodGFyZ2V0KSA/IHRhcmdldCA6IG51bGw7XG4gICAgICB3aGlsZSAodGFyZ2V0Um9vdEFuY2VzdG9yICYmICFpc0xhc3RUcmF2ZXJzYWJsZU5vZGUodGFyZ2V0Um9vdEFuY2VzdG9yKSkge1xuICAgICAgICBjb25zdCBuZXh0UGFyZW50ID0gZ2V0UGFyZW50Tm9kZSh0YXJnZXRSb290QW5jZXN0b3IpO1xuICAgICAgICBpZiAoaXNMYXN0VHJhdmVyc2FibGVOb2RlKG5leHRQYXJlbnQpIHx8ICFpc0VsZW1lbnQobmV4dFBhcmVudCkpIHtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICB0YXJnZXRSb290QW5jZXN0b3IgPSBuZXh0UGFyZW50O1xuICAgICAgfVxuXG4gICAgICAvLyBDaGVjayBpZiB0aGUgY2xpY2sgb2NjdXJyZWQgb24gYSB0aGlyZC1wYXJ0eSBlbGVtZW50IGluamVjdGVkIGFmdGVyIHRoZVxuICAgICAgLy8gZmxvYXRpbmcgZWxlbWVudCByZW5kZXJlZC5cbiAgICAgIGlmIChtYXJrZXJzLmxlbmd0aCAmJiBpc0VsZW1lbnQodGFyZ2V0KSAmJiAhaXNSb290RWxlbWVudCh0YXJnZXQpICYmXG4gICAgICAvLyBDbGlja2VkIG9uIGEgZGlyZWN0IGFuY2VzdG9yIChlLmcuIEZsb2F0aW5nT3ZlcmxheSkuXG4gICAgICAhY29udGFpbnModGFyZ2V0LCBzdG9yZS5zZWxlY3QoJ2Zsb2F0aW5nRWxlbWVudCcpKSAmJlxuICAgICAgLy8gSWYgdGhlIHRhcmdldCByb290IGVsZW1lbnQgY29udGFpbnMgbm9uZSBvZiB0aGUgbWFya2VycywgdGhlbiB0aGVcbiAgICAgIC8vIGVsZW1lbnQgd2FzIGluamVjdGVkIGFmdGVyIHRoZSBmbG9hdGluZyBlbGVtZW50IHJlbmRlcmVkLlxuICAgICAgbWFya2Vycy5ldmVyeShtYXJrZXIgPT4gIWNvbnRhaW5zKHRhcmdldFJvb3RBbmNlc3RvciwgbWFya2VyKSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBDaGVjayBpZiB0aGUgY2xpY2sgb2NjdXJyZWQgb24gdGhlIHNjcm9sbGJhclxuICAgICAgLy8gU2tpcCBmb3IgdG91Y2ggZXZlbnRzOiBzY3JvbGxiYXJzIGRvbid0IHJlY2VpdmUgdG91Y2ggZXZlbnRzIG9uIG1vc3QgcGxhdGZvcm1zXG4gICAgICBpZiAoaXNIVE1MRWxlbWVudCh0YXJnZXQpICYmICEoJ3RvdWNoZXMnIGluIGV2ZW50KSkge1xuICAgICAgICBjb25zdCBsYXN0VHJhdmVyc2FibGVOb2RlID0gaXNMYXN0VHJhdmVyc2FibGVOb2RlKHRhcmdldCk7XG4gICAgICAgIGNvbnN0IHN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZSh0YXJnZXQpO1xuICAgICAgICBjb25zdCBzY3JvbGxSZSA9IC9hdXRvfHNjcm9sbC87XG4gICAgICAgIGNvbnN0IGlzU2Nyb2xsYWJsZVggPSBsYXN0VHJhdmVyc2FibGVOb2RlIHx8IHNjcm9sbFJlLnRlc3Qoc3R5bGUub3ZlcmZsb3dYKTtcbiAgICAgICAgY29uc3QgaXNTY3JvbGxhYmxlWSA9IGxhc3RUcmF2ZXJzYWJsZU5vZGUgfHwgc2Nyb2xsUmUudGVzdChzdHlsZS5vdmVyZmxvd1kpO1xuICAgICAgICBjb25zdCBjYW5TY3JvbGxYID0gaXNTY3JvbGxhYmxlWCAmJiB0YXJnZXQuY2xpZW50V2lkdGggPiAwICYmIHRhcmdldC5zY3JvbGxXaWR0aCA+IHRhcmdldC5jbGllbnRXaWR0aDtcbiAgICAgICAgY29uc3QgY2FuU2Nyb2xsWSA9IGlzU2Nyb2xsYWJsZVkgJiYgdGFyZ2V0LmNsaWVudEhlaWdodCA+IDAgJiYgdGFyZ2V0LnNjcm9sbEhlaWdodCA+IHRhcmdldC5jbGllbnRIZWlnaHQ7XG4gICAgICAgIGNvbnN0IGlzUlRMID0gc3R5bGUuZGlyZWN0aW9uID09PSAncnRsJztcblxuICAgICAgICAvLyBDaGVjayBjbGljayBwb3NpdGlvbiByZWxhdGl2ZSB0byBzY3JvbGxiYXIuXG4gICAgICAgIC8vIEluIHNvbWUgYnJvd3NlcnMgaXQgaXMgcG9zc2libGUgdG8gY2hhbmdlIHRoZSA8Ym9keT4gKG9yIHdpbmRvdylcbiAgICAgICAgLy8gc2Nyb2xsYmFyIHRvIHRoZSBsZWZ0IHNpZGUsIGJ1dCBpcyB2ZXJ5IHJhcmUgYW5kIGlzIGRpZmZpY3VsdCB0b1xuICAgICAgICAvLyBjaGVjayBmb3IuIFBsdXMsIGZvciBtb2RhbCBkaWFsb2dzIHdpdGggYmFja2Ryb3BzLCBpdCBpcyBtb3JlXG4gICAgICAgIC8vIGltcG9ydGFudCB0aGF0IHRoZSBiYWNrZHJvcCBpcyBjaGVja2VkIGJ1dCBub3Qgc28gbXVjaCB0aGUgd2luZG93LlxuICAgICAgICBjb25zdCBwcmVzc2VkVmVydGljYWxTY3JvbGxiYXIgPSBjYW5TY3JvbGxZICYmIChpc1JUTCA/IGV2ZW50Lm9mZnNldFggPD0gdGFyZ2V0Lm9mZnNldFdpZHRoIC0gdGFyZ2V0LmNsaWVudFdpZHRoIDogZXZlbnQub2Zmc2V0WCA+IHRhcmdldC5jbGllbnRXaWR0aCk7XG4gICAgICAgIGNvbnN0IHByZXNzZWRIb3Jpem9udGFsU2Nyb2xsYmFyID0gY2FuU2Nyb2xsWCAmJiBldmVudC5vZmZzZXRZID4gdGFyZ2V0LmNsaWVudEhlaWdodDtcbiAgICAgICAgaWYgKHByZXNzZWRWZXJ0aWNhbFNjcm9sbGJhciB8fCBwcmVzc2VkSG9yaXpvbnRhbFNjcm9sbGJhcikge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGlzRXZlbnRXaXRoaW5GbG9hdGluZ1RyZWUoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gSW4gaW50ZW50aW9uYWwgbW9kZSwgYSBwcmVzcyB0aGF0IHN0YXJ0cyBpbnNpZGUgYW5kIGVuZHMgb3V0c2lkZSBnZXRzXG4gICAgICAvLyBvbmUgc3VwcHJlc3NlZCBvdXRzaWRlIGNsaWNrLiBSdW4gdGhpcyBhZnRlciBpbnNpZGUtdGFyZ2V0IGNoZWNrcyBzb1xuICAgICAgLy8gaW5zaWRlIGNsaWNrcyBkb24ndCBjb25zdW1lIHRoZSBvbmUtc2hvdCBzdXBwcmVzc2lvbi5cbiAgICAgIGlmIChnZXRPdXRzaWRlUHJlc3NFdmVudCgpID09PSAnaW50ZW50aW9uYWwnICYmIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50KSB7XG4gICAgICAgIHByZXZlbnRlZFByZXNzU3VwcHJlc3Npb25UaW1lb3V0LmNsZWFyKCk7XG4gICAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2Ygb3V0c2lkZVByZXNzID09PSAnZnVuY3Rpb24nICYmICFvdXRzaWRlUHJlc3MoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChoYXNCbG9ja2luZ0NoaWxkKCdfX291dHNpZGVQcmVzc0J1YmJsZXMnKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5vdXRzaWRlUHJlc3MsIGV2ZW50KSk7XG4gICAgICBjbGVhckluc2lkZVJlYWN0VHJlZSgpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVQb2ludGVyRG93bihldmVudCkge1xuICAgICAgaWYgKGdldE91dHNpZGVQcmVzc0V2ZW50KCkgIT09ICdzbG9wcHknIHx8IGV2ZW50LnBvaW50ZXJUeXBlID09PSAndG91Y2gnIHx8ICFzdG9yZS5zZWxlY3QoJ29wZW4nKSB8fCAhZW5hYmxlZCB8fCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNsb3NlT25QcmVzc091dHNpZGUoZXZlbnQpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVUb3VjaFN0YXJ0KGV2ZW50KSB7XG4gICAgICBpZiAoZ2V0T3V0c2lkZVByZXNzRXZlbnQoKSAhPT0gJ3Nsb3BweScgfHwgIXN0b3JlLnNlbGVjdCgnb3BlbicpIHx8ICFlbmFibGVkIHx8IGlzRXZlbnRXaXRoaW5Pd25FbGVtZW50cyhldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgdG91Y2ggPSBldmVudC50b3VjaGVzWzBdO1xuICAgICAgaWYgKHRvdWNoKSB7XG4gICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudCA9IHtcbiAgICAgICAgICBzdGFydFRpbWU6IERhdGUubm93KCksXG4gICAgICAgICAgc3RhcnRYOiB0b3VjaC5jbGllbnRYLFxuICAgICAgICAgIHN0YXJ0WTogdG91Y2guY2xpZW50WSxcbiAgICAgICAgICBkaXNtaXNzT25Ub3VjaEVuZDogZmFsc2UsXG4gICAgICAgICAgZGlzbWlzc09uTW91c2VEb3duOiB0cnVlXG4gICAgICAgIH07XG4gICAgICAgIGNhbmNlbERpc21pc3NPbkVuZFRpbWVvdXQuc3RhcnQoMTAwMCwgKCkgPT4ge1xuICAgICAgICAgIGlmICh0b3VjaFN0YXRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudC5kaXNtaXNzT25Ub3VjaEVuZCA9IGZhbHNlO1xuICAgICAgICAgICAgdG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPbk1vdXNlRG93biA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGFkZFRhcmdldEV2ZW50TGlzdGVuZXJPbmNlKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGlmICghdGFyZ2V0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gYWRkRXZlbnRMaXN0ZW5lcih0YXJnZXQsIGV2ZW50LnR5cGUsICgpID0+IHtcbiAgICAgICAgbGlzdGVuZXIoZXZlbnQpO1xuICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVRvdWNoU3RhcnRDYXB0dXJlKGV2ZW50KSB7XG4gICAgICBjdXJyZW50UG9pbnRlclR5cGVSZWYuY3VycmVudCA9ICd0b3VjaCc7XG4gICAgICBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgaGFuZGxlVG91Y2hTdGFydCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlKGV2ZW50KSB7XG4gICAgICBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0LmNsZWFyKCk7XG4gICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ3BvaW50ZXJkb3duJykge1xuICAgICAgICBjdXJyZW50UG9pbnRlclR5cGVSZWYuY3VycmVudCA9IGV2ZW50LnBvaW50ZXJUeXBlO1xuICAgICAgfVxuICAgICAgaWYgKGV2ZW50LnR5cGUgPT09ICdtb3VzZWRvd24nICYmIHRvdWNoU3RhdGVSZWYuY3VycmVudCAmJiAhdG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPbk1vdXNlRG93bikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgdGFyZ2V0RXZlbnQgPT4ge1xuICAgICAgICBpZiAodGFyZ2V0RXZlbnQudHlwZSA9PT0gJ3BvaW50ZXJkb3duJykge1xuICAgICAgICAgIGhhbmRsZVBvaW50ZXJEb3duKHRhcmdldEV2ZW50KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjbG9zZU9uUHJlc3NPdXRzaWRlKHRhcmdldEV2ZW50KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVByZXNzRW5kQ2FwdHVyZShldmVudCkge1xuICAgICAgaWYgKCFwcmVzc1N0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBwcmVzc1N0YXJ0ZWRJbnNpZGVEZWZhdWx0UHJldmVudGVkID0gcHJlc3NTdGFydFByZXZlbnRlZFJlZi5jdXJyZW50O1xuICAgICAgcmVzZXRQcmVzc1N0YXJ0U3RhdGUoKTtcbiAgICAgIGlmIChnZXRPdXRzaWRlUHJlc3NFdmVudCgpICE9PSAnaW50ZW50aW9uYWwnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChldmVudC50eXBlID09PSAncG9pbnRlcmNhbmNlbCcpIHtcbiAgICAgICAgaWYgKHByZXNzU3RhcnRlZEluc2lkZURlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgICBzdXBwcmVzc0ltbWVkaWF0ZU91dHNpZGVDbGlja0FmdGVyUHJldmVudGVkU3RhcnQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoaXNFdmVudFdpdGhpbkZsb2F0aW5nVHJlZShldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBJZiBwb2ludGVyZG93biB3YXMgcHJldmVudGVkLCBubyBjbGljayBtYXkgYmUgZ2VuZXJhdGVkIGZvciB0aGF0XG4gICAgICAvLyBpbnRlcmFjdGlvbi4gSG93ZXZlciwgRmlyZWZveCBtYXkgc3RpbGwgZW1pdCBhbiBpbW1lZGlhdGUgY2xpY2sgYWZ0ZXJcbiAgICAgIC8vIHBvaW50ZXJ1cCAoZS5nLiBOdW1iZXJGaWVsZCBzY3J1YiB3aXRoIHBvaW50ZXIgbG9jayksIHNvIHN1cHByZXNzIGZvclxuICAgICAgLy8gb25lIHRpY2sgdG8gYWJzb3JiIHRoYXQgc3ludGhldGljIGNsaWNrIG9ubHkuXG4gICAgICBpZiAocHJlc3NTdGFydGVkSW5zaWRlRGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICBzdXBwcmVzc0ltbWVkaWF0ZU91dHNpZGVDbGlja0FmdGVyUHJldmVudGVkU3RhcnQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBBdm9pZCBzdXBwcmVzc2luZyB3aGVuIG91dHNpZGVQcmVzcyBleHBsaWNpdGx5IGlnbm9yZXMgdGhpcyB0YXJnZXQuXG4gICAgICBpZiAodHlwZW9mIG91dHNpZGVQcmVzcyA9PT0gJ2Z1bmN0aW9uJyAmJiAhb3V0c2lkZVByZXNzKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBwcmV2ZW50ZWRQcmVzc1N1cHByZXNzaW9uVGltZW91dC5jbGVhcigpO1xuICAgICAgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgY2xlYXJJbnNpZGVSZWFjdFRyZWUoKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlVG91Y2hNb3ZlKGV2ZW50KSB7XG4gICAgICBpZiAoZ2V0T3V0c2lkZVByZXNzRXZlbnQoKSAhPT0gJ3Nsb3BweScgfHwgIXRvdWNoU3RhdGVSZWYuY3VycmVudCB8fCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHRvdWNoID0gZXZlbnQudG91Y2hlc1swXTtcbiAgICAgIGlmICghdG91Y2gpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgZGVsdGFYID0gTWF0aC5hYnModG91Y2guY2xpZW50WCAtIHRvdWNoU3RhdGVSZWYuY3VycmVudC5zdGFydFgpO1xuICAgICAgY29uc3QgZGVsdGFZID0gTWF0aC5hYnModG91Y2guY2xpZW50WSAtIHRvdWNoU3RhdGVSZWYuY3VycmVudC5zdGFydFkpO1xuICAgICAgY29uc3QgZGlzdGFuY2UgPSBNYXRoLnNxcnQoZGVsdGFYICogZGVsdGFYICsgZGVsdGFZICogZGVsdGFZKTtcbiAgICAgIGlmIChkaXN0YW5jZSA+IDUpIHtcbiAgICAgICAgdG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPblRvdWNoRW5kID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChkaXN0YW5jZSA+IDEwKSB7XG4gICAgICAgIGNsb3NlT25QcmVzc091dHNpZGUoZXZlbnQpO1xuICAgICAgICBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0LmNsZWFyKCk7XG4gICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVRvdWNoTW92ZUNhcHR1cmUoZXZlbnQpIHtcbiAgICAgIGFkZFRhcmdldEV2ZW50TGlzdGVuZXJPbmNlKGV2ZW50LCBoYW5kbGVUb3VjaE1vdmUpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVUb3VjaEVuZChldmVudCkge1xuICAgICAgaWYgKGdldE91dHNpZGVQcmVzc0V2ZW50KCkgIT09ICdzbG9wcHknIHx8ICF0b3VjaFN0YXRlUmVmLmN1cnJlbnQgfHwgaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPblRvdWNoRW5kKSB7XG4gICAgICAgIGNsb3NlT25QcmVzc091dHNpZGUoZXZlbnQpO1xuICAgICAgfVxuICAgICAgY2FuY2VsRGlzbWlzc09uRW5kVGltZW91dC5jbGVhcigpO1xuICAgICAgdG91Y2hTdGF0ZVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlVG91Y2hFbmRDYXB0dXJlKGV2ZW50KSB7XG4gICAgICBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgaGFuZGxlVG91Y2hFbmQpO1xuICAgIH1cbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KGZsb2F0aW5nRWxlbWVudCk7XG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSBtZXJnZUNsZWFudXBzKGVzY2FwZUtleSAmJiBtZXJnZUNsZWFudXBzKGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAna2V5ZG93bicsIGNsb3NlT25Fc2NhcGVLZXlEb3duKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdjb21wb3NpdGlvbnN0YXJ0JywgaGFuZGxlQ29tcG9zaXRpb25TdGFydCksIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAnY29tcG9zaXRpb25lbmQnLCBoYW5kbGVDb21wb3NpdGlvbkVuZCkpLCBvdXRzaWRlUHJlc3NFbmFibGVkICYmIG1lcmdlQ2xlYW51cHMoYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdjbGljaycsIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVyZG93bicsIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVydXAnLCBoYW5kbGVQcmVzc0VuZENhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3BvaW50ZXJjYW5jZWwnLCBoYW5kbGVQcmVzc0VuZENhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ21vdXNlZG93bicsIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdtb3VzZXVwJywgaGFuZGxlUHJlc3NFbmRDYXB0dXJlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICd0b3VjaHN0YXJ0JywgaGFuZGxlVG91Y2hTdGFydENhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3RvdWNobW92ZScsIGhhbmRsZVRvdWNoTW92ZUNhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3RvdWNoZW5kJywgaGFuZGxlVG91Y2hFbmRDYXB0dXJlLCB0cnVlKSkpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgY29tcG9zaXRpb25UaW1lb3V0LmNsZWFyKCk7XG4gICAgICBwcmV2ZW50ZWRQcmVzc1N1cHByZXNzaW9uVGltZW91dC5jbGVhcigpO1xuICAgICAgcmVzZXRQcmVzc1N0YXJ0U3RhdGUoKTtcbiAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBjbGVhckluc2lkZVJlYWN0VHJlZSgpO1xuICAgIH07XG4gIH0sIFtkYXRhUmVmLCBmbG9hdGluZ0VsZW1lbnQsIGVzY2FwZUtleSwgb3V0c2lkZVByZXNzRW5hYmxlZCwgb3V0c2lkZVByZXNzLCBvcGVuLCBlbmFibGVkLCBlc2NhcGVLZXlCdWJibGVzLCBvdXRzaWRlUHJlc3NCdWJibGVzLCBjbG9zZU9uRXNjYXBlS2V5RG93biwgY2xlYXJJbnNpZGVSZWFjdFRyZWUsIGdldE91dHNpZGVQcmVzc0V2ZW50UHJvcCwgaGFzQmxvY2tpbmdDaGlsZCwgaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzLCB0cmVlLCBzdG9yZSwgY2FuY2VsRGlzbWlzc09uRW5kVGltZW91dF0pO1xuICBjb25zdCByZWZlcmVuY2UgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgb25LZXlEb3duOiBjbG9zZU9uRXNjYXBlS2V5RG93bixcbiAgICBvblBvaW50ZXJEb3duOiBjbG9zZU9uUmVmZXJlbmNlUHJlc3MsXG4gICAgb25DbGljazogY2xvc2VPblJlZmVyZW5jZVByZXNzXG4gIH0pLCBbY2xvc2VPbkVzY2FwZUtleURvd24sIGNsb3NlT25SZWZlcmVuY2VQcmVzc10pO1xuICBjb25zdCBmbG9hdGluZyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBvbktleURvd246IGNsb3NlT25Fc2NhcGVLZXlEb3duLFxuICAgIC8vIGBvbk1vdXNlRG93bmAgbWF5IGJlIGJsb2NrZWQgaWYgYGV2ZW50LnByZXZlbnREZWZhdWx0KClgIGlzIGNhbGxlZCBpblxuICAgIC8vIGBvblBvaW50ZXJEb3duYCwgc3VjaCBhcyB3aXRoIDxOdW1iZXJGaWVsZC5TY3J1YkFyZWE+LlxuICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vbXVpL2Jhc2UtdWkvcHVsbC8zMzc5XG4gICAgb25Qb2ludGVyRG93bjogbWFya0luc2lkZVByZXNzU3RhcnRQcmV2ZW50ZWQsXG4gICAgb25Nb3VzZURvd246IG1hcmtJbnNpZGVQcmVzc1N0YXJ0UHJldmVudGVkLFxuICAgIG9uQ2xpY2tDYXB0dXJlOiBtYXJrSW5zaWRlUmVhY3RUcmVlLFxuICAgIG9uTW91c2VEb3duQ2FwdHVyZShldmVudCkge1xuICAgICAgbWFya0luc2lkZVJlYWN0VHJlZSgpO1xuICAgICAgbWFya1ByZXNzU3RhcnRlZEluc2lkZVJlYWN0VHJlZShldmVudCk7XG4gICAgfSxcbiAgICBvblBvaW50ZXJEb3duQ2FwdHVyZShldmVudCkge1xuICAgICAgbWFya0luc2lkZVJlYWN0VHJlZSgpO1xuICAgICAgbWFya1ByZXNzU3RhcnRlZEluc2lkZVJlYWN0VHJlZShldmVudCk7XG4gICAgfSxcbiAgICBvbk1vdXNlVXBDYXB0dXJlOiBtYXJrSW5zaWRlUmVhY3RUcmVlLFxuICAgIG9uVG91Y2hFbmRDYXB0dXJlOiBtYXJrSW5zaWRlUmVhY3RUcmVlLFxuICAgIG9uVG91Y2hNb3ZlQ2FwdHVyZTogbWFya0luc2lkZVJlYWN0VHJlZVxuICB9KSwgW2Nsb3NlT25Fc2NhcGVLZXlEb3duLCBtYXJrSW5zaWRlUmVhY3RUcmVlLCBtYXJrUHJlc3NTdGFydGVkSW5zaWRlUmVhY3RUcmVlLCBtYXJrSW5zaWRlUHJlc3NTdGFydFByZXZlbnRlZF0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBlbmFibGVkID8ge1xuICAgIHJlZmVyZW5jZSxcbiAgICBmbG9hdGluZyxcbiAgICB0cmlnZ2VyOiByZWZlcmVuY2VcbiAgfSA6IHt9LCBbZW5hYmxlZCwgcmVmZXJlbmNlLCBmbG9hdGluZ10pO1xufSIsImltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCB7IEFuaW1hdGlvbkZyYW1lIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlQW5pbWF0aW9uRnJhbWUnO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuXG4vKipcbiAqIE1pbmltYWwgc3RvcmUgY29udHJhY3QgZXhwb3NlZCBieSBwb3B1cCBoYW5kbGVzIHRvIGRldGFjaGVkIHRyaWdnZXJzLlxuICpcbiAqIERldGFjaGVkIHRyaWdnZXJzIHJlYWQgYHN0b3JlYCBkdXJpbmcgcmVuZGVyIGFuZCBzdWJzY3JpYmUgdG8gYmUgbm90aWZpZWQgd2hlbiB0aGUgaGFuZGxlIHN3aXRjaGVzXG4gKiBiZXR3ZWVuIGl0cyBmYWxsYmFjayBzdG9yZSBhbmQgYSByb290J3MgbGl2ZSBzdG9yZS5cbiAqXG4gKiBAdGVtcGxhdGUgSGFuZGxlU3RvcmUgU3RvcmUgc2hhcGUgZXhwb3NlZCB0byBkZXRhY2hlZCB0cmlnZ2Vycy5cbiAqL1xuXG4vKipcbiAqIFN0b3JlIHNoYXBlIGhvbGRpbmcgYSB0cmlnZ2VyIHJlZ2lzdHJ5LCByZXF1aXJlZCBieSBgQmFzZVBvcHVwSGFuZGxlLm9wZW5CeVRyaWdnZXJgIHRvIHJlc29sdmUgYVxuICogdHJpZ2dlciBlbGVtZW50IGJ5IGlkIG9uIGJvdGggdGhlIGF0dGFjaGVkIHJvb3QncyBzdG9yZSBhbmQgdGhlIGZhbGxiYWNrIHN0b3JlLlxuICovXG5cbi8qKlxuICogU3RvcmUgc2hhcGUgcmVxdWlyZWQgYnkgYEJhc2VQb3B1cEhhbmRsZS5vcGVuQnlUcmlnZ2VyYC9gY2xvc2VQb3B1cGAgdG8gZHJpdmUgb3Blbi9jbG9zZSBzdGF0ZS5cbiAqIE9ubHkgdGhlIHJvb3Qtb3duZWQgYFN0b3JlYCBuZWVkcyB0aGlzIOKAlCB0aGUgYEhhbmRsZVN0b3JlYCB2aWV3IGV4cG9zZWQgdG8gZGV0YWNoZWQgdHJpZ2dlcnMgbWF5XG4gKiBvbWl0IGBzZXRPcGVuYCBlbnRpcmVseSAoYXMgRGlhbG9nIGFuZCBQcmV2aWV3Q2FyZCdzIGRvKSBzaW5jZSBpdCBpcyBuZXZlciBjYWxsZWQgd2hpbGUgZGV0YWNoZWQuXG4gKi9cblxuLyoqXG4gKiBTaGFyZWQgaW1wbGVtZW50YXRpb24gZm9yIHBvcHVwIGhhbmRsZXMgdGhhdCBjb29yZGluYXRlIGRldGFjaGVkIHRyaWdnZXJzIHdpdGggYSBtb3VudGVkIHJvb3QuXG4gKlxuICogU3ViY2xhc3NlcyBwcm92aWRlIHRoZSBjb21wb25lbnQtc3BlY2lmaWMgaW1wZXJhdGl2ZSBtZXRob2RzLCB3aGlsZSB0aGlzIGJhc2UgY2xhc3Mgb3ducyB0aGVcbiAqIGZhbGxiYWNrIHN0b3JlLCByb290IHN0b3JlIGF0dGFjaG1lbnQgc3RhY2ssIHN1YnNjcmliZXIgbm90aWZpY2F0aW9ucywgYW5kIGRldmVsb3BtZW50IHdhcm5pbmcgZm9yXG4gKiBvdmVybGFwcGluZyByb290cy5cbiAqXG4gKiBAdGVtcGxhdGUgSGFuZGxlU3RvcmUgU3RvcmUgc2hhcGUgZXhwb3NlZCB0byBkZXRhY2hlZCB0cmlnZ2Vycy5cbiAqIEB0ZW1wbGF0ZSBTdG9yZSBSb290LW93bmVkIHN0b3JlIGF0dGFjaGVkIGJ5IHRoZSBjb21wb25lbnQgcm9vdC5cbiAqL1xuZXhwb3J0IGNsYXNzIEJhc2VQb3B1cEhhbmRsZSB7XG4gIC8qKlxuICAgKiBTdG9yZXMgb2YgZXZlcnkgcm9vdCBjdXJyZW50bHkgdXNpbmcgdGhpcyBoYW5kbGUsIGluIGF0dGFjaCBvcmRlci4gQSBoYW5kbGUgaXMgbWVhbnQgdG8gYmUgdXNlZFxuICAgKiBieSBhIHNpbmdsZSBtb3VudGVkIHJvb3QsIGJ1dCByb290cyBjYW4gdHJhbnNpZW50bHkgb3ZlcmxhcCAoZS5nLiBkdXJpbmcgYW4gYW5pbWF0ZWQgcm91dGVcbiAgICogdHJhbnNpdGlvbiksIHNvIHRoaXMgc3RhY2sgbGV0cyBgYXR0YWNoU3RvcmVgJ3MgY2xlYW51cCByZXN0b3JlIHRoZSBwcmV2aW91cyByb290IGluc3RlYWQgb2ZcbiAgICogbGVhdmluZyBhIHN0aWxsLW1vdW50ZWQgcm9vdCB1bmNvbnRyb2xsYWJsZSB3aGVuIGEgbmV3ZXIgb3ZlcmxhcHBpbmcgcm9vdCBkZXRhY2hlcyBmaXJzdC5cbiAgICovXG4gIGF0dGFjaGVkU3RvcmVzID0gW107XG5cbiAgLyoqXG4gICAqIFN0b3JlIG9mIHRoZSByb290IHRoYXQgY3VycmVudGx5IGNvbnRyb2xzIHRoZSBoYW5kbGU6IHRoZSBtb3N0IHJlY2VudGx5IGF0dGFjaGVkIG9uZSBzdGlsbFxuICAgKiBtb3VudGVkLCBvciBgbnVsbGAgd2hlbiBubyByb290IGlzIGF0dGFjaGVkLiBJbXBlcmF0aXZlIG1ldGhvZHMgYXJlIG5vLW9wcyB3aGlsZSB0aGlzIGlzIGBudWxsYC5cbiAgICovXG4gIGF0dGFjaGVkU3RvcmVWYWx1ZSA9IG51bGw7XG5cbiAgLyoqXG4gICAqIExpc3RlbmVycyBub3RpZmllZCB3aGVuIGBhdHRhY2hlZFN0b3JlYCBjaGFuZ2VzLCBzbyBkZXRhY2hlZCB0cmlnZ2VycyBjYW4gZm9sbG93IHRoZSBzdG9yZSBwb2ludGVyLlxuICAgKi9cbiAgc3RvcmVMaXN0ZW5lcnMgPSBuZXcgU2V0KCk7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBoYW5kbGUgYmFja2VkIGJ5IHRoZSBzdG9yZSB1c2VkIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQuXG4gICAqXG4gICAqIEBwYXJhbSBmYWxsYmFja1N0b3JlIEluZXJ0LCBjbG9zZWQgc3RvcmUgaGFuZGVkIHRvIGRldGFjaGVkIHRyaWdnZXJzIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQsXG4gICAqIHNvIHRoZXkgY2FuIHJlbmRlciBhbmQgcmVnaXN0ZXIgd2l0aG91dCBhIG1vdW50ZWQgcm9vdC4gVHJpZ2dlcnMgcmVnaXN0ZXIgaW50byB3aGljaGV2ZXIgc3RvcmVcbiAgICogYHN0b3JlYCBjdXJyZW50bHkgcmVzb2x2ZXMgdG8sIHNvIHdoaWxlIGRldGFjaGVkIHRoZXkgbGl2ZSBpbiB0aGlzIHN0b3JlJ3MgdHJpZ2dlciBtYXAgYW5kXG4gICAqIG1pZ3JhdGUgdGhlbXNlbHZlcyB0byB0aGUgcm9vdCdzIHN0b3JlIChhbmQgYmFjaykgYXMgaXQgYXR0YWNoZXMvZGV0YWNoZXMuXG4gICAqIEBwYXJhbSBjb21wb25lbnROYW1lIENvbXBvbmVudCBuYW1lIHVzZWQgdG8gcHJlZml4IGRldiB3YXJuaW5ncywgZS5nLiBgJ01lbnUnYCBwcm9kdWNlc1xuICAgKiBgTWVudUhhbmRsZS5vcGVuKClgIGluIHdhcm5pbmcgdGV4dC5cbiAgICogQHBhcmFtIHRocm93T25NaXNzaW5nVHJpZ2dlciBXaGV0aGVyIGBvcGVuKHRyaWdnZXJJZClgIHRocm93cyB3aGVuIG5vIHRyaWdnZXIgd2l0aCB0aGF0IGlkIGlzXG4gICAqIHJlZ2lzdGVyZWQuIEFuY2hvcmVkIHBvcHVwcyAoTWVudSwgUG9wb3ZlciwgVG9vbHRpcCwgUHJldmlld0NhcmQpIG5lZWQgYSB0cmlnZ2VyIHRvIGFuY2hvciB0byxcbiAgICogc28gdGhleSB0aHJvdzsgRGlhbG9nIGlzIG5vdCBhbmNob3JlZCBhbmQgaW5zdGVhZCBvcGVucyB1bmFzc29jaWF0ZWQgd2l0aCBhIGRldiB3YXJuaW5nLlxuICAgKi9cbiAgY29uc3RydWN0b3IoZmFsbGJhY2tTdG9yZSwgY29tcG9uZW50TmFtZSwgdGhyb3dPbk1pc3NpbmdUcmlnZ2VyID0gdHJ1ZSkge1xuICAgIHRoaXMuZmFsbGJhY2tTdG9yZSA9IGZhbGxiYWNrU3RvcmU7XG4gICAgdGhpcy5jb21wb25lbnROYW1lID0gY29tcG9uZW50TmFtZTtcbiAgICB0aGlzLnRocm93T25NaXNzaW5nVHJpZ2dlciA9IHRocm93T25NaXNzaW5nVHJpZ2dlcjtcbiAgfVxuICBnZXQgYXR0YWNoZWRTdG9yZSgpIHtcbiAgICByZXR1cm4gdGhpcy5hdHRhY2hlZFN0b3JlVmFsdWU7XG4gIH1cblxuICAvKipcbiAgICogU3RvcmUgdGhhdCBkZXRhY2hlZCB0cmlnZ2VycyByZWFkIGZyb206IHRoZSBhdHRhY2hlZCByb290J3Mgc3RvcmUsIG9yIGFuIGluZXJ0IGZhbGxiYWNrIHN0b3JlXG4gICAqIHVzZWQgd2hpbGUgbm8gcm9vdCBpcyBhdHRhY2hlZC5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBnZXQgc3RvcmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuYXR0YWNoZWRTdG9yZVZhbHVlID8/IHRoaXMuZmFsbGJhY2tTdG9yZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdGFibGUgZmFsbGJhY2sgc3RvcmUgdXNlZCBmb3Igc2VydmVyIHJlbmRlcmluZyBhbmQgaHlkcmF0aW9uLiBSb290IHN0b3JlcyBjYW5ub3QgYmUgcmVjb3JkZWQgb25cbiAgICogdGhlIGhhbmRsZSBkdXJpbmcgcmVuZGVyIGJlY2F1c2UgYSBoYW5kbGUgY2FuIGJlIHNoYXJlZCBieSBjb25jdXJyZW50IHNlcnZlci1yZW5kZXJlZCByZXF1ZXN0cy5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBnZXQgc2VydmVyU3RvcmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZmFsbGJhY2tTdG9yZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmVzIHRvIGNoYW5nZXMgb2YgdGhlIGF0dGFjaGVkIHN0b3JlIHBvaW50ZXIgc28gZGV0YWNoZWQgdHJpZ2dlcnMgcmUtcmVuZGVyIGFuZCByZS1iaW5kXG4gICAqIHdoZW4gYSByb290IGF0dGFjaGVzIG9yIGRldGFjaGVzLiBSZXR1cm5zIGEgZnVuY3Rpb24gdGhhdCByZW1vdmVzIHRoZSBsaXN0ZW5lci5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBzdWJzY3JpYmVTdG9yZShsaXN0ZW5lcikge1xuICAgIHRoaXMuc3RvcmVMaXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgdGhpcy5zdG9yZUxpc3RlbmVycy5kZWxldGUobGlzdGVuZXIpO1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogUG9pbnRzIHRoZSBoYW5kbGUgYXQgYSByb290J3Mgc3RvcmUgYW5kIG5vdGlmaWVzIHN1YnNjcmliZXJzIHNvIGRldGFjaGVkIHRyaWdnZXJzIHJlLXJlbmRlciBhbmRcbiAgICogcmUtcmVnaXN0ZXIgaW50byBpdCAodGhlaXIgcmVnaXN0cmF0aW9uIHJlZiByZS1maXJlcyBvbiB0aGUgc3RvcmUtcG9pbnRlciBjaGFuZ2UpLiBSZXR1cm5zIGFcbiAgICogY2xlYW51cCBmdW5jdGlvbiB0aGF0IGRldGFjaGVzIHRoZSBzdG9yZSBhZ2Fpbi5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBhdHRhY2hTdG9yZShuZXdTdG9yZSkge1xuICAgIHRoaXMuYXR0YWNoZWRTdG9yZXMucHVzaChuZXdTdG9yZSk7XG4gICAgdGhpcy5zZXRBY3RpdmVTdG9yZShuZXdTdG9yZSk7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIGlmICh0aGlzLmF0dGFjaGVkU3RvcmVzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgLy8gTW9yZSB0aGFuIG9uZSByb290IGlzIGF0dGFjaGVkIGF0IG9uY2UuIFRoaXMgaXMgdXN1YWxseSBhIHRyYW5zaWVudCBvdmVybGFwIGR1cmluZyBhblxuICAgICAgICAvLyBhbmltYXRlZCByb3V0ZSB0cmFuc2l0aW9uLCB3aGVyZSB0aGUgb3V0Z29pbmcgcm9vdCB1bm1vdW50cyBzaG9ydGx5IGFmdGVyIHRoZSBpbmNvbWluZ1xuICAgICAgICAvLyBvbmUgbW91bnRzLiBEZWZlciB0aGUgY2hlY2sgYnkgYSBmcmFtZSBhbmQgb25seSB3YXJuIGlmIHRoZSBvdmVybGFwIGlzIHN0aWxsIHByZXNlbnQgb25jZVxuICAgICAgICAvLyB0aGUgdHJhbnNpdGlvbiBoYXMgc2V0dGxlZCAobW9yZSB0aGFuIG9uZSByb290IHN0YXllZCBtb3VudGVkKSwgc28gYSBjbGVhbiBoYW5kb2ZmIGRvZXNuJ3RcbiAgICAgICAgLy8gd2FybiByZWdhcmRsZXNzIG9mIHRoZSBleGFjdCB1bm1vdW50IHRpbWluZy5cbiAgICAgICAgLy8gVGhlIHdhcm5pbmcgZnJhbWUgb25seSBleGlzdHMgaW4gZGV2ZWxvcG1lbnQ7IGl0IGlzIGNyZWF0ZWQgbGF6aWx5IHNvIGl0IG5ldmVyIGFwcGVhcnMgb25cbiAgICAgICAgLy8gaW5zdGFuY2VzIGluIHByb2R1Y3Rpb24gKGxpa2UgYGNvbnRyb2xsZWRWYWx1ZXNgIGluIGBSZWFjdFN0b3JlYCkuXG4gICAgICAgIGNvbnN0IGRldiA9IHRoaXM7XG4gICAgICAgIChkZXYub3ZlcmxhcFdhcm5pbmdGcmFtZSA/Pz0gQW5pbWF0aW9uRnJhbWUuY3JlYXRlKCkpLnJlcXVlc3QoKCkgPT4ge1xuICAgICAgICAgIGlmICh0aGlzLmF0dGFjaGVkU3RvcmVzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignQmFzZSBVSTogQSBoYW5kbGUgaXMgYXR0YWNoZWQgdG8gbW9yZSB0aGFuIG9uZSBtb3VudGVkIHJvb3QgYXQgdGhlIHNhbWUgdGltZS4gJyArICdUaGUgbW9zdCByZWNlbnRseSBtb3VudGVkIHJvb3QgdGFrZXMgb3ZlciBhbmQgdGhlIHByZXZpb3VzIG9uZSBzdG9wcyBiZWluZyBjb250cm9sbGVkIGJ5IHRoZSBoYW5kbGUuICcgKyAnQSBoYW5kbGUgc2hvdWxkIGJlIHVzZWQgYnkgYSBzaW5nbGUgcm9vdCB0aGF0IHN0YXlzIG1vdW50ZWQgZm9yIHRoZSBsaWZldGltZSBvZiB0aGUgaGFuZGxlLicpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjb25zdCBpbmRleCA9IHRoaXMuYXR0YWNoZWRTdG9yZXMubGFzdEluZGV4T2YobmV3U3RvcmUpO1xuICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICB0aGlzLmF0dGFjaGVkU3RvcmVzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICB9XG4gICAgICAvLyBSZXN0b3JlIGNvbnRyb2wgdG8gdGhlIG1vc3QgcmVjZW50bHkgYXR0YWNoZWQgcm9vdCB0aGF0IGlzIHN0aWxsIG1vdW50ZWQgKG9yIGRldGFjaCBmdWxseSBpZlxuICAgICAgLy8gbm9uZSByZW1haW4pLiBDbGVhcmluZyB1bmNvbmRpdGlvbmFsbHkgd291bGQgbGVhdmUgYSBzdGlsbC1tb3VudGVkIG9sZGVyIHJvb3QgdW5jb250cm9sbGFibGVcbiAgICAgIC8vIHdoZW4gYSBuZXdlciBvdmVybGFwcGluZyByb290IGRldGFjaGVzIGZpcnN0IChlLmcuIGEgY2FuY2VsZWQgcm91dGUgdHJhbnNpdGlvbikuXG4gICAgICB0aGlzLnNldEFjdGl2ZVN0b3JlKHRoaXMuYXR0YWNoZWRTdG9yZXNbdGhpcy5hdHRhY2hlZFN0b3Jlcy5sZW5ndGggLSAxXSA/PyBudWxsKTtcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIHN0b3JlIHRoYXQgY3VycmVudGx5IGNvbnRyb2xzIHRoZSBoYW5kbGUgYW5kIG5vdGlmaWVzIHN1YnNjcmliZXJzIHdoZW4gaXQgY2hhbmdlcywgc29cbiAgICogZGV0YWNoZWQgdHJpZ2dlcnMgcmUtcmVuZGVyIGFuZCBtaWdyYXRlIHRoZWlyIHJlZ2lzdHJhdGlvbiB0byB0aGUgbmV3IHN0b3JlLlxuICAgKi9cbiAgc2V0QWN0aXZlU3RvcmUoc3RvcmUpIHtcbiAgICBpZiAodGhpcy5hdHRhY2hlZFN0b3JlVmFsdWUgIT09IHN0b3JlKSB7XG4gICAgICB0aGlzLmF0dGFjaGVkU3RvcmVWYWx1ZSA9IHN0b3JlO1xuICAgICAgdGhpcy5zdG9yZUxpc3RlbmVycy5mb3JFYWNoKGxpc3RlbmVyID0+IHtcbiAgICAgICAgbGlzdGVuZXIoKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyB0aGUgYXR0YWNoZWQgcm9vdCdzIHN0b3JlIGFuZCBhc3NvY2lhdGVzIGl0IHdpdGggdGhlIHRyaWdnZXIgd2l0aCB0aGUgZ2l2ZW4gaWQsIG9yIGFcbiAgICogbm8tb3AgKHdpdGggYSBkZXYgd2FybmluZykgd2hpbGUgbm8gcm9vdCBpcyBhdHRhY2hlZC4gU2hhcmVkIGJ5IGV2ZXJ5IGNvbmNyZXRlIGhhbmRsZSdzIHB1YmxpY1xuICAgKiBgb3BlbigpYCBtZXRob2QsIHdoaWNoIG9ubHkgbmFycm93cyB0aGUgcGFyYW1ldGVyIHR5cGUuXG4gICAqXG4gICAqIFdoZW4gYSB0cmlnZ2VyIGlkIGlzIGdpdmVuIGJ1dCBubyBtYXRjaGluZyB0cmlnZ2VyIGlzIHJlZ2lzdGVyZWQsIGFuY2hvcmVkIHBvcHVwcyB0aHJvdyAoc2VlXG4gICAqIGB0aHJvd09uTWlzc2luZ1RyaWdnZXJgKTsgRGlhbG9nIG9wZW5zIHVuYXNzb2NpYXRlZCB3aXRoIGEgZGV2IHdhcm5pbmcgaW5zdGVhZC5cbiAgICpcbiAgICogVGhpcyBtZXRob2Qgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGluIGFuIGV2ZW50IGhhbmRsZXIgb3IgYW4gZWZmZWN0IChub3QgZHVyaW5nIHJlbmRlcmluZykuXG4gICAqXG4gICAqIEBwYXJhbSB0cmlnZ2VySWQgSUQgb2YgdGhlIHRyaWdnZXIgdG8gYXNzb2NpYXRlIHdpdGggdGhlIHBvcHVwLCBvciBgbnVsbGAvYHVuZGVmaW5lZGAgdG8gb3BlblxuICAgKiB3aXRob3V0IGFzc29jaWF0aW5nIGFueSB0cmlnZ2VyLlxuICAgKi9cbiAgb3BlbkJ5VHJpZ2dlcih0cmlnZ2VySWQpIHtcbiAgICBjb25zdCBhdHRhY2hlZFN0b3JlID0gdGhpcy5hdHRhY2hlZFN0b3JlO1xuICAgIGlmIChhdHRhY2hlZFN0b3JlID09PSBudWxsKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBjb25zb2xlLndhcm4oYEJhc2UgVUk6ICR7dGhpcy5jb21wb25lbnROYW1lfUhhbmRsZS5vcGVuKCkgd2FzIGNhbGxlZCB3aGlsZSBubyByb290IHVzaW5nIHRoaXMgaGFuZGxlIGlzIG1vdW50ZWQuIGAgKyAnVGhlIGNhbGwgd2FzIGlnbm9yZWQ7IG1vdW50IGEgcm9vdCB3aXRoIHRoaXMgaGFuZGxlIGJlZm9yZSBvcGVuaW5nIGl0IGltcGVyYXRpdmVseS4nKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBSZWdpc3RlcmVkIHRyaWdnZXJzIG5vcm1hbGx5IGxpdmUgaW4gdGhlIGFjdGl2ZSByb290J3Mgc3RvcmUuIER1cmluZyB0aGUgY29tbWl0IGluIHdoaWNoIGFcbiAgICAvLyByb290IGF0dGFjaGVzLCBhIHN0aWxsLW1vdW50ZWQgZGV0YWNoZWQgdHJpZ2dlciBoYXMgbm90IHJlLXJlZ2lzdGVyZWQgaW50byB0aGF0IHN0b3JlIHlldCAoaXRcbiAgICAvLyBtaWdyYXRlcyBvbiBpdHMgbmV4dCByZW5kZXIpOiBpdCBpcyBzdGlsbCByZWdpc3RlcmVkIHdoZXJldmVyIGl0IGxpdmVkIGJlZm9yZSDigJQgdGhlIGZhbGxiYWNrXG4gICAgLy8gc3RvcmUgd2hlbiB0aGlzIGlzIHRoZSBmaXJzdCByb290IHRvIGF0dGFjaCwgb3IgYSBwcmV2aW91c2x5IGF0dGFjaGVkIHJvb3QncyBzdG9yZSBkdXJpbmcgYVxuICAgIC8vIHRyYW5zaWVudCBvdmVybGFwIChlLmcuIGFuIGFuaW1hdGVkIHJvdXRlIHRyYW5zaXRpb24pLiBTZWFyY2ggdGhlIHdob2xlIGF0dGFjaG1lbnQgc3RhY2tcbiAgICAvLyAobmV3ZXN0IGZpcnN0KSBhbmQgdGhlIGZhbGxiYWNrIG1hcCBzbyBhbiBpbXBlcmF0aXZlIG9wZW4tYnktaWQgY2FsbGVkIGluIHRoYXQgY29tbWl0IChlLmcuXG4gICAgLy8gZnJvbSBhIGxheW91dCBlZmZlY3QpIHN0aWxsIHJlc29sdmVzIHRoZSB0cmlnZ2VyIGluc3RlYWQgb2YgdHJlYXRpbmcgaXQgYXMgbWlzc2luZy5cbiAgICBsZXQgdHJpZ2dlckVsZW1lbnQ7XG4gICAgaWYgKHRyaWdnZXJJZCkge1xuICAgICAgZm9yIChsZXQgaSA9IHRoaXMuYXR0YWNoZWRTdG9yZXMubGVuZ3RoIC0gMTsgaSA+PSAwICYmICF0cmlnZ2VyRWxlbWVudDsgaSAtPSAxKSB7XG4gICAgICAgIHRyaWdnZXJFbGVtZW50ID0gdGhpcy5hdHRhY2hlZFN0b3Jlc1tpXS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5nZXRCeUlkKHRyaWdnZXJJZCk7XG4gICAgICB9XG4gICAgICB0cmlnZ2VyRWxlbWVudCA/Pz0gdGhpcy5mYWxsYmFja1N0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLmdldEJ5SWQodHJpZ2dlcklkKTtcbiAgICB9XG4gICAgaWYgKHRyaWdnZXJJZCAmJiAhdHJpZ2dlckVsZW1lbnQpIHtcbiAgICAgIGlmICh0aGlzLnRocm93T25NaXNzaW5nVHJpZ2dlcikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gYEJhc2UgVUk6ICR7dGhpcy5jb21wb25lbnROYW1lfUhhbmRsZS5vcGVuKCkgd2FzIGNhbGxlZCB3aXRoIHRoZSB0cmlnZ2VyIGlkIFwiJHt0cmlnZ2VySWR9XCIsIGAgKyAnYnV0IG5vIG1hdGNoaW5nIHRyaWdnZXIgaXMgcmVnaXN0ZXJlZCB3aXRoIHRoaXMgaGFuZGxlLiAnICsgJ0FuIGFuY2hvcmVkIHBvcHVwIGNhbm5vdCBvcGVuIHdpdGhvdXQgYSB0cmlnZ2VyIHRvIGFuY2hvciB0by4gJyArIGBQYXNzIHRoZSBpZCBvZiBhIG1vdW50ZWQgJHt0aGlzLmNvbXBvbmVudE5hbWV9LlRyaWdnZXIgdGhhdCBoYXMgdGhpcyBoYW5kbGUgc2V0IG9uIGl0cyBcImhhbmRsZVwiIHByb3AuYCA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoOTksIHRoaXMuY29tcG9uZW50TmFtZSwgdHJpZ2dlcklkLCB0aGlzLmNvbXBvbmVudE5hbWUpKTtcbiAgICAgIH1cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihgQmFzZSBVSTogJHt0aGlzLmNvbXBvbmVudE5hbWV9SGFuZGxlLm9wZW46IE5vIHRyaWdnZXIgZm91bmQgd2l0aCBpZCBcIiR7dHJpZ2dlcklkfVwiLiBgICsgJ1RoZSBwb3B1cCB3aWxsIG9wZW4sIGJ1dCB0aGUgdHJpZ2dlciB3aWxsIG5vdCBiZSBhc3NvY2lhdGVkIHdpdGggaXQuJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGF0dGFjaGVkU3RvcmUuc2V0T3Blbih0cnVlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5pbXBlcmF0aXZlQWN0aW9uLCB1bmRlZmluZWQsIHRyaWdnZXJFbGVtZW50KSk7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2VzIHRoZSBwb3B1cCBieSBzZXR0aW5nIHRoZSBhdHRhY2hlZCByb290J3Mgc3RvcmUgdG8gY2xvc2VkLCBvciBhIG5vLW9wICh3aXRoIGEgZGV2IHdhcm5pbmcpXG4gICAqIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQuIFNoYXJlZCBieSBldmVyeSBjb25jcmV0ZSBoYW5kbGUncyBwdWJsaWMgYGNsb3NlKClgIG1ldGhvZC5cbiAgICpcbiAgICogVGhpcyBtZXRob2Qgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGluIGFuIGV2ZW50IGhhbmRsZXIgb3IgYW4gZWZmZWN0IChub3QgZHVyaW5nIHJlbmRlcmluZykuXG4gICAqL1xuICBjbG9zZVBvcHVwKCkge1xuICAgIGNvbnN0IGF0dGFjaGVkU3RvcmUgPSB0aGlzLmF0dGFjaGVkU3RvcmU7XG4gICAgaWYgKGF0dGFjaGVkU3RvcmUgPT09IG51bGwpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihgQmFzZSBVSTogJHt0aGlzLmNvbXBvbmVudE5hbWV9SGFuZGxlLmNsb3NlKCkgd2FzIGNhbGxlZCB3aGlsZSBubyByb290IHVzaW5nIHRoaXMgaGFuZGxlIGlzIG1vdW50ZWQuIGAgKyAnVGhlIGNhbGwgd2FzIGlnbm9yZWQuJyk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGF0dGFjaGVkU3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbikpO1xuICB9XG59IiwiLyoqXG4gKiBAbGljZW5zZSBSZWFjdFxuICogdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS5kZXZlbG9wbWVudC5qc1xuICpcbiAqIENvcHlyaWdodCAoYykgTWV0YSBQbGF0Zm9ybXMsIEluYy4gYW5kIGFmZmlsaWF0ZXMuXG4gKlxuICogVGhpcyBzb3VyY2UgY29kZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UgZm91bmQgaW4gdGhlXG4gKiBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxuXCJ1c2Ugc3RyaWN0XCI7XG5cInByb2R1Y3Rpb25cIiAhPT0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgJiZcbiAgKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBpcyh4LCB5KSB7XG4gICAgICByZXR1cm4gKHggPT09IHkgJiYgKDAgIT09IHggfHwgMSAvIHggPT09IDEgLyB5KSkgfHwgKHggIT09IHggJiYgeSAhPT0geSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHVzZVN5bmNFeHRlcm5hbFN0b3JlJDIoc3Vic2NyaWJlLCBnZXRTbmFwc2hvdCkge1xuICAgICAgZGlkV2Fybk9sZDE4QWxwaGEgfHxcbiAgICAgICAgdm9pZCAwID09PSBSZWFjdC5zdGFydFRyYW5zaXRpb24gfHxcbiAgICAgICAgKChkaWRXYXJuT2xkMThBbHBoYSA9ICEwKSxcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIllvdSBhcmUgdXNpbmcgYW4gb3V0ZGF0ZWQsIHByZS1yZWxlYXNlIGFscGhhIG9mIFJlYWN0IDE4IHRoYXQgZG9lcyBub3Qgc3VwcG9ydCB1c2VTeW5jRXh0ZXJuYWxTdG9yZS4gVGhlIHVzZS1zeW5jLWV4dGVybmFsLXN0b3JlIHNoaW0gd2lsbCBub3Qgd29yayBjb3JyZWN0bHkuIFVwZ3JhZGUgdG8gYSBuZXdlciBwcmUtcmVsZWFzZS5cIlxuICAgICAgICApKTtcbiAgICAgIHZhciB2YWx1ZSA9IGdldFNuYXBzaG90KCk7XG4gICAgICBpZiAoIWRpZFdhcm5VbmNhY2hlZEdldFNuYXBzaG90KSB7XG4gICAgICAgIHZhciBjYWNoZWRWYWx1ZSA9IGdldFNuYXBzaG90KCk7XG4gICAgICAgIG9iamVjdElzKHZhbHVlLCBjYWNoZWRWYWx1ZSkgfHxcbiAgICAgICAgICAoY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgIFwiVGhlIHJlc3VsdCBvZiBnZXRTbmFwc2hvdCBzaG91bGQgYmUgY2FjaGVkIHRvIGF2b2lkIGFuIGluZmluaXRlIGxvb3BcIlxuICAgICAgICAgICksXG4gICAgICAgICAgKGRpZFdhcm5VbmNhY2hlZEdldFNuYXBzaG90ID0gITApKTtcbiAgICAgIH1cbiAgICAgIGNhY2hlZFZhbHVlID0gdXNlU3RhdGUoe1xuICAgICAgICBpbnN0OiB7IHZhbHVlOiB2YWx1ZSwgZ2V0U25hcHNob3Q6IGdldFNuYXBzaG90IH1cbiAgICAgIH0pO1xuICAgICAgdmFyIGluc3QgPSBjYWNoZWRWYWx1ZVswXS5pbnN0LFxuICAgICAgICBmb3JjZVVwZGF0ZSA9IGNhY2hlZFZhbHVlWzFdO1xuICAgICAgdXNlTGF5b3V0RWZmZWN0KFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaW5zdC52YWx1ZSA9IHZhbHVlO1xuICAgICAgICAgIGluc3QuZ2V0U25hcHNob3QgPSBnZXRTbmFwc2hvdDtcbiAgICAgICAgICBjaGVja0lmU25hcHNob3RDaGFuZ2VkKGluc3QpICYmIGZvcmNlVXBkYXRlKHsgaW5zdDogaW5zdCB9KTtcbiAgICAgICAgfSxcbiAgICAgICAgW3N1YnNjcmliZSwgdmFsdWUsIGdldFNuYXBzaG90XVxuICAgICAgKTtcbiAgICAgIHVzZUVmZmVjdChcbiAgICAgICAgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGNoZWNrSWZTbmFwc2hvdENoYW5nZWQoaW5zdCkgJiYgZm9yY2VVcGRhdGUoeyBpbnN0OiBpbnN0IH0pO1xuICAgICAgICAgIHJldHVybiBzdWJzY3JpYmUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY2hlY2tJZlNuYXBzaG90Q2hhbmdlZChpbnN0KSAmJiBmb3JjZVVwZGF0ZSh7IGluc3Q6IGluc3QgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIFtzdWJzY3JpYmVdXG4gICAgICApO1xuICAgICAgdXNlRGVidWdWYWx1ZSh2YWx1ZSk7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNoZWNrSWZTbmFwc2hvdENoYW5nZWQoaW5zdCkge1xuICAgICAgdmFyIGxhdGVzdEdldFNuYXBzaG90ID0gaW5zdC5nZXRTbmFwc2hvdDtcbiAgICAgIGluc3QgPSBpbnN0LnZhbHVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmFyIG5leHRWYWx1ZSA9IGxhdGVzdEdldFNuYXBzaG90KCk7XG4gICAgICAgIHJldHVybiAhb2JqZWN0SXMoaW5zdCwgbmV4dFZhbHVlKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiAhMDtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gdXNlU3luY0V4dGVybmFsU3RvcmUkMShzdWJzY3JpYmUsIGdldFNuYXBzaG90KSB7XG4gICAgICByZXR1cm4gZ2V0U25hcHNob3QoKTtcbiAgICB9XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydCAmJlxuICAgICAgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydChFcnJvcigpKTtcbiAgICB2YXIgUmVhY3QgPSByZXF1aXJlKFwicmVhY3RcIiksXG4gICAgICBvYmplY3RJcyA9IFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIE9iamVjdC5pcyA/IE9iamVjdC5pcyA6IGlzLFxuICAgICAgdXNlU3RhdGUgPSBSZWFjdC51c2VTdGF0ZSxcbiAgICAgIHVzZUVmZmVjdCA9IFJlYWN0LnVzZUVmZmVjdCxcbiAgICAgIHVzZUxheW91dEVmZmVjdCA9IFJlYWN0LnVzZUxheW91dEVmZmVjdCxcbiAgICAgIHVzZURlYnVnVmFsdWUgPSBSZWFjdC51c2VEZWJ1Z1ZhbHVlLFxuICAgICAgZGlkV2Fybk9sZDE4QWxwaGEgPSAhMSxcbiAgICAgIGRpZFdhcm5VbmNhY2hlZEdldFNuYXBzaG90ID0gITEsXG4gICAgICBzaGltID1cbiAgICAgICAgXCJ1bmRlZmluZWRcIiA9PT0gdHlwZW9mIHdpbmRvdyB8fFxuICAgICAgICBcInVuZGVmaW5lZFwiID09PSB0eXBlb2Ygd2luZG93LmRvY3VtZW50IHx8XG4gICAgICAgIFwidW5kZWZpbmVkXCIgPT09IHR5cGVvZiB3aW5kb3cuZG9jdW1lbnQuY3JlYXRlRWxlbWVudFxuICAgICAgICAgID8gdXNlU3luY0V4dGVybmFsU3RvcmUkMVxuICAgICAgICAgIDogdXNlU3luY0V4dGVybmFsU3RvcmUkMjtcbiAgICBleHBvcnRzLnVzZVN5bmNFeHRlcm5hbFN0b3JlID1cbiAgICAgIHZvaWQgMCAhPT0gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUgPyBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZSA6IHNoaW07XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdG9wICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AoRXJyb3IoKSk7XG4gIH0pKCk7XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi4vY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXNoaW0ucHJvZHVjdGlvbi5qcycpO1xufSBlbHNlIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuLi9janMvdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS5kZXZlbG9wbWVudC5qcycpO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZSBSZWFjdFxuICogdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS93aXRoLXNlbGVjdG9yLmRldmVsb3BtZW50LmpzXG4gKlxuICogQ29weXJpZ2h0IChjKSBNZXRhIFBsYXRmb3JtcywgSW5jLiBhbmQgYWZmaWxpYXRlcy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG5cInVzZSBzdHJpY3RcIjtcblwicHJvZHVjdGlvblwiICE9PSBwcm9jZXNzLmVudi5OT0RFX0VOViAmJlxuICAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIGlzKHgsIHkpIHtcbiAgICAgIHJldHVybiAoeCA9PT0geSAmJiAoMCAhPT0geCB8fCAxIC8geCA9PT0gMSAvIHkpKSB8fCAoeCAhPT0geCAmJiB5ICE9PSB5KTtcbiAgICB9XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydCAmJlxuICAgICAgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydChFcnJvcigpKTtcbiAgICB2YXIgUmVhY3QgPSByZXF1aXJlKFwicmVhY3RcIiksXG4gICAgICBzaGltID0gcmVxdWlyZShcInVzZS1zeW5jLWV4dGVybmFsLXN0b3JlL3NoaW1cIiksXG4gICAgICBvYmplY3RJcyA9IFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIE9iamVjdC5pcyA/IE9iamVjdC5pcyA6IGlzLFxuICAgICAgdXNlU3luY0V4dGVybmFsU3RvcmUgPSBzaGltLnVzZVN5bmNFeHRlcm5hbFN0b3JlLFxuICAgICAgdXNlUmVmID0gUmVhY3QudXNlUmVmLFxuICAgICAgdXNlRWZmZWN0ID0gUmVhY3QudXNlRWZmZWN0LFxuICAgICAgdXNlTWVtbyA9IFJlYWN0LnVzZU1lbW8sXG4gICAgICB1c2VEZWJ1Z1ZhbHVlID0gUmVhY3QudXNlRGVidWdWYWx1ZTtcbiAgICBleHBvcnRzLnVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yID0gZnVuY3Rpb24gKFxuICAgICAgc3Vic2NyaWJlLFxuICAgICAgZ2V0U25hcHNob3QsXG4gICAgICBnZXRTZXJ2ZXJTbmFwc2hvdCxcbiAgICAgIHNlbGVjdG9yLFxuICAgICAgaXNFcXVhbFxuICAgICkge1xuICAgICAgdmFyIGluc3RSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgICBpZiAobnVsbCA9PT0gaW5zdFJlZi5jdXJyZW50KSB7XG4gICAgICAgIHZhciBpbnN0ID0geyBoYXNWYWx1ZTogITEsIHZhbHVlOiBudWxsIH07XG4gICAgICAgIGluc3RSZWYuY3VycmVudCA9IGluc3Q7XG4gICAgICB9IGVsc2UgaW5zdCA9IGluc3RSZWYuY3VycmVudDtcbiAgICAgIGluc3RSZWYgPSB1c2VNZW1vKFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZnVuY3Rpb24gbWVtb2l6ZWRTZWxlY3RvcihuZXh0U25hcHNob3QpIHtcbiAgICAgICAgICAgIGlmICghaGFzTWVtbykge1xuICAgICAgICAgICAgICBoYXNNZW1vID0gITA7XG4gICAgICAgICAgICAgIG1lbW9pemVkU25hcHNob3QgPSBuZXh0U25hcHNob3Q7XG4gICAgICAgICAgICAgIG5leHRTbmFwc2hvdCA9IHNlbGVjdG9yKG5leHRTbmFwc2hvdCk7XG4gICAgICAgICAgICAgIGlmICh2b2lkIDAgIT09IGlzRXF1YWwgJiYgaW5zdC5oYXNWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBjdXJyZW50U2VsZWN0aW9uID0gaW5zdC52YWx1ZTtcbiAgICAgICAgICAgICAgICBpZiAoaXNFcXVhbChjdXJyZW50U2VsZWN0aW9uLCBuZXh0U25hcHNob3QpKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChtZW1vaXplZFNlbGVjdGlvbiA9IGN1cnJlbnRTZWxlY3Rpb24pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiAobWVtb2l6ZWRTZWxlY3Rpb24gPSBuZXh0U25hcHNob3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbiA9IG1lbW9pemVkU2VsZWN0aW9uO1xuICAgICAgICAgICAgaWYgKG9iamVjdElzKG1lbW9pemVkU25hcHNob3QsIG5leHRTbmFwc2hvdCkpXG4gICAgICAgICAgICAgIHJldHVybiBjdXJyZW50U2VsZWN0aW9uO1xuICAgICAgICAgICAgdmFyIG5leHRTZWxlY3Rpb24gPSBzZWxlY3RvcihuZXh0U25hcHNob3QpO1xuICAgICAgICAgICAgaWYgKHZvaWQgMCAhPT0gaXNFcXVhbCAmJiBpc0VxdWFsKGN1cnJlbnRTZWxlY3Rpb24sIG5leHRTZWxlY3Rpb24pKVxuICAgICAgICAgICAgICByZXR1cm4gKG1lbW9pemVkU25hcHNob3QgPSBuZXh0U25hcHNob3QpLCBjdXJyZW50U2VsZWN0aW9uO1xuICAgICAgICAgICAgbWVtb2l6ZWRTbmFwc2hvdCA9IG5leHRTbmFwc2hvdDtcbiAgICAgICAgICAgIHJldHVybiAobWVtb2l6ZWRTZWxlY3Rpb24gPSBuZXh0U2VsZWN0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIGhhc01lbW8gPSAhMSxcbiAgICAgICAgICAgIG1lbW9pemVkU25hcHNob3QsXG4gICAgICAgICAgICBtZW1vaXplZFNlbGVjdGlvbixcbiAgICAgICAgICAgIG1heWJlR2V0U2VydmVyU25hcHNob3QgPVxuICAgICAgICAgICAgICB2b2lkIDAgPT09IGdldFNlcnZlclNuYXBzaG90ID8gbnVsbCA6IGdldFNlcnZlclNuYXBzaG90O1xuICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBtZW1vaXplZFNlbGVjdG9yKGdldFNuYXBzaG90KCkpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG51bGwgPT09IG1heWJlR2V0U2VydmVyU25hcHNob3RcbiAgICAgICAgICAgICAgPyB2b2lkIDBcbiAgICAgICAgICAgICAgOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gbWVtb2l6ZWRTZWxlY3RvcihtYXliZUdldFNlcnZlclNuYXBzaG90KCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICBdO1xuICAgICAgICB9LFxuICAgICAgICBbZ2V0U25hcHNob3QsIGdldFNlcnZlclNuYXBzaG90LCBzZWxlY3RvciwgaXNFcXVhbF1cbiAgICAgICk7XG4gICAgICB2YXIgdmFsdWUgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmUsIGluc3RSZWZbMF0sIGluc3RSZWZbMV0pO1xuICAgICAgdXNlRWZmZWN0KFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaW5zdC5oYXNWYWx1ZSA9ICEwO1xuICAgICAgICAgIGluc3QudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgW3ZhbHVlXVxuICAgICAgKTtcbiAgICAgIHVzZURlYnVnVmFsdWUodmFsdWUpO1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH07XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdG9wICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AoRXJyb3IoKSk7XG4gIH0pKCk7XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi4vY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXNoaW0vd2l0aC1zZWxlY3Rvci5wcm9kdWN0aW9uLmpzJyk7XG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4uL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltL3dpdGgtc2VsZWN0b3IuZGV2ZWxvcG1lbnQuanMnKTtcbn1cbiIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSBcIi4vdXNlUmVmV2l0aEluaXQubWpzXCI7XG5jb25zdCBob29rcyA9IFtdO1xubGV0IGN1cnJlbnRJbnN0YW5jZSA9IHVuZGVmaW5lZDtcbmV4cG9ydCBmdW5jdGlvbiBnZXRJbnN0YW5jZSgpIHtcbiAgcmV0dXJuIGN1cnJlbnRJbnN0YW5jZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBzZXRJbnN0YW5jZShpbnN0YW5jZSkge1xuICBjdXJyZW50SW5zdGFuY2UgPSBpbnN0YW5jZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZWdpc3Rlcihob29rKSB7XG4gIGhvb2tzLnB1c2goaG9vayk7XG59XG5cbi8qKlxuICogV3JhcHMgYSBjb21wb25lbnQgZnVuY3Rpb24gdG8gZW5hYmxlIHBlcmZvcm1hbmNlIG9wdGltaXphdGlvbnMgZm9yIGludGVybmFsIGhvb2tzLlxuICpcbiAqICoqUGVyZm9ybWFuY2UgT3B0aW1pemF0aW9uOioqXG4gKiBDb21wb25lbnRzIHdyYXBwZWQgd2l0aCBgZmFzdENvbXBvbmVudGAgaGF2ZSBhY2Nlc3MgdG8gYSBzaGFyZWQgXCJpbnN0YW5jZVwiIGNvbnRleHQgdGhhdCBlbmFibGVzXG4gKiBzcGVjaWFsaXplZCBob29rIGltcGxlbWVudGF0aW9ucyB0byBiYXRjaCBvcGVyYXRpb25zIGFuZCByZWR1Y2Ugb3ZlcmhlYWQuIFRoZSB3cmFwcGVyIGNyZWF0ZXMgYVxuICogc3RhYmxlIGluc3RhbmNlIG9iamVjdCB0aGF0IHBlcnNpc3RzIGFjcm9zcyByZW5kZXJzLCBzZXRzIGl0IGFzIHRoZSBjdXJyZW50IGNvbnRleHQsIGNhbGxzXG4gKiByZWdpc3RlcmVkIGhvb2tzIGJlZm9yZSBhbmQgYWZ0ZXIgcmVuZGVyaW5nLCB0aGVuIGNsZWFycyB0aGUgY29udGV4dC4gVGhlIHByaW1hcnkgYmVuZWZpdCBpc1xuICogd2l0aCBgdXNlU3RvcmVgLCB3aGVyZSBtdWx0aXBsZSBzdG9yZSBzdWJzY3JpcHRpb25zIHdpdGhpbiB0aGUgc2FtZSBjb21wb25lbnQgYXJlIGNvbGxhcHNlZCBpbnRvXG4gKiBhIHNpbmdsZSBgdXNlU3luY0V4dGVybmFsU3RvcmVgIHN1YnNjcmlwdGlvbiBwZXIgc3RvcmUsIHNpZ25pZmljYW50bHkgcmVkdWNpbmcgcmUtcmVuZGVyIG92ZXJoZWFkLlxuICogVGhpcyBvcHRpbWl6YXRpb24gaXMgb25seSBhY3RpdmUgb24gUmVhY3QgMTkrOyBvbiBlYXJsaWVyIHZlcnNpb25zIGB1c2VTdG9yZWAgZmFsbHMgYmFjayB0byBhXG4gKiBzZXBhcmF0ZSBzdWJzY3JpcHRpb24gcGVyIGNhbGwuXG4gKlxuICogKipSZXF1aXJlbWVudHM6KipcbiAqIC0gVGhlIGNvbXBvbmVudCBmdW5jdGlvbiBzaG91bGQgZm9sbG93IHN0YW5kYXJkIFJlYWN0IGNvbXBvbmVudCBwYXR0ZXJuc1xuICogLSBgdXNlU3RvcmVgIGNhbGxzIG11c3Qga2VlcCBhIHN0YWJsZSBvcmRlciBhbmQgY291bnQgYWNyb3NzIHJlbmRlcnMsIGFzIGJhdGNoZWQgaG9va3MgYXJlXG4gKiAgIG1hdGNoZWQgYnkgY2FsbCBpbmRleFxuICogLSBEbyBub3QgcmVseSBvbiB0aGUgaW5zdGFuY2UgY29udGV4dCBvdXRzaWRlIG9mIHNwZWNpYWxpemVkIGhvb2tzXG4gKlxuICogQHBhcmFtIGZuIC0gVGhlIGNvbXBvbmVudCBmdW5jdGlvbiB0byB3cmFwXG4gKiBAcmV0dXJucyBBIHdyYXBwZWQgY29tcG9uZW50IHdpdGggdGhlIHNhbWUgc2lnbmF0dXJlIGFzIHRoZSBpbnB1dCBmdW5jdGlvblxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIC8vIFdyYXBwaW5nIGEgY29tcG9uZW50IHRvIGVuYWJsZSBvcHRpbWl6ZWQgdXNlU3RvcmUgYmF0Y2hpbmdcbiAqIGV4cG9ydCBjb25zdCBUb29sdGlwUm9vdCA9IGZhc3RDb21wb25lbnQoZnVuY3Rpb24gVG9vbHRpcFJvb3QocHJvcHMpIHtcbiAqICAgLy8gVGhlc2UgdXNlU3RvcmUgY2FsbHMgc2hhcmUgYSBzaW5nbGUgc3Vic2NyaXB0aW9uXG4gKiAgIGNvbnN0IG9wZW4gPSB1c2VTdG9yZShzdG9yZSwgKHN0YXRlKSA9PiBzdGF0ZS5vcGVuKTtcbiAqICAgY29uc3QgZGlzYWJsZWQgPSB1c2VTdG9yZShzdG9yZSwgKHN0YXRlKSA9PiBzdGF0ZS5kaXNhYmxlZCk7XG4gKiAgIGNvbnN0IHZhbHVlID0gdXNlU3RvcmUoc3RvcmUsIChzdGF0ZSkgPT4gc3RhdGUudmFsdWUpO1xuICogICAvLyAuLi5cbiAqIH0pO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmYXN0Q29tcG9uZW50KGZuKSB7XG4gIGNvbnN0IEZhc3RDb21wb25lbnQgPSAocHJvcHMsIGZvcndhcmRlZFJlZikgPT4ge1xuICAgIGNvbnN0IGluc3RhbmNlID0gdXNlUmVmV2l0aEluaXQoY3JlYXRlSW5zdGFuY2UpLmN1cnJlbnQ7XG4gICAgbGV0IHJlc3VsdDtcbiAgICB0cnkge1xuICAgICAgY3VycmVudEluc3RhbmNlID0gaW5zdGFuY2U7XG4gICAgICBmb3IgKGNvbnN0IGhvb2sgb2YgaG9va3MpIHtcbiAgICAgICAgaG9vay5iZWZvcmUoaW5zdGFuY2UpO1xuICAgICAgfVxuICAgICAgcmVzdWx0ID0gZm4ocHJvcHMsIGZvcndhcmRlZFJlZik7XG4gICAgICBmb3IgKGNvbnN0IGhvb2sgb2YgaG9va3MpIHtcbiAgICAgICAgaG9vay5hZnRlcihpbnN0YW5jZSk7XG4gICAgICB9XG4gICAgICBpbnN0YW5jZS5kaWRJbml0aWFsaXplID0gdHJ1ZTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgY3VycmVudEluc3RhbmNlID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9O1xuICBGYXN0Q29tcG9uZW50LmRpc3BsYXlOYW1lID0gZm4uZGlzcGxheU5hbWUgfHwgZm4ubmFtZTtcbiAgcmV0dXJuIEZhc3RDb21wb25lbnQ7XG59XG5cbi8qKlxuICogV3JhcHMgYSBjb21wb25lbnQgZnVuY3Rpb24gd2l0aCByZWYgZm9yd2FyZGluZyB0byBlbmFibGUgcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9ucyBmb3IgaW50ZXJuYWwgaG9va3MuXG4gKlxuICogVGhpcyBpcyBhIGNvbnZlbmllbmNlIHdyYXBwZXIgdGhhdCBjb21iaW5lcyBgZmFzdENvbXBvbmVudGAgd2l0aCBgUmVhY3QuZm9yd2FyZFJlZmAsIGVuYWJsaW5nXG4gKiBib3RoIHBlcmZvcm1hbmNlIG9wdGltaXphdGlvbnMgYW5kIHByb3BlciByZWYgZm9yd2FyZGluZy4gU2VlIGBmYXN0Q29tcG9uZW50YCBmb3IgZGV0YWlscyBvblxuICogdGhlIHBlcmZvcm1hbmNlIGJlbmVmaXRzLlxuICpcbiAqIEBwYXJhbSBmbiAtIFRoZSBjb21wb25lbnQgZnVuY3Rpb24gdGhhdCBhY2NlcHRzIHByb3BzIGFuZCBhIGZvcndhcmRlZCByZWZcbiAqIEByZXR1cm5zIEEgd3JhcHBlZCBjb21wb25lbnQgd2l0aCByZWYgZm9yd2FyZGluZyBlbmFibGVkXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogLy8gV3JhcHBpbmcgYSBjb21wb25lbnQgd2l0aCByZWYgZm9yd2FyZGluZyBhbmQgb3B0aW1pemVkIGhvb2tzXG4gKiBleHBvcnQgY29uc3QgVG9vbHRpcFRyaWdnZXIgPSBmYXN0Q29tcG9uZW50UmVmKGZ1bmN0aW9uIFRvb2x0aXBUcmlnZ2VyKFxuICogICBwcm9wcyxcbiAqICAgZm9yd2FyZGVkUmVmXG4gKiApIHtcbiAqICAgY29uc3Qgc3RvcmUgPSB1c2VDb250ZXh0KFRvb2x0aXBDb250ZXh0KTtcbiAqICAgY29uc3Qgb3BlbiA9IHVzZVN0b3JlKHN0b3JlLCAoc3RhdGUpID0+IHN0YXRlLm9wZW4pO1xuICogICAvLyAuLi4gY29tcG9uZW50IGxvZ2ljIHdpdGggcmVmXG4gKiAgIHJldHVybiA8YnV0dG9uIHJlZj17Zm9yd2FyZGVkUmVmfSB7Li4ucHJvcHN9IC8+O1xuICogfSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZhc3RDb21wb25lbnRSZWYoZm4pIHtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZhc3RDb21wb25lbnQoZm4pKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluc3RhbmNlKCkge1xuICByZXR1cm4ge1xuICAgIGRpZEluaXRpYWxpemU6IGZhbHNlXG4gIH07XG59IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuLyogV2UgbmVlZCB0byBpbXBvcnQgdGhlIHNoaW0gYmVjYXVzZSBSZWFjdCAxNyBkb2VzIG5vdCBzdXBwb3J0IHRoZSBgdXNlU3luY0V4dGVybmFsU3RvcmVgIEFQSS5cbiAqIE1vcmUgaW5mbzogaHR0cHM6Ly9naXRodWIuY29tL211aS9tdWkteC9pc3N1ZXMvMTgzMDMjaXNzdWVjb21tZW50LTI5NTgzOTIzNDEgKi9cbmltcG9ydCB7IHVzZVN5bmNFeHRlcm5hbFN0b3JlIH0gZnJvbSAndXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbSc7XG5pbXBvcnQgeyB1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvciB9IGZyb20gJ3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL3NoaW0vd2l0aC1zZWxlY3Rvcic7XG5pbXBvcnQgeyBpc1JlYWN0VmVyc2lvbkF0TGVhc3QgfSBmcm9tIFwiLi4vcmVhY3RWZXJzaW9uLm1qc1wiO1xuaW1wb3J0IHsgcmVnaXN0ZXIsIGdldEluc3RhbmNlIH0gZnJvbSBcIi4uL2Zhc3RIb29rcy5tanNcIjtcbi8qIFNvbWUgdGVzdHMgZmFpbCBpbiBSMTggd2l0aCB0aGUgcmF3IHVzZVN5bmNFeHRlcm5hbFN0b3JlLiBJdCBtYXkgYmUgcG9zc2libGUgdG8gbWFrZSBpdCB3b3JrXG4gKiBidXQgZm9yIG5vdyB3ZSBvbmx5IGVuYWJsZSBpdCBmb3IgUjE5Ky4gKi9cbmNvbnN0IGNhblVzZVJhd1VzZVN5bmNFeHRlcm5hbFN0b3JlID0gaXNSZWFjdFZlcnNpb25BdExlYXN0KDE5KTtcbmNvbnN0IHVzZVN0b3JlSW1wbGVtZW50YXRpb24gPSBjYW5Vc2VSYXdVc2VTeW5jRXh0ZXJuYWxTdG9yZSA/IHVzZVN0b3JlRmFzdCA6IHVzZVN0b3JlTGVnYWN5O1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVN0b3JlKHN0b3JlLCBzZWxlY3RvciwgYTEsIGEyLCBhMykge1xuICByZXR1cm4gdXNlU3RvcmVJbXBsZW1lbnRhdGlvbihzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpO1xufVxuZnVuY3Rpb24gdXNlU3RvcmVSMTkoc3RvcmUsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gIGNvbnN0IGdldFNlbGVjdGlvbiA9IFJlYWN0LnVzZUNhbGxiYWNrKCgpID0+IHNlbGVjdG9yKHN0b3JlLmdldFNuYXBzaG90KCksIGExLCBhMiwgYTMpLCBbc3RvcmUsIHNlbGVjdG9yLCBhMSwgYTIsIGEzXSk7XG4gIHJldHVybiB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdG9yZS5zdWJzY3JpYmUsIGdldFNlbGVjdGlvbiwgZ2V0U2VsZWN0aW9uKTtcbn1cbnJlZ2lzdGVyKHtcbiAgYmVmb3JlKGluc3RhbmNlKSB7XG4gICAgaW5zdGFuY2Uuc3luY0luZGV4ID0gMDtcbiAgICBpZiAoIWluc3RhbmNlLmRpZEluaXRpYWxpemUpIHtcbiAgICAgIGluc3RhbmNlLnN5bmNUaWNrID0gMTtcbiAgICAgIGluc3RhbmNlLnN5bmNIb29rcyA9IFtdO1xuICAgICAgaW5zdGFuY2UuZGlkQ2hhbmdlU3RvcmUgPSB0cnVlO1xuICAgICAgaW5zdGFuY2UuZ2V0U25hcHNob3QgPSAoKSA9PiB7XG4gICAgICAgIGxldCBkaWRDaGFuZ2UgPSBmYWxzZTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnN0YW5jZS5zeW5jSG9va3MubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgICBjb25zdCBob29rID0gaW5zdGFuY2Uuc3luY0hvb2tzW2ldO1xuICAgICAgICAgIGNvbnN0IHZhbHVlID0gaG9vay5zZWxlY3Rvcihob29rLnN0b3JlLnN0YXRlLCBob29rLmExLCBob29rLmEyLCBob29rLmEzKTtcbiAgICAgICAgICBpZiAoIU9iamVjdC5pcyhob29rLnZhbHVlLCB2YWx1ZSkpIHtcbiAgICAgICAgICAgIGRpZENoYW5nZSA9IHRydWU7XG4gICAgICAgICAgICBob29rLnZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChkaWRDaGFuZ2UpIHtcbiAgICAgICAgICBpbnN0YW5jZS5zeW5jVGljayArPSAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpbnN0YW5jZS5zeW5jVGljaztcbiAgICAgIH07XG4gICAgfVxuICB9LFxuICBhZnRlcihpbnN0YW5jZSkge1xuICAgIGlmIChpbnN0YW5jZS5zeW5jSG9va3MubGVuZ3RoID4gMCkge1xuICAgICAgaWYgKGluc3RhbmNlLmRpZENoYW5nZVN0b3JlKSB7XG4gICAgICAgIGluc3RhbmNlLmRpZENoYW5nZVN0b3JlID0gZmFsc2U7XG4gICAgICAgIGluc3RhbmNlLnN1YnNjcmliZSA9IG9uU3RvcmVDaGFuZ2UgPT4ge1xuICAgICAgICAgIGNvbnN0IHN0b3JlcyA9IG5ldyBTZXQoKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGhvb2sgb2YgaW5zdGFuY2Uuc3luY0hvb2tzKSB7XG4gICAgICAgICAgICBzdG9yZXMuYWRkKGhvb2suc3RvcmUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCB1bnN1YnNjcmliZXMgPSBbXTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHN0b3JlIG9mIHN0b3Jlcykge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmVzLnB1c2goc3RvcmUuc3Vic2NyaWJlKG9uU3RvcmVDaGFuZ2UpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgdW5zdWJzY3JpYmUgb2YgdW5zdWJzY3JpYmVzKSB7XG4gICAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICAgICAgdXNlU3luY0V4dGVybmFsU3RvcmUoaW5zdGFuY2Uuc3Vic2NyaWJlLCBpbnN0YW5jZS5nZXRTbmFwc2hvdCwgaW5zdGFuY2UuZ2V0U25hcHNob3QpO1xuICAgIH1cbiAgfVxufSk7XG5mdW5jdGlvbiB1c2VTdG9yZUZhc3Qoc3RvcmUsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gIGNvbnN0IGluc3RhbmNlID0gZ2V0SW5zdGFuY2UoKTtcbiAgaWYgKCFpbnN0YW5jZSkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICAgIHJldHVybiB1c2VTdG9yZVIxOShzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpO1xuICB9XG4gIGNvbnN0IGluZGV4ID0gaW5zdGFuY2Uuc3luY0luZGV4O1xuICBpbnN0YW5jZS5zeW5jSW5kZXggKz0gMTtcbiAgbGV0IGhvb2s7XG4gIGlmICghaW5zdGFuY2UuZGlkSW5pdGlhbGl6ZSkge1xuICAgIGhvb2sgPSB7XG4gICAgICBzdG9yZSxcbiAgICAgIHNlbGVjdG9yLFxuICAgICAgYTEsXG4gICAgICBhMixcbiAgICAgIGEzLFxuICAgICAgdmFsdWU6IHNlbGVjdG9yKHN0b3JlLmdldFNuYXBzaG90KCksIGExLCBhMiwgYTMpXG4gICAgfTtcbiAgICBpbnN0YW5jZS5zeW5jSG9va3MucHVzaChob29rKTtcbiAgfSBlbHNlIHtcbiAgICBob29rID0gaW5zdGFuY2Uuc3luY0hvb2tzW2luZGV4XTtcbiAgICBpZiAoaG9vay5zdG9yZSAhPT0gc3RvcmUgfHwgaG9vay5zZWxlY3RvciAhPT0gc2VsZWN0b3IgfHwgIU9iamVjdC5pcyhob29rLmExLCBhMSkgfHwgIU9iamVjdC5pcyhob29rLmEyLCBhMikgfHwgIU9iamVjdC5pcyhob29rLmEzLCBhMykpIHtcbiAgICAgIGlmIChob29rLnN0b3JlICE9PSBzdG9yZSkge1xuICAgICAgICBpbnN0YW5jZS5kaWRDaGFuZ2VTdG9yZSA9IHRydWU7XG4gICAgICB9XG4gICAgICBob29rLnN0b3JlID0gc3RvcmU7XG4gICAgICBob29rLnNlbGVjdG9yID0gc2VsZWN0b3I7XG4gICAgICBob29rLmExID0gYTE7XG4gICAgICBob29rLmEyID0gYTI7XG4gICAgICBob29rLmEzID0gYTM7XG4gICAgICBob29rLnZhbHVlID0gc2VsZWN0b3Ioc3RvcmUuZ2V0U25hcHNob3QoKSwgYTEsIGEyLCBhMyk7XG4gICAgfVxuICB9XG4gIHJldHVybiBob29rLnZhbHVlO1xufVxuZnVuY3Rpb24gdXNlU3RvcmVMZWdhY3koc3RvcmUsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gIHJldHVybiB1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvcihzdG9yZS5zdWJzY3JpYmUsIHN0b3JlLmdldFNuYXBzaG90LCBzdG9yZS5nZXRTbmFwc2hvdCwgc3RhdGUgPT4gc2VsZWN0b3Ioc3RhdGUsIGExLCBhMiwgYTMpKTtcbn0iLCJpbXBvcnQgeyB1c2VTdG9yZSB9IGZyb20gXCIuL3VzZVN0b3JlLm1qc1wiO1xuLyoqXG4gKiBBIGRhdGEgc3RvcmUgaW1wbGVtZW50YXRpb24gdGhhdCBhbGxvd3Mgc3Vic2NyaWJpbmcgdG8gc3RhdGUgY2hhbmdlcyBhbmQgdXBkYXRpbmcgdGhlIHN0YXRlLlxuICogSXQgdXNlcyBhbiBvYnNlcnZlciBwYXR0ZXJuIHRvIG5vdGlmeSBzdWJzY3JpYmVycyB3aGVuIHRoZSBzdGF0ZSBjaGFuZ2VzLlxuICovXG5leHBvcnQgY2xhc3MgU3RvcmUge1xuICAvKipcbiAgICogVGhlIGN1cnJlbnQgc3RhdGUgb2YgdGhlIHN0b3JlLlxuICAgKiBUaGlzIHByb3BlcnR5IGlzIHVwZGF0ZWQgaW1tZWRpYXRlbHkgd2hlbiB0aGUgc3RhdGUgY2hhbmdlcyBhcyBhIHJlc3VsdCBvZiBjYWxsaW5nIHtAbGluayBzZXRTdGF0ZX0sIHtAbGluayB1cGRhdGV9LCBvciB7QGxpbmsgc2V0fS5cbiAgICogVG8gc3Vic2NyaWJlIHRvIHN0YXRlIGNoYW5nZXMsIHVzZSB0aGUge0BsaW5rIHVzZVN0YXRlfSBtZXRob2QuIFRoZSB2YWx1ZSByZXR1cm5lZCBieSB7QGxpbmsgdXNlU3RhdGV9IGlzIHVwZGF0ZWQgYWZ0ZXIgdGhlIGNvbXBvbmVudCByZW5kZXJzIChzaW1pbGFybHkgdG8gUmVhY3QncyB1c2VTdGF0ZSkuXG4gICAqIFRoZSB2YWx1ZXMgY2FuIGJlIHVzZWQgZGlyZWN0bHkgKHRvIGF2b2lkIHN1YnNjcmliaW5nIHRvIHRoZSBzdG9yZSkgaW4gZWZmZWN0cyBvciBldmVudCBoYW5kbGVycy5cbiAgICpcbiAgICogRG8gbm90IG1vZGlmeSBwcm9wZXJ0aWVzIGluIHN0YXRlIGRpcmVjdGx5LiBJbnN0ZWFkLCB1c2UgdGhlIHByb3ZpZGVkIG1ldGhvZHMgdG8gZW5zdXJlIHByb3BlciBzdGF0ZSBtYW5hZ2VtZW50IGFuZCBsaXN0ZW5lciBub3RpZmljYXRpb24uXG4gICAqL1xuXG4gIC8vIEludGVybmFsIHN0YXRlIHRvIGhhbmRsZSByZWN1cnNpdmUgYHNldFN0YXRlKClgIGNhbGxzXG5cbiAgY29uc3RydWN0b3Ioc3RhdGUpIHtcbiAgICB0aGlzLnN0YXRlID0gc3RhdGU7XG4gICAgdGhpcy5saXN0ZW5lcnMgPSBuZXcgU2V0KCk7XG4gICAgdGhpcy51cGRhdGVUaWNrID0gMDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBsaXN0ZW5lciB0aGF0IHdpbGwgYmUgY2FsbGVkIHdoZW5ldmVyIHRoZSBzdG9yZSdzIHN0YXRlIGNoYW5nZXMuXG4gICAqXG4gICAqIEBwYXJhbSBmbiBUaGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIG9uIHN0YXRlIGNoYW5nZXMuXG4gICAqIEByZXR1cm5zIEEgZnVuY3Rpb24gdG8gdW5zdWJzY3JpYmUgdGhlIGxpc3RlbmVyLlxuICAgKi9cbiAgc3Vic2NyaWJlID0gZm4gPT4ge1xuICAgIHRoaXMubGlzdGVuZXJzLmFkZChmbik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMubGlzdGVuZXJzLmRlbGV0ZShmbik7XG4gICAgfTtcbiAgfTtcblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgY3VycmVudCBzdGF0ZSBvZiB0aGUgc3RvcmUuXG4gICAqL1xuICBnZXRTbmFwc2hvdCA9ICgpID0+IHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZTtcbiAgfTtcblxuICAvKipcbiAgICogVXBkYXRlcyB0aGUgZW50aXJlIHN0b3JlJ3Mgc3RhdGUgYW5kIG5vdGlmaWVzIGFsbCByZWdpc3RlcmVkIGxpc3RlbmVycy5cbiAgICpcbiAgICogQHBhcmFtIG5ld1N0YXRlIFRoZSBuZXcgc3RhdGUgdG8gc2V0IGZvciB0aGUgc3RvcmUuXG4gICAqL1xuICBzZXRTdGF0ZShuZXdTdGF0ZSkge1xuICAgIGlmICh0aGlzLnN0YXRlID09PSBuZXdTdGF0ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnN0YXRlID0gbmV3U3RhdGU7XG4gICAgdGhpcy51cGRhdGVUaWNrICs9IDE7XG4gICAgY29uc3QgY3VycmVudFRpY2sgPSB0aGlzLnVwZGF0ZVRpY2s7XG4gICAgZm9yIChjb25zdCBsaXN0ZW5lciBvZiB0aGlzLmxpc3RlbmVycykge1xuICAgICAgaWYgKGN1cnJlbnRUaWNrICE9PSB0aGlzLnVwZGF0ZVRpY2spIHtcbiAgICAgICAgLy8gSWYgdGhlIHRpY2sgaGFzIGNoYW5nZWQsIGEgcmVjdXJzaXZlIGBzZXRTdGF0ZWAgY2FsbCBoYXMgYmVlbiBtYWRlLFxuICAgICAgICAvLyBhbmQgaXQgaGFzIGFscmVhZHkgbm90aWZpZWQgYWxsIGxpc3RlbmVycy5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGlzdGVuZXIobmV3U3RhdGUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBNZXJnZXMgdGhlIHByb3ZpZGVkIGNoYW5nZXMgaW50byB0aGUgY3VycmVudCBzdGF0ZSBhbmQgbm90aWZpZXMgbGlzdGVuZXJzIGlmIHRoZXJlIGFyZSBjaGFuZ2VzLlxuICAgKlxuICAgKiBAcGFyYW0gY2hhbmdlcyBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgY2hhbmdlcyB0byBhcHBseSB0byB0aGUgY3VycmVudCBzdGF0ZS5cbiAgICovXG4gIHVwZGF0ZShjaGFuZ2VzKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gY2hhbmdlcykge1xuICAgICAgaWYgKCFPYmplY3QuaXModGhpcy5zdGF0ZVtrZXldLCBjaGFuZ2VzW2tleV0pKSB7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIC4uLnRoaXMuc3RhdGUsXG4gICAgICAgICAgLi4uY2hhbmdlc1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIGEgc3BlY2lmaWMga2V5IGluIHRoZSBzdG9yZSdzIHN0YXRlIHRvIGEgbmV3IHZhbHVlIGFuZCBub3RpZmllcyBsaXN0ZW5lcnMgaWYgdGhlIHZhbHVlIGhhcyBjaGFuZ2VkLlxuICAgKlxuICAgKiBAcGFyYW0ga2V5IFRoZSBrZXkgaW4gdGhlIHN0b3JlJ3Mgc3RhdGUgdG8gdXBkYXRlLlxuICAgKiBAcGFyYW0gdmFsdWUgVGhlIG5ldyB2YWx1ZSB0byBzZXQgZm9yIHRoZSBzcGVjaWZpZWQga2V5LlxuICAgKi9cbiAgc2V0KGtleSwgdmFsdWUpIHtcbiAgICBpZiAoIU9iamVjdC5pcyh0aGlzLnN0YXRlW2tleV0sIHZhbHVlKSkge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIC4uLnRoaXMuc3RhdGUsXG4gICAgICAgIFtrZXldOiB2YWx1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBzdGF0ZSBhIG5ldyByZWZlcmVuY2UgYW5kIHVwZGF0ZXMgYWxsIHJlZ2lzdGVyZWQgbGlzdGVuZXJzLlxuICAgKi9cbiAgbm90aWZ5QWxsKCkge1xuICAgIGNvbnN0IG5ld1N0YXRlID0ge1xuICAgICAgLi4udGhpcy5zdGF0ZVxuICAgIH07XG4gICAgdGhpcy5zZXRTdGF0ZShuZXdTdGF0ZSk7XG4gIH1cbiAgdXNlKHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgcmV0dXJuIHVzZVN0b3JlKHRoaXMsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKTtcbiAgfVxufSIsIi8qIEZhbHNlIHBvc2l0aXZlcyAtIEVTTGludCB0aGlua3Mgd2UncmUgY2FsbGluZyBhIGhvb2sgZnJvbSBhIGNsYXNzIGNvbXBvbmVudC4gKi9cbi8qIGVzbGludC1kaXNhYmxlIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzICovXG4ndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFN0b3JlIH0gZnJvbSBcIi4vU3RvcmUubWpzXCI7XG5pbXBvcnQgeyB1c2VTdG9yZSB9IGZyb20gXCIuL3VzZVN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tIFwiLi4vdXNlU3RhYmxlQ2FsbGJhY2subWpzXCI7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi4vdXNlSXNvTGF5b3V0RWZmZWN0Lm1qc1wiO1xuaW1wb3J0IHsgTk9PUCB9IGZyb20gXCIuLi9lbXB0eS5tanNcIjtcblxuLyoqXG4gKiBBIFN0b3JlIHRoYXQgc3VwcG9ydHMgY29udHJvbGxlZCBzdGF0ZSBrZXlzLCBub24tcmVhY3RpdmUgdmFsdWVzIGFuZCBwcm92aWRlcyB1dGlsaXR5IG1ldGhvZHMgZm9yIFJlYWN0LlxuICovXG5leHBvcnQgY2xhc3MgUmVhY3RTdG9yZSBleHRlbmRzIFN0b3JlIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgUmVhY3RTdG9yZSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHBhcmFtIHN0YXRlIEluaXRpYWwgc3RhdGUgb2YgdGhlIHN0b3JlLlxuICAgKiBAcGFyYW0gY29udGV4dCBOb24tcmVhY3RpdmUgY29udGV4dCB2YWx1ZXMuXG4gICAqIEBwYXJhbSBzZWxlY3RvcnMgT3B0aW9uYWwgc2VsZWN0b3JzIGZvciB1c2Ugd2l0aCBgdXNlU3RhdGVgLlxuICAgKi9cbiAgY29uc3RydWN0b3Ioc3RhdGUsIGNvbnRleHQgPSB7fSwgc2VsZWN0b3JzKSB7XG4gICAgc3VwZXIoc3RhdGUpO1xuICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgdGhpcy5zZWxlY3RvcnMgPSBzZWxlY3RvcnM7XG4gIH1cblxuICAvKipcbiAgICogTm9uLXJlYWN0aXZlIHZhbHVlcyBzdWNoIGFzIHJlZnMsIGNhbGxiYWNrcywgZXRjLlxuICAgKi9cblxuICAvKipcbiAgICogU3luY2hyb25pemVzIGEgc2luZ2xlIGV4dGVybmFsIHZhbHVlIGludG8gdGhlIHN0b3JlLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgdGhlIHdoaWxlIHRoZSB2YWx1ZSBpbiBgc3RhdGVgIGlzIHVwZGF0ZWQgaW1tZWRpYXRlbHksIHRoZSB2YWx1ZSByZXR1cm5lZFxuICAgKiBieSBgdXNlU3RhdGVgIGlzIHVwZGF0ZWQgYmVmb3JlIHRoZSBuZXh0IHJlbmRlciAoc2ltaWxhcmx5IHRvIFJlYWN0J3MgYHVzZVN0YXRlYCkuXG4gICAqL1xuICB1c2VTeW5jZWRWYWx1ZShrZXksIHZhbHVlKSB7XG4gICAgUmVhY3QudXNlRGVidWdWYWx1ZShrZXkpO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIGlmIChzdG9yZS5zdGF0ZVtrZXldICE9PSB2YWx1ZSkge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfSwgW3N0b3JlLCBrZXksIHZhbHVlXSk7XG4gIH1cblxuICAvKipcbiAgICogU3luY2hyb25pemVzIGEgc2luZ2xlIGV4dGVybmFsIHZhbHVlIGludG8gdGhlIHN0b3JlIGFuZFxuICAgKiBjbGVhbnMgaXQgdXAgKHNldHMgdG8gYHVuZGVmaW5lZGApIG9uIHVubW91bnQuXG4gICAqXG4gICAqIE5vdGUgdGhhdCB0aGUgd2hpbGUgdGhlIHZhbHVlIGluIGBzdGF0ZWAgaXMgdXBkYXRlZCBpbW1lZGlhdGVseSwgdGhlIHZhbHVlIHJldHVybmVkXG4gICAqIGJ5IGB1c2VTdGF0ZWAgaXMgdXBkYXRlZCBiZWZvcmUgdGhlIG5leHQgcmVuZGVyIChzaW1pbGFybHkgdG8gUmVhY3QncyBgdXNlU3RhdGVgKS5cbiAgICovXG4gIHVzZVN5bmNlZFZhbHVlV2l0aENsZWFudXAoa2V5LCB2YWx1ZSkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIGlmIChzdG9yZS5zdGF0ZVtrZXldICE9PSB2YWx1ZSkge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB1bmRlZmluZWQpO1xuICAgICAgfTtcbiAgICB9LCBbc3RvcmUsIGtleSwgdmFsdWVdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5jaHJvbml6ZXMgbXVsdGlwbGUgZXh0ZXJuYWwgdmFsdWVzIGludG8gdGhlIHN0b3JlLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgdGhlIHdoaWxlIHRoZSB2YWx1ZXMgaW4gYHN0YXRlYCBhcmUgdXBkYXRlZCBpbW1lZGlhdGVseSwgdGhlIHZhbHVlcyByZXR1cm5lZFxuICAgKiBieSBgdXNlU3RhdGVgIGFyZSB1cGRhdGVkIGJlZm9yZSB0aGUgbmV4dCByZW5kZXIgKHNpbWlsYXJseSB0byBSZWFjdCdzIGB1c2VTdGF0ZWApLlxuICAgKi9cbiAgdXNlU3luY2VkVmFsdWVzKHN0YXRlUGFydCkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIC8vIENoZWNrIHRoYXQgYW4gb2JqZWN0IHdpdGggdGhlIHNhbWUgc2hhcGUgaXMgcGFzc2VkIG9uIGV2ZXJ5IHJlbmRlclxuICAgICAgUmVhY3QudXNlRGVidWdWYWx1ZShzdGF0ZVBhcnQsIHAgPT4gT2JqZWN0LmtleXMocCkpO1xuICAgICAgY29uc3Qga2V5cyA9IFJlYWN0LnVzZVJlZihPYmplY3Qua2V5cyhzdGF0ZVBhcnQpKS5jdXJyZW50O1xuICAgICAgY29uc3QgbmV4dEtleXMgPSBPYmplY3Qua2V5cyhzdGF0ZVBhcnQpO1xuICAgICAgaWYgKGtleXMubGVuZ3RoICE9PSBuZXh0S2V5cy5sZW5ndGggfHwga2V5cy5zb21lKChrZXksIGluZGV4KSA9PiBrZXkgIT09IG5leHRLZXlzW2luZGV4XSkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignUmVhY3RTdG9yZS51c2VTeW5jZWRWYWx1ZXMgZXhwZWN0cyB0aGUgc2FtZSBwcm9wIGtleXMgb24gZXZlcnkgcmVuZGVyLiBLZXlzIHNob3VsZCBiZSBzdGFibGUuJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGRlcGVuZGVuY2llcyA9IE9iamVjdC52YWx1ZXMoc3RhdGVQYXJ0KTtcbiAgICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgc3RvcmUudXBkYXRlKHN0YXRlUGFydCk7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgfSwgW3N0b3JlLCAuLi5kZXBlbmRlbmNpZXNdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBjb250cm9sbGFibGUgcHJvcCBwYWlyIChgY29udHJvbGxlZGAsIGBkZWZhdWx0VmFsdWVgKSBmb3IgYSBzcGVjaWZpYyBrZXkuIElmIGBjb250cm9sbGVkYFxuICAgKiBpcyBub24tdW5kZWZpbmVkLCB0aGUgc3RvcmUncyBzdGF0ZSBhdCBga2V5YCBpcyB1cGRhdGVkIHRvIG1hdGNoIGBjb250cm9sbGVkYC5cbiAgICovXG4gIHVzZUNvbnRyb2xsZWRQcm9wKGtleSwgY29udHJvbGxlZCkge1xuICAgIFJlYWN0LnVzZURlYnVnVmFsdWUoa2V5KTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC10aGlzXG4gICAgY29uc3Qgc3RvcmUgPSB0aGlzO1xuICAgIGNvbnN0IGlzQ29udHJvbGxlZCA9IGNvbnRyb2xsZWQgIT09IHVuZGVmaW5lZDtcbiAgICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKGlzQ29udHJvbGxlZCAmJiAhT2JqZWN0LmlzKHN0b3JlLnN0YXRlW2tleV0sIGNvbnRyb2xsZWQpKSB7XG4gICAgICAgIC8vIFNldCB0aGUgaW50ZXJuYWwgc3RhdGUgdG8gbWF0Y2ggdGhlIGNvbnRyb2xsZWQgdmFsdWUuXG4gICAgICAgIHN0b3JlLnNldFN0YXRlKHtcbiAgICAgICAgICAuLi5zdG9yZS5zdGF0ZSxcbiAgICAgICAgICBba2V5XTogY29udHJvbGxlZFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LCBbc3RvcmUsIGtleSwgY29udHJvbGxlZCwgaXNDb250cm9sbGVkXSk7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgY29uc3QgY2FjaGUgPSB0aGlzLmNvbnRyb2xsZWRWYWx1ZXMgPz89IG5ldyBNYXAoKTtcbiAgICAgIGlmICghY2FjaGUuaGFzKGtleSkpIHtcbiAgICAgICAgY2FjaGUuc2V0KGtleSwgaXNDb250cm9sbGVkKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHByZXZpb3VzbHlDb250cm9sbGVkID0gY2FjaGUuZ2V0KGtleSk7XG4gICAgICBpZiAocHJldmlvdXNseUNvbnRyb2xsZWQgIT09IHVuZGVmaW5lZCAmJiBwcmV2aW91c2x5Q29udHJvbGxlZCAhPT0gaXNDb250cm9sbGVkKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEEgY29tcG9uZW50IGlzIGNoYW5naW5nIHRoZSAke2lzQ29udHJvbGxlZCA/ICcnIDogJ3VuJ31jb250cm9sbGVkIHN0YXRlIG9mICR7a2V5LnRvU3RyaW5nKCl9IHRvIGJlICR7aXNDb250cm9sbGVkID8gJ3VuJyA6ICcnfWNvbnRyb2xsZWQuIEVsZW1lbnRzIHNob3VsZCBub3Qgc3dpdGNoIGZyb20gdW5jb250cm9sbGVkIHRvIGNvbnRyb2xsZWQgKG9yIHZpY2UgdmVyc2EpLmApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKiBHZXRzIHRoZSBjdXJyZW50IHZhbHVlIGZyb20gdGhlIHN0b3JlIHVzaW5nIGEgc2VsZWN0b3Igd2l0aCB0aGUgcHJvdmlkZWQga2V5LlxuICAgKlxuICAgKiBAcGFyYW0ga2V5IEtleSBvZiB0aGUgc2VsZWN0b3IgdG8gdXNlLlxuICAgKi9cblxuICBzZWxlY3Qoa2V5LCBhMSwgYTIsIGEzKSB7XG4gICAgY29uc3Qgc2VsZWN0b3IgPSB0aGlzLnNlbGVjdG9yc1trZXldO1xuICAgIHJldHVybiBzZWxlY3Rvcih0aGlzLnN0YXRlLCBhMSwgYTIsIGEzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgdmFsdWUgZnJvbSB0aGUgc3RvcmUncyBzdGF0ZSB1c2luZyBhIHNlbGVjdG9yIGZ1bmN0aW9uLlxuICAgKiBVc2VkIHRvIHN1YnNjcmliZSB0byBzcGVjaWZpYyBwYXJ0cyBvZiB0aGUgc3RhdGUuXG4gICAqIFRoaXMgbWV0aG9kcyBjYXVzZXMgYSByZXJlbmRlciB3aGVuZXZlciB0aGUgc2VsZWN0ZWQgc3RhdGUgY2hhbmdlcy5cbiAgICpcbiAgICogQHBhcmFtIGtleSBLZXkgb2YgdGhlIHNlbGVjdG9yIHRvIHVzZS5cbiAgICovXG5cbiAgdXNlU3RhdGUoa2V5LCBhMSwgYTIsIGEzKSB7XG4gICAgUmVhY3QudXNlRGVidWdWYWx1ZShrZXkpO1xuICAgIHJldHVybiB1c2VTdG9yZSh0aGlzLCB0aGlzLnNlbGVjdG9yc1trZXldLCBhMSwgYTIsIGEzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBXcmFwcyBhIGZ1bmN0aW9uIHdpdGggYHVzZVN0YWJsZUNhbGxiYWNrYCB0byBlbnN1cmUgaXQgaGFzIGEgc3RhYmxlIHJlZmVyZW5jZVxuICAgKiBhbmQgYXNzaWducyBpdCB0byB0aGUgY29udGV4dC5cbiAgICpcbiAgICogQHBhcmFtIGtleSBLZXkgb2YgdGhlIGV2ZW50IGNhbGxiYWNrLiBNdXN0IGJlIGEgZnVuY3Rpb24gaW4gdGhlIGNvbnRleHQuXG4gICAqIEBwYXJhbSBmbiBGdW5jdGlvbiB0byBhc3NpZ24uXG4gICAqL1xuICB1c2VDb250ZXh0Q2FsbGJhY2soa2V5LCBmbikge1xuICAgIFJlYWN0LnVzZURlYnVnVmFsdWUoa2V5KTtcbiAgICBjb25zdCBzdGFibGVGdW5jdGlvbiA9IHVzZVN0YWJsZUNhbGxiYWNrKGZuID8/IE5PT1ApO1xuICAgIHRoaXMuY29udGV4dFtrZXldID0gc3RhYmxlRnVuY3Rpb247XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIHN0YWJsZSBzZXR0ZXIgZnVuY3Rpb24gZm9yIGEgc3BlY2lmaWMga2V5IGluIHRoZSBzdG9yZSdzIHN0YXRlLlxuICAgKiBJdCdzIGNvbW1vbmx5IHVzZWQgdG8gcGFzcyBhcyBhIHJlZiBjYWxsYmFjayB0byBSZWFjdCBlbGVtZW50cy5cbiAgICpcbiAgICogQHBhcmFtIGtleSBLZXkgb2YgdGhlIHN0YXRlIHRvIHNldC5cbiAgICovXG4gIHVzZVN0YXRlU2V0dGVyKGtleSkge1xuICAgIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICAgIGlmIChyZWYuY3VycmVudCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZWYuY3VycmVudCA9IHZhbHVlID0+IHtcbiAgICAgICAgdGhpcy5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gcmVmLmN1cnJlbnQ7XG4gIH1cblxuICAvKipcbiAgICogT2JzZXJ2ZXMgY2hhbmdlcyBkZXJpdmVkIGZyb20gdGhlIHN0b3JlJ3Mgc2VsZWN0b3JzIGFuZCBjYWxscyB0aGUgbGlzdGVuZXIgd2hlbiB0aGUgc2VsZWN0ZWQgdmFsdWUgY2hhbmdlcy5cbiAgICpcbiAgICogQHBhcmFtIGtleSBLZXkgb2YgdGhlIHNlbGVjdG9yIHRvIG9ic2VydmUuXG4gICAqIEBwYXJhbSBsaXN0ZW5lciBMaXN0ZW5lciBmdW5jdGlvbiBjYWxsZWQgd2hlbiB0aGUgc2VsZWN0b3IgcmVzdWx0IGNoYW5nZXMuXG4gICAqL1xuXG4gIG9ic2VydmUoc2VsZWN0b3IsIGxpc3RlbmVyKSB7XG4gICAgbGV0IHNlbGVjdEZuO1xuICAgIGlmICh0eXBlb2Ygc2VsZWN0b3IgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHNlbGVjdEZuID0gc2VsZWN0b3I7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNlbGVjdEZuID0gdGhpcy5zZWxlY3RvcnNbc2VsZWN0b3JdO1xuICAgIH1cbiAgICBsZXQgcHJldlZhbHVlID0gc2VsZWN0Rm4odGhpcy5zdGF0ZSk7XG4gICAgbGlzdGVuZXIocHJldlZhbHVlLCBwcmV2VmFsdWUsIHRoaXMpO1xuICAgIHJldHVybiB0aGlzLnN1YnNjcmliZShuZXh0U3RhdGUgPT4ge1xuICAgICAgY29uc3QgbmV4dFZhbHVlID0gc2VsZWN0Rm4obmV4dFN0YXRlKTtcbiAgICAgIGlmICghT2JqZWN0LmlzKHByZXZWYWx1ZSwgbmV4dFZhbHVlKSkge1xuICAgICAgICBjb25zdCBvbGRWYWx1ZSA9IHByZXZWYWx1ZTtcbiAgICAgICAgcHJldlZhbHVlID0gbmV4dFZhbHVlO1xuICAgICAgICBsaXN0ZW5lcihuZXh0VmFsdWUsIG9sZFZhbHVlLCB0aGlzKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufSIsImltcG9ydCB7IFJlYWN0U3RvcmUgfSBmcm9tICdAYmFzZS11aS91dGlscy9zdG9yZSc7XG5pbXBvcnQgeyBjcmVhdGVFdmVudEVtaXR0ZXIgfSBmcm9tIFwiLi4vdXRpbHMvY3JlYXRlRXZlbnRFbWl0dGVyLm1qc1wiO1xuaW1wb3J0IHsgaXNDbGlja0xpa2VFdmVudCB9IGZyb20gXCIuLi91dGlscy5tanNcIjtcbmNvbnN0IHNlbGVjdG9ycyA9IHtcbiAgb3Blbjogc3RhdGUgPT4gc3RhdGUub3BlbixcbiAgdHJhbnNpdGlvblN0YXR1czogc3RhdGUgPT4gc3RhdGUudHJhbnNpdGlvblN0YXR1cyxcbiAgZG9tUmVmZXJlbmNlRWxlbWVudDogc3RhdGUgPT4gc3RhdGUuZG9tUmVmZXJlbmNlRWxlbWVudCxcbiAgcmVmZXJlbmNlRWxlbWVudDogc3RhdGUgPT4gc3RhdGUucG9zaXRpb25SZWZlcmVuY2UgPz8gc3RhdGUucmVmZXJlbmNlRWxlbWVudCxcbiAgZmxvYXRpbmdFbGVtZW50OiBzdGF0ZSA9PiBzdGF0ZS5mbG9hdGluZ0VsZW1lbnQsXG4gIGZsb2F0aW5nSWQ6IHN0YXRlID0+IHN0YXRlLmZsb2F0aW5nSWRcbn07XG5leHBvcnQgY2xhc3MgRmxvYXRpbmdSb290U3RvcmUgZXh0ZW5kcyBSZWFjdFN0b3JlIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIGNvbnN0IHtcbiAgICAgIHN5bmNPbmx5LFxuICAgICAgbmVzdGVkLFxuICAgICAgb25PcGVuQ2hhbmdlLFxuICAgICAgdHJpZ2dlckVsZW1lbnRzLFxuICAgICAgLi4uaW5pdGlhbFN0YXRlXG4gICAgfSA9IG9wdGlvbnM7XG4gICAgc3VwZXIoe1xuICAgICAgLi4uaW5pdGlhbFN0YXRlLFxuICAgICAgcG9zaXRpb25SZWZlcmVuY2U6IGluaXRpYWxTdGF0ZS5yZWZlcmVuY2VFbGVtZW50LFxuICAgICAgZG9tUmVmZXJlbmNlRWxlbWVudDogaW5pdGlhbFN0YXRlLnJlZmVyZW5jZUVsZW1lbnRcbiAgICB9LCB7XG4gICAgICBvbk9wZW5DaGFuZ2UsXG4gICAgICBkYXRhUmVmOiB7XG4gICAgICAgIGN1cnJlbnQ6IHt9XG4gICAgICB9LFxuICAgICAgZXZlbnRzOiBjcmVhdGVFdmVudEVtaXR0ZXIoKSxcbiAgICAgIG5lc3RlZCxcbiAgICAgIHRyaWdnZXJFbGVtZW50c1xuICAgIH0sIHNlbGVjdG9ycyk7XG4gICAgdGhpcy5zeW5jT25seSA9IHN5bmNPbmx5O1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bmNzIHRoZSBldmVudCB1c2VkIGJ5IGhvdmVyIGxvZ2ljIHRvIGRpc3Rpbmd1aXNoIGhvdmVyLW9wZW4gZnJvbSBjbGljay1saWtlIGludGVyYWN0aW9uLlxuICAgKi9cbiAgc3luY09wZW5FdmVudCA9IChuZXdPcGVuLCBldmVudCkgPT4ge1xuICAgIGlmICghbmV3T3BlbiB8fCAhdGhpcy5zdGF0ZS5vcGVuIHx8XG4gICAgLy8gUHJldmVudCBhIHBlbmRpbmcgaG92ZXItb3BlbiBmcm9tIG92ZXJ3cml0aW5nIGEgY2xpY2stb3BlbiBldmVudCwgd2hpbGUgYWxsb3dpbmdcbiAgICAvLyBjbGljayBldmVudHMgdG8gdXBncmFkZSBhIGhvdmVyLW9wZW4uXG4gICAgZXZlbnQgIT0gbnVsbCAmJiBpc0NsaWNrTGlrZUV2ZW50KGV2ZW50KSkge1xuICAgICAgdGhpcy5jb250ZXh0LmRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQgPSBuZXdPcGVuID8gZXZlbnQgOiB1bmRlZmluZWQ7XG4gICAgfVxuICB9O1xuXG4gIC8qKlxuICAgKiBSdW5zIHRoZSByb290LW93bmVkIHNpZGUgZWZmZWN0cyBmb3IgYW4gb3BlbiBzdGF0ZSBjaGFuZ2UuXG4gICAqL1xuICBkaXNwYXRjaE9wZW5DaGFuZ2UgPSAobmV3T3BlbiwgZXZlbnREZXRhaWxzKSA9PiB7XG4gICAgdGhpcy5zeW5jT3BlbkV2ZW50KG5ld09wZW4sIGV2ZW50RGV0YWlscy5ldmVudCk7XG4gICAgY29uc3QgZGV0YWlscyA9IHtcbiAgICAgIG9wZW46IG5ld09wZW4sXG4gICAgICByZWFzb246IGV2ZW50RGV0YWlscy5yZWFzb24sXG4gICAgICBuYXRpdmVFdmVudDogZXZlbnREZXRhaWxzLmV2ZW50LFxuICAgICAgbmVzdGVkOiB0aGlzLmNvbnRleHQubmVzdGVkLFxuICAgICAgdHJpZ2dlckVsZW1lbnQ6IGV2ZW50RGV0YWlscy50cmlnZ2VyXG4gICAgfTtcbiAgICB0aGlzLmNvbnRleHQuZXZlbnRzLmVtaXQoJ29wZW5jaGFuZ2UnLCBkZXRhaWxzKTtcbiAgfTtcblxuICAvKipcbiAgICogRW1pdHMgdGhlIGBvcGVuY2hhbmdlYCBldmVudCB0aHJvdWdoIHRoZSBpbnRlcm5hbCBldmVudCBlbWl0dGVyIGFuZCBjYWxscyB0aGUgYG9uT3BlbkNoYW5nZWAgaGFuZGxlciB3aXRoIHRoZSBwcm92aWRlZCBhcmd1bWVudHMuXG4gICAqXG4gICAqIEBwYXJhbSBuZXdPcGVuIFRoZSBuZXcgb3BlbiBzdGF0ZS5cbiAgICogQHBhcmFtIGV2ZW50RGV0YWlscyBEZXRhaWxzIGFib3V0IHRoZSBldmVudCB0aGF0IHRyaWdnZXJlZCB0aGUgb3BlbiBzdGF0ZSBjaGFuZ2UuXG4gICAqL1xuICBzZXRPcGVuID0gKG5ld09wZW4sIGV2ZW50RGV0YWlscykgPT4ge1xuICAgIGlmICh0aGlzLnN5bmNPbmx5KSB7XG4gICAgICB0aGlzLmNvbnRleHQub25PcGVuQ2hhbmdlPy4obmV3T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5kaXNwYXRjaE9wZW5DaGFuZ2UobmV3T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgICB0aGlzLmNvbnRleHQub25PcGVuQ2hhbmdlPy4obmV3T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBpc0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IEZsb2F0aW5nUm9vdFN0b3JlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvRmxvYXRpbmdSb290U3RvcmUubWpzXCI7XG4vKipcbiAqIEtlZXBzIGEgRmxvYXRpbmdSb290U3RvcmUgaW4gc3luYyB3aXRoIHRoZSBwcm92aWRlZCBQb3B1cFN0b3JlLlxuICogVXNlcyB0aGUgcHJvdmlkZWQgRmxvYXRpbmdSb290U3RvcmUgd2hlbiBvbmUgZXhpc3RzLCBvdGhlcndpc2UgY3JlYXRlcyBvbmUgb25jZSBhbmQgdXBkYXRlcyBpdCBvbiBldmVyeSByZW5kZXIuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0KG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHBvcHVwU3RvcmUsXG4gICAgdHJlYXRQb3B1cEFzRmxvYXRpbmdFbGVtZW50ID0gZmFsc2UsXG4gICAgZmxvYXRpbmdSb290Q29udGV4dDogZmxvYXRpbmdSb290Q29udGV4dFByb3AsXG4gICAgZmxvYXRpbmdJZCxcbiAgICBuZXN0ZWQsXG4gICAgb25PcGVuQ2hhbmdlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBvcGVuID0gcG9wdXBTdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCByZWZlcmVuY2VFbGVtZW50ID0gcG9wdXBTdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgY29uc3QgZmxvYXRpbmdFbGVtZW50ID0gcG9wdXBTdG9yZS51c2VTdGF0ZSh0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgPyAncG9wdXBFbGVtZW50JyA6ICdwb3NpdGlvbmVyRWxlbWVudCcpO1xuICBjb25zdCB0cmlnZ2VyRWxlbWVudHMgPSBwb3B1cFN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzO1xuICBjb25zdCBoYW5kbGVPcGVuQ2hhbmdlID0gb25PcGVuQ2hhbmdlO1xuICBjb25zdCBpbnRlcm5hbFN0b3JlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBpZiAoZmxvYXRpbmdSb290Q29udGV4dFByb3AgPT09IHVuZGVmaW5lZCAmJiBpbnRlcm5hbFN0b3JlUmVmLmN1cnJlbnQgPT09IG51bGwpIHtcbiAgICBpbnRlcm5hbFN0b3JlUmVmLmN1cnJlbnQgPSBuZXcgRmxvYXRpbmdSb290U3RvcmUoe1xuICAgICAgb3BlbixcbiAgICAgIHRyYW5zaXRpb25TdGF0dXM6IHVuZGVmaW5lZCxcbiAgICAgIHJlZmVyZW5jZUVsZW1lbnQsXG4gICAgICBmbG9hdGluZ0VsZW1lbnQsXG4gICAgICB0cmlnZ2VyRWxlbWVudHMsXG4gICAgICBvbk9wZW5DaGFuZ2U6IGhhbmRsZU9wZW5DaGFuZ2UsXG4gICAgICBmbG9hdGluZ0lkLFxuICAgICAgc3luY09ubHk6IHRydWUsXG4gICAgICBuZXN0ZWRcbiAgICB9KTtcbiAgfVxuICBjb25zdCBzdG9yZSA9IGZsb2F0aW5nUm9vdENvbnRleHRQcm9wID8/IGludGVybmFsU3RvcmVSZWYuY3VycmVudDtcbiAgcG9wdXBTdG9yZS51c2VTeW5jZWRWYWx1ZSgnZmxvYXRpbmdJZCcsIGZsb2F0aW5nSWQpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHZhbHVlc1RvU3luYyA9IHtcbiAgICAgIG9wZW4sXG4gICAgICBmbG9hdGluZ0lkLFxuICAgICAgcmVmZXJlbmNlRWxlbWVudCxcbiAgICAgIGZsb2F0aW5nRWxlbWVudFxuICAgIH07XG4gICAgaWYgKGlzRWxlbWVudChyZWZlcmVuY2VFbGVtZW50KSkge1xuICAgICAgdmFsdWVzVG9TeW5jLmRvbVJlZmVyZW5jZUVsZW1lbnQgPSByZWZlcmVuY2VFbGVtZW50O1xuICAgIH1cbiAgICBpZiAoc3RvcmUuc3RhdGUucG9zaXRpb25SZWZlcmVuY2UgPT09IHN0b3JlLnN0YXRlLnJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgICAgIHZhbHVlc1RvU3luYy5wb3NpdGlvblJlZmVyZW5jZSA9IHJlZmVyZW5jZUVsZW1lbnQ7XG4gICAgfVxuICAgIHN0b3JlLnVwZGF0ZSh2YWx1ZXNUb1N5bmMpO1xuICB9LCBbb3BlbiwgZmxvYXRpbmdJZCwgcmVmZXJlbmNlRWxlbWVudCwgZmxvYXRpbmdFbGVtZW50LCBzdG9yZV0pO1xuXG4gIC8vIEtlZXAgbm9uLXJlYWN0aXZlIGNvbnRleHQgdmFsdWVzIGZyZXNoIGZvciBpbnRlcmFjdGlvbnMgdGhhdCBjYWxsIGBzdG9yZS5zZXRPcGVuYC5cbiAgc3RvcmUuY29udGV4dC5vbk9wZW5DaGFuZ2UgPSBoYW5kbGVPcGVuQ2hhbmdlO1xuICBzdG9yZS5jb250ZXh0Lm5lc3RlZCA9IG5lc3RlZDtcbiAgcmV0dXJuIHN0b3JlO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IEVNUFRZX09CSkVDVCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IHVzZUlkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSWQnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VSZWZXaXRoSW5pdCc7XG5pbXBvcnQgeyBGT0NVU0FCTEVfQVRUUklCVVRFIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2NvbXBvbmVudHMvRmxvYXRpbmdUcmVlLm1qc1wiO1xuaW1wb3J0IHsgdXNlU3luY2VkRmxvYXRpbmdSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlVHJhbnNpdGlvblN0YXR1cyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlVHJhbnNpdGlvblN0YXR1cy5tanNcIjtcbmltcG9ydCB7IHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlT3BlbkNoYW5nZUNvbXBsZXRlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuZXhwb3J0IGNvbnN0IEZPQ1VTQUJMRV9QT1BVUF9QUk9QUyA9IHtcbiAgdGFiSW5kZXg6IC0xLFxuICBbRk9DVVNBQkxFX0FUVFJJQlVURV06ICcnXG59O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIGRlZmF1bHQgYGluaXRpYWxGb2N1c2AgcmVzb2x2ZXIgZm9yIGEgcG9wdXAuIFdoZW4gb3BlbmVkIGJ5IHRvdWNoIGl0IGZvY3VzZXMgdGhlXG4gKiBwb3B1cCBlbGVtZW50IGl0c2VsZiB0byBwcmV2ZW50IHRoZSB2aXJ0dWFsIGtleWJvYXJkIGZyb20gb3BlbmluZyAocmVxdWlyZWQgZm9yIEFuZHJvaWRcbiAqIHNwZWNpZmljYWxseTsgaU9TIGhhbmRsZXMgdGhpcyBhdXRvbWF0aWNhbGx5KS4gT3RoZXJ3aXNlIGl0IGZhbGxzIGJhY2sgdG8gdGhlIGRlZmF1bHQgYmVoYXZpb3IuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVEZWZhdWx0SW5pdGlhbEZvY3VzKHBvcHVwUmVmKSB7XG4gIHJldHVybiBpbnRlcmFjdGlvblR5cGUgPT4gaW50ZXJhY3Rpb25UeXBlID09PSAndG91Y2gnID8gcG9wdXBSZWYuY3VycmVudCA6IHRydWU7XG59XG5cbi8qKlxuICogVGhlIHN1YnNldCBvZiBhIHBvcHVwIGhhbmRsZSB0aGF0IGEgUm9vdCBuZWVkcyB0byBiaW5kIGl0cyBzdG9yZSB0by4gQm90aCB0aGUgcmVhbCBoYW5kbGUgY2xhc3Nlc1xuICogYW5kIGFueSB0ZXN0IGRvdWJsZSBzYXRpc2Z5IGl0LlxuICovXG5cbi8qKlxuICogQ3JlYXRlcyBhbmQgb3ducyBhIHBvcHVwIHN0b3JlIG9uIGJlaGFsZiBvZiBhIFJvb3QgcGFydC4gVGhlIHN0b3JlIGlzIGNyZWF0ZWQgZXhhY3RseSBvbmNlLCB3aXRoXG4gKiBjb250cm9sbGVkIHByb3BzIGFuZCByb290IHN0YXRlIHN5bmNlZCBzZXBhcmF0ZWx5IGFmdGVyIGNyZWF0aW9uLiBTZXRzIHVwIHRoZSBzeW5jZWQgZmxvYXRpbmdcbiAqIHJvb3QgY29udGV4dCBhbmQgcmV0dXJucyB0aGUgc3RvcmUuXG4gKlxuICogQHBhcmFtIGNyZWF0ZVN0b3JlIEZhY3RvcnkgdGhhdCBidWlsZHMgdGhlIHN0b3JlLiBDYWxsZWQgZXhhY3RseSBvbmNlLCByZWNlaXZpbmcgdGhlIGZsb2F0aW5nIGlkXG4gKiBhbmQgd2hldGhlciB0aGUgcG9wdXAgaXMgbmVzdGVkIGluc2lkZSBhbm90aGVyIGZsb2F0aW5nIGVsZW1lbnQsIGJvdGggcmVzb2x2ZWQgb24gdGhlIGZpcnN0IHJlbmRlci5cbiAqIEBwYXJhbSB0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgV2hldGhlciB0aGUgcG9wdXAgZWxlbWVudCBpcyBwYXNzZWQgdG8gRmxvYXRpbmcgVUkgYXMgdGhlXG4gKiBmbG9hdGluZyBlbGVtZW50IGluc3RlYWQgb2YgdGhlIGRlZmF1bHQgcG9zaXRpb25lci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVBvcHVwUm9vdFN0b3JlKGNyZWF0ZVN0b3JlLCB0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgPSBmYWxzZSkge1xuICBjb25zdCBmbG9hdGluZ0lkID0gdXNlSWQoKTtcbiAgY29uc3QgbmVzdGVkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKSAhPSBudWxsO1xuICBjb25zdCBzdG9yZSA9IHVzZVJlZldpdGhJbml0KCgpID0+IGNyZWF0ZVN0b3JlKGZsb2F0aW5nSWQsIG5lc3RlZCkpLmN1cnJlbnQ7XG4gIHVzZVN5bmNlZEZsb2F0aW5nUm9vdENvbnRleHQoe1xuICAgIHBvcHVwU3RvcmU6IHN0b3JlLFxuICAgIHRyZWF0UG9wdXBBc0Zsb2F0aW5nRWxlbWVudCxcbiAgICBmbG9hdGluZ1Jvb3RDb250ZXh0OiBzdG9yZS5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LFxuICAgIGZsb2F0aW5nSWQsXG4gICAgbmVzdGVkLFxuICAgIG9uT3BlbkNoYW5nZTogc3RvcmUuc2V0T3BlblxuICB9KTtcbiAgcmV0dXJuIHN0b3JlO1xufVxuXG4vKipcbiAqIEF0dGFjaGVzIGEgUm9vdCdzIHN0b3JlIHRvIGEgaGFuZGxlIGZvciB0aGlzIGNvbXBvbmVudCdzIGNvbW1pdHRlZCBsaWZldGltZS4gUG9wdXAgUm9vdHMgcmVuZGVyXG4gKiBpdCBiZWZvcmUgdGhlaXIgaW50ZXJhY3Rpb25zIGFuZCB1c2VyIGNoaWxkcmVuIHNvIGl0cyBsYXlvdXQgZWZmZWN0IHJ1bnMgYmVmb3JlIGRlc2NlbmRhbnQgbGF5b3V0XG4gKiBlZmZlY3RzLiBUaGlzIGxldHMgZGVzY2VuZGFudHMgY2FsbCB0aGUgaGFuZGxlIGR1cmluZyB0aGUgUm9vdCdzIGluaXRpYWwgY29tbWl0IHdpdGhvdXQgYXR0YWNoaW5nXG4gKiBkdXJpbmcgcmVuZGVyLCB3aGljaCB3b3VsZCBsZWFrIHN1c3BlbmRlZCBvciBhYmFuZG9uZWQgc3RvcmVzLiBTdG9yZSBzdWJzY3JpYmVycyBhcmUgbm90aWZpZWQgYnlcbiAqIGBhdHRhY2hTdG9yZWAgaW4gdGhpcyBvcmRpbmFyeSBsYXlvdXQgcGhhc2UsIHdoZXJlIFJlYWN0IHBlcm1pdHMgc3luY2hyb25vdXMgdXBkYXRlcy5cbiAqXG4gKiBQb3B1cCBSb290cyBtdXN0IHJlbmRlciB0aGlzIGNvbXBvbmVudCBvbmx5IHdoZW4gYSBoYW5kbGUgaXMgcHJlc2VudCBzbyBoYW5kbGUtbGVzcyBSb290cyBhdm9pZFxuICogbW91bnRpbmcgYW4gZXh0cmEgZmliZXIgYW5kIGxheW91dCBlZmZlY3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBQb3B1cEhhbmRsZUF0dGFjaG1lbnQoe1xuICBoYW5kbGUsXG4gIHN0b3JlXG59KSB7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuIGhhbmRsZS5hdHRhY2hTdG9yZShzdG9yZSk7XG4gIH0sIFtoYW5kbGUsIHN0b3JlXSk7XG4gIHJldHVybiBudWxsO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSBjYWxsYmFjayByZWYgdGhhdCByZWdpc3RlcnMvdW5yZWdpc3RlcnMgdGhlIHRyaWdnZXIgZWxlbWVudCBpbiB0aGUgc3RvcmUuXG4gKlxuICogQHBhcmFtIHN0b3JlIFRoZSBTdG9yZSBpbnN0YW5jZSB3aGVyZSB0aGUgdHJpZ2dlciBzaG91bGQgYmUgcmVnaXN0ZXJlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVRyaWdnZXJSZWdpc3RyYXRpb24oaWQsIHN0b3JlKSB7XG4gIC8vIEtlZXAgdHJhY2sgb2YgdGhlIGN1cnJlbnRseSByZWdpc3RlcmVkIGVsZW1lbnQgdG8gdW5yZWdpc3RlciBpdCBvbiB1bm1vdW50IG9yIGlkIGNoYW5nZS5cbiAgY29uc3QgcmVnaXN0ZXJlZEVsZW1lbnRJZFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgcmVnaXN0ZXJlZEVsZW1lbnRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIHJldHVybiBSZWFjdC51c2VDYWxsYmFjayhlbGVtZW50ID0+IHtcbiAgICBpZiAoaWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgc2hvdWxkU3luY1RyaWdnZXJDb3VudCA9IGZhbHNlO1xuICAgIGlmIChyZWdpc3RlcmVkRWxlbWVudElkUmVmLmN1cnJlbnQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHJlZ2lzdGVyZWRJZCA9IHJlZ2lzdGVyZWRFbGVtZW50SWRSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IHJlZ2lzdGVyZWRFbGVtZW50ID0gcmVnaXN0ZXJlZEVsZW1lbnRSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IGN1cnJlbnRFbGVtZW50ID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZ2V0QnlJZChyZWdpc3RlcmVkSWQpO1xuICAgICAgaWYgKHJlZ2lzdGVyZWRFbGVtZW50ICYmIGN1cnJlbnRFbGVtZW50ID09PSByZWdpc3RlcmVkRWxlbWVudCkge1xuICAgICAgICBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5kZWxldGUocmVnaXN0ZXJlZElkKTtcbiAgICAgICAgc2hvdWxkU3luY1RyaWdnZXJDb3VudCA9IHRydWU7XG4gICAgICB9XG4gICAgICByZWdpc3RlcmVkRWxlbWVudElkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgcmVnaXN0ZXJlZEVsZW1lbnRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmIChlbGVtZW50ICE9PSBudWxsKSB7XG4gICAgICByZWdpc3RlcmVkRWxlbWVudElkUmVmLmN1cnJlbnQgPSBpZDtcbiAgICAgIHJlZ2lzdGVyZWRFbGVtZW50UmVmLmN1cnJlbnQgPSBlbGVtZW50O1xuICAgICAgc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuYWRkKGlkLCBlbGVtZW50KTtcbiAgICAgIHNob3VsZFN5bmNUcmlnZ2VyQ291bnQgPSB0cnVlO1xuICAgIH1cbiAgICBpZiAoc2hvdWxkU3luY1RyaWdnZXJDb3VudCkge1xuICAgICAgY29uc3QgdHJpZ2dlckNvdW50ID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuc2l6ZTtcbiAgICAgIGlmIChzdG9yZS5zZWxlY3QoJ29wZW4nKSAmJiBzdG9yZS5zdGF0ZS50cmlnZ2VyQ291bnQgIT09IHRyaWdnZXJDb3VudCkge1xuICAgICAgICBzdG9yZS5zZXQoJ3RyaWdnZXJDb3VudCcsIHRyaWdnZXJDb3VudCk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbc3RvcmUsIGlkXSk7XG59XG5leHBvcnQgZnVuY3Rpb24gc2V0UG9wdXBPcGVuU3RhdGUoc3RhdGUsIG9wZW4sIHRyaWdnZXIsIHByZXZlbnRVbm1vdW50T25DbG9zZSA9IGZhbHNlKSB7XG4gIGlmIChvcGVuKSB7XG4gICAgLy8gT3BlbmluZyBzdGFydHMgYSBuZXcgY2xvc2UgY3ljbGUsIHNvIGNsZWFyIGFueSBwcmV2aW91cyByZXF1ZXN0IHRvIGtlZXAgdGhlIHBvcHVwIG1vdW50ZWQuXG4gICAgc3RhdGUucHJldmVudFVubW91bnRpbmdPbkNsb3NlID0gZmFsc2U7XG4gIH0gZWxzZSBpZiAocHJldmVudFVubW91bnRPbkNsb3NlKSB7XG4gICAgc3RhdGUucHJldmVudFVubW91bnRpbmdPbkNsb3NlID0gdHJ1ZTtcbiAgfVxuICBjb25zdCB0cmlnZ2VySWQgPSB0cmlnZ2VyPy5pZCA/PyBudWxsO1xuXG4gIC8vIElmIGEgcG9wdXAgaXMgY2xvc2luZywgdGhlIGB0cmlnZ2VyYCBtYXkgYmUgdW5kZWZpbmVkLlxuICAvLyBXZSB3YW50IHRvIGtlZXAgdGhlIHByZXZpb3VzIHZhbHVlIHNvIHRoYXQgZXhpdCBhbmltYXRpb25zIGFyZSBwbGF5ZWQgYW5kIGZvY3VzIGlzIHJldHVybmVkIGNvcnJlY3RseS5cbiAgaWYgKHRyaWdnZXJJZCB8fCBvcGVuKSB7XG4gICAgc3RhdGUuYWN0aXZlVHJpZ2dlcklkID0gdHJpZ2dlcklkO1xuICAgIHN0YXRlLmFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gdHJpZ2dlciA/PyBudWxsO1xuICB9XG59XG5leHBvcnQgZnVuY3Rpb24gYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlKGV2ZW50RGV0YWlscykge1xuICBsZXQgcHJldmVudFVubW91bnRPbkNsb3NlID0gZmFsc2U7XG4gIGV2ZW50RGV0YWlscy5wcmV2ZW50VW5tb3VudE9uQ2xvc2UgPSAoKSA9PiB7XG4gICAgcHJldmVudFVubW91bnRPbkNsb3NlID0gdHJ1ZTtcbiAgfTtcbiAgcmV0dXJuICgpID0+IHByZXZlbnRVbm1vdW50T25DbG9zZTtcbn1cblxuLyoqXG4gKiBSdW5zIHRoZSBzaGFyZWQgb3Blbi1jaGFuZ2Ugc2VxdWVuY2UgZm9yIGEgcG9wdXAgc3RvcmU6IG5vdGlmaWVzIGBvbk9wZW5DaGFuZ2VgLFxuICogaG9ub3JzIGNhbmNlbGxhdGlvbiwgZGlzcGF0Y2hlcyB0aGUgZmxvYXRpbmcgcm9vdCBjaGFuZ2UsIG1hcHMgdGhlIHJlYXNvbiB0byBhblxuICogYGluc3RhbnRUeXBlYCwgYW5kIGNvbW1pdHMgdGhlIHN0YXRlIHVwZGF0ZSAoc3luY2hyb25vdXNseSBmb3IgaG92ZXIgc29cbiAqIGBnZXRBbmltYXRpb25zKClgIG9ic2VydmVzIGl0KS4gU3RvcmVzIHN1cHBseSB0aGVpciBvd24gZGlmZmVyZW5jZXMgdmlhXG4gKiBgZXh0cmFTdGF0ZWAgKGUuZy4gdGhlIGxhc3QgY2hhbmdlIHJlYXNvbikgYW5kIGBvbkJlZm9yZURpc3BhdGNoYCAoZS5nLiB1cGRhdGluZ1xuICogaW5saW5lLXJlY3QgY29vcmRpbmF0ZXMpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlQb3B1cE9wZW5DaGFuZ2Uoc3RvcmUsIG5leHRPcGVuLCBldmVudERldGFpbHMsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCByZWFzb24gPSBldmVudERldGFpbHMucmVhc29uO1xuICBjb25zdCBpc0hvdmVyID0gcmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJIb3ZlcjtcbiAgY29uc3QgaXNGb2N1c09wZW4gPSBuZXh0T3BlbiAmJiByZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckZvY3VzO1xuICBjb25zdCBpc0Rpc21pc3NDbG9zZSA9ICFuZXh0T3BlbiAmJiAocmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJQcmVzcyB8fCByZWFzb24gPT09IFJFQVNPTlMuZXNjYXBlS2V5KTtcbiAgY29uc3Qgc2hvdWxkUHJldmVudFVubW91bnRPbkNsb3NlID0gYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlKGV2ZW50RGV0YWlscyk7XG4gIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlPy4obmV4dE9wZW4sIGV2ZW50RGV0YWlscyk7XG4gIGlmIChldmVudERldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgIHJldHVybjtcbiAgfVxuICBvcHRpb25zLm9uQmVmb3JlRGlzcGF0Y2g/LigpO1xuICBzdG9yZS5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LmRpc3BhdGNoT3BlbkNoYW5nZShuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgY29uc3QgY2hhbmdlU3RhdGUgPSAoKSA9PiB7XG4gICAgLy8gU3ByZWFkIGBleHRyYVN0YXRlYCBmaXJzdCBzbyBgb3BlbmAgYWx3YXlzIHJlZmxlY3RzIGBuZXh0T3BlbmAsIGtlZXBpbmcgaXQgaW5cbiAgICAvLyBzeW5jIHdpdGggdGhlIHZhbHVlIGFscmVhZHkgcGFzc2VkIHRvIGBkaXNwYXRjaE9wZW5DaGFuZ2VgL2BzZXRQb3B1cE9wZW5TdGF0ZWAuXG4gICAgY29uc3QgdXBkYXRlZFN0YXRlID0ge1xuICAgICAgLi4ub3B0aW9ucy5leHRyYVN0YXRlLFxuICAgICAgb3BlbjogbmV4dE9wZW5cbiAgICB9O1xuICAgIGlmIChpc0ZvY3VzT3Blbikge1xuICAgICAgdXBkYXRlZFN0YXRlLmluc3RhbnRUeXBlID0gJ2ZvY3VzJztcbiAgICB9IGVsc2UgaWYgKGlzRGlzbWlzc0Nsb3NlKSB7XG4gICAgICB1cGRhdGVkU3RhdGUuaW5zdGFudFR5cGUgPSAnZGlzbWlzcyc7XG4gICAgfSBlbHNlIGlmIChpc0hvdmVyKSB7XG4gICAgICB1cGRhdGVkU3RhdGUuaW5zdGFudFR5cGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHNldFBvcHVwT3BlblN0YXRlKHVwZGF0ZWRTdGF0ZSwgbmV4dE9wZW4sIGV2ZW50RGV0YWlscy50cmlnZ2VyLCBzaG91bGRQcmV2ZW50VW5tb3VudE9uQ2xvc2UoKSk7XG4gICAgc3RvcmUudXBkYXRlKHVwZGF0ZWRTdGF0ZSk7XG4gIH07XG4gIGlmIChpc0hvdmVyKSB7XG4gICAgLy8gRmx1c2ggc3luY2hyb25vdXNseSBmb3IgaG92ZXIgc28gYG5vZGUuZ2V0QW5pbWF0aW9ucygpYCBzZWVzIHRoZSBuZXcgc3RhdGUuXG4gICAgUmVhY3RET00uZmx1c2hTeW5jKGNoYW5nZVN0YXRlKTtcbiAgfSBlbHNlIHtcbiAgICBjaGFuZ2VTdGF0ZSgpO1xuICB9XG59XG5cbi8qKlxuICogU2V0cyB1cCB0cmlnZ2VyIGRhdGEgZm9yd2FyZGluZyB0byB0aGUgc3RvcmUuXG4gKlxuICogQHBhcmFtIHRyaWdnZXJJZCBJZCBvZiB0aGUgdHJpZ2dlci5cbiAqIEBwYXJhbSB0cmlnZ2VyRWxlbWVudFJlZiBSZWYgZm9yIHRoZSB0cmlnZ2VyIERPTSBlbGVtZW50LlxuICogQHBhcmFtIHN0b3JlIFRoZSBTdG9yZSBpbnN0YW5jZSBtYW5hZ2luZyB0aGUgcG9wdXAgc3RhdGUuXG4gKiBAcGFyYW0gc3RhdGVVcGRhdGVzIEFuIG9iamVjdCB3aXRoIHN0YXRlIHVwZGF0ZXMgdG8gYXBwbHkgd2hlbiB0aGUgdHJpZ2dlciBpcyBhY3RpdmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VUcmlnZ2VyRGF0YUZvcndhcmRpbmcodHJpZ2dlcklkLCB0cmlnZ2VyRWxlbWVudFJlZiwgc3RvcmUsIHN0YXRlVXBkYXRlcykge1xuICBjb25zdCBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyID0gc3RvcmUudXNlU3RhdGUoJ2lzTW91bnRlZEJ5VHJpZ2dlcicsIHRyaWdnZXJJZCk7XG4gIGNvbnN0IGJhc2VSZWdpc3RlclRyaWdnZXIgPSB1c2VUcmlnZ2VyUmVnaXN0cmF0aW9uKHRyaWdnZXJJZCwgc3RvcmUpO1xuXG4gIC8vIEFwcGxpZXMgdHJpZ2dlci1vd25lZCBzdGF0ZSAoYWN0aXZlLXRyaWdnZXIgb3duZXJzaGlwIGFuZCBwYXlsb2FkKSB3aGVuIHRoZSB0cmlnZ2VyIHJlZ2lzdGVycy5cbiAgLy8gU3RhYmxlIHNvIHBheWxvYWQvYHN0YXRlVXBkYXRlc2AgY2hhbmdlcyBkbyBub3QgY2hhbmdlIHRoZSByZWYgaWRlbnRpdHkgKHdoaWNoIHdvdWxkIG5lZWRsZXNzbHlcbiAgLy8gY2h1cm4gcmVnaXN0cmF0aW9uKTsgaXQgcmVhZHMgdGhlIGxhdGVzdCBjbG9zdXJlIHZhbHVlcyB3aGVuIGludm9rZWQuXG4gIGNvbnN0IGFwcGx5VHJpZ2dlckRhdGEgPSB1c2VTdGFibGVDYWxsYmFjayhlbGVtZW50ID0+IHtcbiAgICBjb25zdCBvcGVuID0gc3RvcmUuc2VsZWN0KCdvcGVuJyk7XG4gICAgY29uc3QgYWN0aXZlVHJpZ2dlcklkID0gc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VySWQnKTtcbiAgICBpZiAoYWN0aXZlVHJpZ2dlcklkID09PSB0cmlnZ2VySWQpIHtcbiAgICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBlbGVtZW50LFxuICAgICAgICAuLi4ob3BlbiA/IHN0YXRlVXBkYXRlcyA6IG51bGwpXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGFjdGl2ZVRyaWdnZXJJZCA9PSBudWxsICYmIG9wZW4pIHtcbiAgICAgIC8vIElmIGEgcG9wdXAgaXMgYWxyZWFkeSBvcGVuLCBhIGRldGFjaGVkIHRyaWdnZXIgY2FuIG1vdW50IGJlZm9yZSBhbnkgYWN0aXZlIHRyaWdnZXJcbiAgICAgIC8vIGhhcyBiZWVuIGVzdGFibGlzaGVkLiBDbGFpbSB0aGUgZmlyc3QgcmVnaXN0ZXJlZCB0cmlnZ2VyIHNvIHRyaWdnZXItb3duZWQgZm9jdXNcbiAgICAgIC8vIG1hbmFnZW1lbnQgYW5kIEFSSUEgcmVsYXRpb25zaGlwcyB3b3JrLlxuICAgICAgc3RvcmUudXBkYXRlKHtcbiAgICAgICAgYWN0aXZlVHJpZ2dlcklkOiB0cmlnZ2VySWQsXG4gICAgICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBlbGVtZW50LFxuICAgICAgICAuLi5zdGF0ZVVwZGF0ZXNcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gSW50ZW50aW9uYWxseSBOT1Qgc3RhYmxlLiBJdHMgaWRlbnRpdHkgaXMgZGVyaXZlZCBmcm9tIGBiYXNlUmVnaXN0ZXJUcmlnZ2VyYCwgd2hpY2ggaXMga2V5ZWQgb25cbiAgLy8gYFtzdG9yZSwgaWRdYCwgc28gd2hlbiBhIGhhbmRsZS1iYWNrZWQgdHJpZ2dlcidzIHN0b3JlIHBvaW50ZXIgc3dhcHMgdGhlIG1lcmdlZCByZWYgcmUtZmlyZXMg4oCUXG4gIC8vIHVucmVnaXN0ZXJpbmcgZnJvbSB0aGUgcHJldmlvdXMgc3RvcmUgYW5kIHJlZ2lzdGVyaW5nIGludG8gdGhlIG5ldyBvbmUuIFRoaXMgbGV0cyBhIGRldGFjaGVkXG4gIC8vIHRyaWdnZXIgZm9sbG93IGl0cyBoYW5kbGUncyBjdXJyZW50bHktYXR0YWNoZWQgc3RvcmUgYWNyb3NzIGF0dGFjaC9kZXRhY2gvcmVtb3VudC4gKEEgc3RhYmxlXG4gIC8vIGNhbGxiYWNrIHdvdWxkIGtlZXAgaXRzIGlkZW50aXR5IGFuZCBuZXZlciByZS1maXJlIG9uIGEgc3RvcmUgc3dhcC4pXG4gIGNvbnN0IHJlZ2lzdGVyVHJpZ2dlciA9IFJlYWN0LnVzZUNhbGxiYWNrKGVsZW1lbnQgPT4ge1xuICAgIGJhc2VSZWdpc3RlclRyaWdnZXIoZWxlbWVudCk7XG4gICAgaWYgKGVsZW1lbnQpIHtcbiAgICAgIGFwcGx5VHJpZ2dlckRhdGEoZWxlbWVudCk7XG4gICAgfVxuICB9LCBbYmFzZVJlZ2lzdGVyVHJpZ2dlciwgYXBwbHlUcmlnZ2VyRGF0YV0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc01vdW50ZWRCeVRoaXNUcmlnZ2VyKSB7XG4gICAgICBzdG9yZS51cGRhdGUoe1xuICAgICAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogdHJpZ2dlckVsZW1lbnRSZWYuY3VycmVudCxcbiAgICAgICAgLi4uc3RhdGVVcGRhdGVzXG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbaXNNb3VudGVkQnlUaGlzVHJpZ2dlciwgc3RvcmUsIHRyaWdnZXJFbGVtZW50UmVmLCAuLi5PYmplY3QudmFsdWVzKHN0YXRlVXBkYXRlcyldKTtcbiAgcmV0dXJuIHtcbiAgICByZWdpc3RlclRyaWdnZXIsXG4gICAgaXNNb3VudGVkQnlUaGlzVHJpZ2dlclxuICB9O1xufVxuLyoqXG4gKiBLZWVwcyB0cmlnZ2VyIHJlZ2lzdHJhdGlvbiBzdGF0ZSBzeW5jaHJvbml6ZWQgd2hpbGUgdGhlIHBvcHVwIGlzIG9wZW4uXG4gKlxuICogV2hlbiBhIHBvcHVwIG9wZW5zIHdpdGhvdXQgYW4gZXhwbGljaXQgdHJpZ2dlciBpZCBhbmQgZXhhY3RseSBvbmUgdHJpZ2dlciBpcyByZWdpc3RlcmVkLCB0aGF0XG4gKiB0cmlnZ2VyIGlzIGNsYWltZWQgYXMgdGhlIGFjdGl2ZSB0cmlnZ2VyLiBXaGVuIHRoZSBhY3RpdmUgdHJpZ2dlciBpZCBpcyBzdGlsbCByZWdpc3RlcmVkIGJ1dCBpdHNcbiAqIGVsZW1lbnQgY2hhbmdlZCwgdGhlIGFjdGl2ZSBlbGVtZW50IGlzIHJlZnJlc2hlZC4gV2hlbiB0aGUgYWN0aXZlIHRyaWdnZXIgaWQgaXMgbWlzc2luZyBmcm9tIHRoZVxuICogcmVnaXN0cnkgYnV0IHRoZSBzYW1lIGVsZW1lbnQgaXMgc3RpbGwgcmVnaXN0ZXJlZCB1bmRlciBhIGRpZmZlcmVudCBpZCAoZS5nLiB0aGUgcmVuZGVyZWQgdHJpZ2dlclxuICogY2FycmllcyBpdHMgb3duIERPTSBgaWRgIHRoYXQgZGlmZmVycyBmcm9tIEJhc2UgVUkncyBpbnRlcm5hbCB0cmlnZ2VyIGlkKSwgdGhlIGFjdGl2ZSBpZCBpc1xuICogcmVhc3NvY2lhdGVkIHRvIHRoZSByZWdpc3RlcmVkIGlkIGluc3RlYWQgb2YgYmVpbmcgdHJlYXRlZCBhcyBsb3N0LiBXaGVuIHRoZSBhY3RpdmUgdHJpZ2dlclxuICogdW5yZWdpc3RlcnMsIHRoZSBkZWZhdWx0IHBhdGggcHJlc2VydmVzIGV4aXN0aW5nIG93bmVyc2hpcCBzbyBub24tY2xvc2luZyBwb3B1cCBmYW1pbGllcyBkbyBub3RcbiAqIHNpbGVudGx5IGNsYWltIGEgZGlmZmVyZW50IHRyaWdnZXIgd2hpbGUgc3RheWluZyBvcGVuLlxuICpcbiAqIElmIGBjbG9zZU9uQWN0aXZlVHJpZ2dlclVubW91bnRgIGlzIGVuYWJsZWQsIHVucmVnaXN0ZXJpbmcgYSBwcmV2aW91c2x5IHJlc29sdmVkIGFjdGl2ZSB0cmlnZ2VyXG4gKiByZXF1ZXN0cyBhIGNsb3NlIGFmdGVyIGEgbWljcm90YXNrIHNvIGEgc2FtZS10aWNrIHJlcGxhY2VtZW50IHRyaWdnZXIgd2l0aCB0aGUgc2FtZSBpZCBjYW5cbiAqIHJlZ2lzdGVyIGZpcnN0LiBBbiBhY3RpdmUgdHJpZ2dlciBpZCB0aGF0IGhhcyBub3QgbWF0Y2hlZCBhIHJlZ2lzdGVyZWQgdHJpZ2dlciB5ZXQgaXMgdHJlYXRlZCBhc1xuICogcGVuZGluZyBhbmQgZG9lcyBub3QgcmVxdWVzdCBhIGNsb3NlLlxuICpcbiAqIFRoaXMgc2hvdWxkIGJlIGNhbGxlZCBvbiB0aGUgUm9vdCBwYXJ0LlxuICpcbiAqIEBwYXJhbSBzdG9yZSBUaGUgU3RvcmUgaW5zdGFuY2UgbWFuYWdpbmcgdGhlIHBvcHVwIHN0YXRlLlxuICogQHBhcmFtIG9wdGlvbnMgT3B0aW9ucyBmb3IgYWN0aXZlIHRyaWdnZXIgdW5tb3VudCBiZWhhdmlvci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUltcGxpY2l0QWN0aXZlVHJpZ2dlcihzdG9yZSwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBjbG9zZU9uQWN0aXZlVHJpZ2dlclVubW91bnQgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgLy8gRGlzdGluZ3Vpc2hlcyBhIHRyaWdnZXIgdGhhdCB1bm1vdW50ZWQgZnJvbSBhIG5ldyBhY3RpdmUgdHJpZ2dlciB0aGF0IGhhcyBub3QgaHlkcmF0ZWQgeWV0LlxuICBjb25zdCByZXNvbHZlZEFjdGl2ZVRyaWdnZXJJZFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IHJlYWN0aXZlVHJpZ2dlckNvdW50ID0gc3RvcmUudXNlU3RhdGUoJ3RyaWdnZXJDb3VudCcpO1xuICAvLyBTdWJzY3JpYmUgdG8gdGhlIGFjdGl2ZSB0cmlnZ2VyIGlkIHNvIHRoZSByZWNvbmNpbGlhdGlvbiBiZWxvdyByZXJ1bnMgd2hlbiBvd25lcnNoaXAgbW92ZXMgdG9cbiAgLy8gYW5vdGhlciB0cmlnZ2VyIHdoaWxlIHRoZSBwb3B1cCBzdGF5cyBvcGVuIChlLmcuIGEgZm9jdXMvaG92ZXIgaGFuZG9mZiBiZXR3ZWVuIHRyaWdnZXJzKS5cbiAgY29uc3QgYWN0aXZlVHJpZ2dlcklkID0gc3RvcmUudXNlU3RhdGUoJ2FjdGl2ZVRyaWdnZXJJZCcpO1xuICAvLyBTdWJzY3JpYmUgdG8gdGhlIGFjdGl2ZSB0cmlnZ2VyIGVsZW1lbnQgc28gdGhlIHJlY29uY2lsaWF0aW9uIHJlcnVucyB3aGVuIGEgcGVuZGluZyBhY3RpdmVcbiAgLy8gdHJpZ2dlciByZWdpc3RlcnMgaW4gYSBjb21taXQgd2hlcmUgdGhlIHRyaWdnZXIgY291bnQgbmV0cyBvdXQgdW5jaGFuZ2VkIChyZWdpc3RyYXRpb25cbiAgLy8gZm9yd2FyZHMgdGhlIGVsZW1lbnQgdG8gdGhlIHN0b3JlIHdoZW4gdGhlIHJlZ2lzdGVyaW5nIHRyaWdnZXIgbWF0Y2hlcyB0aGUgYWN0aXZlIGlkKS5cbiAgLy8gV2l0aG91dCB0aGlzLCB0aGUgaWQgd291bGQgbmV2ZXIgYmUgbWFya2VkIHJlc29sdmVkIGFuZCBhIGxhdGVyIGdlbnVpbmUgdW5tb3VudCB3b3VsZCBiZVxuICAvLyBtaXNjbGFzc2lmaWVkIGFzIHBlbmRpbmcsIGRpc2FibGluZyBgY2xvc2VPbkFjdGl2ZVRyaWdnZXJVbm1vdW50YC5cbiAgY29uc3QgcmVhY3RpdmVBY3RpdmVUcmlnZ2VyRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3Blbikge1xuICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBpZiAoc3RvcmUuc3RhdGUudHJpZ2dlckNvdW50ICE9PSAwKSB7XG4gICAgICAgIHN0b3JlLnNldCgndHJpZ2dlckNvdW50JywgMCk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRyaWdnZXJDb3VudCA9IHN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLnNpemU7XG4gICAgY29uc3Qgc3RhdGVVcGRhdGVzID0ge307XG4gICAgaWYgKHN0b3JlLnN0YXRlLnRyaWdnZXJDb3VudCAhPT0gdHJpZ2dlckNvdW50KSB7XG4gICAgICBzdGF0ZVVwZGF0ZXMudHJpZ2dlckNvdW50ID0gdHJpZ2dlckNvdW50O1xuICAgIH1cbiAgICBjb25zdCBjdXJyZW50QWN0aXZlVHJpZ2dlcklkID0gc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VySWQnKTtcbiAgICBsZXQgbG9zdEFjdGl2ZVRyaWdnZXJJZCA9IG51bGw7XG4gICAgaWYgKGN1cnJlbnRBY3RpdmVUcmlnZ2VySWQpIHtcbiAgICAgIGNvbnN0IGFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZ2V0QnlJZChjdXJyZW50QWN0aXZlVHJpZ2dlcklkKTtcbiAgICAgIGlmICghYWN0aXZlVHJpZ2dlckVsZW1lbnQpIHtcbiAgICAgICAgZm9yIChjb25zdCBbdHJpZ2dlcklkLCB0cmlnZ2VyRWxlbWVudF0gb2Ygc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZW50cmllcygpKSB7XG4gICAgICAgICAgaWYgKHRyaWdnZXJFbGVtZW50ID09PSBzdG9yZS5zdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudCkge1xuICAgICAgICAgICAgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJJZCA9IHRyaWdnZXJJZDtcbiAgICAgICAgICAgIHN0YXRlVXBkYXRlcy5hY3RpdmVUcmlnZ2VyRWxlbWVudCA9IHRyaWdnZXJFbGVtZW50O1xuICAgICAgICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IHRyaWdnZXJJZDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgaWYgKHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPT09IGN1cnJlbnRBY3RpdmVUcmlnZ2VySWQpIHtcbiAgICAgICAgICAgIGxvc3RBY3RpdmVUcmlnZ2VySWQgPSBjdXJyZW50QWN0aXZlVHJpZ2dlcklkO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlZEFjdGl2ZVRyaWdnZXJJZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPSBjdXJyZW50QWN0aXZlVHJpZ2dlcklkO1xuICAgICAgICBpZiAoYWN0aXZlVHJpZ2dlckVsZW1lbnQgIT09IHN0b3JlLnN0YXRlLmFjdGl2ZVRyaWdnZXJFbGVtZW50KSB7XG4gICAgICAgICAgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gYWN0aXZlVHJpZ2dlckVsZW1lbnQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmICghbG9zdEFjdGl2ZVRyaWdnZXJJZCAmJiAhY3VycmVudEFjdGl2ZVRyaWdnZXJJZCAmJiB0cmlnZ2VyQ291bnQgPT09IDEpIHtcbiAgICAgIGNvbnN0IGl0ZXJhdG9yUmVzdWx0ID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZW50cmllcygpLm5leHQoKTtcbiAgICAgIGlmICghaXRlcmF0b3JSZXN1bHQuZG9uZSkge1xuICAgICAgICBjb25zdCBbaW1wbGljaXRUcmlnZ2VySWQsIGltcGxpY2l0VHJpZ2dlckVsZW1lbnRdID0gaXRlcmF0b3JSZXN1bHQudmFsdWU7XG4gICAgICAgIHN0YXRlVXBkYXRlcy5hY3RpdmVUcmlnZ2VySWQgPSBpbXBsaWNpdFRyaWdnZXJJZDtcbiAgICAgICAgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gaW1wbGljaXRUcmlnZ2VyRWxlbWVudDtcbiAgICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IGltcGxpY2l0VHJpZ2dlcklkO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoc3RhdGVVcGRhdGVzLnRyaWdnZXJDb3VudCAhPT0gdW5kZWZpbmVkIHx8IHN0YXRlVXBkYXRlcy5hY3RpdmVUcmlnZ2VySWQgIT09IHVuZGVmaW5lZCB8fCBzdGF0ZVVwZGF0ZXMuYWN0aXZlVHJpZ2dlckVsZW1lbnQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgc3RvcmUudXBkYXRlKHN0YXRlVXBkYXRlcyk7XG4gICAgfVxuICAgIGlmIChsb3N0QWN0aXZlVHJpZ2dlcklkKSB7XG4gICAgICBpZiAoY2xvc2VPbkFjdGl2ZVRyaWdnZXJVbm1vdW50KSB7XG4gICAgICAgIC8vIERlZmVyIHNvIGEgc2FtZS10aWNrIHJlcGxhY2VtZW50IHRyaWdnZXIgd2l0aCB0aGUgc2FtZSBpZCBjYW4gcmVnaXN0ZXIgZmlyc3QuXG4gICAgICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICAgICAgICBpZiAoc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VySWQnKSA9PT0gbG9zdEFjdGl2ZVRyaWdnZXJJZCAmJiAhc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZ2V0QnlJZChsb3N0QWN0aXZlVHJpZ2dlcklkKSkge1xuICAgICAgICAgICAgY29uc3QgZXZlbnREZXRhaWxzID0gY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMubm9uZSk7XG4gICAgICAgICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBldmVudERldGFpbHMpO1xuICAgICAgICAgICAgLy8gSWYgY2xvc2luZyBpcyBjYW5jZWxlZCwga2VlcCB0aGUgcHJldmlvdXMgYWN0aXZlIHRyaWdnZXIgb3duZXJzaGlwIGZvciB0aGVcbiAgICAgICAgICAgIC8vIHN0aWxsLW9wZW4gcG9wdXAgaW5zdGVhZCBvZiBjbGFpbWluZyBhbm90aGVyIHRyaWdnZXIgaW1wbGljaXRseS5cbiAgICAgICAgICAgIGlmICghZXZlbnREZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgICAgICAgICAgc3RvcmUudXBkYXRlKHtcbiAgICAgICAgICAgICAgICBhY3RpdmVUcmlnZ2VySWQ6IG51bGwsXG4gICAgICAgICAgICAgICAgYWN0aXZlVHJpZ2dlckVsZW1lbnQ6IG51bGxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtvcGVuLCBzdG9yZSwgcmVhY3RpdmVUcmlnZ2VyQ291bnQsIGFjdGl2ZVRyaWdnZXJJZCwgcmVhY3RpdmVBY3RpdmVUcmlnZ2VyRWxlbWVudCwgY2xvc2VPbkFjdGl2ZVRyaWdnZXJVbm1vdW50XSk7XG59XG5cbi8qKlxuICogTWFuYWdlcyB0aGUgbW91bnRlZCBzdGF0ZSBvZiB0aGUgcG9wdXAuXG4gKiBTZXRzIHVwIHRoZSB0cmFuc2l0aW9uIHN0YXR1cyBsaXN0ZW5lcnMgYW5kIGhhbmRsZXMgdW5tb3VudGluZyB3aGVuIG5lZWRlZC5cbiAqIFVwZGF0ZXMgdGhlIGBtb3VudGVkYCwgYHRyYW5zaXRpb25TdGF0dXNgLCBhbmQgYHByZXZlbnRVbm1vdW50aW5nT25DbG9zZWAgc3RhdGVzIGluIHRoZSBzdG9yZS5cbiAqXG4gKiBAcGFyYW0gb3BlbiBXaGV0aGVyIHRoZSBwb3B1cCBpcyBvcGVuLlxuICogQHBhcmFtIHN0b3JlIFRoZSBTdG9yZSBpbnN0YW5jZSBtYW5hZ2luZyB0aGUgcG9wdXAgc3RhdGUuXG4gKiBAcGFyYW0gb25Vbm1vdW50IE9wdGlvbmFsIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCB3aGVuIHRoZSBwb3B1cCBpcyB1bm1vdW50ZWQuXG4gKlxuICogQHJldHVybnMgQSBmdW5jdGlvbiB0byBmb3JjaWJseSB1bm1vdW50IHRoZSBwb3B1cC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU9wZW5TdGF0ZVRyYW5zaXRpb25zKG9wZW4sIHN0b3JlLCBvblVubW91bnQpIHtcbiAgY29uc3Qge1xuICAgIG1vdW50ZWQsXG4gICAgc2V0TW91bnRlZCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH0gPSB1c2VUcmFuc2l0aW9uU3RhdHVzKG9wZW4pO1xuICBjb25zdCBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UgPSBzdG9yZS51c2VTdGF0ZSgncHJldmVudFVubW91bnRpbmdPbkNsb3NlJyk7XG4gIC8vIE9wZW5pbmcgc3RhcnRzIGEgbmV3IGNsb3NlIGN5Y2xlLiBDbGVhciBkdXJpbmcgcmVuZGVyIHNvIHRoZSBjbG9zZS1jb21wbGV0aW9uIGhvb2sgYmVsb3dcbiAgLy8gcmVhZHMgdGhlIHN5bmNocm9uaXplZCB2YWx1ZSBvbiB0aGUgc2FtZSBwYXNzLlxuICBjb25zdCBzeW5jZWRQcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UgPSBvcGVuID8gZmFsc2UgOiBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2U7XG4gIHN0b3JlLnVzZVN5bmNlZFZhbHVlcyh7XG4gICAgbW91bnRlZCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzLFxuICAgIHByZXZlbnRVbm1vdW50aW5nT25DbG9zZTogc3luY2VkUHJldmVudFVubW91bnRpbmdPbkNsb3NlXG4gIH0pO1xuICBjb25zdCBmb3JjZVVubW91bnQgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0TW91bnRlZChmYWxzZSk7XG4gICAgc3RvcmUudXBkYXRlKHtcbiAgICAgIGFjdGl2ZVRyaWdnZXJJZDogbnVsbCxcbiAgICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBudWxsLFxuICAgICAgbW91bnRlZDogZmFsc2UsXG4gICAgICBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2U6IGZhbHNlXG4gICAgfSk7XG4gICAgb25Vbm1vdW50Py4oKTtcbiAgICBzdG9yZS5jb250ZXh0Lm9uT3BlbkNoYW5nZUNvbXBsZXRlPy4oZmFsc2UpO1xuICB9KTtcbiAgdXNlT3BlbkNoYW5nZUNvbXBsZXRlKHtcbiAgICBlbmFibGVkOiBtb3VudGVkICYmICFvcGVuICYmICFzeW5jZWRQcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UsXG4gICAgb3BlbixcbiAgICByZWY6IHN0b3JlLmNvbnRleHQucG9wdXBSZWYsXG4gICAgb25Db21wbGV0ZSgpIHtcbiAgICAgIGlmICghb3Blbikge1xuICAgICAgICBmb3JjZVVubW91bnQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICByZXR1cm4ge1xuICAgIGZvcmNlVW5tb3VudCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gdXNlUG9wdXBJbnRlcmFjdGlvblByb3BzKHN0b3JlLCBzdGF0ZVBhcnQpIHtcbiAgc3RvcmUudXNlU3luY2VkVmFsdWVzKHN0YXRlUGFydCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiAoKSA9PiB7XG4gICAgc3RvcmUudXBkYXRlKHtcbiAgICAgIGFjdGl2ZVRyaWdnZXJQcm9wczogRU1QVFlfT0JKRUNULFxuICAgICAgaW5hY3RpdmVUcmlnZ2VyUHJvcHM6IEVNUFRZX09CSkVDVCxcbiAgICAgIHBvcHVwUHJvcHM6IEVNUFRZX09CSkVDVFxuICAgIH0pO1xuICB9LCBbc3RvcmVdKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1c2VQb3B1cFJvb3RTeW5jKHN0b3JlLCBvcGVuKSB7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuICYmIHN0b3JlLnN0YXRlLm9wZW5NZXRob2QgIT09IG51bGwpIHtcbiAgICAgIHN0b3JlLnNldCgnb3Blbk1ldGhvZCcsIG51bGwpO1xuICAgIH1cbiAgfSwgW29wZW4sIHN0b3JlXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiAoKSA9PiB7XG4gICAgaWYgKHN0b3JlLnN0YXRlLm9wZW5NZXRob2QgIT09IG51bGwpIHtcbiAgICAgIHN0b3JlLnNldCgnb3Blbk1ldGhvZCcsIG51bGwpO1xuICAgIH1cbiAgfSwgW3N0b3JlXSk7XG59IiwiLyoqXG4gKiBEZXZlbG9wbWVudC1vbmx5IHJldmVyc2UgaW5kZXggb2YgZWxlbWVudCB0byByZWdpc3RlcmVkIGlkLCBrZXllZCBieSB0aGUgb3duaW5nIG1hcC5cbiAqXG4gKiBSZWdpc3RyYXRpb24gd291bGQgb3RoZXJ3aXNlIGhhdmUgdG8gc2NhbiBldmVyeSBlbnRyeSB0byBkZXRlY3QgYW4gZWxlbWVudCBjbGFpbWVkIGJ5IHR3byBpZHMsXG4gKiBtYWtpbmcgdGhlIG1vdW50IG9mIG1hbnkgdHJpZ2dlcnMgc2hhcmluZyBvbmUgaGFuZGxlIHF1YWRyYXRpYy4gS2VwdCBtb2R1bGUtc2NvcGVkLCBsYXppbHlcbiAqIGluaXRpYWxpemVkLCBhbmQgcmVhZCBvbmx5IGZyb20gYHByb2Nlc3MuZW52Lk5PREVfRU5WYCBndWFyZHMgc28gcHJvZHVjdGlvbiBidWlsZHMgZHJvcCBpdCBhbG9uZ1xuICogd2l0aCB0aGUgY2hlY2tzLlxuICovXG5sZXQgZGV2RWxlbWVudElkc0J5TWFwO1xuZnVuY3Rpb24gZ2V0RGV2RWxlbWVudElkcyhtYXApIHtcbiAgZGV2RWxlbWVudElkc0J5TWFwID8/PSBuZXcgV2Vha01hcCgpO1xuICBsZXQgZWxlbWVudElkcyA9IGRldkVsZW1lbnRJZHNCeU1hcC5nZXQobWFwKTtcbiAgaWYgKCFlbGVtZW50SWRzKSB7XG4gICAgZWxlbWVudElkcyA9IG5ldyBXZWFrTWFwKCk7XG4gICAgZGV2RWxlbWVudElkc0J5TWFwLnNldChtYXAsIGVsZW1lbnRJZHMpO1xuICB9XG4gIHJldHVybiBlbGVtZW50SWRzO1xufVxuXG4vKipcbiAqIERhdGEgc3RydWN0dXJlIHRvIGtlZXAgdHJhY2sgb2YgcG9wdXAgdHJpZ2dlciBlbGVtZW50cyBieSB0aGVpciBJRHMuXG4gKlxuICogRWxlbWVudCBsb29rdXBzIGl0ZXJhdGUgdGhlIGlkIG1hcCByYXRoZXIgdGhhbiBtYWludGFpbmluZyBhIHBhcmFsbGVsIFNldC4gUmVnaXN0cmF0aW9uIGlzIE8oMSksXG4gKiB3aGlsZSBgaGFzRWxlbWVudGAgYW5kIGBoYXNNYXRjaGluZ0VsZW1lbnRgIGFyZSBsaW5lYXIgaW4gdGhlIG51bWJlciBvZiB0cmlnZ2Vycy5cbiAqL1xuZXhwb3J0IGNsYXNzIFBvcHVwVHJpZ2dlck1hcCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuaWRNYXAgPSBuZXcgTWFwKCk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIHRyaWdnZXIgZWxlbWVudCB3aXRoIHRoZSBnaXZlbiBJRC5cbiAgICpcbiAgICogTm90ZTogVGhlIHByb3ZpZGVkIGVsZW1lbnQgaXMgYXNzdW1lZCB0byBub3QgYmUgcmVnaXN0ZXJlZCB1bmRlciBtdWx0aXBsZSBJRHMuXG4gICAqL1xuICBhZGQoaWQsIGVsZW1lbnQpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgZWxlbWVudElkcyA9IGdldERldkVsZW1lbnRJZHModGhpcyk7XG4gICAgICBjb25zdCBleGlzdGluZ0lkID0gZWxlbWVudElkcy5nZXQoZWxlbWVudCk7XG4gICAgICBpZiAoZXhpc3RpbmdJZCAhPT0gdW5kZWZpbmVkICYmIGV4aXN0aW5nSWQgIT09IGlkKSB7XG4gICAgICAgIC8vIFRPRE86IGZpeCBtdWkvbm8tZ3VhcmRlZC10aHJvd1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdCYXNlIFVJOiBBIHRyaWdnZXIgZWxlbWVudCBjYW5ub3QgYmUgcmVnaXN0ZXJlZCB1bmRlciBtdWx0aXBsZSBJRHMgaW4gUG9wdXBUcmlnZ2VyTWFwLicpO1xuICAgICAgfVxuXG4gICAgICAvLyBSZXVzaW5nIGFuIGlkIGZvciBhIGRpZmZlcmVudCBlbGVtZW50IGV2aWN0cyB0aGUgcHJldmlvdXMgb25lLCBzbyBpdCBtdXN0IGxvc2UgaXRzIGNsYWltXG4gICAgICAvLyBvbiB0aGUgaWQgb3IgYSBsYXRlciByZWdpc3RyYXRpb24gdW5kZXIgYSBkaWZmZXJlbnQgaWQgd291bGQgYmUgcmVwb3J0ZWQgYXMgYSBkdXBsaWNhdGUuXG4gICAgICBjb25zdCBwcmV2aW91c0VsZW1lbnQgPSB0aGlzLmlkTWFwLmdldChpZCk7XG4gICAgICBpZiAocHJldmlvdXNFbGVtZW50ICE9PSB1bmRlZmluZWQgJiYgcHJldmlvdXNFbGVtZW50ICE9PSBlbGVtZW50KSB7XG4gICAgICAgIGVsZW1lbnRJZHMuZGVsZXRlKHByZXZpb3VzRWxlbWVudCk7XG4gICAgICB9XG4gICAgICBlbGVtZW50SWRzLnNldChlbGVtZW50LCBpZCk7XG4gICAgfVxuICAgIHRoaXMuaWRNYXAuc2V0KGlkLCBlbGVtZW50KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSB0cmlnZ2VyIGVsZW1lbnQgd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAqL1xuICBkZWxldGUoaWQpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgZWxlbWVudCA9IHRoaXMuaWRNYXAuZ2V0KGlkKTtcbiAgICAgIGlmIChlbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgZGV2RWxlbWVudElkc0J5TWFwPy5nZXQodGhpcyk/LmRlbGV0ZShlbGVtZW50KTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5pZE1hcC5kZWxldGUoaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGdpdmVuIGVsZW1lbnQgaXMgcmVnaXN0ZXJlZCBhcyBhIHRyaWdnZXIuXG4gICAqL1xuICBoYXNFbGVtZW50KGVsZW1lbnQpIHtcbiAgICBmb3IgKGNvbnN0IHJlZ2lzdGVyZWQgb2YgdGhpcy5pZE1hcC52YWx1ZXMoKSkge1xuICAgICAgaWYgKHJlZ2lzdGVyZWQgPT09IGVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZXJlIGlzIGEgcmVnaXN0ZXJlZCB0cmlnZ2VyIGVsZW1lbnQgbWF0Y2hpbmcgdGhlIGdpdmVuIHByZWRpY2F0ZS5cbiAgICovXG4gIGhhc01hdGNoaW5nRWxlbWVudChwcmVkaWNhdGUpIHtcbiAgICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgdGhpcy5pZE1hcC52YWx1ZXMoKSkge1xuICAgICAgaWYgKHByZWRpY2F0ZShlbGVtZW50KSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHRyaWdnZXIgZWxlbWVudCBhc3NvY2lhdGVkIHdpdGggdGhlIGdpdmVuIElELCBvciB1bmRlZmluZWQgaWYgbm8gc3VjaCBlbGVtZW50IGV4aXN0cy5cbiAgICovXG4gIGdldEJ5SWQoaWQpIHtcbiAgICByZXR1cm4gdGhpcy5pZE1hcC5nZXQoaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gaXRlcmFibGUgb2YgYWxsIHJlZ2lzdGVyZWQgdHJpZ2dlciBlbnRyaWVzLCB3aGVyZSBlYWNoIGVudHJ5IGlzIGEgdHVwbGUgb2YgW2lkLCBlbGVtZW50XS5cbiAgICovXG4gIGVudHJpZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuaWRNYXAuZW50cmllcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gaXRlcmFibGUgb2YgYWxsIHJlZ2lzdGVyZWQgdHJpZ2dlciBlbGVtZW50cy5cbiAgICovXG4gIGVsZW1lbnRzKCkge1xuICAgIHJldHVybiB0aGlzLmlkTWFwLnZhbHVlcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIG51bWJlciBvZiByZWdpc3RlcmVkIHRyaWdnZXIgZWxlbWVudHMuXG4gICAqL1xuICBnZXQgc2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5pZE1hcC5zaXplO1xuICB9XG59IiwiaW1wb3J0IHsgUG9wdXBUcmlnZ2VyTWFwIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IEZsb2F0aW5nUm9vdFN0b3JlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvRmxvYXRpbmdSb290U3RvcmUubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gZ2V0RW1wdHlSb290Q29udGV4dCgpIHtcbiAgcmV0dXJuIG5ldyBGbG9hdGluZ1Jvb3RTdG9yZSh7XG4gICAgb3BlbjogZmFsc2UsXG4gICAgdHJhbnNpdGlvblN0YXR1czogdW5kZWZpbmVkLFxuICAgIGZsb2F0aW5nRWxlbWVudDogbnVsbCxcbiAgICByZWZlcmVuY2VFbGVtZW50OiBudWxsLFxuICAgIHRyaWdnZXJFbGVtZW50czogbmV3IFBvcHVwVHJpZ2dlck1hcCgpLFxuICAgIGZsb2F0aW5nSWQ6IHVuZGVmaW5lZCxcbiAgICBzeW5jT25seTogZmFsc2UsXG4gICAgbmVzdGVkOiBmYWxzZSxcbiAgICBvbk9wZW5DaGFuZ2U6IHVuZGVmaW5lZFxuICB9KTtcbn0iLCJpbXBvcnQgeyBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBGbG9hdGluZ1Jvb3RTdG9yZSB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nUm9vdFN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgZ2V0RW1wdHlSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC91dGlscy9nZXRFbXB0eVJvb3RDb250ZXh0Lm1qc1wiO1xuXG4vKipcbiAqIFN0YXRlIGNvbW1vbiB0byBhbGwgcG9wdXAgc3RvcmVzLlxuICovXG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVJbml0aWFsUG9wdXBTdG9yZVN0YXRlKCkge1xuICByZXR1cm4ge1xuICAgIG9wZW46IGZhbHNlLFxuICAgIG9wZW5Qcm9wOiB1bmRlZmluZWQsXG4gICAgbW91bnRlZDogZmFsc2UsXG4gICAgdHJhbnNpdGlvblN0YXR1czogdW5kZWZpbmVkLFxuICAgIGZsb2F0aW5nUm9vdENvbnRleHQ6IGdldEVtcHR5Um9vdENvbnRleHQoKSxcbiAgICBmbG9hdGluZ0lkOiB1bmRlZmluZWQsXG4gICAgdHJpZ2dlckNvdW50OiAwLFxuICAgIHByZXZlbnRVbm1vdW50aW5nT25DbG9zZTogZmFsc2UsXG4gICAgcGF5bG9hZDogdW5kZWZpbmVkLFxuICAgIGFjdGl2ZVRyaWdnZXJJZDogbnVsbCxcbiAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogbnVsbCxcbiAgICB0cmlnZ2VySWRQcm9wOiB1bmRlZmluZWQsXG4gICAgcG9wdXBFbGVtZW50OiBudWxsLFxuICAgIHBvc2l0aW9uZXJFbGVtZW50OiBudWxsLFxuICAgIGFjdGl2ZVRyaWdnZXJQcm9wczogRU1QVFlfT0JKRUNULFxuICAgIGluYWN0aXZlVHJpZ2dlclByb3BzOiBFTVBUWV9PQkpFQ1QsXG4gICAgcG9wdXBQcm9wczogRU1QVFlfT0JKRUNUXG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUG9wdXBGbG9hdGluZ1Jvb3RDb250ZXh0KHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkID0gZmFsc2UpIHtcbiAgcmV0dXJuIG5ldyBGbG9hdGluZ1Jvb3RTdG9yZSh7XG4gICAgb3BlbjogZmFsc2UsXG4gICAgdHJhbnNpdGlvblN0YXR1czogdW5kZWZpbmVkLFxuICAgIGZsb2F0aW5nRWxlbWVudDogbnVsbCxcbiAgICByZWZlcmVuY2VFbGVtZW50OiBudWxsLFxuICAgIHRyaWdnZXJFbGVtZW50cyxcbiAgICBmbG9hdGluZ0lkLFxuICAgIHN5bmNPbmx5OiB0cnVlLFxuICAgIG5lc3RlZCxcbiAgICBvbk9wZW5DaGFuZ2U6IHVuZGVmaW5lZFxuICB9KTtcbn1cbmNvbnN0IGFjdGl2ZVRyaWdnZXJJZFNlbGVjdG9yID0gc3RhdGUgPT4gc3RhdGUudHJpZ2dlcklkUHJvcCA/PyBzdGF0ZS5hY3RpdmVUcmlnZ2VySWQ7XG5jb25zdCBvcGVuU2VsZWN0b3IgPSBzdGF0ZSA9PiBzdGF0ZS5vcGVuUHJvcCA/PyBzdGF0ZS5vcGVuO1xuY29uc3QgcG9wdXBJZFNlbGVjdG9yID0gc3RhdGUgPT4ge1xuICBjb25zdCBwb3B1cElkID0gc3RhdGUucG9wdXBFbGVtZW50Py5pZCA/PyBzdGF0ZS5mbG9hdGluZ0lkO1xuICByZXR1cm4gcG9wdXBJZCB8fCB1bmRlZmluZWQ7XG59O1xuZnVuY3Rpb24gdHJpZ2dlck93bnNPcGVuUG9wdXAoc3RhdGUsIHRyaWdnZXJJZCkge1xuICByZXR1cm4gdHJpZ2dlcklkICE9PSB1bmRlZmluZWQgJiYgb3BlblNlbGVjdG9yKHN0YXRlKSAmJiBhY3RpdmVUcmlnZ2VySWRTZWxlY3RvcihzdGF0ZSkgPT09IHRyaWdnZXJJZDtcbn1cbmZ1bmN0aW9uIHRyaWdnZXJPd25zT3BlblBvcHVwT3JJc09ubHlUcmlnZ2VyKHN0YXRlLCB0cmlnZ2VySWQpIHtcbiAgaWYgKHRyaWdnZXJPd25zT3BlblBvcHVwKHN0YXRlLCB0cmlnZ2VySWQpKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIHRyaWdnZXJJZCAhPT0gdW5kZWZpbmVkICYmIG9wZW5TZWxlY3RvcihzdGF0ZSkgJiYgYWN0aXZlVHJpZ2dlcklkU2VsZWN0b3Ioc3RhdGUpID09IG51bGwgJiYgc3RhdGUudHJpZ2dlckNvdW50ID09PSAxO1xufVxuZXhwb3J0IGNvbnN0IHBvcHVwU3RvcmVTZWxlY3RvcnMgPSB7XG4gIG9wZW46IG9wZW5TZWxlY3RvcixcbiAgbW91bnRlZDogc3RhdGUgPT4gc3RhdGUubW91bnRlZCxcbiAgdHJhbnNpdGlvblN0YXR1czogc3RhdGUgPT4gc3RhdGUudHJhbnNpdGlvblN0YXR1cyxcbiAgZmxvYXRpbmdSb290Q29udGV4dDogc3RhdGUgPT4gc3RhdGUuZmxvYXRpbmdSb290Q29udGV4dCxcbiAgdHJpZ2dlckNvdW50OiBzdGF0ZSA9PiBzdGF0ZS50cmlnZ2VyQ291bnQsXG4gIHByZXZlbnRVbm1vdW50aW5nT25DbG9zZTogc3RhdGUgPT4gc3RhdGUucHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICBwYXlsb2FkOiBzdGF0ZSA9PiBzdGF0ZS5wYXlsb2FkLFxuICBhY3RpdmVUcmlnZ2VySWQ6IGFjdGl2ZVRyaWdnZXJJZFNlbGVjdG9yLFxuICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogc3RhdGUgPT4gc3RhdGUubW91bnRlZCA/IHN0YXRlLmFjdGl2ZVRyaWdnZXJFbGVtZW50IDogbnVsbCxcbiAgcG9wdXBJZDogcG9wdXBJZFNlbGVjdG9yLFxuICAvKipcbiAgICogV2hldGhlciB0aGUgdHJpZ2dlciB3aXRoIHRoZSBnaXZlbiBJRCB3YXMgdXNlZCB0byBvcGVuIHRoZSBwb3B1cC5cbiAgICovXG4gIGlzVHJpZ2dlckFjdGl2ZTogKHN0YXRlLCB0cmlnZ2VySWQpID0+IHRyaWdnZXJJZCAhPT0gdW5kZWZpbmVkICYmIGFjdGl2ZVRyaWdnZXJJZFNlbGVjdG9yKHN0YXRlKSA9PT0gdHJpZ2dlcklkLFxuICAvKipcbiAgICogV2hldGhlciB0aGUgcG9wdXAgaXMgb3BlbiBhbmQgd2FzIGFjdGl2YXRlZCBieSBhIHRyaWdnZXIgd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAqL1xuICBpc09wZW5lZEJ5VHJpZ2dlcjogKHN0YXRlLCB0cmlnZ2VySWQpID0+IHRyaWdnZXJPd25zT3BlblBvcHVwKHN0YXRlLCB0cmlnZ2VySWQpLFxuICAvKipcbiAgICogV2hldGhlciB0aGUgcG9wdXAgaXMgbW91bnRlZCBhbmQgd2FzIGFjdGl2YXRlZCBieSBhIHRyaWdnZXIgd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAqL1xuICBpc01vdW50ZWRCeVRyaWdnZXI6IChzdGF0ZSwgdHJpZ2dlcklkKSA9PiB0cmlnZ2VySWQgIT09IHVuZGVmaW5lZCAmJiBhY3RpdmVUcmlnZ2VySWRTZWxlY3RvcihzdGF0ZSkgPT09IHRyaWdnZXJJZCAmJiBzdGF0ZS5tb3VudGVkLFxuICB0cmlnZ2VyUHJvcHM6IChzdGF0ZSwgaXNBY3RpdmUpID0+IGlzQWN0aXZlID8gc3RhdGUuYWN0aXZlVHJpZ2dlclByb3BzIDogc3RhdGUuaW5hY3RpdmVUcmlnZ2VyUHJvcHMsXG4gIC8qKlxuICAgKiBQb3B1cCBpZCBmb3IgdGhlIHRyaWdnZXIgdGhhdCBjdXJyZW50bHkgb3ducyB0aGUgb3BlbiBwb3B1cC5cbiAgICovXG4gIHRyaWdnZXJQb3B1cElkOiAoc3RhdGUsIHRyaWdnZXJJZCkgPT4gdHJpZ2dlck93bnNPcGVuUG9wdXBPcklzT25seVRyaWdnZXIoc3RhdGUsIHRyaWdnZXJJZCkgPyBwb3B1cElkU2VsZWN0b3Ioc3RhdGUpIDogdW5kZWZpbmVkLFxuICBwb3B1cFByb3BzOiBzdGF0ZSA9PiBzdGF0ZS5wb3B1cFByb3BzLFxuICBwb3B1cEVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnBvcHVwRWxlbWVudCxcbiAgcG9zaXRpb25lckVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnBvc2l0aW9uZXJFbGVtZW50XG59O1xuXG4vKipcbiAqIFN0b3JlIG1lbWJlcnMgYSBkZXRhY2hlZCBoYW5kbGUtYmFja2VkIHRyaWdnZXIgcmVhZHMgb3IgaW52b2tlcyBmb3IgdHJpZ2dlciByZWdpc3RyYXRpb24gYW5kIGRhdGFcbiAqIGZvcndhcmRpbmcuIGBzZXRgL2B1cGRhdGVgIGFyZSBpbmNsdWRlZCBvbmx5IGZvciB0cmlnZ2VyLWNvdW50IGFuZCB0cmlnZ2VyLWRhdGEgYm9va2tlZXBpbmc7IG9uIGFcbiAqIGRldGFjaGVkIChpbmVydCkgc3RvcmUgdGhleSBhcmUgaW50ZW50aW9uYWxseSBuby1vcHMsIHNvIGEgd3JpdGUgdGhyb3VnaCB0aGVtIGlzIG5vdCBndWFyYW50ZWVkIHRvXG4gKiBiZSBkdXJhYmxlLiBDb21wb25lbnQgaGFuZGxlLXN0b3JlIHZpZXdzIFBpY2sgdGhlc2UgZnJvbSB0aGVpciBjb25jcmV0ZSBzdG9yZSAocHJlc2VydmluZyBpdHNcbiAqIGNvbnRleHQgYW5kIHNlbGVjdG9ycykgYW5kIGFkZCBhbnkgY29tcG9uZW50LXNwZWNpZmljIHRyaWdnZXItaW52b2tlZCBtZW1iZXJzIHN1Y2ggYXMgYHNldE9wZW5gLlxuICovXG5cbi8qKlxuICogVGhlIHN1YnNldCBvZiBhIHBvcHVwIHN0b3JlIHRoYXQgdHJpZ2dlciByZWdpc3RyYXRpb24gYW5kIGRhdGEgZm9yd2FyZGluZyByZWx5IG9uLiBOYXJyb3cgZW5vdWdoXG4gKiB0aGF0IGFuIGluZXJ0IHN0b3JlIGNhbiBiZSBwYXNzZWQgd2hpbGUgZGV0YWNoZWQuXG4gKi8iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVN5bmNFeHRlcm5hbFN0b3JlIH0gZnJvbSAndXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbSc7XG5pbXBvcnQgeyBOT09QIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuLyoqXG4gKiBSZWFkcyB0aGUgc3RvcmUgY3VycmVudGx5IGV4cG9zZWQgYnkgYSBwb3B1cCBoYW5kbGUgYW5kIHN1YnNjcmliZXMgdG8gc3RvcmUtcG9pbnRlciBjaGFuZ2VzLlxuICogRGV0YWNoZWQgdHJpZ2dlcnMgdXNlIHRoaXMgdG8gZm9sbG93IGEgaGFuZGxlIGFzIGEgcm9vdCBhdHRhY2hlcyBvciBkZXRhY2hlczogd2hpbGUgbm8gcm9vdCBpc1xuICogYXR0YWNoZWQsIHRoZSBoYW5kbGUgZXhwb3NlcyBpdHMgZmFsbGJhY2sgc3RvcmU7IG9uY2UgYSByb290IGF0dGFjaGVzLCBzdWJzY3JpYmVycyByZS1yZW5kZXIgYW5kXG4gKiByZWFkIGZyb20gdGhlIGxpdmUgcm9vdCBzdG9yZS5cbiAqXG4gKiBSZXR1cm5zIGB1bmRlZmluZWRgIHdoZW4gbm8gaGFuZGxlIGlzIHByb3ZpZGVkIHNvIGNhbGxlcnMgY2FuIGZhbGwgYmFjayB0byB0aGVpciByb290IGNvbnRleHQuXG4gKlxuICogQHBhcmFtIGhhbmRsZSBUaGUgcG9wdXAgaGFuZGxlIHRvIHJlYWQgZnJvbSwgb3IgYHVuZGVmaW5lZGAgd2hlbiB0aGUgdHJpZ2dlciBpcyBub3QgaGFuZGxlLWJvdW5kLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUG9wdXBIYW5kbGVTdG9yZShoYW5kbGUpIHtcbiAgY29uc3Qgc3Vic2NyaWJlID0gUmVhY3QudXNlQ2FsbGJhY2sobGlzdGVuZXIgPT4ge1xuICAgIGlmIChoYW5kbGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIE5PT1A7XG4gICAgfVxuICAgIHJldHVybiBoYW5kbGUuc3Vic2NyaWJlU3RvcmUobGlzdGVuZXIpO1xuICB9LCBbaGFuZGxlXSk7XG4gIGNvbnN0IGdldFNuYXBzaG90ID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJldHVybiBoYW5kbGUgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IGhhbmRsZS5zdG9yZTtcbiAgfSwgW2hhbmRsZV0pO1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3Vic2NyaWJlLCBnZXRTbmFwc2hvdCwgKCkgPT4gaGFuZGxlPy5zZXJ2ZXJTdG9yZSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlU2Nyb2xsTG9jayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVNjcm9sbExvY2snO1xuaW1wb3J0IHsgdXNlRGlzbWlzcyB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9pbmRleC5tanNcIjtcbmltcG9ydCB7IGNvbnRhaW5zLCBnZXRUYXJnZXQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyB1c2VQb3B1cEludGVyYWN0aW9uUHJvcHMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIERpYWxvZ0ludGVyYWN0aW9ucyh7XG4gIHN0b3JlLFxuICBwYXJlbnRDb250ZXh0LFxuICBpc0RyYXdlclxufSkge1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWwgPSBzdG9yZS51c2VTdGF0ZSgnZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWwnKTtcbiAgY29uc3QgbW9kYWwgPSBzdG9yZS51c2VTdGF0ZSgnbW9kYWwnKTtcbiAgY29uc3QgcG9wdXBFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3BvcHVwRWxlbWVudCcpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3QgW293bk5lc3RlZE9wZW5EaWFsb2dzLCBzZXRPd25OZXN0ZWRPcGVuRGlhbG9nc10gPSBSZWFjdC51c2VTdGF0ZSgwKTtcbiAgY29uc3QgW293bk5lc3RlZE9wZW5EcmF3ZXJzLCBzZXRPd25OZXN0ZWRPcGVuRHJhd2Vyc10gPSBSZWFjdC51c2VTdGF0ZSgwKTtcbiAgY29uc3QgaXNUb3Btb3N0ID0gb3duTmVzdGVkT3BlbkRpYWxvZ3MgPT09IDA7XG4gIGNvbnN0IGRpc21pc3MgPSB1c2VEaXNtaXNzKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICBvdXRzaWRlUHJlc3NFdmVudCgpIHtcbiAgICAgIGlmIChzdG9yZS5jb250ZXh0LmludGVybmFsQmFja2Ryb3BSZWYuY3VycmVudCB8fCBzdG9yZS5jb250ZXh0LmJhY2tkcm9wUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuICdpbnRlbnRpb25hbCc7XG4gICAgICB9XG4gICAgICAvLyBFbnN1cmUgYGFyaWEtaGlkZGVuYCBvbiBvdXRzaWRlIGVsZW1lbnRzIGlzIHJlbW92ZWQgaW1tZWRpYXRlbHlcbiAgICAgIC8vIG9uIG91dHNpZGUgcHJlc3Mgd2hlbiB0cmFwcGluZyBmb2N1cy5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIG1vdXNlOiBtb2RhbCA9PT0gJ3RyYXAtZm9jdXMnID8gJ3Nsb3BweScgOiAnaW50ZW50aW9uYWwnLFxuICAgICAgICB0b3VjaDogJ3Nsb3BweSdcbiAgICAgIH07XG4gICAgfSxcbiAgICBvdXRzaWRlUHJlc3MoZXZlbnQpIHtcbiAgICAgIGlmICghc3RvcmUuY29udGV4dC5vdXRzaWRlUHJlc3NFbmFibGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuXG4gICAgICAvLyBGb3IgbW91c2UgZXZlbnRzLCBvbmx5IGFjY2VwdCBsZWZ0IGJ1dHRvbiAoYnV0dG9uIDApXG4gICAgICAvLyBGb3IgdG91Y2ggZXZlbnRzLCBhIHNpbmdsZSB0b3VjaCBpcyBlcXVpdmFsZW50IHRvIGxlZnQgYnV0dG9uXG4gICAgICBpZiAoJ2J1dHRvbicgaW4gZXZlbnQgJiYgZXZlbnQuYnV0dG9uICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICgndG91Y2hlcycgaW4gZXZlbnQpIHtcbiAgICAgICAgLy8gT3V0c2lkZSBwcmVzcyBjYW4gYmUgaGFuZGxlZCBvbiBgdG91Y2hlbmRgLCB3aGVyZSB0aGUgbGlmdGVkIHBvaW50IGlzXG4gICAgICAgIC8vIHJlcG9ydGVkIGluIGBjaGFuZ2VkVG91Y2hlc2AgYW5kIGB0b3VjaGVzYCBjb250YWlucyBhbnkgcmVtYWluaW5nXG4gICAgICAgIC8vIGFjdGl2ZSBwb2ludHMuIFRyZWF0IGl0IGFzIGEgc2luZ2xlLWZpbmdlciB0YXAgb25seSB3aGVuIGV4YWN0bHkgb25lXG4gICAgICAgIC8vIHRvdWNoIGVuZGVkIGFuZCBubyBvdGhlciBmaW5nZXJzIGFyZSBzdGlsbCBkb3duLlxuICAgICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ3RvdWNoZW5kJykge1xuICAgICAgICAgIGlmIChldmVudC5jaGFuZ2VkVG91Y2hlcy5sZW5ndGggIT09IDEgfHwgZXZlbnQudG91Y2hlcy5sZW5ndGggIT09IDApIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoZXZlbnQudG91Y2hlcy5sZW5ndGggIT09IDEpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG4gICAgICBpZiAoaXNUb3Btb3N0ICYmICFkaXNhYmxlUG9pbnRlckRpc21pc3NhbCkge1xuICAgICAgICAvLyBPbmx5IGNsb3NlIGlmIHRoZSBjbGljayBvY2N1cnJlZCBvbiB0aGUgZGlhbG9nJ3Mgb3duaW5nIGJhY2tkcm9wLlxuICAgICAgICAvLyBUaGlzIHN1cHBvcnRzIG11bHRpcGxlIG1vZGFsIGRpYWxvZ3MgdGhhdCBhcmVuJ3QgbmVzdGVkIGluIHRoZSBSZWFjdCB0cmVlOlxuICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vbXVpL2Jhc2UtdWkvaXNzdWVzLzEzMjBcbiAgICAgICAgaWYgKG1vZGFsKSB7XG4gICAgICAgICAgY29uc3QgaW50ZXJuYWxCYWNrZHJvcCA9IHN0b3JlLmNvbnRleHQuaW50ZXJuYWxCYWNrZHJvcFJlZi5jdXJyZW50O1xuICAgICAgICAgIGNvbnN0IGJhY2tkcm9wID0gc3RvcmUuY29udGV4dC5iYWNrZHJvcFJlZi5jdXJyZW50O1xuICAgICAgICAgIHJldHVybiBpbnRlcm5hbEJhY2tkcm9wIHx8IGJhY2tkcm9wID8gaW50ZXJuYWxCYWNrZHJvcCA9PT0gdGFyZ2V0IHx8IGJhY2tkcm9wID09PSB0YXJnZXQgfHwgY29udGFpbnModGFyZ2V0LCBwb3B1cEVsZW1lbnQpICYmICF0YXJnZXQ/Lmhhc0F0dHJpYnV0ZSgnZGF0YS1iYXNlLXVpLXBvcnRhbCcpIDogdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9LFxuICAgIGVzY2FwZUtleTogaXNUb3Btb3N0XG4gIH0pO1xuICB1c2VTY3JvbGxMb2NrKG9wZW4gJiYgbW9kYWwgPT09IHRydWUsIHBvcHVwRWxlbWVudCk7XG5cbiAgLy8gTGlzdGVuIGZvciBuZXN0ZWQgb3Blbi9jbG9zZSBldmVudHMgb24gdGhpcyBzdG9yZSB0byBtYWludGFpbiB0aGUgY291bnRzLlxuICAvLyBBIGNsb3NlIG5vdGlmaWNhdGlvbiBpcyBhbiBvcGVuIG5vdGlmaWNhdGlvbiB3aXRoIHplcm9lZCBjb3VudHMuXG4gIHN0b3JlLnVzZUNvbnRleHRDYWxsYmFjaygnb25OZXN0ZWREaWFsb2dPcGVuJywgKGRpYWxvZ0NvdW50LCBkcmF3ZXJDb3VudCkgPT4ge1xuICAgIHNldE93bk5lc3RlZE9wZW5EaWFsb2dzKGRpYWxvZ0NvdW50KTtcbiAgICBzZXRPd25OZXN0ZWRPcGVuRHJhd2VycyhkcmF3ZXJDb3VudCk7XG4gIH0pO1xuXG4gIC8vIE5vdGlmeSBwYXJlbnQgb2Ygb3VyIG9wZW4vY2xvc2Ugc3RhdGUgdXNpbmcgcGFyZW50IGNhbGxiYWNrcywgaWYgYW55XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHBhcmVudENvbnRleHQ/Lm9uTmVzdGVkRGlhbG9nT3Blbikge1xuICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgcGFyZW50Q29udGV4dC5vbk5lc3RlZERpYWxvZ09wZW4ob3duTmVzdGVkT3BlbkRpYWxvZ3MgKyAxLCBvd25OZXN0ZWRPcGVuRHJhd2VycyArIChpc0RyYXdlciA/IDEgOiAwKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJlbnRDb250ZXh0Lm9uTmVzdGVkRGlhbG9nT3BlbigwLCAwKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChwYXJlbnRDb250ZXh0Py5vbk5lc3RlZERpYWxvZ09wZW4gJiYgb3Blbikge1xuICAgICAgICBwYXJlbnRDb250ZXh0Lm9uTmVzdGVkRGlhbG9nT3BlbigwLCAwKTtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbaXNEcmF3ZXIsIG9wZW4sIG93bk5lc3RlZE9wZW5EaWFsb2dzLCBvd25OZXN0ZWRPcGVuRHJhd2VycywgcGFyZW50Q29udGV4dF0pO1xuICB1c2VQb3B1cEludGVyYWN0aW9uUHJvcHMoc3RvcmUsIHtcbiAgICAvLyBgZW5hYmxlZGAgaXMgbm90IHBhc3NlZCB0byBgdXNlRGlzbWlzc2AsIHNvIGl0cyBwcm9wcyBhcmUgYWx3YXlzIGRlZmluZWQsXG4gICAgLy8gYW5kIGB0cmlnZ2VyYCBpcyB0aGUgc2FtZSBvYmplY3QgYXMgYHJlZmVyZW5jZWAuXG4gICAgYWN0aXZlVHJpZ2dlclByb3BzOiBkaXNtaXNzLnJlZmVyZW5jZSxcbiAgICBpbmFjdGl2ZVRyaWdnZXJQcm9wczogZGlzbWlzcy50cmlnZ2VyLFxuICAgIC8vIERpYWxvZ1BvcHVwIGFuZCBEcmF3ZXJQb3B1cCBzcHJlYWQgYEZPQ1VTQUJMRV9QT1BVUF9QUk9QU2AgZGlyZWN0bHksIHNvXG4gICAgLy8gdGhpcyBvbmx5IG5lZWRzIHRvIGNhcnJ5IHRoZSBkaXNtaXNzIGhhbmRsZXJzLlxuICAgIHBvcHVwUHJvcHM6IGRpc21pc3MuZmxvYXRpbmcsXG4gICAgbmVzdGVkT3BlbkRpYWxvZ0NvdW50OiBvd25OZXN0ZWRPcGVuRGlhbG9ncyxcbiAgICBuZXN0ZWRPcGVuRHJhd2VyQ291bnQ6IG93bk5lc3RlZE9wZW5EcmF3ZXJzXG4gIH0pO1xuICByZXR1cm4gbnVsbDtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBEaWFsb2dSb290Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dSb290Q29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nUm9vdENvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VEaWFsb2dSb290Q29udGV4dChvcHRpb25hbCkge1xuICBjb25zdCBzdG9yZSA9IFJlYWN0LnVzZUNvbnRleHQoRGlhbG9nUm9vdENvbnRleHQpO1xuICBpZiAoIW9wdGlvbmFsICYmIHN0b3JlID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IERpYWxvZ1Jvb3RDb250ZXh0IGlzIG1pc3NpbmcuIERpYWxvZyBwYXJ0cyBtdXN0IGJlIHBsYWNlZCB3aXRoaW4gPERpYWxvZy5Sb290Pi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSgyNykpO1xuICB9XG4gIHJldHVybiBzdG9yZTtcbn0iLCJpbXBvcnQgeyBSZWFjdFN0b3JlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RvcmUnO1xuLyoqXG4gKiBBIGBSZWFjdFN0b3JlYCB3aG9zZSBzdGF0ZSBuZXZlciBjaGFuZ2VzLlxuICpcbiAqIFVzZWZ1bCBmb3IgZmFsbGJhY2sgc3RvcmVzIHRoYXQgbmVlZCB0byBzdXBwb3J0IG5vcm1hbCBzdG9yZSByZWFkcyB3aGlsZSBkZXRhY2hlZCBmcm9tIHRoZVxuICogY29tcG9uZW50IHRoYXQgb3ducyByZWFsIHN0YXRlLiBDb250ZXh0IHZhbHVlcyBtYXkgc3RpbGwgY29udGFpbiBtdXRhYmxlIHJlZnMgb3IgbWFwcy5cbiAqL1xuZXhwb3J0IGNsYXNzIE51bGxTdG9yZSBleHRlbmRzIFJlYWN0U3RvcmUge1xuICAvLyBgdXBkYXRlYC9gc2V0YC9gbm90aWZ5QWxsYCBmdW5uZWwgdGhyb3VnaCBgc2V0U3RhdGVgIGluIHRoZSBiYXNlIGBTdG9yZWAsIHNvIG92ZXJyaWRpbmdcbiAgLy8gYHNldFN0YXRlYCBhbG9uZSB3b3VsZCBuZXV0cmFsaXplIHRoZW0gdG9kYXkuIFRoZXkgYXJlIG92ZXJyaWRkZW4gZXhwbGljaXRseSBzbyB0aGUgc3RvcmUgc3RheXNcbiAgLy8gaW5lcnQgZXZlbiBpZiBhIGZ1dHVyZSBiYXNlLWNsYXNzIGNoYW5nZSBzdG9wcyByb3V0aW5nIGEgbXV0YXRvciB0aHJvdWdoIGBzZXRTdGF0ZWAuXG4gIHNldFN0YXRlKF9uZXdTdGF0ZSkge31cbiAgdXBkYXRlKF9jaGFuZ2VzKSB7fVxuICBzZXQoX2tleSwgX3ZhbHVlKSB7fVxuICBub3RpZnlBbGwoKSB7fVxufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFJlYWN0U3RvcmUgfSBmcm9tICdAYmFzZS11aS91dGlscy9zdG9yZSc7XG5pbXBvcnQgeyBOdWxsU3RvcmUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvTnVsbFN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlUG9wdXBGbG9hdGluZ1Jvb3RDb250ZXh0LCBjcmVhdGVJbml0aWFsUG9wdXBTdG9yZVN0YXRlLCBwb3B1cFN0b3JlU2VsZWN0b3JzLCBQb3B1cFRyaWdnZXJNYXAsIHNldFBvcHVwT3BlblN0YXRlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmNvbnN0IHNlbGVjdG9ycyA9IHtcbiAgLi4ucG9wdXBTdG9yZVNlbGVjdG9ycyxcbiAgbW9kYWw6IHN0YXRlID0+IHN0YXRlLm1vZGFsLFxuICBuZXN0ZWQ6IHN0YXRlID0+IHN0YXRlLm5lc3RlZCxcbiAgbmVzdGVkT3BlbkRpYWxvZ0NvdW50OiBzdGF0ZSA9PiBzdGF0ZS5uZXN0ZWRPcGVuRGlhbG9nQ291bnQsXG4gIG5lc3RlZE9wZW5EcmF3ZXJDb3VudDogc3RhdGUgPT4gc3RhdGUubmVzdGVkT3BlbkRyYXdlckNvdW50LFxuICBkaXNhYmxlUG9pbnRlckRpc21pc3NhbDogc3RhdGUgPT4gc3RhdGUuZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWwsXG4gIG9wZW5NZXRob2Q6IHN0YXRlID0+IHN0YXRlLm9wZW5NZXRob2QsXG4gIGRlc2NyaXB0aW9uRWxlbWVudElkOiBzdGF0ZSA9PiBzdGF0ZS5kZXNjcmlwdGlvbkVsZW1lbnRJZCxcbiAgdGl0bGVFbGVtZW50SWQ6IHN0YXRlID0+IHN0YXRlLnRpdGxlRWxlbWVudElkLFxuICB2aWV3cG9ydEVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnZpZXdwb3J0RWxlbWVudCxcbiAgcm9sZTogc3RhdGUgPT4gc3RhdGUucm9sZVxufTtcblxuLyoqXG4gKiBUaGUgc3Vic2V0IG9mIGBEaWFsb2dTdG9yZWAgdGhhdCBkZXRhY2hlZCBoYW5kbGUtYmFja2VkIHRyaWdnZXJzIHJlbHkgb24uIEJvdGggdGhlIHJlYWxcbiAqIGBEaWFsb2dTdG9yZWAgYW5kIHRoZSBpbmVydCBmYWxsYmFjayBzdG9yZSBzYXRpc2Z5IGl0LCBzbyBhIHRyaWdnZXIgY2FuIHJlYWQgZnJvbSB3aGljaGV2ZXJcbiAqIHN0b3JlIHRoZSBoYW5kbGUgY3VycmVudGx5IGV4cG9zZXMuXG4gKi9cblxuZXhwb3J0IGNsYXNzIERpYWxvZ1N0b3JlIGV4dGVuZHMgUmVhY3RTdG9yZSB7XG4gIGNvbnN0cnVjdG9yKGluaXRpYWxTdGF0ZSwgZmxvYXRpbmdJZCwgbmVzdGVkKSB7XG4gICAgY29uc3QgdHJpZ2dlckVsZW1lbnRzID0gbmV3IFBvcHVwVHJpZ2dlck1hcCgpO1xuICAgIGNvbnN0IHN0YXRlID0gY3JlYXRlSW5pdGlhbFN0YXRlKGluaXRpYWxTdGF0ZSwgdHJpZ2dlckVsZW1lbnRzLCBmbG9hdGluZ0lkLCBuZXN0ZWQpO1xuICAgIHN1cGVyKHN0YXRlLCBjcmVhdGVJbml0aWFsQ29udGV4dCh0cmlnZ2VyRWxlbWVudHMpLCBzZWxlY3RvcnMpO1xuICB9XG4gIHNldE9wZW4gPSAobmV4dE9wZW4sIGV2ZW50RGV0YWlscykgPT4ge1xuICAgIGV2ZW50RGV0YWlscy5wcmV2ZW50VW5tb3VudE9uQ2xvc2UgPSAoKSA9PiB7XG4gICAgICB0aGlzLnNldCgncHJldmVudFVubW91bnRpbmdPbkNsb3NlJywgdHJ1ZSk7XG4gICAgfTtcbiAgICBpZiAoIW5leHRPcGVuICYmIGV2ZW50RGV0YWlscy50cmlnZ2VyID09IG51bGwgJiYgdGhpcy5zdGF0ZS5hY3RpdmVUcmlnZ2VySWQgIT0gbnVsbCkge1xuICAgICAgLy8gV2hlbiBjbG9zaW5nIHRoZSBkaWFsb2csIHBhc3MgdGhlIG9sZCB0cmlnZ2VyIHRvIHRoZSBvbk9wZW5DaGFuZ2UgZXZlbnRcbiAgICAgIC8vIHNvIGl0J3Mgbm90IHJlc2V0IHRvbyBlYXJseSAocG90ZW50aWFsbHkgY2F1c2luZyBmb2N1cyBpc3N1ZXMgaW4gY29udHJvbGxlZCBzY2VuYXJpb3MpLlxuICAgICAgZXZlbnREZXRhaWxzLnRyaWdnZXIgPSB0aGlzLnN0YXRlLmFjdGl2ZVRyaWdnZXJFbGVtZW50ID8/IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgdGhpcy5jb250ZXh0Lm9uT3BlbkNoYW5nZT8uKG5leHRPcGVuLCBldmVudERldGFpbHMpO1xuICAgIGlmIChldmVudERldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnN0YXRlLmZsb2F0aW5nUm9vdENvbnRleHQuZGlzcGF0Y2hPcGVuQ2hhbmdlKG5leHRPcGVuLCBldmVudERldGFpbHMpO1xuICAgIGNvbnN0IHVwZGF0ZWRTdGF0ZSA9IHtcbiAgICAgIG9wZW46IG5leHRPcGVuXG4gICAgfTtcbiAgICBzZXRQb3B1cE9wZW5TdGF0ZSh1cGRhdGVkU3RhdGUsIG5leHRPcGVuLCBldmVudERldGFpbHMudHJpZ2dlcik7XG4gICAgdGhpcy51cGRhdGUodXBkYXRlZFN0YXRlKTtcbiAgfTtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIHRoZSBpbmVydCBmYWxsYmFjayBzdG9yZSB1c2VkIGJ5IGRldGFjaGVkIGhhbmRsZS1iYWNrZWQgdHJpZ2dlcnMgd2hpbGUgbm9cbiAqIGBEaWFsb2cuUm9vdGAgaXMgYXR0YWNoZWQuIEl0IHByZXNlcnZlcyBhIGRpYWxvZy1zcGVjaWZpYyB0cmlnZ2VyIHJlZ2lzdHJ5IGluIGNvbnRleHQgc29cbiAqIGRldGFjaGVkIHRyaWdnZXJzIGNhbiByZWdpc3RlciBiZWZvcmUgbWlncmF0aW5nIHRvIHRoZSBsaXZlIHJvb3Qgc3RvcmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVOdWxsRGlhbG9nU3RvcmUoKSB7XG4gIGNvbnN0IHRyaWdnZXJFbGVtZW50cyA9IG5ldyBQb3B1cFRyaWdnZXJNYXAoKTtcbiAgcmV0dXJuIG5ldyBOdWxsU3RvcmUoT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsU3RhdGUodW5kZWZpbmVkLCB0cmlnZ2VyRWxlbWVudHMpKSwgT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsQ29udGV4dCh0cmlnZ2VyRWxlbWVudHMpKSwgc2VsZWN0b3JzKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxTdGF0ZShpbml0aWFsU3RhdGUsIHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkID0gZmFsc2UpIHtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgLi4uY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSgpLFxuICAgIG1vZGFsOiB0cnVlLFxuICAgIGRpc2FibGVQb2ludGVyRGlzbWlzc2FsOiBmYWxzZSxcbiAgICB2aWV3cG9ydEVsZW1lbnQ6IG51bGwsXG4gICAgZGVzY3JpcHRpb25FbGVtZW50SWQ6IHVuZGVmaW5lZCxcbiAgICB0aXRsZUVsZW1lbnRJZDogdW5kZWZpbmVkLFxuICAgIG9wZW5NZXRob2Q6IG51bGwsXG4gICAgbmVzdGVkOiBmYWxzZSxcbiAgICBuZXN0ZWRPcGVuRGlhbG9nQ291bnQ6IDAsXG4gICAgbmVzdGVkT3BlbkRyYXdlckNvdW50OiAwLFxuICAgIHJvbGU6ICdkaWFsb2cnLFxuICAgIC4uLmluaXRpYWxTdGF0ZVxuICB9O1xuICBzdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0ID0gY3JlYXRlUG9wdXBGbG9hdGluZ1Jvb3RDb250ZXh0KHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkKTtcbiAgcmV0dXJuIHN0YXRlO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5pdGlhbENvbnRleHQodHJpZ2dlckVsZW1lbnRzKSB7XG4gIHJldHVybiB7XG4gICAgcG9wdXBSZWY6IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVSZWYoKSxcbiAgICBiYWNrZHJvcFJlZjogLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZVJlZigpLFxuICAgIGludGVybmFsQmFja2Ryb3BSZWY6IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVSZWYoKSxcbiAgICBvdXRzaWRlUHJlc3NFbmFibGVkUmVmOiB7XG4gICAgICBjdXJyZW50OiB0cnVlXG4gICAgfSxcbiAgICB0cmlnZ2VyRWxlbWVudHMsXG4gICAgb25PcGVuQ2hhbmdlOiB1bmRlZmluZWQsXG4gICAgb25PcGVuQ2hhbmdlQ29tcGxldGU6IHVuZGVmaW5lZFxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRGlhbG9nSW50ZXJhY3Rpb25zIH0gZnJvbSBcIi4vdXNlRGlhbG9nUm9vdC5tanNcIjtcbmltcG9ydCB7IERpYWxvZ1Jvb3RDb250ZXh0LCB1c2VEaWFsb2dSb290Q29udGV4dCB9IGZyb20gXCIuL0RpYWxvZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgRGlhbG9nU3RvcmUgfSBmcm9tIFwiLi4vc3RvcmUvRGlhbG9nU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyB1c2VJbXBsaWNpdEFjdGl2ZVRyaWdnZXIsIHVzZU9wZW5TdGF0ZVRyYW5zaXRpb25zLCBQb3B1cEhhbmRsZUF0dGFjaG1lbnQsIHVzZVBvcHVwUm9vdFN0b3JlLCB1c2VQb3B1cFJvb3RTeW5jIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlUmVuZGVyRGlhbG9nUm9vdChtb2RlLCBwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgb3Blbjogb3BlblByb3AsXG4gICAgZGVmYXVsdE9wZW4gPSBmYWxzZSxcbiAgICBvbk9wZW5DaGFuZ2UsXG4gICAgb25PcGVuQ2hhbmdlQ29tcGxldGUsXG4gICAgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWw6IGRpc2FibGVQb2ludGVyRGlzbWlzc2FsUHJvcCA9IGZhbHNlLFxuICAgIG1vZGFsOiBtb2RhbFByb3AgPSB0cnVlLFxuICAgIGFjdGlvbnNSZWYsXG4gICAgaGFuZGxlLFxuICAgIHRyaWdnZXJJZDogdHJpZ2dlcklkUHJvcCxcbiAgICBkZWZhdWx0VHJpZ2dlcklkOiBkZWZhdWx0VHJpZ2dlcklkUHJvcCA9IG51bGxcbiAgfSA9IHByb3BzO1xuICBjb25zdCBpc0RyYXdlciA9IG1vZGUgPT09ICdkcmF3ZXInO1xuICBjb25zdCBpc0FsZXJ0RGlhbG9nID0gbW9kZSA9PT0gJ2FsZXJ0LWRpYWxvZyc7XG4gIGNvbnN0IG1vZGFsID0gaXNBbGVydERpYWxvZyA/IHRydWUgOiBtb2RhbFByb3A7XG4gIGNvbnN0IGRpc2FibGVQb2ludGVyRGlzbWlzc2FsID0gaXNBbGVydERpYWxvZyB8fCBkaXNhYmxlUG9pbnRlckRpc21pc3NhbFByb3A7XG4gIGNvbnN0IHJvbGUgPSBpc0FsZXJ0RGlhbG9nID8gJ2FsZXJ0ZGlhbG9nJyA6ICdkaWFsb2cnO1xuICBjb25zdCBwYXJlbnRTdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KHRydWUpO1xuICBjb25zdCBuZXN0ZWQgPSBwYXJlbnRTdG9yZSAhPSBudWxsO1xuICBjb25zdCByb290U3RhdGUgPSB7XG4gICAgbW9kYWwsXG4gICAgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWwsXG4gICAgbmVzdGVkLFxuICAgIHJvbGVcbiAgfTtcblxuICAvLyBUaGUgc3RvcmUgaXMgb3duZWQgYnkgdGhpcyBSb290IGluc3RhbmNlIGFuZCBjcmVhdGVkIGV4YWN0bHkgb25jZS4gSXQgaXMgbm90IHRpZWQgdG8gdGhlIGhhbmRsZTpcbiAgLy8gdGhlIGhhbmRsZSBhdHRhY2hlcyB0byBpdCwgc28gc3dhcHBpbmcgdGhlIGhhbmRsZSByZS1hdHRhY2hlcyByYXRoZXIgdGhhbiByZWNyZWF0aW5nIHN0YXRlLlxuICAvLyBEZWZhdWx0IHZhbHVlcyBhcmUgb25seSBpbml0aWFsIHZhbHVlczsgY29udHJvbGxlZCB2YWx1ZXMgYW5kIHJvb3Qgc3RhdGUgYXJlIHN5bmNlZCBhZnRlciBjcmVhdGlvbi5cbiAgLy8gRGlhbG9ncyBwYXNzIHRoZSBwb3B1cCBlbGVtZW50IHRvIEZsb2F0aW5nIFVJIGFzIHRoZSBmbG9hdGluZyBlbGVtZW50IChgdHJlYXRQb3B1cEFzRmxvYXRpbmdFbGVtZW50YCkuXG4gIGNvbnN0IHN0b3JlID0gdXNlUG9wdXBSb290U3RvcmUoKGZsb2F0aW5nSWQsIGZsb2F0aW5nTmVzdGVkKSA9PiBuZXcgRGlhbG9nU3RvcmUoe1xuICAgIG9wZW46IGRlZmF1bHRPcGVuLFxuICAgIG9wZW5Qcm9wLFxuICAgIGFjdGl2ZVRyaWdnZXJJZDogZGVmYXVsdFRyaWdnZXJJZFByb3AsXG4gICAgdHJpZ2dlcklkUHJvcCxcbiAgICAuLi5yb290U3RhdGVcbiAgfSwgZmxvYXRpbmdJZCwgZmxvYXRpbmdOZXN0ZWQpLCB0cnVlKTtcbiAgc3RvcmUudXNlQ29udHJvbGxlZFByb3AoJ29wZW5Qcm9wJywgb3BlblByb3ApO1xuICBzdG9yZS51c2VDb250cm9sbGVkUHJvcCgndHJpZ2dlcklkUHJvcCcsIHRyaWdnZXJJZFByb3ApO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZXMocm9vdFN0YXRlKTtcbiAgc3RvcmUudXNlQ29udGV4dENhbGxiYWNrKCdvbk9wZW5DaGFuZ2UnLCBvbk9wZW5DaGFuZ2UpO1xuICBzdG9yZS51c2VDb250ZXh0Q2FsbGJhY2soJ29uT3BlbkNoYW5nZUNvbXBsZXRlJywgb25PcGVuQ2hhbmdlQ29tcGxldGUpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHBheWxvYWQgPSBzdG9yZS51c2VTdGF0ZSgncGF5bG9hZCcpO1xuICB1c2VQb3B1cFJvb3RTeW5jKHN0b3JlLCBvcGVuKTtcbiAgdXNlSW1wbGljaXRBY3RpdmVUcmlnZ2VyKHN0b3JlKTtcbiAgY29uc3Qge1xuICAgIGZvcmNlVW5tb3VudFxuICB9ID0gdXNlT3BlblN0YXRlVHJhbnNpdGlvbnMob3Blbiwgc3RvcmUpO1xuICBSZWFjdC51c2VJbXBlcmF0aXZlSGFuZGxlKGFjdGlvbnNSZWYsICgpID0+ICh7XG4gICAgdW5tb3VudDogZm9yY2VVbm1vdW50LFxuICAgIGNsb3NlOiAoKSA9PiBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5pbXBlcmF0aXZlQWN0aW9uKSlcbiAgfSksIFtmb3JjZVVubW91bnQsIHN0b3JlXSk7XG4gIGNvbnN0IHNob3VsZFJlbmRlckludGVyYWN0aW9ucyA9IG9wZW4gfHwgbW91bnRlZDtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhEaWFsb2dSb290Q29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBzdG9yZSxcbiAgICBjaGlsZHJlbjogW2hhbmRsZSAmJiAvKiNfX1BVUkVfXyovX2pzeChQb3B1cEhhbmRsZUF0dGFjaG1lbnQsIHtcbiAgICAgIGhhbmRsZTogaGFuZGxlLFxuICAgICAgc3RvcmU6IHN0b3JlXG4gICAgfSksIHNob3VsZFJlbmRlckludGVyYWN0aW9ucyAmJiAvKiNfX1BVUkVfXyovX2pzeChEaWFsb2dJbnRlcmFjdGlvbnMsIHtcbiAgICAgIHN0b3JlOiBzdG9yZSxcbiAgICAgIHBhcmVudENvbnRleHQ6IHBhcmVudFN0b3JlPy5jb250ZXh0LFxuICAgICAgaXNEcmF3ZXI6IGlzRHJhd2VyXG4gICAgfSksIHR5cGVvZiBjaGlsZHJlbiA9PT0gJ2Z1bmN0aW9uJyA/IGNoaWxkcmVuKHtcbiAgICAgIHBheWxvYWRcbiAgICB9KSA6IGNoaWxkcmVuXVxuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IHVzZVJlbmRlckRpYWxvZ1Jvb3QgfSBmcm9tIFwiLi4vLi4vZGlhbG9nL3Jvb3QvdXNlUmVuZGVyRGlhbG9nUm9vdC5tanNcIjtcbi8qKlxuICogR3JvdXBzIGFsbCBwYXJ0cyBvZiB0aGUgYWxlcnQgZGlhbG9nLlxuICogRG9lc24ndCByZW5kZXIgaXRzIG93biBIVE1MIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgQWxlcnQgRGlhbG9nXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvYWxlcnQtZGlhbG9nKVxuICovXG5leHBvcnQgZnVuY3Rpb24gQWxlcnREaWFsb2dSb290KHByb3BzKSB7XG4gIHJldHVybiB1c2VSZW5kZXJEaWFsb2dSb290KCdhbGVydC1kaWFsb2cnLCBwcm9wcyk7XG59IiwiaW1wb3J0IHsgVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLCB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmV4cG9ydCBsZXQgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyA9IGZ1bmN0aW9uIChDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzKSB7XG4gIC8qKlxuICAgKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGlzIG9wZW4uXG4gICAqL1xuICBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzW1wib3BlblwiXSA9IFwiZGF0YS1vcGVuXCI7XG4gIC8qKlxuICAgKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGlzIGNsb3NlZC5cbiAgICovXG4gIENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXNbXCJjbG9zZWRcIl0gPSBcImRhdGEtY2xvc2VkXCI7XG4gIC8qKlxuICAgKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGJlZ2lucyBhbmltYXRpbmcgaW4uXG4gICAqL1xuICBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzW0NvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXNbXCJzdGFydGluZ1N0eWxlXCJdID0gVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGVdID0gXCJzdGFydGluZ1N0eWxlXCI7XG4gIC8qKlxuICAgKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGlzIGFuaW1hdGluZyBvdXQuXG4gICAqL1xuICBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzW0NvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXNbXCJlbmRpbmdTdHlsZVwiXSA9IFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZV0gPSBcImVuZGluZ1N0eWxlXCI7XG4gIC8qKlxuICAgKiBQcmVzZW50IHdoZW4gdGhlIGFuY2hvciBpcyBoaWRkZW4uXG4gICAqL1xuICBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzW1wiYW5jaG9ySGlkZGVuXCJdID0gXCJkYXRhLWFuY2hvci1oaWRkZW5cIjtcbiAgLyoqXG4gICAqIEluZGljYXRlcyB3aGljaCBzaWRlIHRoZSBwb3B1cCBpcyBwb3NpdGlvbmVkIHJlbGF0aXZlIHRvIHRoZSB0cmlnZ2VyLlxuICAgKiBAdHlwZSB7ICd0b3AnIHwgJ2JvdHRvbScgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2lubGluZS1lbmQnIHwgJ2lubGluZS1zdGFydCd9XG4gICAqL1xuICBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzW1wic2lkZVwiXSA9IFwiZGF0YS1zaWRlXCI7XG4gIC8qKlxuICAgKiBJbmRpY2F0ZXMgaG93IHRoZSBwb3B1cCBpcyBhbGlnbmVkIHJlbGF0aXZlIHRvIHNwZWNpZmllZCBzaWRlLlxuICAgKiBAdHlwZSB7J3N0YXJ0JyB8ICdjZW50ZXInIHwgJ2VuZCd9XG4gICAqL1xuICBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzW1wiYWxpZ25cIl0gPSBcImRhdGEtYWxpZ25cIjtcbiAgcmV0dXJuIENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXM7XG59KHt9KTtcbmV4cG9ydCBsZXQgQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzID0gLyojX19QVVJFX18qL2Z1bmN0aW9uIChDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMpIHtcbiAgLyoqXG4gICAqIFByZXNlbnQgd2hlbiB0aGUgcG9wdXAgaXMgb3Blbi5cbiAgICovXG4gIENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlc1tcInBvcHVwT3BlblwiXSA9IFwiZGF0YS1wb3B1cC1vcGVuXCI7XG4gIC8qKlxuICAgKiBQcmVzZW50IHdoZW4gYSBwcmVzc2FibGUgdHJpZ2dlciBpcyBwcmVzc2VkLlxuICAgKi9cbiAgQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzW1wicHJlc3NlZFwiXSA9IFwiZGF0YS1wcmVzc2VkXCI7XG4gIHJldHVybiBDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXM7XG59KHt9KTtcblxuLy8gTGl0ZXJhbCBrZXlzIChpbnN0ZWFkIG9mIGVudW0gbWVtYmVyIHJlZmVyZW5jZXMpIGtlZXAgdGhlIGRvY3Mtb25seSBlbnVtcyBhYm92ZVxuLy8gdHJlZS1zaGFrZWFibGU6IGEgcnVudGltZSByZWZlcmVuY2Ugd291bGQgcmV0YWluIHRoZSB3aG9sZSBlbnVtIElJRkUgaW4gZXZlcnkgYnVuZGxlLlxuY29uc3QgVFJJR0dFUl9IT09LID0ge1xuICAnZGF0YS1wb3B1cC1vcGVuJzogJydcbn07XG5jb25zdCBQUkVTU0FCTEVfVFJJR0dFUl9IT09LID0ge1xuICAnZGF0YS1wb3B1cC1vcGVuJzogJycsXG4gICdkYXRhLXByZXNzZWQnOiAnJ1xufTtcbmNvbnN0IFBPUFVQX09QRU5fSE9PSyA9IHtcbiAgJ2RhdGEtb3Blbic6ICcnXG59O1xuY29uc3QgUE9QVVBfQ0xPU0VEX0hPT0sgPSB7XG4gICdkYXRhLWNsb3NlZCc6ICcnXG59O1xuY29uc3QgQU5DSE9SX0hJRERFTl9IT09LID0ge1xuICAnZGF0YS1hbmNob3ItaGlkZGVuJzogJydcbn07XG5leHBvcnQgY29uc3QgdHJpZ2dlck9wZW5TdGF0ZU1hcHBpbmcgPSB7XG4gIG9wZW4odmFsdWUpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBUUklHR0VSX0hPT0s7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59O1xuZXhwb3J0IGNvbnN0IHByZXNzYWJsZVRyaWdnZXJPcGVuU3RhdGVNYXBwaW5nID0ge1xuICBvcGVuKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICByZXR1cm4gUFJFU1NBQkxFX1RSSUdHRVJfSE9PSztcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn07XG5leHBvcnQgY29uc3QgcG9wdXBTdGF0ZU1hcHBpbmcgPSB7XG4gIG9wZW4odmFsdWUpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHJldHVybiBQT1BVUF9PUEVOX0hPT0s7XG4gICAgfVxuICAgIHJldHVybiBQT1BVUF9DTE9TRURfSE9PSztcbiAgfSxcbiAgYW5jaG9ySGlkZGVuKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICByZXR1cm4gQU5DSE9SX0hJRERFTl9IT09LO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufTtcbmV4cG9ydCBjb25zdCBwb3B1cFRyYW5zaXRpb25TdGF0ZU1hcHBpbmcgPSB7XG4gIC4uLnBvcHVwU3RhdGVNYXBwaW5nLFxuICAuLi50cmFuc2l0aW9uU3RhdHVzTWFwcGluZ1xufTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIEFuIG92ZXJsYXkgZGlzcGxheWVkIGJlbmVhdGggdGhlIHBvcHVwLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dCYWNrZHJvcCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ0JhY2tkcm9wKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZm9yY2VSZW5kZXIgPSBmYWxzZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBuZXN0ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbmVzdGVkJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCB0cmFuc2l0aW9uU3RhdHVzID0gc3RvcmUudXNlU3RhdGUoJ3RyYW5zaXRpb25TdGF0dXMnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHJlZjogW3N0b3JlLmNvbnRleHQuYmFja2Ryb3BSZWYsIGZvcndhcmRlZFJlZl0sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nLFxuICAgIHByb3BzOiBbe1xuICAgICAgcm9sZTogJ3ByZXNlbnRhdGlvbicsXG4gICAgICBoaWRkZW46ICFtb3VudGVkLFxuICAgICAgc3R5bGU6IHtcbiAgICAgICAgdXNlclNlbGVjdDogJ25vbmUnLFxuICAgICAgICBXZWJraXRVc2VyU2VsZWN0OiAnbm9uZSdcbiAgICAgIH1cbiAgICB9LCBlbGVtZW50UHJvcHNdLFxuICAgIGVuYWJsZWQ6IGZvcmNlUmVuZGVyIHx8ICFuZXN0ZWRcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ0JhY2tkcm9wLmRpc3BsYXlOYW1lID0gXCJEaWFsb2dCYWNrZHJvcFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBjbG9zZXMgdGhlIGRpYWxvZy5cbiAqIFJlbmRlcnMgYSBgPGJ1dHRvbj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgRGlhbG9nXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvZGlhbG9nKVxuICovXG5leHBvcnQgY29uc3QgRGlhbG9nQ2xvc2UgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBEaWFsb2dDbG9zZShjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgbmF0aXZlQnV0dG9uID0gdHJ1ZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCB7XG4gICAgZ2V0QnV0dG9uUHJvcHMsXG4gICAgYnV0dG9uUmVmXG4gIH0gPSB1c2VCdXR0b24oe1xuICAgIGRpc2FibGVkLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uXG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBkaXNhYmxlZFxuICB9O1xuICBmdW5jdGlvbiBoYW5kbGVDbGljayhldmVudCkge1xuICAgIGlmIChvcGVuKSB7XG4gICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5jbG9zZVByZXNzLCBldmVudC5uYXRpdmVFdmVudCkpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnYnV0dG9uJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIGJ1dHRvblJlZl0sXG4gICAgcHJvcHM6IFt7XG4gICAgICBvbkNsaWNrOiBoYW5kbGVDbGlja1xuICAgIH0sIGVsZW1lbnRQcm9wcywgZ2V0QnV0dG9uUHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dDbG9zZS5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nQ2xvc2VcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuLyoqXG4gKiBBIHBhcmFncmFwaCB3aXRoIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGRpYWxvZy5cbiAqIFJlbmRlcnMgYSBgPHA+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuZXhwb3J0IGNvbnN0IERpYWxvZ0Rlc2NyaXB0aW9uID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nRGVzY3JpcHRpb24oY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZVdpdGhDbGVhbnVwKCdkZXNjcmlwdGlvbkVsZW1lbnRJZCcsIGlkKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ3AnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIHByb3BzOiBbe1xuICAgICAgaWRcbiAgICB9LCBlbGVtZW50UHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dEZXNjcmlwdGlvbi5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nRGVzY3JpcHRpb25cIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBEaWFsb2dQb3J0YWxDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ1BvcnRhbENvbnRleHQuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1BvcnRhbENvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VEaWFsb2dQb3J0YWxDb250ZXh0KCkge1xuICBjb25zdCB2YWx1ZSA9IFJlYWN0LnVzZUNvbnRleHQoRGlhbG9nUG9ydGFsQ29udGV4dCk7XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiA8RGlhbG9nLlBvcnRhbD4gaXMgbWlzc2luZy4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSgyNikpO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn0iLCJpbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHBvcHVwU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuLyoqXG4gKiBTaGFyZWQgYnkgYERpYWxvZy5Qb3B1cGAgYW5kIGBEaWFsb2cuVmlld3BvcnRgLCB3aG9zZSBzdGF0ZXMgaGF2ZSB0aGUgc2FtZSBzaGFwZS5cbiAqIGBuZXN0ZWRgIGlzIG5vdCBtYXBwZWQ6IHVubWFwcGVkIGB0cnVlYCBib29sZWFucyBhbHJlYWR5IHJlbmRlciBhcyBgZGF0YS1uZXN0ZWRgLlxuICovXG5leHBvcnQgY29uc3QgZGlhbG9nU3RhdGVBdHRyaWJ1dGVzTWFwcGluZyA9IHtcbiAgLi4ucG9wdXBTdGF0ZU1hcHBpbmcsXG4gIC4uLnRyYW5zaXRpb25TdGF0dXNNYXBwaW5nLFxuICBuZXN0ZWREaWFsb2dPcGVuKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlID8ge1xuICAgICAgJ2RhdGEtbmVzdGVkLWRpYWxvZy1vcGVuJzogJydcbiAgICB9IDogbnVsbDtcbiAgfVxufTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEZsb2F0aW5nRm9jdXNNYW5hZ2VyIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VEaWFsb2dQb3J0YWxDb250ZXh0IH0gZnJvbSBcIi4uL3BvcnRhbC9EaWFsb2dQb3J0YWxDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlT3BlbkNoYW5nZUNvbXBsZXRlIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VPcGVuQ2hhbmdlQ29tcGxldGUubWpzXCI7XG5pbXBvcnQgeyBDT01QT1NJVEVfS0VZUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29tcG9zaXRlL2NvbXBvc2l0ZS5tanNcIjtcbmltcG9ydCB7IEZPQ1VTQUJMRV9QT1BVUF9QUk9QUywgY3JlYXRlRGVmYXVsdEluaXRpYWxGb2N1cyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBkaWFsb2dTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nIH0gZnJvbSBcIi4uL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogQSBjb250YWluZXIgZm9yIHRoZSBkaWFsb2cgY29udGVudHMuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBEaWFsb2dQb3B1cCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ1BvcHVwKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZmluYWxGb2N1cyxcbiAgICBpbml0aWFsRm9jdXMsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VEaWFsb2dSb290Q29udGV4dCgpO1xuICBjb25zdCBkZXNjcmlwdGlvbkVsZW1lbnRJZCA9IHN0b3JlLnVzZVN0YXRlKCdkZXNjcmlwdGlvbkVsZW1lbnRJZCcpO1xuICBjb25zdCBkaXNhYmxlUG9pbnRlckRpc21pc3NhbCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlUG9pbnRlckRpc21pc3NhbCcpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3Qgcm9vdFBvcHVwUHJvcHMgPSBzdG9yZS51c2VTdGF0ZSgncG9wdXBQcm9wcycpO1xuICBjb25zdCBtb2RhbCA9IHN0b3JlLnVzZVN0YXRlKCdtb2RhbCcpO1xuICBjb25zdCBtb3VudGVkID0gc3RvcmUudXNlU3RhdGUoJ21vdW50ZWQnKTtcbiAgY29uc3QgbmVzdGVkID0gc3RvcmUudXNlU3RhdGUoJ25lc3RlZCcpO1xuICBjb25zdCBuZXN0ZWRPcGVuRGlhbG9nQ291bnQgPSBzdG9yZS51c2VTdGF0ZSgnbmVzdGVkT3BlbkRpYWxvZ0NvdW50Jyk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBvcGVuTWV0aG9kID0gc3RvcmUudXNlU3RhdGUoJ29wZW5NZXRob2QnKTtcbiAgY29uc3QgdGl0bGVFbGVtZW50SWQgPSBzdG9yZS51c2VTdGF0ZSgndGl0bGVFbGVtZW50SWQnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IHJvbGUgPSBzdG9yZS51c2VTdGF0ZSgncm9sZScpO1xuICBjb25zdCBmbG9hdGluZ0lkID0gZmxvYXRpbmdSb290Q29udGV4dC51c2VTdGF0ZSgnZmxvYXRpbmdJZCcpO1xuICB1c2VEaWFsb2dQb3J0YWxDb250ZXh0KCk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgb3BlbixcbiAgICByZWY6IHN0b3JlLmNvbnRleHQucG9wdXBSZWYsXG4gICAgb25Db21wbGV0ZSgpIHtcbiAgICAgIGlmIChvcGVuKSB7XG4gICAgICAgIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlQ29tcGxldGU/Lih0cnVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICBjb25zdCByZXNvbHZlZEluaXRpYWxGb2N1cyA9IGluaXRpYWxGb2N1cyA9PT0gdW5kZWZpbmVkID8gY3JlYXRlRGVmYXVsdEluaXRpYWxGb2N1cyhzdG9yZS5jb250ZXh0LnBvcHVwUmVmKSA6IGluaXRpYWxGb2N1cztcbiAgY29uc3QgbmVzdGVkRGlhbG9nT3BlbiA9IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA+IDA7XG4gIGNvbnN0IHNldFBvcHVwRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCdwb3B1cEVsZW1lbnQnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICBuZXN0ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBuZXN0ZWREaWFsb2dPcGVuXG4gIH07XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHByb3BzOiBbcm9vdFBvcHVwUHJvcHMsIHtcbiAgICAgIGlkOiBmbG9hdGluZ0lkLFxuICAgICAgJ2FyaWEtbGFiZWxsZWRieSc6IHRpdGxlRWxlbWVudElkLFxuICAgICAgJ2FyaWEtZGVzY3JpYmVkYnknOiBkZXNjcmlwdGlvbkVsZW1lbnRJZCxcbiAgICAgIHJvbGUsXG4gICAgICAuLi5GT0NVU0FCTEVfUE9QVVBfUFJPUFMsXG4gICAgICBoaWRkZW46ICFtb3VudGVkLFxuICAgICAgb25LZXlEb3duKGV2ZW50KSB7XG4gICAgICAgIGlmIChDT01QT1NJVEVfS0VZUy5oYXMoZXZlbnQua2V5KSkge1xuICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgc3R5bGU6IHtcbiAgICAgICAgJy0tbmVzdGVkLWRpYWxvZ3MnOiBuZXN0ZWRPcGVuRGlhbG9nQ291bnRcbiAgICAgIH1cbiAgICB9LCBlbGVtZW50UHJvcHNdLFxuICAgIHJlZjogW2ZvcndhcmRlZFJlZiwgc3RvcmUuY29udGV4dC5wb3B1cFJlZiwgc2V0UG9wdXBFbGVtZW50XSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBkaWFsb2dTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nXG4gIH0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goRmxvYXRpbmdGb2N1c01hbmFnZXIsIHtcbiAgICBjb250ZXh0OiBmbG9hdGluZ1Jvb3RDb250ZXh0LFxuICAgIG9wZW5JbnRlcmFjdGlvblR5cGU6IG9wZW5NZXRob2QsXG4gICAgZGlzYWJsZWQ6ICFtb3VudGVkLFxuICAgIGNsb3NlT25Gb2N1c091dDogIWRpc2FibGVQb2ludGVyRGlzbWlzc2FsLFxuICAgIGluaXRpYWxGb2N1czogcmVzb2x2ZWRJbml0aWFsRm9jdXMsXG4gICAgcmV0dXJuRm9jdXM6IGZpbmFsRm9jdXMsXG4gICAgbW9kYWw6IG1vZGFsICE9PSBmYWxzZSxcbiAgICByZXN0b3JlRm9jdXM6IFwicG9wdXBcIixcbiAgICBjaGlsZHJlbjogZWxlbWVudFxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nUG9wdXAuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1BvcHVwXCI7IiwiaW1wb3J0IHsgaXNSZWFjdFZlcnNpb25BdExlYXN0IH0gZnJvbSBcIi4vcmVhY3RWZXJzaW9uLm1qc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIGluZXJ0VmFsdWUodmFsdWUpIHtcbiAgaWYgKGlzUmVhY3RWZXJzaW9uQXRMZWFzdCgxOSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgLy8gY29tcGF0aWJpbGl0eSB3aXRoIFJlYWN0IDwgMTlcbiAgcmV0dXJuIHZhbHVlID8gJ3RydWUnIDogdW5kZWZpbmVkO1xufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBJbnRlcm5hbEJhY2tkcm9wID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gSW50ZXJuYWxCYWNrZHJvcChwcm9wcywgcmVmKSB7XG4gIGNvbnN0IHtcbiAgICBjdXRvdXQsXG4gICAgLi4ub3RoZXJQcm9wc1xuICB9ID0gcHJvcHM7XG4gIGxldCBjbGlwUGF0aDtcbiAgaWYgKGN1dG91dCkge1xuICAgIGNvbnN0IHJlY3QgPSBjdXRvdXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY2xpcFBhdGggPSBgcG9seWdvbigwJSAwJSwxMDAlIDAlLDEwMCUgMTAwJSwwJSAxMDAlLDAlIDAlLCR7cmVjdC5sZWZ0fXB4ICR7cmVjdC50b3B9cHgsJHtyZWN0LmxlZnR9cHggJHtyZWN0LmJvdHRvbX1weCwke3JlY3QucmlnaHR9cHggJHtyZWN0LmJvdHRvbX1weCwke3JlY3QucmlnaHR9cHggJHtyZWN0LnRvcH1weCwke3JlY3QubGVmdH1weCAke3JlY3QudG9wfXB4KWA7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFwiZGl2XCIsIHtcbiAgICByZWY6IHJlZixcbiAgICByb2xlOiBcInByZXNlbnRhdGlvblwiXG4gICAgLy8gRW5zdXJlcyBGbG9hdGluZyBVSSdzIG91dHNpZGUgcHJlc3MgZGV0ZWN0aW9uIHJ1bnMsIGFzIGl0IGNvbnNpZGVyc1xuICAgIC8vIGl0IGFuIGVsZW1lbnQgdGhhdCBleGlzdGVkIHdoZW4gdGhlIHBvcHVwIHJlbmRlcmVkLlxuICAgICxcbiAgICBcImRhdGEtYmFzZS11aS1pbmVydFwiOiBcIlwiLFxuICAgIC4uLm90aGVyUHJvcHMsXG4gICAgc3R5bGU6IHtcbiAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgaW5zZXQ6IDAsXG4gICAgICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICBXZWJraXRVc2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICBjbGlwUGF0aFxuICAgIH1cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEludGVybmFsQmFja2Ryb3AuZGlzcGxheU5hbWUgPSBcIkludGVybmFsQmFja2Ryb3BcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGluZXJ0VmFsdWUgfSBmcm9tICdAYmFzZS11aS91dGlscy9pbmVydFZhbHVlJztcbmltcG9ydCB7IEZsb2F0aW5nUG9ydGFsIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IERpYWxvZ1BvcnRhbENvbnRleHQgfSBmcm9tIFwiLi9EaWFsb2dQb3J0YWxDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgSW50ZXJuYWxCYWNrZHJvcCB9IGZyb20gXCIuLi8uLi91dGlscy9JbnRlcm5hbEJhY2tkcm9wLm1qc1wiO1xuXG4vKipcbiAqIEEgcG9ydGFsIGVsZW1lbnQgdGhhdCBtb3ZlcyB0aGUgcG9wdXAgdG8gYSBkaWZmZXJlbnQgcGFydCBvZiB0aGUgRE9NLlxuICogQnkgZGVmYXVsdCwgdGhlIHBvcnRhbCBlbGVtZW50IGlzIGFwcGVuZGVkIHRvIGA8Ym9keT5gLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgRGlhbG9nUG9ydGFsID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nUG9ydGFsKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGtlZXBNb3VudGVkID0gZmFsc2UsXG4gICAgLi4ucG9ydGFsUHJvcHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBtb2RhbCA9IHN0b3JlLnVzZVN0YXRlKCdtb2RhbCcpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3Qgc2hvdWxkUmVuZGVyID0gbW91bnRlZCB8fCBrZWVwTW91bnRlZDtcbiAgaWYgKCFzaG91bGRSZW5kZXIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goRGlhbG9nUG9ydGFsQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBrZWVwTW91bnRlZCxcbiAgICBjaGlsZHJlbjogLyojX19QVVJFX18qL19qc3hzKEZsb2F0aW5nUG9ydGFsLCB7XG4gICAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAgIC4uLnBvcnRhbFByb3BzLFxuICAgICAgY2hpbGRyZW46IFttb3VudGVkICYmIG1vZGFsID09PSB0cnVlICYmIC8qI19fUFVSRV9fKi9fanN4KEludGVybmFsQmFja2Ryb3AsIHtcbiAgICAgICAgcmVmOiBzdG9yZS5jb250ZXh0LmludGVybmFsQmFja2Ryb3BSZWYsXG4gICAgICAgIGluZXJ0OiBpbmVydFZhbHVlKCFvcGVuKVxuICAgICAgfSksIHByb3BzLmNoaWxkcmVuXVxuICAgIH0pXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dQb3J0YWwuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1BvcnRhbFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQmFzZVVpSWQubWpzXCI7XG4vKipcbiAqIEEgaGVhZGluZyB0aGF0IGxhYmVscyB0aGUgZGlhbG9nLlxuICogUmVuZGVycyBhbiBgPGgyPmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dUaXRsZSA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ1RpdGxlKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgaWQ6IGlkUHJvcCxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IGlkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgc3RvcmUudXNlU3luY2VkVmFsdWVXaXRoQ2xlYW51cCgndGl0bGVFbGVtZW50SWQnLCBpZCk7XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdoMicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgcHJvcHM6IFt7XG4gICAgICBpZFxuICAgIH0sIGVsZW1lbnRQcm9wc11cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ1RpdGxlLmRpc3BsYXlOYW1lID0gXCJEaWFsb2dUaXRsZVwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuLyoqXG4gKiBQcm92aWRlcyBhIGNyb3NzLWJyb3dzZXIgd2F5IHRvIGRldGVybWluZSB0aGUgdHlwZSBvZiB0aGUgcG9pbnRlciB1c2VkIHRvIGNsaWNrLlxuICogU2FmYXJpIGFuZCBGaXJlZm94IGRvIG5vdCBwcm92aWRlIHRoZSBQb2ludGVyRXZlbnQgdG8gdGhlIGNsaWNrIGhhbmRsZXIgKHRoZXkgdXNlIE1vdXNlRXZlbnQpIHlldC5cbiAqIEFkZGl0aW9uYWxseSwgdGhpcyBpbXBsZW1lbnRhdGlvbiBkZXRlY3RzIGlmIHRoZSBjbGljayB3YXMgdHJpZ2dlcmVkIGJ5IHRoZSBrZXlib2FyZC5cbiAqXG4gKiBAcGFyYW0gaGFuZGxlciBUaGUgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIHdoZW4gdGhlIGJ1dHRvbiBpcyBjbGlja2VkLiBUaGUgZmlyc3QgcGFyYW1ldGVyIGlzIHRoZSBvcmlnaW5hbCBldmVudCBhbmQgdGhlIHNlY29uZCBwYXJhbWV0ZXIgaXMgdGhlIHBvaW50ZXIgdHlwZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUVuaGFuY2VkQ2xpY2tIYW5kbGVyKGhhbmRsZXIpIHtcbiAgY29uc3QgbGFzdENsaWNrSW50ZXJhY3Rpb25UeXBlUmVmID0gUmVhY3QudXNlUmVmKCcnKTtcbiAgY29uc3QgaGFuZGxlUG9pbnRlckRvd24gPSBSZWFjdC51c2VDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbGFzdENsaWNrSW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgPSBldmVudC5wb2ludGVyVHlwZTtcbiAgICBoYW5kbGVyKGV2ZW50LCBldmVudC5wb2ludGVyVHlwZSk7XG4gIH0sIFtoYW5kbGVyXSk7XG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gUmVhY3QudXNlQ2FsbGJhY2soZXZlbnQgPT4ge1xuICAgIC8vIGV2ZW50LmRldGFpbCBoYXMgdGhlIG51bWJlciBvZiBjbGlja3MgcGVyZm9ybWVkIG9uIHRoZSBlbGVtZW50LiAwIG1lYW5zIGl0IHdhcyB0cmlnZ2VyZWQgYnkgdGhlIGtleWJvYXJkLlxuICAgIGlmIChldmVudC5kZXRhaWwgPT09IDApIHtcbiAgICAgIGhhbmRsZXIoZXZlbnQsICdrZXlib2FyZCcpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoJ3BvaW50ZXJUeXBlJyBpbiBldmVudCkge1xuICAgICAgLy8gQ2hyb21lIGFuZCBFZGdlIGNvcnJlY3RseSB1c2UgUG9pbnRlckV2ZW50XG4gICAgICBoYW5kbGVyKGV2ZW50LCBldmVudC5wb2ludGVyVHlwZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGhhbmRsZXIoZXZlbnQsIGxhc3RDbGlja0ludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50KTtcbiAgICB9XG4gICAgbGFzdENsaWNrSW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgPSAnJztcbiAgfSwgW2hhbmRsZXJdKTtcbiAgcmV0dXJuIHtcbiAgICBvbkNsaWNrOiBoYW5kbGVDbGljayxcbiAgICBvblBvaW50ZXJEb3duOiBoYW5kbGVQb2ludGVyRG93blxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VFbmhhbmNlZENsaWNrSGFuZGxlciB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUVuaGFuY2VkQ2xpY2tIYW5kbGVyJztcbmltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0nO1xuaW1wb3J0IHsgdXNlVmFsdWVDaGFuZ2VkIH0gZnJvbSBcIi4uL2ludGVybmFscy91c2VWYWx1ZUNoYW5nZWQubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlT3Blbk1ldGhvZFRyaWdnZXJQcm9wcyhvcGVuLCBzZXRPcGVuTWV0aG9kKSB7XG4gIGNvbnN0IGhhbmRsZVRyaWdnZXJDbGljayA9IHVzZVN0YWJsZUNhbGxiYWNrKChfLCBpbnRlcmFjdGlvblR5cGUpID0+IHtcbiAgICBjb25zdCBpc09wZW4gPSB0eXBlb2Ygb3BlbiA9PT0gJ2Z1bmN0aW9uJyA/IG9wZW4oKSA6IG9wZW47XG4gICAgaWYgKCFpc09wZW4pIHtcbiAgICAgIHNldE9wZW5NZXRob2QoaW50ZXJhY3Rpb25UeXBlIHx8IChcbiAgICAgIC8vIE9uIGlPUyBTYWZhcmksIHRoZSBoaXRzbG9wIGFyb3VuZCB0b3VjaCB0YXJnZXRzIG1lYW5zIHRhcHBpbmcgb3V0c2lkZSBhbiBlbGVtZW50J3NcbiAgICAgIC8vIGJvdW5kcyBkb2VzIG5vdCBmaXJlIGBwb2ludGVyZG93bmAgYnV0IGRvZXMgZmlyZSBgbW91c2Vkb3duYC4gVGhlIGBpbnRlcmFjdGlvblR5cGVgXG4gICAgICAvLyB3aWxsIGJlIFwiXCIgaW4gdGhhdCBjYXNlLlxuICAgICAgcGxhdGZvcm0ub3MuaW9zID8gJ3RvdWNoJyA6ICcnKSk7XG4gICAgfVxuICB9KTtcbiAgY29uc3Qge1xuICAgIG9uQ2xpY2ssXG4gICAgb25Qb2ludGVyRG93blxuICB9ID0gdXNlRW5oYW5jZWRDbGlja0hhbmRsZXIoaGFuZGxlVHJpZ2dlckNsaWNrKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBvbkNsaWNrLFxuICAgIG9uUG9pbnRlckRvd25cbiAgfSksIFtvbkNsaWNrLCBvblBvaW50ZXJEb3duXSk7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB0aGUgaW50ZXJhY3Rpb24gdHlwZSAoa2V5Ym9hcmQsIG1vdXNlLCB0b3VjaCwgZXRjLikgdGhhdCBvcGVuZWQgdGhlIGNvbXBvbmVudC5cbiAqXG4gKiBAcGFyYW0gb3BlbiBUaGUgb3BlbiBzdGF0ZSBvZiB0aGUgY29tcG9uZW50LlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlT3BlbkludGVyYWN0aW9uVHlwZShvcGVuKSB7XG4gIGNvbnN0IFtvcGVuTWV0aG9kLCBzZXRPcGVuTWV0aG9kXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCB0cmlnZ2VyUHJvcHMgPSB1c2VPcGVuTWV0aG9kVHJpZ2dlclByb3BzKG9wZW4sIHNldE9wZW5NZXRob2QpO1xuICB1c2VWYWx1ZUNoYW5nZWQob3BlbiwgcHJldmlvdXNPcGVuID0+IHtcbiAgICBpZiAocHJldmlvdXNPcGVuICYmICFvcGVuKSB7XG4gICAgICBzZXRPcGVuTWV0aG9kKG51bGwpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgb3Blbk1ldGhvZCxcbiAgICB0cmlnZ2VyUHJvcHNcbiAgfSksIFtvcGVuTWV0aG9kLCB0cmlnZ2VyUHJvcHNdKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vdXNlQnV0dG9uLm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHRyaWdnZXJPcGVuU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgQ0xJQ0tfVFJJR0dFUl9JREVOVElGSUVSIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyB1c2VQb3B1cEhhbmRsZVN0b3JlLCB1c2VUcmlnZ2VyRGF0YUZvcndhcmRpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuaW1wb3J0IHsgdXNlQ2xpY2sgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuTWV0aG9kVHJpZ2dlclByb3BzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3VzZU9wZW5JbnRlcmFjdGlvblR5cGUubWpzXCI7XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBvcGVucyB0aGUgZGlhbG9nLlxuICogUmVuZGVycyBhIGA8YnV0dG9uPmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dUcmlnZ2VyID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nVHJpZ2dlcihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgbmF0aXZlQnV0dG9uID0gdHJ1ZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIHBheWxvYWQsXG4gICAgaGFuZGxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IGRpYWxvZ1Jvb3RTdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KHRydWUpO1xuICBjb25zdCBoYW5kbGVTdG9yZSA9IHVzZVBvcHVwSGFuZGxlU3RvcmUoaGFuZGxlKTtcbiAgY29uc3Qgc3RvcmUgPSBoYW5kbGVTdG9yZSA/PyBkaWFsb2dSb290U3RvcmU7XG4gIGlmICghc3RvcmUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IDxEaWFsb2cuVHJpZ2dlcj4gbXVzdCBiZSB1c2VkIHdpdGhpbiA8RGlhbG9nLlJvb3Q+IG9yIHByb3ZpZGVkIHdpdGggYSBoYW5kbGUuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoNzkpKTtcbiAgfVxuICBjb25zdCB0aGlzVHJpZ2dlcklkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgY29uc3QgZmxvYXRpbmdDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3QgaXNPcGVuZWRCeVRoaXNUcmlnZ2VyID0gc3RvcmUudXNlU3RhdGUoJ2lzT3BlbmVkQnlUcmlnZ2VyJywgdGhpc1RyaWdnZXJJZCk7XG4gIGNvbnN0IHBvcHVwSWQgPSBzdG9yZS51c2VTdGF0ZSgndHJpZ2dlclBvcHVwSWQnLCB0aGlzVHJpZ2dlcklkKTtcbiAgY29uc3QgdHJpZ2dlckVsZW1lbnRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHtcbiAgICByZWdpc3RlclRyaWdnZXIsXG4gICAgaXNNb3VudGVkQnlUaGlzVHJpZ2dlclxuICB9ID0gdXNlVHJpZ2dlckRhdGFGb3J3YXJkaW5nKHRoaXNUcmlnZ2VySWQsIHRyaWdnZXJFbGVtZW50UmVmLCBzdG9yZSwge1xuICAgIHBheWxvYWRcbiAgfSk7XG4gIGNvbnN0IHtcbiAgICBnZXRCdXR0b25Qcm9wcyxcbiAgICBidXR0b25SZWZcbiAgfSA9IHVzZUJ1dHRvbih7XG4gICAgZGlzYWJsZWQsXG4gICAgbmF0aXZlOiBuYXRpdmVCdXR0b25cbiAgfSk7XG4gIGNvbnN0IGNsaWNrID0gdXNlQ2xpY2soZmxvYXRpbmdDb250ZXh0KTtcbiAgY29uc3QgaW50ZXJhY3Rpb25UeXBlUHJvcHMgPSB1c2VPcGVuTWV0aG9kVHJpZ2dlclByb3BzKCgpID0+IHN0b3JlLnNlbGVjdCgnb3BlbicpLCBpbnRlcmFjdGlvblR5cGUgPT4ge1xuICAgIHN0b3JlLnNldCgnb3Blbk1ldGhvZCcsIGludGVyYWN0aW9uVHlwZSk7XG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBkaXNhYmxlZCxcbiAgICBvcGVuOiBpc09wZW5lZEJ5VGhpc1RyaWdnZXJcbiAgfTtcbiAgY29uc3Qgcm9vdFRyaWdnZXJQcm9wcyA9IHN0b3JlLnVzZVN0YXRlKCd0cmlnZ2VyUHJvcHMnLCBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2J1dHRvbicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBbYnV0dG9uUmVmLCBmb3J3YXJkZWRSZWYsIHJlZ2lzdGVyVHJpZ2dlciwgdHJpZ2dlckVsZW1lbnRSZWZdLFxuICAgIHByb3BzOiBbY2xpY2sucmVmZXJlbmNlLCByb290VHJpZ2dlclByb3BzLCBpbnRlcmFjdGlvblR5cGVQcm9wcywge1xuICAgICAgW0NMSUNLX1RSSUdHRVJfSURFTlRJRklFUl06ICcnLFxuICAgICAgaWQ6IHRoaXNUcmlnZ2VySWQsXG4gICAgICAnYXJpYS1oYXNwb3B1cCc6ICdkaWFsb2cnLFxuICAgICAgJ2FyaWEtZXhwYW5kZWQnOiBpc09wZW5lZEJ5VGhpc1RyaWdnZXIsXG4gICAgICAnYXJpYS1jb250cm9scyc6IHBvcHVwSWRcbiAgICB9LCBlbGVtZW50UHJvcHMsIGdldEJ1dHRvblByb3BzXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiB0cmlnZ2VyT3BlblN0YXRlTWFwcGluZ1xuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nVHJpZ2dlci5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nVHJpZ2dlclwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgRGlhbG9nVHJpZ2dlciB9IGZyb20gXCIuLi8uLi9kaWFsb2cvdHJpZ2dlci9EaWFsb2dUcmlnZ2VyLm1qc1wiO1xuLyoqXG4gKiBBIGJ1dHRvbiB0aGF0IG9wZW5zIHRoZSBhbGVydCBkaWFsb2cuXG4gKiBSZW5kZXJzIGEgYDxidXR0b24+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIEFsZXJ0IERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2FsZXJ0LWRpYWxvZylcbiAqL1xuZXhwb3J0IGNvbnN0IEFsZXJ0RGlhbG9nVHJpZ2dlciA9IERpYWxvZ1RyaWdnZXI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZURpYWxvZ1BvcnRhbENvbnRleHQgfSBmcm9tIFwiLi4vcG9ydGFsL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBkaWFsb2dTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nIH0gZnJvbSBcIi4uL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogQSBwb3NpdGlvbmluZyBjb250YWluZXIgZm9yIHRoZSBkaWFsb2cgcG9wdXAgdGhhdCBjYW4gYmUgbWFkZSBzY3JvbGxhYmxlLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dWaWV3cG9ydCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ1ZpZXdwb3J0KGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgY2hpbGRyZW4sXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qga2VlcE1vdW50ZWQgPSB1c2VEaWFsb2dQb3J0YWxDb250ZXh0KCk7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG5lc3RlZCA9IHN0b3JlLnVzZVN0YXRlKCduZXN0ZWQnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA9IHN0b3JlLnVzZVN0YXRlKCduZXN0ZWRPcGVuRGlhbG9nQ291bnQnKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHNldFZpZXdwb3J0RWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCd2aWV3cG9ydEVsZW1lbnQnKTtcbiAgY29uc3QgbmVzdGVkRGlhbG9nT3BlbiA9IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA+IDA7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIG9wZW4sXG4gICAgbmVzdGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgbmVzdGVkRGlhbG9nT3BlblxuICB9O1xuICBjb25zdCBzaG91bGRSZW5kZXIgPSBrZWVwTW91bnRlZCB8fCBtb3VudGVkO1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBlbmFibGVkOiBzaG91bGRSZW5kZXIsXG4gICAgc3RhdGUsXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBzZXRWaWV3cG9ydEVsZW1lbnRdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmc6IGRpYWxvZ1N0YXRlQXR0cmlidXRlc01hcHBpbmcsXG4gICAgcHJvcHM6IFt7XG4gICAgICByb2xlOiAncHJlc2VudGF0aW9uJyxcbiAgICAgIGhpZGRlbjogIW1vdW50ZWQsXG4gICAgICBzdHlsZToge1xuICAgICAgICBwb2ludGVyRXZlbnRzOiAhb3BlbiA/ICdub25lJyA6IHVuZGVmaW5lZFxuICAgICAgfSxcbiAgICAgIGNoaWxkcmVuXG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nVmlld3BvcnQuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1ZpZXdwb3J0XCI7IiwiaW1wb3J0IHsgY3JlYXRlTnVsbERpYWxvZ1N0b3JlIH0gZnJvbSBcIi4vRGlhbG9nU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyBCYXNlUG9wdXBIYW5kbGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL3BvcHVwSGFuZGxlLm1qc1wiO1xuXG4vKipcbiAqIENvbnRyb2xzIGEgRGlhbG9nIGltcGVyYXRpdmVseSBhbmQgYXNzb2NpYXRlcyBkZXRhY2hlZCBgRGlhbG9nLlRyaWdnZXJgIGNvbXBvbmVudHMgd2l0aCBhXG4gKiBgRGlhbG9nLlJvb3RgLiBDcmVhdGUgb25lIHdpdGggYERpYWxvZy5jcmVhdGVIYW5kbGUoKWAgYW5kIHBhc3MgaXQgdG8gdGhlIGBoYW5kbGVgIHByb3Agb2YgdGhlXG4gKiByb290IGFuZCBvZiBhbnkgdHJpZ2dlcnMgcmVuZGVyZWQgb3V0c2lkZSBvZiBpdC5cbiAqXG4gKiBUaGUgaW1wZXJhdGl2ZSBtZXRob2RzIHRha2UgZWZmZWN0IG9ubHkgd2hpbGUgYSByb290IHVzaW5nIHRoaXMgaGFuZGxlIGlzIG1vdW50ZWQ7IGNhbGxzIG1hZGVcbiAqIGJlZm9yZSBhIHJvb3QgYXR0YWNoZXMgKG9yIGFmdGVyIGl0IHVubW91bnRzKSBhcmUgaWdub3JlZC5cbiAqL1xuZXhwb3J0IGNsYXNzIERpYWxvZ0hhbmRsZSBleHRlbmRzIEJhc2VQb3B1cEhhbmRsZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKGNyZWF0ZU51bGxEaWFsb2dTdG9yZSgpLCAnRGlhbG9nJywgZmFsc2UpO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIHRoZSBkaWFsb2csIG9wdGlvbmFsbHkgYXNzb2NpYXRpbmcgaXQgd2l0aCBhIHRyaWdnZXIuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKlxuICAgKiBAcGFyYW0gdHJpZ2dlcklkIElEIG9mIHRoZSB0cmlnZ2VyIHRvIGFzc29jaWF0ZSB3aXRoIHRoZSBkaWFsb2cuIFRoZSB0cmlnZ2VyIG11c3QgYmUgYSBtYXRjaGluZ1xuICAgKiBgRGlhbG9nLlRyaWdnZXJgIHdpdGggdGhpcyBoYW5kbGUgcGFzc2VkIGFzIGEgcHJvcC4gUGFzcyBgbnVsbGAgdG8gb3BlbiB3aXRob3V0IGFzc29jaWF0aW5nIGFueSB0cmlnZ2VyLlxuICAgKi9cbiAgb3Blbih0cmlnZ2VySWQpIHtcbiAgICB0aGlzLm9wZW5CeVRyaWdnZXIodHJpZ2dlcklkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyB0aGUgZGlhbG9nIHdpdGggdGhlIGdpdmVuIHBheWxvYWQsIHdpdGhvdXQgYXNzb2NpYXRpbmcgaXQgd2l0aCBhbnkgdHJpZ2dlci5cbiAgICpcbiAgICogVGhpcyBtZXRob2Qgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGluIGFuIGV2ZW50IGhhbmRsZXIgb3IgYW4gZWZmZWN0IChub3QgZHVyaW5nIHJlbmRlcmluZykuXG4gICAqXG4gICAqIEBwYXJhbSBwYXlsb2FkIFBheWxvYWQgdG8gc2V0IHdoZW4gb3BlbmluZyB0aGUgZGlhbG9nLiBJdCBpcyBleHBvc2VkIHRvIHRoZSByb290J3MgcmVuZGVyLXByb3AgY2hpbGRyZW4uXG4gICAqL1xuICBvcGVuV2l0aFBheWxvYWQocGF5bG9hZCkge1xuICAgIGNvbnN0IGF0dGFjaGVkU3RvcmUgPSB0aGlzLmF0dGFjaGVkU3RvcmU7XG4gICAgaWYgKGF0dGFjaGVkU3RvcmUgPT09IG51bGwpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignQmFzZSBVSTogRGlhbG9nSGFuZGxlLm9wZW5XaXRoUGF5bG9hZCgpIHdhcyBjYWxsZWQgd2hpbGUgbm8gcm9vdCB1c2luZyB0aGlzIGhhbmRsZSBpcyBtb3VudGVkLiAnICsgJ1RoZSBjYWxsIGFuZCBpdHMgcGF5bG9hZCB3ZXJlIGlnbm9yZWQ7IG1vdW50IGEgcm9vdCB3aXRoIHRoaXMgaGFuZGxlIGJlZm9yZSBvcGVuaW5nIGl0IGltcGVyYXRpdmVseS4nKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXR0YWNoZWRTdG9yZS5zZXQoJ3BheWxvYWQnLCBwYXlsb2FkKTtcbiAgICBhdHRhY2hlZFN0b3JlLnNldE9wZW4odHJ1ZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbikpO1xuICB9XG5cbiAgLyoqXG4gICAqIENsb3NlcyB0aGUgZGlhbG9nLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBzaG91bGQgb25seSBiZSBjYWxsZWQgaW4gYW4gZXZlbnQgaGFuZGxlciBvciBhbiBlZmZlY3QgKG5vdCBkdXJpbmcgcmVuZGVyaW5nKS5cbiAgICovXG4gIGNsb3NlKCkge1xuICAgIHRoaXMuY2xvc2VQb3B1cCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGRpYWxvZyBpcyBjdXJyZW50bHkgb3Blbi4gUmV0dXJucyBgZmFsc2VgIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQgdG8gdGhlIGhhbmRsZS5cbiAgICovXG4gIGdldCBpc09wZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMuYXR0YWNoZWRTdG9yZT8uc2VsZWN0KCdvcGVuJykgPz8gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IGhhbmRsZSB0byBjb25uZWN0IGEgRGlhbG9nLlJvb3Qgd2l0aCBkZXRhY2hlZCBEaWFsb2cuVHJpZ2dlciBjb21wb25lbnRzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRGlhbG9nSGFuZGxlKCkge1xuICByZXR1cm4gbmV3IERpYWxvZ0hhbmRsZSgpO1xufSIsImltcG9ydCB7IERpYWxvZ0hhbmRsZSB9IGZyb20gXCIuLi9kaWFsb2cvc3RvcmUvRGlhbG9nSGFuZGxlLm1qc1wiO1xuXG4vKipcbiAqIENvbnRyb2xzIGFuIEFsZXJ0IERpYWxvZyBpbXBlcmF0aXZlbHkgYW5kIGFzc29jaWF0ZXMgZGV0YWNoZWQgYEFsZXJ0RGlhbG9nLlRyaWdnZXJgIGNvbXBvbmVudHMgd2l0aFxuICogYW4gYEFsZXJ0RGlhbG9nLlJvb3RgLiBDcmVhdGUgb25lIHdpdGggYEFsZXJ0RGlhbG9nLmNyZWF0ZUhhbmRsZSgpYCBhbmQgcGFzcyBpdCB0byB0aGUgYGhhbmRsZWBcbiAqIHByb3Agb2YgdGhlIHJvb3QgYW5kIG9mIGFueSB0cmlnZ2VycyByZW5kZXJlZCBvdXRzaWRlIG9mIGl0LlxuICpcbiAqIFRoZSBpbXBlcmF0aXZlIG1ldGhvZHMgdGFrZSBlZmZlY3Qgb25seSB3aGlsZSBhIHJvb3QgdXNpbmcgdGhpcyBoYW5kbGUgaXMgbW91bnRlZDsgY2FsbHMgbWFkZVxuICogYmVmb3JlIGEgcm9vdCBhdHRhY2hlcyAob3IgYWZ0ZXIgaXQgdW5tb3VudHMpIGFyZSBpZ25vcmVkLlxuICovXG5leHBvcnQgY2xhc3MgQWxlcnREaWFsb2dIYW5kbGUgZXh0ZW5kcyBEaWFsb2dIYW5kbGUge31cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IGhhbmRsZSB0byBjb25uZWN0IGFuIEFsZXJ0RGlhbG9nLlJvb3Qgd2l0aCBkZXRhY2hlZCBBbGVydERpYWxvZy5UcmlnZ2VyIGNvbXBvbmVudHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVBbGVydERpYWxvZ0hhbmRsZSgpIHtcbiAgcmV0dXJuIG5ldyBBbGVydERpYWxvZ0hhbmRsZSgpO1xufSJdLCJmaWxlIjoiQzovVXNlcnMvVXNlci9EZXNrdG9wL3N0dWRlbnRwcmVwL2Zyb250ZW5kL25vZGVfbW9kdWxlcy8udml0ZS9kZXBzL0BiYXNlLXVpX3JlYWN0X2FsZXJ0LWRpYWxvZy5qcyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyLDUzLDU0LDU1LDU2LDU3LDU4LDU5LDYwLDYxLDYyLDYzLDY0LDY1LDY2XX0=