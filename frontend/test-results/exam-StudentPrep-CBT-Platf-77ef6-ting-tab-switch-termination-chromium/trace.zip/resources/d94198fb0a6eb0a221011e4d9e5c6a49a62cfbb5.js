import { r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=076f3cfd";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=cdd924ad";
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-with-selector.development.js
/**
* @license React
* use-sync-external-store-with-selector.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_with_selector_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is, useSyncExternalStore = React.useSyncExternalStore, useRef = React.useRef, useEffect = React.useEffect, useMemo = React.useMemo, useDebugValue = React.useDebugValue;
		exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
			var instRef = useRef(null);
			if (null === instRef.current) {
				var inst = {
					hasValue: !1,
					value: null
				};
				instRef.current = inst;
			} else inst = instRef.current;
			instRef = useMemo(function() {
				function memoizedSelector(nextSnapshot) {
					if (!hasMemo) {
						hasMemo = !0;
						memoizedSnapshot = nextSnapshot;
						nextSnapshot = selector(nextSnapshot);
						if (void 0 !== isEqual && inst.hasValue) {
							var currentSelection = inst.value;
							if (isEqual(currentSelection, nextSnapshot)) return memoizedSelection = currentSelection;
						}
						return memoizedSelection = nextSnapshot;
					}
					currentSelection = memoizedSelection;
					if (objectIs(memoizedSnapshot, nextSnapshot)) return currentSelection;
					var nextSelection = selector(nextSnapshot);
					if (void 0 !== isEqual && isEqual(currentSelection, nextSelection)) return memoizedSnapshot = nextSnapshot, currentSelection;
					memoizedSnapshot = nextSnapshot;
					return memoizedSelection = nextSelection;
				}
				var hasMemo = !1, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
				return [function() {
					return memoizedSelector(getSnapshot());
				}, null === maybeGetServerSnapshot ? void 0 : function() {
					return memoizedSelector(maybeGetServerSnapshot());
				}];
			}, [
				getSnapshot,
				getServerSnapshot,
				selector,
				isEqual
			]);
			var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
			useEffect(function() {
				inst.hasValue = !0;
				inst.value = value;
			}, [value]);
			useDebugValue(value);
			return value;
		};
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/use-sync-external-store/with-selector.js
var require_with_selector = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_use_sync_external_store_with_selector_development();
}));
//#endregion
//#region node_modules/react-redux/dist/react-redux.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_with_selector = require_with_selector();
var IS_REACT_19 = /* @__PURE__ */ "19.2.8".startsWith("19");
var REACT_ELEMENT_TYPE = /* @__PURE__ */ Symbol.for(IS_REACT_19 ? "react.transitional.element" : "react.element");
var REACT_PORTAL_TYPE = /* @__PURE__ */ Symbol.for("react.portal");
var REACT_FRAGMENT_TYPE = /* @__PURE__ */ Symbol.for("react.fragment");
var REACT_STRICT_MODE_TYPE = /* @__PURE__ */ Symbol.for("react.strict_mode");
var REACT_PROFILER_TYPE = /* @__PURE__ */ Symbol.for("react.profiler");
var REACT_CONSUMER_TYPE = /* @__PURE__ */ Symbol.for("react.consumer");
var REACT_CONTEXT_TYPE = /* @__PURE__ */ Symbol.for("react.context");
var REACT_FORWARD_REF_TYPE = /* @__PURE__ */ Symbol.for("react.forward_ref");
var REACT_SUSPENSE_TYPE = /* @__PURE__ */ Symbol.for("react.suspense");
var REACT_SUSPENSE_LIST_TYPE = /* @__PURE__ */ Symbol.for("react.suspense_list");
var REACT_MEMO_TYPE = /* @__PURE__ */ Symbol.for("react.memo");
var REACT_LAZY_TYPE = /* @__PURE__ */ Symbol.for("react.lazy");
var REACT_OFFSCREEN_TYPE = /* @__PURE__ */ Symbol.for("react.offscreen");
var REACT_CLIENT_REFERENCE = /* @__PURE__ */ Symbol.for("react.client.reference");
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Memo = REACT_MEMO_TYPE;
function isValidElementType(type) {
	return typeof type === "string" || typeof type === "function" || type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || type === REACT_OFFSCREEN_TYPE || typeof type === "object" && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_CONSUMER_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_CLIENT_REFERENCE || type.getModuleId !== void 0) ? true : false;
}
function typeOf(object) {
	if (typeof object === "object" && object !== null) {
		const { $$typeof } = object;
		switch ($$typeof) {
			case REACT_ELEMENT_TYPE: switch (object = object.type, object) {
				case REACT_FRAGMENT_TYPE:
				case REACT_PROFILER_TYPE:
				case REACT_STRICT_MODE_TYPE:
				case REACT_SUSPENSE_TYPE:
				case REACT_SUSPENSE_LIST_TYPE: return object;
				default: switch (object = object && object.$$typeof, object) {
					case REACT_CONTEXT_TYPE:
					case REACT_FORWARD_REF_TYPE:
					case REACT_LAZY_TYPE:
					case REACT_MEMO_TYPE: return object;
					case REACT_CONSUMER_TYPE: return object;
					default: return $$typeof;
				}
			}
			case REACT_PORTAL_TYPE: return $$typeof;
		}
	}
}
function isContextConsumer(object) {
	return IS_REACT_19 ? typeOf(object) === REACT_CONSUMER_TYPE : typeOf(object) === REACT_CONTEXT_TYPE;
}
function isMemo(object) {
	return typeOf(object) === REACT_MEMO_TYPE;
}
function warning(message) {
	if (typeof console !== "undefined" && typeof console.error === "function") console.error(message);
	try {
		throw new Error(message);
	} catch (e) {}
}
function verify(selector, methodName) {
	if (!selector) throw new Error(`Unexpected value for ${methodName} in connect.`);
	else if (methodName === "mapStateToProps" || methodName === "mapDispatchToProps") {
		if (!Object.prototype.hasOwnProperty.call(selector, "dependsOnOwnProps")) warning(`The selector for ${methodName} of connect did not specify a value for dependsOnOwnProps.`);
	}
}
function verifySubselectors(mapStateToProps, mapDispatchToProps, mergeProps) {
	verify(mapStateToProps, "mapStateToProps");
	verify(mapDispatchToProps, "mapDispatchToProps");
	verify(mergeProps, "mergeProps");
}
function pureFinalPropsSelectorFactory(mapStateToProps, mapDispatchToProps, mergeProps, dispatch, { areStatesEqual, areOwnPropsEqual, areStatePropsEqual }) {
	let hasRunAtLeastOnce = false;
	let state;
	let ownProps;
	let stateProps;
	let dispatchProps;
	let mergedProps;
	function handleFirstCall(firstState, firstOwnProps) {
		state = firstState;
		ownProps = firstOwnProps;
		stateProps = mapStateToProps(state, ownProps);
		dispatchProps = mapDispatchToProps(dispatch, ownProps);
		mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
		hasRunAtLeastOnce = true;
		return mergedProps;
	}
	function handleNewPropsAndNewState() {
		stateProps = mapStateToProps(state, ownProps);
		if (mapDispatchToProps.dependsOnOwnProps) dispatchProps = mapDispatchToProps(dispatch, ownProps);
		mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
		return mergedProps;
	}
	function handleNewProps() {
		if (mapStateToProps.dependsOnOwnProps) stateProps = mapStateToProps(state, ownProps);
		if (mapDispatchToProps.dependsOnOwnProps) dispatchProps = mapDispatchToProps(dispatch, ownProps);
		mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
		return mergedProps;
	}
	function handleNewState() {
		const nextStateProps = mapStateToProps(state, ownProps);
		const statePropsChanged = !areStatePropsEqual(nextStateProps, stateProps);
		stateProps = nextStateProps;
		if (statePropsChanged) mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
		return mergedProps;
	}
	function handleSubsequentCalls(nextState, nextOwnProps) {
		const propsChanged = !areOwnPropsEqual(nextOwnProps, ownProps);
		const stateChanged = !areStatesEqual(nextState, state, nextOwnProps, ownProps);
		state = nextState;
		ownProps = nextOwnProps;
		if (propsChanged && stateChanged) return handleNewPropsAndNewState();
		if (propsChanged) return handleNewProps();
		if (stateChanged) return handleNewState();
		return mergedProps;
	}
	return function pureFinalPropsSelector(nextState, nextOwnProps) {
		return hasRunAtLeastOnce ? handleSubsequentCalls(nextState, nextOwnProps) : handleFirstCall(nextState, nextOwnProps);
	};
}
function finalPropsSelectorFactory(dispatch, { initMapStateToProps, initMapDispatchToProps, initMergeProps, ...options }) {
	const mapStateToProps = initMapStateToProps(dispatch, options);
	const mapDispatchToProps = initMapDispatchToProps(dispatch, options);
	const mergeProps = initMergeProps(dispatch, options);
	verifySubselectors(mapStateToProps, mapDispatchToProps, mergeProps);
	return pureFinalPropsSelectorFactory(mapStateToProps, mapDispatchToProps, mergeProps, dispatch, options);
}
function bindActionCreators(actionCreators, dispatch) {
	const boundActionCreators = {};
	for (const key in actionCreators) {
		const actionCreator = actionCreators[key];
		if (typeof actionCreator === "function") boundActionCreators[key] = (...args) => dispatch(actionCreator(...args));
	}
	return boundActionCreators;
}
function isPlainObject(obj) {
	if (typeof obj !== "object" || obj === null) return false;
	const proto = Object.getPrototypeOf(obj);
	if (proto === null) return true;
	let baseProto = proto;
	while (Object.getPrototypeOf(baseProto) !== null) baseProto = Object.getPrototypeOf(baseProto);
	return proto === baseProto;
}
function verifyPlainObject(value, displayName, methodName) {
	if (!isPlainObject(value)) warning(`${methodName}() in ${displayName} must return a plain object. Instead received ${value}.`);
}
function wrapMapToPropsConstant(getConstant) {
	return function initConstantSelector(dispatch) {
		const constant = getConstant(dispatch);
		function constantSelector() {
			return constant;
		}
		constantSelector.dependsOnOwnProps = false;
		return constantSelector;
	};
}
function getDependsOnOwnProps(mapToProps) {
	return mapToProps.dependsOnOwnProps ? Boolean(mapToProps.dependsOnOwnProps) : mapToProps.length !== 1;
}
function wrapMapToPropsFunc(mapToProps, methodName) {
	return function initProxySelector(dispatch, { displayName }) {
		const proxy = function mapToPropsProxy(stateOrDispatch, ownProps) {
			return proxy.dependsOnOwnProps ? proxy.mapToProps(stateOrDispatch, ownProps) : proxy.mapToProps(stateOrDispatch, void 0);
		};
		proxy.dependsOnOwnProps = true;
		proxy.mapToProps = function detectFactoryAndVerify(stateOrDispatch, ownProps) {
			proxy.mapToProps = mapToProps;
			proxy.dependsOnOwnProps = getDependsOnOwnProps(mapToProps);
			let props = proxy(stateOrDispatch, ownProps);
			if (typeof props === "function") {
				proxy.mapToProps = props;
				proxy.dependsOnOwnProps = getDependsOnOwnProps(props);
				props = proxy(stateOrDispatch, ownProps);
			}
			verifyPlainObject(props, displayName, methodName);
			return props;
		};
		return proxy;
	};
}
function createInvalidArgFactory(arg, name) {
	return (dispatch, options) => {
		throw new Error(`Invalid value of type ${typeof arg} for ${name} argument when connecting component ${options.wrappedComponentName}.`);
	};
}
function mapDispatchToPropsFactory(mapDispatchToProps) {
	return mapDispatchToProps && typeof mapDispatchToProps === "object" ? wrapMapToPropsConstant((dispatch) => bindActionCreators(mapDispatchToProps, dispatch)) : !mapDispatchToProps ? wrapMapToPropsConstant((dispatch) => ({ dispatch })) : typeof mapDispatchToProps === "function" ? wrapMapToPropsFunc(mapDispatchToProps, "mapDispatchToProps") : createInvalidArgFactory(mapDispatchToProps, "mapDispatchToProps");
}
function mapStateToPropsFactory(mapStateToProps) {
	return !mapStateToProps ? wrapMapToPropsConstant(() => ({})) : typeof mapStateToProps === "function" ? wrapMapToPropsFunc(mapStateToProps, "mapStateToProps") : createInvalidArgFactory(mapStateToProps, "mapStateToProps");
}
function defaultMergeProps(stateProps, dispatchProps, ownProps) {
	return {
		...ownProps,
		...stateProps,
		...dispatchProps
	};
}
function wrapMergePropsFunc(mergeProps) {
	return function initMergePropsProxy(dispatch, { displayName, areMergedPropsEqual }) {
		let hasRunOnce = false;
		let mergedProps;
		return function mergePropsProxy(stateProps, dispatchProps, ownProps) {
			const nextMergedProps = mergeProps(stateProps, dispatchProps, ownProps);
			if (hasRunOnce) {
				if (!areMergedPropsEqual(nextMergedProps, mergedProps)) mergedProps = nextMergedProps;
			} else {
				hasRunOnce = true;
				mergedProps = nextMergedProps;
				verifyPlainObject(mergedProps, displayName, "mergeProps");
			}
			return mergedProps;
		};
	};
}
function mergePropsFactory(mergeProps) {
	return !mergeProps ? () => defaultMergeProps : typeof mergeProps === "function" ? wrapMergePropsFunc(mergeProps) : createInvalidArgFactory(mergeProps, "mergeProps");
}
function defaultNoopBatch(callback) {
	callback();
}
function createListenerCollection() {
	let first = null;
	let last = null;
	return {
		clear() {
			first = null;
			last = null;
		},
		notify() {
			defaultNoopBatch(() => {
				let listener = first;
				while (listener) {
					listener.callback();
					listener = listener.next;
				}
			});
		},
		get() {
			const listeners = [];
			let listener = first;
			while (listener) {
				listeners.push(listener);
				listener = listener.next;
			}
			return listeners;
		},
		subscribe(callback) {
			let isSubscribed = true;
			const listener = last = {
				callback,
				next: null,
				prev: last
			};
			if (listener.prev) listener.prev.next = listener;
			else first = listener;
			return function unsubscribe() {
				if (!isSubscribed || first === null) return;
				isSubscribed = false;
				if (listener.next) listener.next.prev = listener.prev;
				else last = listener.prev;
				if (listener.prev) listener.prev.next = listener.next;
				else first = listener.next;
			};
		}
	};
}
var nullListeners = {
	notify() {},
	get: () => []
};
function createSubscription(store, parentSub) {
	let unsubscribe;
	let listeners = nullListeners;
	let subscriptionsAmount = 0;
	let selfSubscribed = false;
	function addNestedSub(listener) {
		trySubscribe();
		const cleanupListener = listeners.subscribe(listener);
		let removed = false;
		return () => {
			if (!removed) {
				removed = true;
				cleanupListener();
				tryUnsubscribe();
			}
		};
	}
	function notifyNestedSubs() {
		listeners.notify();
	}
	function handleChangeWrapper() {
		if (subscription.onStateChange) subscription.onStateChange();
	}
	function isSubscribed() {
		return selfSubscribed;
	}
	function trySubscribe() {
		subscriptionsAmount++;
		if (!unsubscribe) {
			unsubscribe = parentSub ? parentSub.addNestedSub(handleChangeWrapper) : store.subscribe(handleChangeWrapper);
			listeners = createListenerCollection();
		}
	}
	function tryUnsubscribe() {
		subscriptionsAmount--;
		if (unsubscribe && subscriptionsAmount === 0) {
			unsubscribe();
			unsubscribe = void 0;
			listeners.clear();
			listeners = nullListeners;
		}
	}
	function trySubscribeSelf() {
		if (!selfSubscribed) {
			selfSubscribed = true;
			trySubscribe();
		}
	}
	function tryUnsubscribeSelf() {
		if (selfSubscribed) {
			selfSubscribed = false;
			tryUnsubscribe();
		}
	}
	const subscription = {
		addNestedSub,
		notifyNestedSubs,
		handleChangeWrapper,
		isSubscribed,
		trySubscribe: trySubscribeSelf,
		tryUnsubscribe: tryUnsubscribeSelf,
		getListeners: () => listeners
	};
	return subscription;
}
var canUseDOM = () => !!(typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined");
var isDOM = /* @__PURE__ */ canUseDOM();
var isRunningInReactNative = () => typeof navigator !== "undefined" && navigator.product === "ReactNative";
var isReactNative = /* @__PURE__ */ isRunningInReactNative();
var getUseIsomorphicLayoutEffect = () => isDOM || isReactNative ? import_react.useLayoutEffect : import_react.useEffect;
var useIsomorphicLayoutEffect = /* @__PURE__ */ getUseIsomorphicLayoutEffect();
function is(x, y) {
	if (x === y) return x !== 0 || y !== 0 || 1 / x === 1 / y;
	else return x !== x && y !== y;
}
function shallowEqual(objA, objB) {
	if (is(objA, objB)) return true;
	if (typeof objA !== "object" || objA === null || typeof objB !== "object" || objB === null) return false;
	const keysA = Object.keys(objA);
	const keysB = Object.keys(objB);
	if (keysA.length !== keysB.length) return false;
	for (let i = 0; i < keysA.length; i++) if (!Object.prototype.hasOwnProperty.call(objB, keysA[i]) || !is(objA[keysA[i]], objB[keysA[i]])) return false;
	return true;
}
var REACT_STATICS = {
	childContextTypes: true,
	contextType: true,
	contextTypes: true,
	defaultProps: true,
	displayName: true,
	getDefaultProps: true,
	getDerivedStateFromError: true,
	getDerivedStateFromProps: true,
	mixins: true,
	propTypes: true,
	type: true
};
var KNOWN_STATICS = {
	name: true,
	length: true,
	prototype: true,
	caller: true,
	callee: true,
	arguments: true,
	arity: true
};
var FORWARD_REF_STATICS = {
	$$typeof: true,
	render: true,
	defaultProps: true,
	displayName: true,
	propTypes: true
};
var MEMO_STATICS = {
	$$typeof: true,
	compare: true,
	defaultProps: true,
	displayName: true,
	propTypes: true,
	type: true
};
var TYPE_STATICS = {
	[ForwardRef]: FORWARD_REF_STATICS,
	[Memo]: MEMO_STATICS
};
function getStatics(component) {
	if (isMemo(component)) return MEMO_STATICS;
	return TYPE_STATICS[component["$$typeof"]] || REACT_STATICS;
}
var defineProperty = Object.defineProperty;
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var getPrototypeOf = Object.getPrototypeOf;
var objectPrototype = Object.prototype;
function hoistNonReactStatics(targetComponent, sourceComponent) {
	if (typeof sourceComponent !== "string") {
		if (objectPrototype) {
			const inheritedComponent = getPrototypeOf(sourceComponent);
			if (inheritedComponent && inheritedComponent !== objectPrototype) hoistNonReactStatics(targetComponent, inheritedComponent);
		}
		let keys = getOwnPropertyNames(sourceComponent);
		if (getOwnPropertySymbols) keys = keys.concat(getOwnPropertySymbols(sourceComponent));
		const targetStatics = getStatics(targetComponent);
		const sourceStatics = getStatics(sourceComponent);
		for (let i = 0; i < keys.length; ++i) {
			const key = keys[i];
			if (!KNOWN_STATICS[key] && !(sourceStatics && sourceStatics[key]) && !(targetStatics && targetStatics[key])) {
				const descriptor = getOwnPropertyDescriptor(sourceComponent, key);
				try {
					defineProperty(targetComponent, key, descriptor);
				} catch (e) {}
			}
		}
	}
	return targetComponent;
}
var ContextKey = /* @__PURE__ */ Symbol.for(`react-redux-context`);
var gT = typeof globalThis !== "undefined" ? globalThis : {};
function getContext() {
	if (!import_react.createContext) return {};
	const contextMap = gT[ContextKey] ??= /* @__PURE__ */ new Map();
	let realContext = contextMap.get(import_react.createContext);
	if (!realContext) {
		realContext = import_react.createContext(null);
		realContext.displayName = "ReactRedux";
		contextMap.set(import_react.createContext, realContext);
	}
	return realContext;
}
var ReactReduxContext = /* @__PURE__ */ getContext();
var NO_SUBSCRIPTION_ARRAY = [null, null];
var stringifyComponent = (Comp) => {
	try {
		return JSON.stringify(Comp);
	} catch (err) {
		return String(Comp);
	}
};
function useIsomorphicLayoutEffectWithArgs(effectFunc, effectArgs, dependencies) {
	useIsomorphicLayoutEffect(() => effectFunc(...effectArgs), dependencies);
}
function captureWrapperProps(lastWrapperProps, lastChildProps, renderIsScheduled, wrapperProps, childPropsFromStoreUpdate, notifyNestedSubs) {
	lastWrapperProps.current = wrapperProps;
	renderIsScheduled.current = false;
	if (childPropsFromStoreUpdate.current) {
		childPropsFromStoreUpdate.current = null;
		notifyNestedSubs();
	}
}
function subscribeUpdates(shouldHandleStateChanges, store, subscription, childPropsSelector, lastWrapperProps, lastChildProps, renderIsScheduled, isMounted, childPropsFromStoreUpdate, notifyNestedSubs, additionalSubscribeListener) {
	if (!shouldHandleStateChanges) return () => {};
	let didUnsubscribe = false;
	let lastThrownError = null;
	const checkForUpdates = () => {
		if (didUnsubscribe || !isMounted.current) return;
		const latestStoreState = store.getState();
		let newChildProps, error;
		try {
			newChildProps = childPropsSelector(latestStoreState, lastWrapperProps.current);
		} catch (e) {
			error = e;
			lastThrownError = e;
		}
		if (!error) lastThrownError = null;
		if (newChildProps === lastChildProps.current) {
			if (!renderIsScheduled.current) notifyNestedSubs();
		} else {
			lastChildProps.current = newChildProps;
			childPropsFromStoreUpdate.current = newChildProps;
			renderIsScheduled.current = true;
			additionalSubscribeListener();
		}
	};
	subscription.onStateChange = checkForUpdates;
	subscription.trySubscribe();
	checkForUpdates();
	const unsubscribeWrapper = () => {
		didUnsubscribe = true;
		subscription.tryUnsubscribe();
		subscription.onStateChange = null;
		if (lastThrownError) throw lastThrownError;
	};
	return unsubscribeWrapper;
}
function strictEqual(a, b) {
	return a === b;
}
var hasWarnedAboutDeprecatedPureOption = false;
function _connect(mapStateToProps, mapDispatchToProps, mergeProps, { pure, areStatesEqual = strictEqual, areOwnPropsEqual = shallowEqual, areStatePropsEqual = shallowEqual, areMergedPropsEqual = shallowEqual, forwardRef = false, context = ReactReduxContext } = {}) {
	if (pure !== void 0 && !hasWarnedAboutDeprecatedPureOption) {
		hasWarnedAboutDeprecatedPureOption = true;
		warning("The `pure` option has been removed. `connect` is now always a \"pure/memoized\" component");
	}
	const Context = context;
	const initMapStateToProps = mapStateToPropsFactory(mapStateToProps);
	const initMapDispatchToProps = mapDispatchToPropsFactory(mapDispatchToProps);
	const initMergeProps = mergePropsFactory(mergeProps);
	const shouldHandleStateChanges = Boolean(mapStateToProps);
	const wrapWithConnect = (WrappedComponent) => {
		if (!/* @__PURE__ */ isValidElementType(WrappedComponent)) throw new Error(`You must pass a component to the function returned by connect. Instead received ${stringifyComponent(WrappedComponent)}`);
		const wrappedComponentName = WrappedComponent.displayName || WrappedComponent.name || "Component";
		const displayName = `Connect(${wrappedComponentName})`;
		const selectorFactoryOptions = {
			shouldHandleStateChanges,
			displayName,
			wrappedComponentName,
			WrappedComponent,
			initMapStateToProps,
			initMapDispatchToProps,
			initMergeProps,
			areStatesEqual,
			areStatePropsEqual,
			areOwnPropsEqual,
			areMergedPropsEqual
		};
		function ConnectFunction(props) {
			const [propsContext, reactReduxForwardedRef, wrapperProps] = import_react.useMemo(() => {
				const { reactReduxForwardedRef: reactReduxForwardedRef2, ...wrapperProps2 } = props;
				return [
					props.context,
					reactReduxForwardedRef2,
					wrapperProps2
				];
			}, [props]);
			const ContextToUse = import_react.useMemo(() => {
				let ResultContext = Context;
				if (propsContext?.Consumer) {
					if (!/* @__PURE__ */ isContextConsumer(/* @__PURE__ */ import_react.createElement(propsContext.Consumer, null))) throw new Error("You must pass a valid React context consumer as `props.context`");
					ResultContext = propsContext;
				}
				return ResultContext;
			}, [propsContext, Context]);
			const contextValue = import_react.useContext(ContextToUse);
			const didStoreComeFromProps = Boolean(props.store) && Boolean(props.store.getState) && Boolean(props.store.dispatch);
			const didStoreComeFromContext = Boolean(contextValue) && Boolean(contextValue.store);
			if (!didStoreComeFromProps && !didStoreComeFromContext) throw new Error(`Could not find "store" in the context of "${displayName}". Either wrap the root component in a <Provider>, or pass a custom React context provider to <Provider> and the corresponding React context consumer to ${displayName} in connect options.`);
			const store = didStoreComeFromProps ? props.store : contextValue.store;
			const getServerState = didStoreComeFromContext ? contextValue.getServerState : store.getState;
			const childPropsSelector = import_react.useMemo(() => {
				return finalPropsSelectorFactory(store.dispatch, selectorFactoryOptions);
			}, [store]);
			const [subscription, notifyNestedSubs] = import_react.useMemo(() => {
				if (!shouldHandleStateChanges) return NO_SUBSCRIPTION_ARRAY;
				const subscription2 = createSubscription(store, didStoreComeFromProps ? void 0 : contextValue.subscription);
				return [subscription2, subscription2.notifyNestedSubs.bind(subscription2)];
			}, [
				store,
				didStoreComeFromProps,
				contextValue
			]);
			const overriddenContextValue = import_react.useMemo(() => {
				if (didStoreComeFromProps) return contextValue;
				return {
					...contextValue,
					subscription
				};
			}, [
				didStoreComeFromProps,
				contextValue,
				subscription
			]);
			const lastChildProps = import_react.useRef(void 0);
			const lastWrapperProps = import_react.useRef(wrapperProps);
			const childPropsFromStoreUpdate = import_react.useRef(void 0);
			const renderIsScheduled = import_react.useRef(false);
			const isMounted = import_react.useRef(false);
			const latestSubscriptionCallbackError = import_react.useRef(void 0);
			useIsomorphicLayoutEffect(() => {
				isMounted.current = true;
				return () => {
					isMounted.current = false;
				};
			}, []);
			const actualChildPropsSelector = import_react.useMemo(() => {
				const selector = () => {
					if (childPropsFromStoreUpdate.current && wrapperProps === lastWrapperProps.current) return childPropsFromStoreUpdate.current;
					return childPropsSelector(store.getState(), wrapperProps);
				};
				return selector;
			}, [store, wrapperProps]);
			const subscribeForReact = import_react.useMemo(() => {
				const subscribe = (reactListener) => {
					if (!subscription) return () => {};
					return subscribeUpdates(shouldHandleStateChanges, store, subscription, childPropsSelector, lastWrapperProps, lastChildProps, renderIsScheduled, isMounted, childPropsFromStoreUpdate, notifyNestedSubs, reactListener);
				};
				return subscribe;
			}, [subscription]);
			useIsomorphicLayoutEffectWithArgs(captureWrapperProps, [
				lastWrapperProps,
				lastChildProps,
				renderIsScheduled,
				wrapperProps,
				childPropsFromStoreUpdate,
				notifyNestedSubs
			]);
			let actualChildProps;
			try {
				actualChildProps = import_react.useSyncExternalStore(subscribeForReact, actualChildPropsSelector, getServerState ? () => childPropsSelector(getServerState(), wrapperProps) : actualChildPropsSelector);
			} catch (err) {
				if (latestSubscriptionCallbackError.current) err.message += `
The error may be correlated with this previous error:
${latestSubscriptionCallbackError.current.stack}

`;
				throw err;
			}
			useIsomorphicLayoutEffect(() => {
				latestSubscriptionCallbackError.current = void 0;
				childPropsFromStoreUpdate.current = void 0;
				lastChildProps.current = actualChildProps;
			});
			const renderedWrappedComponent = import_react.useMemo(() => {
				return /* @__PURE__ */ import_react.createElement(WrappedComponent, {
					...actualChildProps,
					ref: reactReduxForwardedRef
				});
			}, [
				reactReduxForwardedRef,
				WrappedComponent,
				actualChildProps
			]);
			return import_react.useMemo(() => {
				if (shouldHandleStateChanges) return /* @__PURE__ */ import_react.createElement(ContextToUse.Provider, { value: overriddenContextValue }, renderedWrappedComponent);
				return renderedWrappedComponent;
			}, [
				ContextToUse,
				renderedWrappedComponent,
				overriddenContextValue
			]);
		}
		const Connect = import_react.memo(ConnectFunction);
		Connect.WrappedComponent = WrappedComponent;
		Connect.displayName = ConnectFunction.displayName = displayName;
		if (forwardRef) {
			const forwarded = import_react.forwardRef(function forwardConnectRef(props, ref) {
				return /* @__PURE__ */ import_react.createElement(Connect, {
					...props,
					reactReduxForwardedRef: ref
				});
			});
			forwarded.displayName = displayName;
			forwarded.WrappedComponent = WrappedComponent;
			return /* @__PURE__ */ hoistNonReactStatics(forwarded, WrappedComponent);
		}
		return /* @__PURE__ */ hoistNonReactStatics(Connect, WrappedComponent);
	};
	return wrapWithConnect;
}
var connect = _connect;
var legacy_connect = _connect;
function Provider(providerProps) {
	const { children, context, serverState, store } = providerProps;
	const contextValue = import_react.useMemo(() => {
		const subscription = createSubscription(store);
		const baseContextValue = {
			store,
			subscription,
			getServerState: serverState ? () => serverState : void 0
		};
		{
			const { identityFunctionCheck = "once", stabilityCheck = "once" } = providerProps;
			return /* @__PURE__ */ Object.assign(baseContextValue, {
				stabilityCheck,
				identityFunctionCheck
			});
		}
	}, [store, serverState]);
	const previousState = import_react.useMemo(() => store.getState(), [store]);
	useIsomorphicLayoutEffect(() => {
		const { subscription } = contextValue;
		subscription.onStateChange = subscription.notifyNestedSubs;
		subscription.trySubscribe();
		if (previousState !== store.getState()) subscription.notifyNestedSubs();
		return () => {
			subscription.tryUnsubscribe();
			subscription.onStateChange = void 0;
		};
	}, [contextValue, previousState]);
	const Context = context || ReactReduxContext;
	return /* @__PURE__ */ import_react.createElement(Context.Provider, { value: contextValue }, children);
}
var Provider_default = Provider;
function createReduxContextHook(context = ReactReduxContext) {
	return function useReduxContext2() {
		const contextValue = import_react.useContext(context);
		if (!contextValue) throw new Error("could not find react-redux context value; please ensure the component is wrapped in a <Provider>");
		return contextValue;
	};
}
var useReduxContext = /* @__PURE__ */ createReduxContextHook();
function createStoreHook(context = ReactReduxContext) {
	const useReduxContext2 = context === ReactReduxContext ? useReduxContext : createReduxContextHook(context);
	const useStore2 = () => {
		const { store } = useReduxContext2();
		return store;
	};
	Object.assign(useStore2, { withTypes: () => useStore2 });
	return useStore2;
}
var useStore = /* @__PURE__ */ createStoreHook();
function createDispatchHook(context = ReactReduxContext) {
	const useStore2 = context === ReactReduxContext ? useStore : createStoreHook(context);
	const useDispatch2 = () => {
		return useStore2().dispatch;
	};
	Object.assign(useDispatch2, { withTypes: () => useDispatch2 });
	return useDispatch2;
}
var useDispatch = /* @__PURE__ */ createDispatchHook();
var refEquality = (a, b) => a === b;
function createSelectorHook(context = ReactReduxContext) {
	const useReduxContext2 = context === ReactReduxContext ? useReduxContext : createReduxContextHook(context);
	const useSelector2 = (selector, equalityFnOrOptions = {}) => {
		const { equalityFn = refEquality } = typeof equalityFnOrOptions === "function" ? { equalityFn: equalityFnOrOptions } : equalityFnOrOptions;
		if (!selector) throw new Error(`You must pass a selector to useSelector`);
		if (typeof selector !== "function") throw new Error(`You must pass a function as a selector to useSelector`);
		if (typeof equalityFn !== "function") throw new Error(`You must pass a function as an equality function to useSelector`);
		const reduxContext = useReduxContext2();
		const { store, subscription, getServerState } = reduxContext;
		const firstRun = import_react.useRef(true);
		const wrappedSelector = import_react.useCallback({ [selector.name](state) {
			const selected = selector(state);
			{
				const { devModeChecks = {} } = typeof equalityFnOrOptions === "function" ? {} : equalityFnOrOptions;
				const { identityFunctionCheck, stabilityCheck } = reduxContext;
				const { identityFunctionCheck: finalIdentityFunctionCheck, stabilityCheck: finalStabilityCheck } = {
					stabilityCheck,
					identityFunctionCheck,
					...devModeChecks
				};
				if (finalStabilityCheck === "always" || finalStabilityCheck === "once" && firstRun.current) {
					const toCompare = selector(state);
					if (!equalityFn(selected, toCompare)) {
						let stack = void 0;
						try {
							throw new Error();
						} catch (e) {
							({stack} = e);
						}
						console.warn("Selector " + (selector.name || "unknown") + " returned a different result when called with the same parameters. This can lead to unnecessary rerenders.\nSelectors that return a new reference (such as an object or an array) should be memoized: https://redux.js.org/usage/deriving-data-selectors#optimizing-selectors-with-memoization", {
							state,
							selected,
							selected2: toCompare,
							stack
						});
					}
				}
				if (finalIdentityFunctionCheck === "always" || finalIdentityFunctionCheck === "once" && firstRun.current) {
					if (selected === state) {
						let stack = void 0;
						try {
							throw new Error();
						} catch (e) {
							({stack} = e);
						}
						console.warn("Selector " + (selector.name || "unknown") + " returned the root state when called. This can lead to unnecessary rerenders.\nSelectors that return the entire state are almost certainly a mistake, as they will cause a rerender whenever *anything* in state changes.", { stack });
					}
				}
				if (firstRun.current) firstRun.current = false;
			}
			return selected;
		} }[selector.name], [selector]);
		const selectedState = (0, import_with_selector.useSyncExternalStoreWithSelector)(subscription.addNestedSub, store.getState, getServerState || store.getState, wrappedSelector, equalityFn);
		import_react.useDebugValue(selectedState);
		return selectedState;
	};
	Object.assign(useSelector2, { withTypes: () => useSelector2 });
	return useSelector2;
}
var useSelector = /* @__PURE__ */ createSelectorHook();
var batch = defaultNoopBatch;
//#endregion
export { Provider_default as Provider, ReactReduxContext, batch, connect, createDispatchHook, createSelectorHook, createStoreHook, legacy_connect, shallowEqual, useDispatch, useSelector, useStore };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtcmVkdXguanMiLCJuYW1lcyI6WyJ1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvciJdLCJzb3VyY2VzIjpbIi4uLy4uL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS13aXRoLXNlbGVjdG9yLmRldmVsb3BtZW50LmpzIiwiLi4vLi4vdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvd2l0aC1zZWxlY3Rvci5qcyIsIi4uLy4uL3JlYWN0LXJlZHV4L2Rpc3QvcmVhY3QtcmVkdXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2UgUmVhY3RcbiAqIHVzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXdpdGgtc2VsZWN0b3IuZGV2ZWxvcG1lbnQuanNcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIE1ldGEgUGxhdGZvcm1zLCBJbmMuIGFuZCBhZmZpbGlhdGVzLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cblwidXNlIHN0cmljdFwiO1xuXCJwcm9kdWN0aW9uXCIgIT09IHByb2Nlc3MuZW52Lk5PREVfRU5WICYmXG4gIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gaXMoeCwgeSkge1xuICAgICAgcmV0dXJuICh4ID09PSB5ICYmICgwICE9PSB4IHx8IDEgLyB4ID09PSAxIC8geSkpIHx8ICh4ICE9PSB4ICYmIHkgIT09IHkpO1xuICAgIH1cbiAgICBcInVuZGVmaW5lZFwiICE9PSB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmXG4gICAgICBcImZ1bmN0aW9uXCIgPT09XG4gICAgICAgIHR5cGVvZiBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0ICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0YXJ0KEVycm9yKCkpO1xuICAgIHZhciBSZWFjdCA9IHJlcXVpcmUoXCJyZWFjdFwiKSxcbiAgICAgIG9iamVjdElzID0gXCJmdW5jdGlvblwiID09PSB0eXBlb2YgT2JqZWN0LmlzID8gT2JqZWN0LmlzIDogaXMsXG4gICAgICB1c2VTeW5jRXh0ZXJuYWxTdG9yZSA9IFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlLFxuICAgICAgdXNlUmVmID0gUmVhY3QudXNlUmVmLFxuICAgICAgdXNlRWZmZWN0ID0gUmVhY3QudXNlRWZmZWN0LFxuICAgICAgdXNlTWVtbyA9IFJlYWN0LnVzZU1lbW8sXG4gICAgICB1c2VEZWJ1Z1ZhbHVlID0gUmVhY3QudXNlRGVidWdWYWx1ZTtcbiAgICBleHBvcnRzLnVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yID0gZnVuY3Rpb24gKFxuICAgICAgc3Vic2NyaWJlLFxuICAgICAgZ2V0U25hcHNob3QsXG4gICAgICBnZXRTZXJ2ZXJTbmFwc2hvdCxcbiAgICAgIHNlbGVjdG9yLFxuICAgICAgaXNFcXVhbFxuICAgICkge1xuICAgICAgdmFyIGluc3RSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgICBpZiAobnVsbCA9PT0gaW5zdFJlZi5jdXJyZW50KSB7XG4gICAgICAgIHZhciBpbnN0ID0geyBoYXNWYWx1ZTogITEsIHZhbHVlOiBudWxsIH07XG4gICAgICAgIGluc3RSZWYuY3VycmVudCA9IGluc3Q7XG4gICAgICB9IGVsc2UgaW5zdCA9IGluc3RSZWYuY3VycmVudDtcbiAgICAgIGluc3RSZWYgPSB1c2VNZW1vKFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZnVuY3Rpb24gbWVtb2l6ZWRTZWxlY3RvcihuZXh0U25hcHNob3QpIHtcbiAgICAgICAgICAgIGlmICghaGFzTWVtbykge1xuICAgICAgICAgICAgICBoYXNNZW1vID0gITA7XG4gICAgICAgICAgICAgIG1lbW9pemVkU25hcHNob3QgPSBuZXh0U25hcHNob3Q7XG4gICAgICAgICAgICAgIG5leHRTbmFwc2hvdCA9IHNlbGVjdG9yKG5leHRTbmFwc2hvdCk7XG4gICAgICAgICAgICAgIGlmICh2b2lkIDAgIT09IGlzRXF1YWwgJiYgaW5zdC5oYXNWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBjdXJyZW50U2VsZWN0aW9uID0gaW5zdC52YWx1ZTtcbiAgICAgICAgICAgICAgICBpZiAoaXNFcXVhbChjdXJyZW50U2VsZWN0aW9uLCBuZXh0U25hcHNob3QpKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChtZW1vaXplZFNlbGVjdGlvbiA9IGN1cnJlbnRTZWxlY3Rpb24pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiAobWVtb2l6ZWRTZWxlY3Rpb24gPSBuZXh0U25hcHNob3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbiA9IG1lbW9pemVkU2VsZWN0aW9uO1xuICAgICAgICAgICAgaWYgKG9iamVjdElzKG1lbW9pemVkU25hcHNob3QsIG5leHRTbmFwc2hvdCkpXG4gICAgICAgICAgICAgIHJldHVybiBjdXJyZW50U2VsZWN0aW9uO1xuICAgICAgICAgICAgdmFyIG5leHRTZWxlY3Rpb24gPSBzZWxlY3RvcihuZXh0U25hcHNob3QpO1xuICAgICAgICAgICAgaWYgKHZvaWQgMCAhPT0gaXNFcXVhbCAmJiBpc0VxdWFsKGN1cnJlbnRTZWxlY3Rpb24sIG5leHRTZWxlY3Rpb24pKVxuICAgICAgICAgICAgICByZXR1cm4gKG1lbW9pemVkU25hcHNob3QgPSBuZXh0U25hcHNob3QpLCBjdXJyZW50U2VsZWN0aW9uO1xuICAgICAgICAgICAgbWVtb2l6ZWRTbmFwc2hvdCA9IG5leHRTbmFwc2hvdDtcbiAgICAgICAgICAgIHJldHVybiAobWVtb2l6ZWRTZWxlY3Rpb24gPSBuZXh0U2VsZWN0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIGhhc01lbW8gPSAhMSxcbiAgICAgICAgICAgIG1lbW9pemVkU25hcHNob3QsXG4gICAgICAgICAgICBtZW1vaXplZFNlbGVjdGlvbixcbiAgICAgICAgICAgIG1heWJlR2V0U2VydmVyU25hcHNob3QgPVxuICAgICAgICAgICAgICB2b2lkIDAgPT09IGdldFNlcnZlclNuYXBzaG90ID8gbnVsbCA6IGdldFNlcnZlclNuYXBzaG90O1xuICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBtZW1vaXplZFNlbGVjdG9yKGdldFNuYXBzaG90KCkpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG51bGwgPT09IG1heWJlR2V0U2VydmVyU25hcHNob3RcbiAgICAgICAgICAgICAgPyB2b2lkIDBcbiAgICAgICAgICAgICAgOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gbWVtb2l6ZWRTZWxlY3RvcihtYXliZUdldFNlcnZlclNuYXBzaG90KCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICBdO1xuICAgICAgICB9LFxuICAgICAgICBbZ2V0U25hcHNob3QsIGdldFNlcnZlclNuYXBzaG90LCBzZWxlY3RvciwgaXNFcXVhbF1cbiAgICAgICk7XG4gICAgICB2YXIgdmFsdWUgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmUsIGluc3RSZWZbMF0sIGluc3RSZWZbMV0pO1xuICAgICAgdXNlRWZmZWN0KFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaW5zdC5oYXNWYWx1ZSA9ICEwO1xuICAgICAgICAgIGluc3QudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgW3ZhbHVlXVxuICAgICAgKTtcbiAgICAgIHVzZURlYnVnVmFsdWUodmFsdWUpO1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH07XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdG9wICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AoRXJyb3IoKSk7XG4gIH0pKCk7XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9janMvdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtd2l0aC1zZWxlY3Rvci5wcm9kdWN0aW9uLmpzJyk7XG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXdpdGgtc2VsZWN0b3IuZGV2ZWxvcG1lbnQuanMnKTtcbn1cbiIsIi8vIHNyYy91dGlscy9yZWFjdC50c1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbi8vIHNyYy91dGlscy9yZWFjdC1pcy50c1xudmFyIElTX1JFQUNUXzE5ID0gLyogQF9fUFVSRV9fICovIFJlYWN0LnZlcnNpb24uc3RhcnRzV2l0aChcIjE5XCIpO1xudmFyIFJFQUNUX0VMRU1FTlRfVFlQRSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFxuICBJU19SRUFDVF8xOSA/IFwicmVhY3QudHJhbnNpdGlvbmFsLmVsZW1lbnRcIiA6IFwicmVhY3QuZWxlbWVudFwiXG4pO1xudmFyIFJFQUNUX1BPUlRBTF9UWVBFID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJyZWFjdC5wb3J0YWxcIik7XG52YXIgUkVBQ1RfRlJBR01FTlRfVFlQRSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwicmVhY3QuZnJhZ21lbnRcIik7XG52YXIgUkVBQ1RfU1RSSUNUX01PREVfVFlQRSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwicmVhY3Quc3RyaWN0X21vZGVcIik7XG52YXIgUkVBQ1RfUFJPRklMRVJfVFlQRSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwicmVhY3QucHJvZmlsZXJcIik7XG52YXIgUkVBQ1RfQ09OU1VNRVJfVFlQRSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwicmVhY3QuY29uc3VtZXJcIik7XG52YXIgUkVBQ1RfQ09OVEVYVF9UWVBFID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJyZWFjdC5jb250ZXh0XCIpO1xudmFyIFJFQUNUX0ZPUldBUkRfUkVGX1RZUEUgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sLmZvcihcInJlYWN0LmZvcndhcmRfcmVmXCIpO1xudmFyIFJFQUNUX1NVU1BFTlNFX1RZUEUgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sLmZvcihcInJlYWN0LnN1c3BlbnNlXCIpO1xudmFyIFJFQUNUX1NVU1BFTlNFX0xJU1RfVFlQRSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFxuICBcInJlYWN0LnN1c3BlbnNlX2xpc3RcIlxuKTtcbnZhciBSRUFDVF9NRU1PX1RZUEUgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sLmZvcihcInJlYWN0Lm1lbW9cIik7XG52YXIgUkVBQ1RfTEFaWV9UWVBFID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJyZWFjdC5sYXp5XCIpO1xudmFyIFJFQUNUX09GRlNDUkVFTl9UWVBFID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJyZWFjdC5vZmZzY3JlZW5cIik7XG52YXIgUkVBQ1RfQ0xJRU5UX1JFRkVSRU5DRSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFxuICBcInJlYWN0LmNsaWVudC5yZWZlcmVuY2VcIlxuKTtcbnZhciBGb3J3YXJkUmVmID0gUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRTtcbnZhciBNZW1vID0gUkVBQ1RfTUVNT19UWVBFO1xuZnVuY3Rpb24gaXNWYWxpZEVsZW1lbnRUeXBlKHR5cGUpIHtcbiAgcmV0dXJuIHR5cGVvZiB0eXBlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB0eXBlID09PSBcImZ1bmN0aW9uXCIgfHwgdHlwZSA9PT0gUkVBQ1RfRlJBR01FTlRfVFlQRSB8fCB0eXBlID09PSBSRUFDVF9QUk9GSUxFUl9UWVBFIHx8IHR5cGUgPT09IFJFQUNUX1NUUklDVF9NT0RFX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfU1VTUEVOU0VfVFlQRSB8fCB0eXBlID09PSBSRUFDVF9TVVNQRU5TRV9MSVNUX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfT0ZGU0NSRUVOX1RZUEUgfHwgdHlwZW9mIHR5cGUgPT09IFwib2JqZWN0XCIgJiYgdHlwZSAhPT0gbnVsbCAmJiAodHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfTEFaWV9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX01FTU9fVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9DT05URVhUX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfQ09OU1VNRVJfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9GT1JXQVJEX1JFRl9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX0NMSUVOVF9SRUZFUkVOQ0UgfHwgdHlwZS5nZXRNb2R1bGVJZCAhPT0gdm9pZCAwKSA/IHRydWUgOiBmYWxzZTtcbn1cbmZ1bmN0aW9uIHR5cGVPZihvYmplY3QpIHtcbiAgaWYgKHR5cGVvZiBvYmplY3QgPT09IFwib2JqZWN0XCIgJiYgb2JqZWN0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgeyAkJHR5cGVvZiB9ID0gb2JqZWN0O1xuICAgIHN3aXRjaCAoJCR0eXBlb2YpIHtcbiAgICAgIGNhc2UgUkVBQ1RfRUxFTUVOVF9UWVBFOlxuICAgICAgICBzd2l0Y2ggKG9iamVjdCA9IG9iamVjdC50eXBlLCBvYmplY3QpIHtcbiAgICAgICAgICBjYXNlIFJFQUNUX0ZSQUdNRU5UX1RZUEU6XG4gICAgICAgICAgY2FzZSBSRUFDVF9QUk9GSUxFUl9UWVBFOlxuICAgICAgICAgIGNhc2UgUkVBQ1RfU1RSSUNUX01PREVfVFlQRTpcbiAgICAgICAgICBjYXNlIFJFQUNUX1NVU1BFTlNFX1RZUEU6XG4gICAgICAgICAgY2FzZSBSRUFDVF9TVVNQRU5TRV9MSVNUX1RZUEU6XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICBzd2l0Y2ggKG9iamVjdCA9IG9iamVjdCAmJiBvYmplY3QuJCR0eXBlb2YsIG9iamVjdCkge1xuICAgICAgICAgICAgICBjYXNlIFJFQUNUX0NPTlRFWFRfVFlQRTpcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9GT1JXQVJEX1JFRl9UWVBFOlxuICAgICAgICAgICAgICBjYXNlIFJFQUNUX0xBWllfVFlQRTpcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9NRU1PX1RZUEU6XG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9DT05TVU1FUl9UWVBFOlxuICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuICQkdHlwZW9mO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICBjYXNlIFJFQUNUX1BPUlRBTF9UWVBFOlxuICAgICAgICByZXR1cm4gJCR0eXBlb2Y7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBpc0NvbnRleHRDb25zdW1lcihvYmplY3QpIHtcbiAgcmV0dXJuIElTX1JFQUNUXzE5ID8gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX0NPTlNVTUVSX1RZUEUgOiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfQ09OVEVYVF9UWVBFO1xufVxuZnVuY3Rpb24gaXNNZW1vKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX01FTU9fVFlQRTtcbn1cblxuLy8gc3JjL3V0aWxzL3dhcm5pbmcudHNcbmZ1bmN0aW9uIHdhcm5pbmcobWVzc2FnZSkge1xuICBpZiAodHlwZW9mIGNvbnNvbGUgIT09IFwidW5kZWZpbmVkXCIgJiYgdHlwZW9mIGNvbnNvbGUuZXJyb3IgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGNvbnNvbGUuZXJyb3IobWVzc2FnZSk7XG4gIH1cbiAgdHJ5IHtcbiAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgfVxufVxuXG4vLyBzcmMvY29ubmVjdC92ZXJpZnlTdWJzZWxlY3RvcnMudHNcbmZ1bmN0aW9uIHZlcmlmeShzZWxlY3RvciwgbWV0aG9kTmFtZSkge1xuICBpZiAoIXNlbGVjdG9yKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIHZhbHVlIGZvciAke21ldGhvZE5hbWV9IGluIGNvbm5lY3QuYCk7XG4gIH0gZWxzZSBpZiAobWV0aG9kTmFtZSA9PT0gXCJtYXBTdGF0ZVRvUHJvcHNcIiB8fCBtZXRob2ROYW1lID09PSBcIm1hcERpc3BhdGNoVG9Qcm9wc1wiKSB7XG4gICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc2VsZWN0b3IsIFwiZGVwZW5kc09uT3duUHJvcHNcIikpIHtcbiAgICAgIHdhcm5pbmcoXG4gICAgICAgIGBUaGUgc2VsZWN0b3IgZm9yICR7bWV0aG9kTmFtZX0gb2YgY29ubmVjdCBkaWQgbm90IHNwZWNpZnkgYSB2YWx1ZSBmb3IgZGVwZW5kc09uT3duUHJvcHMuYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHZlcmlmeVN1YnNlbGVjdG9ycyhtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcywgbWVyZ2VQcm9wcykge1xuICB2ZXJpZnkobWFwU3RhdGVUb1Byb3BzLCBcIm1hcFN0YXRlVG9Qcm9wc1wiKTtcbiAgdmVyaWZ5KG1hcERpc3BhdGNoVG9Qcm9wcywgXCJtYXBEaXNwYXRjaFRvUHJvcHNcIik7XG4gIHZlcmlmeShtZXJnZVByb3BzLCBcIm1lcmdlUHJvcHNcIik7XG59XG5cbi8vIHNyYy9jb25uZWN0L3NlbGVjdG9yRmFjdG9yeS50c1xuZnVuY3Rpb24gcHVyZUZpbmFsUHJvcHNTZWxlY3RvckZhY3RvcnkobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMsIG1lcmdlUHJvcHMsIGRpc3BhdGNoLCB7XG4gIGFyZVN0YXRlc0VxdWFsLFxuICBhcmVPd25Qcm9wc0VxdWFsLFxuICBhcmVTdGF0ZVByb3BzRXF1YWxcbn0pIHtcbiAgbGV0IGhhc1J1bkF0TGVhc3RPbmNlID0gZmFsc2U7XG4gIGxldCBzdGF0ZTtcbiAgbGV0IG93blByb3BzO1xuICBsZXQgc3RhdGVQcm9wcztcbiAgbGV0IGRpc3BhdGNoUHJvcHM7XG4gIGxldCBtZXJnZWRQcm9wcztcbiAgZnVuY3Rpb24gaGFuZGxlRmlyc3RDYWxsKGZpcnN0U3RhdGUsIGZpcnN0T3duUHJvcHMpIHtcbiAgICBzdGF0ZSA9IGZpcnN0U3RhdGU7XG4gICAgb3duUHJvcHMgPSBmaXJzdE93blByb3BzO1xuICAgIHN0YXRlUHJvcHMgPSBtYXBTdGF0ZVRvUHJvcHMoc3RhdGUsIG93blByb3BzKTtcbiAgICBkaXNwYXRjaFByb3BzID0gbWFwRGlzcGF0Y2hUb1Byb3BzKGRpc3BhdGNoLCBvd25Qcm9wcyk7XG4gICAgbWVyZ2VkUHJvcHMgPSBtZXJnZVByb3BzKHN0YXRlUHJvcHMsIGRpc3BhdGNoUHJvcHMsIG93blByb3BzKTtcbiAgICBoYXNSdW5BdExlYXN0T25jZSA9IHRydWU7XG4gICAgcmV0dXJuIG1lcmdlZFByb3BzO1xuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZU5ld1Byb3BzQW5kTmV3U3RhdGUoKSB7XG4gICAgc3RhdGVQcm9wcyA9IG1hcFN0YXRlVG9Qcm9wcyhzdGF0ZSwgb3duUHJvcHMpO1xuICAgIGlmIChtYXBEaXNwYXRjaFRvUHJvcHMuZGVwZW5kc09uT3duUHJvcHMpXG4gICAgICBkaXNwYXRjaFByb3BzID0gbWFwRGlzcGF0Y2hUb1Byb3BzKGRpc3BhdGNoLCBvd25Qcm9wcyk7XG4gICAgbWVyZ2VkUHJvcHMgPSBtZXJnZVByb3BzKHN0YXRlUHJvcHMsIGRpc3BhdGNoUHJvcHMsIG93blByb3BzKTtcbiAgICByZXR1cm4gbWVyZ2VkUHJvcHM7XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlTmV3UHJvcHMoKSB7XG4gICAgaWYgKG1hcFN0YXRlVG9Qcm9wcy5kZXBlbmRzT25Pd25Qcm9wcylcbiAgICAgIHN0YXRlUHJvcHMgPSBtYXBTdGF0ZVRvUHJvcHMoc3RhdGUsIG93blByb3BzKTtcbiAgICBpZiAobWFwRGlzcGF0Y2hUb1Byb3BzLmRlcGVuZHNPbk93blByb3BzKVxuICAgICAgZGlzcGF0Y2hQcm9wcyA9IG1hcERpc3BhdGNoVG9Qcm9wcyhkaXNwYXRjaCwgb3duUHJvcHMpO1xuICAgIG1lcmdlZFByb3BzID0gbWVyZ2VQcm9wcyhzdGF0ZVByb3BzLCBkaXNwYXRjaFByb3BzLCBvd25Qcm9wcyk7XG4gICAgcmV0dXJuIG1lcmdlZFByb3BzO1xuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZU5ld1N0YXRlKCkge1xuICAgIGNvbnN0IG5leHRTdGF0ZVByb3BzID0gbWFwU3RhdGVUb1Byb3BzKHN0YXRlLCBvd25Qcm9wcyk7XG4gICAgY29uc3Qgc3RhdGVQcm9wc0NoYW5nZWQgPSAhYXJlU3RhdGVQcm9wc0VxdWFsKG5leHRTdGF0ZVByb3BzLCBzdGF0ZVByb3BzKTtcbiAgICBzdGF0ZVByb3BzID0gbmV4dFN0YXRlUHJvcHM7XG4gICAgaWYgKHN0YXRlUHJvcHNDaGFuZ2VkKVxuICAgICAgbWVyZ2VkUHJvcHMgPSBtZXJnZVByb3BzKHN0YXRlUHJvcHMsIGRpc3BhdGNoUHJvcHMsIG93blByb3BzKTtcbiAgICByZXR1cm4gbWVyZ2VkUHJvcHM7XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlU3Vic2VxdWVudENhbGxzKG5leHRTdGF0ZSwgbmV4dE93blByb3BzKSB7XG4gICAgY29uc3QgcHJvcHNDaGFuZ2VkID0gIWFyZU93blByb3BzRXF1YWwobmV4dE93blByb3BzLCBvd25Qcm9wcyk7XG4gICAgY29uc3Qgc3RhdGVDaGFuZ2VkID0gIWFyZVN0YXRlc0VxdWFsKFxuICAgICAgbmV4dFN0YXRlLFxuICAgICAgc3RhdGUsXG4gICAgICBuZXh0T3duUHJvcHMsXG4gICAgICBvd25Qcm9wc1xuICAgICk7XG4gICAgc3RhdGUgPSBuZXh0U3RhdGU7XG4gICAgb3duUHJvcHMgPSBuZXh0T3duUHJvcHM7XG4gICAgaWYgKHByb3BzQ2hhbmdlZCAmJiBzdGF0ZUNoYW5nZWQpIHJldHVybiBoYW5kbGVOZXdQcm9wc0FuZE5ld1N0YXRlKCk7XG4gICAgaWYgKHByb3BzQ2hhbmdlZCkgcmV0dXJuIGhhbmRsZU5ld1Byb3BzKCk7XG4gICAgaWYgKHN0YXRlQ2hhbmdlZCkgcmV0dXJuIGhhbmRsZU5ld1N0YXRlKCk7XG4gICAgcmV0dXJuIG1lcmdlZFByb3BzO1xuICB9XG4gIHJldHVybiBmdW5jdGlvbiBwdXJlRmluYWxQcm9wc1NlbGVjdG9yKG5leHRTdGF0ZSwgbmV4dE93blByb3BzKSB7XG4gICAgcmV0dXJuIGhhc1J1bkF0TGVhc3RPbmNlID8gaGFuZGxlU3Vic2VxdWVudENhbGxzKG5leHRTdGF0ZSwgbmV4dE93blByb3BzKSA6IGhhbmRsZUZpcnN0Q2FsbChuZXh0U3RhdGUsIG5leHRPd25Qcm9wcyk7XG4gIH07XG59XG5mdW5jdGlvbiBmaW5hbFByb3BzU2VsZWN0b3JGYWN0b3J5KGRpc3BhdGNoLCB7XG4gIGluaXRNYXBTdGF0ZVRvUHJvcHMsXG4gIGluaXRNYXBEaXNwYXRjaFRvUHJvcHMsXG4gIGluaXRNZXJnZVByb3BzLFxuICAuLi5vcHRpb25zXG59KSB7XG4gIGNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IGluaXRNYXBTdGF0ZVRvUHJvcHMoZGlzcGF0Y2gsIG9wdGlvbnMpO1xuICBjb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSBpbml0TWFwRGlzcGF0Y2hUb1Byb3BzKGRpc3BhdGNoLCBvcHRpb25zKTtcbiAgY29uc3QgbWVyZ2VQcm9wcyA9IGluaXRNZXJnZVByb3BzKGRpc3BhdGNoLCBvcHRpb25zKTtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIHZlcmlmeVN1YnNlbGVjdG9ycyhtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcywgbWVyZ2VQcm9wcyk7XG4gIH1cbiAgcmV0dXJuIHB1cmVGaW5hbFByb3BzU2VsZWN0b3JGYWN0b3J5KG1hcFN0YXRlVG9Qcm9wcywgbWFwRGlzcGF0Y2hUb1Byb3BzLCBtZXJnZVByb3BzLCBkaXNwYXRjaCwgb3B0aW9ucyk7XG59XG5cbi8vIHNyYy91dGlscy9iaW5kQWN0aW9uQ3JlYXRvcnMudHNcbmZ1bmN0aW9uIGJpbmRBY3Rpb25DcmVhdG9ycyhhY3Rpb25DcmVhdG9ycywgZGlzcGF0Y2gpIHtcbiAgY29uc3QgYm91bmRBY3Rpb25DcmVhdG9ycyA9IHt9O1xuICBmb3IgKGNvbnN0IGtleSBpbiBhY3Rpb25DcmVhdG9ycykge1xuICAgIGNvbnN0IGFjdGlvbkNyZWF0b3IgPSBhY3Rpb25DcmVhdG9yc1trZXldO1xuICAgIGlmICh0eXBlb2YgYWN0aW9uQ3JlYXRvciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICBib3VuZEFjdGlvbkNyZWF0b3JzW2tleV0gPSAoLi4uYXJncykgPT4gZGlzcGF0Y2goYWN0aW9uQ3JlYXRvciguLi5hcmdzKSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBib3VuZEFjdGlvbkNyZWF0b3JzO1xufVxuXG4vLyBzcmMvdXRpbHMvaXNQbGFpbk9iamVjdC50c1xuZnVuY3Rpb24gaXNQbGFpbk9iamVjdChvYmopIHtcbiAgaWYgKHR5cGVvZiBvYmogIT09IFwib2JqZWN0XCIgfHwgb2JqID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iaik7XG4gIGlmIChwcm90byA9PT0gbnVsbCkgcmV0dXJuIHRydWU7XG4gIGxldCBiYXNlUHJvdG8gPSBwcm90bztcbiAgd2hpbGUgKE9iamVjdC5nZXRQcm90b3R5cGVPZihiYXNlUHJvdG8pICE9PSBudWxsKSB7XG4gICAgYmFzZVByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKGJhc2VQcm90byk7XG4gIH1cbiAgcmV0dXJuIHByb3RvID09PSBiYXNlUHJvdG87XG59XG5cbi8vIHNyYy91dGlscy92ZXJpZnlQbGFpbk9iamVjdC50c1xuZnVuY3Rpb24gdmVyaWZ5UGxhaW5PYmplY3QodmFsdWUsIGRpc3BsYXlOYW1lLCBtZXRob2ROYW1lKSB7XG4gIGlmICghaXNQbGFpbk9iamVjdCh2YWx1ZSkpIHtcbiAgICB3YXJuaW5nKFxuICAgICAgYCR7bWV0aG9kTmFtZX0oKSBpbiAke2Rpc3BsYXlOYW1lfSBtdXN0IHJldHVybiBhIHBsYWluIG9iamVjdC4gSW5zdGVhZCByZWNlaXZlZCAke3ZhbHVlfS5gXG4gICAgKTtcbiAgfVxufVxuXG4vLyBzcmMvY29ubmVjdC93cmFwTWFwVG9Qcm9wcy50c1xuZnVuY3Rpb24gd3JhcE1hcFRvUHJvcHNDb25zdGFudChnZXRDb25zdGFudCkge1xuICByZXR1cm4gZnVuY3Rpb24gaW5pdENvbnN0YW50U2VsZWN0b3IoZGlzcGF0Y2gpIHtcbiAgICBjb25zdCBjb25zdGFudCA9IGdldENvbnN0YW50KGRpc3BhdGNoKTtcbiAgICBmdW5jdGlvbiBjb25zdGFudFNlbGVjdG9yKCkge1xuICAgICAgcmV0dXJuIGNvbnN0YW50O1xuICAgIH1cbiAgICBjb25zdGFudFNlbGVjdG9yLmRlcGVuZHNPbk93blByb3BzID0gZmFsc2U7XG4gICAgcmV0dXJuIGNvbnN0YW50U2VsZWN0b3I7XG4gIH07XG59XG5mdW5jdGlvbiBnZXREZXBlbmRzT25Pd25Qcm9wcyhtYXBUb1Byb3BzKSB7XG4gIHJldHVybiBtYXBUb1Byb3BzLmRlcGVuZHNPbk93blByb3BzID8gQm9vbGVhbihtYXBUb1Byb3BzLmRlcGVuZHNPbk93blByb3BzKSA6IG1hcFRvUHJvcHMubGVuZ3RoICE9PSAxO1xufVxuZnVuY3Rpb24gd3JhcE1hcFRvUHJvcHNGdW5jKG1hcFRvUHJvcHMsIG1ldGhvZE5hbWUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGluaXRQcm94eVNlbGVjdG9yKGRpc3BhdGNoLCB7IGRpc3BsYXlOYW1lIH0pIHtcbiAgICBjb25zdCBwcm94eSA9IGZ1bmN0aW9uIG1hcFRvUHJvcHNQcm94eShzdGF0ZU9yRGlzcGF0Y2gsIG93blByb3BzKSB7XG4gICAgICByZXR1cm4gcHJveHkuZGVwZW5kc09uT3duUHJvcHMgPyBwcm94eS5tYXBUb1Byb3BzKHN0YXRlT3JEaXNwYXRjaCwgb3duUHJvcHMpIDogcHJveHkubWFwVG9Qcm9wcyhzdGF0ZU9yRGlzcGF0Y2gsIHZvaWQgMCk7XG4gICAgfTtcbiAgICBwcm94eS5kZXBlbmRzT25Pd25Qcm9wcyA9IHRydWU7XG4gICAgcHJveHkubWFwVG9Qcm9wcyA9IGZ1bmN0aW9uIGRldGVjdEZhY3RvcnlBbmRWZXJpZnkoc3RhdGVPckRpc3BhdGNoLCBvd25Qcm9wcykge1xuICAgICAgcHJveHkubWFwVG9Qcm9wcyA9IG1hcFRvUHJvcHM7XG4gICAgICBwcm94eS5kZXBlbmRzT25Pd25Qcm9wcyA9IGdldERlcGVuZHNPbk93blByb3BzKG1hcFRvUHJvcHMpO1xuICAgICAgbGV0IHByb3BzID0gcHJveHkoc3RhdGVPckRpc3BhdGNoLCBvd25Qcm9wcyk7XG4gICAgICBpZiAodHlwZW9mIHByb3BzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgcHJveHkubWFwVG9Qcm9wcyA9IHByb3BzO1xuICAgICAgICBwcm94eS5kZXBlbmRzT25Pd25Qcm9wcyA9IGdldERlcGVuZHNPbk93blByb3BzKHByb3BzKTtcbiAgICAgICAgcHJvcHMgPSBwcm94eShzdGF0ZU9yRGlzcGF0Y2gsIG93blByb3BzKTtcbiAgICAgIH1cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpXG4gICAgICAgIHZlcmlmeVBsYWluT2JqZWN0KHByb3BzLCBkaXNwbGF5TmFtZSwgbWV0aG9kTmFtZSk7XG4gICAgICByZXR1cm4gcHJvcHM7XG4gICAgfTtcbiAgICByZXR1cm4gcHJveHk7XG4gIH07XG59XG5cbi8vIHNyYy9jb25uZWN0L2ludmFsaWRBcmdGYWN0b3J5LnRzXG5mdW5jdGlvbiBjcmVhdGVJbnZhbGlkQXJnRmFjdG9yeShhcmcsIG5hbWUpIHtcbiAgcmV0dXJuIChkaXNwYXRjaCwgb3B0aW9ucykgPT4ge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBJbnZhbGlkIHZhbHVlIG9mIHR5cGUgJHt0eXBlb2YgYXJnfSBmb3IgJHtuYW1lfSBhcmd1bWVudCB3aGVuIGNvbm5lY3RpbmcgY29tcG9uZW50ICR7b3B0aW9ucy53cmFwcGVkQ29tcG9uZW50TmFtZX0uYFxuICAgICk7XG4gIH07XG59XG5cbi8vIHNyYy9jb25uZWN0L21hcERpc3BhdGNoVG9Qcm9wcy50c1xuZnVuY3Rpb24gbWFwRGlzcGF0Y2hUb1Byb3BzRmFjdG9yeShtYXBEaXNwYXRjaFRvUHJvcHMpIHtcbiAgcmV0dXJuIG1hcERpc3BhdGNoVG9Qcm9wcyAmJiB0eXBlb2YgbWFwRGlzcGF0Y2hUb1Byb3BzID09PSBcIm9iamVjdFwiID8gd3JhcE1hcFRvUHJvcHNDb25zdGFudChcbiAgICAoZGlzcGF0Y2gpID0+IChcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIGJpbmRBY3Rpb25DcmVhdG9ycyhtYXBEaXNwYXRjaFRvUHJvcHMsIGRpc3BhdGNoKVxuICAgIClcbiAgKSA6ICFtYXBEaXNwYXRjaFRvUHJvcHMgPyB3cmFwTWFwVG9Qcm9wc0NvbnN0YW50KChkaXNwYXRjaCkgPT4gKHtcbiAgICBkaXNwYXRjaFxuICB9KSkgOiB0eXBlb2YgbWFwRGlzcGF0Y2hUb1Byb3BzID09PSBcImZ1bmN0aW9uXCIgPyAoXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHdyYXBNYXBUb1Byb3BzRnVuYyhtYXBEaXNwYXRjaFRvUHJvcHMsIFwibWFwRGlzcGF0Y2hUb1Byb3BzXCIpXG4gICkgOiBjcmVhdGVJbnZhbGlkQXJnRmFjdG9yeShtYXBEaXNwYXRjaFRvUHJvcHMsIFwibWFwRGlzcGF0Y2hUb1Byb3BzXCIpO1xufVxuXG4vLyBzcmMvY29ubmVjdC9tYXBTdGF0ZVRvUHJvcHMudHNcbmZ1bmN0aW9uIG1hcFN0YXRlVG9Qcm9wc0ZhY3RvcnkobWFwU3RhdGVUb1Byb3BzKSB7XG4gIHJldHVybiAhbWFwU3RhdGVUb1Byb3BzID8gd3JhcE1hcFRvUHJvcHNDb25zdGFudCgoKSA9PiAoe30pKSA6IHR5cGVvZiBtYXBTdGF0ZVRvUHJvcHMgPT09IFwiZnVuY3Rpb25cIiA/IChcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgd3JhcE1hcFRvUHJvcHNGdW5jKG1hcFN0YXRlVG9Qcm9wcywgXCJtYXBTdGF0ZVRvUHJvcHNcIilcbiAgKSA6IGNyZWF0ZUludmFsaWRBcmdGYWN0b3J5KG1hcFN0YXRlVG9Qcm9wcywgXCJtYXBTdGF0ZVRvUHJvcHNcIik7XG59XG5cbi8vIHNyYy9jb25uZWN0L21lcmdlUHJvcHMudHNcbmZ1bmN0aW9uIGRlZmF1bHRNZXJnZVByb3BzKHN0YXRlUHJvcHMsIGRpc3BhdGNoUHJvcHMsIG93blByb3BzKSB7XG4gIHJldHVybiB7IC4uLm93blByb3BzLCAuLi5zdGF0ZVByb3BzLCAuLi5kaXNwYXRjaFByb3BzIH07XG59XG5mdW5jdGlvbiB3cmFwTWVyZ2VQcm9wc0Z1bmMobWVyZ2VQcm9wcykge1xuICByZXR1cm4gZnVuY3Rpb24gaW5pdE1lcmdlUHJvcHNQcm94eShkaXNwYXRjaCwgeyBkaXNwbGF5TmFtZSwgYXJlTWVyZ2VkUHJvcHNFcXVhbCB9KSB7XG4gICAgbGV0IGhhc1J1bk9uY2UgPSBmYWxzZTtcbiAgICBsZXQgbWVyZ2VkUHJvcHM7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIG1lcmdlUHJvcHNQcm94eShzdGF0ZVByb3BzLCBkaXNwYXRjaFByb3BzLCBvd25Qcm9wcykge1xuICAgICAgY29uc3QgbmV4dE1lcmdlZFByb3BzID0gbWVyZ2VQcm9wcyhzdGF0ZVByb3BzLCBkaXNwYXRjaFByb3BzLCBvd25Qcm9wcyk7XG4gICAgICBpZiAoaGFzUnVuT25jZSkge1xuICAgICAgICBpZiAoIWFyZU1lcmdlZFByb3BzRXF1YWwobmV4dE1lcmdlZFByb3BzLCBtZXJnZWRQcm9wcykpXG4gICAgICAgICAgbWVyZ2VkUHJvcHMgPSBuZXh0TWVyZ2VkUHJvcHM7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBoYXNSdW5PbmNlID0gdHJ1ZTtcbiAgICAgICAgbWVyZ2VkUHJvcHMgPSBuZXh0TWVyZ2VkUHJvcHM7XG4gICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpXG4gICAgICAgICAgdmVyaWZ5UGxhaW5PYmplY3QobWVyZ2VkUHJvcHMsIGRpc3BsYXlOYW1lLCBcIm1lcmdlUHJvcHNcIik7XG4gICAgICB9XG4gICAgICByZXR1cm4gbWVyZ2VkUHJvcHM7XG4gICAgfTtcbiAgfTtcbn1cbmZ1bmN0aW9uIG1lcmdlUHJvcHNGYWN0b3J5KG1lcmdlUHJvcHMpIHtcbiAgcmV0dXJuICFtZXJnZVByb3BzID8gKCkgPT4gZGVmYXVsdE1lcmdlUHJvcHMgOiB0eXBlb2YgbWVyZ2VQcm9wcyA9PT0gXCJmdW5jdGlvblwiID8gd3JhcE1lcmdlUHJvcHNGdW5jKG1lcmdlUHJvcHMpIDogY3JlYXRlSW52YWxpZEFyZ0ZhY3RvcnkobWVyZ2VQcm9wcywgXCJtZXJnZVByb3BzXCIpO1xufVxuXG4vLyBzcmMvdXRpbHMvYmF0Y2gudHNcbmZ1bmN0aW9uIGRlZmF1bHROb29wQmF0Y2goY2FsbGJhY2spIHtcbiAgY2FsbGJhY2soKTtcbn1cblxuLy8gc3JjL3V0aWxzL1N1YnNjcmlwdGlvbi50c1xuZnVuY3Rpb24gY3JlYXRlTGlzdGVuZXJDb2xsZWN0aW9uKCkge1xuICBsZXQgZmlyc3QgPSBudWxsO1xuICBsZXQgbGFzdCA9IG51bGw7XG4gIHJldHVybiB7XG4gICAgY2xlYXIoKSB7XG4gICAgICBmaXJzdCA9IG51bGw7XG4gICAgICBsYXN0ID0gbnVsbDtcbiAgICB9LFxuICAgIG5vdGlmeSgpIHtcbiAgICAgIGRlZmF1bHROb29wQmF0Y2goKCkgPT4ge1xuICAgICAgICBsZXQgbGlzdGVuZXIgPSBmaXJzdDtcbiAgICAgICAgd2hpbGUgKGxpc3RlbmVyKSB7XG4gICAgICAgICAgbGlzdGVuZXIuY2FsbGJhY2soKTtcbiAgICAgICAgICBsaXN0ZW5lciA9IGxpc3RlbmVyLm5leHQ7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0sXG4gICAgZ2V0KCkge1xuICAgICAgY29uc3QgbGlzdGVuZXJzID0gW107XG4gICAgICBsZXQgbGlzdGVuZXIgPSBmaXJzdDtcbiAgICAgIHdoaWxlIChsaXN0ZW5lcikge1xuICAgICAgICBsaXN0ZW5lcnMucHVzaChsaXN0ZW5lcik7XG4gICAgICAgIGxpc3RlbmVyID0gbGlzdGVuZXIubmV4dDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBsaXN0ZW5lcnM7XG4gICAgfSxcbiAgICBzdWJzY3JpYmUoY2FsbGJhY2spIHtcbiAgICAgIGxldCBpc1N1YnNjcmliZWQgPSB0cnVlO1xuICAgICAgY29uc3QgbGlzdGVuZXIgPSBsYXN0ID0ge1xuICAgICAgICBjYWxsYmFjayxcbiAgICAgICAgbmV4dDogbnVsbCxcbiAgICAgICAgcHJldjogbGFzdFxuICAgICAgfTtcbiAgICAgIGlmIChsaXN0ZW5lci5wcmV2KSB7XG4gICAgICAgIGxpc3RlbmVyLnByZXYubmV4dCA9IGxpc3RlbmVyO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZmlyc3QgPSBsaXN0ZW5lcjtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmdW5jdGlvbiB1bnN1YnNjcmliZSgpIHtcbiAgICAgICAgaWYgKCFpc1N1YnNjcmliZWQgfHwgZmlyc3QgPT09IG51bGwpIHJldHVybjtcbiAgICAgICAgaXNTdWJzY3JpYmVkID0gZmFsc2U7XG4gICAgICAgIGlmIChsaXN0ZW5lci5uZXh0KSB7XG4gICAgICAgICAgbGlzdGVuZXIubmV4dC5wcmV2ID0gbGlzdGVuZXIucHJldjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsYXN0ID0gbGlzdGVuZXIucHJldjtcbiAgICAgICAgfVxuICAgICAgICBpZiAobGlzdGVuZXIucHJldikge1xuICAgICAgICAgIGxpc3RlbmVyLnByZXYubmV4dCA9IGxpc3RlbmVyLm5leHQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZmlyc3QgPSBsaXN0ZW5lci5uZXh0O1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn1cbnZhciBudWxsTGlzdGVuZXJzID0ge1xuICBub3RpZnkoKSB7XG4gIH0sXG4gIGdldDogKCkgPT4gW11cbn07XG5mdW5jdGlvbiBjcmVhdGVTdWJzY3JpcHRpb24oc3RvcmUsIHBhcmVudFN1Yikge1xuICBsZXQgdW5zdWJzY3JpYmU7XG4gIGxldCBsaXN0ZW5lcnMgPSBudWxsTGlzdGVuZXJzO1xuICBsZXQgc3Vic2NyaXB0aW9uc0Ftb3VudCA9IDA7XG4gIGxldCBzZWxmU3Vic2NyaWJlZCA9IGZhbHNlO1xuICBmdW5jdGlvbiBhZGROZXN0ZWRTdWIobGlzdGVuZXIpIHtcbiAgICB0cnlTdWJzY3JpYmUoKTtcbiAgICBjb25zdCBjbGVhbnVwTGlzdGVuZXIgPSBsaXN0ZW5lcnMuc3Vic2NyaWJlKGxpc3RlbmVyKTtcbiAgICBsZXQgcmVtb3ZlZCA9IGZhbHNlO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoIXJlbW92ZWQpIHtcbiAgICAgICAgcmVtb3ZlZCA9IHRydWU7XG4gICAgICAgIGNsZWFudXBMaXN0ZW5lcigpO1xuICAgICAgICB0cnlVbnN1YnNjcmliZSgpO1xuICAgICAgfVxuICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gbm90aWZ5TmVzdGVkU3VicygpIHtcbiAgICBsaXN0ZW5lcnMubm90aWZ5KCk7XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlQ2hhbmdlV3JhcHBlcigpIHtcbiAgICBpZiAoc3Vic2NyaXB0aW9uLm9uU3RhdGVDaGFuZ2UpIHtcbiAgICAgIHN1YnNjcmlwdGlvbi5vblN0YXRlQ2hhbmdlKCk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGlzU3Vic2NyaWJlZCgpIHtcbiAgICByZXR1cm4gc2VsZlN1YnNjcmliZWQ7XG4gIH1cbiAgZnVuY3Rpb24gdHJ5U3Vic2NyaWJlKCkge1xuICAgIHN1YnNjcmlwdGlvbnNBbW91bnQrKztcbiAgICBpZiAoIXVuc3Vic2NyaWJlKSB7XG4gICAgICB1bnN1YnNjcmliZSA9IHBhcmVudFN1YiA/IHBhcmVudFN1Yi5hZGROZXN0ZWRTdWIoaGFuZGxlQ2hhbmdlV3JhcHBlcikgOiBzdG9yZS5zdWJzY3JpYmUoaGFuZGxlQ2hhbmdlV3JhcHBlcik7XG4gICAgICBsaXN0ZW5lcnMgPSBjcmVhdGVMaXN0ZW5lckNvbGxlY3Rpb24oKTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gdHJ5VW5zdWJzY3JpYmUoKSB7XG4gICAgc3Vic2NyaXB0aW9uc0Ftb3VudC0tO1xuICAgIGlmICh1bnN1YnNjcmliZSAmJiBzdWJzY3JpcHRpb25zQW1vdW50ID09PSAwKSB7XG4gICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgdW5zdWJzY3JpYmUgPSB2b2lkIDA7XG4gICAgICBsaXN0ZW5lcnMuY2xlYXIoKTtcbiAgICAgIGxpc3RlbmVycyA9IG51bGxMaXN0ZW5lcnM7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHRyeVN1YnNjcmliZVNlbGYoKSB7XG4gICAgaWYgKCFzZWxmU3Vic2NyaWJlZCkge1xuICAgICAgc2VsZlN1YnNjcmliZWQgPSB0cnVlO1xuICAgICAgdHJ5U3Vic2NyaWJlKCk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHRyeVVuc3Vic2NyaWJlU2VsZigpIHtcbiAgICBpZiAoc2VsZlN1YnNjcmliZWQpIHtcbiAgICAgIHNlbGZTdWJzY3JpYmVkID0gZmFsc2U7XG4gICAgICB0cnlVbnN1YnNjcmliZSgpO1xuICAgIH1cbiAgfVxuICBjb25zdCBzdWJzY3JpcHRpb24gPSB7XG4gICAgYWRkTmVzdGVkU3ViLFxuICAgIG5vdGlmeU5lc3RlZFN1YnMsXG4gICAgaGFuZGxlQ2hhbmdlV3JhcHBlcixcbiAgICBpc1N1YnNjcmliZWQsXG4gICAgdHJ5U3Vic2NyaWJlOiB0cnlTdWJzY3JpYmVTZWxmLFxuICAgIHRyeVVuc3Vic2NyaWJlOiB0cnlVbnN1YnNjcmliZVNlbGYsXG4gICAgZ2V0TGlzdGVuZXJzOiAoKSA9PiBsaXN0ZW5lcnNcbiAgfTtcbiAgcmV0dXJuIHN1YnNjcmlwdGlvbjtcbn1cblxuLy8gc3JjL3V0aWxzL3VzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QudHNcbnZhciBjYW5Vc2VET00gPSAoKSA9PiAhISh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiB3aW5kb3cuZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgdHlwZW9mIHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50ICE9PSBcInVuZGVmaW5lZFwiKTtcbnZhciBpc0RPTSA9IC8qIEBfX1BVUkVfXyAqLyBjYW5Vc2VET00oKTtcbnZhciBpc1J1bm5pbmdJblJlYWN0TmF0aXZlID0gKCkgPT4gdHlwZW9mIG5hdmlnYXRvciAhPT0gXCJ1bmRlZmluZWRcIiAmJiBuYXZpZ2F0b3IucHJvZHVjdCA9PT0gXCJSZWFjdE5hdGl2ZVwiO1xudmFyIGlzUmVhY3ROYXRpdmUgPSAvKiBAX19QVVJFX18gKi8gaXNSdW5uaW5nSW5SZWFjdE5hdGl2ZSgpO1xudmFyIGdldFVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QgPSAoKSA9PiBpc0RPTSB8fCBpc1JlYWN0TmF0aXZlID8gUmVhY3QudXNlTGF5b3V0RWZmZWN0IDogUmVhY3QudXNlRWZmZWN0O1xudmFyIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QgPSAvKiBAX19QVVJFX18gKi8gZ2V0VXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgpO1xuXG4vLyBzcmMvdXRpbHMvc2hhbGxvd0VxdWFsLnRzXG5mdW5jdGlvbiBpcyh4LCB5KSB7XG4gIGlmICh4ID09PSB5KSB7XG4gICAgcmV0dXJuIHggIT09IDAgfHwgeSAhPT0gMCB8fCAxIC8geCA9PT0gMSAvIHk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHggIT09IHggJiYgeSAhPT0geTtcbiAgfVxufVxuZnVuY3Rpb24gc2hhbGxvd0VxdWFsKG9iakEsIG9iakIpIHtcbiAgaWYgKGlzKG9iakEsIG9iakIpKSByZXR1cm4gdHJ1ZTtcbiAgaWYgKHR5cGVvZiBvYmpBICE9PSBcIm9iamVjdFwiIHx8IG9iakEgPT09IG51bGwgfHwgdHlwZW9mIG9iakIgIT09IFwib2JqZWN0XCIgfHwgb2JqQiA9PT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBrZXlzQSA9IE9iamVjdC5rZXlzKG9iakEpO1xuICBjb25zdCBrZXlzQiA9IE9iamVjdC5rZXlzKG9iakIpO1xuICBpZiAoa2V5c0EubGVuZ3RoICE9PSBrZXlzQi5sZW5ndGgpIHJldHVybiBmYWxzZTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzQS5sZW5ndGg7IGkrKykge1xuICAgIGlmICghT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iakIsIGtleXNBW2ldKSB8fCAhaXMob2JqQVtrZXlzQVtpXV0sIG9iakJba2V5c0FbaV1dKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gc3JjL3V0aWxzL2hvaXN0U3RhdGljcy50c1xudmFyIFJFQUNUX1NUQVRJQ1MgPSB7XG4gIGNoaWxkQ29udGV4dFR5cGVzOiB0cnVlLFxuICBjb250ZXh0VHlwZTogdHJ1ZSxcbiAgY29udGV4dFR5cGVzOiB0cnVlLFxuICBkZWZhdWx0UHJvcHM6IHRydWUsXG4gIGRpc3BsYXlOYW1lOiB0cnVlLFxuICBnZXREZWZhdWx0UHJvcHM6IHRydWUsXG4gIGdldERlcml2ZWRTdGF0ZUZyb21FcnJvcjogdHJ1ZSxcbiAgZ2V0RGVyaXZlZFN0YXRlRnJvbVByb3BzOiB0cnVlLFxuICBtaXhpbnM6IHRydWUsXG4gIHByb3BUeXBlczogdHJ1ZSxcbiAgdHlwZTogdHJ1ZVxufTtcbnZhciBLTk9XTl9TVEFUSUNTID0ge1xuICBuYW1lOiB0cnVlLFxuICBsZW5ndGg6IHRydWUsXG4gIHByb3RvdHlwZTogdHJ1ZSxcbiAgY2FsbGVyOiB0cnVlLFxuICBjYWxsZWU6IHRydWUsXG4gIGFyZ3VtZW50czogdHJ1ZSxcbiAgYXJpdHk6IHRydWVcbn07XG52YXIgRk9SV0FSRF9SRUZfU1RBVElDUyA9IHtcbiAgJCR0eXBlb2Y6IHRydWUsXG4gIHJlbmRlcjogdHJ1ZSxcbiAgZGVmYXVsdFByb3BzOiB0cnVlLFxuICBkaXNwbGF5TmFtZTogdHJ1ZSxcbiAgcHJvcFR5cGVzOiB0cnVlXG59O1xudmFyIE1FTU9fU1RBVElDUyA9IHtcbiAgJCR0eXBlb2Y6IHRydWUsXG4gIGNvbXBhcmU6IHRydWUsXG4gIGRlZmF1bHRQcm9wczogdHJ1ZSxcbiAgZGlzcGxheU5hbWU6IHRydWUsXG4gIHByb3BUeXBlczogdHJ1ZSxcbiAgdHlwZTogdHJ1ZVxufTtcbnZhciBUWVBFX1NUQVRJQ1MgPSB7XG4gIFtGb3J3YXJkUmVmXTogRk9SV0FSRF9SRUZfU1RBVElDUyxcbiAgW01lbW9dOiBNRU1PX1NUQVRJQ1Ncbn07XG5mdW5jdGlvbiBnZXRTdGF0aWNzKGNvbXBvbmVudCkge1xuICBpZiAoaXNNZW1vKGNvbXBvbmVudCkpIHtcbiAgICByZXR1cm4gTUVNT19TVEFUSUNTO1xuICB9XG4gIHJldHVybiBUWVBFX1NUQVRJQ1NbY29tcG9uZW50W1wiJCR0eXBlb2ZcIl1dIHx8IFJFQUNUX1NUQVRJQ1M7XG59XG52YXIgZGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgZ2V0T3duUHJvcGVydHlOYW1lcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzO1xudmFyIGdldE93blByb3BlcnR5U3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHM7XG52YXIgZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcbnZhciBnZXRQcm90b3R5cGVPZiA9IE9iamVjdC5nZXRQcm90b3R5cGVPZjtcbnZhciBvYmplY3RQcm90b3R5cGUgPSBPYmplY3QucHJvdG90eXBlO1xuZnVuY3Rpb24gaG9pc3ROb25SZWFjdFN0YXRpY3ModGFyZ2V0Q29tcG9uZW50LCBzb3VyY2VDb21wb25lbnQpIHtcbiAgaWYgKHR5cGVvZiBzb3VyY2VDb21wb25lbnQgIT09IFwic3RyaW5nXCIpIHtcbiAgICBpZiAob2JqZWN0UHJvdG90eXBlKSB7XG4gICAgICBjb25zdCBpbmhlcml0ZWRDb21wb25lbnQgPSBnZXRQcm90b3R5cGVPZihzb3VyY2VDb21wb25lbnQpO1xuICAgICAgaWYgKGluaGVyaXRlZENvbXBvbmVudCAmJiBpbmhlcml0ZWRDb21wb25lbnQgIT09IG9iamVjdFByb3RvdHlwZSkge1xuICAgICAgICBob2lzdE5vblJlYWN0U3RhdGljcyh0YXJnZXRDb21wb25lbnQsIGluaGVyaXRlZENvbXBvbmVudCk7XG4gICAgICB9XG4gICAgfVxuICAgIGxldCBrZXlzID0gZ2V0T3duUHJvcGVydHlOYW1lcyhzb3VyY2VDb21wb25lbnQpO1xuICAgIGlmIChnZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICAgIGtleXMgPSBrZXlzLmNvbmNhdChnZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlQ29tcG9uZW50KSk7XG4gICAgfVxuICAgIGNvbnN0IHRhcmdldFN0YXRpY3MgPSBnZXRTdGF0aWNzKHRhcmdldENvbXBvbmVudCk7XG4gICAgY29uc3Qgc291cmNlU3RhdGljcyA9IGdldFN0YXRpY3Moc291cmNlQ29tcG9uZW50KTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpIHtcbiAgICAgIGNvbnN0IGtleSA9IGtleXNbaV07XG4gICAgICBpZiAoIUtOT1dOX1NUQVRJQ1Nba2V5XSAmJiAhKHNvdXJjZVN0YXRpY3MgJiYgc291cmNlU3RhdGljc1trZXldKSAmJiAhKHRhcmdldFN0YXRpY3MgJiYgdGFyZ2V0U3RhdGljc1trZXldKSkge1xuICAgICAgICBjb25zdCBkZXNjcmlwdG9yID0gZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNvdXJjZUNvbXBvbmVudCwga2V5KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBkZWZpbmVQcm9wZXJ0eSh0YXJnZXRDb21wb25lbnQsIGtleSwgZGVzY3JpcHRvcik7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gdGFyZ2V0Q29tcG9uZW50O1xufVxuXG4vLyBzcmMvY29tcG9uZW50cy9Db250ZXh0LnRzXG52YXIgQ29udGV4dEtleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKGByZWFjdC1yZWR1eC1jb250ZXh0YCk7XG52YXIgZ1QgPSB0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbFRoaXMgOiAoXG4gIC8qIGZhbGwgYmFjayB0byBhIHBlci1tb2R1bGUgc2NvcGUgKHByZS04LjEgYmVoYXZpb3VyKSBpZiBgZ2xvYmFsVGhpc2AgaXMgbm90IGF2YWlsYWJsZSAqL1xuICB7fVxuKTtcbmZ1bmN0aW9uIGdldENvbnRleHQoKSB7XG4gIGlmICghUmVhY3QuY3JlYXRlQ29udGV4dCkgcmV0dXJuIHt9O1xuICBjb25zdCBjb250ZXh0TWFwID0gZ1RbQ29udGV4dEtleV0gPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIGxldCByZWFsQ29udGV4dCA9IGNvbnRleHRNYXAuZ2V0KFJlYWN0LmNyZWF0ZUNvbnRleHQpO1xuICBpZiAoIXJlYWxDb250ZXh0KSB7XG4gICAgcmVhbENvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KFxuICAgICAgbnVsbFxuICAgICk7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgcmVhbENvbnRleHQuZGlzcGxheU5hbWUgPSBcIlJlYWN0UmVkdXhcIjtcbiAgICB9XG4gICAgY29udGV4dE1hcC5zZXQoUmVhY3QuY3JlYXRlQ29udGV4dCwgcmVhbENvbnRleHQpO1xuICB9XG4gIHJldHVybiByZWFsQ29udGV4dDtcbn1cbnZhciBSZWFjdFJlZHV4Q29udGV4dCA9IC8qIEBfX1BVUkVfXyAqLyBnZXRDb250ZXh0KCk7XG5cbi8vIHNyYy9jb21wb25lbnRzL2Nvbm5lY3QudHN4XG52YXIgTk9fU1VCU0NSSVBUSU9OX0FSUkFZID0gW251bGwsIG51bGxdO1xudmFyIHN0cmluZ2lmeUNvbXBvbmVudCA9IChDb21wKSA9PiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KENvbXApO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICByZXR1cm4gU3RyaW5nKENvbXApO1xuICB9XG59O1xuZnVuY3Rpb24gdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdFdpdGhBcmdzKGVmZmVjdEZ1bmMsIGVmZmVjdEFyZ3MsIGRlcGVuZGVuY2llcykge1xuICB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0KCgpID0+IGVmZmVjdEZ1bmMoLi4uZWZmZWN0QXJncyksIGRlcGVuZGVuY2llcyk7XG59XG5mdW5jdGlvbiBjYXB0dXJlV3JhcHBlclByb3BzKGxhc3RXcmFwcGVyUHJvcHMsIGxhc3RDaGlsZFByb3BzLCByZW5kZXJJc1NjaGVkdWxlZCwgd3JhcHBlclByb3BzLCBjaGlsZFByb3BzRnJvbVN0b3JlVXBkYXRlLCBub3RpZnlOZXN0ZWRTdWJzKSB7XG4gIGxhc3RXcmFwcGVyUHJvcHMuY3VycmVudCA9IHdyYXBwZXJQcm9wcztcbiAgcmVuZGVySXNTY2hlZHVsZWQuY3VycmVudCA9IGZhbHNlO1xuICBpZiAoY2hpbGRQcm9wc0Zyb21TdG9yZVVwZGF0ZS5jdXJyZW50KSB7XG4gICAgY2hpbGRQcm9wc0Zyb21TdG9yZVVwZGF0ZS5jdXJyZW50ID0gbnVsbDtcbiAgICBub3RpZnlOZXN0ZWRTdWJzKCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHN1YnNjcmliZVVwZGF0ZXMoc2hvdWxkSGFuZGxlU3RhdGVDaGFuZ2VzLCBzdG9yZSwgc3Vic2NyaXB0aW9uLCBjaGlsZFByb3BzU2VsZWN0b3IsIGxhc3RXcmFwcGVyUHJvcHMsIGxhc3RDaGlsZFByb3BzLCByZW5kZXJJc1NjaGVkdWxlZCwgaXNNb3VudGVkLCBjaGlsZFByb3BzRnJvbVN0b3JlVXBkYXRlLCBub3RpZnlOZXN0ZWRTdWJzLCBhZGRpdGlvbmFsU3Vic2NyaWJlTGlzdGVuZXIpIHtcbiAgaWYgKCFzaG91bGRIYW5kbGVTdGF0ZUNoYW5nZXMpIHJldHVybiAoKSA9PiB7XG4gIH07XG4gIGxldCBkaWRVbnN1YnNjcmliZSA9IGZhbHNlO1xuICBsZXQgbGFzdFRocm93bkVycm9yID0gbnVsbDtcbiAgY29uc3QgY2hlY2tGb3JVcGRhdGVzID0gKCkgPT4ge1xuICAgIGlmIChkaWRVbnN1YnNjcmliZSB8fCAhaXNNb3VudGVkLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbGF0ZXN0U3RvcmVTdGF0ZSA9IHN0b3JlLmdldFN0YXRlKCk7XG4gICAgbGV0IG5ld0NoaWxkUHJvcHMsIGVycm9yO1xuICAgIHRyeSB7XG4gICAgICBuZXdDaGlsZFByb3BzID0gY2hpbGRQcm9wc1NlbGVjdG9yKFxuICAgICAgICBsYXRlc3RTdG9yZVN0YXRlLFxuICAgICAgICBsYXN0V3JhcHBlclByb3BzLmN1cnJlbnRcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgZXJyb3IgPSBlO1xuICAgICAgbGFzdFRocm93bkVycm9yID0gZTtcbiAgICB9XG4gICAgaWYgKCFlcnJvcikge1xuICAgICAgbGFzdFRocm93bkVycm9yID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKG5ld0NoaWxkUHJvcHMgPT09IGxhc3RDaGlsZFByb3BzLmN1cnJlbnQpIHtcbiAgICAgIGlmICghcmVuZGVySXNTY2hlZHVsZWQuY3VycmVudCkge1xuICAgICAgICBub3RpZnlOZXN0ZWRTdWJzKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGxhc3RDaGlsZFByb3BzLmN1cnJlbnQgPSBuZXdDaGlsZFByb3BzO1xuICAgICAgY2hpbGRQcm9wc0Zyb21TdG9yZVVwZGF0ZS5jdXJyZW50ID0gbmV3Q2hpbGRQcm9wcztcbiAgICAgIHJlbmRlcklzU2NoZWR1bGVkLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgYWRkaXRpb25hbFN1YnNjcmliZUxpc3RlbmVyKCk7XG4gICAgfVxuICB9O1xuICBzdWJzY3JpcHRpb24ub25TdGF0ZUNoYW5nZSA9IGNoZWNrRm9yVXBkYXRlcztcbiAgc3Vic2NyaXB0aW9uLnRyeVN1YnNjcmliZSgpO1xuICBjaGVja0ZvclVwZGF0ZXMoKTtcbiAgY29uc3QgdW5zdWJzY3JpYmVXcmFwcGVyID0gKCkgPT4ge1xuICAgIGRpZFVuc3Vic2NyaWJlID0gdHJ1ZTtcbiAgICBzdWJzY3JpcHRpb24udHJ5VW5zdWJzY3JpYmUoKTtcbiAgICBzdWJzY3JpcHRpb24ub25TdGF0ZUNoYW5nZSA9IG51bGw7XG4gICAgaWYgKGxhc3RUaHJvd25FcnJvcikge1xuICAgICAgdGhyb3cgbGFzdFRocm93bkVycm9yO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIHVuc3Vic2NyaWJlV3JhcHBlcjtcbn1cbmZ1bmN0aW9uIHN0cmljdEVxdWFsKGEsIGIpIHtcbiAgcmV0dXJuIGEgPT09IGI7XG59XG52YXIgaGFzV2FybmVkQWJvdXREZXByZWNhdGVkUHVyZU9wdGlvbiA9IGZhbHNlO1xuZnVuY3Rpb24gX2Nvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMsIG1lcmdlUHJvcHMsIHtcbiAgLy8gVGhlIGBwdXJlYCBvcHRpb24gaGFzIGJlZW4gcmVtb3ZlZCwgc28gVFMgZG9lc24ndCBsaWtlIHVzIGRlc3RydWN0dXJpbmcgdGhpcyB0byBjaGVjayBpdHMgZXhpc3RlbmNlLlxuICAvLyBAdHMtaWdub3JlXG4gIHB1cmUsXG4gIGFyZVN0YXRlc0VxdWFsID0gc3RyaWN0RXF1YWwsXG4gIGFyZU93blByb3BzRXF1YWwgPSBzaGFsbG93RXF1YWwsXG4gIGFyZVN0YXRlUHJvcHNFcXVhbCA9IHNoYWxsb3dFcXVhbCxcbiAgYXJlTWVyZ2VkUHJvcHNFcXVhbCA9IHNoYWxsb3dFcXVhbCxcbiAgLy8gdXNlIFJlYWN0J3MgZm9yd2FyZFJlZiB0byBleHBvc2UgYSByZWYgb2YgdGhlIHdyYXBwZWQgY29tcG9uZW50XG4gIGZvcndhcmRSZWYgPSBmYWxzZSxcbiAgLy8gdGhlIGNvbnRleHQgY29uc3VtZXIgdG8gdXNlXG4gIGNvbnRleHQgPSBSZWFjdFJlZHV4Q29udGV4dFxufSA9IHt9KSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICBpZiAocHVyZSAhPT0gdm9pZCAwICYmICFoYXNXYXJuZWRBYm91dERlcHJlY2F0ZWRQdXJlT3B0aW9uKSB7XG4gICAgICBoYXNXYXJuZWRBYm91dERlcHJlY2F0ZWRQdXJlT3B0aW9uID0gdHJ1ZTtcbiAgICAgIHdhcm5pbmcoXG4gICAgICAgICdUaGUgYHB1cmVgIG9wdGlvbiBoYXMgYmVlbiByZW1vdmVkLiBgY29ubmVjdGAgaXMgbm93IGFsd2F5cyBhIFwicHVyZS9tZW1vaXplZFwiIGNvbXBvbmVudCdcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGNvbnN0IENvbnRleHQgPSBjb250ZXh0O1xuICBjb25zdCBpbml0TWFwU3RhdGVUb1Byb3BzID0gbWFwU3RhdGVUb1Byb3BzRmFjdG9yeShtYXBTdGF0ZVRvUHJvcHMpO1xuICBjb25zdCBpbml0TWFwRGlzcGF0Y2hUb1Byb3BzID0gbWFwRGlzcGF0Y2hUb1Byb3BzRmFjdG9yeShtYXBEaXNwYXRjaFRvUHJvcHMpO1xuICBjb25zdCBpbml0TWVyZ2VQcm9wcyA9IG1lcmdlUHJvcHNGYWN0b3J5KG1lcmdlUHJvcHMpO1xuICBjb25zdCBzaG91bGRIYW5kbGVTdGF0ZUNoYW5nZXMgPSBCb29sZWFuKG1hcFN0YXRlVG9Qcm9wcyk7XG4gIGNvbnN0IHdyYXBXaXRoQ29ubmVjdCA9IChXcmFwcGVkQ29tcG9uZW50KSA9PiB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgY29uc3QgaXNWYWxpZCA9IC8qIEBfX1BVUkVfXyAqLyBpc1ZhbGlkRWxlbWVudFR5cGUoV3JhcHBlZENvbXBvbmVudCk7XG4gICAgICBpZiAoIWlzVmFsaWQpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICBgWW91IG11c3QgcGFzcyBhIGNvbXBvbmVudCB0byB0aGUgZnVuY3Rpb24gcmV0dXJuZWQgYnkgY29ubmVjdC4gSW5zdGVhZCByZWNlaXZlZCAke3N0cmluZ2lmeUNvbXBvbmVudChcbiAgICAgICAgICAgIFdyYXBwZWRDb21wb25lbnRcbiAgICAgICAgICApfWBcbiAgICAgICAgKTtcbiAgICB9XG4gICAgY29uc3Qgd3JhcHBlZENvbXBvbmVudE5hbWUgPSBXcmFwcGVkQ29tcG9uZW50LmRpc3BsYXlOYW1lIHx8IFdyYXBwZWRDb21wb25lbnQubmFtZSB8fCBcIkNvbXBvbmVudFwiO1xuICAgIGNvbnN0IGRpc3BsYXlOYW1lID0gYENvbm5lY3QoJHt3cmFwcGVkQ29tcG9uZW50TmFtZX0pYDtcbiAgICBjb25zdCBzZWxlY3RvckZhY3RvcnlPcHRpb25zID0ge1xuICAgICAgc2hvdWxkSGFuZGxlU3RhdGVDaGFuZ2VzLFxuICAgICAgZGlzcGxheU5hbWUsXG4gICAgICB3cmFwcGVkQ29tcG9uZW50TmFtZSxcbiAgICAgIFdyYXBwZWRDb21wb25lbnQsXG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBpbml0TWFwU3RhdGVUb1Byb3BzLFxuICAgICAgaW5pdE1hcERpc3BhdGNoVG9Qcm9wcyxcbiAgICAgIGluaXRNZXJnZVByb3BzLFxuICAgICAgYXJlU3RhdGVzRXF1YWwsXG4gICAgICBhcmVTdGF0ZVByb3BzRXF1YWwsXG4gICAgICBhcmVPd25Qcm9wc0VxdWFsLFxuICAgICAgYXJlTWVyZ2VkUHJvcHNFcXVhbFxuICAgIH07XG4gICAgZnVuY3Rpb24gQ29ubmVjdEZ1bmN0aW9uKHByb3BzKSB7XG4gICAgICBjb25zdCBbcHJvcHNDb250ZXh0LCByZWFjdFJlZHV4Rm9yd2FyZGVkUmVmLCB3cmFwcGVyUHJvcHNdID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgcmVhY3RSZWR1eEZvcndhcmRlZFJlZjogcmVhY3RSZWR1eEZvcndhcmRlZFJlZjIsIC4uLndyYXBwZXJQcm9wczIgfSA9IHByb3BzO1xuICAgICAgICByZXR1cm4gW3Byb3BzLmNvbnRleHQsIHJlYWN0UmVkdXhGb3J3YXJkZWRSZWYyLCB3cmFwcGVyUHJvcHMyXTtcbiAgICAgIH0sIFtwcm9wc10pO1xuICAgICAgY29uc3QgQ29udGV4dFRvVXNlID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGxldCBSZXN1bHRDb250ZXh0ID0gQ29udGV4dDtcbiAgICAgICAgaWYgKHByb3BzQ29udGV4dD8uQ29uc3VtZXIpIHtcbiAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgICAgICBjb25zdCBpc1ZhbGlkID0gLyogQF9fUFVSRV9fICovIGlzQ29udGV4dENvbnN1bWVyKFxuICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICAgIC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5jcmVhdGVFbGVtZW50KHByb3BzQ29udGV4dC5Db25zdW1lciwgbnVsbClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAoIWlzVmFsaWQpIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAgIFwiWW91IG11c3QgcGFzcyBhIHZhbGlkIFJlYWN0IGNvbnRleHQgY29uc3VtZXIgYXMgYHByb3BzLmNvbnRleHRgXCJcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFJlc3VsdENvbnRleHQgPSBwcm9wc0NvbnRleHQ7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBSZXN1bHRDb250ZXh0O1xuICAgICAgfSwgW3Byb3BzQ29udGV4dCwgQ29udGV4dF0pO1xuICAgICAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlQ29udGV4dChDb250ZXh0VG9Vc2UpO1xuICAgICAgY29uc3QgZGlkU3RvcmVDb21lRnJvbVByb3BzID0gQm9vbGVhbihwcm9wcy5zdG9yZSkgJiYgQm9vbGVhbihwcm9wcy5zdG9yZS5nZXRTdGF0ZSkgJiYgQm9vbGVhbihwcm9wcy5zdG9yZS5kaXNwYXRjaCk7XG4gICAgICBjb25zdCBkaWRTdG9yZUNvbWVGcm9tQ29udGV4dCA9IEJvb2xlYW4oY29udGV4dFZhbHVlKSAmJiBCb29sZWFuKGNvbnRleHRWYWx1ZS5zdG9yZSk7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFkaWRTdG9yZUNvbWVGcm9tUHJvcHMgJiYgIWRpZFN0b3JlQ29tZUZyb21Db250ZXh0KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICBgQ291bGQgbm90IGZpbmQgXCJzdG9yZVwiIGluIHRoZSBjb250ZXh0IG9mIFwiJHtkaXNwbGF5TmFtZX1cIi4gRWl0aGVyIHdyYXAgdGhlIHJvb3QgY29tcG9uZW50IGluIGEgPFByb3ZpZGVyPiwgb3IgcGFzcyBhIGN1c3RvbSBSZWFjdCBjb250ZXh0IHByb3ZpZGVyIHRvIDxQcm92aWRlcj4gYW5kIHRoZSBjb3JyZXNwb25kaW5nIFJlYWN0IGNvbnRleHQgY29uc3VtZXIgdG8gJHtkaXNwbGF5TmFtZX0gaW4gY29ubmVjdCBvcHRpb25zLmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHN0b3JlID0gZGlkU3RvcmVDb21lRnJvbVByb3BzID8gcHJvcHMuc3RvcmUgOiBjb250ZXh0VmFsdWUuc3RvcmU7XG4gICAgICBjb25zdCBnZXRTZXJ2ZXJTdGF0ZSA9IGRpZFN0b3JlQ29tZUZyb21Db250ZXh0ID8gY29udGV4dFZhbHVlLmdldFNlcnZlclN0YXRlIDogc3RvcmUuZ2V0U3RhdGU7XG4gICAgICBjb25zdCBjaGlsZFByb3BzU2VsZWN0b3IgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICAgICAgcmV0dXJuIGZpbmFsUHJvcHNTZWxlY3RvckZhY3Rvcnkoc3RvcmUuZGlzcGF0Y2gsIHNlbGVjdG9yRmFjdG9yeU9wdGlvbnMpO1xuICAgICAgfSwgW3N0b3JlXSk7XG4gICAgICBjb25zdCBbc3Vic2NyaXB0aW9uLCBub3RpZnlOZXN0ZWRTdWJzXSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoIXNob3VsZEhhbmRsZVN0YXRlQ2hhbmdlcykgcmV0dXJuIE5PX1NVQlNDUklQVElPTl9BUlJBWTtcbiAgICAgICAgY29uc3Qgc3Vic2NyaXB0aW9uMiA9IGNyZWF0ZVN1YnNjcmlwdGlvbihcbiAgICAgICAgICBzdG9yZSxcbiAgICAgICAgICBkaWRTdG9yZUNvbWVGcm9tUHJvcHMgPyB2b2lkIDAgOiBjb250ZXh0VmFsdWUuc3Vic2NyaXB0aW9uXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IG5vdGlmeU5lc3RlZFN1YnMyID0gc3Vic2NyaXB0aW9uMi5ub3RpZnlOZXN0ZWRTdWJzLmJpbmQoc3Vic2NyaXB0aW9uMik7XG4gICAgICAgIHJldHVybiBbc3Vic2NyaXB0aW9uMiwgbm90aWZ5TmVzdGVkU3ViczJdO1xuICAgICAgfSwgW3N0b3JlLCBkaWRTdG9yZUNvbWVGcm9tUHJvcHMsIGNvbnRleHRWYWx1ZV0pO1xuICAgICAgY29uc3Qgb3ZlcnJpZGRlbkNvbnRleHRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoZGlkU3RvcmVDb21lRnJvbVByb3BzKSB7XG4gICAgICAgICAgcmV0dXJuIGNvbnRleHRWYWx1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLmNvbnRleHRWYWx1ZSxcbiAgICAgICAgICBzdWJzY3JpcHRpb25cbiAgICAgICAgfTtcbiAgICAgIH0sIFtkaWRTdG9yZUNvbWVGcm9tUHJvcHMsIGNvbnRleHRWYWx1ZSwgc3Vic2NyaXB0aW9uXSk7XG4gICAgICBjb25zdCBsYXN0Q2hpbGRQcm9wcyA9IFJlYWN0LnVzZVJlZih2b2lkIDApO1xuICAgICAgY29uc3QgbGFzdFdyYXBwZXJQcm9wcyA9IFJlYWN0LnVzZVJlZih3cmFwcGVyUHJvcHMpO1xuICAgICAgY29uc3QgY2hpbGRQcm9wc0Zyb21TdG9yZVVwZGF0ZSA9IFJlYWN0LnVzZVJlZih2b2lkIDApO1xuICAgICAgY29uc3QgcmVuZGVySXNTY2hlZHVsZWQgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgICAgY29uc3QgaXNNb3VudGVkID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICAgIGNvbnN0IGxhdGVzdFN1YnNjcmlwdGlvbkNhbGxiYWNrRXJyb3IgPSBSZWFjdC51c2VSZWYoXG4gICAgICAgIHZvaWQgMFxuICAgICAgKTtcbiAgICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpc01vdW50ZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgaXNNb3VudGVkLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfTtcbiAgICAgIH0sIFtdKTtcbiAgICAgIGNvbnN0IGFjdHVhbENoaWxkUHJvcHNTZWxlY3RvciA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBzZWxlY3RvciA9ICgpID0+IHtcbiAgICAgICAgICBpZiAoY2hpbGRQcm9wc0Zyb21TdG9yZVVwZGF0ZS5jdXJyZW50ICYmIHdyYXBwZXJQcm9wcyA9PT0gbGFzdFdyYXBwZXJQcm9wcy5jdXJyZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gY2hpbGRQcm9wc0Zyb21TdG9yZVVwZGF0ZS5jdXJyZW50O1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gY2hpbGRQcm9wc1NlbGVjdG9yKHN0b3JlLmdldFN0YXRlKCksIHdyYXBwZXJQcm9wcyk7XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBzZWxlY3RvcjtcbiAgICAgIH0sIFtzdG9yZSwgd3JhcHBlclByb3BzXSk7XG4gICAgICBjb25zdCBzdWJzY3JpYmVGb3JSZWFjdCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCBzdWJzY3JpYmUgPSAocmVhY3RMaXN0ZW5lcikgPT4ge1xuICAgICAgICAgIGlmICghc3Vic2NyaXB0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHN1YnNjcmliZVVwZGF0ZXMoXG4gICAgICAgICAgICBzaG91bGRIYW5kbGVTdGF0ZUNoYW5nZXMsXG4gICAgICAgICAgICBzdG9yZSxcbiAgICAgICAgICAgIHN1YnNjcmlwdGlvbixcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgIGNoaWxkUHJvcHNTZWxlY3RvcixcbiAgICAgICAgICAgIGxhc3RXcmFwcGVyUHJvcHMsXG4gICAgICAgICAgICBsYXN0Q2hpbGRQcm9wcyxcbiAgICAgICAgICAgIHJlbmRlcklzU2NoZWR1bGVkLFxuICAgICAgICAgICAgaXNNb3VudGVkLFxuICAgICAgICAgICAgY2hpbGRQcm9wc0Zyb21TdG9yZVVwZGF0ZSxcbiAgICAgICAgICAgIG5vdGlmeU5lc3RlZFN1YnMsXG4gICAgICAgICAgICByZWFjdExpc3RlbmVyXG4gICAgICAgICAgKTtcbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIHN1YnNjcmliZTtcbiAgICAgIH0sIFtzdWJzY3JpcHRpb25dKTtcbiAgICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3RXaXRoQXJncyhjYXB0dXJlV3JhcHBlclByb3BzLCBbXG4gICAgICAgIGxhc3RXcmFwcGVyUHJvcHMsXG4gICAgICAgIGxhc3RDaGlsZFByb3BzLFxuICAgICAgICByZW5kZXJJc1NjaGVkdWxlZCxcbiAgICAgICAgd3JhcHBlclByb3BzLFxuICAgICAgICBjaGlsZFByb3BzRnJvbVN0b3JlVXBkYXRlLFxuICAgICAgICBub3RpZnlOZXN0ZWRTdWJzXG4gICAgICBdKTtcbiAgICAgIGxldCBhY3R1YWxDaGlsZFByb3BzO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYWN0dWFsQ2hpbGRQcm9wcyA9IFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFxuICAgICAgICAgIC8vIFRPRE8gV2UncmUgcGFzc2luZyB0aHJvdWdoIGEgYmlnIHdyYXBwZXIgdGhhdCBkb2VzIGEgYnVuY2ggb2YgZXh0cmEgc2lkZSBlZmZlY3RzIGJlc2lkZXMgc3Vic2NyaWJpbmdcbiAgICAgICAgICBzdWJzY3JpYmVGb3JSZWFjdCxcbiAgICAgICAgICAvLyBUT0RPIFRoaXMgaXMgaW5jcmVkaWJseSBoYWNreS4gV2UndmUgYWxyZWFkeSBwcm9jZXNzZWQgdGhlIHN0b3JlIHVwZGF0ZSBhbmQgY2FsY3VsYXRlZCBuZXcgY2hpbGQgcHJvcHMsXG4gICAgICAgICAgLy8gVE9ETyBhbmQgd2UncmUganVzdCBwYXNzaW5nIHRoYXQgdGhyb3VnaCBzbyBpdCB0cmlnZ2VycyBhIHJlLXJlbmRlciBmb3IgdXMgcmF0aGVyIHRoYW4gcmVseWluZyBvbiBgdVNFU2AuXG4gICAgICAgICAgYWN0dWFsQ2hpbGRQcm9wc1NlbGVjdG9yLFxuICAgICAgICAgIGdldFNlcnZlclN0YXRlID8gKCkgPT4gY2hpbGRQcm9wc1NlbGVjdG9yKGdldFNlcnZlclN0YXRlKCksIHdyYXBwZXJQcm9wcykgOiBhY3R1YWxDaGlsZFByb3BzU2VsZWN0b3JcbiAgICAgICAgKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBpZiAobGF0ZXN0U3Vic2NyaXB0aW9uQ2FsbGJhY2tFcnJvci5jdXJyZW50KSB7XG4gICAgICAgICAgO1xuICAgICAgICAgIGVyci5tZXNzYWdlICs9IGBcblRoZSBlcnJvciBtYXkgYmUgY29ycmVsYXRlZCB3aXRoIHRoaXMgcHJldmlvdXMgZXJyb3I6XG4ke2xhdGVzdFN1YnNjcmlwdGlvbkNhbGxiYWNrRXJyb3IuY3VycmVudC5zdGFja31cblxuYDtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgICB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgbGF0ZXN0U3Vic2NyaXB0aW9uQ2FsbGJhY2tFcnJvci5jdXJyZW50ID0gdm9pZCAwO1xuICAgICAgICBjaGlsZFByb3BzRnJvbVN0b3JlVXBkYXRlLmN1cnJlbnQgPSB2b2lkIDA7XG4gICAgICAgIGxhc3RDaGlsZFByb3BzLmN1cnJlbnQgPSBhY3R1YWxDaGlsZFByb3BzO1xuICAgICAgfSk7XG4gICAgICBjb25zdCByZW5kZXJlZFdyYXBwZWRDb21wb25lbnQgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgLyogQF9fUFVSRV9fICovIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICAgICAgICBXcmFwcGVkQ29tcG9uZW50LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAuLi5hY3R1YWxDaGlsZFByb3BzLFxuICAgICAgICAgICAgICByZWY6IHJlYWN0UmVkdXhGb3J3YXJkZWRSZWZcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApXG4gICAgICAgICk7XG4gICAgICB9LCBbcmVhY3RSZWR1eEZvcndhcmRlZFJlZiwgV3JhcHBlZENvbXBvbmVudCwgYWN0dWFsQ2hpbGRQcm9wc10pO1xuICAgICAgY29uc3QgcmVuZGVyZWRDaGlsZCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoc2hvdWxkSGFuZGxlU3RhdGVDaGFuZ2VzKSB7XG4gICAgICAgICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5jcmVhdGVFbGVtZW50KENvbnRleHRUb1VzZS5Qcm92aWRlciwgeyB2YWx1ZTogb3ZlcnJpZGRlbkNvbnRleHRWYWx1ZSB9LCByZW5kZXJlZFdyYXBwZWRDb21wb25lbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZW5kZXJlZFdyYXBwZWRDb21wb25lbnQ7XG4gICAgICB9LCBbQ29udGV4dFRvVXNlLCByZW5kZXJlZFdyYXBwZWRDb21wb25lbnQsIG92ZXJyaWRkZW5Db250ZXh0VmFsdWVdKTtcbiAgICAgIHJldHVybiByZW5kZXJlZENoaWxkO1xuICAgIH1cbiAgICBjb25zdCBfQ29ubmVjdCA9IFJlYWN0Lm1lbW8oQ29ubmVjdEZ1bmN0aW9uKTtcbiAgICBjb25zdCBDb25uZWN0ID0gX0Nvbm5lY3Q7XG4gICAgQ29ubmVjdC5XcmFwcGVkQ29tcG9uZW50ID0gV3JhcHBlZENvbXBvbmVudDtcbiAgICBDb25uZWN0LmRpc3BsYXlOYW1lID0gQ29ubmVjdEZ1bmN0aW9uLmRpc3BsYXlOYW1lID0gZGlzcGxheU5hbWU7XG4gICAgaWYgKGZvcndhcmRSZWYpIHtcbiAgICAgIGNvbnN0IF9mb3J3YXJkZWQgPSBSZWFjdC5mb3J3YXJkUmVmKFxuICAgICAgICBmdW5jdGlvbiBmb3J3YXJkQ29ubmVjdFJlZihwcm9wcywgcmVmKSB7XG4gICAgICAgICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5jcmVhdGVFbGVtZW50KENvbm5lY3QsIHsgLi4ucHJvcHMsIHJlYWN0UmVkdXhGb3J3YXJkZWRSZWY6IHJlZiB9KTtcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICAgIGNvbnN0IGZvcndhcmRlZCA9IF9mb3J3YXJkZWQ7XG4gICAgICBmb3J3YXJkZWQuZGlzcGxheU5hbWUgPSBkaXNwbGF5TmFtZTtcbiAgICAgIGZvcndhcmRlZC5XcmFwcGVkQ29tcG9uZW50ID0gV3JhcHBlZENvbXBvbmVudDtcbiAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8gaG9pc3ROb25SZWFjdFN0YXRpY3MoZm9yd2FyZGVkLCBXcmFwcGVkQ29tcG9uZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBob2lzdE5vblJlYWN0U3RhdGljcyhDb25uZWN0LCBXcmFwcGVkQ29tcG9uZW50KTtcbiAgfTtcbiAgcmV0dXJuIHdyYXBXaXRoQ29ubmVjdDtcbn1cbnZhciBjb25uZWN0ID0gX2Nvbm5lY3Q7XG52YXIgbGVnYWN5X2Nvbm5lY3QgPSBfY29ubmVjdDtcblxuLy8gc3JjL2NvbXBvbmVudHMvUHJvdmlkZXIudHN4XG5mdW5jdGlvbiBQcm92aWRlcihwcm92aWRlclByb3BzKSB7XG4gIGNvbnN0IHsgY2hpbGRyZW4sIGNvbnRleHQsIHNlcnZlclN0YXRlLCBzdG9yZSB9ID0gcHJvdmlkZXJQcm9wcztcbiAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3Qgc3Vic2NyaXB0aW9uID0gY3JlYXRlU3Vic2NyaXB0aW9uKHN0b3JlKTtcbiAgICBjb25zdCBiYXNlQ29udGV4dFZhbHVlID0ge1xuICAgICAgc3RvcmUsXG4gICAgICBzdWJzY3JpcHRpb24sXG4gICAgICBnZXRTZXJ2ZXJTdGF0ZTogc2VydmVyU3RhdGUgPyAoKSA9PiBzZXJ2ZXJTdGF0ZSA6IHZvaWQgMFxuICAgIH07XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgcmV0dXJuIGJhc2VDb250ZXh0VmFsdWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHsgaWRlbnRpdHlGdW5jdGlvbkNoZWNrID0gXCJvbmNlXCIsIHN0YWJpbGl0eUNoZWNrID0gXCJvbmNlXCIgfSA9IHByb3ZpZGVyUHJvcHM7XG4gICAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIE9iamVjdC5hc3NpZ24oYmFzZUNvbnRleHRWYWx1ZSwge1xuICAgICAgICBzdGFiaWxpdHlDaGVjayxcbiAgICAgICAgaWRlbnRpdHlGdW5jdGlvbkNoZWNrXG4gICAgICB9KTtcbiAgICB9XG4gIH0sIFtzdG9yZSwgc2VydmVyU3RhdGVdKTtcbiAgY29uc3QgcHJldmlvdXNTdGF0ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gc3RvcmUuZ2V0U3RhdGUoKSwgW3N0b3JlXSk7XG4gIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHsgc3Vic2NyaXB0aW9uIH0gPSBjb250ZXh0VmFsdWU7XG4gICAgc3Vic2NyaXB0aW9uLm9uU3RhdGVDaGFuZ2UgPSBzdWJzY3JpcHRpb24ubm90aWZ5TmVzdGVkU3VicztcbiAgICBzdWJzY3JpcHRpb24udHJ5U3Vic2NyaWJlKCk7XG4gICAgaWYgKHByZXZpb3VzU3RhdGUgIT09IHN0b3JlLmdldFN0YXRlKCkpIHtcbiAgICAgIHN1YnNjcmlwdGlvbi5ub3RpZnlOZXN0ZWRTdWJzKCk7XG4gICAgfVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBzdWJzY3JpcHRpb24udHJ5VW5zdWJzY3JpYmUoKTtcbiAgICAgIHN1YnNjcmlwdGlvbi5vblN0YXRlQ2hhbmdlID0gdm9pZCAwO1xuICAgIH07XG4gIH0sIFtjb250ZXh0VmFsdWUsIHByZXZpb3VzU3RhdGVdKTtcbiAgY29uc3QgQ29udGV4dCA9IGNvbnRleHQgfHwgUmVhY3RSZWR1eENvbnRleHQ7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8gUmVhY3QuY3JlYXRlRWxlbWVudChDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBjb250ZXh0VmFsdWUgfSwgY2hpbGRyZW4pO1xufVxudmFyIFByb3ZpZGVyX2RlZmF1bHQgPSBQcm92aWRlcjtcblxuLy8gc3JjL2hvb2tzL3VzZVJlZHV4Q29udGV4dC50c1xuZnVuY3Rpb24gY3JlYXRlUmVkdXhDb250ZXh0SG9vayhjb250ZXh0ID0gUmVhY3RSZWR1eENvbnRleHQpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIHVzZVJlZHV4Q29udGV4dDIoKSB7XG4gICAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlQ29udGV4dChjb250ZXh0KTtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFjb250ZXh0VmFsdWUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgXCJjb3VsZCBub3QgZmluZCByZWFjdC1yZWR1eCBjb250ZXh0IHZhbHVlOyBwbGVhc2UgZW5zdXJlIHRoZSBjb21wb25lbnQgaXMgd3JhcHBlZCBpbiBhIDxQcm92aWRlcj5cIlxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbnRleHRWYWx1ZTtcbiAgfTtcbn1cbnZhciB1c2VSZWR1eENvbnRleHQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlUmVkdXhDb250ZXh0SG9vaygpO1xuXG4vLyBzcmMvaG9va3MvdXNlU3RvcmUudHNcbmZ1bmN0aW9uIGNyZWF0ZVN0b3JlSG9vayhjb250ZXh0ID0gUmVhY3RSZWR1eENvbnRleHQpIHtcbiAgY29uc3QgdXNlUmVkdXhDb250ZXh0MiA9IGNvbnRleHQgPT09IFJlYWN0UmVkdXhDb250ZXh0ID8gdXNlUmVkdXhDb250ZXh0IDogKFxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBjcmVhdGVSZWR1eENvbnRleHRIb29rKGNvbnRleHQpXG4gICk7XG4gIGNvbnN0IHVzZVN0b3JlMiA9ICgpID0+IHtcbiAgICBjb25zdCB7IHN0b3JlIH0gPSB1c2VSZWR1eENvbnRleHQyKCk7XG4gICAgcmV0dXJuIHN0b3JlO1xuICB9O1xuICBPYmplY3QuYXNzaWduKHVzZVN0b3JlMiwge1xuICAgIHdpdGhUeXBlczogKCkgPT4gdXNlU3RvcmUyXG4gIH0pO1xuICByZXR1cm4gdXNlU3RvcmUyO1xufVxudmFyIHVzZVN0b3JlID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZVN0b3JlSG9vaygpO1xuXG4vLyBzcmMvaG9va3MvdXNlRGlzcGF0Y2gudHNcbmZ1bmN0aW9uIGNyZWF0ZURpc3BhdGNoSG9vayhjb250ZXh0ID0gUmVhY3RSZWR1eENvbnRleHQpIHtcbiAgY29uc3QgdXNlU3RvcmUyID0gY29udGV4dCA9PT0gUmVhY3RSZWR1eENvbnRleHQgPyB1c2VTdG9yZSA6IGNyZWF0ZVN0b3JlSG9vayhjb250ZXh0KTtcbiAgY29uc3QgdXNlRGlzcGF0Y2gyID0gKCkgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gdXNlU3RvcmUyKCk7XG4gICAgcmV0dXJuIHN0b3JlLmRpc3BhdGNoO1xuICB9O1xuICBPYmplY3QuYXNzaWduKHVzZURpc3BhdGNoMiwge1xuICAgIHdpdGhUeXBlczogKCkgPT4gdXNlRGlzcGF0Y2gyXG4gIH0pO1xuICByZXR1cm4gdXNlRGlzcGF0Y2gyO1xufVxudmFyIHVzZURpc3BhdGNoID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZURpc3BhdGNoSG9vaygpO1xuXG4vLyBzcmMvaG9va3MvdXNlU2VsZWN0b3IudHNcbmltcG9ydCB7IHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yIH0gZnJvbSBcInVzZS1zeW5jLWV4dGVybmFsLXN0b3JlL3dpdGgtc2VsZWN0b3IuanNcIjtcbnZhciByZWZFcXVhbGl0eSA9IChhLCBiKSA9PiBhID09PSBiO1xuZnVuY3Rpb24gY3JlYXRlU2VsZWN0b3JIb29rKGNvbnRleHQgPSBSZWFjdFJlZHV4Q29udGV4dCkge1xuICBjb25zdCB1c2VSZWR1eENvbnRleHQyID0gY29udGV4dCA9PT0gUmVhY3RSZWR1eENvbnRleHQgPyB1c2VSZWR1eENvbnRleHQgOiBjcmVhdGVSZWR1eENvbnRleHRIb29rKGNvbnRleHQpO1xuICBjb25zdCB1c2VTZWxlY3RvcjIgPSAoc2VsZWN0b3IsIGVxdWFsaXR5Rm5Pck9wdGlvbnMgPSB7fSkgPT4ge1xuICAgIGNvbnN0IHsgZXF1YWxpdHlGbiA9IHJlZkVxdWFsaXR5IH0gPSB0eXBlb2YgZXF1YWxpdHlGbk9yT3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiID8geyBlcXVhbGl0eUZuOiBlcXVhbGl0eUZuT3JPcHRpb25zIH0gOiBlcXVhbGl0eUZuT3JPcHRpb25zO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIGlmICghc2VsZWN0b3IpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBZb3UgbXVzdCBwYXNzIGEgc2VsZWN0b3IgdG8gdXNlU2VsZWN0b3JgKTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2Ygc2VsZWN0b3IgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFlvdSBtdXN0IHBhc3MgYSBmdW5jdGlvbiBhcyBhIHNlbGVjdG9yIHRvIHVzZVNlbGVjdG9yYCk7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIGVxdWFsaXR5Rm4gIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYFlvdSBtdXN0IHBhc3MgYSBmdW5jdGlvbiBhcyBhbiBlcXVhbGl0eSBmdW5jdGlvbiB0byB1c2VTZWxlY3RvcmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcmVkdXhDb250ZXh0ID0gdXNlUmVkdXhDb250ZXh0MigpO1xuICAgIGNvbnN0IHsgc3RvcmUsIHN1YnNjcmlwdGlvbiwgZ2V0U2VydmVyU3RhdGUgfSA9IHJlZHV4Q29udGV4dDtcbiAgICBjb25zdCBmaXJzdFJ1biA9IFJlYWN0LnVzZVJlZih0cnVlKTtcbiAgICBjb25zdCB3cmFwcGVkU2VsZWN0b3IgPSBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAgIHtcbiAgICAgICAgW3NlbGVjdG9yLm5hbWVdKHN0YXRlKSB7XG4gICAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPSBzZWxlY3RvcihzdGF0ZSk7XG4gICAgICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgICAgICAgY29uc3QgeyBkZXZNb2RlQ2hlY2tzID0ge30gfSA9IHR5cGVvZiBlcXVhbGl0eUZuT3JPcHRpb25zID09PSBcImZ1bmN0aW9uXCIgPyB7fSA6IGVxdWFsaXR5Rm5Pck9wdGlvbnM7XG4gICAgICAgICAgICBjb25zdCB7IGlkZW50aXR5RnVuY3Rpb25DaGVjaywgc3RhYmlsaXR5Q2hlY2sgfSA9IHJlZHV4Q29udGV4dDtcbiAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAgaWRlbnRpdHlGdW5jdGlvbkNoZWNrOiBmaW5hbElkZW50aXR5RnVuY3Rpb25DaGVjayxcbiAgICAgICAgICAgICAgc3RhYmlsaXR5Q2hlY2s6IGZpbmFsU3RhYmlsaXR5Q2hlY2tcbiAgICAgICAgICAgIH0gPSB7XG4gICAgICAgICAgICAgIHN0YWJpbGl0eUNoZWNrLFxuICAgICAgICAgICAgICBpZGVudGl0eUZ1bmN0aW9uQ2hlY2ssXG4gICAgICAgICAgICAgIC4uLmRldk1vZGVDaGVja3NcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoZmluYWxTdGFiaWxpdHlDaGVjayA9PT0gXCJhbHdheXNcIiB8fCBmaW5hbFN0YWJpbGl0eUNoZWNrID09PSBcIm9uY2VcIiAmJiBmaXJzdFJ1bi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgIGNvbnN0IHRvQ29tcGFyZSA9IHNlbGVjdG9yKHN0YXRlKTtcbiAgICAgICAgICAgICAgaWYgKCFlcXVhbGl0eUZuKHNlbGVjdGVkLCB0b0NvbXBhcmUpKSB7XG4gICAgICAgICAgICAgICAgbGV0IHN0YWNrID0gdm9pZCAwO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAoeyBzdGFjayB9ID0gZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAgICAgICAgIFwiU2VsZWN0b3IgXCIgKyAoc2VsZWN0b3IubmFtZSB8fCBcInVua25vd25cIikgKyBcIiByZXR1cm5lZCBhIGRpZmZlcmVudCByZXN1bHQgd2hlbiBjYWxsZWQgd2l0aCB0aGUgc2FtZSBwYXJhbWV0ZXJzLiBUaGlzIGNhbiBsZWFkIHRvIHVubmVjZXNzYXJ5IHJlcmVuZGVycy5cXG5TZWxlY3RvcnMgdGhhdCByZXR1cm4gYSBuZXcgcmVmZXJlbmNlIChzdWNoIGFzIGFuIG9iamVjdCBvciBhbiBhcnJheSkgc2hvdWxkIGJlIG1lbW9pemVkOiBodHRwczovL3JlZHV4LmpzLm9yZy91c2FnZS9kZXJpdmluZy1kYXRhLXNlbGVjdG9ycyNvcHRpbWl6aW5nLXNlbGVjdG9ycy13aXRoLW1lbW9pemF0aW9uXCIsXG4gICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLFxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZCxcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWQyOiB0b0NvbXBhcmUsXG4gICAgICAgICAgICAgICAgICAgIHN0YWNrXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGZpbmFsSWRlbnRpdHlGdW5jdGlvbkNoZWNrID09PSBcImFsd2F5c1wiIHx8IGZpbmFsSWRlbnRpdHlGdW5jdGlvbkNoZWNrID09PSBcIm9uY2VcIiAmJiBmaXJzdFJ1bi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgIGlmIChzZWxlY3RlZCA9PT0gc3RhdGUpIHtcbiAgICAgICAgICAgICAgICBsZXQgc3RhY2sgPSB2b2lkIDA7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcigpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgIDtcbiAgICAgICAgICAgICAgICAgICh7IHN0YWNrIH0gPSBlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgICAgICAgXCJTZWxlY3RvciBcIiArIChzZWxlY3Rvci5uYW1lIHx8IFwidW5rbm93blwiKSArIFwiIHJldHVybmVkIHRoZSByb290IHN0YXRlIHdoZW4gY2FsbGVkLiBUaGlzIGNhbiBsZWFkIHRvIHVubmVjZXNzYXJ5IHJlcmVuZGVycy5cXG5TZWxlY3RvcnMgdGhhdCByZXR1cm4gdGhlIGVudGlyZSBzdGF0ZSBhcmUgYWxtb3N0IGNlcnRhaW5seSBhIG1pc3Rha2UsIGFzIHRoZXkgd2lsbCBjYXVzZSBhIHJlcmVuZGVyIHdoZW5ldmVyICphbnl0aGluZyogaW4gc3RhdGUgY2hhbmdlcy5cIixcbiAgICAgICAgICAgICAgICAgIHsgc3RhY2sgfVxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChmaXJzdFJ1bi5jdXJyZW50KSBmaXJzdFJ1bi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBzZWxlY3RlZDtcbiAgICAgICAgfVxuICAgICAgfVtzZWxlY3Rvci5uYW1lXSxcbiAgICAgIFtzZWxlY3Rvcl1cbiAgICApO1xuICAgIGNvbnN0IHNlbGVjdGVkU3RhdGUgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvcihcbiAgICAgIHN1YnNjcmlwdGlvbi5hZGROZXN0ZWRTdWIsXG4gICAgICBzdG9yZS5nZXRTdGF0ZSxcbiAgICAgIGdldFNlcnZlclN0YXRlIHx8IHN0b3JlLmdldFN0YXRlLFxuICAgICAgd3JhcHBlZFNlbGVjdG9yLFxuICAgICAgZXF1YWxpdHlGblxuICAgICk7XG4gICAgUmVhY3QudXNlRGVidWdWYWx1ZShzZWxlY3RlZFN0YXRlKTtcbiAgICByZXR1cm4gc2VsZWN0ZWRTdGF0ZTtcbiAgfTtcbiAgT2JqZWN0LmFzc2lnbih1c2VTZWxlY3RvcjIsIHtcbiAgICB3aXRoVHlwZXM6ICgpID0+IHVzZVNlbGVjdG9yMlxuICB9KTtcbiAgcmV0dXJuIHVzZVNlbGVjdG9yMjtcbn1cbnZhciB1c2VTZWxlY3RvciA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVTZWxlY3Rvckhvb2soKTtcblxuLy8gc3JjL2V4cG9ydHMudHNcbnZhciBiYXRjaCA9IGRlZmF1bHROb29wQmF0Y2g7XG5leHBvcnQge1xuICBQcm92aWRlcl9kZWZhdWx0IGFzIFByb3ZpZGVyLFxuICBSZWFjdFJlZHV4Q29udGV4dCxcbiAgYmF0Y2gsXG4gIGNvbm5lY3QsXG4gIGNyZWF0ZURpc3BhdGNoSG9vayxcbiAgY3JlYXRlU2VsZWN0b3JIb29rLFxuICBjcmVhdGVTdG9yZUhvb2ssXG4gIGxlZ2FjeV9jb25uZWN0LFxuICBzaGFsbG93RXF1YWwsXG4gIHVzZURpc3BhdGNoLFxuICB1c2VTZWxlY3RvcixcbiAgdXNlU3RvcmVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZWFjdC1yZWR1eC5tanMubWFwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0NBV0EsQ0FDRyxXQUFZO0VBQ1gsU0FBUyxHQUFHLEdBQUcsR0FBRztHQUNoQixPQUFRLE1BQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxNQUFNLElBQUksTUFBUSxNQUFNLEtBQUssTUFBTTtFQUN4RTtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLCtCQUN4QywrQkFBK0IsNEJBQTRCLE1BQU0sQ0FBQztFQUNwRSxJQUFJLFFBQUEsY0FBQSxHQUNGLFdBQVcsZUFBZSxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFDekQsdUJBQXVCLE1BQU0sc0JBQzdCLFNBQVMsTUFBTSxRQUNmLFlBQVksTUFBTSxXQUNsQixVQUFVLE1BQU0sU0FDaEIsZ0JBQWdCLE1BQU07RUFDeEIsUUFBUSxtQ0FBbUMsU0FDekMsV0FDQSxhQUNBLG1CQUNBLFVBQ0EsU0FDQTtHQUNBLElBQUksVUFBVSxPQUFPLElBQUk7R0FDekIsSUFBSSxTQUFTLFFBQVEsU0FBUztJQUM1QixJQUFJLE9BQU87S0FBRSxVQUFVLENBQUM7S0FBRyxPQUFPO0lBQUs7SUFDdkMsUUFBUSxVQUFVO0dBQ3BCLE9BQU8sT0FBTyxRQUFRO0dBQ3RCLFVBQVUsUUFDUixXQUFZO0lBQ1YsU0FBUyxpQkFBaUIsY0FBYztLQUN0QyxJQUFJLENBQUMsU0FBUztNQUNaLFVBQVUsQ0FBQztNQUNYLG1CQUFtQjtNQUNuQixlQUFlLFNBQVMsWUFBWTtNQUNwQyxJQUFJLEtBQUssTUFBTSxXQUFXLEtBQUssVUFBVTtPQUN2QyxJQUFJLG1CQUFtQixLQUFLO09BQzVCLElBQUksUUFBUSxrQkFBa0IsWUFBWSxHQUN4QyxPQUFRLG9CQUFvQjtNQUNoQztNQUNBLE9BQVEsb0JBQW9CO0tBQzlCO0tBQ0EsbUJBQW1CO0tBQ25CLElBQUksU0FBUyxrQkFBa0IsWUFBWSxHQUN6QyxPQUFPO0tBQ1QsSUFBSSxnQkFBZ0IsU0FBUyxZQUFZO0tBQ3pDLElBQUksS0FBSyxNQUFNLFdBQVcsUUFBUSxrQkFBa0IsYUFBYSxHQUMvRCxPQUFRLG1CQUFtQixjQUFlO0tBQzVDLG1CQUFtQjtLQUNuQixPQUFRLG9CQUFvQjtJQUM5QjtJQUNBLElBQUksVUFBVSxDQUFDLEdBQ2Isa0JBQ0EsbUJBQ0EseUJBQ0UsS0FBSyxNQUFNLG9CQUFvQixPQUFPO0lBQzFDLE9BQU8sQ0FDTCxXQUFZO0tBQ1YsT0FBTyxpQkFBaUIsWUFBWSxDQUFDO0lBQ3ZDLEdBQ0EsU0FBUyx5QkFDTCxLQUFLLElBQ0wsV0FBWTtLQUNWLE9BQU8saUJBQWlCLHVCQUF1QixDQUFDO0lBQ2xELENBQ047R0FDRixHQUNBO0lBQUM7SUFBYTtJQUFtQjtJQUFVO0dBQU8sQ0FDcEQ7R0FDQSxJQUFJLFFBQVEscUJBQXFCLFdBQVcsUUFBUSxJQUFJLFFBQVEsRUFBRTtHQUNsRSxVQUNFLFdBQVk7SUFDVixLQUFLLFdBQVcsQ0FBQztJQUNqQixLQUFLLFFBQVE7R0FDZixHQUNBLENBQUMsS0FBSyxDQUNSO0dBQ0EsY0FBYyxLQUFLO0dBQ25CLE9BQU87RUFDVDtFQUNBLGdCQUFnQixPQUFPLGtDQUNyQixlQUNFLE9BQU8sK0JBQStCLDhCQUN4QywrQkFBK0IsMkJBQTJCLE1BQU0sQ0FBQztDQUNyRSxFQUFBLENBQUc7Ozs7O0NDMUZILE9BQU8sVUFBQSwwREFBQTs7Ozs7O0FDRFQsSUFBSSxjQUE4Qix5QkFBYyxXQUFXLElBQUk7QUFDL0QsSUFBSSxxQkFBcUMsdUJBQU8sSUFDOUMsY0FBYywrQkFBK0IsZUFDL0M7QUFDQSxJQUFJLG9CQUFvQyx1QkFBTyxJQUFJLGNBQWM7QUFDakUsSUFBSSxzQkFBc0MsdUJBQU8sSUFBSSxnQkFBZ0I7QUFDckUsSUFBSSx5QkFBeUMsdUJBQU8sSUFBSSxtQkFBbUI7QUFDM0UsSUFBSSxzQkFBc0MsdUJBQU8sSUFBSSxnQkFBZ0I7QUFDckUsSUFBSSxzQkFBc0MsdUJBQU8sSUFBSSxnQkFBZ0I7QUFDckUsSUFBSSxxQkFBcUMsdUJBQU8sSUFBSSxlQUFlO0FBQ25FLElBQUkseUJBQXlDLHVCQUFPLElBQUksbUJBQW1CO0FBQzNFLElBQUksc0JBQXNDLHVCQUFPLElBQUksZ0JBQWdCO0FBQ3JFLElBQUksMkJBQTJDLHVCQUFPLElBQ3BELHFCQUNGO0FBQ0EsSUFBSSxrQkFBa0MsdUJBQU8sSUFBSSxZQUFZO0FBQzdELElBQUksa0JBQWtDLHVCQUFPLElBQUksWUFBWTtBQUM3RCxJQUFJLHVCQUF1Qyx1QkFBTyxJQUFJLGlCQUFpQjtBQUN2RSxJQUFJLHlCQUF5Qyx1QkFBTyxJQUNsRCx3QkFDRjtBQUNBLElBQUksYUFBYTtBQUNqQixJQUFJLE9BQU87QUFDWCxTQUFTLG1CQUFtQixNQUFNO0NBQ2hDLE9BQU8sT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLGNBQWMsU0FBUyx1QkFBdUIsU0FBUyx1QkFBdUIsU0FBUywwQkFBMEIsU0FBUyx1QkFBdUIsU0FBUyw0QkFBNEIsU0FBUyx3QkFBd0IsT0FBTyxTQUFTLFlBQVksU0FBUyxTQUFTLEtBQUssYUFBYSxtQkFBbUIsS0FBSyxhQUFhLG1CQUFtQixLQUFLLGFBQWEsc0JBQXNCLEtBQUssYUFBYSx1QkFBdUIsS0FBSyxhQUFhLDBCQUEwQixLQUFLLGFBQWEsMEJBQTBCLEtBQUssZ0JBQWdCLEtBQUssS0FBSyxPQUFPO0FBQ25sQjtBQUNBLFNBQVMsT0FBTyxRQUFRO0NBQ3RCLElBQUksT0FBTyxXQUFXLFlBQVksV0FBVyxNQUFNO0VBQ2pELE1BQU0sRUFBRSxhQUFhO0VBQ3JCLFFBQVEsVUFBUjtHQUNFLEtBQUssb0JBQ0gsUUFBUSxTQUFTLE9BQU8sTUFBTSxRQUE5QjtJQUNFLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLLDBCQUNILE9BQU87SUFDVCxTQUNFLFFBQVEsU0FBUyxVQUFVLE9BQU8sVUFBVSxRQUE1QztLQUNFLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUssaUJBQ0gsT0FBTztLQUNULEtBQUsscUJBQ0gsT0FBTztLQUNULFNBQ0UsT0FBTztJQUNYO0dBQ0o7R0FDRixLQUFLLG1CQUNILE9BQU87RUFDWDtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixRQUFRO0NBQ2pDLE9BQU8sY0FBYyxPQUFPLE1BQU0sTUFBTSxzQkFBc0IsT0FBTyxNQUFNLE1BQU07QUFDbkY7QUFDQSxTQUFTLE9BQU8sUUFBUTtDQUN0QixPQUFPLE9BQU8sTUFBTSxNQUFNO0FBQzVCO0FBR0EsU0FBUyxRQUFRLFNBQVM7Q0FDeEIsSUFBSSxPQUFPLFlBQVksZUFBZSxPQUFPLFFBQVEsVUFBVSxZQUM3RCxRQUFRLE1BQU0sT0FBTztDQUV2QixJQUFJO0VBQ0YsTUFBTSxJQUFJLE1BQU0sT0FBTztDQUN6QixTQUFTLEdBQUcsQ0FDWjtBQUNGO0FBR0EsU0FBUyxPQUFPLFVBQVUsWUFBWTtDQUNwQyxJQUFJLENBQUMsVUFDSCxNQUFNLElBQUksTUFBTSx3QkFBd0IsV0FBVyxhQUFhO01BQzNELElBQUksZUFBZSxxQkFBcUIsZUFBZSxzQkFDeEQ7TUFBQSxDQUFDLE9BQU8sVUFBVSxlQUFlLEtBQUssVUFBVSxtQkFBbUIsR0FDckUsUUFDRSxvQkFBb0IsV0FBVywyREFDakM7Q0FBQTtBQUdOO0FBQ0EsU0FBUyxtQkFBbUIsaUJBQWlCLG9CQUFvQixZQUFZO0NBQzNFLE9BQU8saUJBQWlCLGlCQUFpQjtDQUN6QyxPQUFPLG9CQUFvQixvQkFBb0I7Q0FDL0MsT0FBTyxZQUFZLFlBQVk7QUFDakM7QUFHQSxTQUFTLDhCQUE4QixpQkFBaUIsb0JBQW9CLFlBQVksVUFBVSxFQUNoRyxnQkFDQSxrQkFDQSxzQkFDQztDQUNELElBQUksb0JBQW9CO0NBQ3hCLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osU0FBUyxnQkFBZ0IsWUFBWSxlQUFlO0VBQ2xELFFBQVE7RUFDUixXQUFXO0VBQ1gsYUFBYSxnQkFBZ0IsT0FBTyxRQUFRO0VBQzVDLGdCQUFnQixtQkFBbUIsVUFBVSxRQUFRO0VBQ3JELGNBQWMsV0FBVyxZQUFZLGVBQWUsUUFBUTtFQUM1RCxvQkFBb0I7RUFDcEIsT0FBTztDQUNUO0NBQ0EsU0FBUyw0QkFBNEI7RUFDbkMsYUFBYSxnQkFBZ0IsT0FBTyxRQUFRO0VBQzVDLElBQUksbUJBQW1CLG1CQUNyQixnQkFBZ0IsbUJBQW1CLFVBQVUsUUFBUTtFQUN2RCxjQUFjLFdBQVcsWUFBWSxlQUFlLFFBQVE7RUFDNUQsT0FBTztDQUNUO0NBQ0EsU0FBUyxpQkFBaUI7RUFDeEIsSUFBSSxnQkFBZ0IsbUJBQ2xCLGFBQWEsZ0JBQWdCLE9BQU8sUUFBUTtFQUM5QyxJQUFJLG1CQUFtQixtQkFDckIsZ0JBQWdCLG1CQUFtQixVQUFVLFFBQVE7RUFDdkQsY0FBYyxXQUFXLFlBQVksZUFBZSxRQUFRO0VBQzVELE9BQU87Q0FDVDtDQUNBLFNBQVMsaUJBQWlCO0VBQ3hCLE1BQU0saUJBQWlCLGdCQUFnQixPQUFPLFFBQVE7RUFDdEQsTUFBTSxvQkFBb0IsQ0FBQyxtQkFBbUIsZ0JBQWdCLFVBQVU7RUFDeEUsYUFBYTtFQUNiLElBQUksbUJBQ0YsY0FBYyxXQUFXLFlBQVksZUFBZSxRQUFRO0VBQzlELE9BQU87Q0FDVDtDQUNBLFNBQVMsc0JBQXNCLFdBQVcsY0FBYztFQUN0RCxNQUFNLGVBQWUsQ0FBQyxpQkFBaUIsY0FBYyxRQUFRO0VBQzdELE1BQU0sZUFBZSxDQUFDLGVBQ3BCLFdBQ0EsT0FDQSxjQUNBLFFBQ0Y7RUFDQSxRQUFRO0VBQ1IsV0FBVztFQUNYLElBQUksZ0JBQWdCLGNBQWMsT0FBTywwQkFBMEI7RUFDbkUsSUFBSSxjQUFjLE9BQU8sZUFBZTtFQUN4QyxJQUFJLGNBQWMsT0FBTyxlQUFlO0VBQ3hDLE9BQU87Q0FDVDtDQUNBLE9BQU8sU0FBUyx1QkFBdUIsV0FBVyxjQUFjO0VBQzlELE9BQU8sb0JBQW9CLHNCQUFzQixXQUFXLFlBQVksSUFBSSxnQkFBZ0IsV0FBVyxZQUFZO0NBQ3JIO0FBQ0Y7QUFDQSxTQUFTLDBCQUEwQixVQUFVLEVBQzNDLHFCQUNBLHdCQUNBLGdCQUNBLEdBQUcsV0FDRjtDQUNELE1BQU0sa0JBQWtCLG9CQUFvQixVQUFVLE9BQU87Q0FDN0QsTUFBTSxxQkFBcUIsdUJBQXVCLFVBQVUsT0FBTztDQUNuRSxNQUFNLGFBQWEsZUFBZSxVQUFVLE9BQU87Q0FFakQsbUJBQW1CLGlCQUFpQixvQkFBb0IsVUFBVTtDQUVwRSxPQUFPLDhCQUE4QixpQkFBaUIsb0JBQW9CLFlBQVksVUFBVSxPQUFPO0FBQ3pHO0FBR0EsU0FBUyxtQkFBbUIsZ0JBQWdCLFVBQVU7Q0FDcEQsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixLQUFLLE1BQU0sT0FBTyxnQkFBZ0I7RUFDaEMsTUFBTSxnQkFBZ0IsZUFBZTtFQUNyQyxJQUFJLE9BQU8sa0JBQWtCLFlBQzNCLG9CQUFvQixRQUFRLEdBQUcsU0FBUyxTQUFTLGNBQWMsR0FBRyxJQUFJLENBQUM7Q0FFM0U7Q0FDQSxPQUFPO0FBQ1Q7QUFHQSxTQUFTLGNBQWMsS0FBSztDQUMxQixJQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsTUFBTSxPQUFPO0NBQ3BELE1BQU0sUUFBUSxPQUFPLGVBQWUsR0FBRztDQUN2QyxJQUFJLFVBQVUsTUFBTSxPQUFPO0NBQzNCLElBQUksWUFBWTtDQUNoQixPQUFPLE9BQU8sZUFBZSxTQUFTLE1BQU0sTUFDMUMsWUFBWSxPQUFPLGVBQWUsU0FBUztDQUU3QyxPQUFPLFVBQVU7QUFDbkI7QUFHQSxTQUFTLGtCQUFrQixPQUFPLGFBQWEsWUFBWTtDQUN6RCxJQUFJLENBQUMsY0FBYyxLQUFLLEdBQ3RCLFFBQ0UsR0FBRyxXQUFXLFFBQVEsWUFBWSxnREFBZ0QsTUFBTSxFQUMxRjtBQUVKO0FBR0EsU0FBUyx1QkFBdUIsYUFBYTtDQUMzQyxPQUFPLFNBQVMscUJBQXFCLFVBQVU7RUFDN0MsTUFBTSxXQUFXLFlBQVksUUFBUTtFQUNyQyxTQUFTLG1CQUFtQjtHQUMxQixPQUFPO0VBQ1Q7RUFDQSxpQkFBaUIsb0JBQW9CO0VBQ3JDLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsWUFBWTtDQUN4QyxPQUFPLFdBQVcsb0JBQW9CLFFBQVEsV0FBVyxpQkFBaUIsSUFBSSxXQUFXLFdBQVc7QUFDdEc7QUFDQSxTQUFTLG1CQUFtQixZQUFZLFlBQVk7Q0FDbEQsT0FBTyxTQUFTLGtCQUFrQixVQUFVLEVBQUUsZUFBZTtFQUMzRCxNQUFNLFFBQVEsU0FBUyxnQkFBZ0IsaUJBQWlCLFVBQVU7R0FDaEUsT0FBTyxNQUFNLG9CQUFvQixNQUFNLFdBQVcsaUJBQWlCLFFBQVEsSUFBSSxNQUFNLFdBQVcsaUJBQWlCLEtBQUssQ0FBQztFQUN6SDtFQUNBLE1BQU0sb0JBQW9CO0VBQzFCLE1BQU0sYUFBYSxTQUFTLHVCQUF1QixpQkFBaUIsVUFBVTtHQUM1RSxNQUFNLGFBQWE7R0FDbkIsTUFBTSxvQkFBb0IscUJBQXFCLFVBQVU7R0FDekQsSUFBSSxRQUFRLE1BQU0saUJBQWlCLFFBQVE7R0FDM0MsSUFBSSxPQUFPLFVBQVUsWUFBWTtJQUMvQixNQUFNLGFBQWE7SUFDbkIsTUFBTSxvQkFBb0IscUJBQXFCLEtBQUs7SUFDcEQsUUFBUSxNQUFNLGlCQUFpQixRQUFRO0dBQ3pDO0dBRUUsa0JBQWtCLE9BQU8sYUFBYSxVQUFVO0dBQ2xELE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVDtBQUNGO0FBR0EsU0FBUyx3QkFBd0IsS0FBSyxNQUFNO0NBQzFDLFFBQVEsVUFBVSxZQUFZO0VBQzVCLE1BQU0sSUFBSSxNQUNSLHlCQUF5QixPQUFPLElBQUksT0FBTyxLQUFLLHNDQUFzQyxRQUFRLHFCQUFxQixFQUNySDtDQUNGO0FBQ0Y7QUFHQSxTQUFTLDBCQUEwQixvQkFBb0I7Q0FDckQsT0FBTyxzQkFBc0IsT0FBTyx1QkFBdUIsV0FBVyx3QkFDbkUsYUFFQyxtQkFBbUIsb0JBQW9CLFFBQVEsQ0FFbkQsSUFBSSxDQUFDLHFCQUFxQix3QkFBd0IsY0FBYyxFQUM5RCxTQUNGLEVBQUUsSUFBSSxPQUFPLHVCQUF1QixhQUVsQyxtQkFBbUIsb0JBQW9CLG9CQUFvQixJQUN6RCx3QkFBd0Isb0JBQW9CLG9CQUFvQjtBQUN0RTtBQUdBLFNBQVMsdUJBQXVCLGlCQUFpQjtDQUMvQyxPQUFPLENBQUMsa0JBQWtCLDhCQUE4QixDQUFDLEVBQUUsSUFBSSxPQUFPLG9CQUFvQixhQUV4RixtQkFBbUIsaUJBQWlCLGlCQUFpQixJQUNuRCx3QkFBd0IsaUJBQWlCLGlCQUFpQjtBQUNoRTtBQUdBLFNBQVMsa0JBQWtCLFlBQVksZUFBZSxVQUFVO0NBQzlELE9BQU87RUFBRSxHQUFHO0VBQVUsR0FBRztFQUFZLEdBQUc7Q0FBYztBQUN4RDtBQUNBLFNBQVMsbUJBQW1CLFlBQVk7Q0FDdEMsT0FBTyxTQUFTLG9CQUFvQixVQUFVLEVBQUUsYUFBYSx1QkFBdUI7RUFDbEYsSUFBSSxhQUFhO0VBQ2pCLElBQUk7RUFDSixPQUFPLFNBQVMsZ0JBQWdCLFlBQVksZUFBZSxVQUFVO0dBQ25FLE1BQU0sa0JBQWtCLFdBQVcsWUFBWSxlQUFlLFFBQVE7R0FDdEUsSUFBSSxZQUNFO1FBQUEsQ0FBQyxvQkFBb0IsaUJBQWlCLFdBQVcsR0FDbkQsY0FBYztHQUFBLE9BQ1g7SUFDTCxhQUFhO0lBQ2IsY0FBYztJQUVaLGtCQUFrQixhQUFhLGFBQWEsWUFBWTtHQUM1RDtHQUNBLE9BQU87RUFDVDtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixZQUFZO0NBQ3JDLE9BQU8sQ0FBQyxtQkFBbUIsb0JBQW9CLE9BQU8sZUFBZSxhQUFhLG1CQUFtQixVQUFVLElBQUksd0JBQXdCLFlBQVksWUFBWTtBQUNySztBQUdBLFNBQVMsaUJBQWlCLFVBQVU7Q0FDbEMsU0FBUztBQUNYO0FBR0EsU0FBUywyQkFBMkI7Q0FDbEMsSUFBSSxRQUFRO0NBQ1osSUFBSSxPQUFPO0NBQ1gsT0FBTztFQUNMLFFBQVE7R0FDTixRQUFRO0dBQ1IsT0FBTztFQUNUO0VBQ0EsU0FBUztHQUNQLHVCQUF1QjtJQUNyQixJQUFJLFdBQVc7SUFDZixPQUFPLFVBQVU7S0FDZixTQUFTLFNBQVM7S0FDbEIsV0FBVyxTQUFTO0lBQ3RCO0dBQ0YsQ0FBQztFQUNIO0VBQ0EsTUFBTTtHQUNKLE1BQU0sWUFBWSxDQUFDO0dBQ25CLElBQUksV0FBVztHQUNmLE9BQU8sVUFBVTtJQUNmLFVBQVUsS0FBSyxRQUFRO0lBQ3ZCLFdBQVcsU0FBUztHQUN0QjtHQUNBLE9BQU87RUFDVDtFQUNBLFVBQVUsVUFBVTtHQUNsQixJQUFJLGVBQWU7R0FDbkIsTUFBTSxXQUFXLE9BQU87SUFDdEI7SUFDQSxNQUFNO0lBQ04sTUFBTTtHQUNSO0dBQ0EsSUFBSSxTQUFTLE1BQ1gsU0FBUyxLQUFLLE9BQU87UUFFckIsUUFBUTtHQUVWLE9BQU8sU0FBUyxjQUFjO0lBQzVCLElBQUksQ0FBQyxnQkFBZ0IsVUFBVSxNQUFNO0lBQ3JDLGVBQWU7SUFDZixJQUFJLFNBQVMsTUFDWCxTQUFTLEtBQUssT0FBTyxTQUFTO1NBRTlCLE9BQU8sU0FBUztJQUVsQixJQUFJLFNBQVMsTUFDWCxTQUFTLEtBQUssT0FBTyxTQUFTO1NBRTlCLFFBQVEsU0FBUztHQUVyQjtFQUNGO0NBQ0Y7QUFDRjtBQUNBLElBQUksZ0JBQWdCO0NBQ2xCLFNBQVMsQ0FDVDtDQUNBLFdBQVcsQ0FBQztBQUNkO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTyxXQUFXO0NBQzVDLElBQUk7Q0FDSixJQUFJLFlBQVk7Q0FDaEIsSUFBSSxzQkFBc0I7Q0FDMUIsSUFBSSxpQkFBaUI7Q0FDckIsU0FBUyxhQUFhLFVBQVU7RUFDOUIsYUFBYTtFQUNiLE1BQU0sa0JBQWtCLFVBQVUsVUFBVSxRQUFRO0VBQ3BELElBQUksVUFBVTtFQUNkLGFBQWE7R0FDWCxJQUFJLENBQUMsU0FBUztJQUNaLFVBQVU7SUFDVixnQkFBZ0I7SUFDaEIsZUFBZTtHQUNqQjtFQUNGO0NBQ0Y7Q0FDQSxTQUFTLG1CQUFtQjtFQUMxQixVQUFVLE9BQU87Q0FDbkI7Q0FDQSxTQUFTLHNCQUFzQjtFQUM3QixJQUFJLGFBQWEsZUFDZixhQUFhLGNBQWM7Q0FFL0I7Q0FDQSxTQUFTLGVBQWU7RUFDdEIsT0FBTztDQUNUO0NBQ0EsU0FBUyxlQUFlO0VBQ3RCO0VBQ0EsSUFBSSxDQUFDLGFBQWE7R0FDaEIsY0FBYyxZQUFZLFVBQVUsYUFBYSxtQkFBbUIsSUFBSSxNQUFNLFVBQVUsbUJBQW1CO0dBQzNHLFlBQVkseUJBQXlCO0VBQ3ZDO0NBQ0Y7Q0FDQSxTQUFTLGlCQUFpQjtFQUN4QjtFQUNBLElBQUksZUFBZSx3QkFBd0IsR0FBRztHQUM1QyxZQUFZO0dBQ1osY0FBYyxLQUFLO0dBQ25CLFVBQVUsTUFBTTtHQUNoQixZQUFZO0VBQ2Q7Q0FDRjtDQUNBLFNBQVMsbUJBQW1CO0VBQzFCLElBQUksQ0FBQyxnQkFBZ0I7R0FDbkIsaUJBQWlCO0dBQ2pCLGFBQWE7RUFDZjtDQUNGO0NBQ0EsU0FBUyxxQkFBcUI7RUFDNUIsSUFBSSxnQkFBZ0I7R0FDbEIsaUJBQWlCO0dBQ2pCLGVBQWU7RUFDakI7Q0FDRjtDQUNBLE1BQU0sZUFBZTtFQUNuQjtFQUNBO0VBQ0E7RUFDQTtFQUNBLGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEIsb0JBQW9CO0NBQ3RCO0NBQ0EsT0FBTztBQUNUO0FBR0EsSUFBSSxrQkFBa0IsQ0FBQyxFQUFFLE9BQU8sV0FBVyxlQUFlLE9BQU8sT0FBTyxhQUFhLGVBQWUsT0FBTyxPQUFPLFNBQVMsa0JBQWtCO0FBQzdJLElBQUksUUFBd0IsMEJBQVU7QUFDdEMsSUFBSSwrQkFBK0IsT0FBTyxjQUFjLGVBQWUsVUFBVSxZQUFZO0FBQzdGLElBQUksZ0JBQWdDLHVDQUF1QjtBQUMzRCxJQUFJLHFDQUFxQyxTQUFTLGdCQUFBLGFBQXNCLGtCQUFBLGFBQXdCO0FBQ2hHLElBQUksNEJBQTRDLDZDQUE2QjtBQUc3RSxTQUFTLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLElBQUksTUFBTSxHQUNSLE9BQU8sTUFBTSxLQUFLLE1BQU0sS0FBSyxJQUFJLE1BQU0sSUFBSTtNQUUzQyxPQUFPLE1BQU0sS0FBSyxNQUFNO0FBRTVCO0FBQ0EsU0FBUyxhQUFhLE1BQU0sTUFBTTtDQUNoQyxJQUFJLEdBQUcsTUFBTSxJQUFJLEdBQUcsT0FBTztDQUMzQixJQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsUUFBUSxPQUFPLFNBQVMsWUFBWSxTQUFTLE1BQ3BGLE9BQU87Q0FFVCxNQUFNLFFBQVEsT0FBTyxLQUFLLElBQUk7Q0FDOUIsTUFBTSxRQUFRLE9BQU8sS0FBSyxJQUFJO0NBQzlCLElBQUksTUFBTSxXQUFXLE1BQU0sUUFBUSxPQUFPO0NBQzFDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FDaEMsSUFBSSxDQUFDLE9BQU8sVUFBVSxlQUFlLEtBQUssTUFBTSxNQUFNLEVBQUUsS0FBSyxDQUFDLEdBQUcsS0FBSyxNQUFNLEtBQUssS0FBSyxNQUFNLEdBQUcsR0FDN0YsT0FBTztDQUdYLE9BQU87QUFDVDtBQUdBLElBQUksZ0JBQWdCO0NBQ2xCLG1CQUFtQjtDQUNuQixhQUFhO0NBQ2IsY0FBYztDQUNkLGNBQWM7Q0FDZCxhQUFhO0NBQ2IsaUJBQWlCO0NBQ2pCLDBCQUEwQjtDQUMxQiwwQkFBMEI7Q0FDMUIsUUFBUTtDQUNSLFdBQVc7Q0FDWCxNQUFNO0FBQ1I7QUFDQSxJQUFJLGdCQUFnQjtDQUNsQixNQUFNO0NBQ04sUUFBUTtDQUNSLFdBQVc7Q0FDWCxRQUFRO0NBQ1IsUUFBUTtDQUNSLFdBQVc7Q0FDWCxPQUFPO0FBQ1Q7QUFDQSxJQUFJLHNCQUFzQjtDQUN4QixVQUFVO0NBQ1YsUUFBUTtDQUNSLGNBQWM7Q0FDZCxhQUFhO0NBQ2IsV0FBVztBQUNiO0FBQ0EsSUFBSSxlQUFlO0NBQ2pCLFVBQVU7Q0FDVixTQUFTO0NBQ1QsY0FBYztDQUNkLGFBQWE7Q0FDYixXQUFXO0NBQ1gsTUFBTTtBQUNSO0FBQ0EsSUFBSSxlQUFlO0VBQ2hCLGFBQWE7RUFDYixPQUFPO0FBQ1Y7QUFDQSxTQUFTLFdBQVcsV0FBVztDQUM3QixJQUFJLE9BQU8sU0FBUyxHQUNsQixPQUFPO0NBRVQsT0FBTyxhQUFhLFVBQVUsZ0JBQWdCO0FBQ2hEO0FBQ0EsSUFBSSxpQkFBaUIsT0FBTztBQUM1QixJQUFJLHNCQUFzQixPQUFPO0FBQ2pDLElBQUksd0JBQXdCLE9BQU87QUFDbkMsSUFBSSwyQkFBMkIsT0FBTztBQUN0QyxJQUFJLGlCQUFpQixPQUFPO0FBQzVCLElBQUksa0JBQWtCLE9BQU87QUFDN0IsU0FBUyxxQkFBcUIsaUJBQWlCLGlCQUFpQjtDQUM5RCxJQUFJLE9BQU8sb0JBQW9CLFVBQVU7RUFDdkMsSUFBSSxpQkFBaUI7R0FDbkIsTUFBTSxxQkFBcUIsZUFBZSxlQUFlO0dBQ3pELElBQUksc0JBQXNCLHVCQUF1QixpQkFDL0MscUJBQXFCLGlCQUFpQixrQkFBa0I7RUFFNUQ7RUFDQSxJQUFJLE9BQU8sb0JBQW9CLGVBQWU7RUFDOUMsSUFBSSx1QkFDRixPQUFPLEtBQUssT0FBTyxzQkFBc0IsZUFBZSxDQUFDO0VBRTNELE1BQU0sZ0JBQWdCLFdBQVcsZUFBZTtFQUNoRCxNQUFNLGdCQUFnQixXQUFXLGVBQWU7RUFDaEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxFQUFFLEdBQUc7R0FDcEMsTUFBTSxNQUFNLEtBQUs7R0FDakIsSUFBSSxDQUFDLGNBQWMsUUFBUSxFQUFFLGlCQUFpQixjQUFjLFNBQVMsRUFBRSxpQkFBaUIsY0FBYyxPQUFPO0lBQzNHLE1BQU0sYUFBYSx5QkFBeUIsaUJBQWlCLEdBQUc7SUFDaEUsSUFBSTtLQUNGLGVBQWUsaUJBQWlCLEtBQUssVUFBVTtJQUNqRCxTQUFTLEdBQUcsQ0FDWjtHQUNGO0VBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUdBLElBQUksYUFBNkIsdUJBQU8sSUFBSSxxQkFBcUI7QUFDakUsSUFBSSxLQUFLLE9BQU8sZUFBZSxjQUFjLGFBRTNDLENBQUM7QUFFSCxTQUFTLGFBQWE7Q0FDcEIsSUFBSSxDQUFBLGFBQU8sZUFBZSxPQUFPLENBQUM7Q0FDbEMsTUFBTSxhQUFhLEdBQUcsZ0NBQWdDLElBQUksSUFBSTtDQUM5RCxJQUFJLGNBQWMsV0FBVyxJQUFBLGFBQVUsYUFBYTtDQUNwRCxJQUFJLENBQUMsYUFBYTtFQUNoQixjQUFBLGFBQW9CLGNBQ2xCLElBQ0Y7RUFFRSxZQUFZLGNBQWM7RUFFNUIsV0FBVyxJQUFBLGFBQVUsZUFBZSxXQUFXO0NBQ2pEO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBSSxvQkFBb0MsMkJBQVc7QUFHbkQsSUFBSSx3QkFBd0IsQ0FBQyxNQUFNLElBQUk7QUFDdkMsSUFBSSxzQkFBc0IsU0FBUztDQUNqQyxJQUFJO0VBQ0YsT0FBTyxLQUFLLFVBQVUsSUFBSTtDQUM1QixTQUFTLEtBQUs7RUFDWixPQUFPLE9BQU8sSUFBSTtDQUNwQjtBQUNGO0FBQ0EsU0FBUyxrQ0FBa0MsWUFBWSxZQUFZLGNBQWM7Q0FDL0UsZ0NBQWdDLFdBQVcsR0FBRyxVQUFVLEdBQUcsWUFBWTtBQUN6RTtBQUNBLFNBQVMsb0JBQW9CLGtCQUFrQixnQkFBZ0IsbUJBQW1CLGNBQWMsMkJBQTJCLGtCQUFrQjtDQUMzSSxpQkFBaUIsVUFBVTtDQUMzQixrQkFBa0IsVUFBVTtDQUM1QixJQUFJLDBCQUEwQixTQUFTO0VBQ3JDLDBCQUEwQixVQUFVO0VBQ3BDLGlCQUFpQjtDQUNuQjtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsMEJBQTBCLE9BQU8sY0FBYyxvQkFBb0Isa0JBQWtCLGdCQUFnQixtQkFBbUIsV0FBVywyQkFBMkIsa0JBQWtCLDZCQUE2QjtDQUNyTyxJQUFJLENBQUMsMEJBQTBCLGFBQWEsQ0FDNUM7Q0FDQSxJQUFJLGlCQUFpQjtDQUNyQixJQUFJLGtCQUFrQjtDQUN0QixNQUFNLHdCQUF3QjtFQUM1QixJQUFJLGtCQUFrQixDQUFDLFVBQVUsU0FDL0I7RUFFRixNQUFNLG1CQUFtQixNQUFNLFNBQVM7RUFDeEMsSUFBSSxlQUFlO0VBQ25CLElBQUk7R0FDRixnQkFBZ0IsbUJBQ2Qsa0JBQ0EsaUJBQWlCLE9BQ25CO0VBQ0YsU0FBUyxHQUFHO0dBQ1YsUUFBUTtHQUNSLGtCQUFrQjtFQUNwQjtFQUNBLElBQUksQ0FBQyxPQUNILGtCQUFrQjtFQUVwQixJQUFJLGtCQUFrQixlQUFlLFNBQy9CO09BQUEsQ0FBQyxrQkFBa0IsU0FDckIsaUJBQWlCO0VBQUEsT0FFZDtHQUNMLGVBQWUsVUFBVTtHQUN6QiwwQkFBMEIsVUFBVTtHQUNwQyxrQkFBa0IsVUFBVTtHQUM1Qiw0QkFBNEI7RUFDOUI7Q0FDRjtDQUNBLGFBQWEsZ0JBQWdCO0NBQzdCLGFBQWEsYUFBYTtDQUMxQixnQkFBZ0I7Q0FDaEIsTUFBTSwyQkFBMkI7RUFDL0IsaUJBQWlCO0VBQ2pCLGFBQWEsZUFBZTtFQUM1QixhQUFhLGdCQUFnQjtFQUM3QixJQUFJLGlCQUNGLE1BQU07Q0FFVjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7Q0FDekIsT0FBTyxNQUFNO0FBQ2Y7QUFDQSxJQUFJLHFDQUFxQztBQUN6QyxTQUFTLFNBQVMsaUJBQWlCLG9CQUFvQixZQUFZLEVBR2pFLE1BQ0EsaUJBQWlCLGFBQ2pCLG1CQUFtQixjQUNuQixxQkFBcUIsY0FDckIsc0JBQXNCLGNBRXRCLGFBQWEsT0FFYixVQUFVLHNCQUNSLENBQUMsR0FBRztDQUVKLElBQUksU0FBUyxLQUFLLEtBQUssQ0FBQyxvQ0FBb0M7RUFDMUQscUNBQXFDO0VBQ3JDLFFBQ0UsMkZBQ0Y7Q0FDRjtDQUVGLE1BQU0sVUFBVTtDQUNoQixNQUFNLHNCQUFzQix1QkFBdUIsZUFBZTtDQUNsRSxNQUFNLHlCQUF5QiwwQkFBMEIsa0JBQWtCO0NBQzNFLE1BQU0saUJBQWlCLGtCQUFrQixVQUFVO0NBQ25ELE1BQU0sMkJBQTJCLFFBQVEsZUFBZTtDQUN4RCxNQUFNLG1CQUFtQixxQkFBcUI7RUFHMUMsSUFBSSxDQUQ0QixtQ0FBbUIsZ0JBQ3hDLEdBQ1QsTUFBTSxJQUFJLE1BQ1IsbUZBQW1GLG1CQUNqRixnQkFDRixHQUNGO0VBRUosTUFBTSx1QkFBdUIsaUJBQWlCLGVBQWUsaUJBQWlCLFFBQVE7RUFDdEYsTUFBTSxjQUFjLFdBQVcscUJBQXFCO0VBQ3BELE1BQU0seUJBQXlCO0dBQzdCO0dBQ0E7R0FDQTtHQUNBO0dBRUE7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLFNBQVMsZ0JBQWdCLE9BQU87R0FDOUIsTUFBTSxDQUFDLGNBQWMsd0JBQXdCLGdCQUFBLGFBQXNCLGNBQWM7SUFDL0UsTUFBTSxFQUFFLHdCQUF3Qix5QkFBeUIsR0FBRyxrQkFBa0I7SUFDOUUsT0FBTztLQUFDLE1BQU07S0FBUztLQUF5QjtJQUFhO0dBQy9ELEdBQUcsQ0FBQyxLQUFLLENBQUM7R0FDVixNQUFNLGVBQUEsYUFBcUIsY0FBYztJQUN2QyxJQUFJLGdCQUFnQjtJQUNwQixJQUFJLGNBQWMsVUFBVTtLQU14QixJQUFJLENBSjRCLGtDQUVkLDZCQUFNLGNBQWMsYUFBYSxVQUFVLElBQUksQ0FFdEQsR0FDVCxNQUFNLElBQUksTUFDUixpRUFDRjtLQUVGLGdCQUFnQjtJQUVwQjtJQUNBLE9BQU87R0FDVCxHQUFHLENBQUMsY0FBYyxPQUFPLENBQUM7R0FDMUIsTUFBTSxlQUFBLGFBQXFCLFdBQVcsWUFBWTtHQUNsRCxNQUFNLHdCQUF3QixRQUFRLE1BQU0sS0FBSyxLQUFLLFFBQVEsTUFBTSxNQUFNLFFBQVEsS0FBSyxRQUFRLE1BQU0sTUFBTSxRQUFRO0dBQ25ILE1BQU0sMEJBQTBCLFFBQVEsWUFBWSxLQUFLLFFBQVEsYUFBYSxLQUFLO0dBQ25GLElBQTZDLENBQUMseUJBQXlCLENBQUMseUJBQ3RFLE1BQU0sSUFBSSxNQUNSLDZDQUE2QyxZQUFZLDJKQUEySixZQUFZLHFCQUNsTztHQUVGLE1BQU0sUUFBUSx3QkFBd0IsTUFBTSxRQUFRLGFBQWE7R0FDakUsTUFBTSxpQkFBaUIsMEJBQTBCLGFBQWEsaUJBQWlCLE1BQU07R0FDckYsTUFBTSxxQkFBQSxhQUEyQixjQUFjO0lBQzdDLE9BQU8sMEJBQTBCLE1BQU0sVUFBVSxzQkFBc0I7R0FDekUsR0FBRyxDQUFDLEtBQUssQ0FBQztHQUNWLE1BQU0sQ0FBQyxjQUFjLG9CQUFBLGFBQTBCLGNBQWM7SUFDM0QsSUFBSSxDQUFDLDBCQUEwQixPQUFPO0lBQ3RDLE1BQU0sZ0JBQWdCLG1CQUNwQixPQUNBLHdCQUF3QixLQUFLLElBQUksYUFBYSxZQUNoRDtJQUVBLE9BQU8sQ0FBQyxlQURrQixjQUFjLGlCQUFpQixLQUFLLGFBQ3ZCLENBQUM7R0FDMUMsR0FBRztJQUFDO0lBQU87SUFBdUI7R0FBWSxDQUFDO0dBQy9DLE1BQU0seUJBQUEsYUFBK0IsY0FBYztJQUNqRCxJQUFJLHVCQUNGLE9BQU87SUFFVCxPQUFPO0tBQ0wsR0FBRztLQUNIO0lBQ0Y7R0FDRixHQUFHO0lBQUM7SUFBdUI7SUFBYztHQUFZLENBQUM7R0FDdEQsTUFBTSxpQkFBQSxhQUF1QixPQUFPLEtBQUssQ0FBQztHQUMxQyxNQUFNLG1CQUFBLGFBQXlCLE9BQU8sWUFBWTtHQUNsRCxNQUFNLDRCQUFBLGFBQWtDLE9BQU8sS0FBSyxDQUFDO0dBQ3JELE1BQU0sb0JBQUEsYUFBMEIsT0FBTyxLQUFLO0dBQzVDLE1BQU0sWUFBQSxhQUFrQixPQUFPLEtBQUs7R0FDcEMsTUFBTSxrQ0FBQSxhQUF3QyxPQUM1QyxLQUFLLENBQ1A7R0FDQSxnQ0FBZ0M7SUFDOUIsVUFBVSxVQUFVO0lBQ3BCLGFBQWE7S0FDWCxVQUFVLFVBQVU7SUFDdEI7R0FDRixHQUFHLENBQUMsQ0FBQztHQUNMLE1BQU0sMkJBQUEsYUFBaUMsY0FBYztJQUNuRCxNQUFNLGlCQUFpQjtLQUNyQixJQUFJLDBCQUEwQixXQUFXLGlCQUFpQixpQkFBaUIsU0FDekUsT0FBTywwQkFBMEI7S0FFbkMsT0FBTyxtQkFBbUIsTUFBTSxTQUFTLEdBQUcsWUFBWTtJQUMxRDtJQUNBLE9BQU87R0FDVCxHQUFHLENBQUMsT0FBTyxZQUFZLENBQUM7R0FDeEIsTUFBTSxvQkFBQSxhQUEwQixjQUFjO0lBQzVDLE1BQU0sYUFBYSxrQkFBa0I7S0FDbkMsSUFBSSxDQUFDLGNBQ0gsYUFBYSxDQUNiO0tBRUYsT0FBTyxpQkFDTCwwQkFDQSxPQUNBLGNBRUEsb0JBQ0Esa0JBQ0EsZ0JBQ0EsbUJBQ0EsV0FDQSwyQkFDQSxrQkFDQSxhQUNGO0lBQ0Y7SUFDQSxPQUFPO0dBQ1QsR0FBRyxDQUFDLFlBQVksQ0FBQztHQUNqQixrQ0FBa0MscUJBQXFCO0lBQ3JEO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNGLENBQUM7R0FDRCxJQUFJO0dBQ0osSUFBSTtJQUNGLG1CQUFBLGFBQXlCLHFCQUV2QixtQkFHQSwwQkFDQSx1QkFBdUIsbUJBQW1CLGVBQWUsR0FBRyxZQUFZLElBQUksd0JBQzlFO0dBQ0YsU0FBUyxLQUFLO0lBQ1osSUFBSSxnQ0FBZ0MsU0FFbEMsSUFBSSxXQUFXOztFQUV2QixnQ0FBZ0MsUUFBUSxNQUFNOzs7SUFJeEMsTUFBTTtHQUNSO0dBQ0EsZ0NBQWdDO0lBQzlCLGdDQUFnQyxVQUFVLEtBQUs7SUFDL0MsMEJBQTBCLFVBQVUsS0FBSztJQUN6QyxlQUFlLFVBQVU7R0FDM0IsQ0FBQztHQUNELE1BQU0sMkJBQUEsYUFBaUMsY0FBYztJQUNuRCxPQUVrQiw2QkFBTSxjQUNwQixrQkFDQTtLQUNFLEdBQUc7S0FDSCxLQUFLO0lBQ1AsQ0FDRjtHQUVKLEdBQUc7SUFBQztJQUF3QjtJQUFrQjtHQUFnQixDQUFDO0dBTy9ELE9BQUEsYUFONEIsY0FBYztJQUN4QyxJQUFJLDBCQUNGLE9BQXVCLDZCQUFNLGNBQWMsYUFBYSxVQUFVLEVBQUUsT0FBTyx1QkFBdUIsR0FBRyx3QkFBd0I7SUFFL0gsT0FBTztHQUNULEdBQUc7SUFBQztJQUFjO0lBQTBCO0dBQXNCLENBQy9DO0VBQ3JCO0VBRUEsTUFBTSxVQUFBLGFBRGlCLEtBQUssZUFDTDtFQUN2QixRQUFRLG1CQUFtQjtFQUMzQixRQUFRLGNBQWMsZ0JBQWdCLGNBQWM7RUFDcEQsSUFBSSxZQUFZO0dBTWQsTUFBTSxZQUFBLGFBTG1CLFdBQ3ZCLFNBQVMsa0JBQWtCLE9BQU8sS0FBSztJQUNyQyxPQUF1Qiw2QkFBTSxjQUFjLFNBQVM7S0FBRSxHQUFHO0tBQU8sd0JBQXdCO0lBQUksQ0FBQztHQUMvRixDQUV5QjtHQUMzQixVQUFVLGNBQWM7R0FDeEIsVUFBVSxtQkFBbUI7R0FDN0IsT0FBdUIscUNBQXFCLFdBQVcsZ0JBQWdCO0VBQ3pFO0VBQ0EsT0FBdUIscUNBQXFCLFNBQVMsZ0JBQWdCO0NBQ3ZFO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBSSxVQUFVO0FBQ2QsSUFBSSxpQkFBaUI7QUFHckIsU0FBUyxTQUFTLGVBQWU7Q0FDL0IsTUFBTSxFQUFFLFVBQVUsU0FBUyxhQUFhLFVBQVU7Q0FDbEQsTUFBTSxlQUFBLGFBQXFCLGNBQWM7RUFDdkMsTUFBTSxlQUFlLG1CQUFtQixLQUFLO0VBQzdDLE1BQU0sbUJBQW1CO0dBQ3ZCO0dBQ0E7R0FDQSxnQkFBZ0Isb0JBQW9CLGNBQWMsS0FBSztFQUN6RDtFQUdPO0dBQ0wsTUFBTSxFQUFFLHdCQUF3QixRQUFRLGlCQUFpQixXQUFXO0dBQ3BFLE9BQXVCLHVCQUFPLE9BQU8sa0JBQWtCO0lBQ3JEO0lBQ0E7R0FDRixDQUFDO0VBQ0g7Q0FDRixHQUFHLENBQUMsT0FBTyxXQUFXLENBQUM7Q0FDdkIsTUFBTSxnQkFBQSxhQUFzQixjQUFjLE1BQU0sU0FBUyxHQUFHLENBQUMsS0FBSyxDQUFDO0NBQ25FLGdDQUFnQztFQUM5QixNQUFNLEVBQUUsaUJBQWlCO0VBQ3pCLGFBQWEsZ0JBQWdCLGFBQWE7RUFDMUMsYUFBYSxhQUFhO0VBQzFCLElBQUksa0JBQWtCLE1BQU0sU0FBUyxHQUNuQyxhQUFhLGlCQUFpQjtFQUVoQyxhQUFhO0dBQ1gsYUFBYSxlQUFlO0dBQzVCLGFBQWEsZ0JBQWdCLEtBQUs7RUFDcEM7Q0FDRixHQUFHLENBQUMsY0FBYyxhQUFhLENBQUM7Q0FDaEMsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsT0FBdUIsNkJBQU0sY0FBYyxRQUFRLFVBQVUsRUFBRSxPQUFPLGFBQWEsR0FBRyxRQUFRO0FBQ2hHO0FBQ0EsSUFBSSxtQkFBbUI7QUFHdkIsU0FBUyx1QkFBdUIsVUFBVSxtQkFBbUI7Q0FDM0QsT0FBTyxTQUFTLG1CQUFtQjtFQUNqQyxNQUFNLGVBQUEsYUFBcUIsV0FBVyxPQUFPO0VBQzdDLElBQTZDLENBQUMsY0FDNUMsTUFBTSxJQUFJLE1BQ1Isa0dBQ0Y7RUFFRixPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQUksa0JBQWtDLHVDQUF1QjtBQUc3RCxTQUFTLGdCQUFnQixVQUFVLG1CQUFtQjtDQUNwRCxNQUFNLG1CQUFtQixZQUFZLG9CQUFvQixrQkFFdkQsdUJBQXVCLE9BQU87Q0FFaEMsTUFBTSxrQkFBa0I7RUFDdEIsTUFBTSxFQUFFLFVBQVUsaUJBQWlCO0VBQ25DLE9BQU87Q0FDVDtDQUNBLE9BQU8sT0FBTyxXQUFXLEVBQ3ZCLGlCQUFpQixVQUNuQixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsSUFBSSxXQUEyQixnQ0FBZ0I7QUFHL0MsU0FBUyxtQkFBbUIsVUFBVSxtQkFBbUI7Q0FDdkQsTUFBTSxZQUFZLFlBQVksb0JBQW9CLFdBQVcsZ0JBQWdCLE9BQU87Q0FDcEYsTUFBTSxxQkFBcUI7RUFFekIsT0FEYyxVQUNILENBQUMsQ0FBQztDQUNmO0NBQ0EsT0FBTyxPQUFPLGNBQWMsRUFDMUIsaUJBQWlCLGFBQ25CLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxJQUFJLGNBQThCLG1DQUFtQjtBQUlyRCxJQUFJLGVBQWUsR0FBRyxNQUFNLE1BQU07QUFDbEMsU0FBUyxtQkFBbUIsVUFBVSxtQkFBbUI7Q0FDdkQsTUFBTSxtQkFBbUIsWUFBWSxvQkFBb0Isa0JBQWtCLHVCQUF1QixPQUFPO0NBQ3pHLE1BQU0sZ0JBQWdCLFVBQVUsc0JBQXNCLENBQUMsTUFBTTtFQUMzRCxNQUFNLEVBQUUsYUFBYSxnQkFBZ0IsT0FBTyx3QkFBd0IsYUFBYSxFQUFFLFlBQVksb0JBQW9CLElBQUk7RUFFckgsSUFBSSxDQUFDLFVBQ0gsTUFBTSxJQUFJLE1BQU0seUNBQXlDO0VBRTNELElBQUksT0FBTyxhQUFhLFlBQ3RCLE1BQU0sSUFBSSxNQUFNLHVEQUF1RDtFQUV6RSxJQUFJLE9BQU8sZUFBZSxZQUN4QixNQUFNLElBQUksTUFDUixpRUFDRjtFQUdKLE1BQU0sZUFBZSxpQkFBaUI7RUFDdEMsTUFBTSxFQUFFLE9BQU8sY0FBYyxtQkFBbUI7RUFDaEQsTUFBTSxXQUFBLGFBQWlCLE9BQU8sSUFBSTtFQUNsQyxNQUFNLGtCQUFBLGFBQXdCLFlBQzVCLEVBQ0UsQ0FBQyxTQUFTLE1BQU0sT0FBTztHQUNyQixNQUFNLFdBQVcsU0FBUyxLQUFLO0dBQ1k7SUFDekMsTUFBTSxFQUFFLGdCQUFnQixDQUFDLE1BQU0sT0FBTyx3QkFBd0IsYUFBYSxDQUFDLElBQUk7SUFDaEYsTUFBTSxFQUFFLHVCQUF1QixtQkFBbUI7SUFDbEQsTUFBTSxFQUNKLHVCQUF1Qiw0QkFDdkIsZ0JBQWdCLHdCQUNkO0tBQ0Y7S0FDQTtLQUNBLEdBQUc7SUFDTDtJQUNBLElBQUksd0JBQXdCLFlBQVksd0JBQXdCLFVBQVUsU0FBUyxTQUFTO0tBQzFGLE1BQU0sWUFBWSxTQUFTLEtBQUs7S0FDaEMsSUFBSSxDQUFDLFdBQVcsVUFBVSxTQUFTLEdBQUc7TUFDcEMsSUFBSSxRQUFRLEtBQUs7TUFDakIsSUFBSTtPQUNGLE1BQU0sSUFBSSxNQUFNO01BQ2xCLFNBQVMsR0FBRztPQUVWLENBQUMsQ0FBRSxTQUFVO01BQ2Y7TUFDQSxRQUFRLEtBQ04sZUFBZSxTQUFTLFFBQVEsYUFBYSxrU0FDN0M7T0FDRTtPQUNBO09BQ0EsV0FBVztPQUNYO01BQ0YsQ0FDRjtLQUNGO0lBQ0Y7SUFDQSxJQUFJLCtCQUErQixZQUFZLCtCQUErQixVQUFVLFNBQVMsU0FDM0Y7U0FBQSxhQUFhLE9BQU87TUFDdEIsSUFBSSxRQUFRLEtBQUs7TUFDakIsSUFBSTtPQUNGLE1BQU0sSUFBSSxNQUFNO01BQ2xCLFNBQVMsR0FBRztPQUVWLENBQUMsQ0FBRSxTQUFVO01BQ2Y7TUFDQSxRQUFRLEtBQ04sZUFBZSxTQUFTLFFBQVEsYUFBYSw2TkFDN0MsRUFBRSxNQUFNLENBQ1Y7S0FDRjs7SUFFRixJQUFJLFNBQVMsU0FBUyxTQUFTLFVBQVU7R0FDM0M7R0FDQSxPQUFPO0VBQ1QsRUFDRixFQUFFLFNBQVMsT0FDWCxDQUFDLFFBQVEsQ0FDWDtFQUNBLE1BQU0saUJBQUEsR0FBZ0JBLHFCQUFBQSxpQ0FBQUEsQ0FDcEIsYUFBYSxjQUNiLE1BQU0sVUFDTixrQkFBa0IsTUFBTSxVQUN4QixpQkFDQSxVQUNGO0VBQ0EsYUFBTSxjQUFjLGFBQWE7RUFDakMsT0FBTztDQUNUO0NBQ0EsT0FBTyxPQUFPLGNBQWMsRUFDMUIsaUJBQWlCLGFBQ25CLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxJQUFJLGNBQThCLG1DQUFtQjtBQUdyRCxJQUFJLFFBQVEiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDJdfQ==