/**
* Copyright 2018 Google Inc. All Rights Reserved.
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*     http://www.apache.org/licenses/LICENSE-2.0
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
// If the loader is already loaded, just stop.
if (!self.define) {
	let registry = {};
	// Used for `eval` and `importScripts` where we can't get script URL by other means.
	// In both cases, it's safe to use a global var because those functions are synchronous.
	let nextDefineUri;
	const singleRequire = (uri, parentUri) => {
		uri = new URL(uri + ".js", parentUri).href;
		return registry[uri] || new Promise((resolve) => {
			if ("document" in self) {
				const script = document.createElement("script");
				script.src = uri;
				script.onload = resolve;
				document.head.appendChild(script);
			} else {
				nextDefineUri = uri;
				importScripts(uri);
				resolve();
			}
		}).then(() => {
			let promise = registry[uri];
			if (!promise) {
				throw new Error(`Module ${uri} didn’t register its module`);
			}
			return promise;
		});
	};
	self.define = (depsNames, factory) => {
		const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
		if (registry[uri]) {
			// Module is already loading or loaded.
			return;
		}
		let exports = {};
		const require = (depUri) => singleRequire(depUri, uri);
		const specialDeps = {
			module: { uri },
			exports,
			require
		};
		registry[uri] = Promise.all(depsNames.map((depName) => specialDeps[depName] || require(depName))).then((deps) => {
			factory(...deps);
			return exports;
		});
	};
}
define(["./workbox-7e5eb42b"], (function(workbox) {
	"use strict";
	self.skipWaiting();
	workbox.clientsClaim();
	/**
	* The precacheAndRoute() method efficiently caches and responds to
	* requests for URLs in the manifest.
	* See https://goo.gl/S9QRab
	*/
	workbox.precacheAndRoute([{
		"url": "registerSW.js",
		"revision": "3ca0b8505b4bec776b69afdba2768812"
	}, {
		"url": "index.html",
		"revision": "0.nktnverr50g"
	}], {});
	workbox.cleanupOutdatedCaches();
	workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), { allowlist: [/^\/$/] }));
}));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQWNBLElBQUksQ0FBQyxLQUFLLFFBQVE7Q0FDaEIsSUFBSSxXQUFXLENBQUM7OztDQUloQixJQUFJO0NBRUosTUFBTSxpQkFBaUIsS0FBSyxjQUFjO0VBQ3hDLE1BQU0sSUFBSSxJQUFJLE1BQU0sT0FBTyxTQUFTLENBQUMsQ0FBQztFQUN0QyxPQUFPLFNBQVMsUUFFWixJQUFJLFNBQVEsWUFBVztHQUNyQixJQUFJLGNBQWMsTUFBTTtJQUN0QixNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7SUFDOUMsT0FBTyxNQUFNO0lBQ2IsT0FBTyxTQUFTO0lBQ2hCLFNBQVMsS0FBSyxZQUFZLE1BQU07R0FDbEMsT0FBTztJQUNMLGdCQUFnQjtJQUNoQixjQUFjLEdBQUc7SUFDakIsUUFBUTtHQUNWO0VBQ0YsQ0FBQyxDQUFDLENBRUgsV0FBVztHQUNWLElBQUksVUFBVSxTQUFTO0dBQ3ZCLElBQUksQ0FBQyxTQUFTO0lBQ1osTUFBTSxJQUFJLE1BQU0sVUFBVSxJQUFJLDRCQUE0QjtHQUM1RDtHQUNBLE9BQU87RUFDVCxDQUFDO0NBRUw7Q0FFQSxLQUFLLFVBQVUsV0FBVyxZQUFZO0VBQ3BDLE1BQU0sTUFBTSxrQkFBa0IsY0FBYyxPQUFPLFNBQVMsY0FBYyxNQUFNLE9BQU8sU0FBUztFQUNoRyxJQUFJLFNBQVMsTUFBTTs7R0FFakI7RUFDRjtFQUNBLElBQUksVUFBVSxDQUFDO0VBQ2YsTUFBTSxXQUFVLFdBQVUsY0FBYyxRQUFRLEdBQUc7RUFDbkQsTUFBTSxjQUFjO0dBQ2xCLFFBQVEsRUFBRSxJQUFJO0dBQ2Q7R0FDQTtFQUNGO0VBQ0EsU0FBUyxPQUFPLFFBQVEsSUFBSSxVQUFVLEtBQ3BDLFlBQVcsWUFBWSxZQUFZLFFBQVEsT0FBTyxDQUNwRCxDQUFDLENBQUMsQ0FBQyxNQUFLLFNBQVE7R0FDZCxRQUFRLEdBQUcsSUFBSTtHQUNmLE9BQU87RUFDVCxDQUFDO0NBQ0g7QUFDRjtBQUNBLE9BQU8sQ0FBQyxvQkFBb0IsSUFBSSxTQUFVLFNBQVM7Q0FBRTtDQUVuRCxLQUFLLFlBQVk7Q0FDakIsUUFBUSxhQUFhOzs7Ozs7Q0FNckIsUUFBUSxpQkFBaUIsQ0FBQztFQUN4QixPQUFPO0VBQ1AsWUFBWTtDQUNkLEdBQUc7RUFDRCxPQUFPO0VBQ1AsWUFBWTtDQUNkLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDTixRQUFRLHNCQUFzQjtDQUM5QixRQUFRLGNBQWMsSUFBSSxRQUFRLGdCQUFnQixRQUFRLHdCQUF3QixZQUFZLEdBQUcsRUFDL0YsV0FBVyxDQUFDLE1BQU0sRUFDcEIsQ0FBQyxDQUFDO0FBRUosRUFBRSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJkZXYtc3cuanM/ZGV2LXN3Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDb3B5cmlnaHQgMjAxOCBHb29nbGUgSW5jLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxyXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xyXG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXHJcbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxyXG4gKiAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXHJcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcclxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxyXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cclxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxyXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuICovXHJcblxyXG4vLyBJZiB0aGUgbG9hZGVyIGlzIGFscmVhZHkgbG9hZGVkLCBqdXN0IHN0b3AuXHJcbmlmICghc2VsZi5kZWZpbmUpIHtcclxuICBsZXQgcmVnaXN0cnkgPSB7fTtcclxuXHJcbiAgLy8gVXNlZCBmb3IgYGV2YWxgIGFuZCBgaW1wb3J0U2NyaXB0c2Agd2hlcmUgd2UgY2FuJ3QgZ2V0IHNjcmlwdCBVUkwgYnkgb3RoZXIgbWVhbnMuXHJcbiAgLy8gSW4gYm90aCBjYXNlcywgaXQncyBzYWZlIHRvIHVzZSBhIGdsb2JhbCB2YXIgYmVjYXVzZSB0aG9zZSBmdW5jdGlvbnMgYXJlIHN5bmNocm9ub3VzLlxyXG4gIGxldCBuZXh0RGVmaW5lVXJpO1xyXG5cclxuICBjb25zdCBzaW5nbGVSZXF1aXJlID0gKHVyaSwgcGFyZW50VXJpKSA9PiB7XHJcbiAgICB1cmkgPSBuZXcgVVJMKHVyaSArIFwiLmpzXCIsIHBhcmVudFVyaSkuaHJlZjtcclxuICAgIHJldHVybiByZWdpc3RyeVt1cmldIHx8IChcclxuICAgICAgXHJcbiAgICAgICAgbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XHJcbiAgICAgICAgICBpZiAoXCJkb2N1bWVudFwiIGluIHNlbGYpIHtcclxuICAgICAgICAgICAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKTtcclxuICAgICAgICAgICAgc2NyaXB0LnNyYyA9IHVyaTtcclxuICAgICAgICAgICAgc2NyaXB0Lm9ubG9hZCA9IHJlc29sdmU7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIG5leHREZWZpbmVVcmkgPSB1cmk7XHJcbiAgICAgICAgICAgIGltcG9ydFNjcmlwdHModXJpKTtcclxuICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIFxyXG4gICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgbGV0IHByb21pc2UgPSByZWdpc3RyeVt1cmldO1xyXG4gICAgICAgIGlmICghcHJvbWlzZSkge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNb2R1bGUgJHt1cml9IGRpZG7igJl0IHJlZ2lzdGVyIGl0cyBtb2R1bGVgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHByb21pc2U7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIHNlbGYuZGVmaW5lID0gKGRlcHNOYW1lcywgZmFjdG9yeSkgPT4ge1xyXG4gICAgY29uc3QgdXJpID0gbmV4dERlZmluZVVyaSB8fCAoXCJkb2N1bWVudFwiIGluIHNlbGYgPyBkb2N1bWVudC5jdXJyZW50U2NyaXB0LnNyYyA6IFwiXCIpIHx8IGxvY2F0aW9uLmhyZWY7XHJcbiAgICBpZiAocmVnaXN0cnlbdXJpXSkge1xyXG4gICAgICAvLyBNb2R1bGUgaXMgYWxyZWFkeSBsb2FkaW5nIG9yIGxvYWRlZC5cclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgbGV0IGV4cG9ydHMgPSB7fTtcclxuICAgIGNvbnN0IHJlcXVpcmUgPSBkZXBVcmkgPT4gc2luZ2xlUmVxdWlyZShkZXBVcmksIHVyaSk7XHJcbiAgICBjb25zdCBzcGVjaWFsRGVwcyA9IHtcclxuICAgICAgbW9kdWxlOiB7IHVyaSB9LFxyXG4gICAgICBleHBvcnRzLFxyXG4gICAgICByZXF1aXJlXHJcbiAgICB9O1xyXG4gICAgcmVnaXN0cnlbdXJpXSA9IFByb21pc2UuYWxsKGRlcHNOYW1lcy5tYXAoXHJcbiAgICAgIGRlcE5hbWUgPT4gc3BlY2lhbERlcHNbZGVwTmFtZV0gfHwgcmVxdWlyZShkZXBOYW1lKVxyXG4gICAgKSkudGhlbihkZXBzID0+IHtcclxuICAgICAgZmFjdG9yeSguLi5kZXBzKTtcclxuICAgICAgcmV0dXJuIGV4cG9ydHM7XHJcbiAgICB9KTtcclxuICB9O1xyXG59XHJcbmRlZmluZShbJy4vd29ya2JveC03ZTVlYjQyYiddLCAoZnVuY3Rpb24gKHdvcmtib3gpIHsgJ3VzZSBzdHJpY3QnO1xuXG4gIHNlbGYuc2tpcFdhaXRpbmcoKTtcbiAgd29ya2JveC5jbGllbnRzQ2xhaW0oKTtcbiAgLyoqXG4gICAqIFRoZSBwcmVjYWNoZUFuZFJvdXRlKCkgbWV0aG9kIGVmZmljaWVudGx5IGNhY2hlcyBhbmQgcmVzcG9uZHMgdG9cbiAgICogcmVxdWVzdHMgZm9yIFVSTHMgaW4gdGhlIG1hbmlmZXN0LlxuICAgKiBTZWUgaHR0cHM6Ly9nb28uZ2wvUzlRUmFiXG4gICAqL1xuICB3b3JrYm94LnByZWNhY2hlQW5kUm91dGUoW3tcbiAgICBcInVybFwiOiBcInJlZ2lzdGVyU1cuanNcIixcbiAgICBcInJldmlzaW9uXCI6IFwiM2NhMGI4NTA1YjRiZWM3NzZiNjlhZmRiYTI3Njg4MTJcIlxuICB9LCB7XG4gICAgXCJ1cmxcIjogXCJpbmRleC5odG1sXCIsXG4gICAgXCJyZXZpc2lvblwiOiBcIjAubmt0bnZlcnI1MGdcIlxuICB9XSwge30pO1xuICB3b3JrYm94LmNsZWFudXBPdXRkYXRlZENhY2hlcygpO1xuICB3b3JrYm94LnJlZ2lzdGVyUm91dGUobmV3IHdvcmtib3guTmF2aWdhdGlvblJvdXRlKHdvcmtib3guY3JlYXRlSGFuZGxlckJvdW5kVG9VUkwoXCJpbmRleC5odG1sXCIpLCB7XG4gICAgYWxsb3dsaXN0OiBbL15cXC8kL11cbiAgfSkpO1xuXG59KSk7XG4iXX0=